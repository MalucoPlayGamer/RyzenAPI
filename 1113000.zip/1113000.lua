-- Lua provided by RyzenAPI
-- Game: Persona 4 Golden

-- MAIN APPLICATION
addappid(1113000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1113001, 1, "0f306d31499478d6f1a6971240693c21891f3887103f5f2c92766c20a91cc0ec")
addappid(1113002, 1, "b10005d38f9cc7dd78f58cb736b8b8f2c9401087b8ac0a5386737bae70fe3a46")

