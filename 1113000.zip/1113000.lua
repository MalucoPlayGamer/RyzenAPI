-- Lua provided by SkyAPI 
-- Game: Persona 4 Golden
addappid(1113000)
addappid(1113001, 1, "0f306d31499478d6f1a6971240693c21891f3887103f5f2c92766c20a91cc0ec")
addappid(1113002, 1, "b10005d38f9cc7dd78f58cb736b8b8f2c9401087b8ac0a5386737bae70fe3a46")
