-- Lua provided by SkyAPI 
-- Game: Milf City
addappid(1706820)
addappid(1706821, 1, "b04ff44688067aa0f1bc30d30b4adc392853b0afa2136b7b155b72c5699f4ae5")
