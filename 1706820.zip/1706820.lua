-- Lua provided by RyzenAPI
-- Game: 1706820

-- MAIN APPLICATION
addappid(1706820)
-- Game: addappid(1706820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706821, 1, "b04ff44688067aa0f1bc30d30b4adc392853b0afa2136b7b155b72c5699f4ae5")
