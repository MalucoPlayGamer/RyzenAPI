-- Lua provided by RyzenAPI
-- Game: 1997420

-- MAIN APPLICATION
addappid(1997420)
-- Game: addappid(1997420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997421, 1, "ee9f16682ca6951c8fef80e3f483517ed8a475cfb4ec240611ce568a1cd76275")
