-- Lua provided by RyzenAPI
-- Game: 1938680

-- MAIN APPLICATION
addappid(1938680)
-- Game: addappid(1938680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1938680,0,"621c3ccf7710f0d63f3ee70d2762c5fc42ca5f009b35846398abaaaf0752a1c0")
