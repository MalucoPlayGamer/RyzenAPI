-- Lua provided by RyzenAPI
-- Game: Shadow Puppets & Beijing opera

-- MAIN APPLICATION
addappid(228983)
addappid(228984)
addappid(228985)
addappid(228988)
addappid(1240840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240842,0,"8b6d23c41465e498f239de3268556ccfb6a1be78387730ad6dd2da3481f19089")
addappid(1240843,0,"b63fc6b9db2e5ebc380c95bb16b860b4e1c000dffc64a7638624be4c994da7b5")

