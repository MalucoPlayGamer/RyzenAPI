-- Lua provided by RyzenAPI
-- Game: Game: Murder Machine Mini

-- MAIN APPLICATION
addappid(1024730)
-- Game: addappid(1024730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024731, 1, "5fe5cddd15b96cb447f7049af687a86f8bce22551bc891ce8b52d272887632c1")
