-- Lua provided by RyzenAPI
-- Game: Fish's Trip

-- MAIN APPLICATION
addappid(701960)

-- MAIN APP DEPOTS / PACKAGES
addappid(701961,0,"e2c2fae110c4da3cf31ee6978674f96e46cea50764d44b3f52981e0a0e789146")

