-- Lua provided by RyzenAPI
-- Game: Tower Princess

-- MAIN APPLICATION
addappid(1138650)
addappid(2141310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138651, 1, "143a746d23c3fb9f41cbb2533201742110293bb8c0526a245c0d8aea68749fae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
