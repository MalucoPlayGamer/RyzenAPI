-- Lua provided by SkyAPI 
-- Game: Tower Princess
addappid(1138650)
addappid(1138651, 1, "143a746d23c3fb9f41cbb2533201742110293bb8c0526a245c0d8aea68749fae")
addappid(2141310)
