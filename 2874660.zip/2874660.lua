-- Lua provided by RyzenAPI
-- Game: Exit: Left or Right

-- MAIN APPLICATION
addappid(2874660)
-- Game: addappid(2874660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2874661, 1, "26d2065a11d9b030fa78a872fcb26b427bfe281a8c7276906535aee3b219d68c")
