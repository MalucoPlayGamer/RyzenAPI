-- Lua provided by RyzenAPI
-- Game: Exit: Left or Right

-- MAIN APPLICATION
addappid(2874660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2874661, 1, "26d2065a11d9b030fa78a872fcb26b427bfe281a8c7276906535aee3b219d68c")

