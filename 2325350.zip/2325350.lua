-- Lua provided by RyzenAPI
-- Game: addappid(2325350)

-- MAIN APPLICATION
addappid(2325350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2325351, 1, "ab3653d569e4d723469490d06530dbd9dc168b222e3990266fcaa3dabd8d404f")
