-- Lua provided by RyzenAPI
-- Game: addappid(949600)

-- MAIN APPLICATION
addappid(949600)

-- MAIN APP DEPOTS / PACKAGES
addappid(949601, 1, "da3feef0c5e345f78c85e87a1cb2d78c6c18495289418edcaa230bd250dffba8")
