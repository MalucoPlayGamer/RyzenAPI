-- Lua provided by RyzenAPI
-- Game: September Fall - Loneliness

-- MAIN APPLICATION
addappid(3124460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3124461, 1, "2ad58afe880b93535b6131beb26f03a79d9c1172488f449ffd47ac1b990dc532")
