-- Lua provided by RyzenAPI
-- Game: One Final Chaos

-- MAIN APPLICATION
addappid(409610)
-- Game: addappid(409610)

-- MAIN APP DEPOTS / PACKAGES
addappid(409611, 1, "ea0b3310689e41146c1f0cb822602902891e60a9d4f9dd2e98d70978016a77fc")
