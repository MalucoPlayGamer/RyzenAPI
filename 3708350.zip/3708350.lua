-- Lua provided by RyzenAPI
-- Game: Game: WTF: Waifu Tactical Force Playtest

-- MAIN APPLICATION
addappid(3708350)
-- Game: addappid(3708350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3708351, 1, "5cc36640450303e9ced3962f2da16d024eaf2b259b196c068218ff01aba4568e")
