-- Lua provided by RyzenAPI
-- Game: AppID 1832720

-- MAIN APPLICATION
addappid(1832720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832721, 1, "48bf9c769630d1fa249f69da003084b1cd899711accb2983eaaae70d6f1d4a6b")

