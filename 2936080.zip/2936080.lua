-- Lua provided by RyzenAPI
-- Game: ReSetna

-- MAIN APPLICATION
addappid(2936080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2936081, 1, "cb2163bacefaccd77ee61cba9322358f3c6632597c7d978e284c783463e27190")

