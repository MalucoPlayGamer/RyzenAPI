-- Lua provided by SkyAPI 
-- Game: Hollow Remnant
addappid(1234600)
addappid(1234601, 1, "dd5a8a15977666d1acf30a27c4b0927888ab0b8c3faa57680de1f050cbbb6209")
