-- Lua provided by RyzenAPI
-- Game: Cross and Gun

-- MAIN APPLICATION
addappid(3828730)
-- Game: addappid(3828730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3828731, 1, "6060df5f9267aae512d2e0797529bf82a88fd19c6096fb1ff341e5d1e0670d38")
