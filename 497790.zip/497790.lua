-- Lua provided by RyzenAPI
-- Game: 497790

-- MAIN APPLICATION
addappid(497790)
-- Game: addappid(497790)

-- MAIN APP DEPOTS / PACKAGES
addappid(497791, 1, "ed2651173e956878d2106d66361395bb0627aab604dc65cb85c4e3a851d1a354")
