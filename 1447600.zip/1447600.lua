-- Lua provided by RyzenAPI
-- Game: Pandemos

-- MAIN APPLICATION
addappid(1447600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447601, 1, "df85fe9e221db8bb52d9d3fef315abb8a057b7d620f2280079e34c2c18bf7da8")

