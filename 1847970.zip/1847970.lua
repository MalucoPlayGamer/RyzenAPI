-- Lua provided by RyzenAPI
-- Game: 1847970

-- MAIN APPLICATION
addappid(1847970)
-- Game: addappid(1847970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1847971, 1, "9ec6d392a34c113ccbf314ed0f8864f10348aecccaa73d1ca0dab7138a8adfb2")
