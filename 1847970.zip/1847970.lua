-- Lua provided by RyzenAPI
-- Game: STARTMOVE

-- MAIN APPLICATION
addappid(1847970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1847971, 1, "9ec6d392a34c113ccbf314ed0f8864f10348aecccaa73d1ca0dab7138a8adfb2")

