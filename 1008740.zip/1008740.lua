-- Lua provided by RyzenAPI
-- Game: addappid(1008740)

-- MAIN APPLICATION
addappid(1008740)
addappid(1039700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1008741, 1, "07bc36db124ec7af5bd27b723dcc6e5bc8ee342cc589f87e4294b9608268ff7e")
