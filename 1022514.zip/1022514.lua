-- Lua provided by RyzenAPI
-- Game: DFF NT: Truth Seeker, Y'shtola's EX weapon

-- MAIN APPLICATION
addappid(1022514)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022514,0,"b6d9b2c4f01ca996ac67c755c725f9c8ceff3c7c4024010c2d8f8882ad3917c5")

