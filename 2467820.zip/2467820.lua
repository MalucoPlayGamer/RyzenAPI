-- Lua provided by RyzenAPI
-- Game: Game: AppID 2467820

-- MAIN APPLICATION
addappid(2467820)
-- Game: addappid(2467820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467821, 1, "d9d31a9fa9275d914a897b074ed98f57f375cdac635665545e5aa425cc75940e")
