-- Lua provided by RyzenAPI
-- Game: addappid(3254100)

-- MAIN APPLICATION
addappid(3254100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3254101, 1, "7bccf428831a0c6ac954c039fbe9276721f013cab39ceb5e25ee4c3b2a8c78fc")
