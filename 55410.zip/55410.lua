-- Lua provided by RyzenAPI
-- Game: 55410

-- MAIN APPLICATION
addappid(55410)
-- Game: addappid(55410)

-- MAIN APP DEPOTS / PACKAGES
addappid(55419,0,"91c0789c000ff021f6b5c81908e8bbf29ffd5168a1bf77cd76f8781bb49a4da9")
addappid(55420,0,"16e0082e12a32324e3844c2b781e21bae12f26d1180a2ed58fca9857ea9d9ead")
