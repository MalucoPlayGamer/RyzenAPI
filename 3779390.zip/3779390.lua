-- Lua provided by RyzenAPI
-- Game: Dungeon of Erotic Master Reboot

-- MAIN APPLICATION
addappid(3779390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3779392,0,"f758e55423074650d6a9ae051eb97068f6a40757d3f4db8cd08d7a5ed94cb2a3")

