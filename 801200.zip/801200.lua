-- Lua provided by SkyAPI 
-- Game: AppID 801200
addappid(801200)
addappid(801201, 1, "a4c43d67a7642ed35ddf1903f66799a50910f955ff2512c6622fb5cb46c5b8a8")
