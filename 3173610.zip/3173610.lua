-- Lua provided by RyzenAPI
-- Game: Yaoling: Mythical Journey Soundtrack

-- MAIN APPLICATION
addappid(3173610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3173611, 1, "7b5f2b4226bf1755cd9b28f5ff8f850546a5036ed7299f2f6a425759e0b9e3b5")

