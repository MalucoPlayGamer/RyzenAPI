-- Lua provided by RyzenAPI
-- Game: Battle Royale Survival

-- MAIN APPLICATION
addappid(923790)

-- MAIN APP DEPOTS / PACKAGES
addappid(923791, 1, "8ae7696059418188de7a178aa57a2aab5167b8ba5df9464fd91eff2cc8b949a1")
