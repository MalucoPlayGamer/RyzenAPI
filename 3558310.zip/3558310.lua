-- Lua provided by RyzenAPI
-- Game: addappid(3558310)

-- MAIN APPLICATION
addappid(3558310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3558311, 1, "492b53645d0edc258e82c18431600f9f38791aaff3f49ebf172f2fdb4e288855")
