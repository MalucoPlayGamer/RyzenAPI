-- Lua provided by RyzenAPI
-- Game: Game: AppID 749890

-- MAIN APPLICATION
addappid(749890)
-- Game: addappid(749890)

-- MAIN APP DEPOTS / PACKAGES
addappid(749891, 1, "ca27c11502c5c4c68ed5b012d373bf83d62241b17308ebe1af04d4a36712cd8c")
addappid(749893, 1, "bcae436e28d15ee2b0aef746151afd2b0e324014c551d188cd7d0abb37c49848")
addappid(749896, 1, "68dd6d287fac80851613a781e2948d7af46f06236aa18823ffcf69d3d4e500d6")
