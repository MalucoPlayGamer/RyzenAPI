-- Lua provided by RyzenAPI
-- Game: Brothel Simulator (妓院模拟器)

-- MAIN APPLICATION
addappid(3764330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3764331, 1, "00222f43a94570dff22a114171869d6b94c2c52af7259a61bc44cb027c1f70a9")

