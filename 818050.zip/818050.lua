-- Lua provided by RyzenAPI
-- Game: Wormster Dash

-- MAIN APPLICATION
addappid(818050)

-- MAIN APP DEPOTS / PACKAGES
addappid(818051, 1, "4fb4d7065c6b7a88c80954bd6dfd0052839489fd68a3aaa83fc989bae1679380")
addappid(818052, 1, "48a3c192a7e45f086c7565025100712db391a6cbf1ffc8bba815bb9a7221bc20")
