-- Lua provided by RyzenAPI
-- Game: Lost in Play

-- MAIN APPLICATION
addappid(1328840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328841, 1, "ced632dc70dc2b26d0dd6394025b43c0b54e4e580ee72da795b4ce31ced31b7b")
addappid(1328842, 1, "08f81f199e072973d6313488cd4722619777b0d46545dfe1fa546f824abb32cf")
