-- Lua provided by RyzenAPI 
-- Game: Chrono Survival
addappid(1897740)
addappid(1897741, 1, "1bcd154be8739cf7e7f296d967d87760b4a474d8d2d7bb1187ee0d62a1598f3f")
