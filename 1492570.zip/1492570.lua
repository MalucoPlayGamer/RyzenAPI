-- Lua provided by RyzenAPI
-- Game: Race To Sanity

-- MAIN APPLICATION
addappid(1492570)
-- Game: addappid(1492570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492571, 1, "99a0df70f925bc7ad0018bf4a692be308aa6e42b8fb9a5a04d694b17982407a6")
