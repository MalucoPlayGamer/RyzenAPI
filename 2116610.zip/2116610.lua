-- Lua provided by RyzenAPI
-- Game: Game: Seclusa

-- MAIN APPLICATION
addappid(2116610)
-- Game: addappid(2116610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2116611, 1, "4a4f455edb08f67aa21975a5aadcd59dee949fe10b98049228afbad633c9889f")
