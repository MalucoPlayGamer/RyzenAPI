-- 4362790's Lua and Manifest Created by Hubcap Manifest
-- Fit Happens: A Clothing Shop Simulator
-- Created: July 18, 2026 at 09:40:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4362790) -- Fit Happens: A Clothing Shop Simulator
-- MAIN APP DEPOTS
addappid(4362791, 1, "7dde91b4b1af7cbdb642e94710ae95c816f2e0aaf097d94d21c277662b0a0426") -- Depot 4362791
setManifestid(4362791, "901628042917450664", 757418982)