-- Lua provided by SkyAPI 
-- Game: ESCAPE FROM TIMOKHA 2: ARMY
addappid(3554450)
addappid(3554451, 1, "04372e0dfb51b09feacab25028b8bbf9a684d8437157db959a46de0e49d4250a")
