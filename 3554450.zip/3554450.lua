-- Lua provided by RyzenAPI
-- Game: 3554450

-- MAIN APPLICATION
addappid(3554450)
-- Game: addappid(3554450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3554451, 1, "04372e0dfb51b09feacab25028b8bbf9a684d8437157db959a46de0e49d4250a")
