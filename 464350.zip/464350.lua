-- Lua provided by RyzenAPI
-- Game: Screeps: World

-- MAIN APPLICATION
addappid(464350)

-- MAIN APP DEPOTS / PACKAGES
addappid(464351, 1, "83f3f4220b963d7eb32c9a7ac6f93d9d3ce94632932272f6633ebaeb9d427df6")
addappid(464352, 1, "5a8e0899ce3e030e108334786dbf36b17833d4f8c09769b1dd088e06ec6e9b28")
addappid(464353, 1, "ceac7b95dcb3b557392bf956669626a7ac0c02436da573d31d84d314c10c0946")
addappid(464354, 1, "98fcc635e8bd7fc79f4eb1e474afe77bbed247e27384bcd9fc199cf4a0a1bf21")
addappid(464355, 1, "4ee5c65c8ddfb054a4be8ed967eccb73c3d62c2c4630d59439882247b07783ee")
addappid(464356, 1, "04fcf217cc4ad9736913d5154beeac9b290eb3d9181027208688b42daf4ff885")
addappid(464357, 1, "296524030a72b5f8ad07025c16ee3fe1c0fe3cac8a4f075a0d6147f8180e75dc")
addappid(464358, 1, "6991e0c1267cf6878a03bfee037ea98b8e38af50b3114c0c08f2759a6d02a833")
addappid(464359, 1, "72757e5408706129722bf15ec1b7c0b03c07ad0dc0e7ee3c3f7151ab082cf0a4")
addappid(491761, 0, "7f42d7a3c5d855bbd538d36af951f8672e9bc4926f47f4080dfbbb6c219c5233")
addappid(491762, 0, "69c685bc8b70a677153546d8fb1aa0a2ef001acd65102b0c6b2442bcb0b4cc2a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(491760)
addappid(883940)
addappid(4507040)
