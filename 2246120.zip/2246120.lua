-- Lua provided by SkyAPI 
-- Game: Coralina
addappid(2246120)
addappid(2246121, 1, "17dfadbbf3354eb6c80742e5992cff42c1c54349e985e3b43daf1d53668fdd26")
