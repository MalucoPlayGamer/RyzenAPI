-- 4804130's Lua and Manifest Created by Hubcap Manifest
-- Artificial Bloodline
-- Created: August 26, 2026 at 12:22:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4804130) -- Artificial Bloodline
-- MAIN APP DEPOTS
addappid(4804131, 1, "bd58712b6822a7102a99e188d5dff73621cc9f48435bf4634cc5c67665147521") -- Depot 4804131
setManifestid(4804131, "4565330669221494981", 13407387192)