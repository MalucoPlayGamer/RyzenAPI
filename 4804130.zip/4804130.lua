-- Lua provided by RyzenAPI
-- Game: Artificial Bloodline

-- MAIN APPLICATION
addappid(4804130) -- Artificial Bloodline

-- MAIN APP DEPOTS / PACKAGES
addappid(4804131, 1, "bd58712b6822a7102a99e188d5dff73621cc9f48435bf4634cc5c67665147521") -- Depot 4804131

