-- Lua provided by RyzenAPI
-- Game: addappid(1788710)

-- MAIN APPLICATION
addappid(1788710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1788711, 1, "4dcf08b1cecf0ef8101ce41ec0a10b56d25e56e1a611f532d53549d7e5165e94")
