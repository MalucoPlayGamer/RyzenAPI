-- Lua provided by RyzenAPI
-- Game: addappid(783210)

-- MAIN APPLICATION
addappid(783210)

-- MAIN APP DEPOTS / PACKAGES
addappid(783211, 1, "aac84f9623f8874e0e4e2e105e4890071aa9f24bb2163036100b6fb6aa512b3d")
