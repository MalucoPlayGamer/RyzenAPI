-- Lua provided by RyzenAPI
-- Game: Aggressors: Ancient Rome

-- MAIN APPLICATION
addappid(783210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(783211, 1, "aac84f9623f8874e0e4e2e105e4890071aa9f24bb2163036100b6fb6aa512b3d")

