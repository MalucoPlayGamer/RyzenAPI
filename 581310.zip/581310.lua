-- Lua provided by RyzenAPI
-- Game: Riskers

-- MAIN APPLICATION
addappid(581310)

-- MAIN APP DEPOTS / PACKAGES
addappid(581311, 1, "24fab96bca6dd63de75dfe69c0ff57be26fa29dd7eea50863e367c465129034c")
addappid(581312, 1, "5c590d63e51bfec59b23d3b6c5ecadbd788a910dea5c31aa763b3a115fb382d1")
addappid(732120, 0, "f724fcb271725d66ff7be621cb1c5921a9f78ed49c6acbd14c3804d3875fc2f2")

