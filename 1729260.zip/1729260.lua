-- Lua provided by RyzenAPI
-- Game: addappid(1729260)

-- MAIN APPLICATION
addappid(1729260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729261, 1, "7d30306ecf56becf5dcd69de277066a242a35bb64f9df32f4f131e9eedbd37d3")
