-- Lua provided by RyzenAPI
-- Game: EOS 27

-- MAIN APPLICATION
addappid(1729260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729261, 1, "7d30306ecf56becf5dcd69de277066a242a35bb64f9df32f4f131e9eedbd37d3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
