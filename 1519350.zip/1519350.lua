-- Lua provided by RyzenAPI
-- Game: Madden NFL 22

-- MAIN APPLICATION
addappid(1519350)
addappid(1606960)
addappid(1607060)
addappid(1607061)
addappid(1607062)
addappid(1607063)
addappid(1607064)
addappid(1634440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1519351, 1, "c12c22ddc527c9f36ca8a82809b85dc5781d294e147e1d296cf677075706e493")
addappid(3340991, 0, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")

