-- Lua provided by RyzenAPI
-- Game: VIVE Console for SteamVR

-- MAIN APPLICATION
addappid(1635730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635731, 1, "317b888a388bc0fb47fd2fa0544587e0e97f24887ea2339ceb90c62dbb0776ce")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
