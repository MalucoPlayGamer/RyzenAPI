-- Lua provided by RyzenAPI
-- Game: 1635730

-- MAIN APPLICATION
addappid(1635730)
-- Game: addappid(1635730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635731, 1, "317b888a388bc0fb47fd2fa0544587e0e97f24887ea2339ceb90c62dbb0776ce")
