-- Lua provided by SkyAPI 
-- Game: AppID 386540
addappid(386540)
addappid(386541, 1, "8194517038cf51039e69168c0b180db14a93dcccbedfa3c27069a122d7ea68cb")
addappid(412900, 0, "25e785644a1223e9c263769f79f0a19aa312fedd9e9a4209a74b8332bc8b5d06")
