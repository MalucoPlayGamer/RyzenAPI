-- Lua provided by RyzenAPI
-- Game: Creeper World IXE Demo

-- MAIN APPLICATION
addappid(2918980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918981, 1, "0242f6aea744940fc77c3b56f3b1975c58370b18b28d4a9a3e4204214a77f195")
