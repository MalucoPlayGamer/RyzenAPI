-- Lua provided by RyzenAPI
-- Game: 陌界·终末序曲

-- MAIN APPLICATION
addappid(2722480)
-- Game: addappid(2722480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2722481, 1, "6e6668459a2278598e1117e99f4b7ec4a5d52f2b10170b1157918fd8335a2556")
