-- Lua provided by RyzenAPI
-- Game: Festival Tycoon 🎪

-- MAIN APPLICATION
addappid(1326270)
addappid(1745460)
addappid(2195860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1326271, 1, "fee82da01d0239caa657d3f45fe542332cc9d7d669128f82070524016e104cfc")

