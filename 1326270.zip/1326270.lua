-- Lua provided by RyzenAPI
-- Game: 1326270

-- MAIN APPLICATION
addappid(1326270)
-- Game: addappid(1326270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1326271, 1, "fee82da01d0239caa657d3f45fe542332cc9d7d669128f82070524016e104cfc")
