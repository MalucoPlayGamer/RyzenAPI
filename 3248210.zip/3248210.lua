-- Lua provided by RyzenAPI
-- Game: 3248210

-- MAIN APPLICATION
addappid(3248210)
-- Game: addappid(3248210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3248211, 1, "b15bec71ba1851badb63dbfb3b30b12d548ed4a0181350cf8d63508f6b77fe9f")
