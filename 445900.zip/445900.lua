-- Lua provided by RyzenAPI
-- Game: 445900

-- MAIN APPLICATION
addappid(445900)
-- Game: addappid(445900)

-- MAIN APP DEPOTS / PACKAGES
addappid(445901, 1, "58bc2615d2a3bd1a9ca01c2d358bffe859a083b502f63fe3628c9758068e22a2")
