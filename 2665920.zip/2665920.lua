-- Lua provided by RyzenAPI
-- Game: Ninja Issen (忍者一閃) Soundtrack

-- MAIN APPLICATION
addappid(2665920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2665921, 1, "8b4fc52f9a1e1ecaa1515c44de5e3075573fd07956ba10808b8bc6fdd190664c")
addappid(2665922, 1, "303398f638cf64a6d1d774a148dc839c75b77987226633d34a681924c4357a74")

