-- Lua provided by RyzenAPI
-- Game: Reflex Unit: Strike Ops Demo

-- MAIN APPLICATION
addappid(3186100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3186101, 1, "3904a5c55213ca36d4ec23d54c9d32815ef7c433dd0ce306aa30c135a2c8341d")
