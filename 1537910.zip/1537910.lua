-- Lua provided by RyzenAPI
-- Game: addappid(1537910)

-- MAIN APPLICATION
addappid(1537910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537911, 1, "4cb47c85eec658c68d3c7a7710d9d8f3976a1e7829c075b62968fbfae7ed48c9")
