-- Lua provided by RyzenAPI 
-- Game: Ultra Foodmess 2
addappid(2392000)
addappid(2392001, 1, "0c22c54398d248cddd7c45c96cc4dd30a6938d859a39dda9fecfa10d9c468d55")
