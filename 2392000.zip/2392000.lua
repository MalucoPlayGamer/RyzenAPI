-- Lua provided by RyzenAPI
-- Game: Game: Ultra Foodmess 2

-- MAIN APPLICATION
addappid(2392000)
-- Game: addappid(2392000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2392001, 1, "0c22c54398d248cddd7c45c96cc4dd30a6938d859a39dda9fecfa10d9c468d55")
