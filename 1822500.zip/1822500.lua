-- Lua provided by RyzenAPI
-- Game: Mixx Island: Remix Vol. 2

-- MAIN APPLICATION
addappid(1822500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1822501, 1, "db85e4069ff72588b40efa086f6dcc27a746b6202248af104b4202851e956074")

