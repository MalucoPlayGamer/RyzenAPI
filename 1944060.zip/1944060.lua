-- Lua provided by RyzenAPI
-- Game: Game: Super Alloy Ranger

-- MAIN APPLICATION
addappid(1944060)
-- Game: addappid(1944060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1944061, 1, "7b5f4d1a67fcec88fe63480415cb36cdfff27a3de4fd537e1544d68b6de22792")
addappid(1944063, 1, "6c568a8e97e278292f9c5bc523438649079507b754081fa10d7d5f7f094435c2")
addappid(2314590, 0, "09646e78cb9dff0dd30c1fd267509b94b10f1d471d598c8433ea19281d7d52a7")
