-- Lua provided by RyzenAPI 
-- Game: Dragon Song Tavern: Cozy & Adventurous
addappid(3148160)
addappid(3148161, 1, "16a24fe795ecb786924c5dec2ece27ee05d370710c0f176727d2c469c08bebcc")
