-- Lua provided by RyzenAPI
-- Game: addappid(3148160)

-- MAIN APPLICATION
addappid(3148160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3148161, 1, "16a24fe795ecb786924c5dec2ece27ee05d370710c0f176727d2c469c08bebcc")
