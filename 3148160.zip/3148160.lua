-- Lua provided by RyzenAPI
-- Game: Dragon Song Tavern: Cozy & Adventurous

-- MAIN APPLICATION
addappid(3148160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3148161, 1, "16a24fe795ecb786924c5dec2ece27ee05d370710c0f176727d2c469c08bebcc")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4010300)
addappid(4010310)
addappid(4010320)
addappid(4010370)
addappid(4010380)
addappid(4010390)
addappid(4010720)
addappid(4010730)
