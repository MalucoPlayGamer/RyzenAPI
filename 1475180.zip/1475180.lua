-- Lua provided by RyzenAPI
-- Game: addappid(1475180)

-- MAIN APPLICATION
addappid(1475180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1475181, 1, "4cdf3c6507b8a5cd139257bbe42000ee9686845c27d31ea6fb9a41324030740e")
