-- Lua provided by RyzenAPI 
-- Game: XPock
addappid(1475180)
addappid(1475181, 1, "4cdf3c6507b8a5cd139257bbe42000ee9686845c27d31ea6fb9a41324030740e")
