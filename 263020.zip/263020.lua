-- Lua provided by RyzenAPI
-- Game: AppID 263020

-- MAIN APPLICATION
addappid(263020)
addappid(356970)

-- MAIN APP DEPOTS / PACKAGES
addappid(263021, 1, "6db0181ebfd85337eb5b4b91f1b4b8ec04dd8dc41695e8c30e2221b4565f8643")
addappid(263022, 1, "fab2e198c798884e1197f7b32957af1fc09e13871744ff6fb003105c62f7e2ab")
addappid(263023, 1, "3869d956e021ab7014cb179d5ef0ee5d33a0205d76c2f3d0a71b105332a48344")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
