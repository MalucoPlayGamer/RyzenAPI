-- Lua provided by RyzenAPI
-- Game: Zombie Zoeds

-- MAIN APPLICATION
addappid(366890)

-- MAIN APP DEPOTS / PACKAGES
addappid(366891, 1, "201ff3e02f89aa5899feb3c77e2b321e66d6fe4ec370ac1ed10686c4e132c48c")
