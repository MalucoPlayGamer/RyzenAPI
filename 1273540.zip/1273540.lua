-- Lua provided by RyzenAPI
-- Game: Mail Mole

-- MAIN APPLICATION
addappid(1273540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273541, 1, "4512476479ff9928f18955fcf32ca1d6e269de5cc6aafcf53882601f0afe4147")
addappid(1273542, 1, "7e7dd5d8d424b3419d4f4b24cd2dbe33e0366306450d53d44d6ae6b8c4c99cec")
addappid(1773880, 0, "d9b3b1ed60d9c111fea84d9c87a19abccff6bfc1ec63bb27829e10b8a9f4696d")
addappid(1823720, 0, "dc723a70d7baca338ba087bfa5b0088ff18958a83707812eb14478c070d7e4d0")
