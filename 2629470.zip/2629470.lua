-- Lua provided by RyzenAPI
-- Game: Clear Plan

-- MAIN APPLICATION
addappid(2629470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2629471, 1, "f7bc6d2a5bfb5c661e58b007358cc4c393d94f83cfb23b7f782a176a6e0cb122")

