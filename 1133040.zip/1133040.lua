-- Lua provided by RyzenAPI
-- Game: addappid(1133040)

-- MAIN APPLICATION
addappid(1133040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133041, 1, "a99bf37aae3cfcba3ec8eb15b940be2c2508fe96f9e5668182137dd1b60e674c")
