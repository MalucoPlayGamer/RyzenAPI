-- Lua provided by RyzenAPI 
-- Game: Bandit Brawler
addappid(1133040)
addappid(1133041, 1, "a99bf37aae3cfcba3ec8eb15b940be2c2508fe96f9e5668182137dd1b60e674c")
