-- Lua provided by RyzenAPI
-- Game: Monkeys & Typewriters!

-- MAIN APPLICATION
addappid(3070260)
-- Game: addappid(3070260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3070261, 1, "8e0e9eb713c1cb5660d25b85d3ae80577a870ad3885a313f4b070f2a3a06588f")
