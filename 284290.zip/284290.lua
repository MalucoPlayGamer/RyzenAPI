-- Lua provided by RyzenAPI
-- Game: Game: AppID 284290

-- MAIN APPLICATION
addappid(284290)
-- Game: addappid(284290)

-- MAIN APP DEPOTS / PACKAGES
addappid(284291, 1, "02d91cb6ea967d217c7d69726c92714b003d2f1b84603b9d167ee2b7c2860fa7")
