-- Lua provided by RyzenAPI
-- Game: Emily Wants To Play

-- MAIN APPLICATION
addappid(416590)

-- MAIN APP DEPOTS / PACKAGES
addappid(416591, 1, "f09af4d91921b55b9d09a8f5229f160bc15a5a8fe5519530bc3a189ebff3f4f6")
addappid(416592, 1, "ff0edb25ef7a3e95ad74617cff7ae05f5075bf31f5aee48a6ce44231df04d52e")
addappid(416593, 1, "f0680f777e95ba8269e291593b01da2e83a1395c42ca6499169b243077506932")
