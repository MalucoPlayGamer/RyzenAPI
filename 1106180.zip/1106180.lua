-- Lua provided by RyzenAPI
-- Game: SpriteStack

-- MAIN APPLICATION
addappid(1106180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106182,0,"7dc2ee766532a0ca773dd68cdf1d16aa6727e53c65a28de8c0cf40f23e962114")

