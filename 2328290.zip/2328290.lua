-- Lua provided by RyzenAPI
-- Game: Game: Hentai Oni

-- MAIN APPLICATION
addappid(2328290)
-- Game: addappid(2328290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328291, 1, "b0312a2b0fdc1df149b7df7000c32bd22bcd67ae70c71c04448277782890a7f9")
