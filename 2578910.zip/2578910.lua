-- Lua provided by RyzenAPI
-- Game: 2578910

-- MAIN APPLICATION
addappid(2578910)
-- Game: addappid(2578910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2578911, 1, "3f3fc39b6b92969461bdf78d9e299e5f2f3ddcdcea5afc41faec651d4bb96689")
