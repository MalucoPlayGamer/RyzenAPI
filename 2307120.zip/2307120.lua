-- Lua provided by RyzenAPI
-- Game: Game: Lovelorn sanatorium Ⅲ

-- MAIN APPLICATION
addappid(2307120)
-- Game: addappid(2307120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307121, 1, "905af712dc71051d3cc5f8f5696df4248e26e00cd6b05113c64799a11d74f374")
addappid(2317410, 0, "b341db8b1afc48b483dd5fdf5e61934f3b2659bfad9da141620bd2d1491db7e8")
