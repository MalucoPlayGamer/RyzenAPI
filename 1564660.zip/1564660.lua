-- Lua provided by RyzenAPI
-- Game: addappid(1564660)

-- MAIN APPLICATION
addappid(1564660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564662,0,"e533317dc25aee932bded932fcdd0f275eaf9e9674f9f54f9654eb061bce98f0")
addappid(1564663,0,"debd82037adc6a6931b8c77da926e92d134af9c4db386d90126904f28a88e606")
