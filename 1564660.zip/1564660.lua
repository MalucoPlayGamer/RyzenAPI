-- Lua provided by RyzenAPI
-- Game: Bongo Arena

-- MAIN APPLICATION
addappid(1564660)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1564662,0,"e533317dc25aee932bded932fcdd0f275eaf9e9674f9f54f9654eb061bce98f0")
addappid(1564663,0,"debd82037adc6a6931b8c77da926e92d134af9c4db386d90126904f28a88e606")

