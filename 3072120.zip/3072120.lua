-- Lua provided by RyzenAPI
-- Game: Backrooms Lost Runners

-- MAIN APPLICATION
addappid(3072120)
-- Game: addappid(3072120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3072121, 1, "3893e74f509714a02402663b2218789ed8bd7f0e3c3575fff0685903934394c8")
