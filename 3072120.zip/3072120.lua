-- Lua provided by RyzenAPI 
-- Game: Backrooms Lost Runners
addappid(3072120)
addappid(3072121, 1, "3893e74f509714a02402663b2218789ed8bd7f0e3c3575fff0685903934394c8")
