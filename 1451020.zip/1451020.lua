-- Lua provided by RyzenAPI
-- Game: 1451020

-- MAIN APPLICATION
addappid(1451020)
-- Game: addappid(1451020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451020,0,"3725256feb9a0eb5cffc03979321e596e1c75ddb945cb9c09a496bc42a06ce37")
