-- Lua provided by RyzenAPI
-- Game: JR EAST Train Simulator: Yamanote Line (Osaki to Osaki) E235-0 series

-- MAIN APPLICATION
addappid(2514660)
-- Game: addappid(2514660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2514661, 1, "8658f4fecfc03ce6d670b2fb8560ae4c745684e5afec9ac223bde1ba3ea863c1")
addappid(2514662, 1, "e342559c56b98c3119c3024417fece384cc8da8275b06bc1d3cfb35f9f55bc78")
