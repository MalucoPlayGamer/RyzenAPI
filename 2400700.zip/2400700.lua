-- Lua provided by RyzenAPI
-- Game: Beginning of the Rain

-- MAIN APPLICATION
addappid(2400700)
-- Game: addappid(2400700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2400702,0,"2ad4d0f380b1ce17fa1e327d68bc26bb7599c9b149e53bf18e4426c46a2955c3")
