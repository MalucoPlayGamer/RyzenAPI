-- Lua provided by RyzenAPI
-- Game: Attack of the Gigant Zombie vs Unity chan

-- MAIN APPLICATION
addappid(807070)

-- MAIN APP DEPOTS / PACKAGES
addappid(807071, 1, "0e9191317901b222c59503272e4b7eef228776c0d20fc9382200d5db63effce9")
addappid(1369680, 0, "30c1b7226b1328f5db627818dd6f4c0d8e4c11302463af714ede0c760ad6650d")
