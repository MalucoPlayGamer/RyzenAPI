-- Lua provided by RyzenAPI
-- Game: addappid(997700)

-- MAIN APPLICATION
addappid(997700)

-- MAIN APP DEPOTS / PACKAGES
addappid(997701, 1, "ae978036d1f294533807c303eff41c7aef3d4ee3ccd122ce04facbd31f7e6244")
