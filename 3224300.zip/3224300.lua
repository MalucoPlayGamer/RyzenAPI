-- Lua provided by RyzenAPI
-- Game: Game: ROGUE FLIGHT DEMO

-- MAIN APPLICATION
addappid(3224300)
-- Game: addappid(3224300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3224301, 1, "5ae8a816eb791b96dfae861b6f5ed866009cc64d2762a1077ed68f764f1ed252")
