-- Lua provided by RyzenAPI
-- Game: Trapers Platformer

-- MAIN APPLICATION
addappid(2257790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257791, 1, "686dc0ae057e963f1fd4992d4270b45db538a7aac6d577c4a27f3a07408bbd7f")

