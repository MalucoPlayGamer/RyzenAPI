-- Lua provided by SkyAPI 
-- Game: Super Minesweeper attACK
addappid(1151940)
addappid(1151941, 1, "1722e74781328c75cb5120c2572e78210db14e62c7412d221e945652fef1d186")
