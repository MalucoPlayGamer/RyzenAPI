-- Lua provided by RyzenAPI
-- Game: Super Minesweeper attACK

-- MAIN APPLICATION
addappid(1151940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151941, 1, "1722e74781328c75cb5120c2572e78210db14e62c7412d221e945652fef1d186")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1165130)
