-- Lua provided by RyzenAPI
-- Game: Typer Hero (打字英雄)

-- MAIN APPLICATION
addappid(1743720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743721, 1, "794481186e30389c1e137f498a2700e61aefc530b87ecfd7cd76fea374855043")

