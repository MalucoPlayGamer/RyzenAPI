-- Lua provided by RyzenAPI
-- Game: Sixth Night

-- MAIN APPLICATION
addappid(944050)
addappid(1246910)
-- Game: addappid(944050)

-- MAIN APP DEPOTS / PACKAGES
addappid(944051, 1, "d7280039bce94af6aa45da836246176a216798a1289a4e7f9453d7742991c447")
