-- Lua provided by RyzenAPI
-- Game: Necronator: Dead Wrong

-- MAIN APPLICATION
addappid(1144970)
addappid(1361250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144971, 1, "748908175a9db296dcf36bf0fa75c6daea5fcdba3172437ac8130ad68b59fa4c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
