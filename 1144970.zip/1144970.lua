-- Lua provided by SkyAPI 
-- Game: Necronator: Dead Wrong
addappid(1144970)
addappid(1144971, 1, "748908175a9db296dcf36bf0fa75c6daea5fcdba3172437ac8130ad68b59fa4c")
addappid(1361250)
