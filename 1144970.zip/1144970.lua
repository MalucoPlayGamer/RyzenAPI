-- Lua provided by RyzenAPI
-- Game: Game: Necronator: Dead Wrong

-- MAIN APPLICATION
addappid(1144970)
addappid(1361250)
-- Game: addappid(1144970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144971, 1, "748908175a9db296dcf36bf0fa75c6daea5fcdba3172437ac8130ad68b59fa4c")
