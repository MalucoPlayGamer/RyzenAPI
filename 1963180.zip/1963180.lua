-- Lua provided by RyzenAPI
-- Game: 1963180

-- MAIN APPLICATION
addappid(1963180)
-- Game: addappid(1963180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1963181, 1, "9c0551639fb816b3be6e7c409cb4c75b0c1ace89acbcf8ab85f3caeaa01250fe")
