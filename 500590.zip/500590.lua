-- Lua provided by RyzenAPI
-- Game: addappid(500590)

-- MAIN APPLICATION
addappid(500590)

-- MAIN APP DEPOTS / PACKAGES
addappid(500591, 1, "4b746a6223bd81885483d062f29e7a4152fa7f1b970b4140318c6a8c7c52d4de")
