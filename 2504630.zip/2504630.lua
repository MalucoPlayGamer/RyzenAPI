-- Lua provided by RyzenAPI
-- Game: Ur

-- MAIN APPLICATION
addappid(2504630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2504631, 1, "e49b4d520abea6ee00628b3b8ee2187be3bdf04a5f2bfee739e49ac3bc74168b")

