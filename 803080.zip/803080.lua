-- Lua provided by RyzenAPI
-- Game: addappid(803080)

-- MAIN APPLICATION
addappid(803080)
addappid(811770)

-- MAIN APP DEPOTS / PACKAGES
addappid(803081, 1, "a91dd0d2ed7c876ef04b832582312effb826bdc1408b2111955b8f7051b74eae")
