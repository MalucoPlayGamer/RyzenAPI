-- Lua provided by RyzenAPI
-- Game: setManifestid(316742,"3941772104670490794")

-- MAIN APPLICATION
addappid(316740)
-- Game: addappid(316740)

-- MAIN APP DEPOTS / PACKAGES
addappid(316742,0,"072267f549ac74b54ebdc434fbbf3c02a50b9d827c7a38ede40d424614b9a0e6")
