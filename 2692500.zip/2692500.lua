-- Lua provided by RyzenAPI
-- Game: Game: Holdfast OST - The Plight of War

-- MAIN APPLICATION
addappid(2692500)
-- Game: addappid(2692500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692501, 1, "266c4af4a58e605061670d982f37fff681df0f6aac97c8ccbbc28b2055c7d42b")
addappid(2692502, 1, "236d055ecc5e70394e2712d12c1ece3e244af6572f28e653c378038bad21b963")
