-- Lua provided by RyzenAPI 
-- Game: Holdfast OST - The Plight of War
addappid(2692500)
addappid(2692501, 1, "266c4af4a58e605061670d982f37fff681df0f6aac97c8ccbbc28b2055c7d42b")
addappid(2692502, 1, "236d055ecc5e70394e2712d12c1ece3e244af6572f28e653c378038bad21b963")
