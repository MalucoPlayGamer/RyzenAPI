-- Lua provided by RyzenAPI
-- Game: Kritter

-- MAIN APPLICATION
addappid(2103950)
addappid(4486830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103951,0,"ab8681abd767a8ffec36489d90174f6ee488ecc8a79fae944fed2f873c3557c4")

