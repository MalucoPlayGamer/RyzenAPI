-- Lua provided by RyzenAPI 
-- Game: Daily life with my succubus boss
addappid(2059310)
addappid(2059311, 1, "ec8c19f17621a44e38fd9d2685d7da2c81a3614f2db4ba2df3bb78d2674da9b4")
addappid(2059312, 1, "742fd94003cf03475836408718ebbc6c7877cf6f0e9b5908daec26eae4416e90")
addappid(2059313, 1, "0a2ce387e17bef69c4424ea5ba357e6432d662c90a555418979179473429ac69")
