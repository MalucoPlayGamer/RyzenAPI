-- Lua provided by RyzenAPI
-- Game: addappid(933470)

-- MAIN APPLICATION
addappid(933470)

-- MAIN APP DEPOTS / PACKAGES
addappid(933470,0,"fad4246ba5ef1b11fbf068d6d9fc2f8b95e98c2daf78979ec841ee1db99f1228")
addtoken(933470,6442844779032101448)
