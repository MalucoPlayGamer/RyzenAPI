-- Lua provided by RyzenAPI
-- Game: Panda Run

-- MAIN APPLICATION
addappid(693250)

-- MAIN APP DEPOTS / PACKAGES
addappid(693251, 1, "82bc7c3db910e5a783f8cc3055496cfe564c68dfd00021b885b5071efaeb11c5")
