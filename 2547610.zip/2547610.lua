-- Lua provided by RyzenAPI 
-- Game: Crea Run!
addappid(2547610)
addappid(2547611, 1, "60290a0ee1dc6bbf8b13b4611fc8e9c5677563b78ed899510026f916dc742e39")
