-- Lua provided by RyzenAPI
-- Game: addappid(2547610)

-- MAIN APPLICATION
addappid(2547610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2547611, 1, "60290a0ee1dc6bbf8b13b4611fc8e9c5677563b78ed899510026f916dc742e39")
