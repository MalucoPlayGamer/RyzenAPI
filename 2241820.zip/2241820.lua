-- Lua provided by RyzenAPI
-- Game: Sokoban

-- MAIN APPLICATION
addappid(2241820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2241821, 1, "664a75cd4d47fdf633c6207f7a89c915eaab7032923a9cf2f75b570fa7914f67")
