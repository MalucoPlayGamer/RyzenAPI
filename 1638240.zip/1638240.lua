-- Lua provided by SkyAPI 
-- Game: Sword and Fairy 5 Prequel: OST
addappid(1638240)
addappid(1638241, 1, "6f82838c328fedee0b88f5b3cb8dbd06284d2a2dfc9ce91a82122c379b46fe8c")
addappid(1638242, 1, "f0d5d6713397cb0c7e9edf444886ea83d59de87e35e3aed83a4b2341f5844ad8")
