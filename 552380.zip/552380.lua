-- Lua provided by RyzenAPI
-- Game: 552380

-- MAIN APPLICATION
addappid(552380)
-- Game: addappid(552380)

-- MAIN APP DEPOTS / PACKAGES
addappid(552381, 1, "6efbe70c191854e296abea338c1b6f4499e8ca674d79991a247791db696c22f7")
