-- Lua provided by RyzenAPI
-- Game: Help Me Remember, Satori-sama!

-- MAIN APPLICATION
addappid(1914970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914971, 1, "04781dd4575c65d9bbb35ad50d606faf06700a9a672a827e1121b12298f31167")
