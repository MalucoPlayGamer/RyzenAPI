-- Lua provided by RyzenAPI
-- Game: Rescue Dash - Management Puzzle

-- MAIN APPLICATION
addappid(2254000)
addappid(2493840)
addappid(2494140)
addappid(2494150)
addappid(2494160)
addappid(2494170)
addappid(2494180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2254001, 1, "11d1c5fd04044704142efe005ba5abcd48e1170fb0219830626855f700a2b5a0")
addappid(2254002, 1, "b03a4583f4f8ed8798f60639fbe7197a42688a885108173bb7681e4a19c55aa5")

