-- Lua provided by RyzenAPI
-- Game: NightZ

-- MAIN APPLICATION
addappid(548480)

-- MAIN APP DEPOTS / PACKAGES
addappid(548481, 1, "2834faf59362882a6d9d4fef0cbe2acae992008f88891ff69bdf0dd6587c375a")

