-- Lua provided by RyzenAPI 
-- Game: Slave Zero X
addappid(1903910)
addappid(1903911, 1, "ad111a4f54cfa8c33ff9ea831baa253660d63745a55987eb65f69b846e73e581")
addappid(2822490)
addappid(2822500)
