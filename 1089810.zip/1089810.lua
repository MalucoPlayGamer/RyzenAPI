-- Lua provided by RyzenAPI
-- Game: setManifestid(1089812,"4249295124752334868")

-- MAIN APPLICATION
addappid(1089810)
-- Game: addappid(1089810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089812,0,"d25bafea34164622b98643729baeff046d4334d9e28c5e4c2ed275f19104c6fa")
