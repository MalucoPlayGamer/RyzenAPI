-- Lua provided by SkyAPI 
-- Game: Reality Break Demo
addappid(2468370)
addappid(2468371, 1, "329d20976c7a66f2b8b683ddb7bb689d48b9ec074cfa0071d7985de2fa7fa00f")
