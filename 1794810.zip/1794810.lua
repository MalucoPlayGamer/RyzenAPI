-- Lua provided by RyzenAPI
-- Game: Game: AppID 1794810

-- MAIN APPLICATION
addappid(1794810)
-- Game: addappid(1794810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794811, 1, "995f1feb66b02ba661048be931face47ce493238e3af232eac70f28bb161c486")
