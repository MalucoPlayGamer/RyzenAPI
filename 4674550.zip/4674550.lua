-- 4674550's Lua and Manifest Created by Hubcap Manifest
-- 矿业帝国
-- Created: June 23, 2026 at 07:07:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4674550) -- 矿业帝国
-- MAIN APP DEPOTS
addappid(4674551, 1, "ffed0b638e599155cc36c5c719f84c4ed386d0f40079e040c49551a1b7d89cb0") -- Depot 4674551
-- setManifestid(4674551, "2522737429839701438", 934428619)