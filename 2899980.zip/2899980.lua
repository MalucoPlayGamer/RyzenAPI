-- Lua provided by RyzenAPI
-- Game: Graces: Posthumous Wish

-- MAIN APPLICATION
addappid(2899980)
addappid(3753200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2899981, 1, "cc43996014187e6ec7a6f50d5744e50b43d9696a756fc0b50268473b4571f0cf")

