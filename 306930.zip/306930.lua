-- Lua provided by RyzenAPI
-- Game: 306930

-- MAIN APPLICATION
addappid(306930)
-- Game: addappid(306930)

-- MAIN APP DEPOTS / PACKAGES
addappid(306931, 1, "a26cb2668d4d1988b43e93c66d88f724e6dd44eddd8248d2cd93d6aeaba1faaf")
