-- Lua provided by RyzenAPI
-- Game: Game: Maid of Sker

-- MAIN APPLICATION
addappid(826940)
-- Game: addappid(826940)

-- MAIN APP DEPOTS / PACKAGES
addappid(826941, 1, "0280be40e2a7cbc80f73135022b85e377a2d815bb947df62c2c9be9c3500c2f9")
addappid(826942, 1, "c526f53ea45c5b9d9cef2743229fa819757c52489050b263903b8dc99420eed2")
