-- Lua provided by RyzenAPI
-- Game: Hentai USSR

-- MAIN APPLICATION
addappid(3159680)
-- Game: addappid(3159680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3159681, 1, "5b31fd1da72f8ff7ee29f9c9f2cb4bd78240b89f38f23d2ea307840c030d92f9")
