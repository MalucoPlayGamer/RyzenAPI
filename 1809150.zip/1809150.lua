-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1809150)
-- Game: addappid(1809150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809150,0,"139c4d457bd0ab240bc24404f0c783fbb8aa125e55f61cee4251967bbad33ad8")
