-- Lua provided by RyzenAPI
-- Game: 2413730

-- MAIN APPLICATION
addappid(2413730)
-- Game: addappid(2413730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413731, 1, "c5670f74edbdb4709a9aeab0d094c7b40ce75a190252b9b3cb0dcaf1053ab3e2")
