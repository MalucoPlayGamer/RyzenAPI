-- Lua provided by RyzenAPI
-- Game: Hole Is Mine

-- MAIN APPLICATION
addappid(4508020) -- Hole Is Mine

-- MAIN APP DEPOTS / PACKAGES
addappid(4508021, 1, "347b5ddbc714660777c6ef9b8a451c1d65ffee61b82a6f3a9395afd0cd351fdd") -- Depot 4508021

