-- 4508020's Lua and Manifest Created by Hubcap Manifest
-- Hole Is Mine
-- Created: August 10, 2026 at 15:54:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4508020) -- Hole Is Mine
-- MAIN APP DEPOTS
addappid(4508021, 1, "347b5ddbc714660777c6ef9b8a451c1d65ffee61b82a6f3a9395afd0cd351fdd") -- Depot 4508021
setManifestid(4508021, "7151218962865121975", 1440468005)