-- Lua provided by RyzenAPI
-- Game: addappid(844920)

-- MAIN APPLICATION
addappid(844920)

-- MAIN APP DEPOTS / PACKAGES
addappid(844921, 1, "1a85dec9cd526828901576b6047f58a2bff8844e3af2ab3934d8055312c7cc17")
