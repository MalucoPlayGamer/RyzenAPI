-- Lua provided by RyzenAPI
-- Game: Game: Singalongsong

-- MAIN APPLICATION
addappid(2949480)
-- Game: addappid(2949480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2949481, 1, "2fd6e7e8edf2dc7cd5e79f08ab0e90fc93d8cc8c21f3fc3bb60fe659416719c1")
