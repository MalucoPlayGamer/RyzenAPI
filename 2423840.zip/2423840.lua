-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2423840)
addappid(2423841)

-- MAIN APP DEPOTS / PACKAGES
addappid(2388461,0,"df5b531131bdde59e44e07763828b889d3808d09fd0e2b0daf678841ccde5f88")
