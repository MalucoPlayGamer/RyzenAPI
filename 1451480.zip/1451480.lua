-- Lua provided by RyzenAPI 
-- Game: The Greatest Penguin Heist of All Time
addappid(1451480)
addappid(1451481, 1, "803908852d4442cab75b83ab01c008d5dcf536aa2a405fb9174793b0bdab56bb")
addappid(1451482, 1, "5bf3185aea27548106ef1ab8ff48b60297ae9613d1ec72a033b25e7b7cd82a6d")
addappid(1451483, 1, "1848ae703facf3f03b1f808b190bc2a87d84a486f9f253322d59fa26c2141df7")
