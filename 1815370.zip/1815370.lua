-- Lua provided by RyzenAPI
-- Game: 1815370

-- MAIN APPLICATION
addappid(1815370)
addappid(1854860)
-- Game: addappid(1815370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815371, 1, "fbed9bf52c2a60ca449339cdd541b6ddde6010e562a02bcbe8e87f68a7d678ba")
