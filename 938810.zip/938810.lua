-- Lua provided by RyzenAPI
-- Game: 938810

-- MAIN APPLICATION
addappid(938810)
-- Game: addappid(938810)

-- MAIN APP DEPOTS / PACKAGES
addappid(938811, 1, "749d9f9961ba05fbad445275584e8bc3771477ba21dc9029d862d6174ec48a66")
