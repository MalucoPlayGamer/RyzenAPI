-- Lua provided by RyzenAPI
-- Game: AppID 731120

-- MAIN APPLICATION
addappid(731120)

-- MAIN APP DEPOTS / PACKAGES
addappid(731121, 1, "4ba950e51b3b9bcefa3aae55dabf307d1e5dd4438822fc1c58390795b59b41e4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
