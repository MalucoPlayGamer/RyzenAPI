-- Lua provided by RyzenAPI 
-- Game: AppID 731120
addappid(731120)
addappid(731121, 1, "4ba950e51b3b9bcefa3aae55dabf307d1e5dd4438822fc1c58390795b59b41e4")
