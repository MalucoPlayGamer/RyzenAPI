-- Lua provided by RyzenAPI
-- Game: 731120

-- MAIN APPLICATION
addappid(731120)
-- Game: addappid(731120)

-- MAIN APP DEPOTS / PACKAGES
addappid(731121, 1, "4ba950e51b3b9bcefa3aae55dabf307d1e5dd4438822fc1c58390795b59b41e4")
