-- Lua provided by RyzenAPI
-- Game: ASURA

-- MAIN APPLICATION
addappid(2293900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293901, 1, "e1de8d00a6aa7b48970435936c6ed032aeadde5eb150e561dfa3c4b4922362de")
