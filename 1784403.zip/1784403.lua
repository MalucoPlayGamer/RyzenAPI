-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - 90s Retro Sounds - Adventure

-- MAIN APPLICATION
addappid(1784403)

-- MAIN APP DEPOTS / PACKAGES
addappid(1784403,0,"c4e0c43f6ff1b5ebe15aa3c9648f720dd19fa080c8d566a35e612ac25922e24f")

