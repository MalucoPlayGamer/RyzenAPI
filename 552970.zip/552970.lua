-- Lua provided by RyzenAPI
-- Game: Sumoman

-- MAIN APPLICATION
addappid(552970)

-- MAIN APP DEPOTS / PACKAGES
addappid(552971, 1, "0d2be83141957c9680d3eb0431d02142856c996032370f3a8e7be26fd744e5fe")
addappid(552972, 1, "e4714383977e2cc2386a1a8c0f12c4395d740f5114f3b965404de8c1e28172db")
addappid(552973, 1, "303e45605d43cc7e0d81899f8623d9094f9d67c92ac6cb517d04f43afd4aa1a4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
