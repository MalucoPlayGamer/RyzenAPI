-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: FACO Simulations - F-15C Eagle

-- MAIN APPLICATION
addappid(2969770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969770,0,"b59508418d27721bfc4e2e2077daffb93e05d1e5c7c2ecd3d195f411a66f2a1f")

