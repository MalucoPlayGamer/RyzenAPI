-- Lua provided by RyzenAPI
-- Game: 589770

-- MAIN APPLICATION
addappid(589770)
-- Game: addappid(589770)

-- MAIN APP DEPOTS / PACKAGES
addappid(589771, 1, "bf38775aa7a49bf56a6d2cf607307aeb890eeb694cd4851099558119ae29ae8a")
