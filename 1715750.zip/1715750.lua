-- Lua provided by RyzenAPI
-- Game: Craterbound

-- MAIN APPLICATION
addappid(1715750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1715751, 1, "aede97f2c6f30499dd1ed5e6b385f86bca47299d7cac1fcc22eccd44860acf76")

