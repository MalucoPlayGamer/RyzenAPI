-- Lua provided by RyzenAPI
-- Game: Craterbound

-- MAIN APPLICATION
addappid(1715750)
-- Game: addappid(1715750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715751, 1, "aede97f2c6f30499dd1ed5e6b385f86bca47299d7cac1fcc22eccd44860acf76")
