-- Lua provided by RyzenAPI
-- Game: Builder Simulator VR

-- MAIN APPLICATION
addappid(2270940)
-- Game: addappid(2270940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2270941, 1, "eea0405fc660f9da32e526ac2c39719a5457cfdb7faa55f18e5347f5280baccf")
