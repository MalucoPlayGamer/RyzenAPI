-- Lua provided by RyzenAPI
-- Game: Game: Fantasy Fishing Town

-- MAIN APPLICATION
addappid(1904040)
-- Game: addappid(1904040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904041, 1, "ebf9a37181784837c9c852c219f45dd89d713d99a0655689c8796309498671c6")
