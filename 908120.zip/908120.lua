-- Lua provided by SkyAPI 
-- Game: W. T. B.
addappid(908120)
addappid(908121, 1, "5f86f5bd63721843aa647ea3de152615ee4fea6f9031aea317af7dcb33f72934")
