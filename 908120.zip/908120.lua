-- Lua provided by RyzenAPI
-- Game: W. T. B.

-- MAIN APPLICATION
addappid(908120)
-- Game: addappid(908120)

-- MAIN APP DEPOTS / PACKAGES
addappid(908121, 1, "5f86f5bd63721843aa647ea3de152615ee4fea6f9031aea317af7dcb33f72934")
