-- Lua provided by RyzenAPI
-- Game: 1441990

-- MAIN APPLICATION
addappid(1441990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441990,0,"d969eaacddfa8facaa6706d04bddfbb53730503a92f7287e1e9c370d932e2c45")

