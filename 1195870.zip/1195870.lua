-- Lua provided by RyzenAPI
-- Game: Game: 零界战线

-- MAIN APPLICATION
addappid(1195870)
addappid(1207250)
addappid(1207890)
addappid(1207900)
addappid(1207910)
addappid(1207920)
addappid(1207930)
addappid(1207940)
addappid(1207950)
addappid(1207960)
addappid(1207970)
addappid(1207980)
addappid(1207990)
-- Game: addappid(1195870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1195871, 1, "4797065300c577ee232f152d56181659cec7acda6d36a616923aa5896831eced")
