-- Lua provided by RyzenAPI
-- Game: Oh...Sir! The Hollywood Roast

-- MAIN APPLICATION
addappid(575330)
-- Game: addappid(575330)

-- MAIN APP DEPOTS / PACKAGES
addappid(575331, 1, "ede43a7cdf729c9e9fece2e034b6ba7fb6f4dd777300e2eaa7d8efc3631a503e")
addappid(575332, 1, "5bc58789c350f8594348248f7cbc2b6476632e03419da9678dc25c24680870f3")
addappid(644700, 0, "4227e3ca1e3ed4742b03a9b53a0548ddc607c806d30466d26b4f74e35fd09cfe")
