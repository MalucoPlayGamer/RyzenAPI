-- Lua provided by RyzenAPI
-- Game: Metro Gravity

-- MAIN APPLICATION
addappid(2986450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2986451, 1, "962eb395eecb9538201954a19f0da9ad1f2de2ffd18479d1b48a59727e7cb266")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
