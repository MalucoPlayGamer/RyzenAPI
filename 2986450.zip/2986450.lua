-- Lua provided by RyzenAPI
-- Game: Metro Gravity

-- MAIN APPLICATION
addappid(2986450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2986451, 1, "962eb395eecb9538201954a19f0da9ad1f2de2ffd18479d1b48a59727e7cb266")
