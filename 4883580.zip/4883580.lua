-- Lua provided by RyzenAPI
-- Game: The One Fish

-- MAIN APPLICATION
addappid(4883580) -- The One Fish

-- MAIN APP DEPOTS / PACKAGES
addappid(4883581, 1, "303c02ea44b6318096971b26aadcebf283651a1a7603639a64b007f633b621ef") -- Depot 4883581

