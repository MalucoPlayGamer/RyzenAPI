-- 4883580's Lua and Manifest Created by Hubcap Manifest
-- The One Fish
-- Created: August 13, 2026 at 07:35:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4883580) -- The One Fish
-- MAIN APP DEPOTS
addappid(4883581, 1, "303c02ea44b6318096971b26aadcebf283651a1a7603639a64b007f633b621ef") -- Depot 4883581
setManifestid(4883581, "3695141503414127371", 3262578866)