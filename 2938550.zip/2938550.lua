-- Lua provided by RyzenAPI
-- Game: 2938550

-- MAIN APPLICATION
addappid(2938550)
-- Game: addappid(2938550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2938551, 1, "54f72dba735487b011ec52ab0d068de2020fec4832b1fe4a52ed6015796b708d")
