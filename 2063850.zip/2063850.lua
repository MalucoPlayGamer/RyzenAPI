-- Lua provided by RyzenAPI
-- Game: Game: AppID 2063850

-- MAIN APPLICATION
addappid(2063850)
-- Game: addappid(2063850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063851, 1, "8888bab00a7c4aa3f6985ac16a243577cc149744548b60fd94ab6869e8e58bc1")
