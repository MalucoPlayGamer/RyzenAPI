-- Lua provided by RyzenAPI
-- Game: Chowdertwo

-- MAIN APPLICATION
addappid(585750)
-- Game: addappid(585750)

-- MAIN APP DEPOTS / PACKAGES
addappid(585751, 1, "e19de4437b00007b22dd7bd8a1ecae53d7f58dbe00c52e7eff6946df61d3aaf4")
