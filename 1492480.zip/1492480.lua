-- Lua provided by RyzenAPI
-- Game: addappid(1492480)

-- MAIN APPLICATION
addappid(1492480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492481, 1, "348b3cf71fde05a005db42398da69a429dbe0ceef4c54513a9a763f605ced00f")
