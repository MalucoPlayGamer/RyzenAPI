-- Lua provided by RyzenAPI 
-- Game: AppID 702000
addappid(702000)
addappid(702001, 1, "8a498746408b4169dcb48c060be31f9017a356d1c3acd34093c2615f13df9399")
