-- Lua provided by RyzenAPI
-- Game: Game: 再见断刀

-- MAIN APPLICATION
addappid(2663950)
-- Game: addappid(2663950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2663951, 1, "004668597f47ae4de102eb65dbd8957898380a9082876d15c45563fbc4a1bfcf")
addappid(3633640, 0, "78dfded45ebabe7659c29ad5b2aa13c26ff937701e6d4b1906e6dd5f0cd8293d")
