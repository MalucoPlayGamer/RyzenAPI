-- Lua provided by RyzenAPI
-- Game: 1583140

-- MAIN APPLICATION
addappid(1583140)
-- Game: addappid(1583140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583141, 1, "e59631f5cde6571ae025c612d95e49d443f7ad17a35dcd15a1a603c8706592e4")
