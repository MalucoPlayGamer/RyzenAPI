-- Lua provided by RyzenAPI
-- Game: Insexsity

-- MAIN APPLICATION
addappid(1283280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283281, 1, "c6d6f25c341951d854f7c0f68377f840872396da13f17f65ff8aa44a96ab8638")

