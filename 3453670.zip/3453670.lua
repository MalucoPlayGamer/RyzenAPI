-- Lua provided by RyzenAPI
-- Game: addappid(3453670)

-- MAIN APPLICATION
addappid(3453670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3453671, 1, "fa48a3e6c93aaa511c126d15ef5bda5d6ddbd1d77d0aacea1b9b691cbcd2587b")
