-- Lua provided by RyzenAPI
-- Game: AppID 206420

-- MAIN APPLICATION
addappid(206420)
addappid(228983)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(206421, 1, "7049777739d9b05d24fcc717a05a9168f140f3eef0b976125d43152e437ae147")
addappid(206422, 1, "9c408c0c3ba27a85a50a589d50c94feb87c03e295da7f42cb38aea5118012bbd")
addappid(206424, 1, "942ad2f2ef4b1a1c983b5527c02b6fe133d7c8c1b72720e6e1f03569620043e0")
addappid(206425, 1, "56df538ab3669dc36d4b1b3024a9f4cbf34ed345c3a76558058168939742ff52")
addappid(206426, 1, "96cb57c08a31d41f3ccc65749a6a05e049cecc6539d9fa2f7c0862bf569e251d")
addappid(206430, 1, "4455b8ff0aba23f57f32b85d0af9f6fc8d1d5dc339a77c9bf8c08fc74cc8ece7")
addappid(206431, 1, "b4f9484ca820c15f25bbc96f10b12a1bc5ad696e92d8e1a742386e9af1d1be5d")
addappid(206432, 1, "52a5845a87c5923164222c42e0421ffdc24e2fb4316f668c08329655a8fb2f57")
addappid(206433, 1, "8b004eb4746433cbb0656390eebb066adba5d62dd41f6597336aad423309a3b4")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(206435)
addappid(238300)
addappid(238301)
addappid(238302)
addappid(238303)
addappid(238304)
addappid(238305)
addappid(247290)
addappid(247291)
addappid(247292)
addappid(247293)
addappid(247294)
addappid(247295)
addappid(247296)
addappid(247297)
addappid(247298)
addappid(247299)
addappid(247300)
addappid(247301)
addappid(247302)
addappid(247303)
addappid(247304)
addappid(247305)
addappid(247306)
addappid(247307)
addappid(247308)
addappid(247309)
addappid(255050)
addappid(266730)
addappid(267230)
addappid(314580)
