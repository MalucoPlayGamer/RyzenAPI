-- Lua provided by RyzenAPI
-- Game: Nurse Love Addiction - Original Soundtrack

-- MAIN APPLICATION
addappid(543210)

-- MAIN APP DEPOTS / PACKAGES
addappid(543211, 1, "9129255cfd146939d3fa9a238be9d2aee19beee8fb0dd1abda625c5132bbe87d")
