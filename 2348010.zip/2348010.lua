-- Lua provided by RyzenAPI
-- Game: Capes - Supporter Pack

-- MAIN APPLICATION
addappid(2348010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2348010,0,"75a19538fefd4850a0f6cb70bd85b2f0bf80a0df78ef4e8be7ea1d458e04648f")

