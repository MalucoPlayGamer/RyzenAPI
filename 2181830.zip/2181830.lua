-- Lua provided by RyzenAPI
-- Game: Follow The Crown

-- MAIN APPLICATION
addappid(2181830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2181831, 1, "345a0e1a1268028bdf8fdf462155ae54d08d19133e48a431c325e123f8544730")

