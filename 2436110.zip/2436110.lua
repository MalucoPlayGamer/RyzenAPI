-- Lua provided by RyzenAPI
-- Game: KARNAL

-- MAIN APPLICATION
addappid(2436110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2436111, 1, "005d2b90e672dbf8a0f1b9a1e9b0e6c39d195d3fa304d45a3cac8e3c2b566d5f")

