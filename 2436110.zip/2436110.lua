-- Lua provided by RyzenAPI
-- Game: Game: KARNAL

-- MAIN APPLICATION
addappid(2436110)
-- Game: addappid(2436110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436111, 1, "005d2b90e672dbf8a0f1b9a1e9b0e6c39d195d3fa304d45a3cac8e3c2b566d5f")
