-- Lua provided by RyzenAPI
-- Game: The Pale Demo

-- MAIN APPLICATION
addappid(2084290)
-- Game: addappid(2084290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2084291, 1, "43645f83c23feed26d5db623c95ed47b9645404a92a3ef3e23d883bbb261212c")
