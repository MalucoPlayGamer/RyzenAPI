-- Lua provided by SkyAPI 
-- Game: The Pale Demo
addappid(2084290)
addappid(2084291, 1, "43645f83c23feed26d5db623c95ed47b9645404a92a3ef3e23d883bbb261212c")
