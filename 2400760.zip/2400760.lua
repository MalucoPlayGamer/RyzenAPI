-- Lua provided by SkyAPI 
-- Game: Bike Offroad Simulator
addappid(2400760)
addappid(2400761, 1, "c2da7e174331e97ecc84f763802f63549cdf83029162b18f3f33615efbbfa7ab")
