-- Lua provided by RyzenAPI
-- Game: 1700250

-- MAIN APPLICATION
addappid(1700250)
-- Game: addappid(1700250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700251, 1, "b223abfca270e05a33413b52e23b1b0a9a3badfe588e242857d720941f7d61fa")
