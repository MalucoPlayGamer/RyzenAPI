-- Lua provided by RyzenAPI 
-- Game: HEXOPODS
addappid(729990)
addappid(729991, 1, "302e84a699010278cb779262c077f8e45a2ac83379de6265f881ed77023cff70")
