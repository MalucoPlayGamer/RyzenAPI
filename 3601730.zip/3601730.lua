-- Lua provided by RyzenAPI
-- Game: Camp Buddy: Scoutmaster Season - Side Stories

-- MAIN APPLICATION
addappid(3601730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3601731, 1, "57249e8795834ad7b5590a2db71c85ac5d20784f025af43ec287b99cc53b6454")
