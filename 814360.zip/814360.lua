-- Lua provided by RyzenAPI
-- Game: Game: AppID 814360

-- MAIN APPLICATION
addappid(814360)
-- Game: addappid(814360)

-- MAIN APP DEPOTS / PACKAGES
addappid(814361, 1, "4cca9fd7ac126008791104a166b6698ee86d7c765671534902a96c0d5018186d")
