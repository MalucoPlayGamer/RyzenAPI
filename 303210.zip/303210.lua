-- Lua provided by RyzenAPI
-- Game: The Beginner's Guide

-- MAIN APPLICATION
addappid(303210)
-- Game: addappid(303210)

-- MAIN APP DEPOTS / PACKAGES
addappid(303211, 1, "60a04d46a56182551146b5da68422591375fa4a7e6873d6c7dcb3180ae71c6b5")
addappid(303212, 1, "84c93d1124a823f9264b1b93bce67a85f67c5b5ca558c4a360df0a91b3232068")
addappid(303213, 1, "8ee0a1341ca4daf8c7ed32b56e4a8c515fdfc6ae39641957e506fd30580ed0ee")
addappid(406461, 0, "d50673cd1356f45330ee57d1e79ff1c035b72479c166d2a08945fc86fabd06de")
