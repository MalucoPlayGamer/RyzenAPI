-- Lua provided by RyzenAPI
-- Game: Bulkhead

-- MAIN APPLICATION
addappid(1467670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467671, 1, "20832b6dd556d881bcdbb69b1cbdf73f176b6323a26d6edfe471afc2f79e2227")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
