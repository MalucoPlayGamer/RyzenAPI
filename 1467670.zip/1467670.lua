-- Lua provided by RyzenAPI
-- Game: Game: Bulkhead

-- MAIN APPLICATION
addappid(1467670)
-- Game: addappid(1467670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467671, 1, "20832b6dd556d881bcdbb69b1cbdf73f176b6323a26d6edfe471afc2f79e2227")
