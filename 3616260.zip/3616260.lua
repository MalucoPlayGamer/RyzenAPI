-- Lua provided by RyzenAPI
-- Game: MAZEBOUND: Hunt, Gather, Run!

-- MAIN APPLICATION
addappid(3616260)
-- Game: addappid(3616260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3616261, 1, "a0b5579e2cd2fca5a1dd0472f28a4b94758155d04c7448d6f2c8362605db7e01")
