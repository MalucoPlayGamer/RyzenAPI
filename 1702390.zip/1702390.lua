-- Lua provided by RyzenAPI
-- Game: Game: Voor De Kroon

-- MAIN APPLICATION
addappid(1702390)
-- Game: addappid(1702390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702391, 1, "681e40088f726437f9224623495d73305f41d9023d688b6956c352b2d5a9b759")
