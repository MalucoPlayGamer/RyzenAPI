-- Lua provided by RyzenAPI
-- Game: Control Over

-- MAIN APPLICATION
addappid(1410560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1410561, 1, "e446122e6a761c5045a90ddbd9aaede52b0904e8bc00974d1c2214fb55629fa3")
