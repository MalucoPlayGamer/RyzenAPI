-- Lua provided by RyzenAPI
-- Game: Kingdom Come: Deliverance – OST Atmospheres & Additionals

-- MAIN APPLICATION
addappid(1052530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1052530,0,"74ae39f6b741fc66e33370eef78691a0c125e76f50b6798680f8e4c81e4825b1")

