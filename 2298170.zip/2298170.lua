-- Lua provided by RyzenAPI 
-- Game: AppID 2298170
addappid(2298170)
addappid(2298171, 1, "1c062e4700d19cf2c8c639b68f8a537eab94125d858ea7fd12152204330eea09")
