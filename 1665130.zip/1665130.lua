-- Lua provided by RyzenAPI
-- Game: PAC-MAN MUSEUM+

-- MAIN APPLICATION
addappid(1665130)
addappid(1763630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1665131, 1, "fe1b574cd3fd2a82bd0a0d56a7dbd0abfcad414b522a1f437ea24b69c1a2a21b")

