-- Lua provided by RyzenAPI
-- Game: PAC-MAN MUSEUM+

-- MAIN APPLICATION
addappid(1665130)
addappid(1763630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1665131, 1, "fe1b574cd3fd2a82bd0a0d56a7dbd0abfcad414b522a1f437ea24b69c1a2a21b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
