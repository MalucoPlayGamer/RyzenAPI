-- Lua provided by RyzenAPI
-- Game: Drone Swarm

-- MAIN APPLICATION
addappid(401760)
addappid(1390620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(401761, 1, "35a57a69bfb43071e7afc83e854ccd767cc64cdd4d0e024c0aff9d1ec1165bdc")

