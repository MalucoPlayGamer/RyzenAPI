-- Lua provided by RyzenAPI
-- Game: addappid(401760)

-- MAIN APPLICATION
addappid(401760)

-- MAIN APP DEPOTS / PACKAGES
addappid(401761, 1, "35a57a69bfb43071e7afc83e854ccd767cc64cdd4d0e024c0aff9d1ec1165bdc")
