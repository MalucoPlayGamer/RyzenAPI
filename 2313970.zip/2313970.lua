-- Lua provided by RyzenAPI
-- Game: Turbo Racing

-- MAIN APPLICATION
addappid(2313970)
addappid(2346170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313971, 1, "1f51b57b0347511e8df252e1861ec01134186b7fb74f1d2afac275dfb8ecab76")
