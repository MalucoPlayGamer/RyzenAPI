-- Lua provided by RyzenAPI
-- Game: addappid(2743220)

-- MAIN APPLICATION
addappid(2743220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743221, 1, "bb390be839f8e6ed8d89d552bded82b1afb30ad1628ae5948d8e2e138d098b5c")
