-- Lua provided by RyzenAPI
-- Game: Game: AppID 658750

-- MAIN APPLICATION
addappid(658750)
-- Game: addappid(658750)

-- MAIN APP DEPOTS / PACKAGES
addappid(658751, 1, "5aa855c6ec5a641020de622b781f525ab511e537ae8b333bd6dce7c62689e91c")
