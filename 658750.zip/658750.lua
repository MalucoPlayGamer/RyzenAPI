-- Lua provided by RyzenAPI 
-- Game: AppID 658750
addappid(658750)
addappid(658751, 1, "5aa855c6ec5a641020de622b781f525ab511e537ae8b333bd6dce7c62689e91c")
