-- Lua provided by RyzenAPI
-- Game: 1792940

-- MAIN APPLICATION
addappid(1792940)
-- Game: addappid(1792940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1792941, 1, "fcc70d08b5d7f217d5654394c659258266e3bd73027a189fdf2c0bcff5489ef9")
