-- Lua provided by RyzenAPI
-- Game: Legends of Ellaria

-- MAIN APPLICATION
addappid(621070)

-- MAIN APP DEPOTS / PACKAGES
addappid(621071,0,"0d5f79878cbc34c9e66354503630a07a37e42f4a56effaa285520987662d4d79")

