-- Lua provided by RyzenAPI
-- Game: Fate of the Pharaoh

-- MAIN APPLICATION
addappid(1754790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754791, 1, "d2f42b7420458d79b0ada1dfc26b315537bcef7be48698ec6c2c9d823af2c695")
addappid(1754792, 1, "858628d03b76d001f3322745bf7082216533823dda45ce3d8371fd45faf16929")
addappid(1754793, 1, "e32f95e9675bff98f7688e9ab91839214d93f5a858a958767d58b13151715ac9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
