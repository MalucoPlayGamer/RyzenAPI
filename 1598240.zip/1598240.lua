-- Lua provided by RyzenAPI
-- Game: 1598240

-- MAIN APPLICATION
addappid(1598240)
-- Game: addappid(1598240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598240,0,"913a7c653efce5d8794076fcded57de52f6351079b5d03be7bd1eb1559ae94b9")
