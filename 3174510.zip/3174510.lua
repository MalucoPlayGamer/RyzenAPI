-- Lua provided by RyzenAPI
-- Game: Game: Who Killed

-- MAIN APPLICATION
addappid(3174510)
-- Game: addappid(3174510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3174511, 1, "03a5f96cce3ed453e7950236f19f264566b1182b9954c6039ff391a5e6ccbdb4")
