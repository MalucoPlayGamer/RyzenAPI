-- Lua provided by RyzenAPI
-- Game: Game: Just a Cleric

-- MAIN APPLICATION
addappid(467330)
addappid(479270)
-- Game: addappid(467330)

-- MAIN APP DEPOTS / PACKAGES
addappid(467331, 1, "f906f437a313a5be8bcf0fde5abb4ae770991e2702fb941f0ee47ec697e0f1f3")
