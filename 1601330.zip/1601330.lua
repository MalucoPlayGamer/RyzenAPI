-- 1601330's Lua and Manifest Created by Hubcap Manifest
-- Survival Machine
-- Created: June 12, 2026 at 06:05:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1601330) -- Survival Machine
-- MAIN APP DEPOTS
addappid(1601331, 1, "7d1f8b5cacac398272f55abde0b6e0961b853cc9c3678583f07d67742ad1b391") -- Depot 1601331
setManifestid(1601331, "8684121680153707589", 8737423424)
-- DLCS WITH DEDICATED DEPOTS
-- Survival Machine - Supporter Pack (AppID: 4207180)
addappid(4207180)
addappid(4207180, 1, "bb9fa452eca772d0a02217983e940b95daa412b8caa41dc76071d63b89deb2bf") -- Survival Machine - Supporter Pack - Depot 4207180
setManifestid(4207180, "4550657330533468800", 1399615755)