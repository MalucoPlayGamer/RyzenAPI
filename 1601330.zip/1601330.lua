-- Lua provided by RyzenAPI
-- Game: Game: Survival Machine

-- MAIN APPLICATION
addappid(1601330)
addappid(4207180)
-- Game: addappid(1601330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601331, 1, "7d1f8b5cacac398272f55abde0b6e0961b853cc9c3678583f07d67742ad1b391")
