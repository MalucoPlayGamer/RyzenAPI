-- Lua provided by RyzenAPI 
-- Game: Survival Machine
addappid(1601330)
addappid(1601331, 1, "7d1f8b5cacac398272f55abde0b6e0961b853cc9c3678583f07d67742ad1b391")
addappid(4207180)
