-- Lua provided by RyzenAPI
-- Game: Space Pilgrim Episode III: Delta Pavonis

-- MAIN APPLICATION
addappid(439250)

-- MAIN APP DEPOTS / PACKAGES
addappid(439251, 1, "faae83019e1892f4c720c3586ce3c8cb5ef4ae1ee1e0478544a1059b389a0313")
