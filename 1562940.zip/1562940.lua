-- Lua provided by RyzenAPI
-- Game: Game: AppID 1562940

-- MAIN APPLICATION
addappid(1562940)
-- Game: addappid(1562940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562941, 1, "09999efc7850199164d13bcc263c37847c3476fd2dba729c3cf1a51db410d77e")
