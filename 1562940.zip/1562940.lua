-- Generated with Luie @ https://lua.tools/
-- 1562940 - 英雄伝説 創の軌跡
-- Generated 2026-08-15 11:30:38 UTC
-- # Depots (Total/DLC/Shared): 3/0/2

-- Main AppID
addappid(1562940)

-- Main Depots
addappid(1562941, 1, "09999efc7850199164d13bcc263c37847c3476fd2dba729c3cf1a51db410d77e") -- (windows, 64-bit)
setManifestid(1562941, "7224740724412495727", 43847395443)

-- DLC's (no depot keys required)
addappid(1660380) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Elie's Special Costume "Crossbell Queen"
addappid(1660381) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Rixia's Special Costume "Moonlight Wedding"
addappid(1660390) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Nadia's Special Costume "Sweet Devil Summer"
addappid(1660400) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Lapis's Special Costume "The Magic Girl Magical Lapis"
addappid(1660410) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Tio's Special Costume "Tio's original suit"
addappid(1681820) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - C's Special Costume "White Knight"
addappid(1774260) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Free Sample Set Vol.1
addappid(1774261) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Free Sample Set Vol.2
addappid(1774262) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Free Sample Set Vol.3
addappid(1774270) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Black Zemurian Ore Set 3
addappid(1774271) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Black Zemurian Ore Set 2
addappid(1774272) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Black Zemurian Ore Set 1
addappid(1774273) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Azure Divine Water Set 3
addappid(1774274) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Azure Divine Water Set 2
addappid(1774275) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Azure Divine Water Set 1
addappid(1774276) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Azure Drop Set 3
addappid(1774277) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Azure Drop Set 2
addappid(1774278) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Azure Drop Set 1
addappid(1774280) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Value Set 9
addappid(1774281) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Value Set 8
addappid(1774282) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Value Set 7
addappid(1774283) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Value Set 6
addappid(1774284) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Value Set 5
addappid(1774285) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Value Set 4
addappid(1774286) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Value Set 3
addappid(1774287) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Value Set 2
addappid(1774288) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Value Set 1
addappid(1774290) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Set 9
addappid(1774291) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Set 8
addappid(1774292) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Set 7
addappid(1774293) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Set 6
addappid(1774294) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Set 5
addappid(1774295) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Set 4
addappid(1774296) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Set 3
addappid(1774297) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Set 2
addappid(1774298) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Shining Pom Incense Set 1
addappid(1774300) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Divine Water Set 3
addappid(1774301) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Divine Water Set 2
addappid(1774302) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Divine Water Set 1
addappid(1774303) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Droplet Set 3
addappid(1774304) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Droplet Set 2
addappid(1774305) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Droplet Set 1
addappid(1774310) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - U-Material Set 9
addappid(1774311) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - U-Material Set 8
addappid(1774312) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - U-Material Set 7
addappid(1774313) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - U-Material Set 6
addappid(1774314) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - U-Material Set 5
addappid(1774315) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - U-Material Set 4
addappid(1774316) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - U-Material Set 3
addappid(1774317) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - U-Material Set 2
addappid(1774318) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - U-Material Set 1
addappid(1774320) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Zeram Capsule Set 3
addappid(1774321) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Zeram Capsule Set 2
addappid(1774322) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Zeram Capsule Set 1
addappid(1774323) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Zeram Powder Set 3
addappid(1774324) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Zeram Powder Set 2
addappid(1774325) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Zeram Powder Set 1
addappid(1774326) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Dragon Incense Set 3
addappid(1774327) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Dragon Incense Set 2
addappid(1774328) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Dragon Incense Set 1
addappid(1774330) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Spirit Incense Set 3
addappid(1774331) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Spirit Incense Set 2
addappid(1774332) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Spirit Incense Set 1
addappid(1774333) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Advanced Medicine Set 3
addappid(1774334) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Advanced Medicine Set 2
addappid(1774335) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Advanced Medicine Set 1
addappid(1774336) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Monster Ingredients Set 3
addappid(1774337) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Monster Ingredients Set 2
addappid(1774338) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Monster Ingredients Set 1
addappid(1774340) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Useful Accessories Set Vol.3
addappid(1774341) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Useful Accessories Set Vol.2
addappid(1774342) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Useful Accessories Set Vol.1
addappid(1774343) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Sepith Set 6
addappid(1774344) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Sepith Set 5
addappid(1774345) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Sepith Set 4
addappid(1774346) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Sepith Set 3
addappid(1774347) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Sepith Set 2
addappid(1774348) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Sepith Set 1
addappid(1774349) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Dream Fragment Starter Set
addappid(3464410) -- THE LEGEND OF HEROES: HAJIMARI NO KISEKI - Costume Pack

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
