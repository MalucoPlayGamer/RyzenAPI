-- Lua provided by SkyAPI 
-- Game: AppID 1562940
addappid(1562940)
addappid(1562941, 1, "09999efc7850199164d13bcc263c37847c3476fd2dba729c3cf1a51db410d77e")
