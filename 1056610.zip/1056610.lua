-- Lua provided by RyzenAPI 
-- Game: Heal
addappid(1056610)
addappid(1056611, 1, "8f3bd1bec42af66b0cf5a417c7bcb3c7278cacb3d6222536b0fa4af5725e08c7")
