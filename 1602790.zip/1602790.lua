-- Lua provided by RyzenAPI
-- Game: AppID 1602790

-- MAIN APPLICATION
addappid(1602790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602791, 1, "e6ace549b7d6087a51bdb36f0765f0fada207b7ea1b9898efbac2db9cb186724")

