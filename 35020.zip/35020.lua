-- Lua provided by RyzenAPI
-- Game: addappid(35020)

-- MAIN APPLICATION
addappid(35020)

-- MAIN APP DEPOTS / PACKAGES
addappid(35021, 1, "268b23e3a3d533ccf8b1c2f437d413c3f303858d30e8b308b171574c9de838f2")
