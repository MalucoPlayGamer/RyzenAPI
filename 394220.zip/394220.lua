-- Lua provided by RyzenAPI
-- Game: Game: Last Horizon

-- MAIN APPLICATION
addappid(394220)
-- Game: addappid(394220)

-- MAIN APP DEPOTS / PACKAGES
addappid(394221, 1, "9224d91c4b3ae434b316d8388d4278fe8ddd8338ccf5991f23bf5cc28388c537")
addappid(394222, 1, "3a147309894075a44eff1a44664280199d576ae363654b74fbdc06a820e33019")
