-- Lua provided by RyzenAPI 
-- Game: Lodestar
addappid(1460650)
addappid(1460651, 1, "02a7fd0c19de605923b692c1ef53fcc9da95abad2450851cb52dd6436a15d47c")
