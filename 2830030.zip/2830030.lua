-- Lua provided by RyzenAPI
-- Game: MOTORSLICE

-- MAIN APPLICATION
addappid(2830030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2830031, 1, "79dd0da4c8e6d06442724528b5a706b68dfc6beaf2aaec6678caab6b7b268700")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
