-- Lua provided by RyzenAPI
-- Game: MOTORSLICE

-- MAIN APPLICATION
addappid(2830030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2830031, 1, "79dd0da4c8e6d06442724528b5a706b68dfc6beaf2aaec6678caab6b7b268700")

