-- Lua provided by RyzenAPI
-- Game: 2642170

-- MAIN APPLICATION
addappid(2642170)
-- Game: addappid(2642170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2642171, 1, "5ed02ce67cb25cf7f3341c466fe85470b8110023987b78771bda9ba2e78aa110")
