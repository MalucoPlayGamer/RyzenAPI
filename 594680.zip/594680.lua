-- Lua provided by RyzenAPI
-- Game: Game: Shuyan Saga™

-- MAIN APPLICATION
addappid(594680)
-- Game: addappid(594680)

-- MAIN APP DEPOTS / PACKAGES
addappid(594681, 1, "8a60d642150870462b5cdeadce51541531564fbab1eb85756b160e2870483cee")
addappid(594682, 1, "24788d851d88dc96da226e7bddf5d700d250ba717c7087e6438aec7a64b5954c")
addappid(678080, 0, "6ab2a321fac1163c953507be28c16138cc47db751def41d7475174375255da3a")
