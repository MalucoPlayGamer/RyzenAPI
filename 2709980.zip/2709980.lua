-- Lua provided by RyzenAPI
-- Game: addappid(2709980)

-- MAIN APPLICATION
addappid(2709980)
addappid(2801740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2709981, 1, "231b4ee2665444e9a40bb6e93e5ffb2dbf03f366a0fc10ef1373a25a152498e6")
