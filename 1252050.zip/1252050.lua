-- Lua provided by RyzenAPI 
-- Game: AppID 1252050
addappid(1252050)
addappid(1252051, 1, "619fff4a7195f57b7c729129b82ec23cf68c2ca1ccdaac7c3ce9964fa2ace170")
