-- Lua provided by RyzenAPI
-- Game: addappid(1252050)

-- MAIN APPLICATION
addappid(1252050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252051, 1, "619fff4a7195f57b7c729129b82ec23cf68c2ca1ccdaac7c3ce9964fa2ace170")
