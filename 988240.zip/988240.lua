-- Lua provided by RyzenAPI
-- Game: Urban Trial Playground

-- MAIN APPLICATION
addappid(988240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(988241, 1, "7967b4167b90376ca7c29c46f6553c022b9722e114401da5aed6e675fc68f474")

