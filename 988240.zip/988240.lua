-- Lua provided by RyzenAPI
-- Game: Urban Trial Playground

-- MAIN APPLICATION
addappid(988240)
-- Game: addappid(988240)

-- MAIN APP DEPOTS / PACKAGES
addappid(988241, 1, "7967b4167b90376ca7c29c46f6553c022b9722e114401da5aed6e675fc68f474")
