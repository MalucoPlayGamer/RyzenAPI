-- Lua provided by RyzenAPI
-- Game: 2541160

-- MAIN APPLICATION
addappid(2541160)
-- Game: addappid(2541160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2541161, 1, "1d05c3cddfa46313a713a23206995c1201f662766946a2c1e46f7fe09fe97ea2")
