-- Lua provided by RyzenAPI
-- Game: PictoQuest

-- MAIN APPLICATION
addappid(1014040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014041, 1, "d9c4bb4b28345a8b44d20465f05e1d646bb024e34dbc08189bd04f018176d3c1")
