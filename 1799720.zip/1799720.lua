-- Lua provided by RyzenAPI
-- Game: Tale of six

-- MAIN APPLICATION
addappid(1799720)
-- Game: addappid(1799720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1799721, 1, "54849d56a7e5b3055763b2e1cd8bd8d2cb1d5d4e91603fcf1fe5685bb5f4eb63")
