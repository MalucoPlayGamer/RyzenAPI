-- Lua provided by RyzenAPI
-- Game: Garbage Growth

-- MAIN APPLICATION
addappid(4680930) -- Garbage Growth

-- MAIN APP DEPOTS / PACKAGES
addappid(4680931, 1, "7669341c3a27613028361d9d1e8a756b40ab27ddad0f2e92ac6a48e11ef8a115") -- Depot 4680931

