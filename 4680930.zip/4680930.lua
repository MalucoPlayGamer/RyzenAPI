-- 4680930's Lua and Manifest Created by Hubcap Manifest
-- Garbage Growth
-- Created: June 24, 2026 at 05:57:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4680930) -- Garbage Growth
-- MAIN APP DEPOTS
addappid(4680931, 1, "7669341c3a27613028361d9d1e8a756b40ab27ddad0f2e92ac6a48e11ef8a115") -- Depot 4680931
-- setManifestid(4680931, "1096288440382336695", 178090881)