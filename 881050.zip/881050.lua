-- Lua provided by RyzenAPI
-- Game: AppID 881050

-- MAIN APPLICATION
addappid(881050)

-- MAIN APP DEPOTS / PACKAGES
addappid(881051, 1, "966b69cc3ed9f6852c6cbfefcf09cf020b4f41253c7ea35353355d3a8e8880fd")

