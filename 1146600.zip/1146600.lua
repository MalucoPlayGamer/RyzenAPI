-- Lua provided by RyzenAPI
-- Game: addappid(1146600)

-- MAIN APPLICATION
addappid(1146600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1146604,0,"89b4b2ec2c0fb78ffb81f5b34fc6dc1d7f65558e5828141c5ccff77654d13b02")
addappid(1146605,0,"372a7bbf9a90159c07d0ce227337cef95b00974b49d71b94fe54eddf3a6d97ba")
addappid(1146606,0,"bcd35c055cffe5e0c671df6920dafee7b35edf9b3f50ab6139bc50ff0a6c289e")
