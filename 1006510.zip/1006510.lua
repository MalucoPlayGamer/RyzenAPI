-- Lua provided by RyzenAPI
-- Game: AppID 1006510

-- MAIN APPLICATION
addappid(1006510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1006511, 1, "b0515ee5a374e6f06d1e93799d0bbec8efef4f9a2d74b40ffe98a8a07d710489")

