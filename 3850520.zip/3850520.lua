-- Lua provided by RyzenAPI
-- Game: Master of 4 Swords

-- MAIN APPLICATION
addappid(3850520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3850521, 1, "3a5f9d480938472e9509d6d778748dca18f45cdff14e62c7b535d44150297b42")
