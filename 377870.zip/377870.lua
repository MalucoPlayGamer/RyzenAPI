-- Lua provided by RyzenAPI
-- Game: Game: DARIUSBURST Chronicle Saviours

-- MAIN APPLICATION
addappid(377870)
addappid(428600)
addappid(428601)
addappid(428602)
addappid(428603)
addappid(428604)
addappid(428605)
addappid(496970)
addappid(496971)
addappid(496972)
addappid(540680)
addappid(540681)
addappid(540682)
addappid(572380)
addappid(572381)
addappid(572382)
-- Game: addappid(377870)

-- MAIN APP DEPOTS / PACKAGES
addappid(377871, 1, "41495929730eabf20686cbdc4a6d3acc3bf92013393eafc2ec2ba98803be6a41")
addappid(431350, 0, "8b0f429aaa78f5c646d681eb0b5ce3ee4fe44f423a1336ce94f03c66f7400833")
