-- Lua provided by RyzenAPI
-- Game: DARIUSBURST Chronicle Saviours

-- MAIN APPLICATION
addappid(377870)
addappid(428600)
addappid(428601)
addappid(428602)
addappid(428603)
addappid(428604)
addappid(428605)
addappid(496970)
addappid(496971)
addappid(496972)
addappid(540680)
addappid(540681)
addappid(540682)
addappid(572380)
addappid(572381)
addappid(572382)

-- MAIN APP DEPOTS / PACKAGES
addappid(377871, 1, "41495929730eabf20686cbdc4a6d3acc3bf92013393eafc2ec2ba98803be6a41")
addappid(431350, 0, "8b0f429aaa78f5c646d681eb0b5ce3ee4fe44f423a1336ce94f03c66f7400833")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
