-- Lua provided by RyzenAPI
-- Game: Dino Eggs: Rebirth

-- MAIN APPLICATION
addappid(449320)

-- MAIN APP DEPOTS / PACKAGES
addappid(449321, 1, "e28ccbec630d248875151b56964710e2b91197584d87ea270cdb0f019f29b392")
addappid(449322, 1, "afa81ad072f02e4eb46c79e3f7a438168fd8248230a253913a098db61e2783b0")
addappid(449323, 1, "bbdd23041bf3bb9ed7f50b03f8a093d204e427008f4730f7067d06cdd367d50c")
addappid(449324, 1, "f8d14aacc3aef5dd45cbe9ec60a133be0c95f4d23ec1c2ac77fe5b4d61fcc74b")

