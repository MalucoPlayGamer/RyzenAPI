-- Lua provided by RyzenAPI
-- Game: Dino Eggs: Rebirth

-- MAIN APPLICATION
addappid(449320)

-- MAIN APP DEPOTS / PACKAGES
addappid(449321, 1, "e28ccbec630d248875151b56964710e2b91197584d87ea270cdb0f019f29b392")
addappid(449322, 1, "afa81ad072f02e4eb46c79e3f7a438168fd8248230a253913a098db61e2783b0")
addappid(449323, 1, "bbdd23041bf3bb9ed7f50b03f8a093d204e427008f4730f7067d06cdd367d50c")
addappid(449324, 1, "f8d14aacc3aef5dd45cbe9ec60a133be0c95f4d23ec1c2ac77fe5b4d61fcc74b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
