-- Lua provided by RyzenAPI
-- Game: Shiny

-- MAIN APPLICATION
addappid(496390)
addappid(523821)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(496391, 1, "37186bd98acf81e9e9d41510beb3a53cd37a47e74932b9acb46e6cdc9d770efc")
addappid(496392, 1, "b4de0c77eb24d5cbc97ed78584165ed7b0bce35fde78f47140a754e167322c8a")

