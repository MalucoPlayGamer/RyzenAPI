-- Lua provided by RyzenAPI
-- Game: Shiny

-- MAIN APPLICATION
addappid(496390)

-- MAIN APP DEPOTS / PACKAGES
addappid(496391, 1, "37186bd98acf81e9e9d41510beb3a53cd37a47e74932b9acb46e6cdc9d770efc")
addappid(496392, 1, "b4de0c77eb24d5cbc97ed78584165ed7b0bce35fde78f47140a754e167322c8a")

