-- Lua provided by RyzenAPI
-- Game: Game: AppID 855370

-- MAIN APPLICATION
addappid(855370)
-- Game: addappid(855370)

-- MAIN APP DEPOTS / PACKAGES
addappid(855371, 1, "db38b1cd2efc6a37c33570f52fdfec1e161202ec73df5f66fed59a095c439916")
