-- Lua provided by RyzenAPI
-- Game: AppID 2011010

-- MAIN APPLICATION
addappid(2011010)
-- Game: addappid(2011010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011011, 1, "d9735bf9258da91b8289275b0a6e813e1e9e51f0b66efd7e3a3114f55df03372")
