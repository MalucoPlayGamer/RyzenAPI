-- Lua provided by RyzenAPI
-- Game: Electronauts - VR Music

-- MAIN APPLICATION
addappid(691160)

-- MAIN APP DEPOTS / PACKAGES
addappid(691161, 1, "05d5548a630a46ba4a8849f86b0ea0d43fd67ab71d05fc748109aad74f037c08")

