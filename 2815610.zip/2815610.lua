-- Lua provided by RyzenAPI
-- Game: Chronicon: Survivors

-- MAIN APPLICATION
addappid(2815610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2815611, 1, "b6f708696964c6c9aeef289e56398b5a4420c85473b5fbb118f6292344126ecc")

