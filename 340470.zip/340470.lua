-- Lua provided by RyzenAPI
-- Game: You Are Not a Banana: Better Edition

-- MAIN APPLICATION
addappid(340470)

-- MAIN APP DEPOTS / PACKAGES
addappid(340473,0,"e1161ffd712b519301ade862ad78f7d2a32e4078222d3b396a2d11edd88010a4")
addappid(340474,0,"e242bb7dec34c021dc3f1de431b3cb7d2189ee88c4bd93f6962e47bded15e5d0")
addappid(340475,0,"e1ca86d465f81d69239db9220d0afcf91c53a0f2cac08564c2ec19f9c2f99f9a")
