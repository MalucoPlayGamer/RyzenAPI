-- Lua provided by RyzenAPI
-- Game: The Quintessential Quintuplets OMOIDE VR ~ITSUKI~

-- MAIN APPLICATION
addappid(1968570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1968573,0,"44370fc03c284001215a4e89af5c31c1dbf7af14e881f7d703b446234265dfc2")
addappid(1968574,0,"55af9784ce388b689ea8e8eefc69e51cc5f8baed48450c0b78723ddb67614028")
addappid(1968575,0,"5b75296f86ea721e3a1b5d62cf2b2caa133fdcf2f6da1bf7b3a2d1f8240ccb2f")

