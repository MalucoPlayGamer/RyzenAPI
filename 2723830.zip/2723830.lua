-- Lua provided by RyzenAPI
-- Game: Game: True Boxing VR Demo

-- MAIN APPLICATION
addappid(2723830)
-- Game: addappid(2723830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2723831, 1, "04af4add1b390195710eb44c0acecf65889e11c5fd1672e24fccdd7ad2b32b0c")
