-- Lua provided by RyzenAPI
-- Game: Game: AppID 1025240

-- MAIN APPLICATION
addappid(1025240)
-- Game: addappid(1025240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1025241, 1, "9f7f9f91ea6fc211b10b86e8a9a2797d1b1766fcec295b143ab83d1615e0b76f")
