-- Lua provided by RyzenAPI
-- Game: 挂机神话

-- MAIN APPLICATION
addappid(1863750)
-- Game: addappid(1863750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863751, 1, "505f3cd320692208242f51c733b593ef5b157381613a77fd18f644102c0d655b")
