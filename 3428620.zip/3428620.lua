-- Lua provided by RyzenAPI
-- Game: AppID 3428620

-- MAIN APPLICATION
addappid(3428620)
-- Game: addappid(3428620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3428621, 1, "4230ec41b2d210ca9b3cf29d88204be470ce55b8a6b83c4c8fb9c0e541e99c6b")
