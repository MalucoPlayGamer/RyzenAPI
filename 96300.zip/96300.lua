-- Lua provided by RyzenAPI
-- Game: Ravaged Zombie Apocalypse

-- MAIN APPLICATION
addappid(96300)
addappid(96308)

-- MAIN APP DEPOTS / PACKAGES
addappid(96301,0,"ff8c5a7a6d0e3cf4993e5bc8f80d7923b35f22ee1abce8df6943e1794ee6abc9")
addappid(96302,0,"5282ff324bb598a48de9164c751cdd951e4c735047f9bb93714aa4ffee462491")
addappid(96303,0,"c2adfcbe9d399239b31c3fac4727331a2994cd6d19ff28914b56dcb2de57f073")
addappid(96304,0,"d8871b6d38bd579644bd2a49c50b3a6c0bfb0a7dfd0c35129fccd828a38fc1c0")
addappid(96305,0,"def57863bbec5eb6362834d599636c504bdc3c385939f1a283523dfbb0547223")
addappid(96307,0,"575a754d1a8e6175bc305f33153eb0c24d765b56bf6321077e8a7ea6bb2de706")

