-- Lua provided by RyzenAPI
-- Game: Tech Store Simulator: Prologue

-- MAIN APPLICATION
addappid(3069570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3069571, 1, "40f8ff648fd173699782aa5a24f4c17ce24bbb0d8eac1ca78220a5c88f3c5294")

