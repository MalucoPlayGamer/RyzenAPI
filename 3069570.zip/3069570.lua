-- Lua provided by RyzenAPI
-- Game: Game: Tech Store Simulator: Prologue

-- MAIN APPLICATION
addappid(3069570)
-- Game: addappid(3069570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3069571, 1, "40f8ff648fd173699782aa5a24f4c17ce24bbb0d8eac1ca78220a5c88f3c5294")
