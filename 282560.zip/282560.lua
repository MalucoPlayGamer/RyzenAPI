-- Lua provided by RyzenAPI
-- Game: RollerCoaster Tycoon World™

-- MAIN APPLICATION
addappid(282560)

-- MAIN APP DEPOTS / PACKAGES
addappid(282561, 1, "8b3e227e0384abb4cf2bc11c31e7d50519302ee8f891a45faec39b77fac436c6")
addappid(405580, 0, "36c6fb2a14c938966805ab77d290eb8b169ee9bb50d5da5f401ed87b09ac2e3f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(542950)
