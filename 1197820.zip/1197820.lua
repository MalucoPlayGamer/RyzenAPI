-- Lua provided by RyzenAPI 
-- Game: AppID 1197820
addappid(1197820)
addappid(1197821, 1, "db0b0cea6e7a0f43daa3c80003884341d4b1d2ff1b5687bd008356e72b3cfa32")
addappid(1197822, 1, "0c0236a44159a3ef5f52b288ea8757188164c83cab0b11e8768b32f9c200ed26")
