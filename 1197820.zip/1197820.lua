-- Lua provided by RyzenAPI
-- Game: Craftlands Workshoppe

-- MAIN APPLICATION
addappid(1197820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1197821, 1, "db0b0cea6e7a0f43daa3c80003884341d4b1d2ff1b5687bd008356e72b3cfa32")
addappid(1197822, 1, "0c0236a44159a3ef5f52b288ea8757188164c83cab0b11e8768b32f9c200ed26")
