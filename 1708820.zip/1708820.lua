-- Lua provided by RyzenAPI
-- Game: Guardian Force - Saturn Tribute

-- MAIN APPLICATION
addappid(1708820)
-- Game: addappid(1708820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708821, 1, "e225c38f3573d487051bfd94f2ea1cc7d42e7685bc3be06b5b1ce738e4dd7fb3")
