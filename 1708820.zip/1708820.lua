-- Lua provided by RyzenAPI
-- Game: Guardian Force - Saturn Tribute

-- MAIN APPLICATION
addappid(1708820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708821, 1, "e225c38f3573d487051bfd94f2ea1cc7d42e7685bc3be06b5b1ce738e4dd7fb3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
