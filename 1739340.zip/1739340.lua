-- Lua provided by RyzenAPI
-- Game: addappid(1739340)

-- MAIN APPLICATION
addappid(1739340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1739341, 1, "91b94547f57c96bda78cd0e6aeea1ba57442009f6a58e8b9a13df1d6e7b4cbb0")
