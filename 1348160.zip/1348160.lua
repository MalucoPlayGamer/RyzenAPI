-- Lua provided by RyzenAPI
-- Game: Game: Turn on the light

-- MAIN APPLICATION
addappid(1348160)
-- Game: addappid(1348160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1348161, 1, "0627cf194bde99191e8635df245923cdd16e0dec86cd7a4d6f2da7d4660ffc12")
