-- Lua provided by SkyAPI 
-- Game: AppID 1891470
addappid(1891470)
addappid(1891471, 1, "484501e893eeb03e8d53d7015a86197e3c170139f48b6fee1e55a080bde9c771")
