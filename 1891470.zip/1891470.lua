-- Lua provided by RyzenAPI
-- Game: Ghostlore Demo

-- MAIN APPLICATION
addappid(1891470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1891471, 1, "484501e893eeb03e8d53d7015a86197e3c170139f48b6fee1e55a080bde9c771")
