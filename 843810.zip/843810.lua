-- Lua provided by RyzenAPI
-- Game: A Perfect Day

-- MAIN APPLICATION
addappid(843810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(843811, 1, "03c6d967b50c9fff877a5da33cd6e0a840a3da92a8ccb5cfe495425c98861843")
addappid(843812, 1, "126904b199adc3a4e81352c751dfdc85b80c3c5d734d4b5e378044f07351d722")

