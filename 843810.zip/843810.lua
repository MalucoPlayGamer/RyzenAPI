-- Lua provided by RyzenAPI
-- Game: A Perfect Day

-- MAIN APPLICATION
addappid(843810)

-- MAIN APP DEPOTS / PACKAGES
addappid(843811, 1, "03c6d967b50c9fff877a5da33cd6e0a840a3da92a8ccb5cfe495425c98861843")
addappid(843812, 1, "126904b199adc3a4e81352c751dfdc85b80c3c5d734d4b5e378044f07351d722")

