-- Lua provided by RyzenAPI
-- Game: 592780

-- MAIN APPLICATION
addappid(592780)
-- Game: addappid(592780)

-- MAIN APP DEPOTS / PACKAGES
addappid(592781, 1, "10f8125f3de47bfc7baf95b025c068eceedeb15073f8bd1ae1bcdc411ceca289")
