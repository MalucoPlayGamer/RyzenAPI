-- Lua provided by RyzenAPI
-- Game: AppID 824190

-- MAIN APPLICATION
addappid(824190)
-- Game: addappid(824190)

-- MAIN APP DEPOTS / PACKAGES
addappid(824191, 1, "a3d9930b62c8fc8383a057fcb294d8a6ee7f0a24a589f2723daed04a8308d461")
