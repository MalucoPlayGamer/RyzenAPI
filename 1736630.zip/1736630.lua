-- Lua provided by RyzenAPI
-- Game: Game: Minesweeper Ultimate

-- MAIN APPLICATION
addappid(1736630)
-- Game: addappid(1736630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1736631, 1, "4aa0bb02b29c63442161865df582c78d759d454fcabc12a299d3bc2ec28d2d25")
