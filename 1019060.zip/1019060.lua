-- Lua provided by RyzenAPI
-- Game: 1019060

-- MAIN APPLICATION
addappid(1019060)
-- Game: addappid(1019060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019061, 1, "80309eed8e09c6b7b99eb1d0caa95530dac1fe7ff1b48d0a04c9b58801322102")
