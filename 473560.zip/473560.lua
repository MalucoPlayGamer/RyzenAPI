-- Lua provided by RyzenAPI
-- Game: addappid(473560)

-- MAIN APPLICATION
addappid(473560)

-- MAIN APP DEPOTS / PACKAGES
addappid(473561, 1, "09c7438823cc9c11c9e6d23b481861da839244d2096fa9b6eb69c9f05bd960a4")
