-- Lua provided by RyzenAPI
-- Game: Game: Wild Journey

-- MAIN APPLICATION
addappid(1525460)
addappid(1543480)
-- Game: addappid(1525460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1525461, 1, "39dd07639dea94ef7cd3e3824ddc328d970046c34ecd1dd988763847c25b2b98")
