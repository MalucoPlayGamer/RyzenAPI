-- 4809100's Lua and Manifest Created by Hubcap Manifest
-- Heartbeat Impact
-- Created: August 25, 2026 at 08:21:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4809100) -- Heartbeat Impact
-- MAIN APP DEPOTS
addappid(4809101, 1, "33431ef429fade2e2fe1b07bb05f3389de0c88f6e0d1ab079b748e8e990aad9c") -- Depot 4809101
setManifestid(4809101, "6920449890072995203", 316440800)