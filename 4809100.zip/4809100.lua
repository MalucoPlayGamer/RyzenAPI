-- Lua provided by RyzenAPI
-- Game: Heartbeat Impact

-- MAIN APPLICATION
addappid(4809100) -- Heartbeat Impact

-- MAIN APP DEPOTS / PACKAGES
addappid(4809101, 1, "33431ef429fade2e2fe1b07bb05f3389de0c88f6e0d1ab079b748e8e990aad9c") -- Depot 4809101

