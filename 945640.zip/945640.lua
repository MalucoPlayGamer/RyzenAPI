-- Lua provided by RyzenAPI
-- Game: Game: AppID 945640

-- MAIN APPLICATION
addappid(945640)
-- Game: addappid(945640)

-- MAIN APP DEPOTS / PACKAGES
addappid(945641, 1, "a75344207d5661589500ba96c6790d01350a8eca9e1b513111154e192f69ce8a")
