-- Lua provided by RyzenAPI
-- Game: 1192840

-- MAIN APPLICATION
addappid(1192840)
-- Game: addappid(1192840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1192841, 1, "ce36031c805fd0968815a307bd297c4c428b813df0b42592dcd7afb21b058f8f")
