-- Lua provided by RyzenAPI
-- Game: Warplan Pacific

-- MAIN APPLICATION
addappid(1896160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1896161, 1, "d7d1ea10a10147bfb95a9e7f0ae22011935de05ab6c393ff87ff6ac834181306")
addappid(1896162, 1, "bfa47df3cae8df9ae45d28e016283cc236f38c36c624e2bebfa340250b5d6d21")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
