-- Lua provided by RyzenAPI
-- Game: Bloodthief Demo

-- MAIN APPLICATION
addappid(2941730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2941732,0,"d9d3402c0bb2ccc2fbb069eccb545dd60e70f16a86b7c9e2e6e7066d1832368f")

