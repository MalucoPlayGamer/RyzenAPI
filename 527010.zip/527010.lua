-- Lua provided by RyzenAPI
-- Game: Tempest - Original Soundtrack

-- MAIN APPLICATION
addappid(527010)
-- Game: addappid(527010)

-- MAIN APP DEPOTS / PACKAGES
addappid(418184,0,"c727c55d0ca90abf8a7f09dab099e96d2fe00c8911b91f1df0083b4317d7e830")
