-- Lua provided by RyzenAPI
-- Game: Ren the Summoner and the Erotic Dungeon

-- MAIN APPLICATION
addappid(1653030)
addappid(2268530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653031, 1, "8a1dfabb9ff0e28157ecaad1bf24a34348cb46afdcb59490d3d5f169eac91a71")

