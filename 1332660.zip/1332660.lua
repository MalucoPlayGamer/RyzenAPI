-- Lua provided by RyzenAPI
-- Game: addappid(1332660)

-- MAIN APPLICATION
addappid(1332660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332661, 1, "ccefd0fe77982711935b9fe88a8885b0196fb99cfebafbea725d7df81cf80228")
