-- Lua provided by SkyAPI 
-- Game: €100
addappid(1036910)
addappid(1036911, 1, "e5cad217f3e43659f49374308c39512c5b141ab4be7cdb197ef4db62707e0681")
addappid(1045410, 0, "df84eae423ea08fbebf9a4a1482cc289b6488bbb241db42165fa9283bdeedae1")
