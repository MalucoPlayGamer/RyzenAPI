-- Lua provided by RyzenAPI
-- Game: Combolands: Roguelike Citybuilder

-- MAIN APP DEPOTS / PACKAGES
addappid(4075620, 1, "504f6eb7e6f4f87aef685dbc6b06fc0d241cf119f9d81f3d565559d8dd67c4b3") -- Combolands: Roguelike Citybuilder
addappid(4075621, 1, "b6ca94ca10eaf4aea16292ac6c291acbbb0feba390f26f3abcf4d61504a66c68") -- Depot 4075621

