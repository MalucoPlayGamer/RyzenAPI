-- 4075620's Lua and Manifest Created by Hubcap Manifest
-- Combolands: Roguelike Citybuilder
-- Created: August 24, 2026 at 15:06:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4075620, 1, "504f6eb7e6f4f87aef685dbc6b06fc0d241cf119f9d81f3d565559d8dd67c4b3") -- Combolands: Roguelike Citybuilder
-- MAIN APP DEPOTS
addappid(4075621, 1, "b6ca94ca10eaf4aea16292ac6c291acbbb0feba390f26f3abcf4d61504a66c68") -- Depot 4075621
setManifestid(4075621, "6769643243344178156", 379622386)