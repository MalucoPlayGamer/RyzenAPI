-- Lua provided by RyzenAPI
-- Game: addappid(2277310)

-- MAIN APPLICATION
addappid(2277310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2277311, 1, "3fbc427f76e1cd703c3fe9f8fb97cf504696d6d5db161a4144d2e93b7a088c00")
