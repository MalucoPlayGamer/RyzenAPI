-- Lua provided by SkyAPI 
-- Game: Idol Hacked!
addappid(3217000)
addappid(3217001, 1, "cd3a31f30b466c166c1126e34ce3c6e11982b0906bcc31952c398aa7582b63d0")
