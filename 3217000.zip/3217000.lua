-- Lua provided by RyzenAPI
-- Game: Idol Hacked!

-- MAIN APPLICATION
addappid(3217000)
-- Game: addappid(3217000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3217001, 1, "cd3a31f30b466c166c1126e34ce3c6e11982b0906bcc31952c398aa7582b63d0")
