-- Lua provided by RyzenAPI
-- Game: Under The Waves Demo

-- MAIN APPLICATION
addappid(3069100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3069101, 1, "51703515d07055492fdcedecde4327a4978e2a0bc26c57e7afbaa73dca74ce7e")
