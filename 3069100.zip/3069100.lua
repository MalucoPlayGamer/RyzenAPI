-- Lua provided by RyzenAPI 
-- Game: Under The Waves Demo
addappid(3069100)
addappid(3069101, 1, "51703515d07055492fdcedecde4327a4978e2a0bc26c57e7afbaa73dca74ce7e")
