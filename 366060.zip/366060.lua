-- Lua provided by RyzenAPI 
-- Game: Teddy Terror
addappid(366060)
addappid(366061, 1, "5f18928f318793a1646c711f57449f5b29dde99a45b5a91f8b99d15c188af6b0")
