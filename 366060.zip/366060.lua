-- Lua provided by RyzenAPI
-- Game: Teddy Terror

-- MAIN APPLICATION
addappid(366060)

-- MAIN APP DEPOTS / PACKAGES
addappid(366061, 1, "5f18928f318793a1646c711f57449f5b29dde99a45b5a91f8b99d15c188af6b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
