-- Lua provided by RyzenAPI
-- Game: Game: AppID 2641770

-- MAIN APPLICATION
addappid(2641770)
-- Game: addappid(2641770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641771, 1, "4685bcaf5e739b87454d47054e0ac89a227155830ec1420ce1933e29f627f58e")
