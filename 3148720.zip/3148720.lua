-- Lua provided by SkyAPI 
-- Game: AppID 3148720
addappid(3148720)
addappid(3148721, 1, "c16f7db3ee8659c1b17c344e40649ccfb46203a6244710004149cf0e07bc5d79")
