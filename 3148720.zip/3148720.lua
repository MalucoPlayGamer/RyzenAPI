-- Lua provided by RyzenAPI
-- Game: 永无乡 Demo

-- MAIN APPLICATION
addappid(3148720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3148721, 1, "c16f7db3ee8659c1b17c344e40649ccfb46203a6244710004149cf0e07bc5d79")

