-- Lua provided by RyzenAPI
-- Game: AppID 1059460

-- MAIN APPLICATION
addappid(1059460)
-- Game: addappid(1059460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059461, 1, "f87d8bc2383b9a9cacebe798891f766331380204a50cc42b89c6b8af795b7fbf")
