-- Lua provided by RyzenAPI
-- Game: AppID 1015350

-- MAIN APPLICATION
addappid(1015350)
-- Game: addappid(1015350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1015351, 1, "efda3cadfd6a3ee1c8ed9698e4070ece65c53ade3002efac84d9e044e99a5f18")
addappid(1039740, 0, "8981c224bd1b71d2c40d9ccc132108219f9aad87b2c78c701a737687f767be0c")
