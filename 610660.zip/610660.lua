-- Lua provided by RyzenAPI
-- Game: addappid(610660)

-- MAIN APPLICATION
addappid(610660)

-- MAIN APP DEPOTS / PACKAGES
addappid(610661, 1, "27bb842b8eae7fd6a17bbf49be4f2264cc4dfe7b313f3e0736244ae490b467df")
