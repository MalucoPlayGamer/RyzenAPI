-- Lua provided by SkyAPI 
-- Game: Memory of Lust
addappid(3432000)
addappid(3432001, 1, "6503f0c1eb4ee13f42a68d654dfcedc5d9af64a7e899f394d0a0d293a7ff16a1")
