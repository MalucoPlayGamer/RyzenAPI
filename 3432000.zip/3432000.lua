-- Lua provided by RyzenAPI
-- Game: Memory of Lust

-- MAIN APPLICATION
addappid(3432000)
-- Game: addappid(3432000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3432001, 1, "6503f0c1eb4ee13f42a68d654dfcedc5d9af64a7e899f394d0a0d293a7ff16a1")
