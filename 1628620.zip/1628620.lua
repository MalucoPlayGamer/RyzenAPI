-- Lua provided by RyzenAPI 
-- Game: AppID 1628620
addappid(1628620)
addappid(1628621, 1, "eff2e4641daefca372cec5498c8b9868543d1ef43bfd396ecd2d83d004d7ea54")
