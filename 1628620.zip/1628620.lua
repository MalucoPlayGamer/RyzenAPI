-- Lua provided by RyzenAPI
-- Game: World Boss

-- MAIN APPLICATION
addappid(1628620)
addappid(2128920)
addappid(2128922)

-- MAIN APP DEPOTS / PACKAGES
addappid(1628621, 1, "eff2e4641daefca372cec5498c8b9868543d1ef43bfd396ecd2d83d004d7ea54")
