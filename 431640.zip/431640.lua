-- Lua provided by RyzenAPI
-- Game: Doodle Kingdom

-- MAIN APPLICATION
addappid(431640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(431641, 1, "bc47bf3bbd54fcb526e89323837e7e341add914f084bce95bf808a0d76c9d817")
addappid(431642, 1, "5af0e14c859497ce73b3ea89c3be18957f237f713be5f49b8ec258be567edd46")
addappid(431643, 1, "e775600d36ba3d48eb2e8fa87f006a0983e6a69e06837988f5a3bfc5cf5cd62b")
addappid(431644, 1, "ff452b2887b6fbc0dec5ecd04b860c5b4723906cd597afd867d3bf528f094256")
addappid(431645, 1, "42536c6862aa2c071b64f34700964aeb9d9bf6cb7a7687222ada5782800d6e01")

