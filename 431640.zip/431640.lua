-- Lua provided by RyzenAPI
-- Game: Doodle Kingdom

-- MAIN APPLICATION
addappid(431640)
-- Game: addappid(431640)

-- MAIN APP DEPOTS / PACKAGES
addappid(431641, 1, "bc47bf3bbd54fcb526e89323837e7e341add914f084bce95bf808a0d76c9d817")
addappid(431642, 1, "5af0e14c859497ce73b3ea89c3be18957f237f713be5f49b8ec258be567edd46")
addappid(431643, 1, "e775600d36ba3d48eb2e8fa87f006a0983e6a69e06837988f5a3bfc5cf5cd62b")
addappid(431644, 1, "ff452b2887b6fbc0dec5ecd04b860c5b4723906cd597afd867d3bf528f094256")
addappid(431645, 1, "42536c6862aa2c071b64f34700964aeb9d9bf6cb7a7687222ada5782800d6e01")
