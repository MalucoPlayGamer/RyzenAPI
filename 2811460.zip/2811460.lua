-- Lua provided by RyzenAPI
-- Game: Flambeau Deluxxx Demo

-- MAIN APPLICATION
addappid(2811460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2811461, 1, "bdbad4290cfeacec37cc7bb78bd82e4997ce852a076a9759480a62b33fe7ce5a")
