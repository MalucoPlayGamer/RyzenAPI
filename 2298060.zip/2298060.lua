-- Lua provided by RyzenAPI
-- Game: Polyrhythm Master

-- MAIN APPLICATION
addappid(2298060)
-- Game: addappid(2298060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2298061, 1, "e3c94ccdc333b78bf2b1e112c0159f84c537e495ea11b197ebbaf15a513f6e41")
