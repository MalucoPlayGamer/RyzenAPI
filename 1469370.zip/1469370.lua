-- Lua provided by RyzenAPI
-- Game: addappid(1469370)

-- MAIN APPLICATION
addappid(1469370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1469371, 1, "7ab087d6cebc31b0ff62daa9e90e0f1b70cf441ab019587111f40aa42c24725a")
