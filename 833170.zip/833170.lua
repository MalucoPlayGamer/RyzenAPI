-- Lua provided by RyzenAPI
-- Game: Burned Land

-- MAIN APPLICATION
addappid(833170)

-- MAIN APP DEPOTS / PACKAGES
addappid(833171, 1, "2377d856aa81cc98799fe36e08a44930ea62c228be36494522656631ee2f488e")

