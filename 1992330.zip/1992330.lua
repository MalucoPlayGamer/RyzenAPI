-- Lua provided by RyzenAPI
-- Game: addappid(1992330)

-- MAIN APPLICATION
addappid(1992330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1992331, 1, "2ce2032bf57c303bb66178be3e876236544f2d6836df3ae549c8f753fafd3063")
