-- Lua provided by SkyAPI 
-- Game: AppID 1186030
addappid(1186030)
addappid(1186031, 1, "785bb90d106421ef741c8cf467db2c77ad8ac8daadc0a31bf6912c3573965238")
