-- Lua provided by SkyAPI 
-- Game: Hentai CyberGirl
addappid(2237690)
addappid(2237691, 1, "4b09ddd39fb11b1992ed62120a17c9de1c587a310c7dac3114364e45ca99509c")
