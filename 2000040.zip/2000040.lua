-- Lua provided by RyzenAPI
-- Game: Game: AppID 2000040

-- MAIN APPLICATION
addappid(2000040)
-- Game: addappid(2000040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000041, 1, "3e26cb6c83e8f1c7915ccf157b082f5c9ed63a2f67e01ce113d32f4848bd2bf0")
