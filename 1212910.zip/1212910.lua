-- Lua provided by RyzenAPI
-- Game: addappid(1212910)

-- MAIN APPLICATION
addappid(1212910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212911, 1, "5cf92c608d627abf8172cd3e03db96c3aefb5ba123fda96058d60b4494d81fdb")
