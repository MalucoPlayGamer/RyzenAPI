-- Lua provided by RyzenAPI
-- Game: SHINRAI - Broken Beyond Despair

-- MAIN APPLICATION
addappid(499910)

-- MAIN APP DEPOTS / PACKAGES
addappid(499911, 1, "c38c2e3315b2e55aa77c5fad8ecc362192f7bbbb2fe7bd571f0a42a832965db6")

