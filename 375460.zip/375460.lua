-- Lua provided by RyzenAPI
-- Game: Game: AppID 375460

-- MAIN APPLICATION
addappid(375460)
-- Game: addappid(375460)

-- MAIN APP DEPOTS / PACKAGES
addappid(375461, 1, "8f179e52ebbb142e72b70af4cba1d4c37664cae14f131c533ad417dcf92f0431")
addappid(375462, 1, "f9d047cdab5a01a1f8f3dc7ad302d42414b1357691cc743e15408aff07f6b71a")
addappid(375463, 1, "220149687ee6f1ad8a5a7b7168537e5f5bb3296e0c255912a41502e2a59f8d5f")
