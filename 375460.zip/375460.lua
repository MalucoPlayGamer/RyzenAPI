-- Lua provided by RyzenAPI
-- Game: AppID 375460

-- MAIN APPLICATION
addappid(375460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(375461, 1, "8f179e52ebbb142e72b70af4cba1d4c37664cae14f131c533ad417dcf92f0431")
addappid(375462, 1, "f9d047cdab5a01a1f8f3dc7ad302d42414b1357691cc743e15408aff07f6b71a")
addappid(375463, 1, "220149687ee6f1ad8a5a7b7168537e5f5bb3296e0c255912a41502e2a59f8d5f")

