-- Lua provided by RyzenAPI
-- Game: Game: Stardom MiniGames

-- MAIN APPLICATION
addappid(1642560)
-- Game: addappid(1642560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642561, 1, "4c8cd7aedc7641ee55d58564a6ec0d31aaaa40c510256b05d6e32f34e818bb76")
