-- Lua provided by RyzenAPI
-- Game: AppID 442070

-- MAIN APPLICATION
addappid(442070)

-- MAIN APP DEPOTS / PACKAGES
addappid(442071, 1, "bbf4c8e20e1886a173b9c58061fa0198b09a513b9ed53d6aeff5511c28e105ee")
addappid(442072, 1, "0215f126abaeb57eb1975c7b70f6adf69c05834aced5d3ba6f15dc73b187d52c")
addappid(442073, 1, "0a46ab6ee99f2c91fe52854b46b1fbd6fa402b69c54ab82080e386f33c5e71f5")
addappid(442074, 1, "87280cf9f663f60f577d10c0c1cbb7286c661c813941ef3fbbef55a24bdf5f4f")
addappid(442075, 1, "86de8cb4fbdd4f6dfadfe5faae67e67a322ba2de8db21a85d2e5f5c58c93048b")
addappid(442076, 1, "5722f2873b44ebc8d6bab01409febf71e17a06fae715ea7f4408740fc17dca7d")
addappid(2828508, 0, "86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
