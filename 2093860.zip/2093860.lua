-- Lua provided by RyzenAPI
-- Game: Game: Get the Ball Rolling

-- MAIN APPLICATION
addappid(2093860)
-- Game: addappid(2093860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093861, 1, "029c55a9631a48ad776c07f8946a7fdfda95085e38f5f20aa3523a8022ffdf00")
