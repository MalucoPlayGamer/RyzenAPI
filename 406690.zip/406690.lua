-- Lua provided by RyzenAPI
-- Game: Game: Roses and Gems

-- MAIN APPLICATION
addappid(406690)
-- Game: addappid(406690)

-- MAIN APP DEPOTS / PACKAGES
addappid(406691, 1, "6345c4c0558725de94ea64497beec904ec958843d510e56439e44720d9fa6771")
