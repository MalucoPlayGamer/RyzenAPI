-- Lua provided by RyzenAPI
-- Game: addappid(2507970)

-- MAIN APPLICATION
addappid(2507970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2507971, 1, "641cd9b13c9c165335ecc2ba1a8c1634a80ee1dde3cc42fa657ba73eb7f28625")
addappid(2507972, 1, "aeaf5125e34e1f19351169a2cc8a1a1e7ab5ba681968cd683d0a5310542a5781")
