-- Lua provided by RyzenAPI
-- Game: Game: AppID 2273150

-- MAIN APPLICATION
addappid(2273150)
-- Game: addappid(2273150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2273151, 1, "f4c7208e50f8da12af63231630396fecdfc5d506fa1bffb058e940e34a8e11b2")
