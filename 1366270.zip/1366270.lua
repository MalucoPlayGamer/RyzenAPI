-- Lua provided by RyzenAPI 
-- Game: Primal Carnage: Extinction - Workshop Tool
addappid(1366270)
addappid(1366271, 1, "07c22a7cfafb88c8f7664a9f50870b11cf0f68abc03a1e8cecb524f66eceaa2b")
