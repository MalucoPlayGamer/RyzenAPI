-- Lua provided by RyzenAPI
-- Game: Picross Fairytale - nonogram: Red Riding Hood secret

-- MAIN APPLICATION
addappid(820030)
addappid(897350)

-- MAIN APP DEPOTS / PACKAGES
addappid(820031, 1, "20845d93e9e03b0eec8771b554bf3b6267796eb78eb5535ec56149a885887d63")
addappid(820032, 1, "9642dab7dda21addb3cfb8417a8fbdf398d9195c25971a50e65f0e5a05a52ad1")
addappid(820033, 1, "b3c4e5e0b6f75f5be423a455a06b446b996b2ceb69ef2afc0462706fa94f3789")
addappid(820034, 1, "a4af67be2389f49d098b1214392544dae1ad768c3d133aa5d5ccccce849d4953")
addappid(820035, 1, "9a4df3a3e24aa6cec8f8ec0d9a5e65ba5e5a2195e5cdadbf529d09a5a1030950")
