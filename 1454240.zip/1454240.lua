-- Lua provided by RyzenAPI
-- Game: addappid(1454240)

-- MAIN APPLICATION
addappid(1454240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454241, 1, "be1d706ce3b1d68035835bfd852535bc6f04f4e80e762e41f02bf40acdffd8af")
