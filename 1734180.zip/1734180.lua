-- Lua provided by RyzenAPI
-- Game: FUSER™ - Ellie Goulding - "Lights"

-- MAIN APPLICATION
addappid(1734180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734180,0,"a24573cd673d2cc665b96335627deacbb15a4cf9734d0233da3248860afdfaeb")

