-- Lua provided by RyzenAPI
-- Game: Whispering Willows - Art Book, Soundtrack, and Wallpaper

-- MAIN APPLICATION
addappid(306601)

-- MAIN APP DEPOTS / PACKAGES
addappid(306601,0,"9adb9035a0fbc3528261a9c6fe81a6d009181b8f7447db6cde99afda3452ca51")
addappid(1242870,0,"03143ccc627e96d5176c6e9358fe36c2c5ed57d5a57e65a66f5fbf78b85b9e26")

