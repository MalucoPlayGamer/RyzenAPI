-- Lua provided by RyzenAPI
-- Game: Wild City

-- MAIN APPLICATION
addappid(2436970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436971,0,"9e4393decad96a42d6a819724c3d244424c0249570c4dcd861bd3f09a5fcb955")

