-- Lua provided by RyzenAPI
-- Game: Game: AppID 3174660

-- MAIN APPLICATION
addappid(3174660)
-- Game: addappid(3174660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3174661, 1, "ec44587a1850861991cb819920787bb273248bc2f6769c8fd79c8d73aa7d046c")
