-- Lua provided by RyzenAPI
-- Game: Crystar - Rei's Peddler Outfit

-- MAIN APPLICATION
addappid(1070122)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070122,0,"2be338a08e9e70f4f012568a74ef5898082a3ac220095dcb58025fa339b186a2")

