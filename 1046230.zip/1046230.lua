-- Lua provided by RyzenAPI
-- Game: Game: AppID 1046230

-- MAIN APPLICATION
addappid(1046230)
-- Game: addappid(1046230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046231, 1, "6846fd9879b71f0312cf05d93f30df10285bfe8ef75a37294c394a7941691fe9")
