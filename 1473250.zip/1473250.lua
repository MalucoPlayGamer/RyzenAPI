-- Lua provided by RyzenAPI
-- Game: addappid(1473250)

-- MAIN APPLICATION
addappid(1473250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473251, 1, "3cbbcc5ac633598eb581198b8594acbb2fc21256c4b8337ee6286b3b2c01a318")
