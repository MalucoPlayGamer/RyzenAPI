-- Lua provided by RyzenAPI
-- Game: Get To A Gun

-- MAIN APPLICATION
addappid(935320)

-- MAIN APP DEPOTS / PACKAGES
addappid(935321, 1, "8cd68ccf65008198c72ca1a262b279520fd628c3d77cfafe35314689a89147f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
