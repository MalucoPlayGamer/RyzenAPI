-- Lua provided by SkyAPI 
-- Game: Just Read The Instructions
addappid(1461370)
addappid(1461371, 1, "93e49fc2c884557774b4852f57ee89abd8aa6c6f37827026fccf201ed8bbdffb")
