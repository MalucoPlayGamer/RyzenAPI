-- Lua provided by RyzenAPI
-- Game: Just Read The Instructions

-- MAIN APPLICATION
addappid(1461370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461371, 1, "93e49fc2c884557774b4852f57ee89abd8aa6c6f37827026fccf201ed8bbdffb")
