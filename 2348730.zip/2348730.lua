-- Lua provided by RyzenAPI
-- Game: Hauntsville

-- MAIN APPLICATION
addappid(2348730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2348732,0,"1db34303394ca3a9c48e61c3cf6eb8d9a64a4b95765c951f7a7ec1561977f6e3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
