-- Lua provided by RyzenAPI
-- Game: Hauntsville

-- MAIN APPLICATION
addappid(2348730)
-- Game: addappid(2348730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2348732,0,"1db34303394ca3a9c48e61c3cf6eb8d9a64a4b95765c951f7a7ec1561977f6e3")
