-- Lua provided by RyzenAPI
-- Game: AppID 394950

-- MAIN APPLICATION
addappid(394950)
-- Game: addappid(394950)

-- MAIN APP DEPOTS / PACKAGES
addappid(394951, 1, "9ceda251b38fbb9ad735cd4149bddef60dde8a22d785730de2f201d8928af742")
