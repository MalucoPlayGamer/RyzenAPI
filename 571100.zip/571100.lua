-- Lua provided by RyzenAPI
-- Game: AppID 571100

-- MAIN APPLICATION
addappid(571100)
-- Game: addappid(571100)

-- MAIN APP DEPOTS / PACKAGES
addappid(571101, 1, "c48b55e693271b9c7625832b265ed5db532b20924fc14c4112ef15ad2265e56b")
addappid(571102, 1, "2b71dd90625c1a8af34f94874efeae030df7ed4b9995d098b2c316afb455a86e")
