-- Lua provided by RyzenAPI
-- Game: addappid(1841600)

-- MAIN APPLICATION
addappid(1841600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1841601, 1, "3beb9efa94840a534690c92235cfa080c4fbfd62580193f129cae88fc5caa1f4")
