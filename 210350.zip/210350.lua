-- Lua provided by RyzenAPI
-- Game: Max Payne RU

-- MAIN APPLICATION
addappid(210350)
-- Game: addappid(210350)

-- MAIN APP DEPOTS / PACKAGES
addappid(210351, 1, "73a0b5103b4294a93c3d7ea529e0aab628082ee5c421d1a3422b539670d3d6c2")
