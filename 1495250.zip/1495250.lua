-- Lua provided by RyzenAPI
-- Game: addappid(1495250)

-- MAIN APPLICATION
addappid(1495250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495251, 1, "09c37b5fbd8469212e87d94cca5b5b73946160bf3134d7a9d1c6599a20dfa2cc")
