-- Lua provided by RyzenAPI
-- Game: Stella Pastoris

-- MAIN APPLICATION
addappid(1253010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253013,0,"8c599c187a8f3d1ec13134d14249fc0f19c080557744714180a939aaa51e454e")

