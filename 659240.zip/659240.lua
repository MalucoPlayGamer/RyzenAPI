-- Lua provided by RyzenAPI 
-- Game: AppID 659240
addappid(659240)
addappid(659241, 1, "18a9c1957789ea325edbce59693458c4b550582dfb1c88042d5d2c5df9654c82")
