-- Lua provided by RyzenAPI
-- Game: Will Glow the Wisp Demo

-- MAIN APPLICATION
addappid(727270)
-- Game: addappid(727270)

-- MAIN APP DEPOTS / PACKAGES
addappid(727272,0,"619f006c167cb23455bbe24aae66d1f56f64a7b8cf822884a56e7fb2485e4951")
