-- Lua provided by RyzenAPI
-- Game: 3296460

-- MAIN APPLICATION
addappid(3296460)
-- Game: addappid(3296460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3296460,0,"2bf8a0724cd296118896d9e39b0f171aa1af73b65f1e35293feb158f3c705a0b")
