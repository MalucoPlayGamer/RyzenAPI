-- Lua provided by SkyAPI 
-- Game: Zombie Clicker Defense
addappid(790230)
addappid(790231, 1, "0f74f8d51f62bd0889b07024924d05dfb6b3a143c66e2e89987ad1343f311f5b")
