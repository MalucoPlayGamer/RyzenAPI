-- Lua provided by RyzenAPI
-- Game: Zombie Clicker Defense

-- MAIN APPLICATION
addappid(790230)
-- Game: addappid(790230)

-- MAIN APP DEPOTS / PACKAGES
addappid(790231, 1, "0f74f8d51f62bd0889b07024924d05dfb6b3a143c66e2e89987ad1343f311f5b")
