-- Lua provided by RyzenAPI
-- Game: Present for Manager

-- MAIN APPLICATION
addappid(856670)

-- MAIN APP DEPOTS / PACKAGES
addappid(856671,0,"4680586f433630c5ac5d72305ab6c1700252dc3089650fecf802b5e9900c47c7")

