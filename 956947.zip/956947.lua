-- Lua provided by RyzenAPI
-- Game: addappid(956947)

-- MAIN APPLICATION
addappid(956947)

-- MAIN APP DEPOTS / PACKAGES
addappid(956947,0,"3946d1548d963f40cfdb9fc20b9e7f889b968b578ac1d28f3f4da2347a838330")
