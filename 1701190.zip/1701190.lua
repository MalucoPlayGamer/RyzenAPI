-- Lua provided by RyzenAPI 
-- Game: Chessformer
addappid(1701190)
addappid(1701191, 1, "1105ece05e52c6fca57a489c56d3043a37f47d9fc134898d8ca03a35334b7c7c")
