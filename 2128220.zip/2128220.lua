-- Lua provided by RyzenAPI 
-- Game: The Most Awesome Game Ever Made
addappid(2128220)
addappid(2128221, 1, "57c2d0b094a626ff527f5e43334a21a845f57fb5cb870c8d290d2179d06d1545")
