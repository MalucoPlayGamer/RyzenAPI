-- Lua provided by RyzenAPI
-- Game: Girls Pinball

-- MAIN APPLICATION
addappid(1513760)
addappid(1515910)
addappid(1515911)

-- MAIN APP DEPOTS / PACKAGES
addappid(1513761, 1, "f1e29587f6d7779ff0eeb6e71ff7c1158943488c055596cdaec283d86c68915a")

