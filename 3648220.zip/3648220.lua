-- Lua provided by RyzenAPI
-- Game: Wake Up The House

-- MAIN APPLICATION
addappid(3648220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3648221, 1, "4de127befed5ef661b6d9e59788f1a08cc076ac654201ded5dfb3d41ec0b8069")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
