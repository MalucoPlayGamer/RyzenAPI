-- Lua provided by RyzenAPI
-- Game: 3648220

-- MAIN APPLICATION
addappid(3648220)
-- Game: addappid(3648220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3648221, 1, "4de127befed5ef661b6d9e59788f1a08cc076ac654201ded5dfb3d41ec0b8069")
