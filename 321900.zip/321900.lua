-- Lua provided by RyzenAPI
-- Game: Game: AppID 321900

-- MAIN APPLICATION
addappid(321900)
-- Game: addappid(321900)

-- MAIN APP DEPOTS / PACKAGES
addappid(321901, 1, "d9b29268116d242974e6a54c1c9b6f9abc05dffe93685a9525a119574b6a7c12")
