-- Lua provided by SkyAPI 
-- Game: AppID 321900
addappid(321900)
addappid(321901, 1, "d9b29268116d242974e6a54c1c9b6f9abc05dffe93685a9525a119574b6a7c12")
