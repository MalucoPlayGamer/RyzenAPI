-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1831790)
-- Game: addappid(1831790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831792,0,"7499e86f7dc60361d90e67c1c1dd4c35d6a509d9d0fbccd81f71db1abfe8e29d")
