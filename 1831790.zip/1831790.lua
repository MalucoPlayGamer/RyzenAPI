-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1831790)
addappid(228988)
-- setManifestid(228988,"6645201662696499616")
addappid(228990)
-- setManifestid(228990,"1829726630299308803")
addappid(1831792,0,"7499e86f7dc60361d90e67c1c1dd4c35d6a509d9d0fbccd81f71db1abfe8e29d")
-- setManifestid(1831792,"8830016151677532946")