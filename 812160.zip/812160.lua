-- Lua provided by RyzenAPI 
-- Game: AppID 812160
addappid(812160)
addappid(812161, 1, "bdd5babe38bb6298873e03515466af501e440f7056fcc053937bb202d4b3c9c7")
