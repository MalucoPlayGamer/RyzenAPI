-- Lua provided by RyzenAPI
-- Game: Automon Arena

-- MAIN APP DEPOTS / PACKAGES
addappid(3810160, 1, "0b743cf356d038897751a61467b8e09debfb59310a0e3b911d471d50919722ec") -- Automon Arena
addappid(3810161, 1, "2c9a6e9eb4deace4cae9017dc84830b541caa60289f2157bd591c0a233577b95") -- Depot 3810161

