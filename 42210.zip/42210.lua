-- Lua provided by SkyAPI 
-- Game: AppID 42210
addappid(42210)
addappid(42211, 1, "8a51d659d9805b333d52177d935ff3852eb0122d261d27ca867e7fc1fec19f40")
addappid(42212, 1, "31a09da00558ea3dd283a5bf762c0b5af2e0b9f3cfdd5a149ef061dce9677fc5")
