-- 3340780's Lua and Manifest Created by Hubcap Manifest
-- Kungfu Card
-- Created: August 07, 2026 at 11:10:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3340780) -- Kungfu Card
addtoken(3340780, "15803435493257180962")
-- MAIN APP DEPOTS
addappid(3340781, 1, "f968e85b4f0169ec74042033c84f7c2fc3d97370f3cd39e37886d6e4d8eeebff") -- Depot 3340781
setManifestid(3340781, "7389749887813259316", 1215983105)