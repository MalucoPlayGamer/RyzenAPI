-- Lua provided by RyzenAPI
-- Game: Kungfu Card

-- MAIN APPLICATION
addappid(3340780) -- Kungfu Card

-- MAIN APP DEPOTS / PACKAGES
addappid(3340781, 1, "f968e85b4f0169ec74042033c84f7c2fc3d97370f3cd39e37886d6e4d8eeebff") -- Depot 3340781
addtoken(3340780, "15803435493257180962")

