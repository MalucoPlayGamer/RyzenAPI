-- Lua provided by RyzenAPI
-- Game: Boobs VR 3

-- MAIN APPLICATION
addappid(1411390)
-- Game: addappid(1411390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411390,0,"bcd2175f8299e80960e6fb56c53c724340b91742cf14e28654961536043cb0e3")
