-- Lua provided by RyzenAPI
-- Game: 1538670

-- MAIN APPLICATION
addappid(1538670)
-- Game: addappid(1538670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538671, 1, "50c7f8cbc6b83c288d4b4f4a786b8288f6de12bec5eca63e554d71adbe02ad00")
