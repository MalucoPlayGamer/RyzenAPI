-- Lua provided by RyzenAPI
-- Game: UAL: Universal AIM League

-- MAIN APPLICATION
addappid(1538670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538671, 1, "50c7f8cbc6b83c288d4b4f4a786b8288f6de12bec5eca63e554d71adbe02ad00")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
