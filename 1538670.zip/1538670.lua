-- Lua provided by SkyAPI 
-- Game: UAL: Universal AIM League
addappid(1538670)
addappid(1538671, 1, "50c7f8cbc6b83c288d4b4f4a786b8288f6de12bec5eca63e554d71adbe02ad00")
