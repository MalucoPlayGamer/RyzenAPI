-- Lua provided by SkyAPI 
-- Game: VR Escape From Jurassic Island
addappid(2403090)
addappid(2403091, 1, "a3a8e7ab56512857da80e22f4e79169991bcdb1db12c8a93b7f43e9fdce15e93")
