-- Lua provided by RyzenAPI
-- Game: VR Escape From Jurassic Island

-- MAIN APPLICATION
addappid(2403090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2403091, 1, "a3a8e7ab56512857da80e22f4e79169991bcdb1db12c8a93b7f43e9fdce15e93")

