-- Lua provided by RyzenAPI
-- Game: Bean and Nothingness

-- MAIN APPLICATION
addappid(1706090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1706091, 1, "390e802efe9a403ae5a108f53b980d57e8ced3bcc928cd8cc116701ef0f090ab")
addappid(1706093, 1, "84e2c83fe61ab429873693c1c5e489e214eb57b82f76a48da98ca1c8e7b40b9e")

