-- Lua provided by RyzenAPI
-- Game: addappid(1706090)

-- MAIN APPLICATION
addappid(1706090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706091, 1, "390e802efe9a403ae5a108f53b980d57e8ced3bcc928cd8cc116701ef0f090ab")
addappid(1706093, 1, "84e2c83fe61ab429873693c1c5e489e214eb57b82f76a48da98ca1c8e7b40b9e")
