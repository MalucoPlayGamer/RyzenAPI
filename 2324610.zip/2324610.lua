-- Lua provided by RyzenAPI
-- Game: Xanthiom Zero

-- MAIN APPLICATION
addappid(2324610)
-- Game: addappid(2324610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324613,0,"d41caa5b9432539cb045050a190008c8ba7d8298508e078179f975d74cfcd6a8")
