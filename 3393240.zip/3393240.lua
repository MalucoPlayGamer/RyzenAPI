-- Lua provided by RyzenAPI
-- Game: Banker Simulator

-- MAIN APPLICATION
addappid(3393240)
addappid(4040350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3393241, 1, "e7777dcbe56e62de2f413ac181261293609289fbbb8f749ca35f23e5590a437f")

