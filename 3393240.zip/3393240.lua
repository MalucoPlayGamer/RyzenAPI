-- Lua provided by RyzenAPI
-- Game: addappid(3393240)

-- MAIN APPLICATION
addappid(3393240)
addappid(4040350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3393241, 1, "e7777dcbe56e62de2f413ac181261293609289fbbb8f749ca35f23e5590a437f")
