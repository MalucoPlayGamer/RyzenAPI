-- Lua provided by RyzenAPI 
-- Game: SAHUR: Escape Together
addappid(3736520)
addappid(3736521, 1, "313517f3bb6cc87e48bf2c575d03812fd43e8d611d62013b6777053e9db009d6")
