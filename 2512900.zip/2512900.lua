-- Lua provided by RyzenAPI
-- Game: 2512900

-- MAIN APPLICATION
addappid(2512900)
-- Game: addappid(2512900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2512901, 1, "fdc88fe5f0c6e0ef1c62e10d632e6d0fb4843f052f2f4a009d245e41d2ebf022")
