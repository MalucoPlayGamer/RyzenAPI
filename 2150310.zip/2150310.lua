-- Lua provided by RyzenAPI
-- Game: 元素召唤 Summon Elemental

-- MAIN APPLICATION
addappid(2150310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2150311, 1, "db66d9d099baa1cae6283c03f199caf28330a3088150128ead36548f45f17f4f")
