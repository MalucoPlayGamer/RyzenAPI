-- Lua provided by RyzenAPI
-- Game: 2532200

-- MAIN APPLICATION
addappid(2532200)
-- Game: addappid(2532200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2532201, 1, "4331e1f04b928da9fb95dc35dec0bf5f9b9e6d85d3c044f8a0b6fff9876aad97")
