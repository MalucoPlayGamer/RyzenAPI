-- Lua provided by RyzenAPI
-- Game: AppID 527280

-- MAIN APPLICATION
addappid(527280)

-- MAIN APP DEPOTS / PACKAGES
addappid(527281, 1, "5874565f1aad1d3c4d38e42e58dee98f8265cb28351ace2c3cab18528ce225b3")
