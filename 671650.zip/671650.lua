-- Lua provided by RyzenAPI
-- Game: Game: AppID 671650

-- MAIN APPLICATION
addappid(671650)
-- Game: addappid(671650)

-- MAIN APP DEPOTS / PACKAGES
addappid(671651, 1, "69b704164a599500d027889132ab06a1d941eb228f6266a6794c2519459cebcb")
