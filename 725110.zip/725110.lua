-- Lua provided by RyzenAPI
-- Game: Wizards Tourney

-- MAIN APPLICATION
addappid(725110)

-- MAIN APP DEPOTS / PACKAGES
addappid(725111, 1, "269c55bf94dfa4f2ccfe68167da838a4d4a837e253bc62cf2236a2795e5b6397")

