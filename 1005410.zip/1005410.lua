-- Lua provided by RyzenAPI
-- Game: Freedom Finger

-- MAIN APPLICATION
addappid(1005410)
-- Game: addappid(1005410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005411, 1, "11df4467450980dd4faabfbb4010b912a123bcf2b98ca4f5aa9c2e6721dbcc18")
addappid(1005412, 1, "3933d01db33b50c2e32e9d7b173cbf6917a22f718bc75b5f0eaebd9057eafb08")
