-- Lua provided by RyzenAPI
-- Game: 1368640

-- MAIN APPLICATION
addappid(1368640)
-- Game: addappid(1368640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1368641, 1, "30c53854c2c3938b9f18eae179ab9c554c6d9ab90558f9cc7e322bba2aaa4187")
