-- Lua provided by RyzenAPI
-- Game: TCG Master Trader

-- MAIN APPLICATION
addappid(3301740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3301741, 1, "a4d4d0d3c4a84b69eb59a26136d2616d4ec82d4f383561056a8b46cf2030c143")
