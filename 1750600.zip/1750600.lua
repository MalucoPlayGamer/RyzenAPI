-- Lua provided by RyzenAPI
-- Game: Game: Crate Mates

-- MAIN APPLICATION
addappid(1750600)
-- Game: addappid(1750600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750601, 1, "835ce986865ed15ef010788cad05b7dc6bcbd342cb7870c815dbf1c84a8f7fe8")
