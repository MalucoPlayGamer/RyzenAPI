-- Lua provided by RyzenAPI 
-- Game: Crate Mates
addappid(1750600)
addappid(1750601, 1, "835ce986865ed15ef010788cad05b7dc6bcbd342cb7870c815dbf1c84a8f7fe8")
