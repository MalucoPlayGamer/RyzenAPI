-- Lua provided by RyzenAPI
-- Game: Unearth

-- MAIN APPLICATION
addappid(2487930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487931, 1, "50ab85563ae5cb17cd6b8dbf58371f34f57618e279b85aab1a97641910ed1e82")

