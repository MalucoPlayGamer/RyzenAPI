-- Lua provided by RyzenAPI
-- Game: Master Arena Editor

-- MAIN APPLICATION
addappid(1865620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1865621, 1, "586cf79eae72c83a738e45d7dd565630818018ba315e416326595d607966d6aa")

