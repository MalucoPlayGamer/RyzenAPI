-- Lua provided by RyzenAPI
-- Game: Gods and Idols

-- MAIN APPLICATION
addappid(423890)

-- MAIN APP DEPOTS / PACKAGES
addappid(423891, 1, "4ea81c25785028bfe6482bebce93d932d8372bb7bffe47d6f250a5399f34b2b3")
