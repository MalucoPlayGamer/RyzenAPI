-- Lua provided by RyzenAPI
-- Game: Gods and Idols

-- MAIN APPLICATION
addappid(423890)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(423891, 1, "4ea81c25785028bfe6482bebce93d932d8372bb7bffe47d6f250a5399f34b2b3")

