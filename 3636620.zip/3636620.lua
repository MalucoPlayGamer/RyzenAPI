-- Lua provided by RyzenAPI
-- Game: AppID 3636620

-- MAIN APPLICATION
addappid(3636620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3636621, 1, "8ff3bccdcf016ea3cb6eea0dccb210a9c26d31f077a09c1535d77c8c7bac4218")

