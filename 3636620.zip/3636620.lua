-- Lua provided by RyzenAPI
-- Game: AppID 3636620

-- MAIN APPLICATION
addappid(3636620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3636621, 1, "8ff3bccdcf016ea3cb6eea0dccb210a9c26d31f077a09c1535d77c8c7bac4218")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
