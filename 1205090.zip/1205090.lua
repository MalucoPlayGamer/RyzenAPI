-- Lua provided by RyzenAPI
-- Game: addappid(1205090)

-- MAIN APPLICATION
addappid(1205090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205091, 1, "ef2fa770c97ada8eeb589a6a4cbb8af85aca513a993218d33597793b07de25cf")
addappid(1205093, 1, "6ce9ab6fd2cd6a5fa985c852a7afa2ee25f02e428ee4daf34ae97643224b4d0f")
addappid(1205094, 1, "5a50c4f4e354d0297c853b1b28fa186fd5024662d78f08fd1ced05898b589c38")
addappid(1205095, 1, "cfa1fde76ffeded2cee5572cb0dcc848c6df382ccc37e06631cd057ab9f6953f")
