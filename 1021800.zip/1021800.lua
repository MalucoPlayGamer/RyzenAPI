-- Lua provided by RyzenAPI
-- Game: 妙连千军 Million Dungeon

-- MAIN APPLICATION
addappid(1021800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1021801, 1, "4a02a4558558d3009fc80414a8153284d194bb87e23dc097a6bf956793b6349b")
