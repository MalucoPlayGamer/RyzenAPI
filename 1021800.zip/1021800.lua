-- Lua provided by SkyAPI 
-- Game: AppID 1021800
addappid(1021800)
addappid(1021801, 1, "4a02a4558558d3009fc80414a8153284d194bb87e23dc097a6bf956793b6349b")
