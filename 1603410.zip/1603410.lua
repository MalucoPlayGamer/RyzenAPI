-- Lua provided by RyzenAPI 
-- Game: Lost Nova
addappid(1603410)
addappid(1603411, 1, "108da561d4fdefa71145d831c2828d356766c0ffd48e727c243319f96f7ed57e")
