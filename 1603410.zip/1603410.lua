-- Lua provided by RyzenAPI
-- Game: Lost Nova

-- MAIN APPLICATION
addappid(1603410)
-- Game: addappid(1603410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1603411, 1, "108da561d4fdefa71145d831c2828d356766c0ffd48e727c243319f96f7ed57e")
