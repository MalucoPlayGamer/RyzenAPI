-- Lua provided by RyzenAPI
-- Game: Game: AppID 872350

-- MAIN APPLICATION
addappid(872350)
-- Game: addappid(872350)

-- MAIN APP DEPOTS / PACKAGES
addappid(872351, 1, "a43e937b1ce69da8c29ded55d68aa960bf99e1b0f3db584e4b44ba3e54b01546")
