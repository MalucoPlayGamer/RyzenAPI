-- Lua provided by RyzenAPI
-- Game: Game: Endless Life

-- MAIN APPLICATION
addappid(3206480)
-- Game: addappid(3206480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3206481, 1, "ece562f47f57dd27fdaacb848453c8d1340d90f330ae385dfb027f804cc67cab")
