-- Lua provided by RyzenAPI
-- Game: Game: Our Mountain

-- MAIN APPLICATION
addappid(1668990)
-- Game: addappid(1668990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668991, 1, "fb77b3e63eaeb6cd1da0feeb81c95e5835fff468f7c53bcc3692fed649c7fb98")
