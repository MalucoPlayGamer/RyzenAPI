-- Lua provided by RyzenAPI
-- Game: Our Mountain

-- MAIN APPLICATION
addappid(1668990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668991, 1, "fb77b3e63eaeb6cd1da0feeb81c95e5835fff468f7c53bcc3692fed649c7fb98")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
