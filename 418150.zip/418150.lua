-- Lua provided by RyzenAPI
-- Game: Game: The Madness of Little Emma

-- MAIN APPLICATION
addappid(418150)
-- Game: addappid(418150)

-- MAIN APP DEPOTS / PACKAGES
addappid(418151, 1, "49a82dcc23238664d9213abb529de04ef47e744995bc2de7544920e51c0ac4e1")
addappid(418152, 1, "ad792eb969386a97656e41207db5ddf01a325d3e0962c36fea515bf2153e7ce7")
addappid(418153, 1, "1df19c461a04194e4f138063821612408ad3b0b5d594e4e00674de36d7d5c0a7")
addappid(418154, 1, "e9368e8a54656dfbdaaa3b16a81950a7b3098d09be88c53e40f736eb1a904725")
