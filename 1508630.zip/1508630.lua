-- Lua provided by RyzenAPI
-- Game: Star Melody Yumemi Dreamer

-- MAIN APPLICATION
addappid(1508630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508631, 1, "c036b32a961a7ee691a6fc5f1d884549502cb1a4ab6731e219d93bd7824d2c63")
addappid(1508632, 1, "984c24a52809649a2dd3bb1477146245291f3f363b8db590c409519e30312a24")
addappid(1508633, 1, "5ae04d06e00dc5c8e272c7cc58325cf95be59e8f5a56174b19b8e32f2a9a2887")
addappid(1508634, 1, "97fe5526727f118fe8400e90f4526852a65d8b776cbbcf2c559bd9c6979bcfc0")
addappid(1508635, 1, "90d29fb86254e88a2bb8b96f17df6af8f613a698d4ef3f27d2bd5843f8f5f15e")
addappid(1508636, 1, "b7051b3bd9277e9dfd8a9a0280ed17d43972d2ff8041cf9db1c88f674fcab243")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1711760)
addappid(1711761)
addappid(1711762)
addappid(1796860)
addappid(1796940)
addappid(1796941)
addappid(1796942)
addappid(1796943)
addappid(1796944)
addappid(1796945)
addappid(1796946)
addappid(1797030)
