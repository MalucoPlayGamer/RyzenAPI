-- Lua provided by RyzenAPI
-- Game: 1260800

-- MAIN APPLICATION
addappid(1260800)
-- Game: addappid(1260800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260801, 1, "0a7b6a7773742efdd35452d4f80296a352b7c1d9b53bbb572cfff20592baa099")
