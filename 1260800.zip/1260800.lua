-- Lua provided by SkyAPI 
-- Game: Rocking Legend
addappid(1260800)
addappid(1260801, 1, "0a7b6a7773742efdd35452d4f80296a352b7c1d9b53bbb572cfff20592baa099")
