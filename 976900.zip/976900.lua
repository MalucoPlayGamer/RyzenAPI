-- Lua provided by RyzenAPI
-- Game: Lumberhill

-- MAIN APPLICATION
addappid(976900)
addappid(1649050)
addappid(1697490)

-- MAIN APP DEPOTS / PACKAGES
addappid(976901,0,"408239eadd755b2f8382adaa4c3567f476f0146eda366a838613eb322914917a")

