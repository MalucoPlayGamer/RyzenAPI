-- Lua provided by RyzenAPI
-- Game: 976900

-- MAIN APPLICATION
addappid(976900)
-- Game: addappid(976900)

-- MAIN APP DEPOTS / PACKAGES
addappid(976901, 1, "408239eadd755b2f8382adaa4c3567f476f0146eda366a838613eb322914917a")
