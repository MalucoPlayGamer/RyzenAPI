-- Lua provided by RyzenAPI
-- Game: VR Dinosaur Village

-- MAIN APPLICATION
addappid(2516750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516751, 1, "f10a371f59ca3c85829c8708160b528aee20a25c23d807dcc2989de7b36efe40")

