-- Lua provided by RyzenAPI 
-- Game: Love Is All Around Demo
addappid(2325870)
addappid(2325871, 1, "cff24b3be44cf979927cf5104dbd3a4c9053fe91b012f35d8638afc366641ad5")
