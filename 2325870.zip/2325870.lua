-- Lua provided by RyzenAPI
-- Game: Game: Love Is All Around Demo

-- MAIN APPLICATION
addappid(2325870)
-- Game: addappid(2325870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2325871, 1, "cff24b3be44cf979927cf5104dbd3a4c9053fe91b012f35d8638afc366641ad5")
