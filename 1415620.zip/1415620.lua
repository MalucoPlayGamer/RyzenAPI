-- Lua provided by RyzenAPI
-- Game: Sudoku Forever

-- MAIN APPLICATION
addappid(1415620)
-- Game: addappid(1415620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1415621, 1, "0ce57630fc059d9e36436af33d6b6862c4e063f0dc88ad3bb3207ddabc905977")
