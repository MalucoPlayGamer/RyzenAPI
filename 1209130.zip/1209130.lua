-- Lua provided by RyzenAPI
-- Game: Beat Saber - Green Day - "American Idiot"

-- MAIN APPLICATION
addappid(1209130)
-- Game: addappid(1209130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209130,0,"01676922ef24740225c6f001c904293e069f540c54fb2c6ebdf45ac4e8bd6194")
