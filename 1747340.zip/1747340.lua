-- Lua provided by RyzenAPI
-- Game: Hentai Girls Sliding Puzzle

-- MAIN APPLICATION
addappid(1747340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747341, 1, "01e91796caaa26e74e667e453ec6c53bd42645f85130cdf7e6988e37714a1fea")
addappid(1747780, 0, "ce418c19046a93c83cd4d0e8c6df6666961b77ce5b9e7b1a5e15629513804f2f")
