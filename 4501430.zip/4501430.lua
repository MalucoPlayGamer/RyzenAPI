-- Lua provided by RyzenAPI
-- Game: 8 Ball Pool: Play Together

-- MAIN APPLICATION
addappid(4501430) -- 8 Ball Pool: Play Together

-- MAIN APP DEPOTS / PACKAGES
addappid(4501431, 1, "4365cf6d4789e094f422f9c7384987e24e47a037d13574639cf85e99a56a1696") -- Depot 4501431

