-- Lua provided by RyzenAPI
-- Game: STORY OF SEASONS: Pioneers of Olive Town

-- MAIN APPLICATION
addappid(1392960)
addappid(1567290)
addappid(1567291)
addappid(1567292)
addappid(1567293)
addappid(1567294)
addappid(1692490)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1392961, 1, "7929038c4f0eecc945a4c729b402a052d67647fe9b5ebf6a8a9e62900ad0d621")
addappid(1392962, 1, "59af10455ece1d3b11e9be890adf7127588ed728d20a8a62763ec27a6b513598")

