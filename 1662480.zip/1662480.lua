-- Lua provided by RyzenAPI
-- Game: Game: Nuclear Blaze

-- MAIN APPLICATION
addappid(1662480)
-- Game: addappid(1662480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662481, 1, "d9740aa964949e62db32ff6db4ead98f9ec2507079b980d497e26e1a1a5b8861")
