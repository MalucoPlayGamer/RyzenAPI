-- Lua provided by RyzenAPI
-- Game: Kaz's Adventure

-- MAIN APPLICATION
addappid(2013680)
addappid(2013710)
addappid(2013712)
addappid(2019970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2013681, 1, "004babfa7e1b7f0f36744f696bf2777189605065c43debf2c564af6150e7e23f")
