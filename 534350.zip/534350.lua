-- Lua provided by RyzenAPI
-- Game: Ancient Rome 2

-- MAIN APPLICATION
addappid(534350)

-- MAIN APP DEPOTS / PACKAGES
addappid(534351,0,"e41653d399fff7f5bddd4fc8d5c545764b9edbf27c8b042506358eb0d1edf5f1")

