-- Lua provided by RyzenAPI
-- Game: Shadowbane: Resurgence

-- MAIN APPLICATION
addappid(4371680)

