-- Lua provided by RyzenAPI
-- Game: Graveyard Architect

-- MAIN APPLICATION
addappid(2133530)
-- Game: addappid(2133530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2133531, 1, "64b8b962b6f05f15c82ae3b585cd3e5b9a57fcbf8d48a76b768ac67a8ae4264d")
