-- Lua provided by RyzenAPI
-- Game: Exploding Judo Federation

-- MAIN APPLICATION
addappid(3806150)
