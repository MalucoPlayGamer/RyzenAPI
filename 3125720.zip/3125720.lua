-- Lua provided by RyzenAPI
-- Game: addappid(3125720)

-- MAIN APPLICATION
addappid(3125720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3125721, 1, "ca4908b6fe641cedb7edda95cb171d67f6dbd060f2560d6eb1f04b801a733b94")
