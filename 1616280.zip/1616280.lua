-- Lua provided by RyzenAPI
-- Game: Chronicles of Taldun: The Remainder

-- MAIN APPLICATION
addappid(1616280)
addappid(3337570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1616281, 1, "843232b3b792add06daf6c723648aead052b47a7714bc654072fd9dbdca30729")

