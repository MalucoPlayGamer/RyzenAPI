-- Lua provided by RyzenAPI
-- Game: 3DC

-- MAIN APPLICATION
addappid(2659230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2659231, 1, "2eb21a54b836e0e5396ea433cb94cc61dde8b37b440bb09c8c82a39c8598db68")