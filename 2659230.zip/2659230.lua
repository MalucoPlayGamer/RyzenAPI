-- Lua provided by RyzenAPI
-- Game: Game: 3DC

-- MAIN APPLICATION
addappid(2659230)
-- Game: addappid(2659230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2659231, 1, "2eb21a54b836e0e5396ea433cb94cc61dde8b37b440bb09c8c82a39c8598db68")
