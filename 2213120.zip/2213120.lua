-- Lua provided by RyzenAPI
-- Game: While We Wait Here

-- MAIN APPLICATION
addappid(2213120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2213121, 1, "2b5250d4744cd9b9620ef146c7723389f7b9f36ae44e2a234d6a846d14956812")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
