-- Lua provided by RyzenAPI
-- Game: While We Wait Here

-- MAIN APPLICATION
addappid(2213120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2213121, 1, "2b5250d4744cd9b9620ef146c7723389f7b9f36ae44e2a234d6a846d14956812")
