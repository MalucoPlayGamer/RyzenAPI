-- Lua provided by RyzenAPI
-- Game: addappid(1623420)

-- MAIN APPLICATION
addappid(1623420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623421, 1, "32c30942f53410a05f8e1523db61a51f806eaa1789118cfd9c51e6707bce29af")
