-- Lua provided by RyzenAPI
-- Game: Sherlock Holmes: The Mystery of the Persian Carpet

-- MAIN APPLICATION
addappid(11180)

-- MAIN APP DEPOTS / PACKAGES
addappid(11181, 1, "5992f828692d14bd7d5347c8fb1e17d5b0164f3e82f22fd34da705b6bacb0036")
addappid(11182, 1, "b231d4879ce7bf77ad5384de633f7d7585eb52e7b2ec2cd66835e4429ca7a116")
addappid(11183, 1, "3b30842f8eca5db1aa064a219745dc73a46331813c1391f8ea02586dc0a93f4a")
addappid(11184, 1, "f80451c436c674cc8e4e92e245866be05049de3a0c92257188e4ac5ec56e8c1c")
addappid(11185, 1, "af69cd1167a93c815e824ccc736a5ead674f693048b387b2377590c26541f7a9")

