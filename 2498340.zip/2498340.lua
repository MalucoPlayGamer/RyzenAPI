-- Lua provided by RyzenAPI
-- Game: addappid(2498340)

-- MAIN APPLICATION
addappid(2498340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2498341, 1, "6a7ded6ca3c2f2f20642c6d84dd52353d3e8e11e0d12af6268eee59daf7ce84c")
