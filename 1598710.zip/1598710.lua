-- Lua provided by RyzenAPI
-- Game: Wild world

-- MAIN APPLICATION
addappid(1598710)
-- Game: addappid(1598710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598711, 1, "2e4cb622a482c5d3a3f4e984880a7775277cd599d7f4e58c21e60c2072e3c99d")
