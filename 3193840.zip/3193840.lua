-- Lua provided by RyzenAPI
-- Game: addappid(3193840)

-- MAIN APPLICATION
addappid(3193840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3193841, 1, "f2c67de2826ed98855a3e838bc11d3cb2f6b4b41fd41cfd1ba1ebc1cf810ffff")
