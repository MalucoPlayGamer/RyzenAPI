-- Lua provided by RyzenAPI
-- Game: addappid(2739750)

-- MAIN APPLICATION
addappid(2739750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739750,0,"407fee35bfeb5844cc182459de63ed919d90a87f353be66c7379c93a782537df")
