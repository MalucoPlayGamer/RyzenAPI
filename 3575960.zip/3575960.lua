-- Lua provided by RyzenAPI
-- Game: 3575960

-- MAIN APPLICATION
addappid(3575960)
-- Game: addappid(3575960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3575961, 1, "368f3c82f814e576ab371109575bbc19ec32374c10eee83ab05ef87bbc9bd571")
