-- Lua provided by RyzenAPI
-- Game: Zombie Solitaire

-- MAIN APPLICATION
addappid(311850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(311851, 1, "d0fe947895d01be25faaaf4f47ff5145c29792e76c9e39df2180dbd4f669f888")

