-- Lua provided by RyzenAPI 
-- Game: Zombie Solitaire
addappid(311850)
addappid(311851, 1, "d0fe947895d01be25faaaf4f47ff5145c29792e76c9e39df2180dbd4f669f888")
