-- Lua provided by RyzenAPI
-- Game: Fishing Paradiso Demo

-- MAIN APPLICATION
addappid(1895620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895621, 1, "cf57101327c2a3f3a9a826cd14b639089fdf9db4ed451c6cfc09b18e0557ee6e")
