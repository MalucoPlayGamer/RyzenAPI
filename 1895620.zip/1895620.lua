-- Lua provided by RyzenAPI 
-- Game: Fishing Paradiso Demo
addappid(1895620)
addappid(1895621, 1, "cf57101327c2a3f3a9a826cd14b639089fdf9db4ed451c6cfc09b18e0557ee6e")
