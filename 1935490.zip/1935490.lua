-- Lua provided by RyzenAPI
-- Game: Fluffy Milo

-- MAIN APPLICATION
addappid(1935490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1935491, 1, "7f2d00cefa276eed56381f1ab13551bc8ba804c72b094966e4f42604c3a40b5e")

