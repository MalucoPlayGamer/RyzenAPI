-- Lua provided by SkyAPI 
-- Game: 畜神
addappid(3381310)
addappid(3381311, 1, "5d0d5378be1cb65268c9f13d5efaaa8f93285e3156ce95aecc999672ab34b68e")
