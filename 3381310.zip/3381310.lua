-- Lua provided by RyzenAPI
-- Game: 畜神

-- MAIN APPLICATION
addappid(3381310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3381311, 1, "5d0d5378be1cb65268c9f13d5efaaa8f93285e3156ce95aecc999672ab34b68e")
