-- Lua provided by RyzenAPI
-- Game: Z-Collapse

-- MAIN APPLICATION
addappid(1804500)
-- Game: addappid(1804500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1804501, 1, "97fc1615c880b7a2cf582708bed8be41d5222246448e69702f40373722266967")
