-- Lua provided by RyzenAPI
-- Game: Three Twenty One

-- MAIN APPLICATION
addappid(646960)
-- Game: addappid(646960)

-- MAIN APP DEPOTS / PACKAGES
addappid(646961, 1, "1d1005bcab86b726a25528ecb355c76f5b266aa37d8f469f5e096269104c7e7b")
addappid(646962, 1, "576f2bfcacf160df9ad9afa440d1d268880e2ca04285d2f78f445f91087c46fb")
addappid(646963, 1, "ebf5b4ffa5623a26d56802336b13caca8f9613341bffc07c20c5e4b985648834")
