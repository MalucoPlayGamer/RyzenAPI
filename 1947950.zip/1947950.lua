-- Lua provided by RyzenAPI
-- Game: 1947950

-- MAIN APPLICATION
addappid(1947950)
-- Game: addappid(1947950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1947951, 1, "b30454da0f1e89f72d6c6a0e151353a3a7662cfbf6ec8196f316d205da420242")
