-- Lua provided by RyzenAPI
-- Game: BUSTAFELLOWS

-- MAIN APPLICATION
addappid(1494470)
-- Game: addappid(1494470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494471, 1, "512a95fa53d23d5b0b42223d63f3311ebdb055bcd5b3b32d54137ff4938fcb9b")
