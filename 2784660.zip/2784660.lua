-- Lua provided by RyzenAPI
-- Game: 2784660

-- MAIN APPLICATION
addappid(2784660)
-- Game: addappid(2784660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2784661, 1, "02fb1cf8c3b632b3a400a706cdbe12ddf64ccd51744f946a0865607af1abebcd")
