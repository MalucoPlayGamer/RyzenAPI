-- Lua provided by RyzenAPI
-- Game: Glow Chess

-- MAIN APPLICATION
addappid(908950)

-- MAIN APP DEPOTS / PACKAGES
addappid(908951, 1, "7df7abd463d889ee735e3a896420bc2c6400520bcdf37bc7084f652e88c07b1d")

