-- Lua provided by RyzenAPI
-- Game: Subspace Discovery

-- MAIN APPLICATION
addappid(1717290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717291, 1, "2cf1fb5e8a1285ef1625451638adfe90ad2cafb5dd74d92891ca94c7afeed6da")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
