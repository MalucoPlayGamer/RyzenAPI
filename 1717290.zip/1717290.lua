-- Lua provided by SkyAPI 
-- Game: Subspace Discovery
addappid(1717290)
addappid(1717291, 1, "2cf1fb5e8a1285ef1625451638adfe90ad2cafb5dd74d92891ca94c7afeed6da")
