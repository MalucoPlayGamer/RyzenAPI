-- Lua provided by RyzenAPI
-- Game: Subspace Discovery

-- MAIN APPLICATION
addappid(1717290)
-- Game: addappid(1717290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717291, 1, "2cf1fb5e8a1285ef1625451638adfe90ad2cafb5dd74d92891ca94c7afeed6da")
