-- Lua provided by RyzenAPI
-- Game: setManifestid(2981692,"6248001045030636666")

-- MAIN APPLICATION
addappid(2981690)
-- Game: addappid(2981690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2981692,0,"9dcda47dc9a7341544651e85c3faadff3adf0a276ada76f93d282019e59e945d")
