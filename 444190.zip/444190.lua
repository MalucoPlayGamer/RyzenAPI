-- Lua provided by RyzenAPI
-- Game: 444190

-- MAIN APPLICATION
addappid(444190)
-- Game: addappid(444190)

-- MAIN APP DEPOTS / PACKAGES
addappid(444191, 1, "5a58c11a3e634e013fbd6eef40eebed284786a73e60e83f32501df7082a41132")
