-- Lua provided by RyzenAPI
-- Game: 743940

-- MAIN APPLICATION
addappid(743940)
-- Game: addappid(743940)

-- MAIN APP DEPOTS / PACKAGES
addappid(743941, 1, "8f162ec23be299afb6af170d1696d3b7c0467206ac2ee3c97ce297973d1b6599")
