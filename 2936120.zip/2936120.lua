-- Lua provided by RyzenAPI
-- Game: Game: Marvel Rivals Playtest

-- MAIN APPLICATION
addappid(2936120)
-- Game: addappid(2936120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2936121, 1, "18a987581c317990ab846b8673b8d8c769623e1bcd951551f14b3e15cb374574")
