-- Lua provided by RyzenAPI
-- Game: AppID 598060

-- MAIN APPLICATION
addappid(598060)

-- MAIN APP DEPOTS / PACKAGES
addappid(598061, 1, "ed396032e1a877167485cdbae547cb6ddb37b672e7026e3577aa08e61f4e10e5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
