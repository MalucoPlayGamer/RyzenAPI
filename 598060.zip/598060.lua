-- Lua provided by RyzenAPI
-- Game: addappid(598060)

-- MAIN APPLICATION
addappid(598060)

-- MAIN APP DEPOTS / PACKAGES
addappid(598061, 1, "ed396032e1a877167485cdbae547cb6ddb37b672e7026e3577aa08e61f4e10e5")
