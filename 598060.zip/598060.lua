-- Lua provided by SkyAPI 
-- Game: AppID 598060
addappid(598060)
addappid(598061, 1, "ed396032e1a877167485cdbae547cb6ddb37b672e7026e3577aa08e61f4e10e5")
