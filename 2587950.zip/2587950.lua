-- Lua provided by RyzenAPI
-- Game: 2587950

-- MAIN APPLICATION
addappid(2587950)
-- Game: addappid(2587950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2587951, 1, "9cb3a0bba649f614883e6d9c67d6da6199bd69e5e4329addb3306b84b65e4242")
