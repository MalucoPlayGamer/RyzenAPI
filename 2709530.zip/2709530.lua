-- Lua provided by RyzenAPI
-- Game: Mechanical Lab

-- MAIN APPLICATION
addappid(2709530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2709531, 1, "3a3719259c00533cd1ad2816207f351625c65fbc16f961afa447d60c951a31c5")
