-- Lua provided by RyzenAPI
-- Game: ZomB: Battlegrounds

-- MAIN APPLICATION
addappid(1114020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114021, 1, "700b2d4f641a2c15d15ac96ea7e0281747658de3a25af8c59ec3f78591daefc3")
addappid(1114022, 1, "5a9244d6157a362cd97d209d7dc01a9ba60930d4e595273c4befbd17bbf5ac60")
