-- Lua provided by SkyAPI 
-- Game: Great Deceiver
addappid(2060000)
addappid(2060001, 1, "2927ef070b1a04bd0206946549389598d674e3eb5428599cd0523613ca38a4b5")
