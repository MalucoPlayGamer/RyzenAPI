-- Lua provided by RyzenAPI
-- Game: Game: Great Deceiver

-- MAIN APPLICATION
addappid(2060000)
-- Game: addappid(2060000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060001, 1, "2927ef070b1a04bd0206946549389598d674e3eb5428599cd0523613ca38a4b5")
