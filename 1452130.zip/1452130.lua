-- Lua provided by RyzenAPI
-- Game: My Jigsaw Adventures - Forgotten Destiny

-- MAIN APPLICATION
addappid(1452130)
-- Game: addappid(1452130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1452131, 1, "054d13d4867bbd4d4359ac5c7c07c862a09590b91d368e52415fe4310c506058")
