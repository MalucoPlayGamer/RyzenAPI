-- Lua provided by RyzenAPI
-- Game: Game: Data mining X

-- MAIN APPLICATION
addappid(1373410)
-- Game: addappid(1373410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1373411, 1, "d80a026a47172a086341fe51b3fb059e28978aae70e075404ce82e4ca7b66576")
