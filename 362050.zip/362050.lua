-- Lua provided by RyzenAPI
-- Game: addappid(362050)

-- MAIN APPLICATION
addappid(362050)

-- MAIN APP DEPOTS / PACKAGES
addappid(362051, 1, "607a2a1864df8b19a575da267416e8f755ad2b1af1b0bd49490de9bcc58c8559")
