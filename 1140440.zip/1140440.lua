-- Lua provided by RyzenAPI
-- Game: OMON Simulator

-- MAIN APPLICATION
addappid(1140440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140441, 1, "5543534b8abadbdbafa82b1ce1812ec8a80cd8da2f1b123e30bfd0bac2426cdb")
addappid(1140442, 1, "b3988670445b0a040780a75408485c111a73ee1333c6c649de7d0d213f9635af")
addappid(1140443, 1, "a4d510ed2b252efd6155758cbcf9cd637e32a25dc2e796f82a247fe11393311c")
addappid(1140444, 1, "08d206dfac473b4955d6bb8c0ae4a660fbb6ce4aacfe2307fcf1491f7378a7a5")
