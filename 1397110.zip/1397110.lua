-- Lua provided by RyzenAPI 
-- Game: AppID 1397110
addappid(1397110)
addappid(1397111, 1, "b38dcab918b2d18012189412825dd7dea3739377bf76819e0a575c4c36e1a80c")
