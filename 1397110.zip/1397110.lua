-- Lua provided by RyzenAPI
-- Game: addappid(1397110)

-- MAIN APPLICATION
addappid(1397110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397111, 1, "b38dcab918b2d18012189412825dd7dea3739377bf76819e0a575c4c36e1a80c")
