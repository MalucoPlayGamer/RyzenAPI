-- Lua provided by RyzenAPI
-- Game: 811460

-- MAIN APPLICATION
addappid(811460)
-- Game: addappid(811460)

-- MAIN APP DEPOTS / PACKAGES
addappid(811460,0,"b349c2dd357f9c15aa26502e079d126ce40e98b78f04b9c843f3b4027811aeee")
