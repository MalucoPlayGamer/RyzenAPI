-- Lua provided by RyzenAPI
-- Game: AppID 2942790

-- MAIN APPLICATION
addappid(2942790)
-- Game: addappid(2942790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2942791, 1, "fd7ffbd31eb15171e7f550ff9fa8e48e4c695ac028841536a536640954a0a0e6")
