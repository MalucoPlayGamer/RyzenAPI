-- Lua provided by RyzenAPI
-- Game: 1505540

-- MAIN APPLICATION
addappid(1505540)
-- Game: addappid(1505540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1505541, 1, "687d779692177e7f561fc66e542ddbf01ee7a0b4a60597db53c73c6f2a3fe2cd")
