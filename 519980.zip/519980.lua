-- Lua provided by RyzenAPI
-- Game: 519980

-- MAIN APPLICATION
addappid(519980)
-- Game: addappid(519980)

-- MAIN APP DEPOTS / PACKAGES
addappid(519981, 1, "6a0be41074176fe6bd82314c7bb59ad7e0028cbc27be120e78e7174615e874b3")
