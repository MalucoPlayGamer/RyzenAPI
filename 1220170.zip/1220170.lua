-- Lua provided by RyzenAPI
-- Game: Game: AppID 1220170

-- MAIN APPLICATION
addappid(1220170)
-- Game: addappid(1220170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220171, 1, "9131a0177540f64715ca9a02f13640c81d5f0c8253f9eb8ec079a57c50c2ac60")
