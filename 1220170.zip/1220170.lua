-- Lua provided by RyzenAPI
-- Game: Eville

-- MAIN APPLICATION
addappid(1220170)
addappid(1887850)
addappid(1936260)
addappid(2089400)
addappid(2109250)
addappid(2178200)
addappid(2223890)
addappid(2243640)
addappid(2243641)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1220171, 1, "9131a0177540f64715ca9a02f13640c81d5f0c8253f9eb8ec079a57c50c2ac60")

