-- Lua provided by RyzenAPI
-- Game: STAR WARS™: The Old Republic™

-- MAIN APPLICATION
addappid(1286830)
addappid(1303600)
addappid(1303605)
addappid(1303891)
addappid(1333220)
addappid(1346540)
addappid(1346541)
addappid(2550190)
addappid(3076010)
addappid(3076020)
addappid(3076030)
addappid(4005010)
addappid(4023370)
addappid(4023380)
addappid(4029110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1286831, 1, "5f441ab499a56229f41d6a145429972e63e773be8f3028defce3e15cd0d2c397")
addappid(1286833, 1, "0dc81a7e097e5bcaa2befe6feca6001c8b4e7ec674d5e5faeae16a1d720c6e05")
addappid(1286834, 1, "14b0eb51cb078a993b393e640b71ca12dc5a1b8bb53b9423259e67a2963f374a")
addappid(1286835, 1, "3dff041725d43f20ec9fc52b005a9c94193a7076ad086dd58d989fceb4f8c717")
addappid(1286836, 1, "b21b5ef05d644660d0c7ad11d5390622abd8a6513a7efa65da7f6ef07421f1d8")
