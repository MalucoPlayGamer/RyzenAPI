-- Lua provided by SkyAPI 
-- Game: Demonologist Demo
addappid(2302560)
addappid(2302561, 1, "cc8238b6ba66c637be55f12ab5dedeb0bd1586273815f4a8ae3e1940f871f873")
