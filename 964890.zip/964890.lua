-- Lua provided by RyzenAPI
-- Game: Dream

-- MAIN APPLICATION
addappid(964890)

-- MAIN APP DEPOTS / PACKAGES
addappid(964891, 1, "b9c6bdb7ddda7762764f85e817d00348e981f8be4018eb0570ba9ac4c19160e7")

