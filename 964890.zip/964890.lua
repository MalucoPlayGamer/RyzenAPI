-- Lua provided by RyzenAPI
-- Game: Dream

-- MAIN APPLICATION
addappid(964890)

-- MAIN APP DEPOTS / PACKAGES
addappid(964891, 1, "b9c6bdb7ddda7762764f85e817d00348e981f8be4018eb0570ba9ac4c19160e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
