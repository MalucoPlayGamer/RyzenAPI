-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 Character EX Pack Cunning

-- MAIN APPLICATION
addappid(2750440)
-- Game: addappid(2750440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2750441, 1, "24b08b5f35320564030df6a30e133d4d6e6651183d1bf7cbfcf0c2c4658b603e")
