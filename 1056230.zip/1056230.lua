-- Lua provided by RyzenAPI
-- Game: 1056230

-- MAIN APPLICATION
addappid(1056230)
-- Game: addappid(1056230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056231, 1, "37de006b86681bcd87096d3d52549e2e4d990fc07eec978e95c6db8196af7c0c")
