-- Lua provided by RyzenAPI
-- Game: Medicinal Herbs - Cannabis Grow Simulator

-- MAIN APPLICATION
addappid(1056230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1056231, 1, "37de006b86681bcd87096d3d52549e2e4d990fc07eec978e95c6db8196af7c0c")
