-- Lua provided by RyzenAPI
-- Game: Game: AppID 1006090

-- MAIN APPLICATION
addappid(1006090)
-- Game: addappid(1006090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1006091, 1, "f8fe6be788e7f72888899d6520b6bb6ba2e78e1ced4aa210cae5b42fe8622d72")
