-- Lua provided by RyzenAPI
-- Game: 2114560

-- MAIN APPLICATION
addappid(2114560)
-- Game: addappid(2114560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2114560,0,"6d302a6bd95da65a309d7742dfb8309df06a28a6472b36a7c0e45b167a26c75e")
