-- Lua provided by RyzenAPI
-- Game: Shadow Warrior 2 - Soundtrack

-- MAIN APPLICATION
addappid(522333)

-- MAIN APP DEPOTS / PACKAGES
addappid(522333,0,"6cbfb537c2bf781d2d40c3b0d305a8c40cda348735cc36da33d33f99886b8000")

