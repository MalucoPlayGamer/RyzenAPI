-- Lua provided by RyzenAPI
-- Game: Ultimate Zombie Defense

-- MAIN APPLICATION
addappid(1035510)
addappid(1541180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1035511, 1, "d05be96444ff15c5832e70013a8be6af44289589e42af9ac0053f98bbd1ad1db")
addappid(1035512, 1, "003ac1422d954f302e49c429d6dd00761d4b9daceacbb009673d0dc3194352b5")
addappid(1035513, 1, "c15b805bd5c266bc3d03bac5ad226cb83b1f967e482876d878dd5e07bb793477")
addappid(1035514, 1, "e0a73c0062ba2757877662713d6b07f38eb5929cfcc2f41c6902481be72779bb")

