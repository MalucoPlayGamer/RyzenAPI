-- Lua provided by SkyAPI 
-- Game: Tranquil Isle
addappid(2324180)
addappid(2324181, 1, "8e0a916e475a303736a7eaf8799924d667ec4c77f8098655acd45725d2efb810")
