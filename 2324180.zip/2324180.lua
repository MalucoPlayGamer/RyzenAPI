-- Lua provided by RyzenAPI
-- Game: Tranquil Isle

-- MAIN APPLICATION
addappid(2324180)
-- Game: addappid(2324180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2324181, 1, "8e0a916e475a303736a7eaf8799924d667ec4c77f8098655acd45725d2efb810")
