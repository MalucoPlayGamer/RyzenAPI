-- Lua provided by RyzenAPI
-- Game: 2382920

-- MAIN APPLICATION
addappid(2382920)
-- Game: addappid(2382920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2382921, 1, "3f3ec318b8c7d52bce83e5b5ad2a78b4d792c205de6c0293b4d8afa7eef7ae42")
