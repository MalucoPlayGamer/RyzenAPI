-- Lua provided by RyzenAPI
-- Game: Link Twin

-- MAIN APPLICATION
addappid(612890)

-- MAIN APP DEPOTS / PACKAGES
addappid(612891, 1, "76190cf960f22bb0e760209e160856d47ee7b0620219aa6d4d6a7c16cee43ecd")

