-- Lua provided by RyzenAPI 
-- Game: 水母之夜
addappid(2527350)
addappid(2527351, 1, "0dc2c991ef4a6f25f6af83e0bfe757fce33a3432f2b74807e40784ecfddb4c42")
