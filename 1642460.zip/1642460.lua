-- Lua provided by RyzenAPI
-- Game: Grey Lucidity - Horror Visual Novel

-- MAIN APPLICATION
addappid(1642460)
-- Game: addappid(1642460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642461, 1, "207857f2688ad46d70de2528c73c2989fef40ff0a237522c8305c1df7afa1598")
