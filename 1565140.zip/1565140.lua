-- Lua provided by RyzenAPI
-- Game: Godsbane Idle

-- MAIN APPLICATION
addappid(1565140)
