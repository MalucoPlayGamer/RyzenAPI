-- Lua provided by RyzenAPI
-- Game: QuantumVR

-- MAIN APPLICATION
addappid(2089590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089591, 1, "b79f200d6f5fd3adb7475666b74601167b51847aa4efe0a583a610a428e2d5e8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
