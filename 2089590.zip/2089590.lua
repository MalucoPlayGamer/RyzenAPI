-- Lua provided by RyzenAPI
-- Game: Game: QuantumVR

-- MAIN APPLICATION
addappid(2089590)
-- Game: addappid(2089590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089591, 1, "b79f200d6f5fd3adb7475666b74601167b51847aa4efe0a583a610a428e2d5e8")
