-- Lua provided by RyzenAPI
-- Game: 956949

-- MAIN APPLICATION
addappid(956949)

-- MAIN APP DEPOTS / PACKAGES
addappid(956949,0,"8cf21a5e2ed606d7089bbde792d72df0a42e81c170f068eacf129da5f7482e02")

