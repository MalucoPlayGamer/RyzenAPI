-- Lua provided by RyzenAPI
-- Game: 2211870

-- MAIN APPLICATION
addappid(2211870)
-- Game: addappid(2211870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2211871, 1, "5193d681021d4431d8d95a1a09ab6b647c7905f1aca5e10ddeb5207ba8a70e0f")
