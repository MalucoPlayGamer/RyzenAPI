-- Lua provided by RyzenAPI
-- Game: Lonely Knight

-- MAIN APPLICATION
addappid(1940370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1940371, 1, "57f71d91c0398d97f67ebf5ae73b21c2e8e20961b00c9c758c4be3dafd11fb05")

