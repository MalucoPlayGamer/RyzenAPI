-- Lua provided by RyzenAPI
-- Game: Space Channel 5 VR Kinda Funky News Flash!

-- MAIN APPLICATION
addappid(879140)

-- MAIN APP DEPOTS / PACKAGES
addappid(879142,0,"7b4a62706a62b0f9d5afec214950751e5a6ce1be468e453e9dc33ebad9d77b48")

