-- Lua provided by RyzenAPI
-- Game: Game: Hockey Super Squad

-- MAIN APPLICATION
addappid(3245050)
-- Game: addappid(3245050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3245051, 1, "1a3f459a4beb61082028144e23b02d3f46f14569177165415ca90b6d64432594")
