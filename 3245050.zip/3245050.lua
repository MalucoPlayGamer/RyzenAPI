-- Lua provided by SkyAPI 
-- Game: Hockey Super Squad
addappid(3245050)
addappid(3245051, 1, "1a3f459a4beb61082028144e23b02d3f46f14569177165415ca90b6d64432594")
