-- Lua provided by RyzenAPI
-- Game: 1317180

-- MAIN APPLICATION
addappid(1317180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1317180,0,"bed88c780de0c7394f06e50f12dd800db6ced08544afc06b8983edaa0e34ef45")
