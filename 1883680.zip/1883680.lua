-- Lua provided by RyzenAPI
-- Game: VR Hentai Sex Party

-- MAIN APPLICATION
addappid(1883680)
-- Game: addappid(1883680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883681, 1, "9b0bfd2c06539800d25886e86b5b1595aa1b36ac81aab2a2b85b00faa84aa75d")
addappid(1883682, 1, "ee33e6e1a61ec11e44e32e56ff4aaf0fa8d0f1d72bc799f923b8cac1ede1cc33")
