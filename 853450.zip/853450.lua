-- Lua provided by RyzenAPI
-- Game: 853450

-- MAIN APPLICATION
addappid(853450)
-- Game: addappid(853450)

-- MAIN APP DEPOTS / PACKAGES
addappid(853452,0,"7b8bb5776a770cf0d28212060a0adfa63680a66149dbc81e415c9ea398fba9f8")
