-- Lua provided by RyzenAPI 
-- Game: Perspective
addappid(1109410)
addappid(1109411, 1, "b18ee1a3172eaf0c0ceec125e41527ca2cbf1101451d8d2fa01b1c369237a32e")
