-- Lua provided by RyzenAPI
-- Game: Game: Perspective

-- MAIN APPLICATION
addappid(1109410)
-- Game: addappid(1109410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1109411, 1, "b18ee1a3172eaf0c0ceec125e41527ca2cbf1101451d8d2fa01b1c369237a32e")
