-- Lua provided by RyzenAPI
-- Game: addappid(862180)

-- MAIN APPLICATION
addappid(862180)

-- MAIN APP DEPOTS / PACKAGES
addappid(862181, 1, "6bf44756f39eb192c57cf55794f2e7e878cdad51df977ce244fe99241b320970")
