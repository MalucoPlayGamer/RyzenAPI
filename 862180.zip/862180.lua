-- Lua provided by SkyAPI 
-- Game: AppID 862180
addappid(862180)
addappid(862181, 1, "6bf44756f39eb192c57cf55794f2e7e878cdad51df977ce244fe99241b320970")
