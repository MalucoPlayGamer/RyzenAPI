-- Lua provided by RyzenAPI
-- Game: AppID 551700

-- MAIN APPLICATION
addappid(551700)
-- Game: addappid(551700)

-- MAIN APP DEPOTS / PACKAGES
addappid(551701, 1, "43ef0219a75e469a71737ee2d0ec4f0756ce09cab19db79cc87d730b8b4fbe41")
