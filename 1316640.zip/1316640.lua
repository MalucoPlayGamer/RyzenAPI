-- Lua provided by RyzenAPI
-- Game: Ironsmith Medieval Simulator: Prologue

-- MAIN APPLICATION
addappid(1316640)
-- Game: addappid(1316640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316641, 1, "42e52f723b30e9addee8117553cfed56ab92fa957ab6d32769e27a7a9247520e")
