-- Lua provided by RyzenAPI
-- Game: Ironsmith Medieval Simulator: Prologue

-- MAIN APPLICATION
addappid(1316640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1316641, 1, "42e52f723b30e9addee8117553cfed56ab92fa957ab6d32769e27a7a9247520e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
