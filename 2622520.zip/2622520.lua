-- Lua provided by RyzenAPI
-- Game: Game: AppID 2622520

-- MAIN APPLICATION
addappid(2622520)
-- Game: addappid(2622520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2622521, 1, "78f1d1d2dfc612390d7f79d52c92bb71daaa1fa1f10de4b21dd83cd42c7c7f66")
