-- Lua provided by RyzenAPI
-- Game: Crea Dedicated Server

-- MAIN APPLICATION
addappid(414570)

-- MAIN APP DEPOTS / PACKAGES
addappid(414571, 1, "0a19dc8a187964e36d19a0c82a39d7370ad4a4cd57612bf344e14441cfadcccf")
addappid(414572, 1, "3ea339267cf359f301fafdbca644d604aaf9dbed4025a06b0b1190673b8a1a7b")
addappid(414573, 1, "5ba43376d9ca778ac203eb6a1a0c448467a7846529e43b0e4a2e422036a48ce3")
addappid(414574, 1, "1ac1fcaed57ca616361d66707c830886db0e57b1f3e96900ccb3d57b843af55c")
addappid(414575, 1, "777588d5204dada371b4d0f3565c3d78fce93d4ae5a47f735b665e7a13a4ba08")

