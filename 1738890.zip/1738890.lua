-- Lua provided by RyzenAPI
-- Game: Naval Hurricane

-- MAIN APPLICATION
addappid(1738890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1738891, 1, "bb04109bcf1ce1483bbe1d723f19d1900042f4ace2868ce1d40d47775cb2e297")
