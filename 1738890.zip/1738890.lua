-- Lua provided by SkyAPI 
-- Game: Naval Hurricane
addappid(1738890)
addappid(1738891, 1, "bb04109bcf1ce1483bbe1d723f19d1900042f4ace2868ce1d40d47775cb2e297")
