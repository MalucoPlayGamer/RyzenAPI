-- Lua provided by RyzenAPI
-- Game: addappid(2112880)

-- MAIN APPLICATION
addappid(2112880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2112881, 1, "513f54eb3b32a5e9e8a610fec96d5a594099e5715ee739f6dd8272093f47a847")
