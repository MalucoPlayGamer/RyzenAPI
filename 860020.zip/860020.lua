-- Lua provided by RyzenAPI
-- Game: EXFIL

-- MAIN APPLICATION
addappid(860020)

-- MAIN APP DEPOTS / PACKAGES
addappid(860021, 1, "21a87dcc5e844a77ce8a4f5922e03a7dee2d1177fcf62be69ad21e9f9766136f")

