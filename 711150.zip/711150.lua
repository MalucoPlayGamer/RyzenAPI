-- Lua provided by RyzenAPI
-- Game: 711150

-- MAIN APPLICATION
addappid(711150)
-- Game: addappid(711150)

-- MAIN APP DEPOTS / PACKAGES
addappid(711151, 1, "0e80fb656608ac71316486bae9d820a3b858049f51b95db322c1fbe7d217e68a")
