-- Lua provided by RyzenAPI
-- Game: Heroes of SoulCraft

-- MAIN APPLICATION
addappid(319570)

-- MAIN APP DEPOTS / PACKAGES
addappid(319571, 1, "bc6c6c20760f4065d4540244f13bcb9bb3706bee3080e014f37be93da087654a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
