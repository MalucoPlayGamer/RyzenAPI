-- Lua provided by RyzenAPI
-- Game: Game: Heroes of SoulCraft

-- MAIN APPLICATION
addappid(319570)
-- Game: addappid(319570)

-- MAIN APP DEPOTS / PACKAGES
addappid(319571, 1, "bc6c6c20760f4065d4540244f13bcb9bb3706bee3080e014f37be93da087654a")
