-- Lua provided by RyzenAPI
-- Game: Retro Kart Rush

-- MAIN APPLICATION
addappid(1877000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1877001, 1, "28c4c9d5ebbdaa071f106a2a14ec93ce0e5917fe70a1aab1f5d06bc4e566755e")
