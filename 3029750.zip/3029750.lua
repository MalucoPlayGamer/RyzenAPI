-- Lua provided by RyzenAPI
-- Game: TurretGirls

-- MAIN APPLICATION
addappid(3029750)
-- Game: addappid(3029750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3029751, 1, "b76848db0a9f3e0fff7d765cea6cd9e9da56cbdc25976761cb088e49d7eb0d4f")
