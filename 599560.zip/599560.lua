-- Lua provided by RyzenAPI
-- Game: Ghost Files: The Face of Guilt

-- MAIN APPLICATION
addappid(599560)

-- MAIN APP DEPOTS / PACKAGES
addappid(599561, 1, "705f845662d48e89e13f99f6c84068f1e83e69294226e6952f6a2c05b9125ce8")
addappid(599562, 1, "953570ab44554d7b99e8f86c6d4b791438b62d9a8899ddefe4a0c6ccc7546241")
addappid(599563, 1, "edc73d0a9d0f512025c7cb9e73fbcd43c797efcaf7c7c017d289a0cd7c0b1579")

