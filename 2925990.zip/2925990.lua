-- Lua provided by RyzenAPI
-- Game: Escape the forest

-- MAIN APPLICATION
addappid(2925990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2925991,0,"57438dc6199d5ac77d740fdf56d8bfe53d3417b3daf6e917ae470ae5216536ab")

