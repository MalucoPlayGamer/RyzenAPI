-- Lua provided by RyzenAPI
-- Game: Destroy Korcity

-- MAIN APPLICATION
addappid(2564850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564851, 1, "605ce5e693230ed7f608dfaaa43e6b99cce2fd07aecbdf4122f7ae525ff23d45")
