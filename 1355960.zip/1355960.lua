-- Lua provided by RyzenAPI
-- Game: Casting Couch Simulator

-- MAIN APPLICATION
addappid(1355960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1355961, 1, "a222e5e307aa4bf32d7fbb426d9156b9772351d0aea32dbf10de1ee443c15e14")

