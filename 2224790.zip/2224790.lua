-- Lua provided by RyzenAPI 
-- Game: PIEN & PAON plus
addappid(2224790)
addappid(2224791, 1, "e48cf6d369d25b50a9f75823f61870491697f5cafe807dd3f2c292302bd2ff2c")
