-- Lua provided by RyzenAPI
-- Game: Giant Wishes

-- MAIN APPLICATION
addappid(2122360)
-- Game: addappid(2122360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2122361, 1, "d8eb8bd478366a8ab4a0818f2de9d438e286548fd94161f3f6ba0ad68c18697b")
