-- Lua provided by RyzenAPI
-- Game: AppID 1610630

-- MAIN APPLICATION
addappid(1610630)
-- Game: addappid(1610630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1610631, 1, "692975372fe5ac06c75cd3d1f221110d55eeab32cc27f413a35f49e49adf1c21")
