-- Lua provided by RyzenAPI
-- Game: AppID 4730

-- MAIN APPLICATION
addappid(4730)

-- MAIN APP DEPOTS / PACKAGES
addappid(4731, 1, "44719d50fe157cdd1e51548880748c27f194b388b13f6072e1a96dbb86c7b3bd")

