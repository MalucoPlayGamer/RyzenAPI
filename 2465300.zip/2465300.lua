-- Lua provided by SkyAPI 
-- Game: Loop Kingdom
addappid(2465300)
addappid(2465301, 1, "5567b0457826fd80b53b78ece4557b2635fdb0757f7a9ea363f871d8fcf0f4da")
