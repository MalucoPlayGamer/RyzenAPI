-- Lua provided by RyzenAPI
-- Game: Project Chemistry

-- MAIN APPLICATION
addappid(1270620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1270621, 1, "6af144d6b3b6e0fcf9946d7bfa0318f8d622f08b7eb509c0eacc7d283890d6d0")

