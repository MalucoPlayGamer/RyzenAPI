-- 3404210's Lua and Manifest Created by Hubcap Manifest
-- Continuum - Season 1
-- Created: August 11, 2026 at 23:25:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3404210) -- Continuum - Season 1
-- MAIN APP DEPOTS
addappid(3404211, 1, "d1c07f645a4e3ae48edd0d7a8ed17398bd15c646e2747a32fd3b8f5f3b8b59ee") -- Depot 3404211
setManifestid(3404211, "3079173507089889751", 2150786945)