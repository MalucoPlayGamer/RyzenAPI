-- Lua provided by RyzenAPI
-- Game: Continuum - Season 1

-- MAIN APPLICATION
addappid(3404210) -- Continuum - Season 1

-- MAIN APP DEPOTS / PACKAGES
addappid(3404211, 1, "d1c07f645a4e3ae48edd0d7a8ed17398bd15c646e2747a32fd3b8f5f3b8b59ee") -- Depot 3404211

