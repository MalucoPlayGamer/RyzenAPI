-- Lua provided by RyzenAPI
-- Game: Gigantic

-- MAIN APPLICATION
addappid(327690)
addappid(650610)
addappid(650611)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(327691, 1, "accae6c102fb771ea3b56e1c2f3c4c39a3b7c920f786ead948de76aa40becdd8")

