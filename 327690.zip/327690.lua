-- Lua provided by RyzenAPI
-- Game: Gigantic

-- MAIN APPLICATION
addappid(327690)

-- MAIN APP DEPOTS / PACKAGES
addappid(327691, 1, "accae6c102fb771ea3b56e1c2f3c4c39a3b7c920f786ead948de76aa40becdd8")
