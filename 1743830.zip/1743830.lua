-- Lua provided by RyzenAPI
-- Game: Game: One Military Camp

-- MAIN APPLICATION
addappid(1743830)
-- Game: addappid(1743830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1743831, 1, "b751edce3228577f3a72148e8497c31b93cfdc6c4a71db89d742928d8f96bf6e")
