-- Lua provided by RyzenAPI
-- Game: One Military Camp

-- MAIN APPLICATION
addappid(1743830)
addappid(2686140)
addappid(2705390)
addappid(2779260)
addappid(2867530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1743831, 1, "b751edce3228577f3a72148e8497c31b93cfdc6c4a71db89d742928d8f96bf6e")

