-- Lua provided by SkyAPI 
-- Game: One Military Camp
addappid(1743830)
addappid(1743831, 1, "b751edce3228577f3a72148e8497c31b93cfdc6c4a71db89d742928d8f96bf6e")
