-- Lua provided by RyzenAPI
-- Game: 東方翠神廻廊 〜 Faith in the Goddess of Suwa.

-- MAIN APPLICATION
addappid(1010850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1010851, 1, "a0c2101ee81a7670119b925a87a4894d985f4b1d9d52b359d34ade63b5d634b7")
addappid(1010852, 1, "76761c08e229f53c6fc56790da6417d5d69783c2881024d460817f999a00576b")
addappid(1010853, 1, "704d248eeb8b028b6b54944e642b34a5a0bd001791342fd978d977a4ab10e777")

