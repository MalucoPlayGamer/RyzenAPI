-- Lua provided by RyzenAPI
-- Game: 70年代風ロボットアニメ ゲッP-X

-- MAIN APPLICATION
addappid(4120310)

-- MAIN APP DEPOTS / PACKAGES
addappid(4120311,0,"1fade3aeb9a0b945f74400f5e3b0f1c72c5445bae00ace1b17e1109ff32a5b17")