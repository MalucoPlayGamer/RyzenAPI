-- 2172910's Lua and Manifest Created by Hubcap Manifest
-- CAPTAIN TSUBASA 2: WORLD FIGHTERS
-- Created: August 27, 2026 at 22:38:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 6
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2172910) -- CAPTAIN TSUBASA 2: WORLD FIGHTERS
-- MAIN APP DEPOTS
addappid(2172911, 1, "135e5b2b665c27b9c8e25731dde82adac1fe04efca78531c66e8152e461084cf") -- Depot 2172911
setManifestid(2172911, "5035811274775403685", 21945119654)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4196700) -- CAPTAIN TSUBASA 2 WORLD FIGHTERS - Season Pass Bonus
addappid(4196710) -- CAPTAIN TSUBASA 2 WORLD FIGHTERS - Ultimate Pack
addappid(4196720) -- CAPTAIN TSUBASA 2 WORLD FIGHTERS - Save Data Bonus Pack
addappid(4199240) -- CAPTAIN TSUBASA 2 WORLD FIGHTERS - Pre-Order Bonus Pack
addappid(4280300) -- CAPTAIN TSUBASA 2 WORLD FIGHTERS - 2026 Japan National Team  World Youth Jersey Set
addappid(4280310) -- CAPTAIN TSUBASA 2 WORLD FIGHTERS - Season Pass
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2172912) -- Depot 2172912 (empty depot)