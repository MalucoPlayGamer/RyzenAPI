-- Lua provided by RyzenAPI
-- Game: AppID 543580

-- MAIN APPLICATION
addappid(543580)
-- Game: addappid(543580)

-- MAIN APP DEPOTS / PACKAGES
addappid(543581, 1, "922deebeb4130bfd650c61441775f31ad94bce2b8d2b8ed34a439c4728d17f9d")
