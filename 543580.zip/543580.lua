-- Lua provided by SkyAPI 
-- Game: AppID 543580
addappid(543580)
addappid(543581, 1, "922deebeb4130bfd650c61441775f31ad94bce2b8d2b8ed34a439c4728d17f9d")
