-- Lua provided by RyzenAPI
-- Game: Game: AppID 2256450

-- MAIN APPLICATION
addappid(2256450)
-- Game: addappid(2256450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2256451, 1, "ec8371e1b75a94f9622381589573abb10cce8477b8364e41f90f8754f4e438c7")
