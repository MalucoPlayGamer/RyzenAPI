-- Lua provided by RyzenAPI
-- Game: RAM: Random Access Mayhem

-- MAIN APPLICATION
addappid(2256450)
addappid(4009970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2256451, 1, "ec8371e1b75a94f9622381589573abb10cce8477b8364e41f90f8754f4e438c7")

