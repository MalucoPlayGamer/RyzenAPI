-- Lua provided by RyzenAPI
-- Game: 1980530

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(1980530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1980532,0,"3a5bc1f555d8d6789c837e787d7e41f2468c0d1700d54b76c198d935c61d1bea")

