-- Lua provided by RyzenAPI
-- Game: 3451290

-- MAIN APPLICATION
addappid(3451290)
-- Game: addappid(3451290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3451291, 1, "f6c676f5be9f8105138747b813ad016f1a9ceb6ac721ec7b0a2ac09e0bf2596f")
