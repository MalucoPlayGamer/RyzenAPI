-- Lua provided by RyzenAPI
-- Game: Pale Abyss - Prototype

-- MAIN APPLICATION
addappid(3451290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3451291, 1, "f6c676f5be9f8105138747b813ad016f1a9ceb6ac721ec7b0a2ac09e0bf2596f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
