-- Lua provided by RyzenAPI
-- Game: AppID 680690

-- MAIN APPLICATION
addappid(680690)

-- MAIN APP DEPOTS / PACKAGES
addappid(680691, 1, "70205246e4a76932d7659f79fbb067c16a10b564ff1291a885230df1278882e8")
addappid(680692, 1, "d4f22ea102c6c72a287b42b367184b5213dd6b30bd33b11b4af2e50128b1078c")
addappid(680693, 1, "cf8ca47946d7b496a57e5929c33c6a3fb947f071dfd8f782d6b19960f2a975c9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
