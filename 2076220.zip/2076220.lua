-- Lua provided by RyzenAPI
-- Game: Game: Akai Katana Shin

-- MAIN APPLICATION
addappid(2076220)
-- Game: addappid(2076220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076221, 1, "3480000ad89f5174f6e4429bee7e9f1a3e8500dcc47e4721251974b5c82a29ec")
