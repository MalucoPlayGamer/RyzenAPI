-- Lua provided by RyzenAPI
-- Game: AppID 729970

-- MAIN APPLICATION
addappid(729970)

-- MAIN APP DEPOTS / PACKAGES
addappid(729971, 1, "b25aa9eed16e90201bcd0c2bb0646390982e0f94da7a2f24a7ad7cd67577753e")
