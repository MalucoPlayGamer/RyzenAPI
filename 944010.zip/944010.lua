-- Lua provided by RyzenAPI
-- Game: addappid(944010)

-- MAIN APPLICATION
addappid(944010)

-- MAIN APP DEPOTS / PACKAGES
addappid(944011, 1, "b8f4c5498fbfc24b4b5c7d713bcef7de3b433e72bbae2b4488df7b516a347e72")
