-- Lua provided by RyzenAPI 
-- Game: Pocket Cars
addappid(1170720)
addappid(1170721, 1, "18cb6dc460bb8399071197fbf4093dcfb52b818368958abab731075108fbd391")
addappid(1170722, 1, "303eb447be96ced4f4f2cd7019fbbb51d35666d357fe713d36f38be326bfcbfe")
