-- Lua provided by RyzenAPI
-- Game: 693800

-- MAIN APPLICATION
addappid(693800)
-- Game: addappid(693800)

-- MAIN APP DEPOTS / PACKAGES
addappid(693801, 1, "b22f41f5951c5b597455390abd591791aae72585c3696e64bd7f5240e89a05ec")
