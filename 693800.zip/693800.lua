-- Lua provided by RyzenAPI
-- Game: Loco Parentis / 孤女咒怨

-- MAIN APPLICATION
addappid(693800)

-- MAIN APP DEPOTS / PACKAGES
addappid(693801, 1, "b22f41f5951c5b597455390abd591791aae72585c3696e64bd7f5240e89a05ec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
