-- Lua provided by RyzenAPI
-- Game: Tank Brawl 2: Armor Fury

-- MAIN APPLICATION
addappid(765450)

-- MAIN APP DEPOTS / PACKAGES
addappid(765451, 1, "4fb72d0df5a7496ff7aad84e4d3dd2a69b3b80b24ad00d977b688464dcf9485c")
