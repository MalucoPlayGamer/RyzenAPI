-- Lua provided by RyzenAPI
-- Game: Tank Brawl 2: Armor Fury

-- MAIN APPLICATION
addappid(765450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(765451, 1, "4fb72d0df5a7496ff7aad84e4d3dd2a69b3b80b24ad00d977b688464dcf9485c")

