-- Lua provided by RyzenAPI
-- Game: Michelangelo: Stonemason Simulator

-- MAIN APPLICATION
addappid(3509200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3509201, 1, "563a38d7621966bfc18d46ea0eae0e777a7896944f30a08ec067cd4ce59d9d74")

