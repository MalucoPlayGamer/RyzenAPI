-- Lua provided by RyzenAPI
-- Game: 3597190

-- MAIN APPLICATION
addappid(3597190)
-- Game: addappid(3597190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3597191, 1, "461e39dcef91bc0e59097b19cf7629eedca9f06e177ded9bffbf183642881972")
