-- Lua provided by RyzenAPI 
-- Game: Cake Space Shooter
addappid(3370400)
addappid(3370401, 1, "dc293f3503a01849933fa5b135c23d7cc4375b3cde1828cb6cc350c240d796aa")
