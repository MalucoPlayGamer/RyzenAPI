-- Lua provided by RyzenAPI
-- Game: addappid(3370400)

-- MAIN APPLICATION
addappid(3370400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3370401, 1, "dc293f3503a01849933fa5b135c23d7cc4375b3cde1828cb6cc350c240d796aa")
