-- Lua provided by RyzenAPI
-- Game: Marmoset

-- MAIN APPLICATION
addappid(1783090)
-- Game: addappid(1783090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1783091, 1, "e9df6d09dcc74a54bed638234c5569d7978de926832431ca2ac44cfd8f1a6b6b")
