-- Lua provided by RyzenAPI
-- Game: Growbot

-- MAIN APPLICATION
addappid(661680)

-- MAIN APP DEPOTS / PACKAGES
addappid(661681, 1, "e9a7f40c27b17b956cfdc511eab209a6a03aae4eace2f524dfbf346c3b974439")
addappid(661682, 1, "b3b7905b88f34486464941768913933b3799f3fb113ce5328e8e20f7004810e3")
addappid(661683, 1, "4d74ab23d26c6a6b1607f4510d4c2e65bebb3a12d6c8e4dccb849ef1d2a6e4f5")
addappid(661684, 1, "a7949ae706e6538c5758dddf946088b9416d904a56f503b04abfc5bc1a1a9692")
addappid(661685, 1, "b138187c8afb0ed6c3db5a41b3f79cb1e8530ff4b06abbb2853f7e57e1e3e7b7")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1752120)
