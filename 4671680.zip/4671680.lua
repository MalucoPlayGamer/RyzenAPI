-- Lua provided by RyzenAPI
-- Game: Left Not Right

-- MAIN APPLICATION
addappid(4671680)
addappid(4876610)

-- MAIN APP DEPOTS / PACKAGES
addappid(4671681, 1, "987a3164a791146915b5fcb9302425a5a37805ddf2058965ddb9df5fc942a010")
addappid(4876611, 1, "aa1a771aed9ad2e8cc4ac0b5ed2521ad1a6d7b84e22d471286791e4daf818add")

