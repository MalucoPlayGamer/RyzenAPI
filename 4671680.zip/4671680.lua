-- Generated with Luie @ https://lua.tools/
-- 4671680 - Left Not Right
-- Generated 2026-08-27 21:59:57 UTC
-- # Depots (Total/DLC/Shared): 2/1/0

-- Main AppID
addappid(4671680)

-- Main Depots
addappid(4671681, 1, "987a3164a791146915b5fcb9302425a5a37805ddf2058965ddb9df5fc942a010")
setManifestid(4671681, "2156009602865890353", 219357501)

-- DLC's (with depot keys)
-- Left Not Right Demo (AppID: 4876610)
addappid(4876610)
addappid(4876611, 1, "aa1a771aed9ad2e8cc4ac0b5ed2521ad1a6d7b84e22d471286791e4daf818add")
setManifestid(4876611, "8411699747820230946", 214891123)
