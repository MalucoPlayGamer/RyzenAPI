-- Lua provided by RyzenAPI
-- Game: Who's Your Daddy Playtest

-- MAIN APPLICATION
addappid(1470110)
-- Game: addappid(1470110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1470111, 1, "0167c757a1854327660430358322c613be792f0acad5ff0ef48aac5227e49e3d")
