-- Lua provided by RyzenAPI
-- Game: addappid(33460)

-- MAIN APPLICATION
addappid(33460)

-- MAIN APP DEPOTS / PACKAGES
addappid(33461, 1, "169a20b712fb7808c9ad463f9d9c00b0d6d493e2eed9abbbfa800d52c654f66e")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
