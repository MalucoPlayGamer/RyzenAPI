-- Lua provided by RyzenAPI
-- Game: Security Guard Sex - Episode 1

-- MAIN APPLICATION
addappid(2946870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2946871, 1, "2132a72e52e12cf9445a95c4485d82f28ba7d9468d79884548d3d2f327f0c115")

