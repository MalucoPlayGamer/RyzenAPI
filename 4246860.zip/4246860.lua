-- Lua provided by RyzenAPI
-- Game: Security 51

-- MAIN APP DEPOTS / PACKAGES
addappid(4246860, 1, "75cef07d30041bf5729b5fe3e4a62316d990522c100c038e349f8f2324f7f859") -- Security 51
addappid(4246861, 1, "1488696a7378bf1e1a74e764eb47304af7f09ae46a31440dcc019b8680e13a88") -- Depot 4246861
addappid(4246862, 1, "f0fe3fda2c765fa51000eb31e4f3edf1a303cf0cb5d9a9ef6ac0879e3115cd16") -- Depot 4246862

