-- 4246860's Lua and Manifest Created by Hubcap Manifest
-- Security 51
-- Created: August 12, 2026 at 09:20:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4246860, 1, "75cef07d30041bf5729b5fe3e4a62316d990522c100c038e349f8f2324f7f859") -- Security 51
-- MAIN APP DEPOTS
addappid(4246861, 1, "1488696a7378bf1e1a74e764eb47304af7f09ae46a31440dcc019b8680e13a88") -- Depot 4246861
setManifestid(4246861, "7615631335608036236", 2249029316)
addappid(4246862, 1, "f0fe3fda2c765fa51000eb31e4f3edf1a303cf0cb5d9a9ef6ac0879e3115cd16") -- Depot 4246862
setManifestid(4246862, "5611265527028417615", 2395759771)