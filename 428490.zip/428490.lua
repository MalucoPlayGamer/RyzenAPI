-- Lua provided by RyzenAPI
-- Game: AppID 428490

-- MAIN APPLICATION
addappid(428490)

-- MAIN APP DEPOTS / PACKAGES
addappid(428491, 1, "080604e65cf42af4411acee087877e6cc5e0446fcc8a5c8254a0b1e04d438948")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
