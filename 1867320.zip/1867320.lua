-- Lua provided by RyzenAPI
-- Game: Werewolves Revenge

-- MAIN APPLICATION
addappid(1867320)
