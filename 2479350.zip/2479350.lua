-- Lua provided by RyzenAPI
-- Game: AppID 2479350

-- MAIN APPLICATION
addappid(2479350)
-- Game: addappid(2479350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2479351, 1, "47e7e14d9edf26d3ef0342281b2aa930cf2b8bcb4898a471ed0d4341bd3f93d2")
