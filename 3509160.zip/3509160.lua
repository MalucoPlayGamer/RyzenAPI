-- Lua provided by RyzenAPI
-- Game: BAIONLENJA

-- MAIN APPLICATION
addappid(3509160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3509161, 1, "d04216ceb0f5b366310ff0d5ddbef46abd6d08717284112dd390a7a1e1dbae60")

