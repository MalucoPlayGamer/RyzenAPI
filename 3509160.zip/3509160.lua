-- Lua provided by RyzenAPI
-- Game: BAIONLENJA

-- MAIN APPLICATION
addappid(3509160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3509161, 1, "d04216ceb0f5b366310ff0d5ddbef46abd6d08717284112dd390a7a1e1dbae60")

