-- Lua provided by RyzenAPI
-- Game: There's No Dinosaurs 2

-- MAIN APPLICATION
addappid(2859810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2859811, 1, "45bfb26975ac66df1b4c34c3fba9adfea52cf1830e3e4a49b920adbaa59706e1")
