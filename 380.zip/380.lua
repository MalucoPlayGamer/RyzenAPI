-- Lua provided by RyzenAPI
-- Game: Half-Life 2: Episode One

-- MAIN APPLICATION
addappid(380)
addappid(323150)

-- MAIN APP DEPOTS / PACKAGES
addappid(381, 1, "43cbfef04a73172acde761eb5dfcd8d4ae0a78e6069a5cc5740f83dfb9f352f8")
addappid(382, 1, "d93a483c0da0814e1da42efc92e12f380240561dc3ff6c017716823795d35d1c")
addappid(383, 1, "0887582dc2d4bd92c677b3f22cc2e28bb2066c0c00392413f9fcc2fa90a7b43f")
addappid(384, 1, "27ad5f59a417b17931dfc8b56de22c57060ae041d012382a7dfc8b6b9a1ecb24")
addappid(385, 1, "1d4e92908733db38cbb6a98ecccf19bfd3c90247d20b14a666aa57da0f36e37a")
addappid(386, 1, "17cd02472abe276543703bd06c6ef27b5b888135b3fada6b539e6ccbf8761ec7")
addappid(387, 1, "697c041290f422d01b2e6ec9a77ed1228bb8aea7b8ce4bb7656db4d43cacc3c6")
addappid(388, 1, "8e8fa5db2868d729aeaa092613da7f511d219b2a93c486ec5cb9fd0812d9c998")
addappid(389, 1, "e8a443d7ad9e767467e32e045d3f57cebe75478eb4faec1ea9f36f098df236c8")
