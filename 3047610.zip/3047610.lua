-- Lua provided by SkyAPI 
-- Game: Heirs
addappid(3047610)
addappid(3047611, 1, "b9e0e638a5ad00c21a7729263f9fa7097fc6e62c08f09291dd75f5b0e1b6f312")
