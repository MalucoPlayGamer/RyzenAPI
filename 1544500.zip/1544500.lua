-- Lua provided by RyzenAPI
-- Game: Sensual Adventures - Episode 5

-- MAIN APPLICATION
addappid(1544500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544501, 1, "021101119a4cb2018a9130bb7fce35a661d6f8b98bfde0764bee7711a684a4a8")

