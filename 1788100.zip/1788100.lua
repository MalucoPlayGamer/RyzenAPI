-- Lua provided by RyzenAPI
-- Game: Saimin Gakushū: Secret Desire

-- MAIN APPLICATION
addappid(1788100)
-- Game: addappid(1788100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1788101, 1, "e4d856a9bd00b91530103247f866146a05fc9ccc7a3a2df03dfea9e794c8fa9d")
