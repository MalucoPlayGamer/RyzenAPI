-- Lua provided by RyzenAPI
-- Game: Winning Post 10 体験版

-- MAIN APPLICATION
addappid(2271770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2271771, 1, "75a36e4e8eb0fa8429532f8afc6f68190189a320512ceba03592d90b8d2dbe9b")
