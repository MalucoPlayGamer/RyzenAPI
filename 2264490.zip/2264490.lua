-- Lua provided by RyzenAPI
-- Game: addappid(2264490)

-- MAIN APPLICATION
addappid(2264490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2264491, 1, "05f3cd47db5302cdaf91916c2117b089a2d89e0f4d11598afdcc8bebce8f058d")
