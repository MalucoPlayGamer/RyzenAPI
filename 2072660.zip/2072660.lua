-- Lua provided by RyzenAPI
-- Game: Voidborn

-- MAIN APPLICATION
addappid(2072660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072661, 1, "5efa73871d64b1d009cec8925d8007c02580d70c8fc44f6bed8540ff9a9d6a08")

