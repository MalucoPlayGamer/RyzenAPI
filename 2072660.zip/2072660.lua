-- Lua provided by SkyAPI 
-- Game: Voidborn
addappid(2072660)
addappid(2072661, 1, "5efa73871d64b1d009cec8925d8007c02580d70c8fc44f6bed8540ff9a9d6a08")
