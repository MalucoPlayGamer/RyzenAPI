-- Lua provided by RyzenAPI
-- Game: Game: Stay With Me! Alien Abduction Story Demo

-- MAIN APPLICATION
addappid(2103460)
-- Game: addappid(2103460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103461, 1, "795559d886467a0fff0fc5867aa396dfe57c0a7ed075fea4ec123ad5f3851a4c")
