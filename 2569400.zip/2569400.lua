-- Lua provided by RyzenAPI
-- Game: Game: AppID 2569400

-- MAIN APPLICATION
addappid(2569400)
-- Game: addappid(2569400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569401, 1, "4e21e5f32df04841be265e6d5a80f6c4592bca83cfa3146f047225168a5356bf")
