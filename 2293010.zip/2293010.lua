-- Lua provided by RyzenAPI
-- Game: Game: OnlyFap Simulator  6 💦

-- MAIN APPLICATION
addappid(2293010)
-- Game: addappid(2293010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293011, 1, "0745ec7a4002e835994ae8d44a436b99f624ce10a94793578f59e51d2a35ac8a")
