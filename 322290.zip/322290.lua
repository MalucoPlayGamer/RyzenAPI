-- Lua provided by RyzenAPI
-- Game: Gurumin: A Monstrous Adventure

-- MAIN APPLICATION
addappid(322290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(322291, 1, "43b1c0d3d24d21f3747d85aab8b97e7659495b00cbee44cc7c3e84ac68d8268a")

