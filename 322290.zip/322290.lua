-- Lua provided by RyzenAPI
-- Game: Gurumin: A Monstrous Adventure

-- MAIN APPLICATION
addappid(322290)

-- MAIN APP DEPOTS / PACKAGES
addappid(322291, 1, "43b1c0d3d24d21f3747d85aab8b97e7659495b00cbee44cc7c3e84ac68d8268a")
