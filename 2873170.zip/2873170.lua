-- Lua provided by RyzenAPI 
-- Game: Simulation Training Room: Massacre
addappid(2873170)
addappid(2873171, 1, "2799c9d3c9b1cbc4bb4c129f7a367cd4732f854e6fbfb82054307f13892065ae")
