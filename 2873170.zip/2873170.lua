-- Lua provided by RyzenAPI
-- Game: Game: Simulation Training Room: Massacre

-- MAIN APPLICATION
addappid(2873170)
-- Game: addappid(2873170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2873171, 1, "2799c9d3c9b1cbc4bb4c129f7a367cd4732f854e6fbfb82054307f13892065ae")
