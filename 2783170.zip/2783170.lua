-- Lua provided by RyzenAPI
-- Game: AppID 2783170

-- MAIN APPLICATION
addappid(2783170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2783171, 1, "f3cf39f71b414a85adcbc5eeba3042500f07ee44a2ee7b4bf52ff20c3d389ccc")
