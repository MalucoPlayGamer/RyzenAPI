-- Lua provided by RyzenAPI
-- Game: Darksiders III

-- MAIN APPLICATION
addappid(606280)
addappid(889901)
addappid(889902)
addappid(889903)

-- MAIN APP DEPOTS / PACKAGES
addappid(606281, 1, "1006fea4a0c69e799b0e76c8ac156521a2e813579a945a71ff8810b9880d3d0b")
addappid(889900, 0, "b7145397071d1789e33b19bbb06dd94f643f3a2fb1b2aa62be3925e2c49e2828")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
