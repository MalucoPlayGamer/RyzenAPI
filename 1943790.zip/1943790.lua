-- Lua provided by RyzenAPI
-- Game: 1943790

-- MAIN APPLICATION
addappid(1943790)
-- Game: addappid(1943790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1943790,0,"64af6e3ae9a747833dab8e5d845267f53fd77f470d33edb1f18b0ad8c895dd83")
