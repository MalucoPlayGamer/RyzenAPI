-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1753521)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753521,0,"e0693c00ed84cd9a37a9167abef54673df45a4f6e59be6c044ce80f6ba3f649f")

