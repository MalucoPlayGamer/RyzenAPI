-- Lua provided by RyzenAPI
-- Game: Cloudheim

-- MAIN APPLICATION
addappid(2070270)
addappid(4164290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2070272,0,"edb03c349c8b8875e63425d9789b68b246de360a06f350e8b230357032ebab9b")

