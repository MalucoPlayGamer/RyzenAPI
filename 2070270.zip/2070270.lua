-- Lua provided by RyzenAPI
-- Game: Cloudheim

-- MAIN APPLICATION
addappid(2070270)
addappid(4164290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2070272,0,"edb03c349c8b8875e63425d9789b68b246de360a06f350e8b230357032ebab9b")

