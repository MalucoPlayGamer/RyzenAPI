-- Lua provided by RyzenAPI
-- Game: To Be or Not to Be

-- MAIN APPLICATION
addappid(2190290)
-- Game: addappid(2190290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2190291, 1, "71d020d54704794ac8d42c08d087112ae12660a00337bac1132684a202a3cd69")
addappid(2208180, 0, "aed056f91092aad76d4f85af3d5dbab6130ff7c5790bfcb6c5f94e364169aedd")
