-- Lua provided by RyzenAPI
-- Game: 956722

-- MAIN APPLICATION
addappid(956722)
-- Game: addappid(956722)

-- MAIN APP DEPOTS / PACKAGES
addappid(956722,0,"477dcd7e8cf7778f1492cbeaadaf0b271b9880c0d2daeee2248e190493577a74")
