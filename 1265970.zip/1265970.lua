-- Lua provided by RyzenAPI
-- Game: Dark City: Dublin Collector's Edition

-- MAIN APPLICATION
addappid(1265970)
-- Game: addappid(1265970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265971, 1, "89005e5b92a250f378a1bb44076825ec24c09296a6abd4c98c956e5f2b8b1b66")
