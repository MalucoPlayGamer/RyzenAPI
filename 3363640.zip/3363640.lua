-- Lua provided by RyzenAPI
-- Game: Puyo! Sokoban

-- MAIN APPLICATION
addappid(3363640)
-- Game: addappid(3363640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3363641, 1, "e025e9803e86e0109e9c1765f7512c6344cf4bd2eff5c2f729804686455671f8")
