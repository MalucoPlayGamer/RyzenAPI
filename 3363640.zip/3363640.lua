-- Lua provided by RyzenAPI 
-- Game: Puyo! Sokoban
addappid(3363640)
addappid(3363641, 1, "e025e9803e86e0109e9c1765f7512c6344cf4bd2eff5c2f729804686455671f8")
