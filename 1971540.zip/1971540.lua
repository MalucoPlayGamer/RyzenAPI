-- Lua provided by RyzenAPI
-- Game: 1971540

-- MAIN APPLICATION
addappid(1971540)
-- Game: addappid(1971540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1971541, 1, "45ba433f030d36c8ba1d2f4aeb86828976d12fe237c808b4576bc89da213960c")
