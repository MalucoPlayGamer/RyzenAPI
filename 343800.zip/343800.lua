-- Lua provided by RyzenAPI
-- Game: Game: Shadowgate: MacVenture Series

-- MAIN APPLICATION
addappid(343800)
-- Game: addappid(343800)

-- MAIN APP DEPOTS / PACKAGES
addappid(343801, 1, "dfd4a73e8c067741df8bd5b04e6835ca00f26697792062b48b481711d433c69a")
