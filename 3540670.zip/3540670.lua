-- Lua provided by RyzenAPI
-- Game: Game: SQUASER 5

-- MAIN APPLICATION
addappid(3540670)
-- Game: addappid(3540670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3540671, 1, "5e2a98ad35149991ca7cfe93fb505463d599b8703518050754ff8534ea9f1bb9")
