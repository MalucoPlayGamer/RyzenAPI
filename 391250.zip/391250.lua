-- Lua provided by RyzenAPI 
-- Game: Alien Robot Monsters
addappid(391250)
addappid(391251, 1, "ed84ca138a91743e7e38468d5aaad7a820b659bf7283fd0718e252eccb54c891")
addappid(392840, 0, "0ee0f1a4466dfa5291f3225157b05fc434f5ca668f32ceb14ccd883594b04edb")
