-- Lua provided by RyzenAPI
-- Game: Alien Robot Monsters

-- MAIN APPLICATION
addappid(391250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(391251, 1, "ed84ca138a91743e7e38468d5aaad7a820b659bf7283fd0718e252eccb54c891")
addappid(392840, 0, "0ee0f1a4466dfa5291f3225157b05fc434f5ca668f32ceb14ccd883594b04edb")

