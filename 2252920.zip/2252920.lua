-- Lua provided by RyzenAPI
-- Game: addappid(2252920)

-- MAIN APPLICATION
addappid(2252920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2252921, 1, "d6a433be340e6fc3b6558866ec50ac3b7488ce8d71f2d238978c6022cc8f27eb")
