-- Lua provided by RyzenAPI
-- Game: addappid(508790)

-- MAIN APPLICATION
addappid(508790)

-- MAIN APP DEPOTS / PACKAGES
addappid(508791, 1, "46b944d04d399ccf5495bbd7c98c87f19958a902c783f300af2c2bafb4a44735")
addappid(508792, 1, "02bf3bfc47eb887900902d1019283e5f1bdea62b311dfe48dbd63cf76b9c9c6b")
addappid(508793, 1, "253b6fbcb8c4b37294078bd361355dc21dc78585da0ce6a93372afe434ffae3e")
addappid(508794, 1, "f576d6a257f28dc7cab6cfca7a3403ca9f17b8302d08f25ea0f3429e3a335b3f")
