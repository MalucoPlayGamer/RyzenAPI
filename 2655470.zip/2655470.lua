-- Lua provided by RyzenAPI
-- Game: 2655470

-- MAIN APPLICATION
addappid(2655470)
-- Game: addappid(2655470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2655471, 1, "db88a0b7f0a07923de482c7f25c9f57bf2376232b472373aa6b9beb903c1dbba")
