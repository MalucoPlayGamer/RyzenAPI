-- 2075800's Lua and Manifest Created by Hubcap Manifest
-- STAR WARS Zero Company™
-- Created: August 27, 2026 at 12:54:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 2
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2075800, 1, "8739458192bb08e37151785656da5812d94e6372b0f59181874d85e39e7124e5") -- STAR WARS Zero Company™
-- MAIN APP DEPOTS
addappid(2075801, 1, "aa9607f71f9a605eca85df732f1e983f862efa0e5a2042765c056168b09511aa") -- Depot 2075801
setManifestid(2075801, "733645599275386891", 42592314555)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3701350) -- STAR WARS Zero Company Deluxe Edition Upgrade
addappid(3701360) -- STAR WARS Zero Company  Preorder Bonus