-- Lua provided by RyzenAPI
-- Game: Game: united city

-- MAIN APPLICATION
addappid(2406100)
-- Game: addappid(2406100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406101, 1, "afbf98c64747e417e5a8634019411900dc1f3d2aec24c2a447094ddf7187ac86")
