-- Lua provided by RyzenAPI
-- Game: 1237670

-- MAIN APPLICATION
addappid(1237670)
-- Game: addappid(1237670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237671, 1, "154d45d9b356bec43cf0eaa12308033065fa49017bcd7bb3f05cad3e488904ae")
