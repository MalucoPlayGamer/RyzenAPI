-- Lua provided by RyzenAPI
-- Game: Louie Cooks

-- MAIN APPLICATION
addappid(398480)
-- Game: addappid(398480)

-- MAIN APP DEPOTS / PACKAGES
addappid(398481, 1, "44aad7ac0595c9bcc7f5ba1f6a2084b1d184158773590c7f4bf2b918d1848086")
addappid(398482, 1, "2e825a9348ef58d05221f31d9a77e798b26815a68376180a55ef13491a8aa3c2")
