-- Lua provided by RyzenAPI
-- Game: BLASK

-- MAIN APPLICATION
addappid(987710)

-- MAIN APP DEPOTS / PACKAGES
addappid(987711, 1, "a6383fea9fb331f9f33ce129046b7171c54f847f94d08213b03dc95d8dc80bec")

