-- Lua provided by RyzenAPI
-- Game: 453400

-- MAIN APPLICATION
addappid(453400)
-- Game: addappid(453400)

-- MAIN APP DEPOTS / PACKAGES
addappid(453401, 1, "6f860da845c3de19cc371829ec3022e8dd130e9775343e10aab5a3a5aac938a6")
addappid(453402, 1, "c6bd7a2293fc2e20707ff3b11c4eda5d0fdf5605109120e83cdba24139794f04")
