-- Lua provided by RyzenAPI
-- Game: Call of Duty®: Modern Warfare® 3 (2011) - Multiplayer

-- MAIN APPLICATION
addappid(42695)
addappid(42696)
addappid(42697)
addappid(42698)

-- MAIN APP DEPOTS / PACKAGES
addappid(42682, 1, "a7f0704e4a61083d1ef176c1efe2666a1e694ca4a2e40c17dda9f6c7a9ecceb1") -- Call of Duty Modern Warfare 3 Content
addappid(42683, 1, "252c3bce60c362e7fdb65dabb24a8f0f6d3098ef341315df1a9f2208c8550c9f") -- Call of Duty Modern Warfare 3 english
addappid(42684, 1, "7f904784b8e0755738fd4e3a4ade829396e449060bfd09275dd380dcff422703") -- Call of Duty Modern Warfare 3 spanish
addappid(42685, 1, "55cf38352373d9669395acabad606ab665e82d0421b28dc2c39003055f91ac5f") -- Call of Duty Modern Warfare 3 german
addappid(42686, 1, "1a676d3458091a765385fd997ed2171aeb13045296927c26c6a7bdebba7a3504") -- Call of Duty Modern Warfare 3 french
addappid(42687, 1, "308eb88b20769f215eb317cc8cae34f4e7a4cc74d74e8a04262275dbe41f5eca") -- Call of Duty Modern Warfare 3 italian
addappid(42688, 1, "a86e1ec84e71aad3a8c1b3fc2f3a237906eb6de447510da925db20173fb6b724") -- Call of Duty Modern Warfare 3 Russian
addappid(42689, 1, "5562719fd8e66322c45af3e1b327211c2dd815edd340bd6969a0dac1ebad018f") -- Call of Duty Modern Warfare 3 Japanese
addappid(42690, 1, "acc1258ec3cd48e1ed6d5dc386274f9d3458b04bd5e3ba81792df71d0551fd91") -- Call of Duty®: Modern Warfare® 3 (2011) - Multiplayer
addappid(42691, 1, "1468055b79a759624728a4a6c72688a3ac1051ddd49f410e01340f6af21b8d3a") -- Call of Duty Modern Warfare 3 MP Binaries
addappid(42692, 1, "9c172487a1111e79908452b7cbbb680a070c482754b41be716278f44d681586d") -- Call of Duty Modern Warfare 3 Polish
addappid(42695, 1, "fc4329dbad7b8de99e9e6d4a7c4d0f6a818b325bd0998955085ca719a37a8d9d") -- Call of Duty Modern Warfare 3 (2011) - Collection 1 - Call of Duty Modern Warfare 3 - Collection 1
addappid(42696, 1, "cf65beed5e235a70245d76254d737472e4c45395cedfaf95799da1b2b214e162") -- Call of Duty Modern Warfare 3 (2011) - DLC2 - Call of Duty Modern Warfare 3 - Collection 2
addappid(42697, 1, "f85abaa8253365bc56a5329743975b1d8a069322f53d9a4e16bdc646f525ee8d") -- Call of Duty Modern Warfare 3 (2011) - DLC3 - Call of Duty Modern Warfare 3 - Collection 3
addappid(42698, 1, "f9e01c1cd7fb437811bc3320b8fad54f53fc9cf476d094fdc7c65feb97b6c5bf") -- Call of Duty Modern Warfare 3 (2011) Collection 4 Final Assault - Call of Duty Modern Warfare 3 - Collection 4
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(278310, 1, "c79da57207ccf933258ced455e9793b8ca10fdcd38300181226173ee705fe71b") -- Call of Duty: Modern Warfare 3 suitcase Content
addappid(278311, 1, "5559eee02af42778a8a9fc69adbce13094e87bd75aa467082ef4f0c56f36af0a") -- Call of Duty: Modern Warfare 3 suitcase MP Binary
addappid(278312, 1, "ab950813ce8448c02aad504c486513a86c03aa55bde084c7c6be8f6ca2b71966") -- Call of Duty: Modern Warfare 3 suitcase English
addappid(278313, 1, "fac16c89e3e4731296e3017b59a98ba16fa82ac1eca6b432fb0134639fbcc721") -- Call of Duty: Modern Warfare 3 suitcase Spanish
addappid(278314, 1, "bba43dbf20aca5543940151e8cf815cc535967d8091a6e2a777a4486bb5410a4") -- Call of Duty: Modern Warfare 3 suitcase German
addappid(278315, 1, "ab5bc1898a3c4805ce627fada0b379a4854a291ac920846e1505fcd7ace6b422") -- Call of Duty: Modern Warfare 3 suitcase French
addappid(278316, 1, "654ea6858de9296fc3d260a92db3c6c51acfdda38afd672784f6b5907a2b9ab6") -- Call of Duty: Modern Warfare 3 suitcase Italian
addappid(278317, 1, "26a7d17a842fedac832eb311de43053aee0572e451514ebe5abc100707ab2bf5") -- Call of Duty: Modern Warfare 3 suitcase Collection 1
addappid(278318, 1, "07221ac6457a4eb7bcfe15d69fe30dbe9a4c0fdd6e1b8ff7fa04a07b74cfd942") -- Call of Duty: Modern Warfare 3 suitcase Collection 2
addappid(278319, 1, "d6f4ea33c3ca3f19d04d0f3df0880c25b5c8bffa6c72075453808af6fb14e937") -- Call of Duty: Modern Warfare 3 suitcase Collection 3
addappid(278320, 1, "9633162e088aa0c357694ccbf2e54692adf4eac293c5e7942c53c759bcb737e5") -- Call of Duty: Modern Warfare 3 suitcase Collection 4

