-- Lua provided by RyzenAPI
-- Game: SWEET MILF

-- MAIN APPLICATION
addappid(1195030)
addappid(1195040)
addappid(1195050)
addappid(1195060)
addappid(1288180)
addappid(1318320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
addappid(1173650, 1, "0005867bc6b23fad6b1698c715f35db5e11a09a32f88eb113dbd67a820c56771") -- SWEET MILF
addappid(1173651, 1, "b086663d9b7ac1f6435ad79386dc808804efdbb176b8c4e0cd1a6ab741681ea4") -- SWEET MILF Content
addappid(1195030, 1, "e66a0620f4bdba76ca4716665decc7e80fdeaf868e1ed7006eae134e73417f2e") -- SWEET MILF -EpisodeManami- - SWEET MILF -Episode　Manami- (1195030) デポ
addappid(1195040, 1, "d265880f4c9cbf601c1d89fd3c262a337733f0e1aa9c90422c7c8b5406bb63c3") -- SWEET MILF -EpisodeRie- - SWEET MILF -Episode　Rie- (1195040) デポ
addappid(1195050, 1, "73431fa44397ab4067bf831bb3850af8500850a950a76fb25e76ab4795891d07") -- SWEET MILF -EpisodeSizue- - SWEET MILF -Episode　Sizue- (1195050) デポ
addappid(1195060, 1, "3bb86af3553b5509aabff5fe295b378ef5cfff65e6eb3ee5877d99c000329dae") -- SWEET MILF -EpisodeRumiko- - SWEET MILF -Episode　Ruriko- (1195060) デポ
addappid(1288180, 1, "5d15339436ccb10543af4ecfa25e904f25d1a76833890c997044bf0d1ca0d12a") -- SWEET MILF-Custume Set - Depot 1288180
addappid(1318320, 1, "91907bc77e034fc87a9ad0f387a2d5dfc8f2a8915d4fbe5bc6edf4d15f9cb77f") -- SWEET MILF -Complete version- - SWEET MILF -Complete version- (1318320) デポ

