-- Lua provided by RyzenAPI
-- Game: AppID 1173650

-- MAIN APPLICATION
addappid(1173650)
-- Game: addappid(1173650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173651, 1, "b086663d9b7ac1f6435ad79386dc808804efdbb176b8c4e0cd1a6ab741681ea4")
