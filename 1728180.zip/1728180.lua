-- Lua provided by RyzenAPI
-- Game: Astral Shipwright

-- MAIN APPLICATION
addappid(1728180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1728181, 1, "60e8b61df5784ffef313fa3d0f8519071398e471aa65e372272b72b3a7cf45bd")
addappid(1728182, 1, "e194b7a575531e8aa205b62845e80dc82c0836880ec064c12609a3dfb56f6424")

