-- Lua provided by RyzenAPI
-- Game: Lunistice

-- MAIN APPLICATION
addappid(1701800)
-- Game: addappid(1701800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701802,0,"0056dacdfeda6e8bb949d0caf420b6f228309d6253ffd4c0c0af1fb21e893e6d")
