-- Lua provided by RyzenAPI
-- Game: Shepherd of Light

-- MAIN APPLICATION
addappid(1106770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106771, 1, "96a6f0a275d17af387ca64f0b5bee72bb7dca62b0aed79e49cb93a46e6a479fd")
addappid(1106772, 1, "58b9e041dfa93861516b43161a67a72904287008434a3f1f0424836958b1986c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
