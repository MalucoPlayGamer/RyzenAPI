-- Lua provided by RyzenAPI 
-- Game: Shepherd of Light
addappid(1106770)
addappid(1106771, 1, "96a6f0a275d17af387ca64f0b5bee72bb7dca62b0aed79e49cb93a46e6a479fd")
addappid(1106772, 1, "58b9e041dfa93861516b43161a67a72904287008434a3f1f0424836958b1986c")
