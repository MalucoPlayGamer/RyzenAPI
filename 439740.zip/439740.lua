-- Lua provided by SkyAPI 
-- Game: Eclipsed
addappid(439740)
addappid(439741, 1, "ea1a3c1efefbf4d93901c2683aff87569dbab94f70cc1472db7034703d9fc8e5")
