-- Lua provided by RyzenAPI
-- Game: Eclipsed

-- MAIN APPLICATION
addappid(439740)

-- MAIN APP DEPOTS / PACKAGES
addappid(439741, 1, "ea1a3c1efefbf4d93901c2683aff87569dbab94f70cc1472db7034703d9fc8e5")

