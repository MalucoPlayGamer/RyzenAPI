-- Lua provided by RyzenAPI
-- Game: Eclipsed

-- MAIN APPLICATION
addappid(439740)

-- MAIN APP DEPOTS / PACKAGES
addappid(439741, 1, "ea1a3c1efefbf4d93901c2683aff87569dbab94f70cc1472db7034703d9fc8e5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
