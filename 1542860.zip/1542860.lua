-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Slime 2: Puzzle in the Dark Forest

-- MAIN APPLICATION
addappid(1542860)
-- Game: addappid(1542860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1542861, 1, "1527c0f30c352815b1b8d5c4570d341366a470922285cb6cad59d7ed57e140e1")
