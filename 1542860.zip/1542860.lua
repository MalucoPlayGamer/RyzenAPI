-- Lua provided by RyzenAPI
-- Game: Dungeon Slime 2: Puzzle in the Dark Forest

-- MAIN APPLICATION
addappid(1542860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1542861, 1, "1527c0f30c352815b1b8d5c4570d341366a470922285cb6cad59d7ed57e140e1")

