-- Lua provided by SkyAPI 
-- Game: Dungeon Slime 2: Puzzle in the Dark Forest
addappid(1542860)
addappid(1542861, 1, "1527c0f30c352815b1b8d5c4570d341366a470922285cb6cad59d7ed57e140e1")
