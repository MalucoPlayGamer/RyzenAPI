-- Lua provided by RyzenAPI
-- Game: Soulbringer

-- MAIN APPLICATION
addappid(283310)

-- MAIN APP DEPOTS / PACKAGES
addappid(283311, 1, "0a89c2cc2edfd24800376717cd9a5850778096978efb6a4f1bec3d3d83e66d97")

