-- Lua provided by RyzenAPI
-- Game: 690810

-- MAIN APPLICATION
addappid(690810)
-- Game: addappid(690810)

-- MAIN APP DEPOTS / PACKAGES
addappid(690811, 1, "b55eab61cdb29891953e769bff5c89aa15dce76aaeae0462e799a87b1a1f6510")
