-- Lua provided by RyzenAPI
-- Game: Killing Floor: Incursion

-- MAIN APPLICATION
addappid(690810)

-- MAIN APP DEPOTS / PACKAGES
addappid(690811, 1, "b55eab61cdb29891953e769bff5c89aa15dce76aaeae0462e799a87b1a1f6510")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
