-- Lua provided by RyzenAPI
-- Game: The Legend of Legacy HD Remastered - Art Book

-- MAIN APPLICATION
addappid(2733170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2733170,0,"1bccb6e34cd70b037e561ad92f51c9d4de37993e7ff1c55d3a5aa5589f068871")
