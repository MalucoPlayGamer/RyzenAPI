-- Lua provided by RyzenAPI
-- Game: Omega Agent

-- MAIN APPLICATION
addappid(461500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(461501, 1, "5ffa70b4f23963f97b4aada070c051d9f9f09e2dfd22316145540a11116a68d7")

