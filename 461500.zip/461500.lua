-- Lua provided by RyzenAPI
-- Game: Omega Agent

-- MAIN APPLICATION
addappid(461500)

-- MAIN APP DEPOTS / PACKAGES
addappid(461501, 1, "5ffa70b4f23963f97b4aada070c051d9f9f09e2dfd22316145540a11116a68d7")

