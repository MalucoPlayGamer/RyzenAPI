-- Lua provided by RyzenAPI
-- Game: Nightmares from the Deep 3: Davy Jones

-- MAIN APPLICATION
addappid(284810)

-- MAIN APP DEPOTS / PACKAGES
addappid(284811, 1, "763b18797b0a77fb200df26de52d235954b101c755faf87617d522d551248d6b")
addappid(284812, 1, "a2cab6ad165ff575bcecbc779d02b044e0adf6b609bcf8888a8c31527d3b0f6f")
addappid(284813, 1, "c5b92d1c5586fe8579e13b455090b6d9111ad931e1c6c1e03294145951180025")

