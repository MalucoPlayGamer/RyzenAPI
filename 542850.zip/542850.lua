-- Lua provided by RyzenAPI
-- Game: addappid(542850)

-- MAIN APPLICATION
addappid(542850)

-- MAIN APP DEPOTS / PACKAGES
addappid(542851, 1, "0e2446aa6a6602aa88ec9f92e23d8ab9436cca68edb726afa26bbd04e747117f")
