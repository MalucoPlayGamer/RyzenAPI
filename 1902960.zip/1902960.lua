-- Lua provided by RyzenAPI
-- Game: Lost Records: Bloom & Rage

-- MAIN APPLICATION
addappid(1902960)
addappid(1977350)
-- Game: addappid(1902960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1902961, 1, "abad4c4c537119525145d83f5b7fe9761125627d17fc04758be2de4d40de12ed")
