-- Lua provided by SkyAPI 
-- Game: Hero of the Kingdom III
addappid(772430)
addappid(772431, 1, "f15f5d60baba89f047b13e36559da0337deabaf2cb570e7fc865b491cece3dd7")
addappid(772432, 1, "c54cb3a1786139c0ba1d041b58b16e5b3a31d256f73f22589bfc32d4424b14d9")
addappid(772433, 1, "2c78fef69af35b823bce5e1a35d84f2ddff54eba4a170a4de81a99536e02c3f9")
addappid(772434, 1, "1f7df7b373a1a65c917a02581d37940664240ae8438449d2efc145d2d770f774")
