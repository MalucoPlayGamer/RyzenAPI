-- Lua provided by RyzenAPI
-- Game: Game: Ladra

-- MAIN APPLICATION
addappid(391180)
addappid(418541)
-- Game: addappid(391180)

-- MAIN APP DEPOTS / PACKAGES
addappid(391181, 1, "1da4c26a4ed6597ce50227b265d576685250880955a6fdf06f7f37a4588054aa")
