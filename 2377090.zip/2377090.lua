-- Lua provided by SkyAPI 
-- Game: Willow Guard
addappid(2377090)
addappid(2377091, 1, "9d6bc1b23bed717231800f0708e49325f1cb1600011070fc7cb22ff7a393f34f")
