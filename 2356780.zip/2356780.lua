-- Lua provided by RyzenAPI
-- Game: 2356780

-- MAIN APPLICATION
addappid(2356780)
-- Game: addappid(2356780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2356782,0,"7b6a14efc42db13c57345a4d149afca6f1a16389dc609a5a3c3ad4a85cc61c73")
addappid(2356783,0,"81ce7bfff474863adeb76261d7e151cdd6eb5fd86ce53d6f4e76520bf447cbdb")
addappid(2356784,0,"553e16a517cbe8a877d676827b2eae7dc49471ceb7af1c14894c104126615bbc")
