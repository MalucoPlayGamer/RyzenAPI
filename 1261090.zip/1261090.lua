-- Lua provided by RyzenAPI
-- Game: 1261090

-- MAIN APPLICATION
addappid(1261090)
addappid(1261091)
-- Game: addappid(1261090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1261092,0,"cbdf84add8192390fd29e2aea6477ec9e4a870d5c551145774a446a8c76c82f7")
