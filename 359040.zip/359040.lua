-- Lua provided by RyzenAPI
-- Game: Game: The Music Machine

-- MAIN APPLICATION
addappid(359040)
-- Game: addappid(359040)

-- MAIN APP DEPOTS / PACKAGES
addappid(359041, 1, "7949949116251548cc2f95993fdf7172321aac595842ca17e1d6f08160227cc9")
addappid(359130, 0, "a0771d246dc397a546bd0fc91f81bd8d1269cf9ba3deb25f3d5f7d961aeb92fc")
