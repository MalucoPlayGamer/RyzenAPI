-- Lua provided by RyzenAPI
-- Game: Is It Wrong To Try To Rescue Monster Girls From The Inquisition?

-- MAIN APPLICATION
addappid(1460070)
-- Game: addappid(1460070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460071, 1, "d367b6871e441e26120355abd93db499c5fa65b6c1643ae357f19b82c01a2174")
