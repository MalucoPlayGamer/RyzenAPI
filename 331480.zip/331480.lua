-- Lua provided by RyzenAPI
-- Game: Pinstripe

-- MAIN APPLICATION
addappid(331480)

-- MAIN APP DEPOTS / PACKAGES
addappid(331481, 1, "0fca83ecb0da3e8ea041da43c4d878a41aa8d4ae992ae604e882b932e28ec971")
addappid(331482, 1, "5cf9487b9e1e410233e590bb97d45bf6e691956667be828af875b6b763456828")
addappid(331483, 1, "4e927cf46803db0732576530801d699b04901c90ec9d202eccff405c282f2b68")
addappid(332740, 0, "320ff6f65682afa5a1ac01204704ff86a781dde86a0490001e671728e87faa03")
addappid(616440, 0, "ebed8178afbaabc563a3ea70619d4bcc341b32e51c62a7d9a5d2b4c3202807c7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
