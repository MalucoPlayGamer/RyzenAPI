-- Lua provided by RyzenAPI
-- Game: Enter the Gungeon

-- MAIN APPLICATION
addappid(311690)
addappid(457842)
addappid(457843)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(311691, 1, "cb41ea886018a0dbe571a47aae73942d257981af9625fdc08409463e67586a25")
addappid(311692, 1, "54ad494686956c1b1eaca1b08a62cfedb5acf0dd737fefd91e5202fbf3d669d5")
addappid(311693, 1, "01d88f2672b76cdae7db275c2052bcf297f19145b83cf9f0bc3f93a0d607a66e")
addappid(311694, 1, "5cf258b805c76c8b818f08f6a4979cfef7c5ef60973c074973acf2ac0f0af02e")
addappid(311695, 1, "ab3bc4a264c57e81563d745029e86f1e33a0a9c20cbd69005c333878935975fe")
addappid(457841, 0, "c652beff68c8a4b56f2d009550fc85a8be635f9822ceb8af21dc190e8e5392ff")
