-- Lua provided by RyzenAPI
-- Game: 1839530

-- MAIN APPLICATION
addappid(1839530)
-- Game: addappid(1839530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839531, 1, "482ceac14439d8bbefccf35fd6a5b68130d5ea37e7c2858e086721b86fa61748")
