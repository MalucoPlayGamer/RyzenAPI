-- Lua provided by RyzenAPI
-- Game: Tin Star

-- MAIN APPLICATION
addappid(375130)

-- MAIN APP DEPOTS / PACKAGES
addappid(375131, 1, "57dbc3a066c2b8f1e81d1d13e4459c08834ac56a2eba88613d23be1eb78d1a2f")

