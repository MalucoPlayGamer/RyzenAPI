-- Lua provided by RyzenAPI
-- Game: Game: AppID 1689250

-- MAIN APPLICATION
addappid(1689250)
-- Game: addappid(1689250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689251, 1, "8bf0e792e50fd8203b7943785a6bd6bc941c85f026218d80085f1558a41753eb")
