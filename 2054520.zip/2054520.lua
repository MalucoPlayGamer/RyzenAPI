-- 2054520's Lua and Manifest Created by Hubcap Manifest
-- Gawr Gura: Quest for Bread
-- Created: August 27, 2026 at 21:27:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2054520) -- Gawr Gura: Quest for Bread
-- MAIN APP DEPOTS
addappid(2054521, 1, "54725a9e1ba9fc369d5858d3e7c6f68cae69a47c164b8d1cb1bc2098890224e7") -- Depot 2054521
setManifestid(2054521, "7842906001319171169", 1350415092)