-- Lua provided by RyzenAPI
-- Game: Gawr Gura: Quest for Bread

-- MAIN APPLICATION
addappid(2054520) -- Gawr Gura: Quest for Bread

-- MAIN APP DEPOTS / PACKAGES
addappid(2054521, 1, "54725a9e1ba9fc369d5858d3e7c6f68cae69a47c164b8d1cb1bc2098890224e7") -- Depot 2054521

