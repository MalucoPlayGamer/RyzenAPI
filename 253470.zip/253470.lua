-- Lua provided by RyzenAPI
-- Game: Game: AppID 253470

-- MAIN APPLICATION
addappid(253470)
addappid(316920)
-- Game: addappid(253470)

-- MAIN APP DEPOTS / PACKAGES
addappid(253471, 1, "fa0aa5ffb4cd811913a4c0b5dae58678dbd6322cb195dce990f897f7a81e7f30")
addappid(270930, 0, "d4a77f1bbd57cd525526aba552407dac73f05cc1f7ef0cb776ce0a322bd1ac38")
addappid(292960, 0, "46590848223b701845fed7dd0e4b105cb868dc34e72f75def9259f2e2bbd7f53")
