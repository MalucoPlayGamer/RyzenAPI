-- Lua provided by RyzenAPI
-- Game: Real World Racing

-- MAIN APPLICATION
addappid(253470)
addappid(316920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(253471, 1, "fa0aa5ffb4cd811913a4c0b5dae58678dbd6322cb195dce990f897f7a81e7f30")
addappid(270930, 0, "d4a77f1bbd57cd525526aba552407dac73f05cc1f7ef0cb776ce0a322bd1ac38")
addappid(292960, 0, "46590848223b701845fed7dd0e4b105cb868dc34e72f75def9259f2e2bbd7f53")
