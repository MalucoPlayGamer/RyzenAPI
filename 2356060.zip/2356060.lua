-- Lua provided by RyzenAPI
-- Game: addappid(2356060)

-- MAIN APPLICATION
addappid(2356060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2356061, 1, "80114e572bb05356d101fa05f3532f5fed26b279873fc4dffc6a401092720acf")
