-- Lua provided by RyzenAPI
-- Game: Football Manager 2020 Touch

-- MAIN APPLICATION
addappid(1100620)
addappid(1100780)
addappid(1100781)
addappid(1100782)
addappid(1100783)
addappid(1100784)
addappid(1100785)
addappid(1100787)
addappid(1100788)
addappid(1100789)
addappid(1100790)
addappid(1100791)
addappid(1100792)
addappid(1100793)
addappid(1100794)
addappid(1100795)
addappid(1100796)
addappid(1100797)

-- MAIN APP DEPOTS / PACKAGES
addappid(1100620,0,"027d4e22bb73d64d212acc491c9d1c79d345b07390678602f52561124e33b1dd")
addappid(1100621,0,"7d8716242d38bd11b86b77322d784850fb953d829d942e04e3fb5cc1712d38bd")
addappid(1100622,0,"1a91a4fd9674958b33dad6adab68ec86bcb06b7a0a558913c1684fcbc340e8ac")
addappid(1100623,0,"259e28cd2f6b61d5b9823e727763b08fe82f03203f5e39e5ffed816ce22f2a14")

