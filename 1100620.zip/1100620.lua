-- Lua provided by RyzenAPI 
-- Game: Football Manager 2020 Touch
addappid(1100620)
addappid(1100621, 1, "7d8716242d38bd11b86b77322d784850fb953d829d942e04e3fb5cc1712d38bd")
addappid(1100622, 1, "1a91a4fd9674958b33dad6adab68ec86bcb06b7a0a558913c1684fcbc340e8ac")
addappid(1100623, 1, "259e28cd2f6b61d5b9823e727763b08fe82f03203f5e39e5ffed816ce22f2a14")
