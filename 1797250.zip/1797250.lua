-- Lua provided by RyzenAPI
-- Game: Block Collide

-- MAIN APPLICATION
addappid(1797250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797251, 1, "2bcc2f7c1a7689fdc42e44460246f19221c85beb81caa560bae50b65b768a77c")

