-- Lua provided by RyzenAPI 
-- Game: AppID 1154470
addappid(1154470)
addappid(1154471, 1, "6c30e3b5332fe97ac8eb4d153363f34932469155bbd366ae07e124cbc79d6da4")
addappid(1154472, 1, "1a973046e281f6e12eda484c64cc090807abda4b6d891ad51db6109d23260dbd")
