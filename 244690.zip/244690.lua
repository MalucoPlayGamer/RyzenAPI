-- Lua provided by RyzenAPI
-- Game: Face Noir

-- MAIN APPLICATION
addappid(244690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(244691, 1, "1dca97f954215f5e56ac2165e0960a20cb6972c575c9255836c5d115902b158f")

