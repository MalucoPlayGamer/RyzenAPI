-- Lua provided by SkyAPI 
-- Game: AppID 244690
addappid(244690)
addappid(244691, 1, "1dca97f954215f5e56ac2165e0960a20cb6972c575c9255836c5d115902b158f")
