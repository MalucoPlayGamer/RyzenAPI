-- Lua provided by RyzenAPI
-- Game: Game: AppID 244690

-- MAIN APPLICATION
addappid(244690)
-- Game: addappid(244690)

-- MAIN APP DEPOTS / PACKAGES
addappid(244691, 1, "1dca97f954215f5e56ac2165e0960a20cb6972c575c9255836c5d115902b158f")
