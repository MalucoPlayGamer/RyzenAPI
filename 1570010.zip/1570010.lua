-- Lua provided by RyzenAPI
-- Game: FAR: Changing Tides

-- MAIN APPLICATION
addappid(1570010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1570011, 1, "f3aa74143ab21ae7aed97c2ac67b8c6510b94a84a41f44157671da176d86303e")
