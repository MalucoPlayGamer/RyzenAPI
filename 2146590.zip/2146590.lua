-- Lua provided by SkyAPI 
-- Game: AppID 2146590
addappid(2146590)
addappid(2146591, 1, "6137cb612eaffcb328aa6b4bc9f1999e53054757b01fe47de603f75a85cf4028")
