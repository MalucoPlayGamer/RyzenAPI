-- Lua provided by RyzenAPI
-- Game: Death From Above The Original Soundtrack

-- MAIN APPLICATION
addappid(2434280)
-- Game: addappid(2434280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2434281, 1, "8d152f03dc4c50c8201b5be83c7fd7fcb303e4c31d6cf2f1b77ada096efd1f6e")
addappid(2434282, 1, "7997bf0d9cc6dd89663a6ef836956084672bda7160fa451bc77bec4ec7cbd123")
