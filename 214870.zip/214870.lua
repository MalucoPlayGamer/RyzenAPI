-- Lua provided by RyzenAPI
-- Game: Painkiller Hell & Damnation

-- MAIN APPLICATION
addappid(214870)

-- MAIN APP DEPOTS / PACKAGES
addappid(214871, 1, "6684ec1b205640f956e86273b88cc2c096cf68c37cc0ca28a42b91edfb08ca1f")
addappid(214882, 1, "f8bd0fa115ef1755c17ebccbca33d52eea5eb34ea8cb9024bbc5f637c65d6397")
addappid(214884, 1, "f86e9e9e40137218c2c28493d15872e28e54ff126db3923ca9d07ae8cbe023de")
addappid(214885, 1, "e098cdcdf6784d6ea42f6056c138e956c0814dac4386384875396f6384eddea9")
addappid(219134, 0, "57ea29d40db9862982055394c19d2934c9107c512f18c2611efcaface229c521")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(219130)
addappid(219131)
addappid(219133)
addappid(219135)
addappid(219136)
addappid(229190)
addappid(229210)
addappid(229230)
addappid(229250)
addappid(229270)
addappid(229290)
addappid(229310)
addappid(230010)
