-- Lua provided by RyzenAPI
-- Game: Game: S4U: CITYPUNK 2011 AND LOVE PUNCH Demo

-- MAIN APPLICATION
addappid(2994870)
-- Game: addappid(2994870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2994871, 1, "9bbe6efb8cbf23642b5f8d645ca40a2661b114c7de931ac900d2e8b1205e4317")
