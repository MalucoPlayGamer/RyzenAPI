-- Lua provided by RyzenAPI
-- Game: addappid(1070800)

-- MAIN APPLICATION
addappid(1070800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070801, 1, "c709b4bcf0aa870a84400928007f85c1f7fbe630638a378603d35de3fe2320ea")
