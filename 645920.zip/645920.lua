-- Lua provided by RyzenAPI
-- Game: Game: Dreamstones

-- MAIN APPLICATION
addappid(645920)
addappid(747410)
-- Game: addappid(645920)

-- MAIN APP DEPOTS / PACKAGES
addappid(645921, 1, "bf89db6dcf2e831c12ea98ee986f6bcc1216ebe9e14bd40d9d6aa7d5b8387569")
