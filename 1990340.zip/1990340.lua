-- Lua provided by RyzenAPI
-- Game: Game: Smash N' Crash

-- MAIN APPLICATION
addappid(1990340)
-- Game: addappid(1990340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990341, 1, "ed93c825b67fcfafa5761345e14a2a0773af4285078ffe9f91e97de47c4cd74f")
