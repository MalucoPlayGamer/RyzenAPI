-- Lua provided by RyzenAPI
-- Game: Far Cry 6 Demo

-- MAIN APPLICATION
addappid(2383690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383691, 1, "a3982501b20911c5b91ec6a0447f6fab4e7ed74797a35c1e68f0d366388d4aa6")
