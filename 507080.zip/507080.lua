-- Lua provided by RyzenAPI
-- Game: Game: AppID 507080

-- MAIN APPLICATION
addappid(507080)
-- Game: addappid(507080)

-- MAIN APP DEPOTS / PACKAGES
addappid(507081, 1, "0704251a69c29f715908237f7ae5914917a48c46225ac8ff1564cb07a8543ae8")
