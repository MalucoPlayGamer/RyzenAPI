-- Lua provided by RyzenAPI
-- Game: Game: HEART of CROWN Online

-- MAIN APPLICATION
addappid(1883000)
-- Game: addappid(1883000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883001, 1, "1c3d505d969c8e4cf548c03125a41f1b86027ebd612ef1314d6661084eb37e65")
