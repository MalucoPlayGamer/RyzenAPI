-- Lua provided by RyzenAPI
-- Game: Calibre 10 Racing

-- MAIN APPLICATION
addappid(266370)

-- MAIN APP DEPOTS / PACKAGES
addappid(266371, 1, "8cc178e8c66983b05f93696591053a3525a52f5f4334b6a495b8387b41908adf")

