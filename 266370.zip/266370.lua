-- Lua provided by RyzenAPI
-- Game: Calibre 10 Racing

-- MAIN APPLICATION
addappid(266370)

-- MAIN APP DEPOTS / PACKAGES
addappid(266371, 1, "8cc178e8c66983b05f93696591053a3525a52f5f4334b6a495b8387b41908adf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
