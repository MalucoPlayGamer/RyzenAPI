-- 4075900's Lua and Manifest Created by Hubcap Manifest
-- Flyra: FPV Drone Simulator
-- Created: August 27, 2026 at 10:28:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4075900) -- Flyra: FPV Drone Simulator
-- MAIN APP DEPOTS
addappid(4075901, 1, "8fe5ff2496df3b33bb45e35e1d03107827f583ad0a72168aa8e721da29eeff8a") -- Depot 4075901
setManifestid(4075901, "7449541439206346004", 27903336119)