-- Lua provided by RyzenAPI
-- Game: Flyra: FPV Drone Simulator

-- MAIN APPLICATION
addappid(4075900) -- Flyra: FPV Drone Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(4075901, 1, "8fe5ff2496df3b33bb45e35e1d03107827f583ad0a72168aa8e721da29eeff8a") -- Depot 4075901

