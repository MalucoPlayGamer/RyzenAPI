-- Lua provided by RyzenAPI
-- Game: addappid(1969960)

-- MAIN APPLICATION
addappid(1969960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969961, 1, "6553b8d9ebe09e0da7fcd1780e08c68019e9e6ff7250f6cc1072095946c8e503")
