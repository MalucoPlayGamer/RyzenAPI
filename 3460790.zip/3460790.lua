-- Lua provided by RyzenAPI 
-- Game: Hidden Skulls
addappid(3460790)
addappid(3460791, 1, "5c9a8eab76e2c2c2e4badec32be47efbe2d17ef719a5b9ad20022988c18c70fc")
