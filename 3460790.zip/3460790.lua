-- Lua provided by RyzenAPI
-- Game: 3460790

-- MAIN APPLICATION
addappid(3460790)
-- Game: addappid(3460790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3460791, 1, "5c9a8eab76e2c2c2e4badec32be47efbe2d17ef719a5b9ad20022988c18c70fc")
