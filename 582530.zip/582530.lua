-- Lua provided by RyzenAPI
-- Game: addappid(582530)

-- MAIN APPLICATION
addappid(582530)

-- MAIN APP DEPOTS / PACKAGES
addappid(582531, 1, "d2291c347b0d82dd3b16feaf7bed4e5dd379b70879a23bc1470ce855d1bb6e47")
