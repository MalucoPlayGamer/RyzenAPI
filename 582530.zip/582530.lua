-- Lua provided by RyzenAPI
-- Game: Wacky Spores: The Chase

-- MAIN APPLICATION
addappid(582530)

-- MAIN APP DEPOTS / PACKAGES
addappid(582531, 1, "d2291c347b0d82dd3b16feaf7bed4e5dd379b70879a23bc1470ce855d1bb6e47")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
