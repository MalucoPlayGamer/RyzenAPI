-- Lua provided by RyzenAPI
-- Game: Shapik: The Moon Quest

-- MAIN APPLICATION
addappid(1073810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1073811, 1, "a394548422f604daea72467ea236e8b7d9ae039992d1bfb5c91c181ccaa0c57f")
addappid(1073812, 1, "54993c8439d59df0343f43b5d6c6b23254cdc76c6409603652455996abed264a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
