-- Lua provided by RyzenAPI
-- Game: Volkstein

-- MAIN APPLICATION
addappid(763200)

-- MAIN APP DEPOTS / PACKAGES
addappid(763201, 1, "c665e636900068e99f8341639ece8cd0cd12644fba66a249c77dc2ff34428bff")

