-- Lua provided by RyzenAPI
-- Game: Devotion - Original Soundtracks

-- MAIN APPLICATION
addappid(1026010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1026011, 1, "69907a8097e1e8cfb554ae38ecbc06e306207108c766a0ab162c0141710046a1")
