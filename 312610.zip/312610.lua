-- Lua provided by RyzenAPI
-- Game: METAL SLUG X

-- MAIN APPLICATION
addappid(312610)
-- Game: addappid(312610)

-- MAIN APP DEPOTS / PACKAGES
addappid(312611, 1, "7f1d0f535b6ae360297a32d8be65cde7b69860a123f019983d3b56e37933df8a")
