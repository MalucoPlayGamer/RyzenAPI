-- Lua provided by RyzenAPI
-- Game: Achilles: Legends Untold

-- MAIN APPLICATION
addappid(1314000)
-- Game: addappid(1314000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1314001, 1, "f8ea6ebbef185079adc617c41c6c867f04dcd43446d42aed3ca43a18a39ef4f8")
