-- Lua provided by SkyAPI 
-- Game: AppID 1425880
addappid(1425880)
addappid(1425881, 1, "9f8f1a34e8bfaff91d1fa385a34eed09591e4541fde8a831b4bb45d7614231be")
