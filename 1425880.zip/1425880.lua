-- Lua provided by RyzenAPI
-- Game: 9 Monkeys of Shaolin: Prologue

-- MAIN APPLICATION
addappid(1425880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1425881, 1, "9f8f1a34e8bfaff91d1fa385a34eed09591e4541fde8a831b4bb45d7614231be")