-- Lua provided by RyzenAPI
-- Game: AppID 1425880

-- MAIN APPLICATION
addappid(1425880)
-- Game: addappid(1425880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1425881, 1, "9f8f1a34e8bfaff91d1fa385a34eed09591e4541fde8a831b4bb45d7614231be")
