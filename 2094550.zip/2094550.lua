-- Lua provided by RyzenAPI
-- Game: addappid(2094550)

-- MAIN APPLICATION
addappid(2094550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094553,0,"42838b993374ff650cdc278cdc7eb6f111a182b93ce6f8f1d1c1f0599373494e")
