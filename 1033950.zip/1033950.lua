-- Lua provided by RyzenAPI
-- Game: Lamentum

-- MAIN APPLICATION
addappid(1033950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033951, 1, "4f3c83acb481fca957682d230cbc64e05d8bc2df908a3b486502c9ab6e0f4a4a")
addappid(1033952, 1, "b8fe82d870681cd8fbf0ca6c15a18c22af25d75b7333afbe249c24d5a2f35cc4")
