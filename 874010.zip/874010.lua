-- Lua provided by RyzenAPI 
-- Game: aMAZE Classic: Inverted
addappid(874010)
addappid(874011, 1, "1d8c2f2ecd64afdaedc73c29379406e2e4cb49ed0f28cba7b8cb2ac57d701dd3")
