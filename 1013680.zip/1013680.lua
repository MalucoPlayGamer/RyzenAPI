-- Lua provided by RyzenAPI
-- Game: AppID 1013680

-- MAIN APPLICATION
addappid(1013680)
-- Game: addappid(1013680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013681, 1, "8bc8051051ce2368f31139b821b2a48c702e2eeef943cc3d7bfd3dc6543f4ff6")
