-- Lua provided by RyzenAPI
-- Game: AppID 1013680

-- MAIN APPLICATION
addappid(1013680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013681, 1, "8bc8051051ce2368f31139b821b2a48c702e2eeef943cc3d7bfd3dc6543f4ff6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
