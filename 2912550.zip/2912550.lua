-- 2912550's Lua and Manifest Created by Hubcap Manifest
-- Dark Scrolls
-- Created: June 22, 2026 at 23:12:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2912550) -- Dark Scrolls
-- MAIN APP DEPOTS
addappid(2912551, 1, "780c5357408d681ceb339335d711d3063dde0c01505c07197292e7bd2ab0c318") -- Depot 2912551
-- setManifestid(2912551, "6879286188599574270", 354013232)