-- Lua provided by RyzenAPI
-- Game: Dark Scrolls

-- MAIN APPLICATION
addappid(2912550) -- Dark Scrolls

-- MAIN APP DEPOTS / PACKAGES
addappid(2912551, 1, "780c5357408d681ceb339335d711d3063dde0c01505c07197292e7bd2ab0c318") -- Depot 2912551

