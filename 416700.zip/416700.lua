-- Lua provided by RyzenAPI
-- Game: Game: 5 Minutes Rage - Hatred Edition

-- MAIN APPLICATION
addappid(416700)
-- Game: addappid(416700)

-- MAIN APP DEPOTS / PACKAGES
addappid(416701, 1, "a73217e271f9eb04120eededbe4cb8222bed75b4f1d4db8ff20c59ea3d4379d2")
addappid(416702, 1, "038dc70cb67fe56f787678f710a055b3c414ae43637aa721c216ce6e80f61adc")
addappid(416703, 1, "7f37bb1bca7b44a7a2294ff611e967804a470f017f95a3134a700ac54e146c2d")
addappid(416704, 1, "5f132e8f01dd319eb23f9e2e95881110b279fe2f7f25480a70d891e0d3a45640")
addappid(416705, 1, "49e79796eaf54031896e981780be29c1a41538f05fc60ea665d4e2c75dde2914")
