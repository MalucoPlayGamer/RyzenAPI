-- Lua provided by RyzenAPI
-- Game: 704970

-- MAIN APPLICATION
addappid(704970)
-- Game: addappid(704970)

-- MAIN APP DEPOTS / PACKAGES
addappid(704971, 1, "01b26e779a5ab27eff6cc7fc65366e4cef87d5c85619c386443fc720aa4249be")
