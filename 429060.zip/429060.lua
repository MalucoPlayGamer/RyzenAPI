-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(429060)
-- Game: addappid(429060)

-- MAIN APP DEPOTS / PACKAGES
addappid(429062,0,"d2ed40bc5b7391969ce3f1aeee17b1c67786ee85b17278ddfa8ec4e702f779fe")
