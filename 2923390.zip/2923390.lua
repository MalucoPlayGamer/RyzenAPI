-- Lua provided by RyzenAPI
-- Game: addappid(2923390)

-- MAIN APPLICATION
addappid(2923390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2923391, 1, "d9a7fde689395bd32548f53725ff825360147ba02295ff58d9e021b10b458cbb")
