-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Time Fantasy: Farm and Fort

-- MAIN APPLICATION
addappid(1468930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468930,0,"5757ce6c497e1f5f2a72b29a878576259f401f2a86e94be50ebf07313936b9a3")

