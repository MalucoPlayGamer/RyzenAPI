-- Lua provided by RyzenAPI
-- Game: ENDLESS Legend™ 2

-- MAIN APPLICATION
addappid(3407390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3407391, 1, "5c0d8a9608dff91b54b7ad2d588e18d229a20929f21793eb8378891a5c2ba08c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3760760)
