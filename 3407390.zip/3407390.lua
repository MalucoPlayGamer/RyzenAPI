-- Lua provided by RyzenAPI
-- Game: 3407390

-- MAIN APPLICATION
addappid(3407390)
-- Game: addappid(3407390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3407391, 1, "5c0d8a9608dff91b54b7ad2d588e18d229a20929f21793eb8378891a5c2ba08c")
