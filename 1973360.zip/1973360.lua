-- Lua provided by SkyAPI 
-- Game: AppID 1973360
addappid(1973360)
addappid(1973361, 1, "6b05a2f5b11c498806a54f678f2a4a788fb751d2e8839ea412a74d1aa272ca81")
addappid(1973362, 1, "5d4672e50ba0e160dc2f766d96e050647438bb05a47bde4f1ac51e4a4a8303e0")
