-- Lua provided by RyzenAPI
-- Game: 1506420

-- MAIN APPLICATION
addappid(1506420)
-- Game: addappid(1506420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506421, 1, "68db354f293f57d49d773c60bf47005df6687d450e76d45ebbcc20c7c8000693")
