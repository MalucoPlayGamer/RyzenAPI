-- Lua provided by RyzenAPI
-- Game: 1421700

-- MAIN APPLICATION
addappid(1421700)
-- Game: addappid(1421700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1421703,0,"7566ad03b8fa162307c127471f839fbdddcbeb0be7ca082c2972905b7fc47037")
