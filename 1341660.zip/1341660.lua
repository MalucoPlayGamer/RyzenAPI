-- Lua provided by RyzenAPI
-- Game: ClickMonster

-- MAIN APPLICATION
addappid(1341660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341661, 1, "ff336e320009ccb8114e283b5bc27c065db412e1a4df8298528a2331b83f1a9e")

