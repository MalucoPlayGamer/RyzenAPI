-- Lua provided by RyzenAPI
-- Game: addappid(1632880)

-- MAIN APPLICATION
addappid(1632880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632881, 1, "9bee579cecda92fb621447b236801d50d6043f892508d3e8787001a1be9ff4bc")
