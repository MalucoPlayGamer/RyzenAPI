-- Lua provided by RyzenAPI
-- Game: OVIS LOOP

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2226730, 1, "81141592002d86d4a9edd1603e7c97ce64bbaffffcb3f0fb824ee20709f84960") -- OVIS LOOP
addappid(2226731, 1, "e024ff155fb9f3ce8e387c1c4d4fb860d5f5959d17c8d99d6edbd005e25816a4") -- Depot 2226731

