-- Lua provided by RyzenAPI
-- Game: Game: Saloon Simulator: Prologue

-- MAIN APPLICATION
addappid(2419710)
-- Game: addappid(2419710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2419711, 1, "cd3e6acc07500eaba6b30c27d0dfa8b87b20e94608749d8e175c7d50df31dfdd")
