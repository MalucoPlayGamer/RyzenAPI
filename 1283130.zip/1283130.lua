-- Lua provided by RyzenAPI
-- Game: Micro Platformer

-- MAIN APPLICATION
addappid(1283130)
