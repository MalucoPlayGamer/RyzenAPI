-- Lua provided by RyzenAPI
-- Game: 2415040

-- MAIN APPLICATION
addappid(2415040)
-- Game: addappid(2415040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2415041, 1, "723435df95694746843522477951e55d5c5682a93dbcfae7d3a0cdfeea7a451e")
