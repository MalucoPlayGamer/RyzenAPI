-- Lua provided by RyzenAPI
-- Game: 1460050

-- MAIN APPLICATION
addappid(1460050)
-- Game: addappid(1460050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460051, 1, "404502ec457a70a691e47077d024b31aef33f0ec524cd0d860faa0bb8f56bd3d")
