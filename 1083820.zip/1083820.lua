-- Lua provided by RyzenAPI
-- Game: Eternal Dread 2

-- MAIN APPLICATION
addappid(1083820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1083821, 1, "a8e5f26ee097b93b008e7bee611ea810b5c1dd2e6bafa51a433fc1b79f6929f1")
