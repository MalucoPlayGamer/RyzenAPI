-- Lua provided by RyzenAPI
-- Game: OmniFootman

-- MAIN APPLICATION
addappid(1076230)
addappid(1287570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076231, 1, "7846d18df144c186e7ce9f3b661a9f8c776f6d1d45512aa74a092998d8cbd7e7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
