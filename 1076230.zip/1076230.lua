-- Lua provided by RyzenAPI
-- Game: OmniFootman

-- MAIN APPLICATION
addappid(1076230)
addappid(1287570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076231, 1, "7846d18df144c186e7ce9f3b661a9f8c776f6d1d45512aa74a092998d8cbd7e7")
