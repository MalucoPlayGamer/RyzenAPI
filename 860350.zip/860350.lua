-- Lua provided by RyzenAPI
-- Game: 860350

-- MAIN APPLICATION
addappid(860350)
-- Game: addappid(860350)

-- MAIN APP DEPOTS / PACKAGES
addappid(860351, 1, "3a60d4c51ce8719c919acc1b754a879ff8fd4ab5555abc268e3999bba4e2de77")
