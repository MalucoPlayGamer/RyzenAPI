-- Lua provided by RyzenAPI
-- Game: AppID 981800

-- MAIN APPLICATION
addappid(981800)
addappid(1056210)
addappid(1056220)
-- Game: addappid(981800)

-- MAIN APP DEPOTS / PACKAGES
addappid(981801, 1, "3cb05857da1e8363b8bcf812f0a9489d0fbd3981cf03789f6ef8a491864cc041")
