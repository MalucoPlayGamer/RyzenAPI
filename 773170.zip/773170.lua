-- Lua provided by RyzenAPI
-- Game: Close the Window!

-- MAIN APPLICATION
addappid(773170)
-- Game: addappid(773170)

-- MAIN APP DEPOTS / PACKAGES
addappid(773171, 1, "bdfd765f1b7ff2adfc0e12267aa259ad69c099ebaacbac8ddc01d0031618fb48")
