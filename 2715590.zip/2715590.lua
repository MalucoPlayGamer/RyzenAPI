-- Lua provided by RyzenAPI
-- Game: Game: TryAndLove

-- MAIN APPLICATION
addappid(2715590)
-- Game: addappid(2715590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715591, 1, "1be9c5b16b50c8bdc4fd0b46adf36a26405b0db8cfb65f9aa0064a5d750a255c")
addappid(2715592, 1, "89c46c5aca3f8e90c32aa2a53a8f8bac6b147a954a27a134534a8a7541cfef5a")
addappid(2715593, 1, "d406b4192ffd5d457fdee97f86b6e0dc66a78551a3889560a7d9323277387792")
