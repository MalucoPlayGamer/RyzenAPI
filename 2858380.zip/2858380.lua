-- Lua provided by RyzenAPI
-- Game: Egregore

-- MAIN APPLICATION
addappid(2858380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2858381, 1, "7881949d2e90751ed4f3b2b3df66c288fedfa1fddfca339c2d8f6cae0c4cef79")
addappid(2858382, 1, "0b29e41efde094b2e73399da50acd4ef82024c50f77a313b07cd92edb3da938b")

