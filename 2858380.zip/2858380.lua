-- Lua provided by SkyAPI 
-- Game: Egregore
addappid(2858380)
addappid(2858381, 1, "7881949d2e90751ed4f3b2b3df66c288fedfa1fddfca339c2d8f6cae0c4cef79")
addappid(2858382, 1, "0b29e41efde094b2e73399da50acd4ef82024c50f77a313b07cd92edb3da938b")
