-- Lua provided by RyzenAPI
-- Game: Corrupted: Dawn of Havoc

-- MAIN APPLICATION
addappid(2007770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2007771, 1, "a196aa07c558049945a65c796ef1a4472ecdc19eb547424a1c5017baf9911ab3")
