-- Lua provided by RyzenAPI
-- Game: AppID 3167220

-- MAIN APPLICATION
addappid(3167220)
-- Game: addappid(3167220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3167221, 1, "7f49528ba9c5fe775b245b09cb0544ae4b5442afd7689733cf0c5d1d86aaf034")
