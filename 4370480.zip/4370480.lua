-- Lua provided by RyzenAPI
-- Game: Burnstation

-- MAIN APPLICATION
addappid(4370480) -- Burnstation

-- MAIN APP DEPOTS / PACKAGES
addappid(4370481, 1, "dca448d9a79508d8f6321f0d20ec7ce3756fa18ad08345ae154aee06ef137352") -- Depot 4370481
addappid(4370482, 1, "f4b398bca12b3ca6f4fb27e14456ea84e4481ece674b04315ea30724e54e44f4") -- Depot 4370482
addappid(4370483, 1, "a96616a239950d047db6231fb605c1fc533f010aadf9138479d2340314ab1650") -- Depot 4370483

