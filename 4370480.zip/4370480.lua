-- 4370480's Lua and Manifest Created by Hubcap Manifest
-- Burnstation
-- Created: August 12, 2026 at 22:54:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4370480) -- Burnstation
-- MAIN APP DEPOTS
addappid(4370481, 1, "dca448d9a79508d8f6321f0d20ec7ce3756fa18ad08345ae154aee06ef137352") -- Depot 4370481
setManifestid(4370481, "7163247888628532639", 874967106)
addappid(4370482, 1, "f4b398bca12b3ca6f4fb27e14456ea84e4481ece674b04315ea30724e54e44f4") -- Depot 4370482
setManifestid(4370482, "8569901635636109351", 1268692480)
addappid(4370483, 1, "a96616a239950d047db6231fb605c1fc533f010aadf9138479d2340314ab1650") -- Depot 4370483
setManifestid(4370483, "7559125977472734373", 1221296154)