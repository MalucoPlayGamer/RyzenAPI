-- Lua provided by RyzenAPI
-- Game: Little Dog

-- MAIN APPLICATION
addappid(703040)

-- MAIN APP DEPOTS / PACKAGES
addappid(703041, 1, "6342376111aa725c3197feb6c2c7ce2729c762a2eafbd6f9064dbb3616380e83")
