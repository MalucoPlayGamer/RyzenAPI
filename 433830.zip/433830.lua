-- Lua provided by RyzenAPI
-- Game: Game: Rescue From Goblin Deep

-- MAIN APPLICATION
addappid(433830)
-- Game: addappid(433830)

-- MAIN APP DEPOTS / PACKAGES
addappid(433831, 1, "52fa0a4f561ebbfb2e44fec92bf3d645502ecb3806caab32232ac558c0e0ff86")
