-- Lua provided by RyzenAPI
-- Game: Raatihuone

-- MAIN APPLICATION
addappid(1045130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045131, 1, "3e9cd63e896e790b7d503146262eb30837ce515579697c24be11379229dd0e68")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
