-- Lua provided by RyzenAPI
-- Game: Raatihuone

-- MAIN APPLICATION
addappid(1045130)
-- Game: addappid(1045130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045131, 1, "3e9cd63e896e790b7d503146262eb30837ce515579697c24be11379229dd0e68")
