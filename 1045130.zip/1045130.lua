-- Lua provided by RyzenAPI 
-- Game: Raatihuone
addappid(1045130)
addappid(1045131, 1, "3e9cd63e896e790b7d503146262eb30837ce515579697c24be11379229dd0e68")
