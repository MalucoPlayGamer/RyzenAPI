-- Lua provided by RyzenAPI
-- Game: Craball

-- MAIN APPLICATION
addappid(3744220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3744221, 1, "6b2f3378cfc204890345f5db2763b393f2a8a7fe91db318b408887033d79ab08")
