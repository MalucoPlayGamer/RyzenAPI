-- Lua provided by RyzenAPI
-- Game: Game: EasyMMD

-- MAIN APPLICATION
addappid(2344030)
-- Game: addappid(2344030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2344031, 1, "d57be559d746b403bf99c5ac130da091d24118934c993a41a1c69b8a228f166d")
