-- Lua provided by RyzenAPI
-- Game: Serial Cleaner

-- MAIN APPLICATION
addappid(522210)
-- Game: addappid(522210)

-- MAIN APP DEPOTS / PACKAGES
addappid(522214,0,"14a00acfd66f1972d9e61ec946c2cb0f9f08bfaed149a0e16199432fc1cf1f1f")
addappid(522215,0,"a391037c609c8e73f7a40dfc665269d1b5b687802ae2faa512420b3b378560d3")
addappid(522216,0,"dd663dfbf6f81fd85aa6be89b6b96fbc5e740dcbd33493799887e50abf14f741")
addappid(653230,0,"5a6640ea4a7a9b485104a217c4e142abc72a6c92bceebf007d76964adc5a3553")
