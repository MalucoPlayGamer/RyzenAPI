-- Lua provided by RyzenAPI
-- Game: 1202690

-- MAIN APPLICATION
addappid(1202690)
-- Game: addappid(1202690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202691, 1, "3da30e69657b2f3b2ab434ce2a86f8bb331691ff615436cd27314fc716f246db")
