-- Lua provided by RyzenAPI
-- Game: AppID 1202690

-- MAIN APPLICATION
addappid(1202690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202691, 1, "3da30e69657b2f3b2ab434ce2a86f8bb331691ff615436cd27314fc716f246db")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1757780)
