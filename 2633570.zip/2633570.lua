-- Lua provided by RyzenAPI 
-- Game: United 1944 Multiplayer Demo
addappid(2633570)
addappid(2633571, 1, "7801034465720361d50bb9657b1af68d4e412a57e79ce9f98db22cdebb48551a")
