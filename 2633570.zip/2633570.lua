-- Lua provided by RyzenAPI
-- Game: 2633570

-- MAIN APPLICATION
addappid(2633570)
-- Game: addappid(2633570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2633571, 1, "7801034465720361d50bb9657b1af68d4e412a57e79ce9f98db22cdebb48551a")
