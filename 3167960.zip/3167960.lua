-- Lua provided by RyzenAPI
-- Game: Real Pharmacy Simulator

-- MAIN APPLICATION
addappid(3167960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3167961, 1, "2f1b67cfd9c3e1072ae10ffb6738ba570b9fdea59f31dc8f2e151378db85d9c5")
