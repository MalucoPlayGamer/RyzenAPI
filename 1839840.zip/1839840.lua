-- Lua provided by RyzenAPI 
-- Game: Memory Puzzle - Mystery Mermaids
addappid(1839840)
addappid(1839841, 1, "f6482f657cabc69be59354aeefb97cf94d813f1790d31aafcea7d2e098aae024")
addappid(1840260, 0, "c1d9c26dbfa396601a300418f0cd1164ae15d0da7bd1433aab144841bbe01fa6")
