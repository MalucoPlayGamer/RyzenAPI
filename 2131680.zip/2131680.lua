-- Lua provided by RyzenAPI
-- Game: METAL GEAR & METAL GEAR 2: Solid Snake

-- MAIN APPLICATION
addappid(2131680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2131681, 1, "e5b5860d0f5df9eb8eaee3a850ed74d1af440183694c9b7b8ba794d61ded777b")
addappid(2131682, 1, "899494a75b3ed1b05ae78b85ee635ed8fbbb534ef6999cf5f70e7970d780e130")

