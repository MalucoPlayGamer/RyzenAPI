-- Lua provided by RyzenAPI
-- Game: 1715290

-- MAIN APPLICATION
addappid(1715290)
-- Game: addappid(1715290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1715291, 1, "56160dda07282e60ed95c41f1b093e7894457f9ce22a96e366cd73f033ddb299")
