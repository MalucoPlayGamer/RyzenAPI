-- Lua provided by SkyAPI 
-- Game: Transformation Tycoon
addappid(1799850)
addappid(1799851, 1, "7d1769330907e0d6eb937f6fa7cb80fa613f4f67269797c6cea58d3027ac1f7c")
