-- Lua provided by SkyAPI 
-- Game: FleetCOMM
addappid(367340)
addappid(367341, 1, "6e213d97831e09db238f75d0066dc37a6ee98c68cb09aad712e1594a3a21a75b")
addappid(376860, 0, "136a11acee23196cd09b390fd75830c54027611d9aafd69e2b98dfb62c2fc830")
