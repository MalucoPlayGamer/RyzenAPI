-- Lua provided by RyzenAPI
-- Game: Coffee For Robots

-- MAIN APPLICATION
addappid(2146680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146681, 1, "f36ee11a60e467dd0824aac1e64b1b041185b93900b8a92988287c7a4621d33d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
