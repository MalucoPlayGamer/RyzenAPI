-- Lua provided by SkyAPI 
-- Game: Coffee For Robots
addappid(2146680)
addappid(2146681, 1, "f36ee11a60e467dd0824aac1e64b1b041185b93900b8a92988287c7a4621d33d")
