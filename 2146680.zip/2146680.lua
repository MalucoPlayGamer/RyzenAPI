-- Lua provided by RyzenAPI
-- Game: Coffee For Robots

-- MAIN APPLICATION
addappid(2146680)
-- Game: addappid(2146680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146681, 1, "f36ee11a60e467dd0824aac1e64b1b041185b93900b8a92988287c7a4621d33d")
