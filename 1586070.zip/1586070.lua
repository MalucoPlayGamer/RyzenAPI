-- Lua provided by RyzenAPI
-- Game: Wild Runs

-- MAIN APPLICATION
addappid(1586070)
-- Game: addappid(1586070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1586071, 1, "dedd8109f0b0480a5c871f239814d84909c3f400c7560535e6764e9ea10f79f8")
