-- Lua provided by RyzenAPI
-- Game: Wolf's Fury

-- MAIN APPLICATION
addappid(619270)
addappid(1062190)
-- Game: addappid(619270)

-- MAIN APP DEPOTS / PACKAGES
addappid(619271, 1, "328201ae5c97432dbee9ac70d7b42e0b42ff7b6570e8e90db55e3d06ee378349")
addappid(619272, 1, "6feb3790066fe9a535f0cae5485b8daad6f15b11e33b53969ede0fec9a1f89b8")
addappid(619273, 1, "4691e175bcf10530118ff2729d263d140689c5a810bccaa90fb76ebed46595b6")
addappid(619274, 1, "7f166230f2b4140cc51ebcc52e7a1a320736d0bddbc3fdc2754ad68e33630b82")
