-- Lua provided by RyzenAPI
-- Game: Moonstone Island

-- MAIN APPLICATION
addappid(1658150)
addappid(2650440)
addappid(2692250)
addappid(2747460)
addappid(2945440)
addappid(3039030)
addappid(3048910)
addappid(3146820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1658151, 1, "a0087e864bcd67b31d88085e60a8b344db7098cbe6d6730e9b6ebf40cb025e3f")
addappid(1658152, 1, "4df035403c83e43ffdd7162dd43b9a0238d8c76d3b4225c98981c268d1703671")
addappid(1658153, 1, "7193a0c74850c092dc1d90624c45c4e50216a78a699658d64d5fff26e3c8d8f7")
addappid(2577920, 0, "19d1545edc1525760b1ab0a4b3e8ddc86ecee76712b30fef6235cd3fbb7f8af5")
addappid(2581340, 0, "4b9863518cd49b73ec6241ef7d465e9d1bb1d9f3d8505e3ed778a407ec5bbd23")

