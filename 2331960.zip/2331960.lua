-- Lua provided by RyzenAPI
-- Game: CyberCum: Pussy Attack❗️

-- MAIN APPLICATION
addappid(2331960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2331961, 1, "2a82b4a508e1a8b72bb9d5a14921053dbdcfcd5eccdf46db63c212c92b351a66")

