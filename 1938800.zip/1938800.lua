-- Lua provided by RyzenAPI
-- Game: Alone in the Dark Prologue

-- MAIN APPLICATION
addappid(1938800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1938801, 1, "86adf23b59fbe53326af3e95805f4ec2bebbb33f27cd674b50b06bfb05b54ceb")

