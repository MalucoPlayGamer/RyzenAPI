-- Lua provided by RyzenAPI
-- Game: addappid(46280)

-- MAIN APPLICATION
addappid(46280)

-- MAIN APP DEPOTS / PACKAGES
addappid(46281, 1, "1b598cecf2c0bc9e4926398c000f5ab37637550e4dfd4d6989eb1916f6ffef15")
addappid(46283, 1, "8e5e676b41699d807de76bbc8f6962c0d4e57d2c3383e49c6f939dbcd9117900")
