-- Lua provided by RyzenAPI
-- Game: 1686870

-- MAIN APPLICATION
addappid(1686870)
-- Game: addappid(1686870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1686871, 1, "627a9806d739383b4338580233d1bf6dd51dbe5faceb01904e76ea432e2196fe")
