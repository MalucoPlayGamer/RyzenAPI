-- Lua provided by RyzenAPI
-- Game: setManifestid(589762,"8392322837644063559")

-- MAIN APPLICATION
addappid(589760)
-- Game: addappid(589760)

-- MAIN APP DEPOTS / PACKAGES
addappid(589762,0,"6c97d473db49f9dd698796d8c6e4b791a52a30589737649537d1fd3e74ff7cdd")
