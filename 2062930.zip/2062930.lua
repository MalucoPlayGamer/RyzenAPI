-- Lua provided by RyzenAPI
-- Game: 2062930

-- MAIN APPLICATION
addappid(2062930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2062932,0,"44f9e998ae7c9bdff1fd5c4262ed04cf7df045506c7a23d5d4349308e4cc17fc")

