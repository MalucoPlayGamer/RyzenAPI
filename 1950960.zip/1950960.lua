-- Lua provided by RyzenAPI
-- Game: Lord of Rigel Soundtrack

-- MAIN APPLICATION
addappid(1950960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1950962,0,"13990d6d448d3204017ef891c517d02302395dd6e7d02efdf78ad49a9bbe5d9f")

