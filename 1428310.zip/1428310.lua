-- Lua provided by RyzenAPI
-- Game: The Test: Final Revelation

-- MAIN APPLICATION
addappid(1428310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428311, 1, "c51b643282ea21f4b792e0f4a6dc28610571e1f61ea599253943c4637a1fb427")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
