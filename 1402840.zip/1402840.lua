-- Lua provided by RyzenAPI
-- Game: Game: OshiRabu: Waifus Over Husbandos Original Soundtrack

-- MAIN APPLICATION
addappid(1402840)
-- Game: addappid(1402840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1402841, 1, "c522f8b0d64dd6d49b29997208a9726eb8f07804ff1b2d22248e184fe9b96167")
addappid(1402844, 1, "642f8ed61620e06919f2ae33c9ce17abf59a4629e1ba0ce5e8407d2353b78f98")
addappid(1402845, 1, "65f3fdad47f2bd4a597b40c5c32ca601bf46a1d1687457131b6addac048e4994")
addappid(1402848, 1, "d745eb8593fce7edf5498ca8ae7bba6988a6b397fb9c5c47e7d9a6f04efc13d6")
