-- Lua provided by RyzenAPI
-- Game: Darksiders II - Mortis Pack

-- MAIN APPLICATION
addappid(215816)

-- MAIN APP DEPOTS / PACKAGES
addappid(215816,0,"3408ec283c48d7c3c8431e39c5d16ccdee9bcc598c8656d0e9edc2dcf6f5a14e")

