-- Lua provided by RyzenAPI
-- Game: Ticy Adventure Club

-- MAIN APPLICATION
addappid(2135690)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2241890)
