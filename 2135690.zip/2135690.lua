-- Lua provided by RyzenAPI
-- Game: Ticy Adventure Club

-- MAIN APPLICATION
addappid(2135690)
addappid(2241890)

