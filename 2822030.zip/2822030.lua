-- Lua provided by RyzenAPI
-- Game: addappid(2822030)

-- MAIN APPLICATION
addappid(2822030)
addappid(3053700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2822031, 1, "ecf155e89a4add57921fb5d3955a1b5fff11338d5125dc43e9484ae29ab61b30")
addappid(2822032, 1, "12688a44001d23de71f33e910d01dbc7a08a7e30a7eca24884fd333fd754224e")
