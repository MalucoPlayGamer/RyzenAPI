-- Lua provided by RyzenAPI
-- Game: Tower Princess: Knight's Trial

-- MAIN APPLICATION
addappid(1788110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1788111, 1, "8315e4565cd50ba3059c4034d150de29437a910a06dd04bc44dda98b75213313")

