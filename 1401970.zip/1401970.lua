-- Lua provided by SkyAPI 
-- Game: Galaxy Kart VR
addappid(1401970)
addappid(1401971, 1, "9bdee947f4b102e5e1d72da411a2114b4a90ac2b3f4eaeba92493f2068a23ad4")
