-- Lua provided by RyzenAPI
-- Game: AppID 580310

-- MAIN APPLICATION
addappid(580310)
-- Game: addappid(580310)

-- MAIN APP DEPOTS / PACKAGES
addappid(580311, 1, "3702edcc38950d488bd3f0d86a6e8895105884646c14292ec18b5b27b479cd49")
addappid(580312, 1, "4eed1bb7366f661e25b15e6fe1f1ead2141e441b37f15ca74c15be428b1b34db")
