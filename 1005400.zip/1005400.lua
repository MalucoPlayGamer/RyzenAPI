-- Lua provided by RyzenAPI
-- Game: Star Drift Evolution

-- MAIN APPLICATION
addappid(1005400)
-- Game: addappid(1005400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005401, 1, "45b7fdd2762a7d984debbfefd222499848699c081e21884d526cdea27c2c8b3e")
