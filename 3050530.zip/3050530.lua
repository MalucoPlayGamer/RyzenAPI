-- Lua provided by RyzenAPI 
-- Game: Shokudo Underworld
addappid(3050530)
addappid(3050531, 1, "294b7df43e7d2562da87aabd6137313799278197987bcb4d426e947a7408d0be")
