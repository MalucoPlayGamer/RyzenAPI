-- Lua provided by RyzenAPI
-- Game: Howling Village: Echoes

-- MAIN APPLICATION
addappid(1739850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1739851, 1, "32e1b1095fa161ff4fad7c1c9e020f26d69493192474790c2b684b67e4601a2e")
