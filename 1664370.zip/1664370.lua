-- Lua provided by RyzenAPI
-- Game: The Teleport

-- MAIN APPLICATION
addappid(1664370)
-- Game: addappid(1664370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664371, 1, "31484cc825229e11954cf2348fc06a3d5c3e8b1f9c0b1de76b72df4638a60949")
