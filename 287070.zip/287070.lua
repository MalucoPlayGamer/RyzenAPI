-- Lua provided by RyzenAPI
-- Game: Game: AppID 287070

-- MAIN APPLICATION
addappid(287070)
-- Game: addappid(287070)

-- MAIN APP DEPOTS / PACKAGES
addappid(287071, 1, "6fd6a16af1ed5ba239d75f2b0efd3d09bfa23636c6064f3b97d089e1aad9a76f")
