-- Lua provided by RyzenAPI
-- Game: AppID 287070

-- MAIN APPLICATION
addappid(287070)

-- MAIN APP DEPOTS / PACKAGES
addappid(287071, 1, "6fd6a16af1ed5ba239d75f2b0efd3d09bfa23636c6064f3b97d089e1aad9a76f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(287090)
addappid(287091)
addappid(287092)
addappid(287093)
addappid(287094)
addappid(287095)
