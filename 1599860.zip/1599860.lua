-- Lua provided by RyzenAPI
-- Game: Game: Vanaris Tactics

-- MAIN APPLICATION
addappid(1599860)
-- Game: addappid(1599860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1599861, 1, "74ee8c11aabf0dd6d4f30b98f285ffdaba827dc7a9259386b92ed19d23242b70")
