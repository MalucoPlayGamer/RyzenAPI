-- Lua provided by RyzenAPI
-- Game: Armor Clash 3

-- MAIN APPLICATION
addappid(1114830)
-- Game: addappid(1114830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114831, 1, "08415a5b8ebf2552c9042921998677e2d1a7d4558d59766f2ab6e068c34b692d")
