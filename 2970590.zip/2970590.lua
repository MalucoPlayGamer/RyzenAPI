-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Aerosoft - Airport Melilla

-- MAIN APPLICATION
addappid(2970590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2970590,0,"a6c865e7eb1b283e2635c7de9973342bb0613374172b2f64b371e53bf1449560")
