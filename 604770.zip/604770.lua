-- Lua provided by RyzenAPI
-- Game: Dark Prospect

-- MAIN APPLICATION
addappid(604770)

-- MAIN APP DEPOTS / PACKAGES
addappid(604771,0,"8be070c9a0d0ea76209e797592bc96b320d5927e8501d6060ece6aadac45ad7a")

