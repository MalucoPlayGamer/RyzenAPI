-- Lua provided by RyzenAPI
-- Game: AppID 2187740

-- MAIN APPLICATION
addappid(2187740)
-- Game: addappid(2187740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187741, 1, "249433be5dac4d46fc91aab3a43f00558dc0f455efb289c72391c15ad58e0398")
addappid(2187742, 1, "f93bd9d31544ec1a70e4dba05bcdfdc2305f2569d335115081222b92dae0f400")
addappid(2187743, 1, "f3620581ca71460e29b3a9b84f7ff5faa7de99ca022bea9b67d4d05d0f3fabcb")
