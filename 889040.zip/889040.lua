-- Lua provided by RyzenAPI
-- Game: FPV Air 2

-- MAIN APPLICATION
addappid(889040)
-- Game: addappid(889040)

-- MAIN APP DEPOTS / PACKAGES
addappid(889041, 1, "481c03872ea7a08fecf1013ed822a6e976da45b72eb2a59e764b5fbce99d47e4")
