-- Lua provided by RyzenAPI
-- Game: AppID 35720

-- MAIN APPLICATION
addappid(35720)
addappid(218530)

-- MAIN APP DEPOTS / PACKAGES
addappid(35721, 1, "ebac61308162169f056ce6f37f4428237c04c35f32d14504fb092025703b38fe")
addappid(35722, 1, "65545e46c67c553b7d97f72251814eb912e3c403fcf9a5adeb8b26ae6d2f10e0")
addappid(35723, 1, "fa8c88076e86680d29cc8d4b11610259f4161f0a902ff7c5399202080d5eacac")
addappid(35725, 1, "56a862348c1d6ebd2c6d1e4f4b39da2f532487f923c0a98a27f25df204aa7aa3")
addappid(35726, 1, "e08d642e19c8b6846b1c07ccf0a72a44948455368ab23bae2157c5082f5962cd")
addappid(35727, 1, "3abcc00517f2107b68a33718d9fd3912c9756438c9a3a6e721d8fc79be1289fc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
