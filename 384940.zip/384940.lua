-- Lua provided by RyzenAPI
-- Game: Game: Magical Brickout

-- MAIN APPLICATION
addappid(384940)
-- Game: addappid(384940)

-- MAIN APP DEPOTS / PACKAGES
addappid(384941, 1, "4b4e7a83b15ec271d9fe21076fca08aaccbe35b3c64f66c8d6e95ab0a121f9ad")
addappid(384942, 1, "a6a793f634896071d4477142d844c5950395da6b0aedd498b3a90f905097296c")
addappid(384943, 1, "a82154e35253a766eaf341400e1876a748ef11886d980fcc3534e9456839a532")
