-- Lua provided by RyzenAPI
-- Game: 3D Hentai SeaBattle

-- MAIN APPLICATION
addappid(1822020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1822021, 1, "36c775dbdda5a36c44d61fa35561b87218524a9e2980daf1595dfeb69b87442e")
