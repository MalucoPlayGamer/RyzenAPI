-- Lua provided by SkyAPI 
-- Game: Project Hardline
addappid(2386580)
addappid(2386581, 1, "cb1cc2fb84ef192e811e9554d56450762da85d3ebbeed3a14bbd00dfb85f8783")
addappid(2386582, 1, "cbdf7adb43193a898f900437469b0dd0fb0fcad36f3e6a65b941b4ceb1b18070")
