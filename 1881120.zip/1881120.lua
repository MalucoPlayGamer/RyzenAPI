-- Lua provided by RyzenAPI
-- Game: 1881120

-- MAIN APPLICATION
addappid(1881120)
addappid(2663810)
-- Game: addappid(1881120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881121, 1, "b4a69ecd0cefbcf11da832190c08ba52706b51f77f6a774fc0a83e4300aa4e74")
