-- Lua provided by RyzenAPI
-- Game: Titan Station

-- MAIN APPLICATION
addappid(1881120)
addappid(2663810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1881121, 1, "b4a69ecd0cefbcf11da832190c08ba52706b51f77f6a774fc0a83e4300aa4e74")

