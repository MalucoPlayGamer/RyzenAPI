-- Lua provided by RyzenAPI
-- Game: Game: Mystopia

-- MAIN APPLICATION
addappid(3012780)
-- Game: addappid(3012780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3012781, 1, "6b98a02646f2545af12d9e2cf897e6b251b614f2bede186e212777908b37c100")
