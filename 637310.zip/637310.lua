-- Lua provided by RyzenAPI 
-- Game: Stream Service
addappid(637310)
addappid(637311, 1, "1a7156e09acca75b520c31acc6bace47cf87b49a16af4be721cfd97d5dac8370")
