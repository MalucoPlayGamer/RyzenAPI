-- Lua provided by RyzenAPI
-- Game: The Whisperer

-- MAIN APPLICATION
addappid(1697940)
-- Game: addappid(1697940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1697941, 1, "fa906f159d6ffd086e834437f80684536cf0033e7b42a3c3e140f8900d603259")
