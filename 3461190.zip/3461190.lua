-- Lua provided by RyzenAPI
-- Game: Magatch

-- MAIN APPLICATION
addappid(3461190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3461191, 1, "230fb5ce0f907bf948ab99b7547effcf1e8defc2d6e6c2d06cd42b7afc64424f")

