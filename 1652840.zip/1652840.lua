-- Lua provided by RyzenAPI
-- Game: Game: VR SEX

-- MAIN APPLICATION
addappid(1652840)
-- Game: addappid(1652840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652841, 1, "875bf002730fb9f1483f3e0f458c00501b1c3130784a9aab851c1c58341b4480")
