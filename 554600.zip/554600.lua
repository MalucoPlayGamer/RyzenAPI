-- Lua provided by RyzenAPI
-- Game: Learn Japanese To Survive! Katakana War

-- MAIN APPLICATION
addappid(554600)

-- MAIN APP DEPOTS / PACKAGES
addappid(554601, 1, "8fed36e95f69675b11f0b1cf5c8fd3fb4e65502f79e60a2a0ba71c468c9f0692")
addappid(554602, 1, "16190efbaffe409c838a1f97ba8e59c2d7b23d860942b4d8652b24b8456fcafd")
addappid(575500, 0, "cdae27a7cd3a9a913b02745e173de878564c7770b8ae0b1aca768ac7e75f00b1")
addappid(575501, 0, "2793fbd84442f00de01af9d8c653fb933a5ce763afd8009f84c77f127292f043")

