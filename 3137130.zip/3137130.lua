-- Lua provided by RyzenAPI
-- Game: My Dictator Stalin Can't Be This Cute ?!

-- MAIN APPLICATION
addappid(3137130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3137131, 1, "5017a4f3509314ed9f49ad79047226307e80b4e4d74a3419f808884f611d113e")

