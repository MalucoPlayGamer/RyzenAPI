-- Lua provided by RyzenAPI
-- Game: Game: Jump Hero: Beginning

-- MAIN APPLICATION
addappid(1396390)
-- Game: addappid(1396390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396391, 1, "f7d44e791d011d98538480eda1ea5b6cc3b53591f58d55950fc10a0970b19e42")
