-- Lua provided by RyzenAPI
-- Game: 3280460

-- MAIN APPLICATION
addappid(3280460)
-- Game: addappid(3280460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3280461, 1, "31e60bd339d8422c9dbaad6469156ad3bcc7b6cd7992effff786218abc78ffa4")
