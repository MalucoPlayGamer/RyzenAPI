-- Lua provided by RyzenAPI
-- Game: Game: Campus Fantasy

-- MAIN APPLICATION
addappid(3380110)
-- Game: addappid(3380110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3380111, 1, "b7fa09bdb9062c3005213297eadee8be6bda9a67a6c7372947f8347e34a785d5")
