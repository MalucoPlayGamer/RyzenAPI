-- Lua provided by RyzenAPI 
-- Game: Campus Fantasy
addappid(3380110)
addappid(3380111, 1, "b7fa09bdb9062c3005213297eadee8be6bda9a67a6c7372947f8347e34a785d5")
