-- Lua provided by RyzenAPI
-- Game: Campus Fantasy

-- MAIN APPLICATION
addappid(3380110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3380111, 1, "b7fa09bdb9062c3005213297eadee8be6bda9a67a6c7372947f8347e34a785d5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
