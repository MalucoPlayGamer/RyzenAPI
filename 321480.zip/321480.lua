-- Lua provided by RyzenAPI 
-- Game: Sigils of Elohim
addappid(321480)
addappid(321481, 1, "9b56ddc72768f282487011bf9481b7e7864b64f8f0e071961d17db9b4778de8f")
addappid(321482, 1, "651795252ac980cfcfe378a90babaddcb45f15efb695aa15ada9d77f35514526")
addappid(321483, 1, "484a8232d8e3d0d0b13ec2d6c9489564fb04667baa2a82475ef94ed9dc49c724")
