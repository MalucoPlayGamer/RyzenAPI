-- Lua provided by RyzenAPI 
-- Game: TRADER LIFE SIMULATOR 2
addappid(2231740)
addappid(2231741, 1, "c186874934a8373ba8b9085203e43929906eff59ba9c538ad25902356fbeef81")
