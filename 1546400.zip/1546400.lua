-- Lua provided by RyzenAPI
-- Game: GigaBash

-- MAIN APPLICATION
addappid(1546400)
-- Game: addappid(1546400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546401, 1, "204960045ed3c99ef55795d7304c0d2fb3b2c548b70fabf87559565b88696b18")
