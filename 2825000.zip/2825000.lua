-- Lua provided by RyzenAPI
-- Game: 2825000

-- MAIN APPLICATION
addappid(2825000)
-- Game: addappid(2825000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2825001, 1, "b8e590fadde89cba6ed10a23581f18f02e89f73f628433aa4d139dd6965412fb")
