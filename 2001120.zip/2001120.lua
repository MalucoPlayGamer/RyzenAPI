-- Lua provided by RyzenAPI
-- Game: Split Fiction

-- MAIN APPLICATION
addappid(2001120) -- Split Fiction
addappid(3050960) -- Split Fiction - Full Game Unlock

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2001121, 1, "27f6aac2ce9d80ad4ed8fe3710d306ae108f00ddcf005d47ecf7bfa2a258964c") -- Depot 2001121

