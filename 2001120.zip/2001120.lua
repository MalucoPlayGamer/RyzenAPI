-- Lua provided by RyzenAPI
-- Game: Split Fiction

-- MAIN APPLICATION
addappid(2001120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2001121, 1, "27f6aac2ce9d80ad4ed8fe3710d306ae108f00ddcf005d47ecf7bfa2a258964c")
