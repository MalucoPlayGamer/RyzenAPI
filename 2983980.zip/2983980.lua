-- Lua provided by RyzenAPI
-- Game: AppID 2983980

-- MAIN APPLICATION
addappid(2983980)
-- Game: addappid(2983980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983981, 1, "e95e26ca461126e31c419591d40a96a8c1ccc3f941bf76d1ae6db455be75f983")
