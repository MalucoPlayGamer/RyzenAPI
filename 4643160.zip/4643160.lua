-- Lua provided by RyzenAPI
-- Game: Mining Grounds

-- MAIN APPLICATION
addappid(4643160) -- Mining Grounds

-- MAIN APP DEPOTS / PACKAGES
addappid(4643161, 1, "f6a0653bea40f19a9cdb53aafc2fefdac593945f4f77407a87fa160b2c4bcd07") -- Depot 4643161
addappid(4643162, 1, "28c477c7e0672adc0cb5d1acb6fe7126e72e1da0c54ed24d4e3d736cd2b52f8c") -- Depot 4643162
addappid(4643163, 1, "85ae6b325f70b790969f096f9ba8e4ca13d1411f955260fa120aa001664f77b0") -- Depot 4643163

