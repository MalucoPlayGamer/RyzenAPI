-- Lua provided by RyzenAPI
-- Game: rooMaze

-- MAIN APPLICATION
addappid(575830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(575831, 1, "f03a4457de590fe3d11016c96aa282bb6936931c3fae0c730185029577639ecc")
addappid(575832, 1, "e0f8965195b700d1748e33ed06b503964f2f34ed98fc747549b6c6efddf3dc29")

