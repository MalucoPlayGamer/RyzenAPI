-- Lua provided by RyzenAPI 
-- Game: rooMaze
addappid(575830)
addappid(575831, 1, "f03a4457de590fe3d11016c96aa282bb6936931c3fae0c730185029577639ecc")
addappid(575832, 1, "e0f8965195b700d1748e33ed06b503964f2f34ed98fc747549b6c6efddf3dc29")
