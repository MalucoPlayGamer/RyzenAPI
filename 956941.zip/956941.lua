-- Lua provided by RyzenAPI
-- Game: Jia Chong - Officer Ticket / 賈充使用券

-- MAIN APPLICATION
addappid(956941)

-- MAIN APP DEPOTS / PACKAGES
addappid(956941,0,"e241be9ac9650224ae69977e15d8edbaca710f77a00fba3551b779c762ac1190")

