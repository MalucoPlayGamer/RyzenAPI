-- Lua provided by RyzenAPI
-- Game: Deus Ex: Human Revolution - The Missing Link

-- MAIN APPLICATION
addappid(201280)

-- MAIN APP DEPOTS / PACKAGES
addappid(201281, 1, "638ef8cd258b18800d6bc6f6b967d3e389678c8d92c6d4fa309576c2d67d4134")
addappid(201282, 1, "c763392bcc450ef593b1875a9fbf4fc8f92cbcd2e5224e4fb65b48ebfa9e274b")
addappid(201283, 1, "ca8f826ca47de9c151e0b348e4dbf061d9e4f4c6bedd50bbd1616ac2d09e013e")
addappid(201284, 1, "7929dbac0199ebd5c70b2c2030b402cf6a43f9160844e1f07264490f30a33d0b")
addappid(201285, 1, "ab1b6dea4b57d1947fb35434be742987ac246847c80acbfc82669c7cbdde2dd3")
addappid(201286, 1, "00fa959629ba40dbf7a5b69e5cde819d9cce4c09b907370497747fbe9871bec2")
addappid(201287, 1, "71e126eed38cc01d36407d9d0fe0a0e75ba153903dda14eee8dcec701aaacb20")
addappid(201288, 1, "4b665232eb1b6aa4fb25cfcc973c25bf6e22c4f89769980d9decc62279b84285")
addappid(201289, 1, "abb692f87b97dd8a608bb75defc275826d4a9b03e001947340965a4a41b71f1f")
