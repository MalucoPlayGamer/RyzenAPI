-- Lua provided by RyzenAPI
-- Game: Arma 2: Operation Arrowhead - Dedicated Server

-- MAIN APPLICATION
addappid(33935)

-- MAIN APP DEPOTS / PACKAGES
addappid(33932,0,"07e07b7a6d5f04dbf42162d9ebb710c7ab43b98ec52af69e10b6becb72eda6fa")

