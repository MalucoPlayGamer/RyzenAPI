-- Lua provided by RyzenAPI
-- Game: AppID 715680

-- MAIN APPLICATION
addappid(715680)

-- MAIN APP DEPOTS / PACKAGES
addappid(715681, 1, "b2626279db11a33d275ad1c514913a183b2087ba13c3fee73a71ac7e60895f0d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
