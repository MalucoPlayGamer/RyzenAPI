-- Lua provided by RyzenAPI
-- Game: 715680

-- MAIN APPLICATION
addappid(715680)
-- Game: addappid(715680)

-- MAIN APP DEPOTS / PACKAGES
addappid(715681, 1, "b2626279db11a33d275ad1c514913a183b2087ba13c3fee73a71ac7e60895f0d")
