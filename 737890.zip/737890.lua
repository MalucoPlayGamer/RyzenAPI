-- Lua provided by SkyAPI 
-- Game: AppID 737890
addappid(737890)
addappid(737891, 1, "7f5900324ef9226a76c271b1e3df81da27a748bd5ea96403912127f529d5ae57")
