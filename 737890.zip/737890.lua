-- Lua provided by RyzenAPI
-- Game: Catastronauts

-- MAIN APPLICATION
addappid(737890)

-- MAIN APP DEPOTS / PACKAGES
addappid(737891, 1, "7f5900324ef9226a76c271b1e3df81da27a748bd5ea96403912127f529d5ae57")

