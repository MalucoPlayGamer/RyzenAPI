-- Lua provided by SkyAPI 
-- Game: MiSide Soundtrack
addappid(3404450)
addappid(3404451, 1, "401cfca91341369711b16540df763140e99621c2331d8ebfc736045c290dbf98")
