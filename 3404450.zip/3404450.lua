-- Lua provided by RyzenAPI
-- Game: MiSide Soundtrack

-- MAIN APPLICATION
addappid(3404450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3404451, 1, "401cfca91341369711b16540df763140e99621c2331d8ebfc736045c290dbf98")
