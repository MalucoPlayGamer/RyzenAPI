-- Lua provided by RyzenAPI
-- Game: Celaria

-- MAIN APPLICATION
addappid(1081650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081651, 1, "0b5b54627b1982acbc230b055ae07cbf9cb502ffd9406d62ffca40cc6cf4b47e")

