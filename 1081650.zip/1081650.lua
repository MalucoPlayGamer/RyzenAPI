-- Lua provided by RyzenAPI
-- Game: Celaria

-- MAIN APPLICATION
addappid(1081650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081651, 1, "0b5b54627b1982acbc230b055ae07cbf9cb502ffd9406d62ffca40cc6cf4b47e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
