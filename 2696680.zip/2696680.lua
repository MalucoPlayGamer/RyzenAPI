-- Lua provided by RyzenAPI
-- Game: BABAVA's Playspace

-- MAIN APPLICATION
addappid(2696680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696681, 1, "f1a00f4ad68d0e76e63367a31ac9c5c5c66320f892d0b99514028c88df24fa03")

