-- Lua provided by RyzenAPI
-- Game: BABAVA's Playspace

-- MAIN APPLICATION
addappid(2696680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2696681, 1, "f1a00f4ad68d0e76e63367a31ac9c5c5c66320f892d0b99514028c88df24fa03")

