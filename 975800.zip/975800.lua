-- Lua provided by RyzenAPI
-- Game: addappid(975800)

-- MAIN APPLICATION
addappid(975800)

-- MAIN APP DEPOTS / PACKAGES
addappid(975801, 1, "51e8c871cfc423f05d291a36bf54c03ec5a7942386fbab324c06c669e60caf0a")
