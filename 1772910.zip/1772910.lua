-- Lua provided by RyzenAPI
-- Game: Dead District: Survival

-- MAIN APPLICATION
addappid(1772910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1772911, 1, "40fd39f1f93a5feb08dd14b695e7e268b546c5b480903b75e674c3be4b3a61df")

