-- Lua provided by RyzenAPI
-- Game: Dead District: Survival

-- MAIN APPLICATION
addappid(1772910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1772911, 1, "40fd39f1f93a5feb08dd14b695e7e268b546c5b480903b75e674c3be4b3a61df")
