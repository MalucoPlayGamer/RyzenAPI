-- Lua provided by RyzenAPI
-- Game: Game: I Am Legion: Stand Survivors

-- MAIN APPLICATION
addappid(3109580)
-- Game: addappid(3109580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3109581, 1, "26fd25bacad89c9d9480c88f1deb7f1c694b6e54eb101e3bf2f5a3e62b725f8c")
