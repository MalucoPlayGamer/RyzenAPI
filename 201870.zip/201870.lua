-- Lua provided by RyzenAPI
-- Game: Assassin's Creed® Revelations

-- MAIN APPLICATION
addappid(201870)
addappid(201877)
addappid(228981)
addappid(228982)

-- MAIN APP DEPOTS / PACKAGES
addappid(201871, 1, "8174e101496f03e7544b945add7c99908e744b0c0b2b7182f69e5c408692f082")
addappid(201872, 1, "9ef78f51c49e94cee4c9aea09dabfc753646cd124809429590a467b53cd232e5")
addappid(201873, 1, "e340422eaaff220ae2823c05e9a039d9ba4f8fa68b8e32eff7219def9b6a941a")
addappid(201882, 1, "9da8a3de98388a48fca6702689b9b4bbbf67af576b632ee04e08b98f303efdd2")
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(201878)
addappid(201879)
addappid(201880)
addappid(201881)
