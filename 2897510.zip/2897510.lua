-- Lua provided by RyzenAPI 
-- Game: ココロシャッフル - Spirit Swap -
addappid(2897510)
addappid(2897511, 1, "afa2b91bf743306bc3f7ff65e52ce43c4fad8ee95a190113653337b328828094")
