-- Lua provided by RyzenAPI
-- Game: Vector Race

-- MAIN APPLICATION
addappid(1511250)
-- Game: addappid(1511250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511251, 1, "23bf39b3d7fe199db559579d81d49b37d3a43cb8774eab3e8641e92d1c5175e2")
