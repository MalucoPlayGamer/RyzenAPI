-- Lua provided by RyzenAPI
-- Game: addappid(290810)

-- MAIN APPLICATION
addappid(290810)

-- MAIN APP DEPOTS / PACKAGES
addappid(290811, 1, "14815ddc03305aa4a470fc103f6f3f9120736196043b7f6c367e8d87c316aca3")
