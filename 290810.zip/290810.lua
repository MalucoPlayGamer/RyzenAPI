-- Lua provided by RyzenAPI
-- Game: Colossal Kaiju Combat™: Kaijuland Battles

-- MAIN APPLICATION
addappid(290810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(290811, 1, "14815ddc03305aa4a470fc103f6f3f9120736196043b7f6c367e8d87c316aca3")

