-- Lua provided by RyzenAPI
-- Game: System Shock® 2 (1999)

-- MAIN APPLICATION
addappid(238210)

-- MAIN APP DEPOTS / PACKAGES
addappid(238211, 1, "20ed3421411e6fb016e2e40eb67fc1ce516c6d35689d048d69eeecba29ed69c1")
addappid(238212, 1, "6a8dace3bad8940518c7527559aab80c26b29956d6e422167f8a28c3943c9a09")
addappid(238213, 1, "773b20a379961280d39bae4186f2aca3c2c3270fc62792829cdc60b601f91609")
addappid(238214, 1, "fa8760d8f7e2bd9d472cc4927c04404994d1cfca51c8dda692729a85150a40e6")
addappid(238215, 1, "c5914d2a2118133683f470b521c819e6f6b366b87b4b94458c48acf5a7e98231")
addappid(238216, 1, "d1bc05ba04c4cf4972e64d2690d2ed2af9fe3897dec93a92518145f451c46cc5")
addappid(238217, 1, "66b819eff654773b243bd6aea160f8caa2859ff79c61503236ebb103d4873a0b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
