-- Lua provided by RyzenAPI
-- Game: 姉恋ごっこ - Siblings Role-play -

-- MAIN APPLICATION
addappid(2262040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2262041, 1, "e6e1210aa49c8e1841915470d9342f906718fe601aa95dd2b811ab145880ac62")
