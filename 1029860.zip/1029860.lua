-- Lua provided by RyzenAPI
-- Game: Game: AppID 1029860

-- MAIN APPLICATION
addappid(1029860)
-- Game: addappid(1029860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029861, 1, "64045b38371fe06c6c55b9c4abf0db3541d6d4be027b64413dc4457adf62ecb9")
