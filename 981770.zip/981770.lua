-- Lua provided by RyzenAPI
-- Game: SENRAN KAGURA Reflexions

-- MAIN APPLICATION
addappid(981770)
addappid(1070600)
addappid(1070601)
addappid(1070602)
addappid(1070603)
addappid(1070604)
addappid(1070605)
addappid(1070606)
addappid(1070660)
addappid(1070661)
addappid(1070662)
addappid(1070663)
addappid(1070664)
addappid(1070700)
addappid(1070701)
addappid(1070702)
addappid(1070703)
addappid(1070704)
addappid(1070705)
addappid(1070706)
addappid(1070707)
addappid(1071460)

-- MAIN APP DEPOTS / PACKAGES
addappid(981771,0,"f8b53e48a0fb89fb84d75a2e292ecccd44fd0ea8d8a2926a199a3952b6a4f135")

