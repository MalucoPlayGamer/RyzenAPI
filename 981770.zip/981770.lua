-- Lua provided by RyzenAPI
-- Game: Game: AppID 981770

-- MAIN APPLICATION
addappid(981770)
-- Game: addappid(981770)

-- MAIN APP DEPOTS / PACKAGES
addappid(981771, 1, "f8b53e48a0fb89fb84d75a2e292ecccd44fd0ea8d8a2926a199a3952b6a4f135")
