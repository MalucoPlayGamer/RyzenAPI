-- Lua provided by RyzenAPI
-- Game: StrangerZ

-- MAIN APPLICATION
addappid(2293600)
addappid(2533390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293601, 1, "9b40aa64ca4facd63ca4e3f69d39dc3cfd4c66c7356b28697bde3c6bbd594a3c")
