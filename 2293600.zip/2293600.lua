-- Lua provided by RyzenAPI
-- Game: StrangerZ

-- MAIN APPLICATION
addappid(2293600)
addappid(2533390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293601, 1, "9b40aa64ca4facd63ca4e3f69d39dc3cfd4c66c7356b28697bde3c6bbd594a3c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
