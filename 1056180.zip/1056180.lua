-- Lua provided by RyzenAPI
-- Game: Cathedral

-- MAIN APPLICATION
addappid(1056180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056181, 1, "42e63958f84fbc0c2277d09631105b5d133387f7dd6e31367752143ef03f61cb")
addappid(1056182, 1, "69167135df9d7c5e9c02727944f12bfbb3c1ccf9334d369663aed11727205c1a")
addappid(1056183, 1, "066ec2d8b06c128615ec66eb5142ee925ab3fb6b5487124acb5da935a6d7e8bb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
