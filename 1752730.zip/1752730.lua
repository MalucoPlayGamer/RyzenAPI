-- Lua provided by RyzenAPI
-- Game: Billy Bumbum: A Cheeky Puzzler

-- MAIN APPLICATION
addappid(1752730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752731, 1, "ed089dcfe1c0a6a76d041c1777f45e02d41de91ed7d67b82b23de0c41d9491d7")

