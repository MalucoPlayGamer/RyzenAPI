-- Lua provided by RyzenAPI
-- Game: addappid(1526180)

-- MAIN APPLICATION
addappid(1526180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526181, 1, "894ff5569e46dc82e565deb42c39a242f50309b296cb0ad9b257b24ccad8edf1")
