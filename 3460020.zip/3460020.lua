-- Lua provided by RyzenAPI
-- Game: Game: 幻想症 Fantasy illness

-- MAIN APPLICATION
addappid(3460020)
-- Game: addappid(3460020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3460021, 1, "fc7e9bc3ef80d60cd84a286a296f5fa85ee90d7051c87581efa30bf4cefdecbb")
