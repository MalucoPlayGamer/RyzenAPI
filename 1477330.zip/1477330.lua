-- Lua provided by RyzenAPI
-- Game: Game: Soulestination

-- MAIN APPLICATION
addappid(1477330)
-- Game: addappid(1477330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477331, 1, "4354b5293c40db77974ffc7bcc2cbbfe36c5d8550c654c25758eaaae4988b2a1")
addappid(1477332, 1, "972b56120a5c65c5ab6d94b2ca39cf7039141ff3d54919a4b6b1f4ff3f8da5f2")
addappid(1477333, 1, "6aaaf64dd461c08e7b9e9c4de916c577eefdbc5be392ae997007ab76b1066209")
