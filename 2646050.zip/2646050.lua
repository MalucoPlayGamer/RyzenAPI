-- Lua provided by RyzenAPI
-- Game: 2646050

-- MAIN APPLICATION
addappid(2646050)
-- Game: addappid(2646050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646051, 1, "5063078418cc94616e99f8c453eb16a74b8b13770bde84af02111efc079eccb8")
