-- Lua provided by SkyAPI 
-- Game: PIP X
addappid(2273630)
addappid(2273631, 1, "bc39e901487e5d18f69ad808c676d70007c705c75d3231e40e57a5431c421d37")
