-- Lua provided by RyzenAPI
-- Game: 769920

-- MAIN APPLICATION
addappid(769920)
-- Game: addappid(769920)

-- MAIN APP DEPOTS / PACKAGES
addappid(769921, 1, "b8a2ccf626fb91b5ba38e4aa429c934e96ecbaf6f10562820e16412c2ec95ccb")
