-- Lua provided by RyzenAPI 
-- Game: AppID 354280
addappid(354280)
addappid(354281, 1, "69cfb22e16d3425b9fccee15b2f4f16c4387a77bc43fbaf2cae2a88b630a167b")
