-- Lua provided by RyzenAPI
-- Game: AppID 354280

-- MAIN APPLICATION
addappid(354280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(354281, 1, "69cfb22e16d3425b9fccee15b2f4f16c4387a77bc43fbaf2cae2a88b630a167b")

