-- Lua provided by RyzenAPI
-- Game: Engine Evolution 2021

-- MAIN APPLICATION
addappid(1589770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1589771, 1, "82691a0e2eb97991fe1a36e7b81690e76db146d029852b1ccc6e0281c320c2ae")

