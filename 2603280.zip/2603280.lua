-- Lua provided by RyzenAPI
-- Game: Polygon Fantasy Battle Simulator

-- MAIN APPLICATION
addappid(2603280)
-- Game: addappid(2603280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2603281, 1, "003477c8c09fd265aed862d659d25139021070513a02aae0019e2d5e64341557")
