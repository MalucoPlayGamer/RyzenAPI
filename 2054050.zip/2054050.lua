-- Lua provided by SkyAPI 
-- Game: Magic vs Zombies
addappid(2054050)
addappid(2054051, 1, "0ead804a9c6d0822e3967ff2d5fa43ea78c9b882ddc2029d44465cd2294ad912")
