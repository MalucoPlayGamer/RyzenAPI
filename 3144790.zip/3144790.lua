-- Lua provided by RyzenAPI
-- Game: Game: Ara: History Untold Official Game Soundtrack

-- MAIN APPLICATION
addappid(3144790)
-- Game: addappid(3144790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3144791, 1, "c61b244d062bbd0134123562396d4422cfb720588d1f0d750d4df98ee1227211")
