-- Lua provided by RyzenAPI
-- Game: HALP!

-- MAIN APPLICATION
addappid(485230)
-- Game: addappid(485230)

-- MAIN APP DEPOTS / PACKAGES
addappid(485232,0,"b234a198084fc8ca995e11a6b355e726e3bdb95668430153849b21050d46bb5f")
