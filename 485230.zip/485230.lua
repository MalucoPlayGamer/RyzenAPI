-- Lua provided by RyzenAPI
-- Game: HALP!

-- MAIN APPLICATION
addappid(485230)

-- MAIN APP DEPOTS / PACKAGES
addappid(485232,0,"b234a198084fc8ca995e11a6b355e726e3bdb95668430153849b21050d46bb5f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
