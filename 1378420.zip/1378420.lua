-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Krachware User Interface Material

-- MAIN APPLICATION
addappid(1378420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378420,0,"af4214255f6bb94693772303f36885ad244ac4ca412a6a6356d92e53189b7579")

