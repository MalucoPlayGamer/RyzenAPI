-- Lua provided by RyzenAPI
-- Game: Game: Scarlet Tower

-- MAIN APPLICATION
addappid(2181720)
-- Game: addappid(2181720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2181721, 1, "2e4f4af2d53a710d5176b01c78679fc0f082aa91ee1e66667421debc94f05081")
