-- Lua provided by RyzenAPI
-- Game: Farm to Table

-- MAIN APPLICATION
addappid(3582250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3582251, 1, "282a9be675c4c24f4c51245fcd9cd0042ae1e1f88072efb8288bb8eb425f1fc9")
