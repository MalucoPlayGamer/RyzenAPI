-- Lua provided by RyzenAPI 
-- Game: Benefitship
addappid(2404000)
addappid(2404001, 1, "c00beb08ff963a7779f6950c15aa83cac4cd7c0899c6f1e07c8d98126d0ccb96")
