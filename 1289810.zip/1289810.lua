-- Lua provided by RyzenAPI
-- Game: Game: Siralim Ultimate

-- MAIN APPLICATION
addappid(1289810)
-- Game: addappid(1289810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289811, 1, "7fa2933dccbea29e87886ddd66e11f17df0d68319985eadf4307197a8b54655b")
addappid(1289812, 1, "4c8a54e3a6e6177a1a349cda358c399bffa0c82c07c2ec782d8239803178b20e")
addappid(1289813, 1, "83a31404988f619764e3c3166d21e7372e9aa2d66dc9230226753bc8c1b23f61")
