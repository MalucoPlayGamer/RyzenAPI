-- Lua provided by RyzenAPI
-- Game: Siralim Ultimate

-- MAIN APPLICATION
addappid(1289810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1289811, 1, "7fa2933dccbea29e87886ddd66e11f17df0d68319985eadf4307197a8b54655b")
addappid(1289812, 1, "4c8a54e3a6e6177a1a349cda358c399bffa0c82c07c2ec782d8239803178b20e")
addappid(1289813, 1, "83a31404988f619764e3c3166d21e7372e9aa2d66dc9230226753bc8c1b23f61")

