-- Lua provided by RyzenAPI
-- Game: Extra Terrestrial Nation

-- MAIN APPLICATION
addappid(1304070)
addappid(1353750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304071,0,"666c69962d92e6291a56d2eacc92192390da9e9ef429c3a85ceef80bdcceca6a")

