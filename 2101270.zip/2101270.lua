-- Lua provided by RyzenAPI
-- Game: 2101270

-- MAIN APPLICATION
addappid(2101270)
-- Game: addappid(2101270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101271, 1, "efdd3f9a5e3cded3aa4fbfe866a9c1b0ae2080f9c19f16f124dffbd2c0d74ff9")
