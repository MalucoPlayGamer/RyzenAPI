-- Lua provided by SkyAPI 
-- Game: Computer Club
addappid(2101270)
addappid(2101271, 1, "efdd3f9a5e3cded3aa4fbfe866a9c1b0ae2080f9c19f16f124dffbd2c0d74ff9")
