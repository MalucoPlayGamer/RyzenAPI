-- Lua provided by RyzenAPI
-- Game: Radio Commander: Squad Management

-- MAIN APPLICATION
addappid(1208880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208881, 1, "692470ead768ae3147e7c72241e7b4046222feb2f70cdbb20add84c7b2145c75")
addappid(1208882, 1, "eef9eb6c271528d2b78d147e9f24ef8e54617cc25d3decabf12efc7f306759a3")

