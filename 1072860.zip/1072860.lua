-- Lua provided by RyzenAPI
-- Game: Real Scary

-- MAIN APPLICATION
addappid(1072860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072861, 1, "c76c8d8484ba33912ff045f4b46aaed2359911acead6ef5666bb71cffaa87646")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
