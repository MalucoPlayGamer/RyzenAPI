-- Lua provided by RyzenAPI
-- Game: Real Scary

-- MAIN APPLICATION
addappid(1072860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1072861, 1, "c76c8d8484ba33912ff045f4b46aaed2359911acead6ef5666bb71cffaa87646")

