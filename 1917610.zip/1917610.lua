-- Lua provided by RyzenAPI
-- Game: Twin Mind: Ghost Hunter Collector's Edition

-- MAIN APPLICATION
addappid(1917610)
-- Game: addappid(1917610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1917611, 1, "417f9e66a2a4552e0e8d9d85cdc434e2e2646ce08db3ca661456ffa659f0734f")
