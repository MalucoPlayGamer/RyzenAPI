-- Lua provided by RyzenAPI
-- Game: addappid(982300)

-- MAIN APPLICATION
addappid(982300)

-- MAIN APP DEPOTS / PACKAGES
addappid(982301, 1, "4efbeb6052df73d522338f2693d9575408d60f9cd9aef8eeb5d9ca1fe78a66e8")
