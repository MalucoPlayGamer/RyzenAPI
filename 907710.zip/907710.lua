-- Lua provided by RyzenAPI
-- Game: This is the Zodiac Speaking

-- MAIN APPLICATION
addappid(907710)
-- Game: addappid(907710)

-- MAIN APP DEPOTS / PACKAGES
addappid(907711, 1, "c621f7195e81f70806cea501f703ade6bb31a124de0a0cc6f0fb28cc70a4551e")
