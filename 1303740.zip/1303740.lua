-- Lua provided by RyzenAPI
-- Game: Game: Love n Dream

-- MAIN APPLICATION
addappid(1303740)
addappid(1356850)
-- Game: addappid(1303740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1303741, 1, "8b7988a4584ae9b0ad65ba6bba1db4ef038acde46a442fbdb37d9e83f6a00e95")
