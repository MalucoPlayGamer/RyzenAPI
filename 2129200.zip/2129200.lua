-- Lua provided by RyzenAPI
-- Game: addappid(2129200)

-- MAIN APPLICATION
addappid(2129200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129201, 1, "95a0ba92230a5cd3f2cd4ebb8a2426dcac1f1fd41d2dd4fcad5f22996488da74")
