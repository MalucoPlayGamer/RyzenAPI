-- Lua provided by RyzenAPI
-- Game: Grand Brix Shooter

-- MAIN APPLICATION
addappid(1115580)
-- Game: addappid(1115580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1115581, 1, "19fd2a66a0780527762a1a436392f626acf34eb0b7f230540798c13bb4e46b2c")
