-- Lua provided by RyzenAPI
-- Game: addappid(701970)

-- MAIN APPLICATION
addappid(701970)

-- MAIN APP DEPOTS / PACKAGES
addappid(701971, 1, "d4d020070020484553cd4edc8d1d8166bb94dac9330208f407d0d89a8de5ce08")
