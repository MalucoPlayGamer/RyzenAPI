-- Lua provided by RyzenAPI
-- Game: 3 Minutes to Midnight® - A Comedy Graphic Adventure

-- MAIN APPLICATION
addappid(832500)

-- MAIN APP DEPOTS / PACKAGES
addappid(832502,0,"c113481f717c74c39ca1efb1c2a1989b4fc815bfd65d41ac0f0762d43e8f5251")
addappid(832503,0,"34770173231435add10ecc29be8667dc2166953f0f897594dc8ef52804b92ce6")
addappid(832504,0,"dc28bfc7719a2ce27791a49555bf9f49667fb7d166c965504e004b7b34e94b4c")
