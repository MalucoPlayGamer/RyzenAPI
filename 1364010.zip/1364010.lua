-- Lua provided by RyzenAPI
-- Game: 1364010

-- MAIN APPLICATION
addappid(1364010)
-- Game: addappid(1364010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364012,0,"6a6cbae109faf42d2e09626a9ef5372c301af6bd6584c41a5ee890b7f7d230f7")
