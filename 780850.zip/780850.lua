-- Lua provided by RyzenAPI
-- Game: Recreational Dreaming

-- MAIN APPLICATION
addappid(780850)

-- MAIN APP DEPOTS / PACKAGES
addappid(780851,0,"b0bc07e98c135401a2259260e1517cff3b2d3f60912bbf726ac0ba5a9e1c413b")

