-- Lua provided by RyzenAPI
-- Game: addappid(2273050)

-- MAIN APPLICATION
addappid(2273050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2273051, 1, "a0a99596ffcb8f041091129af5e0118113d1ffeb93fb56e6e2f236bac313daf5")
