-- Lua provided by RyzenAPI
-- Game: 时光超市

-- MAIN APPLICATION
addappid(3687810)

