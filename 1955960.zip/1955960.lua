-- Lua provided by RyzenAPI
-- Game: HAWKED

-- MAIN APPLICATION
addappid(1955960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1955961, 1, "fb24b9a7ba34422f5d35ccda11cc3bc9473915a6331360d3bff8c5a721faaf9a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2523210)
addappid(2523220)
addappid(2523230)
addappid(2523350)
addappid(3010240)
addappid(3335080)
addappid(3335090)
