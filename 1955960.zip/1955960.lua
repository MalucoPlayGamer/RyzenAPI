-- Lua provided by RyzenAPI
-- Game: 1955960

-- MAIN APPLICATION
addappid(1955960)
-- Game: addappid(1955960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1955961, 1, "fb24b9a7ba34422f5d35ccda11cc3bc9473915a6331360d3bff8c5a721faaf9a")
