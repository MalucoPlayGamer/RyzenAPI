-- Lua provided by RyzenAPI
-- Game: Warstone TD

-- MAIN APPLICATION
addappid(562500)
addappid(768240)
-- Game: addappid(562500)

-- MAIN APP DEPOTS / PACKAGES
addappid(562501, 1, "d07673051bf5c1a04a3dd26bc15448ed4a65be0486fd2cb9f7c39a72fde32060")
addappid(562502, 1, "f198868f20fa936c6421970b8ad13a174d221b4d7b06764601dd8a0ffb2a617d")
addappid(562504, 1, "c77cafff1c4ed55c091b1cda35a93eab270615dd730b9f25cb649a2a8ad56df0")
