-- Lua provided by SkyAPI 
-- Game: Sex Arena: Passion of Aquilon 💋⚔️ Demo
addappid(3227410)
addappid(3227411, 1, "e493f236a6df15d028169a28fc6b18fd1ac8b757cf580befd4032ef107b1ed84")
