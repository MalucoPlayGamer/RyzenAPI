-- Lua provided by RyzenAPI
-- Game: Three Kingdoms: The Blood Moon

-- MAIN APPLICATION
addappid(2746910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2746911, 1, "c62479b5db201f6ec039e35cf67977255a07650de17d569ef379209ce617c261")
addappid(2746912, 1, "01bb6f3726e1977dd3cdf8b43c78edddc7857f4e13559a0cbce77bca9cb4704a")

