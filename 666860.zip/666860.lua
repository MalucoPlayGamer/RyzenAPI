-- Lua provided by RyzenAPI
-- Game: Bit Heroes Quest

-- MAIN APPLICATION
addappid(666860)

-- MAIN APP DEPOTS / PACKAGES
addappid(666861, 1, "c498c13aa88dd537af14fd6372d32ed204cf775bf48fc678b55bdad07aa1a756")

