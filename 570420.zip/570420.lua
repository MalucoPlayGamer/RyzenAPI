-- Lua provided by RyzenAPI
-- Game: X Rebirth VR Edition

-- MAIN APPLICATION
addappid(570420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(570421, 1, "7d5014ca5e82e809c2b1d8edea58c3658ec1ac28da2886f3dffef881f6034be3")
addappid(570422, 1, "8d5f37ce232d9accf36ece1257eb8782e5a1095fb58ccfbc0a9c5e632406711b")
addappid(570423, 1, "0c8e4f2cc8e7e91c6545d3a2b95cc9514ab0099b03761041bdd5b5bf7913a9a5")
addappid(570424, 1, "c289565bbda63996ceeb4f010c9815a218764a156a67ae0847820b5ad4326923")

