-- Lua provided by RyzenAPI
-- Game: 3266200

-- MAIN APPLICATION
addappid(3266200)
-- Game: addappid(3266200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3266201, 1, "83adcf06c4591373ebde08dc1e2b32fc812334876a41efa0bf2fa6cd786c4de4")
