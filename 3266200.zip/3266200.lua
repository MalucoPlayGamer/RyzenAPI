-- Lua provided by RyzenAPI
-- Game: CowaCowa: Jinmenken

-- MAIN APPLICATION
addappid(3266200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3266201, 1, "83adcf06c4591373ebde08dc1e2b32fc812334876a41efa0bf2fa6cd786c4de4")

