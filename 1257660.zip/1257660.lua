-- Lua provided by RyzenAPI
-- Game: Time Rift

-- MAIN APPLICATION
addappid(1257660)
-- Game: addappid(1257660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257661, 1, "fa67f981206d7ca331fa4cc69532644685834bd8698c56bb4b20b6b024753da2")
