-- Lua provided by RyzenAPI
-- Game: Game: Cat On My Desktop

-- MAIN APPLICATION
addappid(3085770)
-- Game: addappid(3085770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3085771, 1, "6278e42ea5727ecf4f4981a734c8a22d8258c6cadc469270b0ac3e8bcfe43526")
