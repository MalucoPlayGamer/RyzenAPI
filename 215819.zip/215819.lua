-- Lua provided by RyzenAPI
-- Game: 215819

-- MAIN APPLICATION
addappid(215819)

-- MAIN APP DEPOTS / PACKAGES
addappid(215819,0,"090014bfc12098fe0dfd2cabe99993f3e79f362dd8320db66fdf7960c67ffdde")
