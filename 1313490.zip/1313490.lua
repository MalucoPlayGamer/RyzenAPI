-- Lua provided by RyzenAPI
-- Game: addappid(1313490)

-- MAIN APPLICATION
addappid(1313490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1313491, 1, "e34153e22f7e598b96e4a624e01778f0cfe0f1bdaedef8a8d45dc3c7bdd6f62e")
