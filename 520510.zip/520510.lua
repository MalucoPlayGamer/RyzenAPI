-- Lua provided by RyzenAPI
-- Game: 520510

-- MAIN APPLICATION
addappid(520510)
-- Game: addappid(520510)

-- MAIN APP DEPOTS / PACKAGES
addappid(520511, 1, "5831eb02dc39201d2c2e4d16daa36cd5498115504c2ab30d1ed9a99aab129a61")
