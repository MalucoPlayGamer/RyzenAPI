-- Lua provided by RyzenAPI
-- Game: Sex Adventures - Futanari Mistress

-- MAIN APPLICATION
addappid(1976000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976001, 1, "c6f5c9fcc0162d347c2a839c46ddedd5a97437cbb10bb92d107bca66b4edc24f")
