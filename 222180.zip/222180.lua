-- Lua provided by RyzenAPI
-- Game: Mushroom Men: Truffle Trouble

-- MAIN APPLICATION
addappid(222180)
addappid(228982)
addappid(228983)
addappid(228990)
addappid(229000)

-- MAIN APP DEPOTS / PACKAGES
addappid(222181, 1, "2d4900dbee4580ed4c3d017c9a3a527a25bfd2e49e246de0028c97bc33812571")
