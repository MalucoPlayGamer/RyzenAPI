-- Lua provided by RyzenAPI 
-- Game: Oh My Godheads
addappid(522740)
addappid(522741, 1, "c9d244437a086f97e7d9bcebac0e2e9468e332a846342bdb25aa98f68e641d33")
addappid(733100, 0, "283415e6d7d04f9c20601e40d814447e1bca969bec82b5b989e5fe818e26fd79")
addappid(733101, 0, "88ff8522abe116e0667b399be2e04be92395a5c8d4eb37660943441bcb5cde47")
