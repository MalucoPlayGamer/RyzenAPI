-- Lua provided by SkyAPI 
-- Game: Wwbit
addappid(907680)
addappid(907681, 1, "83a13c15bf9d3b93f03a756268d081155ae1dc5a5a1b3458f7e0b2da2ae52388")
