-- Lua provided by RyzenAPI
-- Game: Game: Bingo Hall

-- MAIN APPLICATION
addappid(1219230)
-- Game: addappid(1219230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1219231, 1, "709c97edc93659f80132a1c2c1d7ad04713745d8ff5bc66b940f67a3e91d2c5b")
