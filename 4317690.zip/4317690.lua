-- Lua provided by RyzenAPI
-- Game: Crimson Moon

-- MAIN APPLICATION
addappid(4317690) -- Crimson Moon
addappid(4984080) -- Crimson Moon Deluxe Edition Upgrade

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4317691, 1, "54374d8fbe8837e5d9bfdb27b4d678cf9905989b976f2e08825bbfd3c5ba96df") -- Depot 4317691

