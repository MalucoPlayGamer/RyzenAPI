-- Lua provided by RyzenAPI
-- Game: addappid(3366410)

-- MAIN APPLICATION
addappid(3366410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3366411, 1, "d5388b57fab789af3518295bb557c2e0d1c3243d5299a3d0d65f07a2acb2d912")
