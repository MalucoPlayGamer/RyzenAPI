-- Lua provided by RyzenAPI
-- Game: Game: Sweet House

-- MAIN APPLICATION
addappid(1659800)
-- Game: addappid(1659800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1659801, 1, "918f3eb9d85ffcf599ea2af91ba3cfd43f21d1d04da9309db57ca1b9858920de")
addappid(1689200, 0, "96c2f8dd611fc4d4f224a7da3151919de312dbbe4c1f079a16ba68dd6cdf8c82")
