-- Lua provided by RyzenAPI
-- Game: PAKO Caravan Demo

-- MAIN APPLICATION
addappid(3188130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3188131, 1, "92edd3fe4c500d93001a990754848128f3685ad2a754fab3b882c8fe1bedaf75")
