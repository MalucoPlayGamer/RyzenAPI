-- Lua provided by RyzenAPI
-- Game: Lock's Quest

-- MAIN APPLICATION
addappid(490080)

-- MAIN APP DEPOTS / PACKAGES
addappid(490081, 1, "14d0dccf8ec8d0a85954dc4231bdc2585a1ffbb51751e4a18060f9fab3979811")
