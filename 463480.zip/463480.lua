-- Lua provided by RyzenAPI
-- Game: Game: AppID 463480

-- MAIN APPLICATION
addappid(463480)
-- Game: addappid(463480)

-- MAIN APP DEPOTS / PACKAGES
addappid(463481, 1, "8342119b96ae02668c300a08fc9ae0864394c378c3707e2458a3f372c4dd3fca")
