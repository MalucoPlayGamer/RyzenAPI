-- Lua provided by RyzenAPI
-- Game: addappid(1817670)

-- MAIN APPLICATION
addappid(1817670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1817671, 1, "0a0fd7fc58e75d476f7ea0fedb58a6e1766ff0c2f167d6374119f1ef5d5a0a28")
