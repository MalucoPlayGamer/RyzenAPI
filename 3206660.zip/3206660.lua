-- Lua provided by RyzenAPI
-- Game: Storage Anomaly

-- MAIN APPLICATION
addappid(3206660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3206661, 1, "2ffa93137ff3850aca90847bc28206e9cd137c6b6e4934d3fd20dfd9f8ff533f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
