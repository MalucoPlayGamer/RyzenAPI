-- Lua provided by RyzenAPI
-- Game: 3206660

-- MAIN APPLICATION
addappid(3206660)
-- Game: addappid(3206660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3206661, 1, "2ffa93137ff3850aca90847bc28206e9cd137c6b6e4934d3fd20dfd9f8ff533f")
