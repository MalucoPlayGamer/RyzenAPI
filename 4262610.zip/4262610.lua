-- Lua provided by RyzenAPI
-- Game: Wannabe Galgame God!!!

-- MAIN APPLICATION
addappid(4262610)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4632570)
