-- Lua provided by RyzenAPI
-- Game: Wannabe Galgame God!!!

-- MAIN APPLICATION
addappid(4262610)

