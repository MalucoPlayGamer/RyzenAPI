-- Lua provided by RyzenAPI
-- Game: Game: Hero Emblems II Demo

-- MAIN APPLICATION
addappid(2967230)
-- Game: addappid(2967230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2967231, 1, "5ab9d1b8827307912f85e14519f102d15e0619373441a1030f64d9a1071272cb")
