-- Lua provided by RyzenAPI
-- Game: Plushie from the Sky Demo

-- MAIN APPLICATION
addappid(1737780)
addappid(1737781)
-- Game: addappid(1737780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1679511,0,"42f67c5679f8552d4ba81b6178652889adbcb6e70e01a4016a4961e2acc17668")
addappid(1737782,0,"17fbd90c4937c29066da50713cecbbde0d954a308b11ece8a660c783eef3947b")
