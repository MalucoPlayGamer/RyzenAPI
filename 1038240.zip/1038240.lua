-- Lua provided by RyzenAPI
-- Game: 1038240

-- MAIN APPLICATION
addappid(1038240)
-- Game: addappid(1038240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1038241, 1, "4cc45c917b0daa2bbe9c6c0b7b1b10daf43637d37528b85a6b03f0dc3789b305")
