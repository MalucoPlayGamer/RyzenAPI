-- Lua provided by RyzenAPI
-- Game: 2619110

-- MAIN APPLICATION
addappid(2619110)
-- Game: addappid(2619110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2619111, 1, "f18002f2af6583bb8ab939fbfe573cddac0b13df78214485a53268756a63d820")
