-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Skyline Simulations - John Wayne Airport

-- MAIN APPLICATION
addappid(2970690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2970690,0,"0ee1277052af26106ca6b0338c238715485c5f874e4e7fc43e6faeb68d080378")
