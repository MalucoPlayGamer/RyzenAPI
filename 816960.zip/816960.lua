-- Lua provided by RyzenAPI
-- Game: 816960

-- MAIN APPLICATION
addappid(816960)
-- Game: addappid(816960)

-- MAIN APP DEPOTS / PACKAGES
addappid(816961, 1, "e35606a4157b48d06b99700cbfb7b7287bedf4b031e4b318e6260343579ab2ce")
