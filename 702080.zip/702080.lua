-- Lua provided by RyzenAPI
-- Game: AppID 702080

-- MAIN APPLICATION
addappid(702080)
addappid(798130)
-- Game: addappid(702080)

-- MAIN APP DEPOTS / PACKAGES
addappid(702081, 1, "49325adf547e5a219cfbfead8e2a208eab15cc4fbab8f8706547bf919cf99664")
