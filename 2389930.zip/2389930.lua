-- Lua provided by RyzenAPI
-- Game: AppID 2389930

-- MAIN APPLICATION
addappid(2389930)
-- Game: addappid(2389930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2389931, 1, "eb5c6d67fe3bc5bc1b8d616163df7b5b0993f63211e81e3b372b62087dd31986")
