-- Lua provided by RyzenAPI
-- Game: Finnish Army Simulator Demo

-- MAIN APPLICATION
addappid(2127950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2127951, 1, "40ffc6737c8047c174dec891fb02f98fdb22a0e52170f16a0dad337fa1d1dcb9")

