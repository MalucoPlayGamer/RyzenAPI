-- Lua provided by RyzenAPI
-- Game: Game: Void Slayer

-- MAIN APPLICATION
addappid(1803150)
-- Game: addappid(1803150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803151, 1, "492104705016027fb6f7870f4e6d12fa367591f91e4a252c270e4bb3220b3cf1")
