-- Lua provided by SkyAPI 
-- Game: Magicbook AutoBattler: Contract
addappid(3521320)
addappid(3521321, 1, "da8e5c19dbd799a01ab9954cdf822c966f4179b3d5d51a2e7a98627bf2c39165")
