-- Lua provided by RyzenAPI
-- Game: 3476490

-- MAIN APPLICATION
addappid(3476490)
-- Game: addappid(3476490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3476491, 1, "56a3159d5f8bef8602ef1e7efeeb814a019f7d5f717f680f288482c1b19b3a2a")
