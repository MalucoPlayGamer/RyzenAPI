-- Lua provided by RyzenAPI
-- Game: Neptunia x SENRAN KAGURA: Ninja Wars

-- MAIN APPLICATION
addappid(1836860)
-- Game: addappid(1836860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836861, 1, "9c3b608aeb5f9fb3d8013b02847fe12d074f1830ca08032339604741898897c6")
