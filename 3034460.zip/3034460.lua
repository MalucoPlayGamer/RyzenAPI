-- Lua provided by RyzenAPI
-- Game: Kurisu

-- MAIN APPLICATION
addappid(3034460)
-- Game: addappid(3034460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3034463,0,"fd983c6514d92da8b503b4ac971161da96e06c62b8ec5477250b3d221e1cdf3f")
