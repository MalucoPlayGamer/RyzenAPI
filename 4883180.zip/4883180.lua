-- Lua provided by RyzenAPI
-- Game: Another Shadow

-- MAIN APPLICATION
addappid(4883180) -- Another Shadow

-- MAIN APP DEPOTS / PACKAGES
addappid(4883181, 1, "f5bfdec77a2afbd8057e5bc70be09042a634d5eacf78a795db0833ceac13811a") -- Depot 4883181
