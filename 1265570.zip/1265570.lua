-- Lua provided by RyzenAPI
-- Game: Game: Death Match Love Comedy!

-- MAIN APPLICATION
addappid(1265570)
-- Game: addappid(1265570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265571, 1, "77b55d1775108df57b439deba69f0d6b07e89d5f90131a46c1c2ad90d01a3841")
