-- Lua provided by RyzenAPI
-- Game: Machick 2

-- MAIN APPLICATION
addappid(4240980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3449040, 1, "015a4d7ffea3c17056f611a83eaab165201bb0063835c807b5dcd1794c3714a9") -- Machick 2
addappid(3449041, 1, "1e736e3c9b85554fd7484945b612748f84ac38a28c2f4eb64b26b8a4aab06d92") -- Depot 3449041

