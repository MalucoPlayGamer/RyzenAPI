-- 3449040's Lua and Manifest Created by Hubcap Manifest
-- Machick 2
-- Created: May 01, 2026 at 04:43:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3449040, 1, "015a4d7ffea3c17056f611a83eaab165201bb0063835c807b5dcd1794c3714a9") -- Machick 2
-- MAIN APP DEPOTS
addappid(3449041, 1, "1e736e3c9b85554fd7484945b612748f84ac38a28c2f4eb64b26b8a4aab06d92") -- Depot 3449041
--setManifestid(3449041, "5088540235033293053", 945794120)