-- Lua provided by RyzenAPI
-- Game: Yonder: The Cloud Catcher Chronicles

-- MAIN APPLICATION
addappid(580200)
addappid(771020)

-- MAIN APP DEPOTS / PACKAGES
addappid(580201, 1, "6b72bde47a0beff82486aee836dcecc1288acab97fba440e9b5e30225143574e")

