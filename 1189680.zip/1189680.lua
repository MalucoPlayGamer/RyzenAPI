-- Lua provided by RyzenAPI
-- Game: Game: Degraman: Act I. Vincent

-- MAIN APPLICATION
addappid(1189680)
-- Game: addappid(1189680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189681, 1, "648aa142a3849b203356ddf3de8fe34b06f1a30c5641bd5e3445a31f480adc97")
