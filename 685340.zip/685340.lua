-- Lua provided by RyzenAPI
-- Game: Delivery From The Pain

-- MAIN APPLICATION
addappid(685340)

-- MAIN APP DEPOTS / PACKAGES
addappid(685341, 1, "c85896ac89dea3201f562c5e7c23f5ae41f766f471b975256b1a011ca13667ee")
addappid(1104750, 0, "8dd86bd97c337bcfad599088bfc848bcbdd6b8ce04b83600274f798cb6962926")
