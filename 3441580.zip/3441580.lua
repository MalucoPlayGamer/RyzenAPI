-- Lua provided by RyzenAPI
-- Game: MiniGolf Showdown

-- MAIN APPLICATION
addappid(3441580) -- MiniGolf Showdown

-- MAIN APP DEPOTS / PACKAGES
addappid(3441581, 1, "c0954c1bf748074bb7b9e19b852138445e0bd3687570065bf199e84cb5a671f9") -- Depot 3441581
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
