-- Lua provided by RyzenAPI
-- Game: addappid(1747450)

-- MAIN APPLICATION
addappid(1747450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747451, 1, "9d558eaa5f4debf3a3f2d33951d518e7f973ccecff9a0f00ed1a6bf3f68ecd53")
