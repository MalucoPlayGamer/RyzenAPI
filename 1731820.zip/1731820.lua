-- Lua provided by RyzenAPI
-- Game: 1731820

-- MAIN APPLICATION
addappid(1731820)
-- Game: addappid(1731820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731821, 1, "39e53d44d9422eda00237ae774ba8ff754356b6ad3d4ca8eb82e82a1610c6bae")
