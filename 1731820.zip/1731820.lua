-- Lua provided by RyzenAPI
-- Game: DEBIE ZONE

-- MAIN APPLICATION
addappid(1731820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1731821, 1, "39e53d44d9422eda00237ae774ba8ff754356b6ad3d4ca8eb82e82a1610c6bae")

