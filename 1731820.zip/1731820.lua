-- Lua provided by RyzenAPI 
-- Game: DEBIE ZONE
addappid(1731820)
addappid(1731821, 1, "39e53d44d9422eda00237ae774ba8ff754356b6ad3d4ca8eb82e82a1610c6bae")
