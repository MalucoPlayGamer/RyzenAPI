-- Lua provided by RyzenAPI
-- Game: War Mongrels Demo

-- MAIN APPLICATION
addappid(1642930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642931, 1, "94ddc888e854e70b77f89e1789e5c0f084459e75eb8b1a5bd2dd1840cfaf365d")
