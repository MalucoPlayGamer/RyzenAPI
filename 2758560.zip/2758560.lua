-- Lua provided by RyzenAPI
-- Game: addappid(2758560)

-- MAIN APPLICATION
addappid(2758560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2758561, 1, "1a89d96152b4338e724918ad9a3f4347ae1f80014faf89714154dae5c8edbaeb")
