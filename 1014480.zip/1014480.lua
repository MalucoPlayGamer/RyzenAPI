-- Lua provided by RyzenAPI
-- Game: addappid(1014480)

-- MAIN APPLICATION
addappid(1014480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014481, 1, "996ac35851186a6da24b7548b3492a6a8c8778d781bac0ae4b365be3fa20c628")
