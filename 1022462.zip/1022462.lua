-- Lua provided by RyzenAPI
-- Game: DFF NT: Zidane Tribal Starter Pack

-- MAIN APPLICATION
addappid(1022462)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022462,0,"fb231ef569b6dd8d8dfac8f1bd0abc140781bad3211ad7e050962f76d35c14b8")

