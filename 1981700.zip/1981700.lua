-- Lua provided by RyzenAPI
-- Game: Game: Jacob's Quest Anniversary Edition

-- MAIN APPLICATION
addappid(1981700)
-- Game: addappid(1981700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981701, 1, "581dcaeb951a0df6b9cfed55124a5b588e9d0c56919b306617d1bbd2240d2ebf")
