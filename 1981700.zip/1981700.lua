-- Lua provided by RyzenAPI
-- Game: Jacob's Quest Anniversary Edition

-- MAIN APPLICATION
addappid(1981700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981701, 1, "581dcaeb951a0df6b9cfed55124a5b588e9d0c56919b306617d1bbd2240d2ebf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2563730)
