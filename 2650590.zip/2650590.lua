-- Lua provided by RyzenAPI
-- Game: Endless Forest Dream

-- MAIN APPLICATION
addappid(2650590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650591, 1, "023950b4e1e83489bb1dff32afbf771bf6d55e751d72afa7035d24fd8f7004f5")

