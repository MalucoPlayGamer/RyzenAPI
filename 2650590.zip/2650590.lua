-- Lua provided by RyzenAPI
-- Game: 2650590

-- MAIN APPLICATION
addappid(2650590)
-- Game: addappid(2650590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650591, 1, "023950b4e1e83489bb1dff32afbf771bf6d55e751d72afa7035d24fd8f7004f5")
