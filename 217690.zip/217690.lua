-- Lua provided by RyzenAPI
-- Game: Anna - Extended Edition

-- MAIN APPLICATION
addappid(217690)
-- Game: addappid(217690)

-- MAIN APP DEPOTS / PACKAGES
addappid(217691, 1, "04fc181314a62ca6fb9af952d6f5118626dad397cb83b0eb2ff2d132f1335c15")
addappid(217692, 1, "0a0fa301f5c47cc0ffe726603ec8158970881aa5d4b17f9880bd14d3be60311d")
addappid(217693, 1, "60de243c5d1d4040a00338798744943916ab19b45b5aa85fc682a52603360608")
addappid(217694, 1, "e23ecbbdad60dbc07360d03c5be5b163d906f5b105b8c176b76b657b6dd67348")
