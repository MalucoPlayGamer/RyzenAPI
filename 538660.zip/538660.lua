-- Lua provided by RyzenAPI
-- Game: Staircase of Darkness: VR

-- MAIN APPLICATION
addappid(538660)

-- MAIN APP DEPOTS / PACKAGES
addappid(538661, 1, "618dc57d21e517a2235450d35de33020ad4de842f9494fae8952ef4883fba8ed")
addappid(538669, 1, "3c52bcec108802c5112c4e97423a460f36d1d322a43f38861a5d6577384351f1")

