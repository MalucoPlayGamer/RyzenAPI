-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1648560)
addappid(1648561)
addappid(1648562,0,"e917de7bf41b29165d769f45f10887e8bb8d75c87c2509f3b433ec2bb0756576")
-- setManifestid(1648562,"2904451720057472614")
addappid(1648563,0,"162fe56b4ea17eb43534919e97f6a03aca589264d0ac79c9468f0ba80708cca1")
-- setManifestid(1648563,"7846253844748085162")