-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1648560)
addappid(1648561)
-- Game: addappid(1648560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648562,0,"e917de7bf41b29165d769f45f10887e8bb8d75c87c2509f3b433ec2bb0756576")
addappid(1648563,0,"162fe56b4ea17eb43534919e97f6a03aca589264d0ac79c9468f0ba80708cca1")
