-- Lua provided by RyzenAPI
-- Game: Blind Fate: Edo no Yami

-- MAIN APPLICATION
addappid(1294880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1294881, 1, "7b1cb6e90988e8e0b5fe697d913bb1fd8029d6d98d6d59f4efad31ef2d8afe6d")

