-- Lua provided by RyzenAPI 
-- Game: AppID 442290
addappid(442290)
addappid(442291, 1, "928e2f666ac14796807db4b164bc340a5569635380971402c430ebf26d27128b")
