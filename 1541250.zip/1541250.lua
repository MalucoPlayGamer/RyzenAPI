-- Lua provided by SkyAPI 
-- Game: Super Raft Boat Classic
addappid(1541250)
addappid(1541251, 1, "088f220f75269081c8ceeefb437717955948d3d2739c1c965b8120bcc512b8c5")
addappid(1541252, 1, "5c74d7c4e6b42da48ee0f6117262d86ab1fd6af7e21d37f6ec34815fe4856297")
