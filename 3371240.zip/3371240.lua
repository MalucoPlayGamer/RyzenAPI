-- Lua provided by RyzenAPI
-- Game: Beyond Citadel

-- MAIN APPLICATION
addappid(3371240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3371241, 1, "545544358b5ccb968bcb306b020d7d3b5f749949a10a6f02958a6d6181e9dcce")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
