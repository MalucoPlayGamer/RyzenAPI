-- Lua provided by RyzenAPI 
-- Game: Beyond Citadel
addappid(3371240)
addappid(3371241, 1, "545544358b5ccb968bcb306b020d7d3b5f749949a10a6f02958a6d6181e9dcce")
