-- Lua provided by RyzenAPI
-- Game: Game: Beyond Citadel

-- MAIN APPLICATION
addappid(3371240)
-- Game: addappid(3371240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3371241, 1, "545544358b5ccb968bcb306b020d7d3b5f749949a10a6f02958a6d6181e9dcce")
