-- Lua provided by RyzenAPI
-- Game: 2330730

-- MAIN APPLICATION
addappid(2330730)
-- Game: addappid(2330730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2330731, 1, "268f0ecd57a6d1289de7cf1762ae37ffb36524c9152cd7756d49a324c1bfbc3c")
