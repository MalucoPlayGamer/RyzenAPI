-- Lua provided by RyzenAPI
-- Game: Game: Squadron 51 - Prologue

-- MAIN APPLICATION
addappid(1731590)
-- Game: addappid(1731590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731591, 1, "8d8c5d56cb126e1c4c92676dea8fd1288b76bf8e9f5113702587c185a6a2edf1")
