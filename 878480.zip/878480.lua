-- Lua provided by RyzenAPI
-- Game: The Shadow of Hell

-- MAIN APPLICATION
addappid(878480)

-- MAIN APP DEPOTS / PACKAGES
addappid(878481, 1, "fb24ae5c740555ff67121251e5fecbfd5ffaff1d5d8474957b8e783ac0e4221c")
