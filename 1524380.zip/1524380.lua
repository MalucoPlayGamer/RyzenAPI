-- Lua provided by RyzenAPI
-- Game: Dr. oil

-- MAIN APPLICATION
addappid(1524380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1524381, 1, "3845d488df68952a18295de977b64e69852747cea57a99e61b80c4f59eac457e")

