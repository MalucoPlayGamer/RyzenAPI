-- Lua provided by RyzenAPI
-- Game: addappid(2666880)

-- MAIN APPLICATION
addappid(2666880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2666881, 1, "a2ae069127c2f02fed206453c714bbe410ab9e92e812120b7037abeaab503c8a")
