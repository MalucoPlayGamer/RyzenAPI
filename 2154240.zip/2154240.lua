-- Lua provided by RyzenAPI
-- Game: Odinfall

-- MAIN APPLICATION
addappid(2154240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2154241, 1, "2bdb2330782582bb0c9d3445a7c5d55115b4368433cdbeb303c095d56bfabb67")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
