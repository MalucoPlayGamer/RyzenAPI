-- Lua provided by RyzenAPI
-- Game: 1674760

-- MAIN APPLICATION
addappid(1674760)
-- Game: addappid(1674760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674761, 1, "dfe64e0b34e76f5223946a2909e4f1aee17c574a1c2006f34d55a7f4d75eab9d")
