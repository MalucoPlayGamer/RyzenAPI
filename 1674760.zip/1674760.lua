-- Lua provided by SkyAPI 
-- Game: Invertigo Demo
addappid(1674760)
addappid(1674761, 1, "dfe64e0b34e76f5223946a2909e4f1aee17c574a1c2006f34d55a7f4d75eab9d")
