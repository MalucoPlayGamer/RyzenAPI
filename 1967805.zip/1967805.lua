-- Lua provided by RyzenAPI
-- Game: Beat Saber - Darude - Sandstorm

-- MAIN APPLICATION
addappid(1967805)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967805,0,"8189d04aeb87dcf233168299fa24173d14222bbfbb1ef0083249e54858ed772f")
