-- Lua provided by RyzenAPI
-- Game: addappid(2307160)

-- MAIN APPLICATION
addappid(2307160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307161, 1, "8092221a74da7557f0f6af2f0190b9f9545a609ecd48d0e3fdc77c450b833b27")
