-- Lua provided by RyzenAPI
-- Game: Yukiiro Sign

-- MAIN APPLICATION
addappid(2307160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2307161, 1, "8092221a74da7557f0f6af2f0190b9f9545a609ecd48d0e3fdc77c450b833b27")

