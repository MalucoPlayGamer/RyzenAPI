-- Lua provided by RyzenAPI
-- Game: Seven Doors

-- MAIN APPLICATION
addappid(1329320)
-- Game: addappid(1329320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1329321, 1, "70452025beaf461a4be34f3bfa36d5218c0513d884073d63e55f59c0d31f6c0a")
