-- Lua provided by RyzenAPI
-- Game: Seven Doors

-- MAIN APPLICATION
addappid(1329320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1329321, 1, "70452025beaf461a4be34f3bfa36d5218c0513d884073d63e55f59c0d31f6c0a")

