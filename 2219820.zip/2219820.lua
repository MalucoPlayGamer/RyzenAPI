-- Lua provided by RyzenAPI
-- Game: Kunoichi Demon Slayers

-- MAIN APPLICATION
addappid(2219820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2219821, 1, "fbe9a49b44d1cecd5ef05fc37b8e622922e6091c199c54db5bbd8a7b46d75cee")
addappid(2219822, 1, "4644415f0836d819ae135806400482dbf36c7e6d870004c236adb486b7dbf2fe")
addappid(2219823, 1, "29ac7b008d756f940c9db5683767a818d782ebbd895677b24efed601d929e2dc")

