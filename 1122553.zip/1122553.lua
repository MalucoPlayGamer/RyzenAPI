-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Guitar - Easy String Switching Exercise 2

-- MAIN APPLICATION
addappid(1122553)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122553,0,"232112bcc9359afd3cc34141dee80673f76ed6840a3105021698618dd7c66aca")

