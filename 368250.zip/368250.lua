-- Lua provided by RyzenAPI 
-- Game: Valiant: Resurrection
addappid(368250)
addappid(368251, 1, "ebfdf2b3dcf91b4e16a26759a66acb700d91066815022acd73f62802b4cf5bd9")
addappid(368510, 0, "7ff13a6d84556b16cc90218631b7df4bb4df351ead709a7756c74df165912227")
