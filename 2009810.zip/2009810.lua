-- Lua provided by RyzenAPI
-- Game: 2009810

-- MAIN APPLICATION
addappid(2009810)
-- Game: addappid(2009810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009811, 1, "216319f15a2cc4747fd3eea1ab6b1f2a08546b46b1977ee086b344615d708b3f")
