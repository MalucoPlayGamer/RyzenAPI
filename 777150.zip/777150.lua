-- Lua provided by RyzenAPI
-- Game: Adventure Land - The Code MMORPG

-- MAIN APPLICATION
addappid(777150)

-- MAIN APP DEPOTS / PACKAGES
addappid(777151,0,"585f8c882693f4afeaca00581d8a5661ddc2a0099066a0acdc8284e9b6f1f079")

