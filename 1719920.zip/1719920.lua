-- Lua provided by RyzenAPI
-- Game: addappid(1719920)

-- MAIN APPLICATION
addappid(1719920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719920,0,"e984c6c0605f00e512f5b7b50c2198b818fa5abbe0ce66d062f3957e3d46c536")
