-- Lua provided by RyzenAPI
-- Game: Xuan-Yuan Sword: Mists Beyond the Mountains (1999)

-- MAIN APPLICATION
addappid(2543420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2543420,0,"0f1f7ce7b64b3644469cd0d87977628abffde60cccdeaabadef37f3971b2ea04")
