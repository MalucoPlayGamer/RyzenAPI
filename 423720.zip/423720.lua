-- Lua provided by RyzenAPI
-- Game: AppID 423720

-- MAIN APPLICATION
addappid(423720)

-- MAIN APP DEPOTS / PACKAGES
addappid(423721, 1, "bc9ff8ac1a938be0562f53e79e937bd8409680edde401f4c5041551d9e848dc5")

