-- Lua provided by RyzenAPI
-- Game: Berserk Mode

-- MAIN APPLICATION
addappid(1649630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1649631, 1, "920e3be9f6235e2dd478ee9c54d8221dd1e9933f630e71839537129f0cc16bf1")
