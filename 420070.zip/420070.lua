-- Lua provided by RyzenAPI
-- Game: Game: Kill The Plumber

-- MAIN APPLICATION
addappid(420070)
-- Game: addappid(420070)

-- MAIN APP DEPOTS / PACKAGES
addappid(420071, 1, "e181771c5c94143f0c574d8be2f73c2dccb2dc4c7947ec49c1f80ac36c9e6211")
