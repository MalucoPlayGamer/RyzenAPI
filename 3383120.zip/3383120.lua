-- Lua provided by RyzenAPI 
-- Game: 呪いの穢れ唄　鳴海龍也の回奇録
addappid(3383120)
addappid(3383121, 1, "bccc2b1f5490fae54dfe43899edcf37594da444ba1853907d5c3069abbbc95d8")
