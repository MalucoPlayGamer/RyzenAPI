-- Lua provided by RyzenAPI
-- Game: Game: 呪いの穢れ唄　鳴海龍也の回奇録

-- MAIN APPLICATION
addappid(3383120)
-- Game: addappid(3383120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3383121, 1, "bccc2b1f5490fae54dfe43899edcf37594da444ba1853907d5c3069abbbc95d8")
