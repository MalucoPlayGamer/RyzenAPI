-- Lua provided by RyzenAPI
-- Game: 3383120

-- MAIN APPLICATION
addappid(3383120)
-- Game: addappid(3383120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3383121, 1, "bccc2b1f5490fae54dfe43899edcf37594da444ba1853907d5c3069abbbc95d8")
