-- Lua provided by RyzenAPI
-- Game: Key Puss

-- MAIN APPLICATION
addappid(1965130)
-- Game: addappid(1965130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1965131, 1, "3d8ea664cb43913dccd0134f78053ff3a5fc353d121ce7c754a3296aadbca8b7")
