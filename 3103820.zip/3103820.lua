-- Lua provided by RyzenAPI 
-- Game: Sewing Machine Simulator
addappid(3103820)
addappid(3103821, 1, "e0695ba65f8145688eb0ccbc1f89738c6e22451f1c5c12db6b3c42bcd96fbdcd")
