-- Lua provided by RyzenAPI
-- Game: Fujii - A Magical Gardening Adventure

-- MAIN APPLICATION
addappid(589040)
-- Game: addappid(589040)

-- MAIN APP DEPOTS / PACKAGES
addappid(589041, 1, "c827b322fdcf9d240bf9acbdcbc5cb8b746c3ebb872b30b5fb53983a55529393")
