-- Lua provided by SkyAPI 
-- Game: AppID 785100
addappid(785100)
addappid(785101, 1, "fe9f74a524e710d055ffcb665b39b816841c5346d01dcc764a7aee460a714207")
addappid(785102, 1, "50638b4dcd9fb53c72100a1e2516401c7995958bf7be9a1c9d79a3ad663c0efc")
