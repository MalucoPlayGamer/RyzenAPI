-- Lua provided by SkyAPI 
-- Game: Ballance: The Return
addappid(1186290)
addappid(1186291, 1, "906c60cc5c4bdba618363a0e75e189f353463c98bdd501bfb08ed11b21568423")
