-- Lua provided by RyzenAPI
-- Game: Game: Beholgar

-- MAIN APPLICATION
addappid(1399750)
-- Game: addappid(1399750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399751, 1, "3aa7d0c4036f64f1e5db10c5bcf6533bb9c220696ec115808d8cd91a3d081968")
