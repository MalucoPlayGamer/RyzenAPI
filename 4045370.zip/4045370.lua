-- Lua provided by RyzenAPI
-- Game: Anomaly Zone Renovation

-- MAIN APPLICATION
addappid(4045370)
