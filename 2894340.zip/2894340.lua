-- Lua provided by RyzenAPI
-- Game: Sophonce Demo

-- MAIN APPLICATION
addappid(2894340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2894341, 1, "8e47eec31fb53128fb6d90fb7037c1f622fb24bb49595ae097d85267daaf54b1")
