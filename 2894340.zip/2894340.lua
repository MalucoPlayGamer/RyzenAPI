-- Lua provided by SkyAPI 
-- Game: AppID 2894340
addappid(2894340)
addappid(2894341, 1, "8e47eec31fb53128fb6d90fb7037c1f622fb24bb49595ae097d85267daaf54b1")
