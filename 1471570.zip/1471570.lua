-- Lua provided by RyzenAPI
-- Game: Industrial Firefighters

-- MAIN APPLICATION
addappid(1471570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1471571, 1, "fe778ef28c7aef9441e5a35c8d8bf8979f1c389f6a3352d6ed2ed2f7a8605f05")

