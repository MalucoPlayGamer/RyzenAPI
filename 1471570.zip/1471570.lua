-- Lua provided by RyzenAPI
-- Game: Industrial Firefighters

-- MAIN APPLICATION
addappid(1471570)
-- Game: addappid(1471570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1471571, 1, "fe778ef28c7aef9441e5a35c8d8bf8979f1c389f6a3352d6ed2ed2f7a8605f05")
