-- Lua provided by RyzenAPI
-- Game: Backrooms Exploration

-- MAIN APPLICATION
addappid(1730930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1730931, 1, "ed8eff423bbcde2e6e53bda4609a34d5a8d4298d12ab5b225ef7721119432525")

