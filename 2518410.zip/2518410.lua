-- Lua provided by RyzenAPI
-- Game: Game: AppID 2518410

-- MAIN APPLICATION
addappid(2518410)
-- Game: addappid(2518410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2518411, 1, "c87f5ae507167b0b905e70c1decd7432aa1767ee3570b681570a54ca8edf728f")
