-- Lua provided by SkyAPI 
-- Game: AppID 2518410
addappid(2518410)
addappid(2518411, 1, "c87f5ae507167b0b905e70c1decd7432aa1767ee3570b681570a54ca8edf728f")
