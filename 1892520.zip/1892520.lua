-- Lua provided by RyzenAPI
-- Game: addappid(1892520)

-- MAIN APPLICATION
addappid(1892520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1892521, 1, "8dced54acffb0228e9acf78126c71108d8d4e6beffc5b21db5fce5123bf9a618")
