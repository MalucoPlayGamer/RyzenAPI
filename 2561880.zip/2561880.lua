-- Lua provided by RyzenAPI
-- Game: 2561880

-- MAIN APPLICATION
addappid(2561880)
-- Game: addappid(2561880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2561881, 1, "ef3e5627630f1223639cace742a3a0cb21039e71ed9fdde4cc8fa62d41b64a6d")
addappid(2561882, 1, "8c9b474435c4bc69fc3c16004dca803ad314128372ef670bbdf25d5828bf0beb")
