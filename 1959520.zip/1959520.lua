-- Lua provided by RyzenAPI
-- Game: addappid(1959520)

-- MAIN APPLICATION
addappid(1959520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1959521, 1, "b99f0b1a0ddb2cc6b26f314c9a857a65fb961f556a4aef394d65a4ec5ba1cbd9")
