-- Lua provided by RyzenAPI 
-- Game: Divine Adventure: Act One
addappid(1374090)
addappid(1374091, 1, "9a4800a26a8c94158329d7f72488195e5009e7a26a15b921e5b115720021b412")
