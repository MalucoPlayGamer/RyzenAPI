-- Lua provided by RyzenAPI
-- Game: Soul Hackers 2

-- MAIN APPLICATION
addappid(1777620)
addappid(1869260)
addappid(1869261)
addappid(1869262)
addappid(1869263)
addappid(1869264)
addappid(1869265)
addappid(1872840)
addappid(1872850)
addappid(1872851)
addappid(1997810)
addappid(1997811)
addappid(1997812)
addappid(1997813)
addappid(1997814)
addappid(2051660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1777621, 1, "d5aef697152a0dbff354e6b2a075efd389cec458dd76e8aa2e6f6495ac4285f6")

