-- Lua provided by RyzenAPI
-- Game: Soul Hackers 2

-- MAIN APPLICATION
addappid(1777620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1777621, 1, "d5aef697152a0dbff354e6b2a075efd389cec458dd76e8aa2e6f6495ac4285f6")
