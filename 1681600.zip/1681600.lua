-- Lua provided by RyzenAPI
-- Game: 1681600

-- MAIN APPLICATION
addappid(1681600)
-- Game: addappid(1681600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681601, 1, "0fd2b2d8c6d548e6c89b84ff4fd4f5c6fc3110cd87d474828920e93ee662cb3f")
