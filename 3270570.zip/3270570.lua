-- Lua provided by RyzenAPI
-- Game: 3270570

-- MAIN APPLICATION
addappid(3270570)
-- Game: addappid(3270570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3270572,0,"5e838d443ed1cfc73df7f350632a95efadc58be3791921c9520f52a721db1c0f")
addappid(3270573,0,"ca87676a28b5003f0e1bfdab23dab70300f31cd3b234b269f5e39a5fcaa07666")
