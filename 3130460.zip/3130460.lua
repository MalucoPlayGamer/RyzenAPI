-- Lua provided by RyzenAPI 
-- Game: Test Dummy Takedown Playtest
addappid(3130460)
addappid(3130461, 1, "2d11152e3fc50a34171b664dff293c731350e550006995bb73f11d2788985a5a")
