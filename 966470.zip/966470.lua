-- Lua provided by RyzenAPI
-- Game: 966470

-- MAIN APPLICATION
addappid(966470)
-- Game: addappid(966470)

-- MAIN APP DEPOTS / PACKAGES
addappid(966471, 1, "321350d7dd59d5138418243367f3a695dd0ff711285ab0beab02e9ec9a6e5c17")
