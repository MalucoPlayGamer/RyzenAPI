-- Lua provided by RyzenAPI
-- Game: Tale of Ninja: Fall of the Miyoshi

-- MAIN APPLICATION
addappid(966470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(966471, 1, "321350d7dd59d5138418243367f3a695dd0ff711285ab0beab02e9ec9a6e5c17")

