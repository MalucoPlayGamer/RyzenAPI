-- Lua provided by RyzenAPI
-- Game: Game: Logistique Act. 1

-- MAIN APPLICATION
addappid(1154130)
-- Game: addappid(1154130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1154131, 1, "2b77026887bf1e7e560cbaee14f7e75ac36e9b80a7fe108a4386cf7c765342ca")
addappid(1154132, 1, "ab893118cb72da25751ff480976463fb52df4a014ce8e9b56fc2e336b378cd22")
addappid(1154133, 1, "16544366b5591bfd8fe18443c3f9cf2b242ea8ef338d3e68f3834bf6c139ee50")
addappid(1154134, 1, "9ebdfbe717263af782aa6cfe049cc44b56b2f72156f89edd97df62a4960a83a1")
