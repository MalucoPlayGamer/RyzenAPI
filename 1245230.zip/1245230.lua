-- Lua provided by RyzenAPI
-- Game: 1245230

-- MAIN APPLICATION
addappid(1245230)
-- Game: addappid(1245230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245231, 1, "c88110b530831450132edde337b22521938a2e7acf401b126fbbc3480b5cdc7a")
