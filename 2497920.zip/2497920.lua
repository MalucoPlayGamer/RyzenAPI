-- Lua provided by RyzenAPI
-- Game: A Difficult Game About Climbing

-- MAIN APPLICATION
addappid(2497920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497921, 1, "89eba51d9ff7c9f0f6e85a64650d0744d02da8ad30dc61daaafe30062861ff88")
addappid(2497922, 1, "24241922346f585fdcce02abae111353524b360de073cddf3a9889ea665366ff")

