-- Lua provided by RyzenAPI
-- Game: Ruin Raiders

-- MAIN APPLICATION
addappid(1262720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262721, 1, "bd5e351a2d83912a74429afd8658a7e2bc9cf4d99e7b0f746080b7be8612f71e")

