-- Lua provided by RyzenAPI 
-- Game: Kona & SnowRabbit: Pilot
addappid(2726560)
addappid(2726561, 1, "e451948e0c5ac72ea5aa6498f3c7edcbf31eae86187046d9aa94d72aeccc0478")
