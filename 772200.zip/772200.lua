-- Lua provided by RyzenAPI
-- Game: 772200

-- MAIN APPLICATION
addappid(772200)
-- Game: addappid(772200)

-- MAIN APP DEPOTS / PACKAGES
addappid(772201, 1, "f4344072ffadfaebbefb7c26b62a8adb39de230b6d1ffdd89199d9d0cfdf27a8")
