-- Lua provided by RyzenAPI
-- Game: Calculator: The Game

-- MAIN APPLICATION
addappid(2508960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2508961, 1, "1893771324bc002acba3e18e4b41a74118f31e8a26ea24120c546386bfe75949")

