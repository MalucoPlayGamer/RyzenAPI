-- Lua provided by RyzenAPI 
-- Game: Street Hoop
addappid(1189520)
addappid(1189521, 1, "5534bcd486ca6a07c1b471ee3ae608e23caaa11f47305af8b75e0dd5e4b261cf")
