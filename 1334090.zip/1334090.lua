-- Lua provided by SkyAPI 
-- Game: Kardboard Kings Demo
addappid(1334090)
addappid(1334091, 1, "59cde7c3c060e6086e224969177c6db0195084789052404ecb66859e44581c15")
