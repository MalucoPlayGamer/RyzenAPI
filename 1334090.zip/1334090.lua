-- Lua provided by RyzenAPI
-- Game: Kardboard Kings Demo

-- MAIN APPLICATION
addappid(1334090)
-- Game: addappid(1334090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334091, 1, "59cde7c3c060e6086e224969177c6db0195084789052404ecb66859e44581c15")
