-- Lua provided by RyzenAPI
-- Game: Seasons of Rocco

-- MAIN APPLICATION
addappid(2700510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2700511, 1, "0704f76f8853d4634ffc21c876591e6ad4bcb1e9d8f555e8d6b0518689228c37")

