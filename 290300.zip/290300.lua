-- Lua provided by RyzenAPI
-- Game: Rebel Galaxy

-- MAIN APPLICATION
addappid(290300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(290301, 1, "8b721bf053bd3d46388293b84eca350884abcfe6cd71b2e909952978386f57c0")
addappid(290302, 1, "dcf79fb675dbbd0d4b7787ca78fd57b946aea706eff3af8fd0a4bc446dbcc7b4")

