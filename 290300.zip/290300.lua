-- Lua provided by RyzenAPI
-- Game: Rebel Galaxy

-- MAIN APPLICATION
addappid(290300)

-- MAIN APP DEPOTS / PACKAGES
addappid(290301, 1, "8b721bf053bd3d46388293b84eca350884abcfe6cd71b2e909952978386f57c0")
addappid(290302, 1, "dcf79fb675dbbd0d4b7787ca78fd57b946aea706eff3af8fd0a4bc446dbcc7b4")

