-- Lua provided by RyzenAPI
-- Game: 691080

-- MAIN APPLICATION
addappid(691080)
-- Game: addappid(691080)

-- MAIN APP DEPOTS / PACKAGES
addappid(691081, 1, "87a2404704163d3777233a4d8d5ab8f64f8720ff3683a5a7c2e28b9aa8c02b25")
