-- Lua provided by RyzenAPI
-- Game: 3604550

-- MAIN APPLICATION
addappid(3604550)
-- Game: addappid(3604550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3604551, 1, "2aed629ae7a6d7654de2a32984ec292f74b1fd741e29faf3e1bbc607b4e4ac93")
