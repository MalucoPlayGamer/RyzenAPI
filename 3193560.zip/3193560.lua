-- Lua provided by RyzenAPI
-- Game: Yokai Landlord: Monster Mystery!

-- MAIN APPLICATION
addappid(3193560)
-- Game: addappid(3193560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3193561, 1, "a581b321d5ae768ca569b9bf7498b3fa0dfb8e144d6f898ed903c6ea44cfa82f")
