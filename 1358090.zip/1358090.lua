-- Lua provided by RyzenAPI
-- Game: Open Hexagon

-- MAIN APPLICATION
addappid(1358090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358091, 1, "404c4205efb71afcc928a7055c2b83ee8fb2d787b5761812c73650ffb1e07c32")
addappid(1358092, 1, "2d426787fe2b932892d9d9ad4a63777b1bb182bc0507e3a5cede7f2834dc5712")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
