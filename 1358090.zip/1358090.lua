-- Lua provided by RyzenAPI
-- Game: Open Hexagon

-- MAIN APPLICATION
addappid(1358090)
-- Game: addappid(1358090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1358091, 1, "404c4205efb71afcc928a7055c2b83ee8fb2d787b5761812c73650ffb1e07c32")
addappid(1358092, 1, "2d426787fe2b932892d9d9ad4a63777b1bb182bc0507e3a5cede7f2834dc5712")
