-- Lua provided by RyzenAPI
-- Game: addappid(3086180)

-- MAIN APPLICATION
addappid(3086180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3086181, 1, "e1378664aca0448f83d2f3f08e9929e238f4a2cd4049bb0f216025a62b05a2cd")
