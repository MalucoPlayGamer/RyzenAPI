-- Lua provided by RyzenAPI
-- Game: Tower of Eglathia

-- MAIN APPLICATION
addappid(351220)

-- MAIN APP DEPOTS / PACKAGES
addappid(351221,0,"3e7fc055f5527730ac819252c2351920bfaeaadf45fe6087a71d199597afb1fc")

