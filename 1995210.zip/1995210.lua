-- Lua provided by RyzenAPI
-- Game: AppID 1995210

-- MAIN APPLICATION
addappid(1995210)
-- Game: addappid(1995210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995211, 1, "b82d7cdbb91aebc11a4d6e7b2d987fcb6707d86bde9fe71b1d7ca34416a1c456")
