-- Lua provided by RyzenAPI
-- Game: Game: Cricket Captain 2024

-- MAIN APPLICATION
addappid(2900670)
-- Game: addappid(2900670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2900671, 1, "41bb57cd6386e42eb1cf0d8d8c7ddf55bf384f69123dafccd52eff5fcd267059")
