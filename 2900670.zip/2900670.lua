-- Lua provided by RyzenAPI
-- Game: Cricket Captain 2024

-- MAIN APPLICATION
addappid(2900670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2900671, 1, "41bb57cd6386e42eb1cf0d8d8c7ddf55bf384f69123dafccd52eff5fcd267059")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
