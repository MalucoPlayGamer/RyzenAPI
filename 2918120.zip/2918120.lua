-- Lua provided by RyzenAPI 
-- Game: Circoid
addappid(2918120)
addappid(2918121, 1, "5dc8966188f11a72c4c0cd1379fb35d671894bb2b67e9d4ad79240ffc14f547d")
