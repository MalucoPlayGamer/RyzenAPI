-- Lua provided by RyzenAPI
-- Game: 末日纷争

-- MAIN APPLICATION
addappid(1792710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1792711, 1, "267e84d69e5239657b7b4f0650bd8a432d3209fe7f55c72205aa35399a10b5ca")

