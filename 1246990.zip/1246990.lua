-- Lua provided by RyzenAPI
-- Game: addappid(1246990)

-- MAIN APPLICATION
addappid(1246990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246991, 1, "b85860854efd7606fbb57ebd56319a879667a65dcd61e94dbbbe656994abcb02")
