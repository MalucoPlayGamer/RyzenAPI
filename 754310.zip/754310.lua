-- Lua provided by RyzenAPI
-- Game: Deadly Cryptids

-- MAIN APPLICATION
addappid(754310)

-- MAIN APP DEPOTS / PACKAGES
addappid(754311, 1, "1bd9ca8adfeddc072354cc172af4501f6275137d640a352bfe6779c753df2f63")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
