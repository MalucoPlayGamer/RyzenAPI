-- Lua provided by RyzenAPI
-- Game: Game: Deadly Cryptids

-- MAIN APPLICATION
addappid(754310)
-- Game: addappid(754310)

-- MAIN APP DEPOTS / PACKAGES
addappid(754311, 1, "1bd9ca8adfeddc072354cc172af4501f6275137d640a352bfe6779c753df2f63")
