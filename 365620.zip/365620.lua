-- Lua provided by RyzenAPI
-- Game: WarBirds 2026

-- MAIN APPLICATION
addappid(365620)

-- MAIN APP DEPOTS / PACKAGES
addappid(365621, 1, "04db506a108f231ea9d01ee858d2d732f893838387b693c3c42733833343eabe")
addappid(365622, 1, "3e4f7a404346036b8e2f9409bc94e700212be34c1a06a33722e3279ecce1778e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
