-- Lua provided by RyzenAPI
-- Game: Game: AppID 1201350

-- MAIN APPLICATION
addappid(1201350)
-- Game: addappid(1201350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201351, 1, "54b76a57eeba942e53614a5081722fe47ac8f5ae6bbbc0ea317feb523e8d5e83")
