-- Lua provided by RyzenAPI
-- Game: Game: 校长模拟器

-- MAIN APPLICATION
addappid(1420780)
-- Game: addappid(1420780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420781, 1, "83a3dc16d8c50cecbdc7d32d3c7e67472e7ce711e34c1c8146db99a83158bca5")
