-- Lua provided by RyzenAPI
-- Game: Gnaughty Gnomes

-- MAIN APPLICATION
addappid(3454480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3454481,0,"aca8b40ecb8589cf444c5554e6c699cdc98da62c0d20f0112b8fdfefebe2353e")

