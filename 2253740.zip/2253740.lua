-- Lua provided by RyzenAPI
-- Game: Game: 国产手机帝国-Mobile phone empire

-- MAIN APPLICATION
addappid(2253740)
-- Game: addappid(2253740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2253741, 1, "2306c77081fc076827905d405a94a726c3b89e71aa89d223d6ab20766959b761")
