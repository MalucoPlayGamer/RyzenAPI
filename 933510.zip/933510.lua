-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4/無双OROCHI３ - Legendary Costumes Wei Pack 2

-- MAIN APPLICATION
addappid(933510)

-- MAIN APP DEPOTS / PACKAGES
addappid(933510,0,"77bb1805984d0e37b6ce83c7084a48f1dceb1a00fff5f07d4419f44cae5b2101")
