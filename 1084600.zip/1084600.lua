-- Lua provided by RyzenAPI
-- Game: AppID 1084600

-- MAIN APPLICATION
addappid(1084600)
addappid(2181522)
addappid(2181528)
addappid(2595600)
addappid(2595610)
addappid(2595620)
addappid(2595710)
addappid(2595720)
addappid(2595730)
addappid(2595740)
addappid(2595750)
addappid(2595760)
addappid(2622210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1084601, 1, "7af65c0378d727ff872dcf1bfc511faa6bda56ddb31f4d891ba88a15e5540d17")
addappid(1084602, 1, "262b20ffd5fbd41eb4e6993b44dba982695731cf82c7f787236a1bc1b82109aa")
addappid(1084603, 1, "5298981b009169e714731cbf957866f073237c264807e27cc5ddc061d41efb5d")
addappid(2182080, 0, "8052cc32bd4cd71ff86ef8c4db68c2dc5ab50884feea0cc90db814a73eb3dcf7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2808740)
addappid(2969170)
