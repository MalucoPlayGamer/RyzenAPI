-- Lua provided by RyzenAPI
-- Game: 2685260

-- MAIN APPLICATION
addappid(2685260)
-- Game: addappid(2685260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2685261, 1, "e5349e73885aff2dcfb6e8933e9ee0b6cbbaa7c116cef4f4dd50e4e22b4a3c5f")
