-- Lua provided by RyzenAPI
-- Game: Weapons Genius

-- MAIN APPLICATION
addappid(385400)
addappid(1247480)

-- MAIN APP DEPOTS / PACKAGES
addappid(385401, 1, "ac55b118a03cf7d4713ce7f10d4a3e24565fc9033bb93999c803557472c4a7d8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
