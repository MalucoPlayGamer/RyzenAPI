-- Lua provided by RyzenAPI
-- Game: Game: Weapons Genius

-- MAIN APPLICATION
addappid(385400)
addappid(1247480)
-- Game: addappid(385400)

-- MAIN APP DEPOTS / PACKAGES
addappid(385401, 1, "ac55b118a03cf7d4713ce7f10d4a3e24565fc9033bb93999c803557472c4a7d8")
