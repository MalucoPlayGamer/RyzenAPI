-- Lua provided by RyzenAPI
-- Game: DIVE: Starpath

-- MAIN APPLICATION
addappid(475070)

-- MAIN APP DEPOTS / PACKAGES
addappid(475071, 1, "5008b4fe38d6e4e3e795af6632d33d384b1dba4e61fb2bec19c2eb21bfa90f0a")

