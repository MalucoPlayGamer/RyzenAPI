-- Lua provided by RyzenAPI
-- Game: Game: GRAY

-- MAIN APPLICATION
addappid(1034700)
-- Game: addappid(1034700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034701, 1, "5c4802e08bfdc737895b13f88a7101c8a855703010b55529f5c46e09cc825100")
