-- Lua provided by RyzenAPI
-- Game: GRAY

-- MAIN APPLICATION
addappid(1034700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034701, 1, "5c4802e08bfdc737895b13f88a7101c8a855703010b55529f5c46e09cc825100")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
