-- Lua provided by RyzenAPI
-- Game: 1957880

-- MAIN APPLICATION
addappid(1957880)
-- Game: addappid(1957880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1957881, 1, "14e083f257afc9e7b9baf0038c103e57258c69368daa151b83f6003307a3d8f3")
