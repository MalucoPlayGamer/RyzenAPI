-- Lua provided by RyzenAPI
-- Game: AppID 375190

-- MAIN APPLICATION
addappid(375190)
-- Game: addappid(375190)

-- MAIN APP DEPOTS / PACKAGES
addappid(375191, 1, "6aa64485a79423ab82b4c1c005261096f7d2da57353ea7d1d18171e6c65a52e3")
