-- Lua provided by RyzenAPI
-- Game: addappid(2669090)

-- MAIN APPLICATION
addappid(2669090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2669092,0,"aca4319e44bc308d5fd165f6700e963ffa2df2fa9f6947fa0c4b8cb47f18f902")
