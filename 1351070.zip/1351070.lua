-- Lua provided by RyzenAPI 
-- Game: Pest Control
addappid(1351070)
addappid(1351071, 1, "e5378589e000a4122a0729323603b0d8979015d0c02457aebd82cb8214aed5e3")
addappid(1351079, 1, "9d23b706b7cf0de5a9284b4d4c9ac642d9e2fbe1e0ecbf880a8659cc1f79ed67")
