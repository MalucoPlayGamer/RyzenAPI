-- Lua provided by RyzenAPI
-- Game: Survival Girls

-- MAIN APPLICATION
addappid(1827550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1827551, 1, "e1e5a8b38967000dbfc1fee2bb1c313d5f8dff77b7181c1cf7463980cda37923")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
