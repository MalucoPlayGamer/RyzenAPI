-- Lua provided by RyzenAPI
-- Game: Love Chronicles: The Sword and the Rose Collector's Edition

-- MAIN APPLICATION
addappid(695940)

-- MAIN APP DEPOTS / PACKAGES
addappid(695941,0,"b4bca7d519343f50926522234572fcd50571dbefb4123f13b5014e6b2cd9f24b")

