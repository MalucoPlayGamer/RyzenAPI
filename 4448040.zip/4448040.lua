-- Lua provided by RyzenAPI
-- Game: Biomechanical Toy (QUByte Classics)

-- MAIN APPLICATION
addappid(4448040) -- Biomechanical Toy (QUByte Classics)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4448041, 1, "0ebf73c12b1282687bc8c2d733817589a2469e73b06a5dc60aa9fb3612a64b2a") -- Depot 4448041

