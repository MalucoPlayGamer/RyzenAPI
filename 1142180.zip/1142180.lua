-- Lua provided by RyzenAPI
-- Game: SE VR World Demo

-- MAIN APPLICATION
addappid(1142180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1142181, 1, "5be47fadf1450c609b218d82164e12926873af0e59d82661838e3cce95d0db30")
