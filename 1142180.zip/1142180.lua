-- Lua provided by RyzenAPI
-- Game: addappid(1142180)

-- MAIN APPLICATION
addappid(1142180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142181, 1, "5be47fadf1450c609b218d82164e12926873af0e59d82661838e3cce95d0db30")
