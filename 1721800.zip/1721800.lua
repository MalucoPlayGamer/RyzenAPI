-- Lua provided by SkyAPI 
-- Game: 八尾
addappid(1721800)
addappid(1721801, 1, "f0132f50ddaac221d4a4fcf459f43af9169605212234b0ec48afb90fdcf5ca5a")
