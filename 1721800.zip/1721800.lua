-- Lua provided by RyzenAPI
-- Game: 八尾

-- MAIN APPLICATION
addappid(1721800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1721801, 1, "f0132f50ddaac221d4a4fcf459f43af9169605212234b0ec48afb90fdcf5ca5a")

