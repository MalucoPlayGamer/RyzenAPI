-- Lua provided by RyzenAPI
-- Game: Tower! Simulator 3 - KDEN Airport

-- MAIN APPLICATION
addappid(3579270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3579270,0,"454723f48425f65546cb652d8be6e9bd78bf0f2476b3c38e451e06cc9540c5d6")
