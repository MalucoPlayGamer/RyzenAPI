-- Lua provided by RyzenAPI
-- Game: Game: AppID 623340

-- MAIN APPLICATION
addappid(623340)
-- Game: addappid(623340)

-- MAIN APP DEPOTS / PACKAGES
addappid(623341, 1, "b7a167ab8fa7c19e19327574d5b79ae8463a904bf54573342cb2ad95ef0cb9be")
