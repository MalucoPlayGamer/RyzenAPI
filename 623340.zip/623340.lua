-- Lua provided by RyzenAPI
-- Game: AppID 623340

-- MAIN APPLICATION
addappid(623340)

-- MAIN APP DEPOTS / PACKAGES
addappid(623341, 1, "b7a167ab8fa7c19e19327574d5b79ae8463a904bf54573342cb2ad95ef0cb9be")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
