-- Lua provided by RyzenAPI
-- Game: The Elephant Collection

-- MAIN APPLICATION
addappid(2274110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2274111, 1, "d00f28ea533394500c484267c59c997e947297cce8bad327ada037e5c3b3d783")
