-- Lua provided by RyzenAPI
-- Game: 3368020

-- MAIN APPLICATION
addappid(3368020)
-- Game: addappid(3368020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3368021, 1, "42a1088c63be5b79b76163cecf457d8cd792bcf76334c1e73467d25845a4b4fb")
