-- Lua provided by RyzenAPI
-- Game: Game: Inversion

-- MAIN APPLICATION
addappid(1505430)
-- Game: addappid(1505430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1505431, 1, "1724541a8185c4512d88377647b4e6768797a4d84c5a1eb87178b5eb160492a5")
