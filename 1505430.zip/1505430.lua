-- Lua provided by RyzenAPI 
-- Game: Inversion
addappid(1505430)
addappid(1505431, 1, "1724541a8185c4512d88377647b4e6768797a4d84c5a1eb87178b5eb160492a5")
