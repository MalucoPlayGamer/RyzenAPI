-- Lua provided by RyzenAPI
-- Game: POOSTALL Royale

-- MAIN APPLICATION
addappid(2362740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362741, 1, "c133af0ae4820533960b5b39b49bc6cb1f00a07b9462d6789f767de73c54afef")
