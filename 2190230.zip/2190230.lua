-- Lua provided by SkyAPI 
-- Game: Dust and Aliens
addappid(2190230)
addappid(2190231, 1, "c18bb38d06488e38449167566a76fbcfb95f4cc750d15411ec8aea1d8005e5f6")
