-- Lua provided by RyzenAPI
-- Game: Dust and Aliens

-- MAIN APPLICATION
addappid(2190230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2190231, 1, "c18bb38d06488e38449167566a76fbcfb95f4cc750d15411ec8aea1d8005e5f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
