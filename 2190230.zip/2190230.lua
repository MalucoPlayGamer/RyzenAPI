-- Lua provided by RyzenAPI
-- Game: Dust and Aliens

-- MAIN APPLICATION
addappid(2190230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2190231, 1, "c18bb38d06488e38449167566a76fbcfb95f4cc750d15411ec8aea1d8005e5f6")
