-- Lua provided by RyzenAPI 
-- Game: Jets'n'Guns Gold
addappid(262260)
addappid(262261, 1, "faf003caf0209c5975fbf5b0371ef2f48bb097460d4998f5f0a9c9b7f2a33d56")
addappid(262262, 1, "682ccc824246fcae0de2c8b86e85b932c9b40f4c780a2a701dd7ae5a2f966c3f")
addappid(262263, 1, "3e1787f32b21fe47973344513fc6454e141fd641e25929005e96e45f28024403")
