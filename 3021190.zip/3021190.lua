-- Lua provided by RyzenAPI
-- Game: 灵兽江湖 Demo

-- MAIN APPLICATION
addappid(3021190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3021191, 1, "6aaf1c981c49d7a75cae0ffaa9aed632a41eeacdbb7da4b4d91034ed9ab3315a")

