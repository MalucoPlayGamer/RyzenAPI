-- Lua provided by RyzenAPI
-- Game: Astrality

-- MAIN APPLICATION
addappid(2485620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485621, 1, "b7fdfce893552f7fbfd8d7b79d866b17c9cc0014177ebf404198d9f6c7d97c6d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
