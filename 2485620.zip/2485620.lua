-- Lua provided by SkyAPI 
-- Game: Astrality
addappid(2485620)
addappid(2485621, 1, "b7fdfce893552f7fbfd8d7b79d866b17c9cc0014177ebf404198d9f6c7d97c6d")
