-- Lua provided by RyzenAPI
-- Game: addappid(2752880)

-- MAIN APPLICATION
addappid(2752880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752881, 1, "7b09ecfcea34e432ca068b5734faa0b8237e4a5141c50fac1769f0e771f9942d")
