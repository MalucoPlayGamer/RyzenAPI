-- Lua provided by RyzenAPI
-- Game: Micronomicon: Heroes

-- MAIN APPLICATION
addappid(601250)

-- MAIN APP DEPOTS / PACKAGES
addappid(601251, 1, "4d61d92536a17906ec5530bf0fbcd4eb72ab4a1a84705a77f3dd5f72a9ece964")

