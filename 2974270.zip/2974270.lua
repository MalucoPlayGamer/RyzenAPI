-- Lua provided by RyzenAPI
-- Game: addappid(2974270)

-- MAIN APPLICATION
addappid(2974270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2974271, 1, "14ee08fbb4bd6c98afd8a2fcd4249bc04eb5a7985383f908d5f958797c875341")
