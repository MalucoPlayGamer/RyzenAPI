-- Lua provided by RyzenAPI
-- Game: Hentai Clicker: Maria is streaming

-- Main AppID
addappid(3519590) -- Hentai Clicker: Maria is streaming

-- Main Depots
addappid(3519591, 1, "51fedfdd3cc84fb9b8a313570cc7195decb73bbab63fbc5ffa8b3d87ac07eb8d") -- (windows)
-- setManifestid(3519591, "6217605048325780727", 231600394)

-- Missing Depots (We don't have the keys yet lol): 3519592, 3519593
