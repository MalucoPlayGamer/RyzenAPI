-- Lua provided by RyzenAPI 
-- Game: AppID 238050
addappid(238050)
addappid(238051, 1, "e8154fbea4a18bca4c3b10173fc55082161e32e8e6f9d8b256cf311940e2526a")
addappid(238052, 1, "e5a68896665a76e86977789c5389d16e0c1a01ec9297068da730d635afd2e66f")
