-- Lua provided by RyzenAPI
-- Game: 3466690

-- MAIN APPLICATION
addappid(3466690)
-- Game: addappid(3466690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3466691, 1, "1a3df1326f2bd25151ef4168d2fe57b09cd07ae91c7ccf7e7ff949b4e56a8ac7")
addappid(3466692, 1, "e6e2a6300f54dccefe03fba409320b3d134e5ad04439a95601c3ae6c9ea64592")
