-- Lua provided by RyzenAPI
-- Game: AppID 2109020

-- MAIN APPLICATION
addappid(2109020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109021, 1, "81a4820a39515b54ea38e813fba615c0598159bce52db25fb28d033822dddf44")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
