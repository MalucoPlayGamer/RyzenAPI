-- Lua provided by RyzenAPI
-- Game: 2109020

-- MAIN APPLICATION
addappid(2109020)
-- Game: addappid(2109020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109021, 1, "81a4820a39515b54ea38e813fba615c0598159bce52db25fb28d033822dddf44")
