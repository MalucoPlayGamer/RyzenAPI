-- Lua provided by RyzenAPI
-- Game: Banyu Lintar Angin - Little Storm -

-- MAIN APPLICATION
addappid(744800)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(760610)
