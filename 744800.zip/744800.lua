-- Lua provided by RyzenAPI
-- Game: Banyu Lintar Angin - Little Storm -

-- MAIN APPLICATION
addappid(744800)
addappid(760610)

