-- Lua provided by RyzenAPI
-- Game: Game: Kitten's Wardrobe

-- MAIN APPLICATION
addappid(2571400)
-- Game: addappid(2571400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2571401, 1, "64d2df244edd23b9411200e534abe2a472340e6d7855aeb58d2450dc4984b2da")
