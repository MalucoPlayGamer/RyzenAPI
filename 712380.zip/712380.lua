-- Lua provided by SkyAPI 
-- Game: AppID 712380
addappid(712380)
addappid(712381, 1, "5fbba3a0538cb9aceca4484732e69e31d7298888ba18a492c03cb21b6850015a")
