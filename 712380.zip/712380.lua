-- Lua provided by RyzenAPI
-- Game: 712380

-- MAIN APPLICATION
addappid(712380)
-- Game: addappid(712380)

-- MAIN APP DEPOTS / PACKAGES
addappid(712381, 1, "5fbba3a0538cb9aceca4484732e69e31d7298888ba18a492c03cb21b6850015a")
