-- Lua provided by RyzenAPI
-- Game: Game: AppID 733820

-- MAIN APPLICATION
addappid(733820)
-- Game: addappid(733820)

-- MAIN APP DEPOTS / PACKAGES
addappid(733821, 1, "77a6aa1c21bb5dd7d3905d9c2e13c7f39b22354359b268dd4217ae2cce41782e")
