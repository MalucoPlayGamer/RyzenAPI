-- Lua provided by RyzenAPI 
-- Game: PARASiTE FLOWER
addappid(2855480)
addappid(2855481, 1, "10b80ab1e3a7ab5d194c5fd71d2ce3e7f36df604e972479b7aa919b36ac0376e")
