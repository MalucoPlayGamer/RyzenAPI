-- Lua provided by RyzenAPI
-- Game: Zorro and Zedd

-- MAIN APPLICATION
addappid(2599630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2599631, 1, "2adf5805178c791afa5d2a031a71c73cc849b85ca72b42f7c50514865fca9aeb")

