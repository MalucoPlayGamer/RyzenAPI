-- Lua provided by RyzenAPI
-- Game: VR NSFW Desktop Mode

-- MAIN APPLICATION
addappid(2334510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334510,0,"9969adb39b6cac7cf48e471a9d0920546311b2031b10c8f8246ff088178a5b6f")

