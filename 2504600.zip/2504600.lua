-- Lua provided by RyzenAPI
-- Game: addappid(2504600)

-- MAIN APPLICATION
addappid(2504600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2504601, 1, "748a138e138f241d762920fadfcc7161080d43c424d5c0aed4a5232b366db48a")
