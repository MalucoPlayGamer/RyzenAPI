-- Lua provided by RyzenAPI
-- Game: Game: ISEKAI QUEST

-- MAIN APPLICATION
addappid(1268110)
-- Game: addappid(1268110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268111, 1, "2cc27adba9ed2e1ae7f47091e6f5d5cdfdcc1bcaa71aa027041b7e78d6ee3d4c")
addappid(1268112, 1, "4e27331c8fbb57aba781b4b4acad469843082e0bd4a58d870c1bf703f0455a62")
