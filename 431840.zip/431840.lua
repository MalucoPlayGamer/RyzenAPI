-- Lua provided by RyzenAPI
-- Game: 3DRPG

-- MAIN APPLICATION
addappid(431840)

-- MAIN APP DEPOTS / PACKAGES
addappid(431841, 1, "277953cfe9eb97b9cbb6af3886da4de5e93de4cf3ca48d721ac6558eec5f8c9f")

