-- Lua provided by SkyAPI 
-- Game: AppID 776280
addappid(776280)
addappid(776281, 1, "f10c43cc5938a8fb9bbaccd62f7a2ba8d82d734d933a1e9e1d4567081703b98b")
