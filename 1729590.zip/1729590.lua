-- Lua provided by RyzenAPI
-- Game: Auto Cell: Game of Life

-- MAIN APPLICATION
addappid(1729590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729591, 1, "e1dc36759f9d5b228d821b0f2eddde13f16d3f7bba69bab095df127f6e25a186")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
