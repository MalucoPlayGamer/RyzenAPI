-- Lua provided by RyzenAPI
-- Game: Auto Cell: Game of Life

-- MAIN APPLICATION
addappid(1729590)
-- Game: addappid(1729590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729591, 1, "e1dc36759f9d5b228d821b0f2eddde13f16d3f7bba69bab095df127f6e25a186")
