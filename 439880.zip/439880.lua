-- Lua provided by RyzenAPI
-- Game: Game: Heroes of Loot 2

-- MAIN APPLICATION
addappid(439880)
-- Game: addappid(439880)

-- MAIN APP DEPOTS / PACKAGES
addappid(439881, 1, "00eeb1c2aaa7e2204fbbadf35d94d8e5e9d00199576dcbf4096d6c8161e9e856")
