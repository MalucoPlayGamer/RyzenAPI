-- Lua provided by RyzenAPI
-- Game: Airport Simulator 2014

-- MAIN APPLICATION
addappid(267600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(267601, 1, "8bdaa378787c73b9b6ef3bf3ac2f5986e08793b51a21f0bb9c8b5321a03f68fa")
addappid(267602, 1, "bb4990ea8d1a3869939b9c670e49e10c56cadf711d82eba5d9bd84ceb28b445d")
addappid(267603, 1, "a191096400262e4f85678c28968146645f5b628eebd73be64a941000c8d5a9d1")
addappid(267604, 1, "df1ec8a5a8e347f929965c3f883750573c03ebcb65498dbd04d150ee1c6e517e")
addappid(267605, 1, "652ae38fedb6f5e12cd024d23726b570dafbe03aa469ae6a3c3e5f710270abc0")
