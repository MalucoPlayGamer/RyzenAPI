-- Lua provided by RyzenAPI
-- Game: Game: CHR$(143)

-- MAIN APPLICATION
addappid(1695620)
-- Game: addappid(1695620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1695621, 1, "e20920d081f07cde0a8e949c29f1768b962fa7793679bf1da932814d347b4caf")
