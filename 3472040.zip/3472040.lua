-- Lua provided by RyzenAPI
-- Game: NBA 2K26

-- MAIN APPLICATION
addappid(3472040)
addappid(3657590)
addappid(3657600)
addappid(3657610)
addappid(3657620)
addappid(3825290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3472041, 1, "98720ddedf5fb5a37faf70ca90602a9949e727a7f7b6b9171ecc2764ee2d3b21")
addappid(3472042, 1, "34db1ecbd759eab0b3e63e7304bc8fe901b1ca351a3d453affb865d97c5e62be")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3657560)
addappid(3657640)
addappid(3657650)
addappid(3657660)
addappid(3657670)
addappid(3657680)
addappid(3657690)
addappid(3657700)
addappid(3657710)
addappid(3657750)
addappid(3657760)
addappid(3657770)
addappid(3657780)
addappid(3657790)
addappid(3657800)
addappid(3657810)
addappid(3657820)
addappid(3657840)
addappid(3657850)
addappid(3657860)
addappid(3657870)
addappid(3657880)
addappid(3657890)
addappid(3657900)
addappid(3657910)
addappid(3657920)
addappid(3657930)
addappid(3657940)
addappid(3657950)
addappid(3657960)
addappid(3657970)
addappid(3657980)
addappid(3657990)
addappid(3901020)
addappid(3901030)
addappid(4765430)
