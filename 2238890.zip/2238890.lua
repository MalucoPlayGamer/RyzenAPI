-- Lua provided by RyzenAPI
-- Game: DancingSim

-- MAIN APPLICATION
addappid(2238890)
-- Game: addappid(2238890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2238891, 1, "eb5a9325fa5ae79bd24499e4ff70e1defd424745ef6cca3e7de00ffcd8c8513e")
