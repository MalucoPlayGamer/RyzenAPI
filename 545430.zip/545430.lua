-- Lua provided by RyzenAPI 
-- Game: Bedfellows FRENZY
addappid(545430)
addappid(545431, 1, "21bfdb3cd7503aaa47f90c48a9de2d0bf0452d055e4fe74319f1a620b3fd52d4")
addappid(574790)
