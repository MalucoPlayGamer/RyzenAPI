-- Lua provided by RyzenAPI
-- Game: Cactus Simulator

-- MAIN APPLICATION
addappid(1883580)
-- Game: addappid(1883580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1883581, 1, "30f9d1975082aea5f454c4d90d96bcb9061834f0f364d744e93e86f46a9025b1")
