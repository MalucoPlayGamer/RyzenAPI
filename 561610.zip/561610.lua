-- Lua provided by RyzenAPI 
-- Game: AppID 561610
addappid(561610)
addappid(561611, 1, "1356c658cbeea3760a250f5c49ff23e8e20f3609e25c91c9df41507e25d3f5ea")
