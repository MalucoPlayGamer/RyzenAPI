-- Lua provided by RyzenAPI
-- Game: addappid(561610)

-- MAIN APPLICATION
addappid(561610)

-- MAIN APP DEPOTS / PACKAGES
addappid(561611, 1, "1356c658cbeea3760a250f5c49ff23e8e20f3609e25c91c9df41507e25d3f5ea")
