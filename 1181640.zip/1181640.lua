-- Lua provided by RyzenAPI
-- Game: Game: Project Exhibited

-- MAIN APPLICATION
addappid(1181640)
-- Game: addappid(1181640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181641, 1, "08eae8c98910f092fa0e8c15de9e2db7dc33f00c362436892e00789dec95f775")
