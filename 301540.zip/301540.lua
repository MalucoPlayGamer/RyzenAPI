-- Lua provided by RyzenAPI 
-- Game: Rhythm Destruction
addappid(301540)
addappid(301541, 1, "42d5503ec520a2b23b5effba6cbfa05d51ed4a949f88eb548b346bea1f864f57")
addappid(305150, 0, "6e3d63ea4f2cfb4ff7a11734473b7f7d35c73a771bc9d58e1935a6455163521d")
