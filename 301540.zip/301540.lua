-- Lua provided by RyzenAPI
-- Game: Rhythm Destruction

-- MAIN APPLICATION
addappid(301540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(229011, 1, "1752f232024a07db347d180533cf95ce5a1233ae3bad0b0093949174079898df") -- (windows)
addappid(301541, 1, "42d5503ec520a2b23b5effba6cbfa05d51ed4a949f88eb548b346bea1f864f57")
addappid(305150, 0, "6e3d63ea4f2cfb4ff7a11734473b7f7d35c73a771bc9d58e1935a6455163521d")

