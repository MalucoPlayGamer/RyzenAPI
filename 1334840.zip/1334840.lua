-- Lua provided by RyzenAPI
-- Game: addappid(1334840)

-- MAIN APPLICATION
addappid(1334840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334841, 1, "f75dbe8f4b63c1f28431ee689ce91756d2cc37a1ddbbfdb92a9d41c2f9d67d9d")
