-- Lua provided by RyzenAPI
-- Game: GOHOME

-- MAIN APPLICATION
addappid(1334840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334841, 1, "f75dbe8f4b63c1f28431ee689ce91756d2cc37a1ddbbfdb92a9d41c2f9d67d9d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
