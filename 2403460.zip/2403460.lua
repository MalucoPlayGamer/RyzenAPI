-- Lua provided by RyzenAPI
-- Game: Moving Out 2 - Soundtrack

-- MAIN APPLICATION
addappid(2403460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2403462,0,"e87ba56bb37d28f109e08dbd8dbdc0e13debb44dda2cfa9e216c3d1cd59e9b2b")
addappid(2403463,0,"892b3094972b94cea317e6fd6f0bfd3a9efa4470bc3a8003a77d7bffb928419c")

