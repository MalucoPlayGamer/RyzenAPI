-- Lua provided by RyzenAPI
-- Game: Tahul

-- MAIN APPLICATION
addappid(1370510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370511, 1, "011baff4c9f3761c6a75047df9390a6ffc4587f2f30b73174954c9fd959e200a")
