-- Lua provided by RyzenAPI
-- Game: Tahul

-- MAIN APPLICATION
addappid(1370510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1370511, 1, "011baff4c9f3761c6a75047df9390a6ffc4587f2f30b73174954c9fd959e200a")

