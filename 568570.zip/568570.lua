-- Lua provided by RyzenAPI
-- Game: Force of Nature

-- MAIN APPLICATION
addappid(568570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(568571, 1, "bb3c543016ff599b4bbeebaa163d5b41976b898951c3ff5672eecb4705cdf00c")

