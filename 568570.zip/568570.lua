-- Lua provided by RyzenAPI
-- Game: 568570

-- MAIN APPLICATION
addappid(568570)
-- Game: addappid(568570)

-- MAIN APP DEPOTS / PACKAGES
addappid(568571, 1, "bb3c543016ff599b4bbeebaa163d5b41976b898951c3ff5672eecb4705cdf00c")
