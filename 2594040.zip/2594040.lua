-- Lua provided by RyzenAPI
-- Game: Beat Saber - Linkin Park - Crawling

-- MAIN APPLICATION
addappid(2594040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594040,0,"c219d336c89166572dde3b9ec7352453fdb4c3431810081791b557561755f5d0")

