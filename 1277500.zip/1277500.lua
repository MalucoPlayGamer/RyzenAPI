-- Lua provided by RyzenAPI
-- Game: Skeletal Avenger

-- MAIN APPLICATION
addappid(1277500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1277501, 1, "4aafde6a00b0e391e133b88263cb010e747665ddd49b2ddc8c293b6ebabb382b")
