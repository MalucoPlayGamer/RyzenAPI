-- Lua provided by RyzenAPI
-- Game: Filament Soundtrack

-- MAIN APPLICATION
addappid(1279680)
-- Game: addappid(1279680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279681, 1, "93e16db06e817bb290ed118afd493de44099576172815d72dcdee631b28382aa")
