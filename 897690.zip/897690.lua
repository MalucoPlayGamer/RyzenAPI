-- Lua provided by RyzenAPI
-- Game: Ding Dong VR

-- MAIN APPLICATION
addappid(897690)

-- MAIN APP DEPOTS / PACKAGES
addappid(897691, 1, "94d48a7b75aa97df48bc10e7f6d7a8d52c9061466671e071b6c6d95a7acb1a17")

