-- Lua provided by RyzenAPI
-- Game: 100 Cats Lost In Canada Find & Color

-- MAIN APPLICATION
addappid(3766210)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3965910)
