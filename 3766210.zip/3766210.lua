-- Lua provided by RyzenAPI
-- Game: 100 Cats Lost In Canada Find & Color

-- MAIN APPLICATION
addappid(3766210)

