-- Lua provided by RyzenAPI
-- Game: Game: Al Emmo and the Lost Dutchman's Mine

-- MAIN APPLICATION
addappid(296850)
-- Game: addappid(296850)

-- MAIN APP DEPOTS / PACKAGES
addappid(296851, 1, "750e2ada7571134810eb63a86a4aa1474231b4bb0b85ef16258be41b36d26516")
addappid(296852, 1, "bcb9bae077f1d306b8d38e2fbbb90f68e98c9d2b23539a5c43fa25afbeb483c1")
