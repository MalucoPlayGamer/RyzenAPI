-- Lua provided by RyzenAPI
-- Game: AppID 874200

-- MAIN APPLICATION
addappid(874200)
addappid(927030)
-- Game: addappid(874200)

-- MAIN APP DEPOTS / PACKAGES
addappid(874201, 1, "60873dc328893b825a1abad5e5e4806dee89c658f6351e7c7a28c5f2885812fc")
