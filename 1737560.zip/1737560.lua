-- Lua provided by RyzenAPI
-- Game: Backbeat Demo

-- MAIN APPLICATION
addappid(1737560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1737561, 1, "d41b22924085dc3f4e43fb62d7f64773fa428360d8ff2bf2a7cff94e56636625")
