-- Lua provided by RyzenAPI
-- Game: Spitkiss

-- MAIN APPLICATION
addappid(949770)
-- Game: addappid(949770)

-- MAIN APP DEPOTS / PACKAGES
addappid(949771, 1, "c4ec0b68089e54ecd1946832f2fd34d6949d648658cd65ea246a03b3a72b8611")
addappid(949772, 1, "e676f453a8d6c853a9d69ed824adad040849e4eed7a47c0a2be2fc7d0f48e85d")
