-- Lua provided by RyzenAPI
-- Game: Game: BLACKTAIL

-- MAIN APPLICATION
addappid(1532690)
-- Game: addappid(1532690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532691, 1, "d5f063b5eb0f808ff7d0e96cb3b35a5acdb5cac935d8af6a5740a4067c7cbb84")
