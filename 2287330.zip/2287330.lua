-- Lua provided by RyzenAPI
-- Game: Empire of the Ants

-- MAIN APPLICATION
addappid(2287330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2287331, 1, "3c0468cad17b6444999a764db47c1c60ac7729f89cfd4f3d51ebf028093ea4f2")
addappid(3126630, 0, "b5f73d6ef197c146069da44a9b909f0501439fd2f1a9f62d18b47108fa32cd51")

