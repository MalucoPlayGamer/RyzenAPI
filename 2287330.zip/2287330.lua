-- Lua provided by SkyAPI 
-- Game: Empire of the Ants
addappid(2287330)
addappid(2287331, 1, "3c0468cad17b6444999a764db47c1c60ac7729f89cfd4f3d51ebf028093ea4f2")
addappid(3126630, 0, "b5f73d6ef197c146069da44a9b909f0501439fd2f1a9f62d18b47108fa32cd51")
