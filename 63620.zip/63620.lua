-- Lua provided by RyzenAPI
-- Game: Cosmic Osmo and the Worlds Beyond the Mackerel

-- MAIN APPLICATION
addappid(63620)

-- MAIN APP DEPOTS / PACKAGES
addappid(63621, 1, "21edb707c57d6f16c7090542a01a9f99094247634868f04fc49422ef73f5750b")

