-- Lua provided by RyzenAPI
-- Game: Project Possession

-- MAIN APPLICATION
addappid(2090180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2090181, 1, "e0276262a2566e39263b7a24a30c7f0590cbec100f3c576549c1bd45368aa79b")
