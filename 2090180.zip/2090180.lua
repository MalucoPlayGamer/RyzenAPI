-- Lua provided by RyzenAPI
-- Game: Project Possession

-- MAIN APPLICATION
addappid(2090180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2090181, 1, "e0276262a2566e39263b7a24a30c7f0590cbec100f3c576549c1bd45368aa79b")

