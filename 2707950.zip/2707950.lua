-- Lua provided by RyzenAPI
-- Game: Pakinpaks

-- MAIN APPLICATION
addappid(2707950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707951,0,"3ed107d91071036ffd2700a1aca4b6f2078fc1e71000924182afbddcb95ba752")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
