-- Lua provided by RyzenAPI
-- Game: Pakinpaks

-- MAIN APPLICATION
addappid(2707950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707951,0,"3ed107d91071036ffd2700a1aca4b6f2078fc1e71000924182afbddcb95ba752")

