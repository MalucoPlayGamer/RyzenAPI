-- Lua provided by RyzenAPI
-- Game: Game: PERIOD SURVIVAL Soundtrack

-- MAIN APPLICATION
addappid(3500560)
-- Game: addappid(3500560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3500561, 1, "9b8671b80b419d31bdb3b6982c513b4c7f8cc67fa0ba1e1a2671d3b91e814051")
