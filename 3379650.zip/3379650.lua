-- Lua provided by RyzenAPI
-- Game: Dark PGT

-- MAIN APPLICATION
addappid(3379650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3379652,0,"793c18283f8c0958dc508b0db1a1c2a2b18cc2d7f36dedc325a3063f8d64ed57")

