-- Lua provided by RyzenAPI
-- Game: setManifestid(3379652,"3855679950306842996")

-- MAIN APPLICATION
addappid(3379650)
-- Game: addappid(3379650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3379652,0,"793c18283f8c0958dc508b0db1a1c2a2b18cc2d7f36dedc325a3063f8d64ed57")
