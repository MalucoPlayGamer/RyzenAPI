-- Lua provided by RyzenAPI
-- Game: Bonaparte - A Mechanized Revolution

-- MAIN APPLICATION
addappid(2560340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2560341, 1, "8bca18896136a286690aca12ab1b52ab1c6274e4501a749b64fd8e25e867ad98")

