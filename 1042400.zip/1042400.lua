-- Lua provided by RyzenAPI
-- Game: 1042400

-- MAIN APPLICATION
addappid(1042400)
-- Game: addappid(1042400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042400,0,"710ac84985d7f8b8a7e3f54c3d53e98f78903fe013e0fdc87cffb2023098430b")
