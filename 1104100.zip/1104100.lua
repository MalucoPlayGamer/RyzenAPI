-- Lua provided by RyzenAPI 
-- Game: Hentai Cuties
addappid(1104100)
addappid(1104101, 1, "caa5cd1ef5fa6946f932ccf2bcd2ce9db96c7e77c08b0fbe2c1f275b0c03e9c5")
