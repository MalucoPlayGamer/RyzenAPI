-- 1104100's Lua and Manifest Created by Hubcap Manifest
-- Hentai Cuties
-- Created: March 16, 2026 at 16:19:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(1104100, 1, "1fc44d74efa8a78768eeda98a3692a50f330a95ef7e8883e6f3175bea3ed01f2") -- Hentai Cuties
-- MAIN APP DEPOTS
addappid(1104101, 1, "caa5cd1ef5fa6946f932ccf2bcd2ce9db96c7e77c08b0fbe2c1f275b0c03e9c5") -- Hentai Content
setManifestid(1104101, "6659791282499588884", 257825955)
-- DLCS WITH DEDICATED DEPOTS
-- Uncensored DLC for Hentai Cuties (AppID: 1115710)
addappid(1115710)
addappid(1115710, 1, "9366bfb1013625e145a1e09ec0aadbf7bc25f02a480669ffd33ee55301049edc") -- Uncensored DLC for Hentai Cuties - Хранилище Uncensored DLC for Hentai Cuties
setManifestid(1115710, "5978753391575618401", 19819086)
-- Hentai Cuties - Artbook 18 (AppID: 1115720)
addappid(1115720)
addappid(1115720, 1, "b5d04a7eec595ee45e95acf58193fb7e1522aa72259c9b180131c2a81ae3b87e") -- Hentai Cuties - Artbook 18 - Хранилище Hentai Cuties - Artbook 18+
setManifestid(1115720, "8812257348566672848", 173512145)