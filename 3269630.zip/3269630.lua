-- Lua provided by RyzenAPI 
-- Game: Archaeology - Frozen Village
addappid(3269630)
addappid(3269631, 1, "eb2afd92be42fd3e25c52636d383537b6a845f5dd7d58d718e529ced2cb40cf2")
