-- Lua provided by RyzenAPI 
-- Game: AppID 2468670
addappid(2468670)
addappid(2468671, 1, "28d4f6666ff090e9b751af1858efcfe1efedfe35b26ec7dad0c3f41b937b4b56")
addappid(2468673, 1, "4e928c9be21942c773e75ee6afae61a53797c097f968da477cdd6c3184aa1744")
