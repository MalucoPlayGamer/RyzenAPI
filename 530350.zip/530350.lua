-- Lua provided by RyzenAPI
-- Game: 530350

-- MAIN APPLICATION
addappid(530350)
-- Game: addappid(530350)

-- MAIN APP DEPOTS / PACKAGES
addappid(530351, 1, "b6adc096f81de328fbafae10734a7bd91cb0e1f4dc92113e965b5c1c33008123")
