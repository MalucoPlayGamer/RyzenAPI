-- Lua provided by RyzenAPI
-- Game: Dream House Days DX

-- MAIN APPLICATION
addappid(1859370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859371, 1, "fa0ef0c570afb428c16000ba9394ec9b82a49fe3e4b398edbd925716ac2217e6")
