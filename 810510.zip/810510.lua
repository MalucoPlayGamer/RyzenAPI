-- Lua provided by RyzenAPI
-- Game: Welcome Back Daddy

-- MAIN APPLICATION
addappid(810510)

-- MAIN APP DEPOTS / PACKAGES
addappid(810511, 1, "e8c056cc9de874d1c77bac139240e6650e3182ad8e35698e9787161f0561ac4c")

