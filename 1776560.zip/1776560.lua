-- Lua provided by RyzenAPI 
-- Game: Dune Girls Attack!
addappid(1776560)
addappid(1776561, 1, "6e5d78ec725edd3dfe14b04be79b1364bf640af20cd15eca6ea735c72a6c13cf")
