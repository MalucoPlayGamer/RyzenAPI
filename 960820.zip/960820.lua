-- Lua provided by RyzenAPI
-- Game: addappid(960820)

-- MAIN APPLICATION
addappid(960820)

-- MAIN APP DEPOTS / PACKAGES
addappid(960821, 1, "c70b9a9d00cf763ee10cff1864e1e5f9d18b2534f45a0d90e33bf87b024111ec")
