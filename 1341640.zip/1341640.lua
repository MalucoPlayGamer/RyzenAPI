-- Lua provided by RyzenAPI
-- Game: Hard Driver

-- MAIN APPLICATION
addappid(1341640)
-- Game: addappid(1341640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341641, 1, "0dddd7ad2e70dc9dbafe959ff89b01ceed88ad00fd165a5eed236bcf564dc4c4")
