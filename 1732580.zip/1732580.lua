-- Lua provided by RyzenAPI
-- Game: 1732580

-- MAIN APPLICATION
addappid(1732580)
-- Game: addappid(1732580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732581, 1, "99541be9122b3a7c5f11b9747afe1ade4fd03811258921526188fdb2f467dc69")
