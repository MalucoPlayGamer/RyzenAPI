-- Lua provided by RyzenAPI
-- Game: 417290

-- MAIN APPLICATION
addappid(417290)
-- Game: addappid(417290)

-- MAIN APP DEPOTS / PACKAGES
addappid(417291, 1, "38162272acc98cd86a366c4c148651404331e59645b3dddd74bc478c771ffcb7")
