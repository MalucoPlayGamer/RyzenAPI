-- Lua provided by RyzenAPI
-- Game: Shadows of Doubt - Digital Artbook

-- MAIN APPLICATION
addappid(3229880)
-- Game: addappid(3229880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3229880,0,"e15b606fff7e6421b843b4c26b2127e49b7e36af9c5e94f0367a5698b77a636a")
