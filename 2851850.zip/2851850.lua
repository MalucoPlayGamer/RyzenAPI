-- Lua provided by RyzenAPI 
-- Game: AppID 2851850
addappid(2851850)
addappid(2851851, 1, "04c2092e25918853172ef2afda03a728124376710c496aa9617ccedfe8dfb78a")
