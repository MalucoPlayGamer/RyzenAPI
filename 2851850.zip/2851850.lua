-- Lua provided by RyzenAPI
-- Game: 2851850

-- MAIN APPLICATION
addappid(2851850)
-- Game: addappid(2851850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2851851, 1, "04c2092e25918853172ef2afda03a728124376710c496aa9617ccedfe8dfb78a")
