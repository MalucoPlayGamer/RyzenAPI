-- Lua provided by RyzenAPI
-- Game: AppID 1754080

-- MAIN APPLICATION
addappid(1754080)
-- Game: addappid(1754080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754081, 1, "db338f1ea930b2b79358887f3a51abe6e6fa98debdd97ec2ac99a3ff32a38da6")
