-- Lua provided by RyzenAPI
-- Game: Tower Tactics: Liberation

-- MAIN APPLICATION
addappid(1709900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1709901, 1, "f1bdadbf552e261bf283a3d1caf24cdf293cea88deb9dc61d4f9a7ab13823306")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2328120)
addappid(2986180)
