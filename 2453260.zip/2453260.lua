-- Lua provided by SkyAPI 
-- Game: 坦克英雄 TankHero
addappid(2453260)
addappid(2453261, 1, "c414160dcaa77ca89004103fc9d5dc6e445cd72b42fcdc80d82609ed0ae4d5cd")
