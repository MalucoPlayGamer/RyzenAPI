-- Lua provided by RyzenAPI
-- Game: 坦克英雄 TankHero

-- MAIN APPLICATION
addappid(2453260)
-- Game: addappid(2453260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2453261, 1, "c414160dcaa77ca89004103fc9d5dc6e445cd72b42fcdc80d82609ed0ae4d5cd")
