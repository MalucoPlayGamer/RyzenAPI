-- Lua provided by RyzenAPI
-- Game: Capoo Pals

-- MAIN APPLICATION
addappid(2253470)
addappid(2282660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2253471, 1, "e251d11f9ec5bf0a276fd832d20b2c7540e04845e91b2884f5ed4b0e3b3bdb0c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2288170)
addappid(2288180)
addappid(2482080)
addappid(2482090)
