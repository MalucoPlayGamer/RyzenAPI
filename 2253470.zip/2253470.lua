-- Lua provided by RyzenAPI 
-- Game: Capoo Pals
addappid(2253470)
addappid(2253471, 1, "e251d11f9ec5bf0a276fd832d20b2c7540e04845e91b2884f5ed4b0e3b3bdb0c")
addappid(2282660)
