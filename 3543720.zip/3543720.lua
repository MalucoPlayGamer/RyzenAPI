-- Lua provided by RyzenAPI 
-- Game: FIND ALL: Bunker
addappid(3543720)
addappid(3543721, 1, "3f128542ab68d1f2167c2391df950a8b49c2e0c9808e90eb2fcf4fb13bd93ea3")
addappid(3640630, 0, "e646dad005490d705645947f09c818541ec1b4204841ed9f0b1775dfa38805e5")
