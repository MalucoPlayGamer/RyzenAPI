-- Lua provided by RyzenAPI
-- Game: Shaylushay Treasure Expedition

-- MAIN APPLICATION
addappid(2684800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2684801, 1, "b5c4dcdaa1702f21a3074ed0ae81fff502121fbaeab53694203d695adc974330")

