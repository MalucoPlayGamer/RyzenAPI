-- Lua provided by RyzenAPI 
-- Game: Shaylushay Treasure Expedition
addappid(2684800)
addappid(2684801, 1, "b5c4dcdaa1702f21a3074ed0ae81fff502121fbaeab53694203d695adc974330")
