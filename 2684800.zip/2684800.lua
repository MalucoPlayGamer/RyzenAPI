-- Lua provided by RyzenAPI
-- Game: Game: Shaylushay Treasure Expedition

-- MAIN APPLICATION
addappid(2684800)
-- Game: addappid(2684800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684801, 1, "b5c4dcdaa1702f21a3074ed0ae81fff502121fbaeab53694203d695adc974330")
