-- Lua provided by RyzenAPI
-- Game: Meet The Animals

-- MAIN APPLICATION
addappid(2883070)
-- Game: addappid(2883070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2883073,0,"30221958210f53c969d8d691459a0116f2ed458a65135f946c880acc8f5e34d6")
addappid(2883075,0,"0d622b82105b286eba5b68ce92cbecbc5428c8cd55c7c9f4bb2650884ba169a5")
