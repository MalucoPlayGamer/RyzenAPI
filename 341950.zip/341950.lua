-- Lua provided by RyzenAPI
-- Game: Game: Lux Delux

-- MAIN APPLICATION
addappid(341950)
-- Game: addappid(341950)

-- MAIN APP DEPOTS / PACKAGES
addappid(341951, 1, "000d793dbc593a862c2bb76074cd48ed2c039358684b92845124844ac1a2d0f5")
addappid(341952, 1, "63d1411e5ec36cd029c3eba1b1196301bc0a1c4be2940f3d031c703be8a2c271")
addappid(341953, 1, "ac0a28c1ab0b2d89e559b6c742299537de882e120d0673d6ce69a4d72a01a81a")
