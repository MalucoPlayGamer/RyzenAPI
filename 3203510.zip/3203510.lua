-- Lua provided by RyzenAPI
-- Game: 3203510

-- MAIN APPLICATION
addappid(3203510)
-- Game: addappid(3203510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3203511, 1, "fb8884a7b3a3ec9479c45c0fde8a39694564072fa7d315df5b7ccda982087df8")
