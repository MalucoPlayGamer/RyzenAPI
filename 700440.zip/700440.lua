-- Lua provided by RyzenAPI
-- Game: AppID 700440

-- MAIN APPLICATION
addappid(700440)

-- MAIN APP DEPOTS / PACKAGES
addappid(700441, 1, "2b2eb75d9082c6e0108597a7fd7ffa6af25661983aacdc88f6cf419c1f2741db")
addappid(700443, 1, "c8717e327e2c119a455644b508312d4ffa1f6b322c3b15817ace80438a3c5f16")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
