-- Lua provided by RyzenAPI
-- Game: Game: AppID 700440

-- MAIN APPLICATION
addappid(700440)
-- Game: addappid(700440)

-- MAIN APP DEPOTS / PACKAGES
addappid(700441, 1, "2b2eb75d9082c6e0108597a7fd7ffa6af25661983aacdc88f6cf419c1f2741db")
addappid(700443, 1, "c8717e327e2c119a455644b508312d4ffa1f6b322c3b15817ace80438a3c5f16")
