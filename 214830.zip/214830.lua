-- Lua provided by RyzenAPI
-- Game: addappid(214830)

-- MAIN APPLICATION
addappid(214830)
addappid(283750)

-- MAIN APP DEPOTS / PACKAGES
addappid(214831, 1, "ed22e3b4ba3e9ac01c8a41a6960a905629312e81ac6a1d3138b73151b9a112cc")
