-- Lua provided by SkyAPI 
-- Game: Half Minute Hero: Super Mega Neo Climax Ultimate Boy
addappid(214830)
addappid(214831, 1, "ed22e3b4ba3e9ac01c8a41a6960a905629312e81ac6a1d3138b73151b9a112cc")
addappid(283750)
