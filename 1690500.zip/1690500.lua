-- Lua provided by RyzenAPI
-- Game: addappid(1690500)

-- MAIN APPLICATION
addappid(1690500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1690502,0,"ed36e9ef5a2e71671c3229d0b729da03a03af81e999ea8fcfeb8f415a73a500d")
