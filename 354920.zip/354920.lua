-- Lua provided by RyzenAPI
-- Game: Game: AppID 354920

-- MAIN APPLICATION
addappid(354920)
-- Game: addappid(354920)

-- MAIN APP DEPOTS / PACKAGES
addappid(354921, 1, "d2091c988123342a0ee962fb3acf8ed3d37e5add0d2b18d93103d69e9abd3c74")
