-- Lua provided by RyzenAPI
-- Game: AppID 354920

-- MAIN APPLICATION
addappid(354920)

-- MAIN APP DEPOTS / PACKAGES
addappid(354921, 1, "d2091c988123342a0ee962fb3acf8ed3d37e5add0d2b18d93103d69e9abd3c74")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
