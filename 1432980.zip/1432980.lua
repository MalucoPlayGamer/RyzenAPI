-- Lua provided by SkyAPI 
-- Game: MOAI 6: Unexpected Guests Collector's Edition
addappid(1432980)
addappid(1432981, 1, "8245feec33231a2ec3d5b3ca48ab6730c065c72367858104d66e5b9a39d51708")
addappid(1432982, 1, "f202f60b31260ef27792801173edddef4eb87aaa2f12b6d813ce8ca467a5bbfb")
