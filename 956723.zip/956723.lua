-- Lua provided by RyzenAPI
-- Game: Zhuge Liang - Officer Ticket / 諸葛亮使用券

-- MAIN APPLICATION
addappid(956723)

-- MAIN APP DEPOTS / PACKAGES
addappid(956723,0,"3464dfdef50d053f7120de7aabfb251b5ab771528e346f3542f81d604e0fbcf8")
