-- 3228380's Lua and Manifest Created by Hubcap Manifest
-- Burger Typer
-- Created: August 03, 2026 at 02:49:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3228380, 1, "d4a21f578880804085dd338b1904b98e12ba779aab7fde66d36153dab1ad1c35") -- Burger Typer
-- MAIN APP DEPOTS
addappid(3228381, 1, "091b181eabbd73d3c37b1bb14a0fcd922dbf1ef3696245eee786268f72fe9ea3") -- Depot 3228381
setManifestid(3228381, "1541034432681368046", 120867288)