-- Lua provided by RyzenAPI
-- Game: AppID 1226770

-- MAIN APPLICATION
addappid(1226770)
-- Game: addappid(1226770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226771, 1, "4e11d9cba4c09f0d95648a7d7e4719c55b3a468b385939a58b9e7c207539ce65")
