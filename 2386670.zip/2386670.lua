-- Lua provided by RyzenAPI
-- Game: Shooter

-- MAIN APPLICATION
addappid(2386670)
-- Game: addappid(2386670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386671, 1, "9b734b3ad3aec4ccddc0707b345424ac3783a1fa688dea4e42670a315b63d476")
