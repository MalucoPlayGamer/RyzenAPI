-- Lua provided by RyzenAPI
-- Game: Hidden Castle Top-Down 3D

-- MAIN APPLICATION
addappid(2878320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878321, 1, "732baa4561088655b6a9f86214420bac8cfdcad6b4b7a3993abb9f178f2129c1")

