-- Lua provided by RyzenAPI
-- Game: Abnormal1999:SU - Unlocking the 4th Dimension

-- MAIN APPLICATION
addappid(2925090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2925091, 1, "b515adf1e8602285d806ff33f30c25f41b93e58582c2db2c693b0b4782d8ff29")
