-- Lua provided by RyzenAPI
-- Game: 叙事曲2：星空下的诺言 / Ballade2: the Celestial Promise

-- MAIN APPLICATION
addappid(1080990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1080991, 1, "96b21699a3c8f14a7f25f2c14f1840741baae2d194a4518d66212db743aa95e1")
addappid(1084940, 0, "8a52e111a2a53889e80f349a64812ce043d4867e7fc454538516d4932f534eb9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
