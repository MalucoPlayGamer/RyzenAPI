-- Lua provided by RyzenAPI
-- Game: AppID 1360810

-- MAIN APPLICATION
addappid(1360810)
-- Game: addappid(1360810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1360811, 1, "fcd0727de0fdf47ccf742e9f5d280bfa66e1ed6a337adf2ebc28212a952e9949")
addappid(1360813, 1, "a6b49045efbee5082f3beff2d6e1f11a7d8f4c2ad5490fc967fd7e44817b0904")
