-- Lua provided by RyzenAPI
-- Game: Senpai and the Mysterious Dungeon

-- MAIN APPLICATION
addappid(1934990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1934992,0,"742a36968ccd56f3ed1a8bb6a1a657b400c70cc9e6d126715c33190e87918a8f")
