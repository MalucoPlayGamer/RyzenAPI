-- Lua provided by RyzenAPI
-- Game: Crimzon Clover World EXplosion

-- MAIN APPLICATION
addappid(1718160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718161, 1, "b6aab5c5616d272151d6c8c45e9f52cea64fbd1c1ecb547c53c916d49b4e3763")
