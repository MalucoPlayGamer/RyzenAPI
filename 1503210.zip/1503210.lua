-- Lua provided by RyzenAPI
-- Game: Game: AppID 1503210

-- MAIN APPLICATION
addappid(1503210)
-- Game: addappid(1503210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503211, 1, "01aab5c6dbd03f0482dbd3fae7f2af1c32c06a1632461a7ae36f7950b779dfcd")
