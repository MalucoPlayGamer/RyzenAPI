-- Lua provided by RyzenAPI
-- Game: 2501710

-- MAIN APPLICATION
addappid(2501710)
-- Game: addappid(2501710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2501711, 1, "d8cbec0cd3fc359ab3621dfa8ac12ce03c3531599463916b1e3e8be993f12221")
