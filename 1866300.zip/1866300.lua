-- Lua provided by RyzenAPI
-- Game: Game: AppID 1866300

-- MAIN APPLICATION
addappid(1866300)
-- Game: addappid(1866300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866301, 1, "e54868dba7f030542f13e2abb7879f5edc1523619fcecf20159031f92794f195")
