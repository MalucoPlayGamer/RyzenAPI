-- Lua provided by RyzenAPI
-- Game: Dead Reckoning: The Crescent Case Collector's Edition

-- MAIN APPLICATION
addappid(815560)

-- MAIN APP DEPOTS / PACKAGES
addappid(815561,0,"77c95f337cbbbf411e103e8082394d0c56c295ef55075817b9496e13cef4c559")

