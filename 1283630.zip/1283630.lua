-- Lua provided by SkyAPI 
-- Game: Frog Bath
addappid(1283630)
addappid(1283631, 1, "0cc67c16933ec456502422ab23b5e013e830d487cc6b97d5e66d0ae292613266")
