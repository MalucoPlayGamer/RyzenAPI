-- Lua provided by RyzenAPI
-- Game: Game: Frog Bath

-- MAIN APPLICATION
addappid(1283630)
-- Game: addappid(1283630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283631, 1, "0cc67c16933ec456502422ab23b5e013e830d487cc6b97d5e66d0ae292613266")
