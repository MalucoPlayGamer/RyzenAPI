-- Lua provided by RyzenAPI
-- Game: Puzzle Compound

-- MAIN APPLICATION
addappid(1611290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1611291, 1, "e5e36210530aed49a5fd6579ba819819276c50767bca96d246e9c00526c6aba5")

