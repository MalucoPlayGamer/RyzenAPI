-- Lua provided by RyzenAPI
-- Game: Tactera

-- MAIN APPLICATION
addappid(696040)

-- MAIN APP DEPOTS / PACKAGES
addappid(696041,0,"890f97d393d1ac876c6bcb087bd7ca082f96ffb426f40aef7e6245e13d409c39")

