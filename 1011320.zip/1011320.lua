-- Lua provided by RyzenAPI
-- Game: Whiskey & Zombies

-- MAIN APPLICATION
addappid(1011320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1011321, 1, "1e89405db29ce474b653a39b66b73af344c408948101395cc77f65237092e0dc")

