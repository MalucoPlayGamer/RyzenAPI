-- Lua provided by RyzenAPI
-- Game: addappid(683210)

-- MAIN APPLICATION
addappid(683210)

-- MAIN APP DEPOTS / PACKAGES
addappid(683211, 1, "e9c405f31900637f7633b733c4b16beba84e31eb49963f58e0b73a64ae5d48a7")
