-- Lua provided by RyzenAPI 
-- Game: Divide By Sheep 2
addappid(2678960)
addappid(2678961, 1, "99f473a949509771921f78a9d6ab9d2295b5b142095bfa1a11910ba54a9ec524")
