-- Lua provided by RyzenAPI
-- Game: 2626940

-- MAIN APPLICATION
addappid(2626940)
-- Game: addappid(2626940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626941, 1, "1a69bf67fd0bafb5e457bc06cb4651c459314beeb3aef017c749eed676fc3c30")
