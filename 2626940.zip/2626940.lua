-- Lua provided by RyzenAPI
-- Game: Life Makeover

-- MAIN APPLICATION
addappid(2626940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2626941, 1, "1a69bf67fd0bafb5e457bc06cb4651c459314beeb3aef017c749eed676fc3c30")

