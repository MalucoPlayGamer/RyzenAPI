-- Lua provided by RyzenAPI
-- Game: Shanshui Haven

-- MAIN APPLICATION
addappid(2653480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653485,0,"c43780174dc01b9f4c262e336f80a2e50e9d7b0aca1493076844b39e9758a61f")

