-- Lua provided by RyzenAPI
-- Game: 2536130

-- MAIN APPLICATION
addappid(2536130)
-- Game: addappid(2536130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2536131, 1, "5b01bd3ad1ca3dc942fa629aa49024c8402dfebc72d80e2a50dd5e6ea5566de1")
