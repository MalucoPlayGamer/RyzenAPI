-- Lua provided by RyzenAPI
-- Game: STRAFTAT

-- MAIN APPLICATION
addappid(2386720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386721, 1, "d6706267b1aa5c534190b8bd47f12b11c89941f6b033bc216190d8cc6fe69aff")
addappid(2386722, 1, "8410e960864a9b470b19e630337c7dba3eb8f4b3d71e2a9fdd24cfb2982ff2da")
addappid(2386723, 1, "a02a66c201210cfc35a00e2ec3e5e2c2bf93052b4936818e266e06458288a931")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3153370)
addappid(3868930)
