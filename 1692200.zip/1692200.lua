-- Lua provided by RyzenAPI
-- Game: DRAGON BALL: THE BREAKERS Playtest

-- MAIN APPLICATION
addappid(1692200)
-- Game: addappid(1692200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1692201, 1, "9e4b23565ab2682c5b84171d761a9c664ef0d7c75cac41185c320adbd4ee7b63")
