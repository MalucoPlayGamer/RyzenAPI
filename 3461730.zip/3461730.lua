-- Lua provided by SkyAPI 
-- Game: AppID 3461730
addappid(3461730)
addappid(3461731, 1, "3bb03d9f0c670cacbb709330f4460010a94f2f76a42e048b91fa25713a7a2921")
