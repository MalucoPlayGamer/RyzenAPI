-- Lua provided by RyzenAPI
-- Game: Indoorlands

-- MAIN APPLICATION
addappid(1378890)
-- Game: addappid(1378890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378891, 1, "a47ee63a3f709857ccfc68e5dce20e45ce834598ed4326aa9cddc40a79a2d1be")
addappid(1378892, 1, "7ae0ef10d4b983707d392d08dfbfe09321076940b0097a154460c7adf873011d")
addappid(1378893, 1, "54687873ffca25d9b015e1f54cd5554f637cb0f5f26fcde3806a7598bafa8dc8")
addappid(1378894, 1, "cfbccf61b2f3e05a7d96b11c590668c8575ae1d5e965b0f12cd5755207aa053a")
addappid(1666380, 0, "afef16cfadc07df51462a5d838d6e884caebd653c3b6d7f802393d098cf52e00")
