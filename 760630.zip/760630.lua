-- Lua provided by RyzenAPI
-- Game: Game: AppID 760630

-- MAIN APPLICATION
addappid(760630)
-- Game: addappid(760630)

-- MAIN APP DEPOTS / PACKAGES
addappid(760631, 1, "9299d55ed3d98cf0b4d2763e96f0d603dca3da290287248d24b054344cea2273")
