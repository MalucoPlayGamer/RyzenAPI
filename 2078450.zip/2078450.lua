-- Lua provided by RyzenAPI
-- Game: addappid(2078450)

-- MAIN APPLICATION
addappid(2078450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2078451, 1, "ce0f8e24d52ed2ed7f0b681aa36a64794236da14843cab407a065f4c98fa62f0")
