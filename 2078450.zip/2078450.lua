-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Speed Freeks

-- MAIN APPLICATION
addappid(2078450)
addappid(3750860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2078451, 1, "ce0f8e24d52ed2ed7f0b681aa36a64794236da14843cab407a065f4c98fa62f0")
