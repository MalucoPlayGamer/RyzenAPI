-- Lua provided by RyzenAPI
-- Game: Streets of Moscow

-- MAIN APPLICATION
addappid(46230)

-- MAIN APP DEPOTS / PACKAGES
addappid(46231, 1, "0ec909a96891d86de3fbad8d066eb46369b5cc90feb33da30f20032213a344fc")
addappid(46232, 1, "7cedf8a97ba671c7accef1a8c798c1517e827dc4531272f88b6a31be8ed43a6b")
addappid(46233, 1, "c07b0287bc0e990a90e4ffd5dbe60f7e0c4e6b96949d6c482719cc35e2cba14a")
addappid(46234, 1, "468c049af8f9c8c9bb11f993592b28aab1f6fca203854e4c7f96de8be2f9bc98")
addappid(46235, 1, "ca1a12cd3dd3a422a053adc0c8bc56c936227878b842a559168af09fa318d07a")

