-- Lua provided by RyzenAPI
-- Game: addappid(849320)

-- MAIN APPLICATION
addappid(849320)

-- MAIN APP DEPOTS / PACKAGES
addappid(849321, 1, "d72ab1dc4d42e1020dc8347bc6b27c40b0277559a2dc35e09e706bf84eda26f7")
