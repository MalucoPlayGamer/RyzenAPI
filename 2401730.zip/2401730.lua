-- Lua provided by RyzenAPI
-- Game: Hot Springs | 温泉 (Onsen)

-- MAIN APPLICATION
addappid(2401730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2401732,0,"5ba01e9d606938fa0f2b2a91198cfcacecb023f91176d4b50accf36dfc8e77f5")

