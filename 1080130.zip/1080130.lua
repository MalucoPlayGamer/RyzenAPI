-- Lua provided by RyzenAPI
-- Game: addappid(1080130)

-- MAIN APPLICATION
addappid(1080130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1080131, 1, "a1a4d5fefddd503348bebc35a6b5a568d6838068876b120d8aec468b7c63445f")
