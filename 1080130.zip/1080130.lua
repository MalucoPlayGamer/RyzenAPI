-- Lua provided by RyzenAPI
-- Game: AppID 1080130

-- MAIN APPLICATION
addappid(1080130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1080131, 1, "a1a4d5fefddd503348bebc35a6b5a568d6838068876b120d8aec468b7c63445f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
