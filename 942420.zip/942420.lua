-- Lua provided by RyzenAPI
-- Game: 东方蝶梦志 Demo

-- MAIN APPLICATION
addappid(942420)

-- MAIN APP DEPOTS / PACKAGES
addappid(942421, 1, "9454b636f35b813bd0ddf19769182d5c2a800d0d4249c06160c604e6164e477a")

