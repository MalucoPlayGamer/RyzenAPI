-- Lua provided by RyzenAPI
-- Game: Game: Ninja Noboken

-- MAIN APPLICATION
addappid(1880720)
-- Game: addappid(1880720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1880721, 1, "9ee3caf013b4af690263cf0719914e6ebe0a6445fb8106f5a03d4dc14a535f0f")
