-- Lua provided by RyzenAPI
-- Game: Game: AppID 2241400

-- MAIN APPLICATION
addappid(2241400)
-- Game: addappid(2241400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2241401, 1, "0cca697c1dfb6a361637401b6d578d816dc6205160a63c5ac72a7282b6452123")
