-- Lua provided by RyzenAPI 
-- Game: AppID 2241400
addappid(2241400)
addappid(2241401, 1, "0cca697c1dfb6a361637401b6d578d816dc6205160a63c5ac72a7282b6452123")
