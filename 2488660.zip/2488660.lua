-- Lua provided by RyzenAPI
-- Game: Brave Escape Friend's Pass

-- MAIN APPLICATION
addappid(2488660)
-- Game: addappid(2488660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2488661, 1, "c3335cc37893b1f37f96e4211d441bb9ef709e7d76e2349eaa8dddb34e153650")
