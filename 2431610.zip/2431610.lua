-- Lua provided by RyzenAPI 
-- Game: ikuzo
addappid(2431610)
addappid(2431611, 1, "e0dba892fc979c92bf673e7380c8fb7e9656fb98b92d3942f4ea5107393ebd36")
