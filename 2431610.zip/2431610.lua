-- Lua provided by RyzenAPI
-- Game: ikuzo

-- MAIN APPLICATION
addappid(2431610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2431611, 1, "e0dba892fc979c92bf673e7380c8fb7e9656fb98b92d3942f4ea5107393ebd36")

