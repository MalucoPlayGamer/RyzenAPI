-- Lua provided by RyzenAPI
-- Game: addappid(2316590)

-- MAIN APPLICATION
addappid(2316590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2316591, 1, "cf2193b93dafdfc3fb59ee281d07b2aa0ae01be88c28aea8d3941605147c9f7e")
