-- Lua provided by RyzenAPI
-- Game: Starbase

-- MAIN APPLICATION
addappid(454120)
-- Game: addappid(454120)

-- MAIN APP DEPOTS / PACKAGES
addappid(454121, 1, "b02cfdfdf74398f9c880cc72d63e6d5c95d65f812eeb016e822a3b915d38200e")
