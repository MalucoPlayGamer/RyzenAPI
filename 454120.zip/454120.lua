-- Lua provided by RyzenAPI
-- Game: Starbase

-- MAIN APPLICATION
addappid(454120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(454121, 1, "b02cfdfdf74398f9c880cc72d63e6d5c95d65f812eeb016e822a3b915d38200e")

