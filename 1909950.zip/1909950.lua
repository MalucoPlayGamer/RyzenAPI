-- Lua provided by RyzenAPI
-- Game: SUPER ROBOT WARS Y

-- MAIN APPLICATION
addappid(3390820)
addappid(3483830)
addappid(3483840)
addappid(3483850)
addappid(3483860)
addappid(3483870)
addappid(3483880)
addappid(3483900)
addappid(3483910)
addappid(3483930) -- SUPER ROBOT WARS Y - DLC 1  2 Set
addappid(4126740)
-- addappid(1909952) -- Depot 1909952 (empty depot)
-- addappid(3483930) -- Depot 3483930 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909950, 1, "11922dc6c02510397696f1c4ce60915fc924a729c8adc02274dbf968b67cbc13") -- SUPER ROBOT WARS Y
addappid(1909951, 1, "77fcc720c77a9d762fca608c74046980979badaf8ce497d8494b3c2da40d3ddb") -- Depot 1909951
addappid(3390820, 1, "d22f81e1d50c71064d093e98fd8d79be8fe2443c109def325c1589235ddee9f2") -- SUPER ROBOT WARS Y - Bonus Mission Pack - Depot 3390820
addappid(3483830, 1, "e32b0227a39c74cf84056450d0d93a70f6c229494b783b3a81935018c7ba5f31") -- SUPER ROBOT WARS Y - Pre-Order Bonus Pack - Depot 3483830
addappid(3483840, 1, "c7108fbc58e82ebc3b10935a5048e2da2860b20e89c11f063d9ffe3cd1f6f638") -- SUPER ROBOT WARS Y - Premium Sound  Data Pack - Depot 3483840
addappid(3483850, 1, "ba95e3ed923a31dee2ca44f450589db4ee2d645691892123d45db80a92358a1e") -- SUPER ROBOT WARS Y - DLC 1 - Depot 3483850
addappid(3483860, 1, "36d2080cd439b6e5db903a5cc34bc10bbaa4c69167a983ff3522237c56edb427") -- SUPER ROBOT WARS Y - DLC 2 - Depot 3483860
addappid(3483870, 1, "9cbfb79f2b6e617b33b8011be6be19e88089ae8343b6b83b7087a59cb1507f7d") -- SUPER ROBOT WARS Y - DLC 1  2 Set Bonus - Depot 3483870
addappid(3483880, 1, "5ba41954600e424f26e9e438ec848fe20c66de2daa77bf8f7d77152134f3ba34") -- SUPER ROBOT WARS Y - Expansion Pack - Depot 3483880
addappid(3483900, 1, "109130b59df37285a9a1e75cdb50516fb303e6694d4ae1d72e1c41cc7ef31cec") -- SUPER ROBOT WARS Y - Deluxe Edition Bonus - Depot 3483900
addappid(3483910, 1, "4a871e042cdbc9309625b25d1178c4a4b761e122b26e96f50a31cb4c80031be3") -- SUPER ROBOT WARS Y - Ultimate Edition Bonus - Depot 3483910
addappid(4126740, 1, "e30f0e1409dcba2cf144878b9e7a30c328af2aefd0881a43159dedcecf61076d") -- SUPER ROBOT WARS Y - Anniversary Expansion Pack - Depot 4126740

