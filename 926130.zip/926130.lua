-- Lua provided by RyzenAPI
-- Game: Game: Living Legends: Wrath of the Beast Collector's Edition

-- MAIN APPLICATION
addappid(926130)
-- Game: addappid(926130)

-- MAIN APP DEPOTS / PACKAGES
addappid(926131, 1, "a91f669bed608d5a7bff8d0bcaf9ecd621fde6aaf7e4f77a4d38f93007ecd2cd")
