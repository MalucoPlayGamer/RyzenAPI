-- Lua provided by SkyAPI 
-- Game: AppID 2529610
addappid(2529610)
addappid(2529611, 1, "12dc87ba182574608d0a1a28dd003f0e94c8311238ab7a0768b26d1b1c81446c")
