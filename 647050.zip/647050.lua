-- Lua provided by RyzenAPI
-- Game: addappid(647050)

-- MAIN APPLICATION
addappid(647050)

-- MAIN APP DEPOTS / PACKAGES
addappid(647051, 1, "d48fe90559ef102f78db8acc0663647e796b6b62bc5116bf544e554d16059e6e")
