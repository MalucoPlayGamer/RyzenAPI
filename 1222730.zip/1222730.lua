-- Lua provided by RyzenAPI
-- Game: STAR WARS™: Squadrons

-- MAIN APPLICATION
addappid(1222730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222731, 1, "4f77dddb105c8e133c35b60b934a60080f3f6b346785c1c21ccfaa671a3f5355")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1282990)
