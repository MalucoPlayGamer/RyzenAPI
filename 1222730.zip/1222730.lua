-- Lua provided by RyzenAPI
-- Game: STAR WARS™: Squadrons

-- MAIN APPLICATION
addappid(1222730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222731, 1, "4f77dddb105c8e133c35b60b934a60080f3f6b346785c1c21ccfaa671a3f5355")
