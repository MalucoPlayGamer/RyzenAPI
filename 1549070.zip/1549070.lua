-- Lua provided by RyzenAPI
-- Game: SugarWinds: Prologue

-- MAIN APPLICATION
addappid(1549070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549071, 1, "dbdd85ef72eb7970d127b9aa8bbab90209ac7cbf0419f86e6f3379dbf53bcb56")

