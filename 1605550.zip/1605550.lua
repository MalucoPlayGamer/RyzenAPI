-- Lua provided by RyzenAPI
-- Game: Final Pilot

-- MAIN APPLICATION
addappid(1605550)
-- Game: addappid(1605550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1605551, 1, "247bde8750e8dbfd1ab43a5c6e0a5f1ba40f003bab55e27c611f40a4478da72a")
