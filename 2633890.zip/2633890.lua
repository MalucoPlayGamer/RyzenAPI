-- Lua provided by RyzenAPI
-- Game: Orgasm Simulator 3 💦

-- MAIN APPLICATION
addappid(2633890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2633891, 1, "68e6bc23620f300ed8d3cfbac56d3cb296fc3363229facf7bd32f5b602d3aaf5")

