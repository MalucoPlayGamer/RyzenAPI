-- Lua provided by SkyAPI 
-- Game: When The Past Was Around Demo
addappid(1268080)
addappid(1268081, 1, "4cdb0c45ff6b622669fc390af6557c89e8111a59334a53d3b881f6e01c52859e")
