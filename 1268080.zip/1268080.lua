-- Lua provided by RyzenAPI
-- Game: 1268080

-- MAIN APPLICATION
addappid(1268080)
-- Game: addappid(1268080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1268081, 1, "4cdb0c45ff6b622669fc390af6557c89e8111a59334a53d3b881f6e01c52859e")
