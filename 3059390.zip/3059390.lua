-- Lua provided by RyzenAPI
-- Game: Game: Hexagod

-- MAIN APPLICATION
addappid(3059390)
-- Game: addappid(3059390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3059391, 1, "2cd2af1c86f4c1bc6e65342bc82bedc923dfb4989258a14c5ee5f2a2304a6164")
