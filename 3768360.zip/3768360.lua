-- Lua provided by RyzenAPI
-- Game: Hentai Casual Swap 3

-- MAIN APPLICATION
addappid(3768360)
addappid(3823630)
-- Game: addappid(3768360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3768361, 1, "a59a717dfca99e88cb5276aa78b8166dc7c0679763ca253c707c933ae63ef2ca")
