-- Lua provided by RyzenAPI
-- Game: Game: AppID 1466870

-- MAIN APPLICATION
addappid(1466870)
-- Game: addappid(1466870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1466871, 1, "3703e2899d71d1a8cbb7172a59e2c93665615a3b3e4d2dd124cfe38ce73c58bd")
