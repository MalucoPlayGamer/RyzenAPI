-- Lua provided by SkyAPI 
-- Game: Drowned God: Conspiracy of the Ages.
addappid(3320100)
addappid(3320101, 1, "0a9552e021dfdf6c09477f1ace3bc7f18e3f6ac25391ac8ca085015c439b4bda")
