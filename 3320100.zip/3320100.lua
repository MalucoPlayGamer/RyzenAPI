-- Lua provided by RyzenAPI
-- Game: addappid(3320100)

-- MAIN APPLICATION
addappid(3320100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3320101, 1, "0a9552e021dfdf6c09477f1ace3bc7f18e3f6ac25391ac8ca085015c439b4bda")
