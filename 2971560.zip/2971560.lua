-- Lua provided by RyzenAPI
-- Game: Star Leaping Story Soundtrack

-- MAIN APPLICATION
addappid(2971560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2971561, 1, "297fa35848c3adccf71610a2bff3e693cabda84617cdda91d7880f32274c49e2")
addappid(2971565, 1, "86ce08789e1083816f82200e5000153941f02915ce784e9e29c41ba819cee948")

