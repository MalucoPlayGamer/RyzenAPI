-- Lua provided by SkyAPI 
-- Game: New Yankee: Under the Genie's Thumb
addappid(1563770)
addappid(1563771, 1, "a6f15097715395cd43be6a2a09bae6859e47e67a8bb4f082518a25b84a8fd402")
