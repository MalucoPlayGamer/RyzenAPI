-- Lua provided by RyzenAPI
-- Game: Metawork - Hotel Simulator

-- MAIN APPLICATION
addappid(2364990)
-- Game: addappid(2364990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2364991, 1, "e8772c947b922f2095a64b2f4f840e34ff1c2f35a0e06b3e5e348446d07d64bb")
