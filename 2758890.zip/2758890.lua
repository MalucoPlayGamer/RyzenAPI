-- Lua provided by RyzenAPI
-- Game: Game: The Symbiant Re:Union - Adult Patch

-- MAIN APPLICATION
addappid(2758890)
-- Game: addappid(2758890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2758891, 1, "0f4ca3079acc3353bd474830b1b56074a2d29a858cfa9c5831d699a3e63ba2d1")
