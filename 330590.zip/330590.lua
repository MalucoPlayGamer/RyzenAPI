-- Lua provided by RyzenAPI
-- Game: 330590

-- MAIN APPLICATION
addappid(330590)
-- Game: addappid(330590)

-- MAIN APP DEPOTS / PACKAGES
addappid(330591, 1, "62cda8f1107c8de5c736b0460e40e52c725a95b1b7b397d3a5d9646c9b126bec")
