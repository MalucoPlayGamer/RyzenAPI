-- Lua provided by RyzenAPI 
-- Game: AppID 1331530
addappid(1331530)
addappid(1331531, 1, "5fed393244cda16112946d8145f6d2fe2412e47aec05b448a675b5a1d0186e08")
