-- Lua provided by RyzenAPI
-- Game: 1331530

-- MAIN APPLICATION
addappid(1331530)
-- Game: addappid(1331530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1331531, 1, "5fed393244cda16112946d8145f6d2fe2412e47aec05b448a675b5a1d0186e08")
