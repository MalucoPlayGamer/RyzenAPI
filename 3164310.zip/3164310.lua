-- 3164310's Lua and Manifest Created by Hubcap Manifest
-- Verde
-- Created: August 13, 2026 at 07:35:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3164310) -- Verde
-- MAIN APP DEPOTS
addappid(3164311, 1, "1a2bf2674a04519dcd39b7e545fb8f4e1b344c0e3061d0db237d053bef455236") -- Depot 3164311
setManifestid(3164311, "6081216509280200939", 1446908698)
addappid(3164312, 1, "0d20631fb6894f06c0d0913fdb78634ec9c9ae1ccf7f572cb223de4756b601db") -- Depot 3164312
setManifestid(3164312, "5470644428810091430", 1466986671)
addappid(3164313, 1, "b72823d9738bee0d3c05fa33c5054a69ce3f626572312fb63201532e5e33b748") -- Depot 3164313
setManifestid(3164313, "4729022667242730456", 1443947996)