-- Lua provided by RyzenAPI
-- Game: addappid(2849310)

-- MAIN APPLICATION
addappid(2849310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2849311, 1, "3fc82af8913a092fd838a4d2a757b61b6c50ad5860ee4dc02db8b3a1b7492277")
