-- Lua provided by RyzenAPI
-- Game: addappid(2827480)

-- MAIN APPLICATION
addappid(2827480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2827481, 1, "7e60838f6c44327d299a7df8dc791feab2c24d38cfceac131dc711d28bec9473")
