-- Lua provided by RyzenAPI
-- Game: Hideout: Face your fears

-- MAIN APPLICATION
addappid(1659400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1659401, 1, "6e9c9eb7a1fef178816a8ba6cabe7c2b02d0050ddf4c762bae62eb70b96da96a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
