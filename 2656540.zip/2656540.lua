-- Lua provided by RyzenAPI
-- Game: Ballads of Hongye: REBORN

-- MAIN APPLICATION
addappid(2656540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2656541, 1, "226ea8fc6fbf56203b2e433de14ecb9db7e75f1bfc44cbd12fdbcb7dd4d37e62")

