-- Lua provided by RyzenAPI
-- Game: 东方：平野孤鸿

-- MAIN APPLICATION
addappid(2656540)
addappid(3298900)
addappid(3307450)
addappid(3332130)
addappid(3333150)
addappid(3410990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2656541,0,"226ea8fc6fbf56203b2e433de14ecb9db7e75f1bfc44cbd12fdbcb7dd4d37e62")
addappid(3298900,0,"047fe37656b447580e81aee0dddb145f926b096789eda141652c89359908a786")

