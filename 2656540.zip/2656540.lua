-- Lua provided by SkyAPI 
-- Game: Ballads of Hongye: REBORN
addappid(2656540)
addappid(2656541, 1, "226ea8fc6fbf56203b2e433de14ecb9db7e75f1bfc44cbd12fdbcb7dd4d37e62")
