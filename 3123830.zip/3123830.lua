-- Lua provided by RyzenAPI 
-- Game: AppID 3123830
addappid(3123830)
addappid(3123831, 1, "c025b0a3591221547af38bfa2f4e058c8b0691499d23e40548db676290c78f96")
