-- Lua provided by RyzenAPI
-- Game: Game: The Storyteller

-- MAIN APPLICATION
addappid(3645820)
-- Game: addappid(3645820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3645821, 1, "e73789cd4f3232a169f0ac8a9857dd054f7bd8b6538e38288e0b8558e21681bb")
