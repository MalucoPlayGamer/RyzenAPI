-- Lua provided by RyzenAPI
-- Game: Within the Backrooms

-- MAIN APPLICATION
addappid(2158740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2158741, 1, "d69679627d868f669449065cfef391c00f8667623ce0cc041227e70b76f44a4c")
