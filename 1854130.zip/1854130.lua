-- Lua provided by RyzenAPI
-- Game: My Boss is a Futanari

-- MAIN APPLICATION
addappid(1854130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1854131, 1, "627f902ee0e726110102af0073e642f2a0ea0aad4290d038a7f311b444c67779")

