-- Lua provided by RyzenAPI
-- Game: 1250630

-- MAIN APPLICATION
addappid(1250630)
-- Game: addappid(1250630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1250631, 1, "14ce82bdc17be0a1866abf67970a6837f5b7cadc843b7ba3320c598e787e2896")
