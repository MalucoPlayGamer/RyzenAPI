-- Lua provided by SkyAPI 
-- Game: AppID 1250630
addappid(1250630)
addappid(1250631, 1, "14ce82bdc17be0a1866abf67970a6837f5b7cadc843b7ba3320c598e787e2896")
