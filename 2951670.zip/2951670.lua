-- Lua provided by SkyAPI 
-- Game: AppID 2951670
addappid(2951670)
addappid(2951671, 1, "32ab3fa8e570d193ca98ef56b26423f365fe160c7e7becb60d71054a527906c5")
