-- Lua provided by RyzenAPI
-- Game: Total War: PHARAOH DYNASTIES - Assembly Kit

-- MAIN APPLICATION
addappid(2951670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2951671, 1, "32ab3fa8e570d193ca98ef56b26423f365fe160c7e7becb60d71054a527906c5")

