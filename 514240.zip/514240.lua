-- Lua provided by RyzenAPI
-- Game: addappid(514240)

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(229005)
addappid(229020)
addappid(514240)
addappid(514241)
addappid(514242)
addappid(514244)
addappid(514245)

-- MAIN APP DEPOTS / PACKAGES
addappid(514243,0,"79b2cb7ae9191fed897dbfdb106607de34131f2671df586388cfa4390f1b3699")
