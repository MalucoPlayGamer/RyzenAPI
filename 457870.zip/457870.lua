-- Lua provided by RyzenAPI
-- Game: Minigame Party VR

-- MAIN APPLICATION
addappid(457870)

-- MAIN APP DEPOTS / PACKAGES
addappid(457871, 1, "1769085bc0b7c88aa6d6e0adc630a659564e6d405c8e71d5c83733bb4793b819")
