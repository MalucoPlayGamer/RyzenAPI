-- Lua provided by RyzenAPI
-- Game: Game: MIRROR MIRROR

-- MAIN APPLICATION
addappid(3541480)
-- Game: addappid(3541480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3541481, 1, "3c19cbae470f0dbcfe52285502eff136245f5c336eb6324ae64386b1e3fe04a3")
