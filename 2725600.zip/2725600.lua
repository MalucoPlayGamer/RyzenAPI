-- Lua provided by RyzenAPI
-- Game: 独特的友谊 - Special Friendship

-- MAIN APPLICATION
addappid(2725600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2725601, 1, "5b4ca9deb794a3beea2649774fb14fb9a264e5f1a59f095ba7303ebaae15e691")

