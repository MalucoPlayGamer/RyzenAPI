-- Lua provided by RyzenAPI
-- Game: addappid(1050150)

-- MAIN APPLICATION
addappid(1050150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1050151, 1, "5b2dd8357d660009b5bdd2567e9e9a84e77d1e840f36ada02bb7579c6279b02a")
