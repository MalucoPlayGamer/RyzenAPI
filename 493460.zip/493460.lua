-- Lua provided by RyzenAPI
-- Game: AppID 493460

-- MAIN APPLICATION
addappid(493460)
-- Game: addappid(493460)

-- MAIN APP DEPOTS / PACKAGES
addappid(493461, 1, "07d274c4ab3b560f81b5175a3defb92b9c7d45fe5855cb4d92f09f6dd43b2225")
