-- Lua provided by SkyAPI 
-- Game: Algo Bot
addappid(286300)
addappid(286301, 1, "dc857147708aee2fee44c38d69a4dec97c4f52228a47b64498cde59c364b20d1")
addappid(286302, 1, "10dcb1bc5da6891c2946a1f86a3e6dbe33843cafc8c5a38f1d2a3f0ec53bfada")
addappid(286303, 1, "932e6bfb5dd594000938fa7bf6068e01f108e3def84f110da6d412e1a993cc78")
addappid(286304, 1, "a2a4b3d63c5de521afab821bdd1b8c6952730b0f56ddfbe0fefac3599a992595")
addappid(799710)
