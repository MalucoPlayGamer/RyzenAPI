-- Lua provided by RyzenAPI 
-- Game: Tom Clancy's Splinter Cell Double Agent®
addappid(13580)
addappid(13581, 1, "8feafa3afc1b5e9a4d7eb89eb1db71167ef6e8ff7184b12cc49f8a83744dfc5d")
addappid(13582, 1, "b203551976ec29581f10288ef4c88af5b48ae9a4ff47d2ec25d742ac76464289")
addappid(13583, 1, "cd4eabea43cb192f8d9b20581914cc2d40afd064776d5998ea756216fb519584")
addappid(13584, 1, "bdc78fd329172a091099ce393e07dcc48e9a1074b5208cd70f2adf81668d0895")
addappid(13585, 1, "eb4fa2b59d290e1878b4b214cf28fbdb27f41eb6aa59098e07599568e92aec47")
addappid(13586, 1, "b45a78b55a7296340d25ed04f0cbf88c00017f2085d67e976d28378de7ae4822")
