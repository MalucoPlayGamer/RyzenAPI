-- Lua provided by RyzenAPI
-- Game: Game: Istanbul Ship Simulator

-- MAIN APPLICATION
addappid(1824210)
-- Game: addappid(1824210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824211, 1, "ad396009d1742ebd85eb97a7f049367a414d14b885076da7b38b82d82133a006")
