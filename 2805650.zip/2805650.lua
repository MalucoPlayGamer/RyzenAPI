-- Lua provided by RyzenAPI
-- Game: Diamonds Collector

-- MAIN APPLICATION
addappid(2805650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805651, 1, "526a1a7f7e17d1417aa7a9c3b3bc9e7e34011dd7e97ad7bef1ba928e1018c9a4")

