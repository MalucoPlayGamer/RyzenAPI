-- Lua provided by RyzenAPI
-- Game: PixiEditor

-- MAIN APPLICATION
addappid(2218560)
addappid(2435860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218561, 1, "be19d44c01f453b1e785aa854c56edf48852af1471436bd58caf8558f2741e7d")
addappid(2218562, 1, "1d89385bc7b8dacb7bdb511a84fb2d79222b8cfcacdfedca2c26c328a5610baf")
addappid(2218563, 1, "99659169871c42d74ff58d37e8708634fec963d589c5b87cdc0a765f4818d5ca")

