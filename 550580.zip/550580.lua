-- Lua provided by RyzenAPI
-- Game: addappid(550580)

-- MAIN APPLICATION
addappid(550580)

-- MAIN APP DEPOTS / PACKAGES
addappid(550581, 1, "e00643c1fdaed7ca56745abd4d086ce20b52e27a26cbf80590712ec968195831")
