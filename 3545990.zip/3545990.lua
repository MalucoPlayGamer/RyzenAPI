-- Lua provided by RyzenAPI 
-- Game: 美女，请别影响我成仙
addappid(3545990)
addappid(3545991, 1, "f66742d81c9b07984f28fee2a81e687feb9fa85c380fb7e3f03e311701d4125c")
addappid(3701000, 0, "fcd04125bc328fc24cc68ec1ae1bbe71f8caabd9217e36e78bef79b93e7f785b")
