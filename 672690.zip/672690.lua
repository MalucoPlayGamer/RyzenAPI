-- Lua provided by RyzenAPI
-- Game: AppID 672690

-- MAIN APPLICATION
addappid(672690)

-- MAIN APP DEPOTS / PACKAGES
addappid(672691, 1, "8f48da14da8b60f2f600c534cf11a5ae4c6e4b4263475b93420de10c76f72ab6")

