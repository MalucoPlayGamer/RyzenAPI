-- Lua provided by RyzenAPI 
-- Game: AppID 588560
addappid(588560)
addappid(588561, 1, "1d085bdf71a94889b60b9ec738797e8fc653cea58b970951dfa19a1fbace7097")
