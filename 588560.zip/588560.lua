-- Lua provided by RyzenAPI
-- Game: VRobot

-- MAIN APPLICATION
addappid(588560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(588561, 1, "1d085bdf71a94889b60b9ec738797e8fc653cea58b970951dfa19a1fbace7097")

