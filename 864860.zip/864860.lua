-- Lua provided by SkyAPI 
-- Game: HellCat
addappid(864860)
addappid(864861, 1, "72f5cdfcf987b349acb8f80820df2bf5dd6a5ff6671e4b57d9ba90502554c63a")
addappid(864862, 1, "9d1144c78480be4bdca7049553ba17fa7733696544c00e30734d448bebc65923")
addappid(1114800)
