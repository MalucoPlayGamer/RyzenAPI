-- Lua provided by RyzenAPI
-- Game: Halloween world

-- MAIN APPLICATION
addappid(1391400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1391401, 1, "1c9a1e621362c092646b821bff732209c0041003d0f525e8620f421b88006ff7")

