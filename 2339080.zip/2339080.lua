-- Lua provided by RyzenAPI
-- Game: Pigments

-- MAIN APPLICATION
addappid(2339080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2339081,0,"4c8849525164a2d1d0475e31263bec9972ec32c4fee4277b727c14e11a621fd1")
addappid(2339082,0,"02f4518ba0c8ee6411ee93a3a499d5a3008bb7ef45bf83ce4203e72f670482cf")
addappid(2339083,0,"50bcb6769d2fbdd85e44bcfeceef9aa6a9df7df7b6db1c8fba68275f8e9efc31")

