-- Lua provided by RyzenAPI
-- Game: AppID 1308950

-- MAIN APPLICATION
addappid(1308950)
-- Game: addappid(1308950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1308951, 1, "3e16a24fc3c1c7e8ca1f8ccc997112126624f4ac8a7755292ca00c1287a026a7")
