-- Lua provided by RyzenAPI 
-- Game: Mech Builder Demo
addappid(2890480)
addappid(2890481, 1, "524ff3a3c27f154cca12232d7285759a7a589785965297e3341a9d88fbb02dc5")
