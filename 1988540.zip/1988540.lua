-- Lua provided by SkyAPI 
-- Game: The Zachtronics Solitaire Collection
addappid(1988540)
addappid(1988541, 1, "466a6944303468eef1960dfe21a1ca8d2aed4821594a449d65d69859dad252a4")
addappid(1988542, 1, "938658eae963f1bc8a8175ecc1963b5ed8576c6a4cc7d06d182c127adca4e66d")
addappid(1988543, 1, "c828548abd851c39e6a82a378182078b86f5a5cf20e441d24b867ec78d62aa4f")
