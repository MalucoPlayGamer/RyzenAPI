-- Lua provided by RyzenAPI
-- Game: The Zachtronics Solitaire Collection

-- MAIN APPLICATION
addappid(1988540)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(1988541, 1, "466a6944303468eef1960dfe21a1ca8d2aed4821594a449d65d69859dad252a4")
addappid(1988542, 1, "938658eae963f1bc8a8175ecc1963b5ed8576c6a4cc7d06d182c127adca4e66d")
addappid(1988543, 1, "c828548abd851c39e6a82a378182078b86f5a5cf20e441d24b867ec78d62aa4f")

