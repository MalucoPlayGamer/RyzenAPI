-- Lua provided by RyzenAPI 
-- Game: Desolate City: Last Show
addappid(2687960)
addappid(2687961, 1, "05ac3c627af505fd24d61818a93ad79f128bbef1d9023b33e2ceee66cacb57b7")
