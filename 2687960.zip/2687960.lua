-- Lua provided by RyzenAPI
-- Game: Desolate City: Last Show

-- MAIN APPLICATION
addappid(2687960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2687961, 1, "05ac3c627af505fd24d61818a93ad79f128bbef1d9023b33e2ceee66cacb57b7")

