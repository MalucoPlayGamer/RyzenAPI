-- Lua provided by RyzenAPI
-- Game: Gamecraft

-- MAIN APPLICATION
addappid(1078000)
-- Game: addappid(1078000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078001, 1, "218ea3818c0da0a44279fb4cb5782ee6502822ccf9730e9c43fc6b24af8ddc98")
