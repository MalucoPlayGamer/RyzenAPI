-- Lua provided by RyzenAPI
-- Game: Gamecraft

-- MAIN APPLICATION
addappid(1078000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1078001, 1, "218ea3818c0da0a44279fb4cb5782ee6502822ccf9730e9c43fc6b24af8ddc98")

