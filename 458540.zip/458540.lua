-- Lua provided by RyzenAPI
-- Game: 458540

-- MAIN APPLICATION
addappid(458540)

-- MAIN APP DEPOTS / PACKAGES
addappid(458542,0,"44b46e5e5c9ee307f31c64cb4349cdc0420b0dbfd547ef831e9ed11869ed6634")

