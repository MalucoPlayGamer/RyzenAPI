-- Lua provided by RyzenAPI
-- Game: AppID 2675160

-- MAIN APPLICATION
addappid(2675160)
-- Game: addappid(2675160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2675161, 1, "bf4fddb4fc2700f37b12428aebf118a2802a41ec8bfcf3b4ea69ae8418c558c9")
