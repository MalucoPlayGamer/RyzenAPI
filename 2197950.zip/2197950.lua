-- Lua provided by RyzenAPI
-- Game: Sweety Kitty 2

-- MAIN APPLICATION
addappid(2197950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197951, 1, "d0a93adf8254b37726601e22587eedafcf6054de3f203ed6ec3d36f2c917d5f7")

