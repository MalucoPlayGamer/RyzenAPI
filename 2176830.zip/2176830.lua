-- Lua provided by RyzenAPI
-- Game: 2176830

-- MAIN APPLICATION
addappid(2176830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2176832,0,"74c48b0e8ecadb8a0c7f352b08dad123a513e2a61f0ce9ee1005cda35c7a637e")
