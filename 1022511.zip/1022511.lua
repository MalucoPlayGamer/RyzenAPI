-- Lua provided by RyzenAPI
-- Game: DFF NT: Fusion Sword, Cloud Strife's EX weapon

-- MAIN APPLICATION
addappid(1022511)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022511,0,"b5136c8460730ae12ae8863968ee4f1bc2d46a3f4f158354eb9e7317ef4f1a1e")

