-- Lua provided by RyzenAPI
-- Game: Monsti

-- MAIN APPLICATION
addappid(526790)

-- MAIN APP DEPOTS / PACKAGES
addappid(526791, 1, "9786debb1322800a410a36ae6c7cd2c1040a33c5496aaad1eb4ce5da174ef67f")
addappid(526850, 0, "2c348826edbf1c038d896785cabddf8f631805d8ea7dede4023eb8068f1834b1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
