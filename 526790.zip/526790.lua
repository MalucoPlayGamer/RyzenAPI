-- Lua provided by RyzenAPI
-- Game: Monsti

-- MAIN APPLICATION
addappid(526790)
-- Game: addappid(526790)

-- MAIN APP DEPOTS / PACKAGES
addappid(526791, 1, "9786debb1322800a410a36ae6c7cd2c1040a33c5496aaad1eb4ce5da174ef67f")
addappid(526850, 0, "2c348826edbf1c038d896785cabddf8f631805d8ea7dede4023eb8068f1834b1")
