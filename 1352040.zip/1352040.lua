-- Lua provided by RyzenAPI
-- Game: Fury Captain

-- MAIN APPLICATION
addappid(1352040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1352041, 1, "3fbc58610eec1a75b817de684713610e8311092b1169b2ee98ecab3f6adbc6f2")

