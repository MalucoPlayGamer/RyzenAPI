-- Lua provided by RyzenAPI
-- Game: 12110

-- MAIN APPLICATION
addappid(12110)
-- Game: addappid(12110)

-- MAIN APP DEPOTS / PACKAGES
addappid(12111, 1, "a7ad1f1b98647e90ed852384deda16f4822fd85665445503aa576ca6f82bdcb5")
