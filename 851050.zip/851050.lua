-- Lua provided by RyzenAPI
-- Game: PaperDolls

-- MAIN APPLICATION
addappid(851050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(851051, 1, "5823ac3b7a212a6239150eb9d1159fb6752c73e0581df0c6211aae54052f0279")
