-- Lua provided by RyzenAPI
-- Game: AppID 851050

-- MAIN APPLICATION
addappid(851050)
-- Game: addappid(851050)

-- MAIN APP DEPOTS / PACKAGES
addappid(851051, 1, "5823ac3b7a212a6239150eb9d1159fb6752c73e0581df0c6211aae54052f0279")
