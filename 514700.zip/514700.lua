-- Lua provided by RyzenAPI
-- Game: Mystery Case Files®: 13th Skull™ Collector's Edition

-- MAIN APPLICATION
addappid(514700)
-- Game: addappid(514700)

-- MAIN APP DEPOTS / PACKAGES
addappid(514701, 1, "f1287e8b1a869fb1b80e847ffc78285fad19c1673dd59b29be0f184dc4a3fa05")
