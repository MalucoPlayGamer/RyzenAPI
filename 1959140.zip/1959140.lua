-- Lua provided by RyzenAPI
-- Game: addappid(1959140)

-- MAIN APPLICATION
addappid(1959140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1959141, 1, "866b0d91fa3fad3b3817c84e21b53d14a2104b3a03410fb32e024f32768e49d5")
