-- Lua provided by RyzenAPI
-- Game: Diesel Legacy: The Brazen Age

-- MAIN APPLICATION
addappid(1959140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1959141, 1, "866b0d91fa3fad3b3817c84e21b53d14a2104b3a03410fb32e024f32768e49d5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
