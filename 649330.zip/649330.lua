-- Lua provided by RyzenAPI
-- Game: addappid(649330)

-- MAIN APPLICATION
addappid(649330)

-- MAIN APP DEPOTS / PACKAGES
addappid(649331, 1, "c292030cbfa95379c9b0fd90a9389d7b7b75f054c37a444ad12035f6306c1951")
