-- Lua provided by RyzenAPI
-- Game: Oversleep Demo

-- MAIN APPLICATION
addappid(2618550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2618551, 1, "349df6db0e4de6186b63b019af46579968a88a657050d6b3c54b947e2baf1ba6")
