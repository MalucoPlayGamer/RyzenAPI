-- Lua provided by RyzenAPI
-- Game: Aura Farming

-- MAIN APPLICATION
addappid(4754800) -- Aura Farming

-- MAIN APP DEPOTS / PACKAGES
addappid(4754801, 1, "49f00675e64d4048f01b829b8a7433031e46ef8e04f816d5b43c5f2b37964783") -- Depot 4754801

