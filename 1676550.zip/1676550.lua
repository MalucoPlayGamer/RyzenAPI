-- Lua provided by RyzenAPI
-- Game: Dull Grey

-- MAIN APPLICATION
addappid(1676550)
-- Game: addappid(1676550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1676551, 1, "ae3c9bebfc00fa09bf701987fcccb5b7a3e8f04399aca86ec3f488101f171d86")
