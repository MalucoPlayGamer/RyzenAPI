-- Lua provided by RyzenAPI
-- Game: Game: A Day - to bring them happiness

-- MAIN APPLICATION
addappid(1507990)
-- Game: addappid(1507990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507991, 1, "bbe0580177e28fd66dae533319a238928c5bdb86d0830726d0174ccb72938f99")
