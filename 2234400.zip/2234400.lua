-- Lua provided by RyzenAPI
-- Game: Eleonor's Nightmares

-- MAIN APPLICATION
addappid(2234400)
-- Game: addappid(2234400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2234401, 1, "f8fb97c9f13a6c6fd37bff3a05580968508971ee9209eda6436e2e9a4d33f1e3")
