-- Lua provided by RyzenAPI
-- Game: 2195410

-- MAIN APPLICATION
addappid(2195410)
-- Game: addappid(2195410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195411, 1, "9634043c605d62441a08ab388b7013a6cedb82be1cff7dbcdf8a8f77045a773a")
