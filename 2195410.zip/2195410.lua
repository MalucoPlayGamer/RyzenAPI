-- Lua provided by RyzenAPI
-- Game: Songs of Silence

-- MAIN APPLICATION
addappid(2195410)
addappid(2685660)
addappid(3400120)
addappid(3560460)
addappid(3670070)
addappid(3676040)
addappid(3774820)
addappid(3776820)
addappid(4179260)
addappid(4561030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195411, 1, "9634043c605d62441a08ab388b7013a6cedb82be1cff7dbcdf8a8f77045a773a")

