-- Lua provided by RyzenAPI
-- Game: 1851060

-- MAIN APPLICATION
addappid(1851060)
-- Game: addappid(1851060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851061, 1, "3c39d50e430ba2bfceab0e8cc25e2771014721193dc0b3afaa4e350cec9dcbf9")
