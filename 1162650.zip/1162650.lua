-- Lua provided by RyzenAPI
-- Game: addappid(1162650)

-- MAIN APPLICATION
addappid(1162650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162651, 1, "65c0be4bb826c50cd16e01d17d6c4e1b797744c62a1fefe9f85b393aaf0a9472")
