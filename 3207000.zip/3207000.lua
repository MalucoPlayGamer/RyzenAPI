-- Lua provided by RyzenAPI
-- Game: addappid(3207000)

-- MAIN APPLICATION
addappid(3207000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3207001, 1, "fe46b9225fba34e8b221fdf2c5f3365ade432fd3a250eea959256a7d3d32133e")
