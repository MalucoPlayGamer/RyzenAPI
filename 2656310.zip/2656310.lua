-- Lua provided by RyzenAPI
-- Game: Game: One Week With The Mafia

-- MAIN APPLICATION
addappid(2656310)
-- Game: addappid(2656310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2656311, 1, "50b2d8f27c16918f0c9749e3ddf12f6bbcc712d87f987fa730272a3a3b3a4f5e")
