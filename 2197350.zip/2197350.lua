-- Lua provided by RyzenAPI
-- Game: 2197350

-- MAIN APPLICATION
addappid(2197350)
-- Game: addappid(2197350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197351, 1, "cfd7a20fcbee50784c802c28ccee79ce4e8bf3d449ea73b626fb51780c926a77")
