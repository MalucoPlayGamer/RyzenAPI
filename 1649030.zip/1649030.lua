-- Lua provided by RyzenAPI
-- Game: Game: Digital Expo Center

-- MAIN APPLICATION
addappid(1649030)
-- Game: addappid(1649030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1649031, 1, "55176dd0001c5a74545a2a0d1a44a2a081c2beb510f738d460149a53da43ca25")
