-- Lua provided by RyzenAPI
-- Game: Digital Expo Center

-- MAIN APPLICATION
addappid(1649030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1649031, 1, "55176dd0001c5a74545a2a0d1a44a2a081c2beb510f738d460149a53da43ca25")

