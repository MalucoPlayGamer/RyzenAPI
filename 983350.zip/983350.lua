-- Lua provided by RyzenAPI
-- Game: 983350

-- MAIN APPLICATION
addappid(983350)
-- Game: addappid(983350)

-- MAIN APP DEPOTS / PACKAGES
addappid(983351, 1, "41bcda5ab651c000a60afb29409245f3129fdf0231833e7ceaddac219bb4a6e4")
addappid(1168480, 0, "b55f67028dcf73b3a6a8bde76f32c14e647a82337951e7d118d1233b0f0fbf72")
