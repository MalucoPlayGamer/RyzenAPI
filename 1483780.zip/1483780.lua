-- Lua provided by RyzenAPI
-- Game: Game: Tested on Humans: Escape Room

-- MAIN APPLICATION
addappid(1483780)
-- Game: addappid(1483780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483781, 1, "f3930df322fac20435286c042e284b9193431a8323c5d39839dad7a79a8de7ef")
