-- Lua provided by RyzenAPI
-- Game: Game: AppID 839860

-- MAIN APPLICATION
addappid(839860)
-- Game: addappid(839860)

-- MAIN APP DEPOTS / PACKAGES
addappid(839861, 1, "5ac402a2f2334d05381a6e9812036b0056375f135992ffe1a98b3b05d75e0d16")
