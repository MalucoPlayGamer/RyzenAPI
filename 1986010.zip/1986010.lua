-- Lua provided by RyzenAPI
-- Game: 灵墟

-- MAIN APPLICATION
addappid(1986010)
-- Game: addappid(1986010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986011, 1, "13b190445ccaf3058d0c3f959e94ad0a4ddf6982fe215327a00290d78549ed8b")
