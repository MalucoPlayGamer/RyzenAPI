-- Lua provided by RyzenAPI
-- Game: 1 Bit Survivor

-- MAIN APPLICATION
addappid(2493160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2493161, 1, "7e641e235475cf64ae06265c50e6fb841ef1f1fd0e31420178832d73135be283")

