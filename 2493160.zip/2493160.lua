-- Lua provided by SkyAPI 
-- Game: 1 Bit Survivor
addappid(2493160)
addappid(2493161, 1, "7e641e235475cf64ae06265c50e6fb841ef1f1fd0e31420178832d73135be283")
