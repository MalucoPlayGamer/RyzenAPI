-- Lua provided by RyzenAPI 
-- Game: Merchant in Dungeon
addappid(1671490)
addappid(1671491, 1, "f734c8e1cb9b78fcb2cb06341981fc1083a2132138f55b5085b1437942ab6098")
