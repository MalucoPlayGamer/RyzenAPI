-- Lua provided by RyzenAPI
-- Game: Merchant in Dungeon

-- MAIN APPLICATION
addappid(1671490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1671491, 1, "f734c8e1cb9b78fcb2cb06341981fc1083a2132138f55b5085b1437942ab6098")

