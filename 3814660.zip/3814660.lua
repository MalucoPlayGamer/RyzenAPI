-- Lua provided by RyzenAPI
-- Game: Fantasy  Journey

-- MAIN APPLICATION
addappid(3814660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3814662,0,"1766adaea2c8f0bfd9c3818583a0b644b8f88c1203c38a9f040fc4cf3edebec9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
