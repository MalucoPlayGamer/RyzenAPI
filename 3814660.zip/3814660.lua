-- Lua provided by RyzenAPI
-- Game: 3814660

-- MAIN APPLICATION
addappid(3814660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3814662,0,"1766adaea2c8f0bfd9c3818583a0b644b8f88c1203c38a9f040fc4cf3edebec9")

