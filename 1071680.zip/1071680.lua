-- Lua provided by RyzenAPI
-- Game: 1071680

-- MAIN APPLICATION
addappid(1071680)
-- Game: addappid(1071680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071681, 1, "f54ec839ec37fc4d165a079da28083c22db2a8bca9267329ead306a9845ef887")
