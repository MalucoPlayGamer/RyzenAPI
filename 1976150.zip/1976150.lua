-- Lua provided by RyzenAPI 
-- Game: Hush Hush - Only Your Love Can Save Them Demo
addappid(1976150)
addappid(1976151, 1, "761dd3106f68e700a252b778d0410a4c8d3d22aa43ebb591d718698a625f62a8")
