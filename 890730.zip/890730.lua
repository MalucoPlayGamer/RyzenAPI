-- Lua provided by RyzenAPI
-- Game: 890730

-- MAIN APPLICATION
addappid(890730)
-- Game: addappid(890730)

-- MAIN APP DEPOTS / PACKAGES
addappid(890731, 1, "f26122e0c18bf9260b94174359169b41aeecac1bb5a3d1398f78c9ee1e4172d6")
