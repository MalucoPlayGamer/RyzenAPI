-- Lua provided by RyzenAPI
-- Game: Trashyard

-- MAIN APPLICATION
addappid(1701640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701641, 1, "a7f5b939d491288ac6c904696a4c797ecb0087724426423c00ef8dbc2eeab139")

