-- Lua provided by SkyAPI 
-- Game: Coast team
addappid(1083410)
addappid(1083411, 1, "1ad1208f4a54b7d9057de3c8f23c343893f0a459f1f68c01497cc48ed48ded7b")
