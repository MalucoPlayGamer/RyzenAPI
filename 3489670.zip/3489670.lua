-- Lua provided by RyzenAPI
-- Game: The Happyhills Homicide 2: Out For Blood

-- MAIN APPLICATION
addappid(3489670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3489671, 1, "b25d40e9a2fe6ead884f54a1b2b763f0b1ba33eda50ee5e40471958dec50bf11")
