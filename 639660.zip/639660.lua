-- Lua provided by RyzenAPI
-- Game: Undying Demo

-- MAIN APPLICATION
addappid(639660)
-- Game: addappid(639660)

-- MAIN APP DEPOTS / PACKAGES
addappid(639661, 1, "4cbe7e6ee0625be260d36616d7e6eb5d3a12d41b7f9cb8273518cd5cf8335657")
