-- Lua provided by RyzenAPI
-- Game: CATGIRL LOVER

-- MAIN APPLICATION
addappid(1096720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1096721, 1, "202e2849b73105622f35969ef7b62834f306a4fe6b52feae995775895f1d8d28")
addappid(1110880, 0, "4a8dc99d1ab1a56bec6b69b0626ee74de663751746bdf68e6414675a4da6296c")

