-- Lua provided by RyzenAPI
-- Game: Demeo Battles Demo

-- MAIN APPLICATION
addappid(2611090)
-- Game: addappid(2611090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2611091, 1, "13b1d36db715c3babba36ddf3b054326cb6a6761943f0c9a5342692cbe565825")
