-- Lua provided by RyzenAPI
-- Game: Kamikaze Cube 2

-- MAIN APPLICATION
addappid(906190)
addappid(909140)

-- MAIN APP DEPOTS / PACKAGES
addappid(906191, 1, "400bf63e56b2497e457f67a28f7d7eb4d4ee7c6ff467909bd1e57e75de6bbf21")

