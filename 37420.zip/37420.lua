-- Lua provided by RyzenAPI
-- Game: Time Gentlemen, Please! and Ben There, Dan That! Special Edition  Double Pack

-- MAIN APPLICATION
addappid(37420)

-- MAIN APP DEPOTS / PACKAGES
addappid(37421, 1, "0cc4226a10a59b9efbe293a92f52292ef89eda3913b913a5d6f008b3b5512bf7")
