-- Lua provided by RyzenAPI
-- Game: Action Alien: Survival

-- MAIN APPLICATION
addappid(773330)

-- MAIN APP DEPOTS / PACKAGES
addappid(773331, 1, "fa943093eb201be3fe1d66d0b76a856b7789335595450ef3d2588b1c2d7217e3")

