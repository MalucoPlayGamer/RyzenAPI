-- Lua provided by RyzenAPI
-- Game: Action Alien: Survival

-- MAIN APPLICATION
addappid(773330)

-- MAIN APP DEPOTS / PACKAGES
addappid(773331, 1, "fa943093eb201be3fe1d66d0b76a856b7789335595450ef3d2588b1c2d7217e3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
