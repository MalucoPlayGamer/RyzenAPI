-- Lua provided by RyzenAPI
-- Game: AppID 1579190

-- MAIN APPLICATION
addappid(1579190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1579191, 1, "e7da23046f1354577471eadc3331f9d2af8263f4877fd2a95287ff38f8ae20bd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
