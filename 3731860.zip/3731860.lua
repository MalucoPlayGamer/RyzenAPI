-- Lua provided by RyzenAPI
-- Game: Ghost Observation

-- MAIN APPLICATION
addappid(3731860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3731861,0,"798f01dd59996eb07dcf12b3b36aeb0452cadd25dc113838e07204dd2850d74b")

