-- Lua provided by RyzenAPI
-- Game: Ghost Observation

-- MAIN APPLICATION
addappid(3731860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3731861,0,"798f01dd59996eb07dcf12b3b36aeb0452cadd25dc113838e07204dd2850d74b")

