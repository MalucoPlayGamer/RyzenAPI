-- Lua provided by RyzenAPI
-- Game: Daily Dadish

-- MAIN APPLICATION
addappid(2274700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2274701, 1, "7b86a21bc870bd06c0a30fe3a54f0e38dea519446d785676fee5db3121bfb006")
