-- Lua provided by RyzenAPI
-- Game: Milling machine simulator

-- MAIN APPLICATION
addappid(1787960)
-- Game: addappid(1787960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787961, 1, "3b607d998f0743eab417b67359783a77214886d5932bcc9cb0c8ba05b572b369")
