-- Lua provided by RyzenAPI
-- Game: Game: Content Warning

-- MAIN APPLICATION
addappid(2881650)
-- Game: addappid(2881650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2881651, 1, "def8422fa7589f4d65aa2cbbb21d623f10e3ad941e695558651289920c89c1d9")
