-- Lua provided by SkyAPI 
-- Game: Content Warning
addappid(2881650)
addappid(2881651, 1, "def8422fa7589f4d65aa2cbbb21d623f10e3ad941e695558651289920c89c1d9")
