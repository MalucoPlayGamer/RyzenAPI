-- Lua provided by RyzenAPI
-- Game: Game: V-Rally 4

-- MAIN APPLICATION
addappid(658700)
-- Game: addappid(658700)

-- MAIN APP DEPOTS / PACKAGES
addappid(658701, 1, "969872cb64d29a8d6b9372a33951e45b1fa559104cf49f4202282392cfde4403")
