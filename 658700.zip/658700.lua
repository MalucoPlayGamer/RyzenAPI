-- Lua provided by RyzenAPI
-- Game: V-Rally 4

-- MAIN APPLICATION
addappid(658700)
addappid(900230)
addappid(900231)
addappid(900232)
addappid(918792)
addappid(918793)
addappid(918794)
addappid(918795)
addappid(958940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(658701, 1, "969872cb64d29a8d6b9372a33951e45b1fa559104cf49f4202282392cfde4403")

