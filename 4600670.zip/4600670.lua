-- Lua provided by RyzenAPI
-- Game: Life in Tudorofka

-- MAIN APPLICATION
addappid(4600670)

-- MAIN APP DEPOTS / PACKAGES
addappid(4600671,0,"50f661cd2409d077dec5cba13055a42b8733ee4e6ea8b6c3b6614c8d22093cfe")

