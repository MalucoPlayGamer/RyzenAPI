-- Lua provided by RyzenAPI
-- Game: Tower! Simulator 3

-- MAIN APPLICATION
addappid(2176130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2176131, 1, "646f01966806a6cff7c5929b91d7c280dff02b08fef9809a02de19a8ad295707")

