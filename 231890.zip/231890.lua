-- Lua provided by RyzenAPI
-- Game: Game: AppID 231890

-- MAIN APPLICATION
addappid(231890)
-- Game: addappid(231890)

-- MAIN APP DEPOTS / PACKAGES
addappid(231891, 1, "2594ee432c24a0bac8340f757311075f6fe68a468c6830995b7d63e3cf4fd2e7")
