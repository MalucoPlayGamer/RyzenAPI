-- Lua provided by RyzenAPI
-- Game: 2140700

-- MAIN APPLICATION
addappid(2140700)
-- Game: addappid(2140700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140701, 1, "26f74f3d1deb8784c7adb55de878e59b32d3d1c8a2af6ca263c9ab1befbf920b")
