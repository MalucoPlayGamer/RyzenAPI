-- Lua provided by RyzenAPI
-- Game: SO BELOW

-- MAIN APPLICATION
addappid(2140700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140701, 1, "26f74f3d1deb8784c7adb55de878e59b32d3d1c8a2af6ca263c9ab1befbf920b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
