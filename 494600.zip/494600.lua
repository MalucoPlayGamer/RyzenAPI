-- Lua provided by RyzenAPI
-- Game: AppID 494600

-- MAIN APPLICATION
addappid(494600)
-- Game: addappid(494600)

-- MAIN APP DEPOTS / PACKAGES
addappid(494601, 1, "7110a1046d6aa895bcd5b5853c03b2832958a956815c065af003a884dee422ab")
