-- Lua provided by SkyAPI 
-- Game: AppID 494600
addappid(494600)
addappid(494601, 1, "7110a1046d6aa895bcd5b5853c03b2832958a956815c065af003a884dee422ab")
