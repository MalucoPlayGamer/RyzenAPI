-- Lua provided by RyzenAPI
-- Game: The Witch of Fern Island

-- MAIN APPLICATION
addappid(1550010)
-- Game: addappid(1550010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550011, 1, "c8b421065260e3d0cf67fd1632fc48eb13af312245d4097c394a14b6112e466e")
