-- Lua provided by RyzenAPI
-- Game: The Witch of Fern Island

-- MAIN APPLICATION
addappid(1550010)
addappid(2789350)
addappid(2997350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1550011, 1, "c8b421065260e3d0cf67fd1632fc48eb13af312245d4097c394a14b6112e466e")

