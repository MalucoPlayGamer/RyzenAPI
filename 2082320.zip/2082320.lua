-- Lua provided by RyzenAPI
-- Game: addappid(2082320)

-- MAIN APPLICATION
addappid(2082320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2082321, 1, "18056fcab71f04b11dda95f597d501b97af7c44f2235b50ca89b39e1ebb5801f")
