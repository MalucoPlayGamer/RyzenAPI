-- Lua provided by SkyAPI 
-- Game: The Master's Pupil
addappid(2082320)
addappid(2082321, 1, "18056fcab71f04b11dda95f597d501b97af7c44f2235b50ca89b39e1ebb5801f")
