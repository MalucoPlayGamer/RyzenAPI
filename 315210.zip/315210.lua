-- Lua provided by RyzenAPI
-- Game: AppID 315210

-- MAIN APPLICATION
addappid(315210)

-- MAIN APP DEPOTS / PACKAGES
addappid(315211, 1, "fabb38272098c3396b2e9f2e47f227b066bb5213920e64570afdac89330de21f")
addappid(315212, 1, "e61a5741667835bdbabe5aebc4348b520f97ed4156dbe3fd607e21a0093fcda0")
addappid(315213, 1, "1e45ecc87c25598487a2fc6aad943085a92d9a220160bf9ed500e24c9669961f")
addappid(315214, 1, "60dc3874da94039f2347261a4d0a3bd1060c1517abadc1872e54887c945cd494")
addappid(315215, 1, "e49e77edadfd05a3d449e867449d8c08a73ca9ff247841043dd594e427ef1c17")
addappid(315216, 1, "cc2767e57c58cc4ce064181e68edb5a71427e4bc638e57ab71ac5b4f089c5b3f")
addappid(315217, 1, "92f2682dbe683871e849b0dc13ec3e397c03d3683720af203527c36e2bd83ab6")
addappid(315218, 1, "0a751ccef3454275907a0e4349eb73ddf25f9c4cfadf6574927bf1cc50f4a387")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2474100)
addappid(2474110)
addappid(2716350)
