-- Lua provided by RyzenAPI
-- Game: AppID 629230

-- MAIN APPLICATION
addappid(629230)
-- Game: addappid(629230)

-- MAIN APP DEPOTS / PACKAGES
addappid(629231, 1, "0ee9a4b6ed784858a455650196780fb9d6f2b4dc95cb379bf91c561477beb861")
