-- Lua provided by RyzenAPI
-- Game: Archaeology - Egypt

-- MAIN APPLICATION
addappid(3244700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3244701, 1, "109bc6ad08eab7c64765bbc89f266e29fbceb1305f540536db1ce2b369c61126")

