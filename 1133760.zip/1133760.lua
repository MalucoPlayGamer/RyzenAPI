-- Lua provided by SkyAPI 
-- Game: AppID 1133760
addappid(1133760)
addappid(1133761, 1, "b4bbdb5b7404dbfdf47766ebff4a48321f558494ee2d181693727679eb8f7967")
addappid(1901760, 0, "d2ba8b92cf5564a409bfd219f7f2fa9e136c3ff8a3cd8fb030120ff92940feb8")
