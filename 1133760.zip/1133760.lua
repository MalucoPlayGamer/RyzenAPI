-- Lua provided by RyzenAPI
-- Game: AppID 1133760

-- MAIN APPLICATION
addappid(1133760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1133761, 1, "b4bbdb5b7404dbfdf47766ebff4a48321f558494ee2d181693727679eb8f7967")
addappid(1901760, 0, "d2ba8b92cf5564a409bfd219f7f2fa9e136c3ff8a3cd8fb030120ff92940feb8")

