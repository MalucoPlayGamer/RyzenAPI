-- Lua provided by RyzenAPI
-- Game: addappid(535230)

-- MAIN APPLICATION
addappid(535230)
addappid(1140080)
addappid(1140081)
addappid(1140082)
addappid(1140083)
addappid(1140084)
addappid(1140085)

-- MAIN APP DEPOTS / PACKAGES
addappid(535231, 1, "dbd05ab6361c4a60b0ec5367cd5d332a61dd7a791542b20825df5c0f736d7bb9")
addappid(535232, 1, "18b835b7a0c5190a3c902bc33be73035f7517c1ba77cdbde6af284254c07b6a5")
addappid(615540, 0, "5cfae5ec6c72d2f52728b24a0f998597f58b153d14ad611d33616869272a0745")
