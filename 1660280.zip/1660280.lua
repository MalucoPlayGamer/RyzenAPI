-- Lua provided by SkyAPI 
-- Game: H-Isekai Loves
addappid(1660280)
addappid(1660281, 1, "8cc649cb0a22cb4c90df6a1cda5c2cb79e8f4c8a98eefbd12ae3c302a4b0b52d")
addappid(1845310)
