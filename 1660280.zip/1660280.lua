-- Lua provided by RyzenAPI
-- Game: H-Isekai Loves

-- MAIN APPLICATION
addappid(1660280)
addappid(1845310)
-- Game: addappid(1660280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1660281, 1, "8cc649cb0a22cb4c90df6a1cda5c2cb79e8f4c8a98eefbd12ae3c302a4b0b52d")
