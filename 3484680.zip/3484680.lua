-- Lua provided by RyzenAPI
-- Game: LES MILLS XR BODYCOMBAT

-- MAIN APPLICATION
addappid(3484680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3484681, 1, "f876e66a7ccce5c6d4d0b2c7c14a098e80469c462db79317d766bac33240fd8b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3713580)
