-- Lua provided by SkyAPI 
-- Game: Shout Of Survival
addappid(491070)
addappid(491071, 1, "98da0ff8bdc45b826172f9f201ee95d363cb6779f0131f709974ca1a2fd66b52")
addappid(491072, 1, "c3f2c9c4d18f331009a9532eefb56789ae5c81ace752ac743db5f233db1d520d")
