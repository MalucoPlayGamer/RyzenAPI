-- Lua provided by RyzenAPI
-- Game: 夏荷 | Summer Lotus

-- MAIN APPLICATION
addappid(931470)

-- MAIN APP DEPOTS / PACKAGES
addappid(931471, 1, "06a929ac6f1c86eb58fe6b4e3a50ecfc17cee5759450b1401aca47970abff033")
addappid(931472, 1, "89578491c26c771e5a0450e2078ff80f2fdf5c4d9a9a164bd519dee5d85b2007")

