-- Lua provided by RyzenAPI
-- Game: addappid(818730)

-- MAIN APPLICATION
addappid(818730)

-- MAIN APP DEPOTS / PACKAGES
addappid(818731, 1, "8e5074b18f38059a0a4fb71d99d24c6c4a6c1eeb41ef4c0f8a89d85792d29e7d")
