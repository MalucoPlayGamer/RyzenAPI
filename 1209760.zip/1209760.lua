-- Lua provided by RyzenAPI
-- Game: Aloe and Cal

-- MAIN APPLICATION
addappid(1209760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209761, 1, "d4a571444b7c0509cc8da7b76e79538974b3704ea547fde4b07028a832376dcb")

