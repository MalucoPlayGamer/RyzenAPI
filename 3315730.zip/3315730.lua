-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3315730)
addappid(3315731)
addappid(3315732)
addappid(3315733)
addappid(3315734)
-- Game: addappid(3315730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3315730,0,"d87bcc2e41f169a0aad25394c45f6aef961dd5b91fdafbdf563491647bdc4c36")
