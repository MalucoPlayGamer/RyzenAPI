-- Lua provided by RyzenAPI
-- Game: AppID 1288900

-- MAIN APPLICATION
addappid(1288900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1288901, 1, "108d89388cc615ea0b122f346587f6e945451b48828b4b695dcb8f96dd64f331")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
