-- Lua provided by RyzenAPI
-- Game: Game: AppID 1288900

-- MAIN APPLICATION
addappid(1288900)
-- Game: addappid(1288900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1288901, 1, "108d89388cc615ea0b122f346587f6e945451b48828b4b695dcb8f96dd64f331")
