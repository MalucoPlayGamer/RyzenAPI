-- Lua provided by RyzenAPI 
-- Game: AppID 1288900
addappid(1288900)
addappid(1288901, 1, "108d89388cc615ea0b122f346587f6e945451b48828b4b695dcb8f96dd64f331")
