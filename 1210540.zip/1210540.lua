-- Lua provided by RyzenAPI 
-- Game: TCM RACING 2
addappid(1210540)
addappid(1210541, 1, "d8ade1696d0cde8443e5bafb417786975ef867a05cc219e3ab03e6a3ab2422ad")
addappid(1210542, 1, "b3f3a0770cb2e6cad62b1edbbed1d8606bf9bed65f0a257669b6d78fde05dda6")
addappid(1210543, 1, "1f8d653dc588dad91d1f7aea240a533fda3338bdc754d97405a1027e2879cf8f")
