-- Lua provided by RyzenAPI
-- Game: Spire Horizon Online Demo

-- MAIN APPLICATION
addappid(3191080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3191081, 1, "73e3fcd70d1dc47a45971b717b6c2d95322fa82ca41a07f08577d7318584ea87")

