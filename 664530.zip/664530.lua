-- Lua provided by RyzenAPI
-- Game: Game: Legends of Iskaria: Days of Thieves

-- MAIN APPLICATION
addappid(664530)
-- Game: addappid(664530)

-- MAIN APP DEPOTS / PACKAGES
addappid(664531, 1, "bfdc1da19472de4b1f62190e77f2156e8d282e0446f380b364e49558c74a1b42")
