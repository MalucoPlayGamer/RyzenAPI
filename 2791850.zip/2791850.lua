-- Lua provided by RyzenAPI
-- Game: Celestia: Chain of Fate

-- MAIN APPLICATION
addappid(2791850)
-- Game: addappid(2791850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791851, 1, "7834ade762e6a392d32fc100ae43cb3ac8619b0d3f48415c38d2351a8b271548")
