-- Lua provided by SkyAPI 
-- Game: AppID 797190
addappid(797190)
addappid(797191, 1, "adf6a38af9daa8f8dfa2a2450f038acddb3d6343bbe4f4e50afb2604dc99a32c")
