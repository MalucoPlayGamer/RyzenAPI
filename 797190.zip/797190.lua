-- Lua provided by RyzenAPI
-- Game: 797190

-- MAIN APPLICATION
addappid(797190)
-- Game: addappid(797190)

-- MAIN APP DEPOTS / PACKAGES
addappid(797191, 1, "adf6a38af9daa8f8dfa2a2450f038acddb3d6343bbe4f4e50afb2604dc99a32c")
