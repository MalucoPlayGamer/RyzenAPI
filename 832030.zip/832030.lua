-- Lua provided by RyzenAPI
-- Game: addappid(832030)

-- MAIN APPLICATION
addappid(832030)

-- MAIN APP DEPOTS / PACKAGES
addappid(832031, 1, "c351a085765998bd8052a610f6f8e4e1b64f20eb617e99853cc06f9e21710f3c")
