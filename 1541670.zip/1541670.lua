-- Lua provided by RyzenAPI 
-- Game: Giant Blobs From Mars
addappid(1541670)
addappid(1541671, 1, "1bdafd0756a7a07e1a3ffde8d0b06403d11638260050b4d48bde5f9858bea611")
