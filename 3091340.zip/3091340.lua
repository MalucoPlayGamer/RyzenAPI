-- Lua provided by RyzenAPI
-- Game: Game: Metal Thunder

-- MAIN APPLICATION
addappid(3091340)
-- Game: addappid(3091340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3091341, 1, "c611035f5f9ae37d5fc0cf5fc96599068c1c30273c3483cdfa9f31c59f30991b")
