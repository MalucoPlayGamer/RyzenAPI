-- Lua provided by RyzenAPI
-- Game: Sexy Furry - Wild Cat Furry DLC

-- MAIN APPLICATION
addappid(3402080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3402080,0,"69a16f9c5ab24510d58265892e4d6a369b46de7637a2bc2f2b0e5c38447e6db9")

