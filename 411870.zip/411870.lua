-- Lua provided by RyzenAPI
-- Game: Game: Discovering Colors - Animals

-- MAIN APPLICATION
addappid(411870)
-- Game: addappid(411870)

-- MAIN APP DEPOTS / PACKAGES
addappid(411871, 1, "c8d84ca009b2e84ac693957e181a076deb049f9603ef463551b20eeb45a2a40a")
