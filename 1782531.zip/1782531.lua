-- Lua provided by RyzenAPI
-- Game: 1782531

-- MAIN APPLICATION
addappid(1782531)
-- Game: addappid(1782531)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782531,0,"b815ed684deac618bea785ee5a37450e6cedc630e5077a4c403dd29c2d339e5e")
