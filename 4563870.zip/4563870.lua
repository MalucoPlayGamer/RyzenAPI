-- Lua provided by RyzenAPI
-- Game: Miseria

-- MAIN APPLICATION
addappid(4563870) -- Miseria

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4563871, 1, "e37e2ee05621c66f9d1a1d776c1e359da0d0a6f4a196b45fdb6d319809f6a978") -- Depot 4563871

