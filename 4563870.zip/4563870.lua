-- 4563870's Lua and Manifest Created by Hubcap Manifest
-- Miseria
-- Created: August 07, 2026 at 22:56:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4563870) -- Miseria
-- MAIN APP DEPOTS
addappid(4563871, 1, "e37e2ee05621c66f9d1a1d776c1e359da0d0a6f4a196b45fdb6d319809f6a978") -- Depot 4563871
setManifestid(4563871, "991993159204599527", 807515598)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)