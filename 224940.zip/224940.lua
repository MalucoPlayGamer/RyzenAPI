-- Lua provided by RyzenAPI
-- Game: Legacy of Kain: Soul Reaver 2 (2001)

-- MAIN APPLICATION
addappid(224940)

-- MAIN APP DEPOTS / PACKAGES
addappid(224941, 1, "be5213fa65e18ef3326472ee087732d4c1026127d41c84a008ede6cb3f49b487")
