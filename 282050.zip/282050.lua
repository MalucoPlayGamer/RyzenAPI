-- Lua provided by RyzenAPI
-- Game: MX vs. ATV Supercross Encore

-- MAIN APPLICATION
addappid(282050)
addappid(420890)
addappid(421160)
addappid(421161)
addappid(421162)
addappid(421163)
addappid(421164)
addappid(421165)
addappid(430322)
addappid(430324)
addappid(430325)
addappid(430326)
addappid(430327)
addappid(430328)
addappid(430329)
addappid(564500)
addappid(564501)
addappid(564502)
addappid(564503)
addappid(564504)
addappid(564505)
addappid(564506)
addappid(564507)
addappid(564508)
addappid(564509)
addappid(564510)

-- MAIN APP DEPOTS / PACKAGES
addappid(282051, 1, "ce3bbf86d7314938bc3c0364de9aae051f4bd5575c9bd0a1251495253b06d5a5")
