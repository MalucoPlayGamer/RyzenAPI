-- Lua provided by RyzenAPI
-- Game: OLDTV

-- MAIN APPLICATION
addappid(643270)
addappid(683420)
addappid(736100)

