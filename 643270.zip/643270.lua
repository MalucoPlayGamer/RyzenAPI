-- Lua provided by RyzenAPI
-- Game: OLDTV

-- MAIN APPLICATION
addappid(643270)
