-- Lua provided by RyzenAPI
-- Game: OLDTV

-- MAIN APPLICATION
addappid(643270)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(683420)
addappid(736100)
