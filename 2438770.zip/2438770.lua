-- Lua provided by RyzenAPI
-- Game: Game: Chores of Corruption

-- MAIN APPLICATION
addappid(2438770)
-- Game: addappid(2438770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2438771, 1, "de502a9fae6a6cc08581778ef6df6641e224f71b868e647f9b24f2348971b68c")
