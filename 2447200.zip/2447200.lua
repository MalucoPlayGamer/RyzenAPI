-- Lua provided by RyzenAPI
-- Game: addappid(2447200)

-- MAIN APPLICATION
addappid(2447200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2447201, 1, "150300dad9623e07faa62f7c28c216bf0cec785ba81d7ff15331ef6771488ed9")
