-- Lua provided by RyzenAPI
-- Game: 闪客快打8武装行

-- MAIN APPLICATION
addappid(2319050)
-- Game: addappid(2319050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2319051, 1, "cea2d1606a031d61487e3cf63fa62297af80a5356e0b828ce6388d52c9d6f279")
