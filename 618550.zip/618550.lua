-- Lua provided by RyzenAPI
-- Game: Chess of Blades

-- MAIN APPLICATION
addappid(618550)

-- MAIN APP DEPOTS / PACKAGES
addappid(618551,0,"bd80818fe0810b455bc1abddc2b0b03a7ad2ccf49889b4bf88016d4c00151b74")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(791670)
