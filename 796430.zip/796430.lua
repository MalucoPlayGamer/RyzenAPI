-- Lua provided by RyzenAPI
-- Game: addappid(796430)

-- MAIN APPLICATION
addappid(796430)

-- MAIN APP DEPOTS / PACKAGES
addappid(796432,0,"bf6fda882334abf4455ecefa65a85f9ad4cb10c64d0856f492e9d640e24f6883")
