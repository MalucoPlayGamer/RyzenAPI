-- Lua provided by RyzenAPI
-- Game: AppID 593620

-- MAIN APPLICATION
addappid(593620)
addappid(739830)
-- Game: addappid(593620)

-- MAIN APP DEPOTS / PACKAGES
addappid(593621, 1, "e0be7aff0f46d2a16bf98d54312c4423089aae6b76a4936199733ee907db2cf1")
addappid(739831, 0, "ebacc05d2f2128f13c9f978591254c6e6952bf98befcc6a35a2ebca4af70b437")
