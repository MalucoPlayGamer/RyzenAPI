-- Lua provided by RyzenAPI
-- Game: Bow Man

-- MAIN APPLICATION
addappid(1713070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1713071, 1, "ec331084f678b012216b6e4015105e9bed90523d02d6943cd80bdb3f1cdd5973")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
