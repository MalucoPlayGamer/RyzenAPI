-- Lua provided by RyzenAPI
-- Game: Bow Man

-- MAIN APPLICATION
addappid(1713070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1713071, 1, "ec331084f678b012216b6e4015105e9bed90523d02d6943cd80bdb3f1cdd5973")
