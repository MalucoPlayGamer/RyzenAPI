-- Lua provided by RyzenAPI
-- Game: Winter With You

-- MAIN APPLICATION
addappid(1870580)
-- Game: addappid(1870580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1870581, 1, "0f7e54857363a2785c878b7a52ac9fd5f1a3cb0108cf7ad321b0219fc730096c")
