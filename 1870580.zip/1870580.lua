-- Lua provided by SkyAPI 
-- Game: Winter With You
addappid(1870580)
addappid(1870581, 1, "0f7e54857363a2785c878b7a52ac9fd5f1a3cb0108cf7ad321b0219fc730096c")
