-- Lua provided by RyzenAPI
-- Game: Game: Little Adventurer II

-- MAIN APPLICATION
addappid(708630)
-- Game: addappid(708630)

-- MAIN APP DEPOTS / PACKAGES
addappid(708631, 1, "db19c8fd6a474e3706572d583436f1c81ef06aafb985030116a97eeb2d514e03")
