-- Lua provided by SkyAPI 
-- Game: Imperial Storm
addappid(2152250)
addappid(2152251, 1, "79530f053cff28215b77e0ec69b12d176c2a44486ee69af4371481b4ca671eed")
