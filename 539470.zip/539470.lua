-- Lua provided by RyzenAPI
-- Game: Game: Police Stories

-- MAIN APPLICATION
addappid(539470)
-- Game: addappid(539470)

-- MAIN APP DEPOTS / PACKAGES
addappid(539471, 1, "97aedb03fac2a0fdfc6c50144f1fd57db3bc61e2c2b81f2d74556611635d5651")
addappid(539472, 1, "cd75e96b4cfafa6918a4cd75fc58ad80061b3e9a12c5559d138fdd214ee294b2")
addappid(539473, 1, "de069b7fb2704f6027aa1890917b246471e650250634876079df7d5fee987905")
addappid(1158270, 0, "40f85c8b7b36d0b6345da0ad638c24b53d4806ff660a43b478321fd7a9a8e951")
