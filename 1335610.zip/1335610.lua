-- Lua provided by RyzenAPI
-- Game: JoY

-- MAIN APPLICATION
addappid(1335610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1335612,0,"79f281809f561c3705301e47da8fbd982693ba2c986b04e08f8b31f5d2a700a5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
