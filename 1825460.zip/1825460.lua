-- Lua provided by RyzenAPI
-- Game: PC Virtual LAB

-- MAIN APPLICATION
addappid(1825460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1825461, 1, "109673a0ac6dc2e8011c2b429bec70c1893adf948900aeb2c8329faeaa8441f3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
