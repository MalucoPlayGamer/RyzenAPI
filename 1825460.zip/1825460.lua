-- Lua provided by RyzenAPI
-- Game: addappid(1825460)

-- MAIN APPLICATION
addappid(1825460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1825461, 1, "109673a0ac6dc2e8011c2b429bec70c1893adf948900aeb2c8329faeaa8441f3")
