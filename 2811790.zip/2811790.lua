-- Lua provided by RyzenAPI
-- Game: QI

-- MAIN APPLICATION
addappid(2811790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2811792,0,"9a59114de3a74e90ecd39cbe5e221074d4b7562d735a1a81fb759effd9cfc268")
