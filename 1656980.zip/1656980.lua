-- Lua provided by RyzenAPI
-- Game: 1656980

-- MAIN APPLICATION
addappid(1656980)
-- Game: addappid(1656980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656981, 1, "ec8acdfc7a38eb52da6c9f898792866605460b4c2834e9e4a3a8a058f09cfaf0")
