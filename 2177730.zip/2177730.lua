-- Lua provided by RyzenAPI
-- Game: addappid(2177730)

-- MAIN APPLICATION
addappid(2177730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177731, 1, "26060a676eca5f0b38a1f97c68db9f8986868e6ac30e3439e88b46a3ac168707")
