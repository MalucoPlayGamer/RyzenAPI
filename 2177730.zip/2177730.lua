-- Lua provided by RyzenAPI
-- Game: Missing Pictures : Naomi Kawase

-- MAIN APPLICATION
addappid(2177730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2177731, 1, "26060a676eca5f0b38a1f97c68db9f8986868e6ac30e3439e88b46a3ac168707")

