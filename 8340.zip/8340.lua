-- Lua provided by RyzenAPI
-- Game: Game: Strong Bad's Cool Game for Attractive People: Season 1

-- MAIN APPLICATION
addappid(8340)
-- Game: addappid(8340)

-- MAIN APP DEPOTS / PACKAGES
addappid(8341, 1, "d3c32c56e8de0fa05024762233481727e814986ec6d910de252cda83cd890dbc")
addappid(8342, 1, "f381b12c9083ec6cfbbe73c2b0d47c15685d9d99d6e0fe0cd18ecfcb46e6c162")
