-- Lua provided by RyzenAPI
-- Game: Love x Debut

-- MAIN APPLICATION
addappid(2589670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589671, 1, "05e7f628cb8c68b4c33f973c79dc6a32e6dc17bc10516ea86262515b9070949e")

