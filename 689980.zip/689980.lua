-- Lua provided by RyzenAPI
-- Game: Car Trader Simulator

-- MAIN APPLICATION
addappid(689980)

-- MAIN APP DEPOTS / PACKAGES
addappid(689981, 1, "7d4bc7959a787db4b343162211210bca845cfd2d3fa93124c97f36d369ed509b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
