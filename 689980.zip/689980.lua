-- Lua provided by RyzenAPI
-- Game: Car Trader Simulator

-- MAIN APPLICATION
addappid(689980)

-- MAIN APP DEPOTS / PACKAGES
addappid(689981, 1, "7d4bc7959a787db4b343162211210bca845cfd2d3fa93124c97f36d369ed509b")

