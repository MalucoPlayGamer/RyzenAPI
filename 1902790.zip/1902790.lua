-- Lua provided by RyzenAPI
-- Game: 刻印战记：冰冻之剑 RE

-- MAIN APPLICATION
addappid(1902790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1902791, 1, "84f5014f8108f3d7dd3e01619d2f8aa3e82bd17149d92ce264fbe7d8a1245101")
