-- Lua provided by RyzenAPI
-- Game: 2017390

-- MAIN APPLICATION
addappid(2017390)
-- Game: addappid(2017390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017391, 1, "91f4f26fcdf7b04dd9844a4daec3e061c4d12eec246ab73168fbaec657381142")
