-- Lua provided by SkyAPI 
-- Game: AppID 948880
addappid(948880)
addappid(948881, 1, "c784420ce7bc07a081d1283d40becac1176d507f1d2554c5283a8e462f3c6855")
