-- Lua provided by RyzenAPI
-- Game: AppID 948880

-- MAIN APPLICATION
addappid(948880)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(948881, 1, "c784420ce7bc07a081d1283d40becac1176d507f1d2554c5283a8e462f3c6855")

