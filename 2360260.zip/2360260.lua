-- Lua provided by RyzenAPI
-- Game: Game: Hot Therapy

-- MAIN APPLICATION
addappid(2360260)
-- Game: addappid(2360260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2360261, 1, "6661a73577ff2d3e8f46e0771eb52e77f8a334b21916d9d2445138b2a6169f79")
