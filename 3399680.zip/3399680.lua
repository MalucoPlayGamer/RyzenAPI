-- Generated with Luie @ https://lua.tools/
-- 3399680 - Cooking Clash
-- Generated 2026-08-21 20:04:24 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(3399680)

-- Main Depots
addappid(3399681, 1, "1347554e57ffaff846110770857223f5a1358f24e9e80203dae7576fe504961c")
setManifestid(3399681, "1850058944233688990", 1885492777)
