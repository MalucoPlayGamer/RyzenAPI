-- Lua provided by RyzenAPI
-- Game: Fisti-Fluffs

-- MAIN APPLICATION
addappid(1407080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407081, 1, "9769abbae02783b449a3dd6e5c6fb7b76fa5792d94f4a08f0ed68cd5ca56ee71")

