-- Lua provided by RyzenAPI
-- Game: Fisti-Fluffs

-- MAIN APPLICATION
addappid(1407080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407081, 1, "9769abbae02783b449a3dd6e5c6fb7b76fa5792d94f4a08f0ed68cd5ca56ee71")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
