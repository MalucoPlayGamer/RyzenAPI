-- Lua provided by RyzenAPI
-- Game: Robots Attack On Vapeland

-- MAIN APPLICATION
addappid(829750)

-- MAIN APP DEPOTS / PACKAGES
addappid(829751, 1, "2ba28963d4240cdaa0c32d2684a1e1657db1c0602844682eb65b0ccf4dccf6d7")
addappid(831760, 0, "8c30f1c9ab3174a10a39e3207c7eabf697e27ba4b2b1014b986427c5a75b2cad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
