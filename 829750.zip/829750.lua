-- Lua provided by RyzenAPI
-- Game: Robots Attack On Vapeland

-- MAIN APPLICATION
addappid(829750)

-- MAIN APP DEPOTS / PACKAGES
addappid(829751, 1, "2ba28963d4240cdaa0c32d2684a1e1657db1c0602844682eb65b0ccf4dccf6d7")
addappid(831760, 0, "8c30f1c9ab3174a10a39e3207c7eabf697e27ba4b2b1014b986427c5a75b2cad")

