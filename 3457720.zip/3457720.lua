-- 3457720's Lua and Manifest Created by Hubcap Manifest
-- Incremental Orbits
-- Created: August 24, 2026 at 13:19:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3457720) -- Incremental Orbits
-- MAIN APP DEPOTS
addappid(3457722, 1, "260ec0ff16a3f5721164ced0de1eab77db72b2a015ff627930cb31e7c51b9c45") -- Depot 3457722
setManifestid(3457722, "5322247273803565459", 30598329)