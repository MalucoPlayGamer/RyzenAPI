-- Lua provided by RyzenAPI
-- Game: 520190

-- MAIN APPLICATION
addappid(520190)
-- Game: addappid(520190)

-- MAIN APP DEPOTS / PACKAGES
addappid(520191, 1, "6f20b73c670a644c2adec8ce9c2ba4d8fd42960537d0256bfadabc87ab21ec3d")
