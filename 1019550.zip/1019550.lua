-- Lua provided by RyzenAPI
-- Game: addappid(1019550)

-- MAIN APPLICATION
addappid(1019550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019552,0,"004820f91ba3af95a97c6fcd8fc3ebe9727bb297b337f4e03c754ffb248cb2fe")
