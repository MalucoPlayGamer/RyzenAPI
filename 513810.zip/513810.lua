-- Lua provided by RyzenAPI
-- Game: Arkham Nightmares

-- MAIN APPLICATION
addappid(513810)

-- MAIN APP DEPOTS / PACKAGES
addappid(513813,0,"4e6a7e2f35d7aaa18eb62f96dc372685bf1e12510a6da1280f18cd94b336f370")

