-- Lua provided by RyzenAPI
-- Game: Aqua Moto Racing Utopia

-- MAIN APPLICATION
addappid(468100)

-- MAIN APP DEPOTS / PACKAGES
addappid(468101, 1, "bdeb5d33cd5df11889d1459da0d7ce609025680160e12ae8c7ffbefef8954acb")
addappid(468102, 1, "a3f0773a23e82a3ab33047441ceceef46afae2bdb3773f9e63ae2f1b1c718194")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
