-- Lua provided by RyzenAPI
-- Game: addappid(570940)

-- MAIN APPLICATION
addappid(570940)

-- MAIN APP DEPOTS / PACKAGES
addappid(570941, 1, "e782efcd07a6c765e4393f9b7b6285c09819e62da5f1573e40f15b98303799fe")
addappid(570942, 1, "74947c74eb866acac60dc108e9c8144e499da81f312f965cfe46ef6c280afaef")
addappid(570943, 1, "b789ea361d9a3e2ff6beb324f2a264fa8db3a49e9ccf390e88332f3850ce5735")
