-- Lua provided by RyzenAPI
-- Game: The Maiden, the Butler, and the Witch

-- MAIN APPLICATION
addappid(1342080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342081, 1, "3e1c34be016a5feca5b0cff31e314f7c590537779e57956fd3960f827302e3c6")
addappid(1342082, 1, "f768b3bcbd9a44866e22707efba567dae4a8b7f8e7539b57221f3e58008e0d4a")
addappid(1342083, 1, "b3859cd1b67499bbeec8d689dcd64dba4456f1cdcdd1ed14e38e4b97d5b021a2")
