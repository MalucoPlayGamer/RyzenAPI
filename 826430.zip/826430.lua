-- Lua provided by RyzenAPI
-- Game: 826430

-- MAIN APPLICATION
addappid(826430)
-- Game: addappid(826430)

-- MAIN APP DEPOTS / PACKAGES
addappid(826431, 1, "9dae9ead16fafda3427dd8257edf5d2ae3eb5bab8593464282c365678c3fbd45")
