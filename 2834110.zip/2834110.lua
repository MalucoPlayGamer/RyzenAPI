-- Lua provided by RyzenAPI
-- Game: 2834110

-- MAIN APPLICATION
addappid(2834110)
addappid(4118750)
-- Game: addappid(2834110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2834111, 1, "258c4da5e233260ba416e1826a8fd97a3883686ed1be94dbf014f343be4932bf")
