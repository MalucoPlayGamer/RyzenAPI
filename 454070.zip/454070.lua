-- Lua provided by RyzenAPI
-- Game: Boundel: The Second Era

-- MAIN APPLICATION
addappid(454070)
addappid(577100)

-- MAIN APP DEPOTS / PACKAGES
addappid(454071, 1, "561a193be4e1102d1c54a11cad882d5e8be4007c7fde21a8847eca350a5a28d9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
