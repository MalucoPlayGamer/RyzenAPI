-- Lua provided by RyzenAPI
-- Game: addappid(454070)

-- MAIN APPLICATION
addappid(454070)
addappid(577100)

-- MAIN APP DEPOTS / PACKAGES
addappid(454071, 1, "561a193be4e1102d1c54a11cad882d5e8be4007c7fde21a8847eca350a5a28d9")
