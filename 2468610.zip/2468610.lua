-- Lua provided by SkyAPI 
-- Game: The Night Shift
addappid(2468610)
addappid(2468611, 1, "d12d39c3e06e346270c9c9ffe7ca2ee439e19183d96ecf49ca32af53efb2899e")
addappid(3601920)
