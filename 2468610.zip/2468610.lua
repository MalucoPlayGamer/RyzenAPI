-- Lua provided by RyzenAPI
-- Game: The Night Shift

-- MAIN APPLICATION
addappid(2468610)
addappid(3601920)
-- Game: addappid(2468610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2468611, 1, "d12d39c3e06e346270c9c9ffe7ca2ee439e19183d96ecf49ca32af53efb2899e")
