-- Lua provided by RyzenAPI
-- Game: addappid(2243250)

-- MAIN APPLICATION
addappid(2243250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2243251, 1, "1e86a12c634dfe0c556616eab99cb094e013f7e96749756251a4a8c87edb0b9f")
