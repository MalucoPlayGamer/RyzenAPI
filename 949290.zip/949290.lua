-- Lua provided by RyzenAPI
-- Game: Winkeltje: The Little Shop

-- MAIN APPLICATION
addappid(949290)
addappid(2187680)

-- MAIN APP DEPOTS / PACKAGES
addappid(949292,0,"be0408e63eb589301712518ee69999fcfac35fb69f9ec88e31795221c12bc47c")

