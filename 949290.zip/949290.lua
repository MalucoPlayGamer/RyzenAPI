-- Lua provided by RyzenAPI
-- Game: addappid(949290)

-- MAIN APPLICATION
addappid(949290)
addappid(949291)
addappid(949293)

-- MAIN APP DEPOTS / PACKAGES
addappid(949292,0,"be0408e63eb589301712518ee69999fcfac35fb69f9ec88e31795221c12bc47c")
