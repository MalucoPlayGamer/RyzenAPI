-- Lua provided by RyzenAPI
-- Game: Solar Ash - Original Soundtrack

-- MAIN APPLICATION
addappid(2237530)
-- Game: addappid(2237530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2237531, 1, "68779eeba7c7ad0436fa1848e81626787c1187b5d7e4d1f6220bf53c58229c63")
addappid(2237532, 1, "bcac502bc1107864edc55ebe42c5d8e871b1d378e61dad4a5ba7c142faba4e99")
