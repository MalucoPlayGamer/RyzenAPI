-- Lua provided by RyzenAPI
-- Game: CASTILLO: Shattered Mirrors

-- MAIN APPLICATION
addappid(1870970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1870971, 1, "424bbab6e11d3a29bf19eed4390eacb8ba529b5919dea7211479b2de71bc77e3")

