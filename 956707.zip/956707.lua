-- Lua provided by RyzenAPI
-- Game: 956707

-- MAIN APPLICATION
addappid(956707)

-- MAIN APP DEPOTS / PACKAGES
addappid(956707,0,"f30902f9fd904bf59c257b054c35970a56ebda0cb98a7702e8a5baff2bc8630b")
