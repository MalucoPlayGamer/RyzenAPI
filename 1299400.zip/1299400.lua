-- Lua provided by RyzenAPI
-- Game: Understand

-- MAIN APPLICATION
addappid(1299400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299401, 1, "812e456978292cf61a11eeb88c185982841c651bac4ca86115a3e3787a74dfb1")
