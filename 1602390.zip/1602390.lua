-- Lua provided by RyzenAPI
-- Game: AppID 1602390

-- MAIN APPLICATION
addappid(1602390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602391, 1, "c1c87b51f3d08c3f79e23c7844af07a3a5740e1c99e0ffa2fb831d2cd9b1158c")
