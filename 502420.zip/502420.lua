-- Lua provided by SkyAPI 
-- Game: AppID 502420
addappid(502420)
addappid(502421, 1, "a2cfb336c684b7f70502438fc6afd3357d5377fd084a77ad0ac1e3f626559ae0")
