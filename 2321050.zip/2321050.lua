-- Lua provided by RyzenAPI
-- Game: Bangkok Story: A Stray Dog Demo

-- MAIN APPLICATION
addappid(2321050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321051, 1, "aab366b356dafed42f1e5056ee1dfd9a0860911f62d3da1172dd1f4911e6d1d2")

