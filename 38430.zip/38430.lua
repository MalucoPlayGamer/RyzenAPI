-- Lua provided by RyzenAPI
-- Game: Game: AppID 38430

-- MAIN APPLICATION
addappid(38430)
-- Game: addappid(38430)

-- MAIN APP DEPOTS / PACKAGES
addappid(38431, 1, "060fd8971db387bb172010aa7e85249cb00654d7b18bbe04495632f87cd54a3c")
