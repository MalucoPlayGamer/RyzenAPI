-- Lua provided by RyzenAPI
-- Game: AppID 776790

-- MAIN APPLICATION
addappid(776790)
-- Game: addappid(776790)

-- MAIN APP DEPOTS / PACKAGES
addappid(776791, 1, "9577e71265b87e9e6faa6d883350cf1cabd45f5ec8eb934caff0d9105c9df06c")
