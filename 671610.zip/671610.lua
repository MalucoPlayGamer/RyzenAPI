-- Lua provided by RyzenAPI
-- Game: Warfork

-- MAIN APPLICATION
addappid(671610)

-- MAIN APP DEPOTS / PACKAGES
addappid(671612,0,"e760c9ff7854dcaecd9ea6db7b1ce50b7caad48608c02040d8e5bdbb9ae97669")
addappid(671615,0,"0a63804ed28018315efd284efc0dea218280e3c2cbce58b6fb0adaa9bd1ace53")
addappid(671617,0,"d0bacd4729547307ea80d108e1e7c18cf091d8cfff099787a6d731976b228eee")
addappid(671618,0,"112f9eb86df45e5dc0038c3b0a97cd1d71d94b5d0441bd7ab5251b0f51cf5b18")
