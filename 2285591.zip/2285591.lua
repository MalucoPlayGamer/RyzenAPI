-- Lua provided by RyzenAPI
-- Game: addappid(2285591)

-- MAIN APPLICATION
addappid(2285591)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285591,0,"a236d6daefe296fd050be090384dda6651c1977693db554da0d03c653516f634")
