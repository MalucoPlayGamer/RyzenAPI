-- Lua provided by RyzenAPI
-- Game: Deducto 2

-- MAIN APPLICATION
addappid(2119590)
-- Game: addappid(2119590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2119591, 1, "d4f2257320ebf7a6bc91dda832303da045c08f731817549ae718a6174206897a")
