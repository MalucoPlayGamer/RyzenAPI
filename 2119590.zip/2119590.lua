-- Lua provided by SkyAPI 
-- Game: Deducto 2
addappid(2119590)
addappid(2119591, 1, "d4f2257320ebf7a6bc91dda832303da045c08f731817549ae718a6174206897a")
