-- Lua provided by RyzenAPI
-- Game: Scott in Space

-- MAIN APPLICATION
addappid(385980)
-- Game: addappid(385980)

-- MAIN APP DEPOTS / PACKAGES
addappid(385981, 1, "1bbc81bd1ace9e0cb1efddf9c2fd3af5ac12b245cb6d1b674913d4d2b6445447")
