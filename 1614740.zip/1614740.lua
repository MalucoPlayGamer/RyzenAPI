-- Lua provided by RyzenAPI
-- Game: 1614740

-- MAIN APPLICATION
addappid(1614740)
addappid(1639820)
-- Game: addappid(1614740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1614741, 1, "35f041c0ad0c6ea4f25e5a8801be6b7697e5e5a283b732330350b1554260d2a8")
