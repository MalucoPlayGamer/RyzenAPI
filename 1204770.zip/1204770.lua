-- Lua provided by RyzenAPI 
-- Game: AppID 1204770
addappid(1204770)
addappid(1204771, 1, "f714ea4318c7d1ae3bc1543000a55b0841e0be0d8003333341d120f28f547eb7")
