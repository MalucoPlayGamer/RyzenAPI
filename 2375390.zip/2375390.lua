-- Lua provided by RyzenAPI
-- Game: Chef: Cocktails & Drinks

-- MAIN APPLICATION
addappid(2375390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375391, 1, "fc85f37c868ce55d912137f78c7f45227e34180b9aa6fe450970a80e4e646519")
