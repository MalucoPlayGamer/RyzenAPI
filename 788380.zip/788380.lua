-- Lua provided by RyzenAPI 
-- Game: AppID 788380
addappid(788380)
addappid(788381, 1, "0de770a8686509f179b2cd27de0f571bd9963488e34b47c9e0c8eb570735bbc7")
addappid(788382, 1, "1fd2dfa3c9d1af05a23b49b631ccc8ada4f2099cd266cfcf2ef40b427f994f19")
addappid(788383, 1, "bd68038bf962d59619c22c607695a31cf6d7926785ca5c31fbbcdc5e4d10bf1d")
