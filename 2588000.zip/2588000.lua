-- Lua provided by RyzenAPI
-- Game: Silent Rain Demo

-- MAIN APPLICATION
addappid(2588000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2588001, 1, "9f7b06032bf9eb78b10d4e9bfe7bc8b0d5bfa283f66ba15b9f5ce6f37b1079c0")
