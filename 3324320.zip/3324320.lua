-- Lua provided by RyzenAPI
-- Game: MYRIAD DEATH

-- MAIN APPLICATION
addappid(3324320)
-- Game: addappid(3324320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3324321, 1, "cfbdf185084ae680275be4d0cd9564c374e24ffd24702d9cfad44063f18a5705")
