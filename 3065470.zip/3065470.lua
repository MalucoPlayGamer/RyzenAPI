-- Lua provided by RyzenAPI 
-- Game: AppID 3065470
addappid(3065470)
addappid(3065471, 1, "e1bf7ddfb698fba3c5dba73168097d394187da77fe0f9a9b44cf79ed78b42906")
