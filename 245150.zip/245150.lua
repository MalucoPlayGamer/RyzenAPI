-- Lua provided by RyzenAPI
-- Game: The Novelist

-- MAIN APPLICATION
addappid(245150)
-- Game: addappid(245150)

-- MAIN APP DEPOTS / PACKAGES
addappid(245151, 1, "6b42200d09d0bf3351f2c41d18f7463ddadf36b468c916d48472d334adfcb8df")
addappid(245152, 1, "4d1c4e0f3d2db439f2694e987158b694af0ee0d139440f585da0b4f853c1369f")
addappid(245153, 1, "bf3b32f155b123835ae46e780f9e725e3d118f34ca8d9062c028a3d91c5fc525")
