-- Lua provided by RyzenAPI
-- Game: Little Traveler

-- MAIN APPLICATION
addappid(1588460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1588461, 1, "7e9332695354e57436d7ea81dad9ee5d006515563eaeb73b22f5294c661a7785")

