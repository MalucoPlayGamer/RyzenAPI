-- Lua provided by RyzenAPI
-- Game: Little Traveler

-- MAIN APPLICATION
addappid(1588460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588461, 1, "7e9332695354e57436d7ea81dad9ee5d006515563eaeb73b22f5294c661a7785")

