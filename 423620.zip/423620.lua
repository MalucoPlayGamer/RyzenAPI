-- Lua provided by RyzenAPI
-- Game: Game: HERO DEFENSE

-- MAIN APPLICATION
addappid(423620)
-- Game: addappid(423620)

-- MAIN APP DEPOTS / PACKAGES
addappid(423621, 1, "bc0ad118c86a23f43eb2d6924654f305f54ba21909ae73af02c21b7f3ff6691c")
