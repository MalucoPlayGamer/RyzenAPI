-- Lua provided by RyzenAPI
-- Game: HERO DEFENSE

-- MAIN APPLICATION
addappid(423620)

-- MAIN APP DEPOTS / PACKAGES
addappid(423621, 1, "bc0ad118c86a23f43eb2d6924654f305f54ba21909ae73af02c21b7f3ff6691c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
