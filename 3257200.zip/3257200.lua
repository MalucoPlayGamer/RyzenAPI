-- Lua provided by RyzenAPI 
-- Game: Emberwake Demo
addappid(3257200)
addappid(3257201, 1, "7bb1b03fbdd3c6d8b142f7c725b17a7e5fd019e6c7e943beb9c60fb929ec6da3")
