-- Lua provided by RyzenAPI
-- Game: 917990

-- MAIN APPLICATION
addappid(917990)
-- Game: addappid(917990)

-- MAIN APP DEPOTS / PACKAGES
addappid(917991, 1, "c32fd43105f8ad1e285b1f7cce1243220c06823ebe7f5a5e68cdd49527796b23")
