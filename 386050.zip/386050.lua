-- Lua provided by RyzenAPI
-- Game: Proto Raider

-- MAIN APPLICATION
addappid(386050)

-- MAIN APP DEPOTS / PACKAGES
addappid(386051, 1, "108260c1e9132e83a23d82cb4c60a795dd5e22314f50108949744d02b9fbb102")

