-- Lua provided by RyzenAPI
-- Game: Game: AppID 848540

-- MAIN APPLICATION
addappid(848540)
-- Game: addappid(848540)

-- MAIN APP DEPOTS / PACKAGES
addappid(848541, 1, "fc066c1279f5f2f6d7a2a42756787e47aa1bbf7dda815512fa098a3b98e8150d")
