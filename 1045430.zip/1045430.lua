-- Lua provided by RyzenAPI
-- Game: Circadian City

-- MAIN APPLICATION
addappid(1045430)
-- Game: addappid(1045430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045431, 1, "4bd8506e8ce1edc9fb77abb3316c0e663897c3adc5f6228e6e9668d69a722c04")
