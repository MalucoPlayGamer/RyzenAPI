-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1659350)
-- Game: addappid(1659350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1659350,0,"39ff6c75019896422b3af44413039293b927b2b6e567e46c5b3804012748a40d")
