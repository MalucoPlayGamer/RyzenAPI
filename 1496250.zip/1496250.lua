-- Lua provided by RyzenAPI
-- Game: Mary Skelter 2

-- MAIN APPLICATION
addappid(1496250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1496251, 1, "d64734489ac73e5a091462c0523367523666507f4fd7adcdef7590aa97fe1f41")
