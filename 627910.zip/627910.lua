-- Lua provided by RyzenAPI
-- Game: Bubsy: The Woolies Strike Back

-- MAIN APPLICATION
addappid(627910)
-- Game: addappid(627910)

-- MAIN APP DEPOTS / PACKAGES
addappid(627911, 1, "396dc533d3360e51954bd4f02db6e059336db869da8aa443c5ab3586c18bf981")
addappid(735480, 0, "721eaefc9c22dec74977ac18b6cc8179edad845edfe3ae35a4d4c43c45c4e4d0")
