-- Lua provided by RyzenAPI
-- Game: Bubsy: The Woolies Strike Back

-- MAIN APPLICATION
addappid(627910)

-- MAIN APP DEPOTS / PACKAGES
addappid(627911, 1, "396dc533d3360e51954bd4f02db6e059336db869da8aa443c5ab3586c18bf981")
addappid(735480, 0, "721eaefc9c22dec74977ac18b6cc8179edad845edfe3ae35a4d4c43c45c4e4d0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
