-- Lua provided by RyzenAPI
-- Game: addappid(1719680)

-- MAIN APPLICATION
addappid(1719680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719681, 1, "8137fa8dc4dae516e41e84df4e7b2c8f6980cc69196618be39c203f568847d34")
