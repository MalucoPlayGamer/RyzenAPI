-- Lua provided by RyzenAPI
-- Game: addappid(3422130)

-- MAIN APPLICATION
addappid(3422130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3422131, 1, "282f90266a3442c1cf0e120d591da20cae5b0bad7888986108b4de7e1d041e65")
