-- Lua provided by RyzenAPI
-- Game: Gun Master

-- MAIN APPLICATION
addappid(1308660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1308661, 1, "aff8e577cc0622eec40668ad7062edf37ada622900879425d0105b9f58378620")
