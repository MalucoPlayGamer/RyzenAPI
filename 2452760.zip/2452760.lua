-- Lua provided by RyzenAPI
-- Game: TV Head: Eight Pages

-- MAIN APPLICATION
addappid(2452760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452761, 1, "f38b19ed74a2bb50a9fd7e121d8a3ca9385ca05cc51c792bc2b93234db132337")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
