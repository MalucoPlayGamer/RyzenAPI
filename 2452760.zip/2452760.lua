-- Lua provided by RyzenAPI
-- Game: Game: TV Head: Eight Pages

-- MAIN APPLICATION
addappid(2452760)
-- Game: addappid(2452760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452761, 1, "f38b19ed74a2bb50a9fd7e121d8a3ca9385ca05cc51c792bc2b93234db132337")
