-- Lua provided by RyzenAPI
-- Game: Fantasy Heroes 4D / Character Maker

-- MAIN APPLICATION
addappid(1741230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1741231, 1, "44fb644ed94e6022e6d322af00b7db5aef0c19010a0c55684193516948fd4416")
