-- Lua provided by RyzenAPI
-- Game: Soccer Manager Arena

-- MAIN APPLICATION
addappid(628870)

-- MAIN APP DEPOTS / PACKAGES
addappid(628871, 1, "068f1759220de858a9bbc4c39e7adcb5e89fd0703e8af1cfa7ffd09316c44d51")
