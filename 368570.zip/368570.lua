-- Lua provided by RyzenAPI
-- Game: AppID 368570

-- MAIN APPLICATION
addappid(368570)

-- MAIN APP DEPOTS / PACKAGES
addappid(368571, 1, "6fe0e655abbf8dec66878967bee3a2ad440d90e44f9baded77b7238d3adf70f8")

