-- Lua provided by RyzenAPI
-- Game: DockBar

-- MAIN APPLICATION
addappid(4431900)

-- MAIN APP DEPOTS / PACKAGES
addappid(4431901,0,"d026a6ff5a3406ada5f7c843d6193feb7f116e41fc5a515f64979b53273e9495")

