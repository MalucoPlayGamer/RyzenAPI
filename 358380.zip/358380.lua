-- Lua provided by RyzenAPI
-- Game: Wacky Wheels

-- MAIN APPLICATION
addappid(358380)

-- MAIN APP DEPOTS / PACKAGES
addappid(358282, 1, "49873ef710660ffb93d7973c089903c68cbb18468ead06151a6a6d658e6a2070") -- (windows)
addappid(358381, 1, "d43834d5e6cf4b82226135fc3a59134f3df2c7f5cbe3e2c73c6e91f19ccc4862")
addappid(358382, 1, "0827e7abc7afa53010041626e5d28d68120faa23e8f2fbd8fd637cff4ce6f454")
