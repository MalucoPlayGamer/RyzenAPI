-- Lua provided by RyzenAPI
-- Game: AppID 358380

-- MAIN APPLICATION
addappid(358380)

-- MAIN APP DEPOTS / PACKAGES
addappid(358381, 1, "d43834d5e6cf4b82226135fc3a59134f3df2c7f5cbe3e2c73c6e91f19ccc4862")
addappid(358382, 1, "0827e7abc7afa53010041626e5d28d68120faa23e8f2fbd8fd637cff4ce6f454")

