-- Lua provided by RyzenAPI
-- Game: Adventurezator: When Pigs Fly

-- MAIN APPLICATION
addappid(300280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(300290,0,"d03f17d5029776fb196efcfd8a6d3fd37f5cdce6f747e8169f3d43df6882dfd5")
addappid(300291,0,"2ea9347459339ef7a15d4ab42dc2ccd2d1cdabe2daf099139f929bf588a7a8d3")
addappid(300292,0,"a459e69644c356a236c42e7ba366d930145ab107424ae36a4e50fb0108bd59ec")

