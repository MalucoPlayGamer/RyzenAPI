-- Lua provided by RyzenAPI
-- Game: AppID 1782680

-- MAIN APPLICATION
addappid(1782680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1782681, 1, "e00539f1fd0f1025f153084b1bd68636f7682b21956832773ad3be2fe7a429ed")

