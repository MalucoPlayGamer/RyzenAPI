-- Lua provided by RyzenAPI
-- Game: addappid(3133040)

-- MAIN APPLICATION
addappid(3133040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3133041, 1, "37e5eaf3a4a72dddb720454ca44f7303b605ba6b5ebcfb994bba580a52b722b3")
