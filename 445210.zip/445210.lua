-- Lua provided by RyzenAPI
-- Game: addappid(445210)

-- MAIN APPLICATION
addappid(445210)

-- MAIN APP DEPOTS / PACKAGES
addappid(445211, 1, "8ff2400948b13b6ed2b8fcfffa665b4931e85a18ccd528e6a8a02196b5795b99")
