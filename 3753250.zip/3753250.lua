-- Lua provided by RyzenAPI
-- Game: addappid(3753250)

-- MAIN APPLICATION
addappid(3753250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3753251, 1, "33a7c57d0f9a0d43b3b892a676316ad864f990e25de8e1e9a602c8f6b11c9842")
