-- Lua provided by RyzenAPI
-- Game: Game: AppID 836440

-- MAIN APPLICATION
addappid(836440)
-- Game: addappid(836440)

-- MAIN APP DEPOTS / PACKAGES
addappid(836441, 1, "8ce5d4301e22ce09757a471658e0d89b3571e1b3d11fee14a6e55d805720e78e")
addappid(836442, 1, "8e085836db864a9bfbb005d893117b5658dc00928aa9ea67c0d0d2cf1278b9b6")
addappid(836443, 1, "573c0458d7eb3acbdda5d1b8786ef5e1203cf6e1f3973898b72bafa079b8dad9")
