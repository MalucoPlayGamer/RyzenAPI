-- Lua provided by RyzenAPI
-- Game: Mayan Prophecies: Blood Moon Collector's Edition

-- MAIN APPLICATION
addappid(805020)

-- MAIN APP DEPOTS / PACKAGES
addappid(805021,0,"84545f5f5a6e40bd3cef5584b7eaf8d6d638a5146870638b09f32b56c7d0426e")

