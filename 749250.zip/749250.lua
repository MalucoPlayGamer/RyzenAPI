-- Lua provided by RyzenAPI
-- Game: 7th Sector

-- MAIN APPLICATION
addappid(749250)

-- MAIN APP DEPOTS / PACKAGES
addappid(749251, 1, "82157d9a03a3b292ce170e454f465f21720cd371013605a33475975123f80ae0")
addappid(1063400, 0, "a885f1d439069864bea4c5a73331aab6a04fa65b7fad48b69458ad3955e076aa")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1060120)
