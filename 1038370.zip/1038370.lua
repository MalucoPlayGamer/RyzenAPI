-- Lua provided by RyzenAPI
-- Game: AppID 1038370

-- MAIN APPLICATION
addappid(1038370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1038371, 1, "785a7a959bc9170a3750fb05f21c128d937cc9b7dc4e0b15b90a6561e40f0cf4")
addappid(1038372, 1, "cc3f76e6e6a3742b0e695147c02b755026b20e2441538b27f90c76142b2a4c7a")
addappid(1038373, 1, "5b91b5cca7632fb083388fc5f53525f9658983467966571d5e19e704726152d8")
addappid(1594260, 0, "ec08c9d96eb6d7592c9312cd47d0ff4012bc14edcf69a4b3dfdf8b759327b1ce")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
