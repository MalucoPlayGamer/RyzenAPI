-- Lua provided by RyzenAPI
-- Game: 2310130

-- MAIN APPLICATION
addappid(2310130)
-- Game: addappid(2310130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310131, 1, "ac6ca3119c8ec56a41117c100a950612b8e2e9d5db4b95f4563180dea21188fd")
