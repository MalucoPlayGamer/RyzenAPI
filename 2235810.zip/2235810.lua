-- Lua provided by RyzenAPI
-- Game: 异世界的雪与奇迹

-- MAIN APPLICATION
addappid(2235810)
addappid(3045710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235811, 1, "3e4b024051cc7ceb8c71e555562a051bd6fb0ee924cb04d948a7b0094c3ec8d4")

