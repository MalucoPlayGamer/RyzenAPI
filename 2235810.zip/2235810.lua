-- Lua provided by SkyAPI 
-- Game: AppID 2235810
addappid(2235810)
addappid(2235811, 1, "3e4b024051cc7ceb8c71e555562a051bd6fb0ee924cb04d948a7b0094c3ec8d4")
