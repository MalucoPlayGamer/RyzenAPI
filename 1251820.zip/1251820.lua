-- Lua provided by RyzenAPI
-- Game: OshiRabu: Waifus Over Husbandos Demo

-- MAIN APPLICATION
addappid(1251820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1251821, 1, "aaef2efafd58b554882973bf0f4c86d042e5478801a2125e80c036962cfab4f2")
