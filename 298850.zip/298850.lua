-- Lua provided by RyzenAPI
-- Game: Millennium 5 - The Battle of the Millennium

-- MAIN APPLICATION
addappid(298850)
addappid(357100)
addappid(372270)

-- MAIN APP DEPOTS / PACKAGES
addappid(298851, 1, "ef934a44ced4e63daa76d9d05df427e3423bcae349b1823dcda211935697847b")
