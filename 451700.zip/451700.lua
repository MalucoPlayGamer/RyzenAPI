-- Lua provided by RyzenAPI
-- Game: Secrets of Deep Earth Shrine

-- MAIN APPLICATION
addappid(451700)
-- Game: addappid(451700)

-- MAIN APP DEPOTS / PACKAGES
addappid(451701, 1, "a5cd7b1971e4e4cfaed81a22b34ad24f67d831705fcf9ab01afd54d31115a297")
addappid(451702, 1, "068a767379aaf1e24c52921a643a1cab22fd854e0cfbbd1b9a48b4811586ab76")
