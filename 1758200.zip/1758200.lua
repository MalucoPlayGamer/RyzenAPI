-- Lua provided by RyzenAPI
-- Game: 1758200

-- MAIN APPLICATION
addappid(1758200)
-- Game: addappid(1758200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758201, 1, "0810fd541000fd63dffdb167dfa250bb13d9c4d348dd11b4c7d7d9d22513101e")
