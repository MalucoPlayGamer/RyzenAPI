-- Lua provided by RyzenAPI
-- Game: ITRP _ Gas Prison

-- MAIN APPLICATION
addappid(1758200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758201, 1, "0810fd541000fd63dffdb167dfa250bb13d9c4d348dd11b4c7d7d9d22513101e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
