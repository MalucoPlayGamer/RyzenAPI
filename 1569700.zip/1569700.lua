-- Lua provided by RyzenAPI
-- Game: addappid(1569700)

-- MAIN APPLICATION
addappid(1569700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569701, 1, "028ae3240e2ecfd3261dcc70029c8164c6e6611973aea6aa0b93b6b10f94f8f6")
