-- Lua provided by RyzenAPI
-- Game: CARNAGE OFFERING Tower Defense

-- MAIN APPLICATION
addappid(2298300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2298301, 1, "7a8e1286d9e0bdd60cbbc7b40a6570c03be11883f64dfe050742eb2146a083ec")

