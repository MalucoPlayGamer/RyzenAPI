-- Lua provided by RyzenAPI
-- Game: 3462210

-- MAIN APPLICATION
addappid(3462210)
-- Game: addappid(3462210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3462211, 1, "a9de09a3ca658b1206cafb3048f91bc45c72185014ee699c0e6ecd87735fb710")
