-- Lua provided by RyzenAPI 
-- Game: AppID 3462210
addappid(3462210)
addappid(3462211, 1, "a9de09a3ca658b1206cafb3048f91bc45c72185014ee699c0e6ecd87735fb710")
