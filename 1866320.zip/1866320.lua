-- Lua provided by RyzenAPI
-- Game: Baladins

-- MAIN APPLICATION
addappid(1866320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866321, 1, "5025947bb99acf50860df7655820bc86ffbbf7fe10c7b83189fccf9c8aaf801d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3076230)
