-- Lua provided by RyzenAPI
-- Game: addappid(564940)

-- MAIN APPLICATION
addappid(564940)

-- MAIN APP DEPOTS / PACKAGES
addappid(564941, 1, "90708a217375d49a3d8b356e50d3a4cc692e36346f6fb6ad6783de11cc5e88f9")
