-- Lua provided by RyzenAPI
-- Game: Quake II Demo

-- MAIN APPLICATION
addappid(9130)

-- MAIN APP DEPOTS / PACKAGES
addappid(9131, 1, "152828d091a364862a4feb12630d72b25f3a63ce4083f71687e838100d9e1b33")

