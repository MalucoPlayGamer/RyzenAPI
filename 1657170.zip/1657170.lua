-- Lua provided by RyzenAPI
-- Game: addappid(1657170)

-- MAIN APPLICATION
addappid(1657170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1657171, 1, "030ba35999ece9b62a23acf872a17b9b0b640ee53338fcb3e9c0ed5448f6e0dc")
