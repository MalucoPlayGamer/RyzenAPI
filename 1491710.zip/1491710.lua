-- Lua provided by SkyAPI 
-- Game: CRIMESIGHT
addappid(1491710)
addappid(1491711, 1, "ec51700578fb2395a1043f87474771f22e26649cb17191aac94d806045a83cdd")
