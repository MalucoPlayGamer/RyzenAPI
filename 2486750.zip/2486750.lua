-- Lua provided by RyzenAPI 
-- Game: Beecarbonize
addappid(2486750)
addappid(2486751, 1, "d7a50086724472d8a6d66e2bec8a2227d22cb4becb41e72d85c940d30daee762")
addappid(2486752, 1, "20c43b1f3e0f405e4570c2ee53045e854cacd813f44cd6bb8a6edc5337a9098a")
