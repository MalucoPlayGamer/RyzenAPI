-- Lua provided by RyzenAPI
-- Game: Blake Stone: Planet Strike

-- MAIN APPLICATION
addappid(358310)

-- MAIN APP DEPOTS / PACKAGES
addappid(358311, 1, "0ddf0dbe69e7578dd3fb08532b7ce3f49586e9d5031c393526dfb69400df85d2")
addappid(358312, 1, "e44d5cec3d72eaac46f117ec5ad31ffa3e65ffd1c2889246c3cb3a28b2b99572")

