-- Lua provided by RyzenAPI
-- Game: addappid(1378080)

-- MAIN APPLICATION
addappid(1378080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378081, 1, "193a905e272eb0c0e70ff9925ee4bdde7b580e7921dda5745b9bcc3ba8325c8f")
