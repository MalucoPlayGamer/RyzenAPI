-- Lua provided by RyzenAPI
-- Game: AppID 957590

-- MAIN APPLICATION
addappid(957590)
-- Game: addappid(957590)

-- MAIN APP DEPOTS / PACKAGES
addappid(957591, 1, "46f69ac00b9d45b5cf1debb3264fd0fd439a2012c4b6c6c4f11bf75a965acd66")
addappid(957592, 1, "3b8b06ad2e52c3f6efef9fd2dc23e046800c66b72ff2b799382c90eb7119c120")
addappid(957593, 1, "efe9774bdea6c18db9ca8213f1f93899fec550c9000fcbda36074c6560ad57e7")
addappid(957594, 1, "ee132ff9d94e6069d6b264b611f4c4446d1b74246a1ed56a64f41f85ed2ef2be")
