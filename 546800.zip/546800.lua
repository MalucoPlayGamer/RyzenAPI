-- Lua provided by RyzenAPI
-- Game: addappid(546800)

-- MAIN APPLICATION
addappid(546800)

-- MAIN APP DEPOTS / PACKAGES
addappid(546801, 1, "ab756be0f9791b986e5e1692da6a890b0e10641f86a2c17af48dc16178c7e737")
