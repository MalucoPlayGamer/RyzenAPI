-- Lua provided by RyzenAPI
-- Game: Bopp File

-- MAIN APPLICATION
addappid(3016610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(3016611, 1, "60937b43e073402885bbb33c7dc6ca59bbf7193d9756c4d5b5e88a0c26a31154")

