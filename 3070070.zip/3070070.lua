-- Lua provided by RyzenAPI
-- Game: Game: TCG Card Shop Simulator

-- MAIN APPLICATION
addappid(3070070)
-- Game: addappid(3070070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3070071, 1, "5c49dfd1ba36d4e81f59ad3a2cd714ec14bdb40ac41848727aca2dc9ed29c748")
