-- Lua provided by RyzenAPI
-- Game: 595340

-- MAIN APPLICATION
addappid(595340)
-- Game: addappid(595340)

-- MAIN APP DEPOTS / PACKAGES
addappid(595341, 1, "5e81b83763785aed9b0e0199e271081eb5e200cedac130fe580b3f84c7b3a5ad")
