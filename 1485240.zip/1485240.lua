-- Lua provided by RyzenAPI
-- Game: 1485240

-- MAIN APPLICATION
addappid(1485240)
-- Game: addappid(1485240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485241, 1, "320aba795deff33277ed7eace01c2f692c15636d2108404bb9b0673e9ecb3de6")
