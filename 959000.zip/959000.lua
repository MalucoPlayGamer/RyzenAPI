-- Lua provided by RyzenAPI
-- Game: 959000

-- MAIN APPLICATION
addappid(959000)
-- Game: addappid(959000)

-- MAIN APP DEPOTS / PACKAGES
addappid(959001, 1, "4d59306ad2be3ac102ca3b970645cb9c337c4a8304153f0bdb460ddb9cce0d6a")
