-- Lua provided by RyzenAPI
-- Game: Edna & Harvey: The Breakout - Anniversary Edition

-- MAIN APPLICATION
addappid(959000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(959001, 1, "4d59306ad2be3ac102ca3b970645cb9c337c4a8304153f0bdb460ddb9cce0d6a")

