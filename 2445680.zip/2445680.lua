-- Lua provided by RyzenAPI
-- Game: addappid(2445680)

-- MAIN APPLICATION
addappid(2445680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2445681, 1, "62e635cab45fdfe607da4c45c506876efd342b57fc91bc4ed7b9db520c20a973")
