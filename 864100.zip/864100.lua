-- Lua provided by RyzenAPI 
-- Game: Sagebrush
addappid(864100)
addappid(864101, 1, "b7c40837ccf4b7a3bb6698faf4153943551e338aa2886cfdd877cf80c292321f")
