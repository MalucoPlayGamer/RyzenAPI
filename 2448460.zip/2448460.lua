-- Lua provided by RyzenAPI
-- Game: Game: SHIMAZU HD: Silent Requiem

-- MAIN APPLICATION
addappid(2448460)
addappid(2453850)
-- Game: addappid(2448460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2448461, 1, "c592fcf3697c0e49102c69208d1e566cac64ddbde8c1e6ca4cd0db90c0d0559c")
