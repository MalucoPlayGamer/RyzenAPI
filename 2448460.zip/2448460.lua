-- Lua provided by RyzenAPI
-- Game: SHIMAZU HD: Silent Requiem

-- MAIN APPLICATION
addappid(2448460)
addappid(2453850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2448461, 1, "c592fcf3697c0e49102c69208d1e566cac64ddbde8c1e6ca4cd0db90c0d0559c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
