-- Lua provided by RyzenAPI
-- Game: Q.U.B.E: Director's Cut

-- MAIN APPLICATION
addappid(239430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- (windows)
addappid(239431, 1, "2ad88d51cb19c74ab18375bdf87894e100bf95b24f1e8374a4c3fcedaacbfd55")
addappid(239432, 1, "2c6ac00823ef170f20d0dafc4b63df8154101306b2b030c11e8f8f3f329f74db")
addappid(239433, 1, "4896a9171e0749745d6b9b43699b5b32dd52e1e7fc7874357a89722949ebc46d")

