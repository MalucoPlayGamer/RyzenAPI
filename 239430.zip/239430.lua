-- Lua provided by RyzenAPI
-- Game: Game: AppID 239430

-- MAIN APPLICATION
addappid(239430)
-- Game: addappid(239430)

-- MAIN APP DEPOTS / PACKAGES
addappid(239431, 1, "2ad88d51cb19c74ab18375bdf87894e100bf95b24f1e8374a4c3fcedaacbfd55")
addappid(239432, 1, "2c6ac00823ef170f20d0dafc4b63df8154101306b2b030c11e8f8f3f329f74db")
addappid(239433, 1, "4896a9171e0749745d6b9b43699b5b32dd52e1e7fc7874357a89722949ebc46d")
