-- Lua provided by RyzenAPI 
-- Game: Capcom Arcade 2nd Stadium: Mini-Album Track 7 - 1943 Kai - Midway Kaisen - Air Battle B
addappid(2087730)
addappid(2087731, 1, "e1afc5c5c2b1c9d646a59f0542947fe8452f6a4147e5feee5c69dbd3742e5da3")
addappid(2087732, 1, "dbe3b2e5bb97e27bf1858268cdcb170f03386ae50f2990f465991a2b588baed2")
addappid(2087733, 1, "21d33efee883db6ef3ddeb2b9208fd3a2f8a7b66787077c95558734e8603982c")
addappid(2087734, 1, "66c57e4d9b998a341045b21eeb23ad3164eed8b510df8b0f4cdf73e0d21458b4")
addappid(2087735, 1, "aebd13d222160ad24c523a5472fa27621fb21705e0e449166aa08cc9aa8b8152")
addappid(2087736, 1, "237734e10653139c6698a69a425f9e22fe5ffdc686581bd57884e0393a998452")
