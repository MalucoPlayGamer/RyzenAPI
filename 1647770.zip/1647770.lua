-- Lua provided by RyzenAPI
-- Game: Ankora: Lost Days

-- MAIN APPLICATION
addappid(1647770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1647771, 1, "e8fe7d76a5703e8d0bbb9154ef82a9b37e4ca439e4200500606468cff6476b2a")
