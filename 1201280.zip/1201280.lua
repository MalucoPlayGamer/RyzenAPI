-- Lua provided by RyzenAPI
-- Game: Game: A Space For The Unbound - Prologue

-- MAIN APPLICATION
addappid(1201280)
-- Game: addappid(1201280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201281, 1, "f7d01d79482a858c8db8897cc2ee8578afc54f52c9629ac8d47483c19daced1d")
addappid(1201282, 1, "dc642ef3313028d9b90b2809a9d1846aa1d42735490c5b41952100d7ce65791a")
