-- 389170's Lua and Manifest Created by Hubcap Manifest
-- Songs for a Hero - Definitive Edition
-- Created: February 01, 2026 at 11:40:39 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 12
-- Total DLCs: 2
-- Shared Depots: 5

-- MAIN APPLICATION
addappid(389170, 1, "cf69fad5394cb48b71e84036716f877588abbe7406a6e13327be7abdc3130cc5") -- Songs for a Hero - Definitive Edition
-- MAIN APP DEPOTS
addappid(389171, 1, "4ee9d4961b9b7a1a42ffbf2d7afaaf0a978a527201106fa3d385f26dfe74b6fc") -- Windows Content
setManifestid(389171, "3849171663715470099", 3295209525)
addappid(389172, 1, "682ef229224e03468068886c6ad0aa0ea451b263eee49bf0ae01511713852acd") -- A Lenda do Herói - O Jogo Depot LINUX
setManifestid(389172, "558437560726499325", 3007266109)
addappid(389173, 1, "3b8aae3273ec48e282308e7e2339860e4be5b7e6d170edd433cea18064311c60") -- MonoGame 3.6 for Mac
setManifestid(389173, "4916034287390799525", 6378340)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)
-- DLCS WITH DEDICATED DEPOTS
-- Songs for a Hero Skin Pack (AppID: 554260)
addappid(554260)
addappid(554260, 1, "0c8db76b67cbeed797eb69ec864bb6336f59ab06d1bb0a8ff5f1dff4f45acb40") -- Songs for a Hero Skin Pack - Skins Pack Youtubers Brasil Depot
setManifestid(554260, "8328274559062710159", 0)
addappid(554261, 1, "582dfd9e949b338591872190cfe53cbaa704b5ec1c36e542d5acdc407045e2fc") -- Songs for a Hero Skin Pack - Skins Pack Youtubers Brasil Depot LINUX
setManifestid(554261, "1436601834961109961", 0)
-- Songs for the Dead (AppID: 729240)
addappid(729240)
addappid(729240, 1, "b70b69d7c9a8d7619c7d3f45ad6c606b18a156e9f651e4abc6b5779bb4978944") -- Songs for the Dead - A Lenda dos Mortos Depot
setManifestid(729240, "3754451603471365863", 256735525)
addappid(729241, 1, "7bb81e7c873ded452484225234b3943ed145a8627db5badd6673f8b48b50624c") -- Songs for the Dead - A Lenda dos Mortos Depot LINUX
setManifestid(729241, "8373673222053469982", 198583660)