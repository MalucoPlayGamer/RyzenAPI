-- Lua provided by RyzenAPI
-- Game: Songs for a Hero - Definitive Edition

-- MAIN APPLICATION
addappid(389170)

-- MAIN APP DEPOTS / PACKAGES
addappid(389171, 1, "4ee9d4961b9b7a1a42ffbf2d7afaaf0a978a527201106fa3d385f26dfe74b6fc")
