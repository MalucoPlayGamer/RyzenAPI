-- Lua provided by RyzenAPI
-- Game: addappid(1486690)

-- MAIN APPLICATION
addappid(1486690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486691, 1, "6698837054d4fb6b2fc3c9380cc3c344dd10b89c83abafded6fd32934b323f92")
