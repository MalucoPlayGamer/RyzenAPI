-- Lua provided by RyzenAPI
-- Game: Farmer's Father: The Origins

-- MAIN APPLICATION
addappid(2802690)
-- Game: addappid(2802690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802691, 1, "85a35a4059e81b505cc1cd3b3e07c291b5c8138111c30f9dfe6769a9c713890a")
