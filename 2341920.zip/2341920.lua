-- Lua provided by RyzenAPI 
-- Game: 三國立志傳2
addappid(2341920)
addappid(2341921, 1, "5177f9ce6a93f6a0be75eb71d66abfaef32e46c3106a1aaeaba8522c8fb9085c")
addappid(2341922, 1, "7e46fc5329498b2516bce15464f8d59b604cce8520b3cf8937333351995b656b")
addappid(2341923, 1, "9c907129ac0723783a2d1a60e7fd7a7e552b50bb7ba856e39cec05a1b6dfbc29")
