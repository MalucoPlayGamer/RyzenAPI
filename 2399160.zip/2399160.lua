-- Lua provided by RyzenAPI
-- Game: Game: AppID 2399160

-- MAIN APPLICATION
addappid(2399160)
-- Game: addappid(2399160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399161, 1, "6d0b2f3c7b505241661c6baa80d5a35e2bd2b6fc975df6cad7c4fb581ab6ed1e")
