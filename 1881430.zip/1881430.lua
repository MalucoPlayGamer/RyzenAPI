-- Lua provided by RyzenAPI
-- Game: DeltaBlade 2700 Re:Create

-- MAIN APPLICATION
addappid(1881430)
-- Game: addappid(1881430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881431, 1, "d3dd892eeea96bf51015e4577128a4409914724b219e9ce991ff669748a6b99b")
