-- Lua provided by RyzenAPI
-- Game: DeltaBlade 2700 Re:Create

-- MAIN APPLICATION
addappid(1881430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1881431, 1, "d3dd892eeea96bf51015e4577128a4409914724b219e9ce991ff669748a6b99b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
