-- Lua provided by RyzenAPI
-- Game: Space Pirates and Zombies

-- MAIN APPLICATION
addappid(107200)

-- MAIN APP DEPOTS / PACKAGES
addappid(107202,0,"bf3da4a1f6b3544335760104c0b48bf6ba1ad1c1ef403b3f7294acc0945f9c56")
addappid(107203,0,"62ac5c9ab1f763b802d3ff9ee5993a26bb01506878a2113be6c1094633638311")
addappid(107204,0,"15bd19c16ba37aa487ccc3291ea97b77f6d117fe2655bba3d6fe27ec1b914ecc")

