-- Lua provided by RyzenAPI
-- Game: Cryptmaster

-- MAIN APPLICATION
addappid(1885110)
-- Game: addappid(1885110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1885111, 1, "174afeda5e3bb5d3548b04c1266968b4ed0280b63468f301b2f78de189ad9479")
