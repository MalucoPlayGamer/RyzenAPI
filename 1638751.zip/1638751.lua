-- Lua provided by RyzenAPI
-- Game: FUSER™ - Machine Gun Kelly & blackbear - "my ex's best friend"

-- MAIN APPLICATION
addappid(1638751)

-- MAIN APP DEPOTS / PACKAGES
addappid(1638751,0,"9a23f621e47aae115aab3b827fc0e5def756839624b71c3c66af41b05929cc53")

