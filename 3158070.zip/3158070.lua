-- Lua provided by RyzenAPI
-- Game: Deadline Savior

-- MAIN APPLICATION
addappid(3158070) -- Deadline Savior

-- MAIN APP DEPOTS / PACKAGES
addappid(3158071, 1, "a53d0f5a0d6ac24df8defbfd7553dbf18e5b727508dea2fdac1417ffb9088104") -- Depot 3158071
