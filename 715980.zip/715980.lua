-- Lua provided by RyzenAPI
-- Game: Game: Eared Hero

-- MAIN APPLICATION
addappid(715980)
-- Game: addappid(715980)

-- MAIN APP DEPOTS / PACKAGES
addappid(715981, 1, "f9862b9313466601035e139bc790e4c74e13e774252cab37bb3af68211ffe6d4")
