-- Lua provided by RyzenAPI
-- Game: Kromaia

-- MAIN APPLICATION
addappid(285980)

-- MAIN APP DEPOTS / PACKAGES
addappid(285981, 1, "cc42c101917cff5673c6bb1df3c8dbfc1aceafce2cc26b21c20be11b8f69164c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
