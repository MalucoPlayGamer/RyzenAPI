-- Lua provided by RyzenAPI
-- Game: Yark Survivors

-- MAIN APPLICATION
addappid(2976160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2976161, 1, "4c32a37ed7920916be36b5e6d3e01506ea784ba2826510f53d9ee7a7ca86c8d5")
