-- Lua provided by RyzenAPI
-- Game: Lilac 0

-- MAIN APPLICATION
addappid(3316380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3316381, 1, "72fc01c656a5b306d4de660ede42c65cad8b48c76aaad2b2c07e921ecd6d832f")

