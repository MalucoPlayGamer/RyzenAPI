-- Lua provided by RyzenAPI
-- Game: 268420

-- MAIN APPLICATION
addappid(268420)

-- MAIN APP DEPOTS / PACKAGES
addappid(268423,0,"1f08152d365c388af3055cf9a1c485cedc8fc9649102fb02a0ce3ff2f314fb97")

