-- Lua provided by RyzenAPI
-- Game: Game: Silverfall

-- MAIN APPLICATION
addappid(4420)
-- Game: addappid(4420)

-- MAIN APP DEPOTS / PACKAGES
addappid(4421, 1, "df98a77ec1e203d5ba5db6cbee60fa428c09db6dee24f62c495c71d29d7d6f83")
addappid(4422, 1, "ff69a5679a20aaae31b1acb7d3f335d475958fbbd740dc69d990499c1a4698e0")
addappid(4423, 1, "511cdbb5f7b91e419db781a4c89a5db9e80329a6be9f11e7a28e742854554b9d")
addappid(4424, 1, "b6ff3377a2951721eb4ab92a28d087e1760d05b6d58ea0dc7ba319d44e4fe2eb")
addappid(4425, 1, "6166727b75a685c73fde1ac965e928813ef5317996a211ab4b665b461df02253")
addappid(4426, 1, "c4a260fc521893be7d996c8effb11da78223c0aef0976f21b67218881f92b536")
addappid(4427, 1, "cffdf48b9ba1444f23a2418b0e8762f9363522ed32b98b652294bafe30b84a37")
addappid(4428, 1, "b2d46dd17eed171dda4eefcd771eaa2bc60329d4c62b35a6af4578bd95b1c404")
addappid(4432, 1, "2e464faecb091a83e7449e0dfef6d66cf99b5ae675de521283c1988b4e41807d")
