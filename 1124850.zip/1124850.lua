-- Lua provided by RyzenAPI
-- Game: AppID 1124850

-- MAIN APPLICATION
addappid(1124850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124851, 1, "25e55df5db6a280422d0740d8b6eec7b7566c6916f9a678f681d92f38991a8e8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
