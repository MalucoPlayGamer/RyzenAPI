-- Lua provided by RyzenAPI
-- Game: addappid(1124850)

-- MAIN APPLICATION
addappid(1124850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124851, 1, "25e55df5db6a280422d0740d8b6eec7b7566c6916f9a678f681d92f38991a8e8")
