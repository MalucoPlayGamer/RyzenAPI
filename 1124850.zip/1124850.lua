-- Lua provided by RyzenAPI
-- Game: 閃電對決Lightning Wings II

-- MAIN APPLICATION
addappid(1124850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1124851, 1, "25e55df5db6a280422d0740d8b6eec7b7566c6916f9a678f681d92f38991a8e8")

