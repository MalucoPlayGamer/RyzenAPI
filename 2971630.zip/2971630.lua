-- Lua provided by RyzenAPI
-- Game: PlasticFighter

-- MAIN APPLICATION
addappid(2971630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2971631,0,"791bb14db0d0b2d82a3635808f3d843030c2857662ada4e69e8dd234e7bef35d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
