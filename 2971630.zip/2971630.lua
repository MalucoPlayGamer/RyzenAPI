-- Lua provided by RyzenAPI
-- Game: PlasticFighter

-- MAIN APPLICATION
addappid(2971630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2971631,0,"791bb14db0d0b2d82a3635808f3d843030c2857662ada4e69e8dd234e7bef35d")

