-- Lua provided by RyzenAPI
-- Game: Game: AppID 1311890

-- MAIN APPLICATION
addappid(1311890)
-- Game: addappid(1311890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311891, 1, "47e9173ff3bcadda95639e81d22290358b8ab49964c89c16246893e085ea9c47")
