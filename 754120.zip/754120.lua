-- Lua provided by RyzenAPI
-- Game: Ninja Stealth 3

-- MAIN APPLICATION
addappid(754120)
addappid(760420)
addappid(817270)

-- MAIN APP DEPOTS / PACKAGES
addappid(754121, 1, "feaa731634ecb4386ddfb742994133ab3093375ba3b036d6b73bd9601562a731")
addappid(754122, 1, "fe9be667af750854abdba833d968e997985cd0ad6fc848b2b9286ecdd4b701bb")

