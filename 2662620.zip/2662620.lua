-- Lua provided by RyzenAPI
-- Game: ◒ Art Boxer

-- MAIN APPLICATION
addappid(2662620)
-- Game: addappid(2662620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2662621, 1, "2e1d4628e01ec7de577f2de3acff9d958bfaa8346a31ca28685e02de9c723812")
