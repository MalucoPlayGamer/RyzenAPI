-- Lua provided by RyzenAPI 
-- Game: 9-nine-:Episode 3
addappid(1142830)
addappid(1142831, 1, "f4207f6223025286865cfecb3efe78b9c024ced2336ece4e92193b75112e617c")
