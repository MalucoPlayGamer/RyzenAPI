-- Lua provided by RyzenAPI
-- Game: Mystical

-- MAIN APPLICATION
addappid(387270)

-- MAIN APP DEPOTS / PACKAGES
addappid(387271, 1, "8b43f1db90db813c91f07a46a0161ed94121db53d341fb07a005be83d36e9169")
