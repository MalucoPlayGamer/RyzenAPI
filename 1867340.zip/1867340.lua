-- Lua provided by RyzenAPI
-- Game: addappid(1867340)

-- MAIN APPLICATION
addappid(1867340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1867341, 1, "b133aee246074393c749f8ce9ff34a83afc836de9ace990ff9ebe06419e71426")
