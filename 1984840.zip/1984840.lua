-- Lua provided by RyzenAPI
-- Game: Traffic Safety

-- MAIN APPLICATION
addappid(1984840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1984841, 1, "db047e8f480152239d6f9c4f52b1e73ce592fdf1f1fb6ee102c50db43b9d6646")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1984990)
addappid(1984991)
addappid(1984992)
addappid(1984993)
addappid(1984994)
addappid(2011500)
addappid(2011501)
addappid(2011502)
addappid(2011503)
addappid(2011504)
