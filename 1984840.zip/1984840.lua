-- Lua provided by RyzenAPI
-- Game: Traffic Safety

-- MAIN APPLICATION
addappid(1984840)
-- Game: addappid(1984840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1984841, 1, "db047e8f480152239d6f9c4f52b1e73ce592fdf1f1fb6ee102c50db43b9d6646")
