-- Lua provided by SkyAPI 
-- Game: Traffic Safety
addappid(1984840)
addappid(1984841, 1, "db047e8f480152239d6f9c4f52b1e73ce592fdf1f1fb6ee102c50db43b9d6646")
