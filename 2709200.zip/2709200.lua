-- Lua provided by RyzenAPI
-- Game: 2709200

-- MAIN APPLICATION
addappid(2709200)
-- Game: addappid(2709200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2709201, 1, "893f7258f7f6e7bfa16dd7bf4b1a8033f7bdf7cc8183cf0aa02a46405f551386")
