-- Lua provided by RyzenAPI 
-- Game: Swappy World Demo
addappid(2709200)
addappid(2709201, 1, "893f7258f7f6e7bfa16dd7bf4b1a8033f7bdf7cc8183cf0aa02a46405f551386")
