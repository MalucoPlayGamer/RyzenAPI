-- Lua provided by RyzenAPI
-- Game: Game: POLE

-- MAIN APPLICATION
addappid(1646730)
-- Game: addappid(1646730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646731, 1, "5ebb366c4366594ad7b60bdaa923dce98ab0a9a3289f864440a45c9c716053fb")
addappid(1646733, 1, "06b7a17a1a8e1727d2328df63c3556831578c7fd29b223820df8fe8fbe4eb9df")
