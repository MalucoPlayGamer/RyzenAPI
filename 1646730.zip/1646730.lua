-- Lua provided by RyzenAPI
-- Game: POLE

-- MAIN APPLICATION
addappid(1646730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1646731, 1, "5ebb366c4366594ad7b60bdaa923dce98ab0a9a3289f864440a45c9c716053fb")
addappid(1646733, 1, "06b7a17a1a8e1727d2328df63c3556831578c7fd29b223820df8fe8fbe4eb9df")

