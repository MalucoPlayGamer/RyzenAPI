-- Lua provided by RyzenAPI
-- Game: Game: Friends vs Friends

-- MAIN APPLICATION
addappid(1785150)
-- Game: addappid(1785150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1785151, 1, "c3804d95965aff919c17133b9368730465743d377206cb34d0a526e61f940b0d")
