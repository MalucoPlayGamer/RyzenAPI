-- Lua provided by RyzenAPI
-- Game: Chillquarium Demo

-- MAIN APPLICATION
addappid(2296100)
-- Game: addappid(2296100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2296101, 1, "b04996dad84d0ab369cafe4faa26fc36c4c817673f65003523657ff6cb156470")
