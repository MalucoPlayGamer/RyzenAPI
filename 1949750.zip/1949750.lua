-- Lua provided by RyzenAPI
-- Game: Slime Corp

-- MAIN APPLICATION
addappid(1949750)
-- Game: addappid(1949750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949751, 1, "cbfa11a750ba59751b2e97babf9ee104165923a3c1cd919cdf303331f11743d1")
