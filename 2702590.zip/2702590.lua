-- Lua provided by RyzenAPI
-- Game: Sidereal

-- MAIN APPLICATION
addappid(2702590)
-- Game: addappid(2702590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2702591, 1, "58b8c29f2cc4884d7b8532a20cf044a5f54d7387a98e5cad804090879673eaa2")
