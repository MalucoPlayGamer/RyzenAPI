-- Lua provided by RyzenAPI
-- Game: AppID 209080

-- MAIN APPLICATION
addappid(209080)
addappid(228983)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(209081, 1, "d1b72b811f4dddeae9330694672dc415a2f0c6279016fdc34e27cc7d68008622")
addappid(209082, 1, "936049ff8e64b3bcc4786e393f495093d7da1d04af844da288079aa815f9ca3d")
addappid(209083, 1, "642a77af5c04308b42f9c7225ef3394d356dfd202d99ce8590f7e991bd030989")
addappid(209084, 1, "fdb7ee095cfb6958129372d72f93bc4118e22e176145ea188a931f5c2d109d97")
addappid(209085, 1, "6be95efe46271f645b9ffd0fcaba2dffbfbc021ab6295b90e3908fd65373fe20")
addappid(209086, 1, "9b138f763d705bb92a6a9f0442d59d316e1efcba93d4f138b69a14cc68936b4a")
addappid(217811, 0, "7d2d9f696828cf4e8112efc1027907b33ad118f5fbf43dd23bba7bb94928a1b6")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(217810)
