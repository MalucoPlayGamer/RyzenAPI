-- Lua provided by RyzenAPI
-- Game: Lost Light

-- MAIN APPLICATION
addappid(1797880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1797881, 1, "f3d278fb8fcc98ab8d1d29ec4a8b5693e0e5dab346f4130f2b75f0b66a6a5cb9")

