-- Lua provided by RyzenAPI
-- Game: addappid(1797880)

-- MAIN APPLICATION
addappid(1797880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797881, 1, "f3d278fb8fcc98ab8d1d29ec4a8b5693e0e5dab346f4130f2b75f0b66a6a5cb9")
