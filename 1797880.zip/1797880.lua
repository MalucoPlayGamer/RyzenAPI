-- Lua provided by RyzenAPI 
-- Game: Lost Light
addappid(1797880)
addappid(1797881, 1, "f3d278fb8fcc98ab8d1d29ec4a8b5693e0e5dab346f4130f2b75f0b66a6a5cb9")
