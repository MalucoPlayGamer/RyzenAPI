-- Lua provided by RyzenAPI 
-- Game: AppID 2576110
addappid(2576110)
addappid(2576111, 1, "7c1328177bce9af3fda91d5cb24f587ce2c97095be752df54fc7411d01de5bdc")
