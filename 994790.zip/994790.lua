-- Lua provided by RyzenAPI
-- Game: AppID 994790

-- MAIN APPLICATION
addappid(994790)
-- Game: addappid(994790)

-- MAIN APP DEPOTS / PACKAGES
addappid(994791, 1, "3c567cda8a6a310d271fa5917f5eb4f30844dc424176231abfed0828be3e2e80")
