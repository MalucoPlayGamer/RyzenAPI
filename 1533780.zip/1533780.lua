-- Lua provided by RyzenAPI 
-- Game: A Walk Through Echoes
addappid(1533780)
addappid(1533781, 1, "5c939fcb607bf3f6a287d005e6ed6d4f4feaac424bce01daec3fcd8f04c86817")
