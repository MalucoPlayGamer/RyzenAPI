-- Lua provided by RyzenAPI
-- Game: Game: Tech Support: Error Unknown

-- MAIN APPLICATION
addappid(781480)
-- Game: addappid(781480)

-- MAIN APP DEPOTS / PACKAGES
addappid(781481, 1, "617c0eac71a71bd935950c023145357540e0bb9b6bbde997521297e4882dde56")
