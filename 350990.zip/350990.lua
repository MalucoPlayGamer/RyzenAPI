-- Lua provided by RyzenAPI
-- Game: Bloodwood Reload

-- MAIN APPLICATION
addappid(350990)

-- MAIN APP DEPOTS / PACKAGES
addappid(350993,0,"b0a55c21bffc108fcf0c83d56789832a7ba17d5d24911f76141b433cc42848ea")
