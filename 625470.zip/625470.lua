-- Lua provided by RyzenAPI
-- Game: AppID 625470

-- MAIN APPLICATION
addappid(625470)

-- MAIN APP DEPOTS / PACKAGES
addappid(625471, 1, "b48a18c76516dd7aa277702b81ae0d76186fd96f02227a8b5589a6a233ebccad")
addappid(625472, 1, "a6b47f6fc83a985e4599c25b98e46d69771f71b811820a69294c5da422f29f51")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
