-- Lua provided by RyzenAPI 
-- Game: AppID 625470
addappid(625470)
addappid(625471, 1, "b48a18c76516dd7aa277702b81ae0d76186fd96f02227a8b5589a6a233ebccad")
addappid(625472, 1, "a6b47f6fc83a985e4599c25b98e46d69771f71b811820a69294c5da422f29f51")
