-- Lua provided by RyzenAPI
-- Game: 1717940

-- MAIN APPLICATION
addappid(1717940)
-- Game: addappid(1717940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717941, 1, "844bea45783e93454561c67496baf8a15c0d857af0b3b6cd25a803a6f7de9cb7")
