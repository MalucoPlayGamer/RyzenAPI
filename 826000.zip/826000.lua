-- Lua provided by RyzenAPI
-- Game: Masked Forces 3

-- MAIN APPLICATION
addappid(826000)

-- MAIN APP DEPOTS / PACKAGES
addappid(826001,0,"160ea5453ee0c4cf49180a8eb54c9c87b8db29cb20739628496c28e281bc342e")

