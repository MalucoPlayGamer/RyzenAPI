-- Lua provided by RyzenAPI
-- Game: Game: Floodland

-- MAIN APPLICATION
addappid(1336180)
-- Game: addappid(1336180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336181, 1, "ebb4c16162ec18cd471493e821eee64160291e92178d67a65f0819454ee43ddf")
addappid(2218180, 0, "a72358b755ede5cf12ccb157ace67c9f803076fd286bd616bf5538251f254297")
