-- Lua provided by RyzenAPI
-- Game: Dorfromantik Soundtrack Vol. 2

-- MAIN APPLICATION
addappid(1981960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981962,0,"0164e14ceffdf7f283499ec91cfd9d9471e12bc4b5deace0aea7f9d6007f4652")
addappid(1981963,0,"100b451b512c0cf956753e6c2c7b52c0aa1e158040d36a700f3b233fc465f72c")
