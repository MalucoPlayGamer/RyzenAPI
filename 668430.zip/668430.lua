-- Lua provided by RyzenAPI
-- Game: VRacer Hoverbike

-- MAIN APPLICATION
addappid(668430)

-- MAIN APP DEPOTS / PACKAGES
addappid(668431, 1, "a700820d5fd00fad0c0a86d33150808c20584f592402cd3f8c7395667940ad47")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4825640)
addappid(4825660)
addappid(4825680)
