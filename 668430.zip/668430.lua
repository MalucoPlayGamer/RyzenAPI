-- Lua provided by RyzenAPI
-- Game: VRacer Hoverbike

-- MAIN APPLICATION
addappid(668430)
-- Game: addappid(668430)

-- MAIN APP DEPOTS / PACKAGES
addappid(668431, 1, "a700820d5fd00fad0c0a86d33150808c20584f592402cd3f8c7395667940ad47")
