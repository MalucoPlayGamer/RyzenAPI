-- Lua provided by RyzenAPI
-- Game: 雪之本境S Conspiracy Field: Snow Trap

-- MAIN APPLICATION
addappid(1908250)
-- Game: addappid(1908250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1908251, 1, "0cabacec3c3cc7681957c59ff0faace402a27a11758175e1c28e1baf95df8bc4")
addappid(2072440, 0, "4a3041a933fd92ae5ad230771242009f555bf3be82457de24cd8123780f20944")
