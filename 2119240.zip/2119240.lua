-- Lua provided by SkyAPI 
-- Game: Trash Horror Collection 2
addappid(2119240)
addappid(2119241, 1, "b3a3a7cc23854b13fe9f82a6f4c1f3647c8ff976bd76ab961bbd7246c3fea115")
