-- Lua provided by RyzenAPI
-- Game: Brigador: Up-Armored Edition

-- MAIN APPLICATION
addappid(274500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(274501, 1, "7b83c828626c56eae0a221af5776403e1aaf430d813950d2f79113aef56e870a")
addappid(274502, 1, "8e6b0eea7961fef1900c6ed5b804ead7aa114e02d35b10c6c23cc7adf0fbd993")
addappid(274503, 1, "d8e7bc978b75d5826ecde1cd146bb4327a865559a4067be69614cd057a8126af")
addappid(468270, 0, "d9e24f9713c4ba9798345c93da5be416116037bc99dedf4c20135f8d2d11d862")
