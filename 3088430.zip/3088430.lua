-- Lua provided by RyzenAPI
-- Game: addappid(3088430)

-- MAIN APPLICATION
addappid(3088430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3088431, 1, "b3ce0d8a45322ea84f096e066b60d057402a3a6c901da9367bd9c4fead9fea69")
