-- Lua provided by RyzenAPI
-- Game: Think To Die

-- MAIN APPLICATION
addappid(533690)

-- MAIN APP DEPOTS / PACKAGES
addappid(533691, 1, "d1f8114d7e916aac01a5db3da0e4a2ab839b674e891f774be7a9ec5df57fd715")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(534260)
