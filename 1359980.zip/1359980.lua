-- Lua provided by RyzenAPI
-- Game: addappid(1359980)

-- MAIN APPLICATION
addappid(1359980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359981, 1, "4407b8f39b12b4d47ebb635bc862313dc9e3f5afe62b8cbbd0314223eead3856")
