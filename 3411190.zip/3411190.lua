-- Lua provided by RyzenAPI
-- Game: Game: CUSTOM ORDER MAID 3D2 It's a Night Magic Lucky Bag 2025 Ver.Luxury Adult

-- MAIN APPLICATION
addappid(3411190)
-- Game: addappid(3411190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3411191, 1, "784bc20523536e79f627a8fb3900b6aebb87d19a606ecd585a3902525e38a826")
