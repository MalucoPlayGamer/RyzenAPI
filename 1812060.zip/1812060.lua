-- Lua provided by RyzenAPI
-- Game: Yokai Art: Night Parade of One Hundred Demons

-- MAIN APPLICATION
addappid(1812060)
addappid(2072470)
addappid(2256730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812061, 1, "3ae5d631e032bf802fcaec330f910b43a08cf26f476f47d1e8658e5811ef7d84")

