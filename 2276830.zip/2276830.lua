-- Lua provided by RyzenAPI
-- Game: Kingsvein

-- MAIN APPLICATION
addappid(2276830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2276831, 1, "bda9c7c9b1d1095a717cbf1dcf309e51145df9162efd362dc83f5a157cb7413e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
