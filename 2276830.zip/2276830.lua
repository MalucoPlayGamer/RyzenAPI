-- Lua provided by RyzenAPI
-- Game: addappid(2276830)

-- MAIN APPLICATION
addappid(2276830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2276831, 1, "bda9c7c9b1d1095a717cbf1dcf309e51145df9162efd362dc83f5a157cb7413e")
