-- Lua provided by RyzenAPI
-- Game: Shadows on the Vatican - Act II: Wrath

-- MAIN APPLICATION
addappid(378630)

-- MAIN APP DEPOTS / PACKAGES
addappid(378631, 1, "b97403f13946b939b18af93bc742a0eadd0e69ae0bec73301c65fbca68f6f7e7")
addappid(378632, 1, "976afe881a90ef50ced77e64144bc29dcb832296dfd34796a46941520e6e2d1b")
addappid(378633, 1, "d6a8554c720f0bec16ed96cb017438de17ed3c54daadc5fe03668882b7519bbd")
addappid(378634, 1, "9fcfa0459fb3a57818218027126ce6f747c185c7660e123b0c8e78cec9be0af4")
addappid(378635, 1, "10786943b7042ac78803e88f497f8d324ed11984c48c66b22a8281e64eb13312")
addappid(378636, 1, "fd79b525fad9defc86aca67d09bcbc37e227e5256ace7e58263f7e87b02b638f")
addappid(378637, 1, "db3361bd0e057958adf2e834e005122dccde75e602ad058a1b77024823ca229f")
addappid(378638, 1, "5058f257b9739e10c58c5f33f392fac9e31444a94a2725fe89f9d3046da953d3")
addappid(378639, 1, "12a5b67fb95f4f93438ac5acd17ae25da1fb1811befebbb3ee0b46838329b043")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
