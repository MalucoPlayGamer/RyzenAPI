-- Lua provided by RyzenAPI
-- Game: addappid(1656820)

-- MAIN APPLICATION
addappid(1656820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656821, 1, "6d08ea74d118040ef4bc5abacd19e457696e30e93c7a4f64ac631610e925a8d7")
