-- Lua provided by RyzenAPI
-- Game: COTTON REBOOT!

-- MAIN APPLICATION
addappid(1656820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1656821, 1, "6d08ea74d118040ef4bc5abacd19e457696e30e93c7a4f64ac631610e925a8d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
