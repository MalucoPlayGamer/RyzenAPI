-- Lua provided by RyzenAPI
-- Game: Snail Racer Extreme

-- MAIN APPLICATION
addappid(854150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(854151, 1, "c5e33516ef2505727fccc226a3eac7cc8c8eff0d10368724c1db7e88bfb4127c")
addappid(854153, 1, "06df9444c20814a75783acad3f8c063b32c8d0f47440169a35e9e4be8b9dc4a9")

