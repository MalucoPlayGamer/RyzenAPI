-- Lua provided by RyzenAPI
-- Game: Running Ninja

-- MAIN APPLICATION
addappid(1037840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1037841, 1, "dd9c8afbdad8a5f61a4f576fef117d693204d3fc0cf137bb7ff0f4193c1ba6e1")

