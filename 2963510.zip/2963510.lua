-- Lua provided by RyzenAPI
-- Game: Game: In Search Of You

-- MAIN APPLICATION
addappid(2963510)
-- Game: addappid(2963510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963511, 1, "1a4edf150a903a02f6a3a1167f48926447f68b1fd7d367e1583284e80f07fb68")
