-- Lua provided by RyzenAPI
-- Game: ASTRONEER (Original Soundtrack)

-- MAIN APPLICATION
addappid(571010)

-- MAIN APP DEPOTS / PACKAGES
addappid(571010,0,"1a421af94606284807e157154ee5a36f0ddf5a3b37d518a3390a98bf0de5d525")

