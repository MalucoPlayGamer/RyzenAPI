-- Lua provided by RyzenAPI 
-- Game: Twizzle Puzzle: Predators
addappid(2850680)
addappid(2850681, 1, "c46cf6d155264f5a1a8bf4c5dc9cb667ed5897274e85d1b591e6b5bd8bb304e8")
