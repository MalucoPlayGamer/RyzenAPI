-- Lua provided by RyzenAPI
-- Game: Game: Twizzle Puzzle: Predators

-- MAIN APPLICATION
addappid(2850680)
-- Game: addappid(2850680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2850681, 1, "c46cf6d155264f5a1a8bf4c5dc9cb667ed5897274e85d1b591e6b5bd8bb304e8")
