-- Lua provided by SkyAPI 
-- Game: Jabroni Brawl: Episode 3
addappid(869480)
addappid(869481, 1, "04ca70818842e0a04db1f9b25ecd4afc1da390b7e9aa8d08ef61244776f26f5b")
addappid(869482, 1, "84bf33439167aaa639c694287ff1cf0f2a2dfbff8e88afc33bea096c8c3d0fd2")
addappid(869484, 1, "c6c7924b5ebd8fd801b2c0b8cd1953d9ccd9a5aef3f552f0fe99157e5ccb5724")
