-- Lua provided by RyzenAPI
-- Game: Jabroni Brawl: Episode 3

-- MAIN APPLICATION
addappid(869480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(869481, 1, "04ca70818842e0a04db1f9b25ecd4afc1da390b7e9aa8d08ef61244776f26f5b")
addappid(869482, 1, "84bf33439167aaa639c694287ff1cf0f2a2dfbff8e88afc33bea096c8c3d0fd2")
addappid(869484, 1, "c6c7924b5ebd8fd801b2c0b8cd1953d9ccd9a5aef3f552f0fe99157e5ccb5724")

