-- Lua provided by RyzenAPI 
-- Game: Dragons On Desktop
addappid(1914900)
addappid(1914901, 1, "38c0948b6a1945a2f1ec8c9dc482c60956d6853255d97f64bcd0f28086bc918e")
