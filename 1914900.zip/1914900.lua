-- Lua provided by RyzenAPI
-- Game: addappid(1914900)

-- MAIN APPLICATION
addappid(1914900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1914901, 1, "38c0948b6a1945a2f1ec8c9dc482c60956d6853255d97f64bcd0f28086bc918e")
