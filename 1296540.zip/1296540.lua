-- Lua provided by SkyAPI 
-- Game: AppID 1296540
addappid(1296540)
addappid(1296541, 1, "7279a9e57841d6f0ff293c2452d0cb04f5789c693a8fc7451b3564f7eca1cb4c")
