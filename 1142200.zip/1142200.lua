-- Lua provided by SkyAPI 
-- Game: AppID 1142200
addappid(1142200)
addappid(1142201, 1, "359d58cbc496109f09beafb41011cc0f1bbbfa4eac57f1f0da18a5bf9aaa28b9")
