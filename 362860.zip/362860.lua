-- Lua provided by SkyAPI 
-- Game: Sylvio
addappid(362860)
addappid(362861, 1, "89a8d88dca6b4dc6ca3298c4dc3bafadd1ab27aeb476bd2b49b8c9c753b6af1a")
addappid(386890, 0, "4783ae0402d798f78cfd7b1c79da954c31c44d9375755bad63df6c54e4652174")
