-- Lua provided by RyzenAPI
-- Game: Game: AppID 738860

-- MAIN APPLICATION
addappid(738860)
-- Game: addappid(738860)

-- MAIN APP DEPOTS / PACKAGES
addappid(738861, 1, "45c559f1b4970594bfba38df277eeb64ab6c3ef812da64c7b932f2a9f50c4e62")
