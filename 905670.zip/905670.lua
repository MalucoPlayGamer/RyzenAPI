-- Lua provided by RyzenAPI
-- Game: 巭孬嫑毖

-- MAIN APPLICATION
addappid(905670)

-- MAIN APP DEPOTS / PACKAGES
addappid(905671, 1, "72d0900bc994e9382db00649d5c07e60cf5d54d108015cff28cef8670b07cf84")

