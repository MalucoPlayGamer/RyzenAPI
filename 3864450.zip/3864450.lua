-- Lua provided by RyzenAPI
-- Game: Goblin Company

-- MAIN APPLICATION
addappid(3864450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3864451, 1, "2c180598182ffa3f889528a2728cb95186951f9de68749df9c7dff20a9e73d58")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
