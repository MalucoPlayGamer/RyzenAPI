-- Lua provided by RyzenAPI
-- Game: AppID 2761010

-- MAIN APPLICATION
addappid(2761010)
-- Game: addappid(2761010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2761011, 1, "a0b07d1beb8bf51cce37097570448b02ab5b6c4ce7b1edae7e25c73f9cefc8b2")
