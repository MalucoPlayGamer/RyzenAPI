-- Lua provided by RyzenAPI
-- Game: Game Of Puzzles: Dinosaurs

-- MAIN APPLICATION
addappid(1294280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1294281, 1, "50acf3a39ebc22b75e95ca72ebe9e297fb325f3ef46c4d9da08c528ba6b5dabf")

