-- Lua provided by RyzenAPI
-- Game: HEROish

-- MAIN APPLICATION
addappid(1876350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876352,0,"a00c3a6247db5fe625c51bf9fc2a4ddd28616e2d2ff06b83a0d88a4fc8f5120d")

