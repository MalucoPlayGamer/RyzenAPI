-- Lua provided by RyzenAPI
-- Game: Gazmatera 2 America's Least Wanted

-- MAIN APPLICATION
addappid(1749480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1749481, 1, "e4a5954e4634077150298af43ffbd06c2b0e38fca26c3e33b616f237672aa34e")

