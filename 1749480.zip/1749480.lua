-- Lua provided by RyzenAPI
-- Game: Gazmatera 2 America's Least Wanted

-- MAIN APPLICATION
addappid(1749480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1749481, 1, "e4a5954e4634077150298af43ffbd06c2b0e38fca26c3e33b616f237672aa34e")

