-- Lua provided by RyzenAPI
-- Game: Last Saintess

-- MAIN APPLICATION
addappid(2280540)
-- Game: addappid(2280540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2280541, 1, "7c02955caec37cfd6018ee7baf7e9cb22cc4c5dc5c7ae83157c99a1dfa5345f6")
