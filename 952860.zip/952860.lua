-- Lua provided by SkyAPI 
-- Game: 河洛群俠傳 (Ho Tu Lo Shu ： The Books of Dragon)
addappid(952860)
addappid(952861, 1, "0fad2070b5f8ede51476f235a502220aff3d1e3cbff42e8c265db8d3e87119af")
addappid(952862, 1, "fdc40edfc42bce607710de539206ce517f547619fe61ac97d9c3dbc99d5df0fb")
addappid(952863, 1, "1a310399a872bf598bc2753ab68c01238834e7059b9a46ed9ed467aab29c1297")
