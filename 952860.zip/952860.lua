-- Lua provided by RyzenAPI
-- Game: 河洛群俠傳 (Ho Tu Lo Shu ： The Books of Dragon)

-- MAIN APPLICATION
addappid(952860)

-- MAIN APP DEPOTS / PACKAGES
addappid(952861, 1, "0fad2070b5f8ede51476f235a502220aff3d1e3cbff42e8c265db8d3e87119af")
addappid(952862, 1, "fdc40edfc42bce607710de539206ce517f547619fe61ac97d9c3dbc99d5df0fb")
addappid(952863, 1, "1a310399a872bf598bc2753ab68c01238834e7059b9a46ed9ed467aab29c1297")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
