-- Lua provided by RyzenAPI
-- Game: Game: AppID 813020

-- MAIN APPLICATION
addappid(813020)
-- Game: addappid(813020)

-- MAIN APP DEPOTS / PACKAGES
addappid(813021, 1, "e02db756ac81c1499c71d1a16a8bee855b74c2b1d6c0600a546eb975b025d085")
