-- Lua provided by RyzenAPI
-- Game: Game: Chronicles of Delights: Isekai Adventure

-- MAIN APPLICATION
addappid(3214690)
-- Game: addappid(3214690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3214691, 1, "c5b966679c899c3d1c8c2f134608174603966690e3ad92659f781101c0a3edd2")
