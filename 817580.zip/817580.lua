-- Lua provided by RyzenAPI
-- Game: addappid(817580)

-- MAIN APPLICATION
addappid(817580)

-- MAIN APP DEPOTS / PACKAGES
addappid(817581, 1, "5a40b83c9ec56b19f4437a27dcbbf9ec578f4d5772bb27a60cf6b83ae9569616")
