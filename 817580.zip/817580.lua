-- Lua provided by SkyAPI 
-- Game: AppID 817580
addappid(817580)
addappid(817581, 1, "5a40b83c9ec56b19f4437a27dcbbf9ec578f4d5772bb27a60cf6b83ae9569616")
