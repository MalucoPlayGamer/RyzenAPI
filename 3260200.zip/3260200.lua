-- Lua provided by RyzenAPI
-- Game: Across the Wonderlands - Appetizer Demo

-- MAIN APPLICATION
addappid(3260200)
-- Game: addappid(3260200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3260201, 1, "ff4250f91a75fdaa80e146c932aff2818d1301a4ddda454034b300ec9924cddb")
