-- Lua provided by SkyAPI 
-- Game: Killer: Infected One of Us
addappid(1453840)
addappid(1453841, 1, "3067a1765cf918c4e5df0d836efddfb32f9c1651b7ce51fe05e511cc1fc0f3e2")
