-- Lua provided by RyzenAPI
-- Game: Killer: Infected One of Us

-- MAIN APPLICATION
addappid(1453840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1453841, 1, "3067a1765cf918c4e5df0d836efddfb32f9c1651b7ce51fe05e511cc1fc0f3e2")

