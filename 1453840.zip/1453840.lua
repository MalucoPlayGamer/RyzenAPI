-- Lua provided by RyzenAPI
-- Game: Killer: Infected One of Us

-- MAIN APPLICATION
addappid(1453840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453841, 1, "3067a1765cf918c4e5df0d836efddfb32f9c1651b7ce51fe05e511cc1fc0f3e2")
