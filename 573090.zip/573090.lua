-- Lua provided by RyzenAPI
-- Game: Stormworks: Build and Rescue

-- MAIN APPLICATION
addappid(573090)
addappid(1542360)
addappid(2124750)
addappid(2383250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(573091, 1, "49f609573f8fc3923ec4eab2ba459bdea77b7a906e9054549c102e4659fcfff7")
addappid(573092, 1, "871725b4b4314590b50465afe4c8ebd3cea63a704afce1ae1f369edecb0be7f5")

