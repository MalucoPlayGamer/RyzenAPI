-- Lua provided by RyzenAPI
-- Game: Game: Stormworks: Build and Rescue

-- MAIN APPLICATION
addappid(573090)
addappid(1542360)
addappid(2124750)
addappid(2383250)
-- Game: addappid(573090)

-- MAIN APP DEPOTS / PACKAGES
addappid(573091, 1, "49f609573f8fc3923ec4eab2ba459bdea77b7a906e9054549c102e4659fcfff7")
addappid(573092, 1, "871725b4b4314590b50465afe4c8ebd3cea63a704afce1ae1f369edecb0be7f5")
