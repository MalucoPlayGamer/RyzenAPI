-- Lua provided by SkyAPI 
-- Game: MULLET MADJACK
addappid(2111190)
addappid(2111191, 1, "948e02b3847d84df1bb86c11f9d0cb0b4aa2bf7f8040f4fb09f08ff8c3b93c70")
addappid(2902200, 0, "62e649811dc1b993a1dd19936e4f2b25d16fc698e28de2a3f7fdb3e099101981")
