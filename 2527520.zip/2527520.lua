-- Lua provided by RyzenAPI
-- Game: MiSide Demo

-- MAIN APPLICATION
addappid(2527520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2527521, 1, "19d70df1dd4c7fcc31a8ee904a69bcb4175fd0a768410bbd3eb72fb87feada73")
