-- Lua provided by SkyAPI 
-- Game: Sundered®: Eldritch Edition
addappid(535480)
addappid(535481, 1, "97dd8ba29cec4cf1c62596195dbacb6f5a6795a9674566e3f32790f08d324da5")
addappid(535482, 1, "b59965189bd8f1c67a2ebc55305bec1646c4ad4b7562c678cced2df50a6f6e77")
addappid(535483, 1, "4c0fe2024da31315fa8793db32bd7208dc1bf3eb29ba578d2e7b4676075e866f")
