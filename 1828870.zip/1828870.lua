-- Lua provided by RyzenAPI
-- Game: Tavern Crawl

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1828870)
-- Game: addappid(1828870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828872,0,"3ea30f90200741120ee925216336df270c38305505016aefd7a84cfbc9ef22c4")
addappid(1828873,0,"9695c16782c7bb32bcbca9f6299c1b668e190b5c0827e090fa5e6403a360861b")
