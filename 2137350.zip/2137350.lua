-- Lua provided by RyzenAPI
-- Game: Input Chaos

-- MAIN APPLICATION
addappid(2137350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137351, 1, "349ee8e89529e9a4b7e6ac7360e22fdb04975ac72846e9ce68c7a293c856eb25")

