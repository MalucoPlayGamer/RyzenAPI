-- Lua provided by RyzenAPI 
-- Game: Umbraclaw Demo
addappid(2461030)
addappid(2461031, 1, "3e6ea3043799b6e3316d2e2b8ad793a9c3d8402d3c245c5e038f1daa7a18114b")
