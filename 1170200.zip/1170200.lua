-- Lua provided by RyzenAPI 
-- Game: AppID 1170200
addappid(1170200)
addappid(1170201, 1, "fd9321823020c7c33f17701631d9b58df14c7e5c0bc6a0cb6f0b274f4e1b295a")
