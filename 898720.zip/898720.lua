-- Lua provided by SkyAPI 
-- Game: AppID 898720
addappid(898720)
addappid(898721, 1, "69e6c56460489423399677b4ef264e436ba5b620491a70b793d97a91bf6f9d0a")
addappid(898722, 1, "c9ba70d7e030037e9cb5b6f7ad7514249f9e7763f3c9c15bc99fa162c342ac33")
addappid(898723, 1, "a67f3a575e194d4af1f6b7c02b5b2c83fb7cfe9aaaa47bc10fbdcc601d69a34d")
