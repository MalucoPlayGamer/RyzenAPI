-- Lua provided by SkyAPI 
-- Game: MocapForAll Demo
addappid(1759730)
addappid(1759731, 1, "de56f0f174dd2584cbf0aabbe5647f05fdf46787bdfc9e802eb70934af02eec7")
