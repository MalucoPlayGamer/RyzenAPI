-- Lua provided by RyzenAPI
-- Game: MocapForAll Demo

-- MAIN APPLICATION
addappid(1759730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1759731, 1, "de56f0f174dd2584cbf0aabbe5647f05fdf46787bdfc9e802eb70934af02eec7")

