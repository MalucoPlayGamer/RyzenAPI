-- Lua provided by RyzenAPI
-- Game: Deep Dark Forest

-- MAIN APPLICATION
addappid(1312900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1312901, 1, "c61c80d332d48ad0b007208e6697311d3de94f48685dee62aecec591bb64252c")

