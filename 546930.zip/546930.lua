-- Lua provided by RyzenAPI
-- Game: Game: Machine Hunt

-- MAIN APPLICATION
addappid(546930)
-- Game: addappid(546930)

-- MAIN APP DEPOTS / PACKAGES
addappid(546931, 1, "6ff232fe06a60c5ad1e7f037aed142577d329cc7e6a93ba1a162fab85c1324a7")
addappid(546932, 1, "d775b6bef1e48744a35d68fd5ec71890737147ca80d9aedfcf18da88a7f70eba")
addappid(546933, 1, "8809b954f3568d8c7ea23da4864ac4218ad7477e6bd2a699f10bc979404b08ce")
addappid(546934, 1, "2e69b870ac775199f5951d52b01c89b2d60d57d6a4c0162e7a10a6b997440de7")
