-- Lua provided by RyzenAPI
-- Game: Home Security

-- MAIN APPLICATION
addappid(926370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(926371, 1, "d3ea08617b0ae22eaa618b5d9da559dd86e713fe55223380185dcf5fcfec2e5d")
