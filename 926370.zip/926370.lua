-- Lua provided by RyzenAPI
-- Game: AppID 926370

-- MAIN APPLICATION
addappid(926370)

-- MAIN APP DEPOTS / PACKAGES
addappid(926371, 1, "d3ea08617b0ae22eaa618b5d9da559dd86e713fe55223380185dcf5fcfec2e5d")

