-- Lua provided by SkyAPI 
-- Game: AppID 926370
addappid(926370)
addappid(926371, 1, "d3ea08617b0ae22eaa618b5d9da559dd86e713fe55223380185dcf5fcfec2e5d")
