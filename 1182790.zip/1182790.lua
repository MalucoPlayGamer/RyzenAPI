-- Lua provided by RyzenAPI
-- Game: AppID 1182790

-- MAIN APPLICATION
addappid(1182790)
-- Game: addappid(1182790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182791, 1, "01ad37f74e1c9288ae86385584e004f0beb80a056e041c6bfee58952240755fd")
