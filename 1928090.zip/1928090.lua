-- Lua provided by RyzenAPI
-- Game: 1928090

-- MAIN APPLICATION
addappid(1928090)
-- Game: addappid(1928090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928091, 1, "c0967e878f7bb94a4470b065f57b26a4cd13b423a995ca97d487d54600c7b5c6")
