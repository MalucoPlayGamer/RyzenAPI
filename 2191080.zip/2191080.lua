-- Lua provided by RyzenAPI
-- Game: Game: Poozle Mania

-- MAIN APPLICATION
addappid(2191080)
-- Game: addappid(2191080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191081, 1, "ed77408141afea2662d2341e87a32f30f84f1cec1dc975bf7a85ea43802317c7")
