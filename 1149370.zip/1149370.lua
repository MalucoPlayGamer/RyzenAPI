-- Lua provided by RyzenAPI
-- Game: Game: Broken Spell

-- MAIN APPLICATION
addappid(1149370)
-- Game: addappid(1149370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149371, 1, "af52e8f9950780718255f41319796da64a53552aac31210cb04f575e25a0d13a")
