-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2482040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2482042,0,"5b2f168388cce2b161666136f08e032fedcf25e6f92789d94da7473214cdaa81")
