-- Lua provided by RyzenAPI
-- Game: No Mercy 🔞

-- MAIN APPLICATION
addappid(3299570)
-- Game: addappid(3299570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3299571, 1, "6028a7baa92bb65c9b2368384f218a1e980fea4e3a0c99e11a27c6237d25ee57")
