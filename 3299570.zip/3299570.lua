-- Lua provided by RyzenAPI 
-- Game: No Mercy 🔞
addappid(3299570)
addappid(3299571, 1, "6028a7baa92bb65c9b2368384f218a1e980fea4e3a0c99e11a27c6237d25ee57")
