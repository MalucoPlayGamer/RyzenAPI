-- Lua provided by RyzenAPI 
-- Game: AppID 3440410
addappid(3440410)
addappid(3440411, 1, "4be61b071f22a222295667491e2a284a4e9b65fc74b3e90e792d2b5fcb8cac0d")
addappid(3440412, 1, "a885b96958436f9a997d018185ade5a95fb7f82afe9031cff200072294edcf4b")
