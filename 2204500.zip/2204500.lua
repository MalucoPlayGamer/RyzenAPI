-- Lua provided by RyzenAPI
-- Game: Cthulhu: Books of Ancients Prologue

-- MAIN APPLICATION
addappid(2204500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2204501, 1, "00f66140f06f717b4af5417a614f68e70fc690f1c2a216082a740f35b1fc318f")
