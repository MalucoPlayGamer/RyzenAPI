-- Lua provided by RyzenAPI
-- Game: BLOODPUNISHED: NO TIME POR PATIENCE

-- MAIN APPLICATION
addappid(3440880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3440882,0,"a191a968f6d50f3ae796be97547ce33c8470e3e15194e853b254c935ff568e70")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
