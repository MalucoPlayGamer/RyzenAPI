-- Lua provided by RyzenAPI
-- Game: [International] AbsentedAge: Squarebound

-- MAIN APPLICATION
addappid(1615930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1615932,0,"8d00b03c4698e1c07b367d666b4d9be23deac35849356b51a85b443fd425e125")

