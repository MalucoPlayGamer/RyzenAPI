-- Lua provided by RyzenAPI
-- Game: 2472000

-- MAIN APPLICATION
addappid(2472000)
-- Game: addappid(2472000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2472001, 1, "a691c81813039fce895c11d391ac5030ff019b8cb2900b6c3a7dafea7267f5a6")
