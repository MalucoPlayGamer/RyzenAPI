-- Lua provided by RyzenAPI 
-- Game: Sap: School Days
addappid(2472000)
addappid(2472001, 1, "a691c81813039fce895c11d391ac5030ff019b8cb2900b6c3a7dafea7267f5a6")
