-- Lua provided by RyzenAPI 
-- Game: AppID 2807870
addappid(2807870)
addappid(2807871, 1, "30025749a78aca9418bc062c9e42bdb233f53aa81f754f3be3138ea96af7b056")
