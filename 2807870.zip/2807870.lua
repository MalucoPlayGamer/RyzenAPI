-- Lua provided by RyzenAPI
-- Game: Darkness Ritual: Impasse

-- MAIN APPLICATION
addappid(2807870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2807871, 1, "30025749a78aca9418bc062c9e42bdb233f53aa81f754f3be3138ea96af7b056")

