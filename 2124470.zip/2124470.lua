-- Lua provided by SkyAPI 
-- Game: 活字引擎
addappid(2124470)
addappid(2124471, 1, "4c3ec96a2aa8bbfda44115368df5c73425ae463975e95064b2cf75486007a20e")
