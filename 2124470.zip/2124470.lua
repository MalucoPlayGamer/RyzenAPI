-- Lua provided by RyzenAPI
-- Game: 活字引擎

-- MAIN APPLICATION
addappid(2124470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2124471, 1, "4c3ec96a2aa8bbfda44115368df5c73425ae463975e95064b2cf75486007a20e")
