-- Lua provided by RyzenAPI
-- Game: The Elder Scrolls Adventures: Redguard

-- MAIN APPLICATION
addappid(1812410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812411, 1, "0502c6aa05008975e99724561a19245f0fb3bb9ee53e2fe145fcb67f42c7d77b")
