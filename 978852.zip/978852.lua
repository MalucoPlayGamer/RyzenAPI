-- Lua provided by RyzenAPI
-- Game: addappid(978852)

-- MAIN APPLICATION
addappid(978852)

-- MAIN APP DEPOTS / PACKAGES
addappid(978852,0,"8af37620ba80bdd730001144e286cfa5c9d1a5a2a2f58c4a602aee08b9a35e11")
