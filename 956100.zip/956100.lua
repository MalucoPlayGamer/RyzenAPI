-- Lua provided by RyzenAPI
-- Game: AppID 956100

-- MAIN APPLICATION
addappid(956100)
-- Game: addappid(956100)

-- MAIN APP DEPOTS / PACKAGES
addappid(956101, 1, "cf24a97e0c1605c25319a5c4c11d72ab2bb8188818a789427fd558301191dfbd")
