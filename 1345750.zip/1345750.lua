-- Lua provided by RyzenAPI
-- Game: AppID 1345750

-- MAIN APPLICATION
addappid(1345750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345751, 1, "e48923e19fad5f57d2f63edabea9d8e4a43f901dbc84fbcd71d7ddb8956767e4")
