-- Lua provided by RyzenAPI
-- Game: Game: AppID 1764030

-- MAIN APPLICATION
addappid(1764030)
-- Game: addappid(1764030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1764031, 1, "ac73859b53366e4db87f5fd79a64ead2e88c25b5f1abf91ebe6e5951703b9301")
