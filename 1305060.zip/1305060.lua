-- Lua provided by RyzenAPI 
-- Game: AppID 1305060
addappid(1305060)
addappid(1305061, 1, "eabfc0c3a0cee5fda91f01affb8a11bcd0330dfd7739894844ef375e73aa6878")
