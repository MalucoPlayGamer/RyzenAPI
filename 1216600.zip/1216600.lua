-- Lua provided by RyzenAPI
-- Game: Game: QUICAL

-- MAIN APPLICATION
addappid(1216600)
-- Game: addappid(1216600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216601, 1, "5d08466b8e67a832b5cefd34b6f68c482aa4470cc5c2a7d40e49e24db435d3a8")
