-- Lua provided by SkyAPI 
-- Game: AppID 320140
addappid(320140)
addappid(320141, 1, "cdf0086eeb3d80beb86bd45680d48cb53f555103c2511d7985d903da2f2b0975")
addappid(320142, 1, "8977c37b2473d5ef3beb304d652fb9424ef0ba3aa5515b817558016ec173f1de")
addappid(320143, 1, "4ea8e2b5cd4868b3de6ecbd36d376981aa9512a01c70c80fdc88a773dac2b2f9")
