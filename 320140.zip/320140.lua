-- Lua provided by RyzenAPI
-- Game: Absolute Drift

-- MAIN APPLICATION
addappid(320140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(320141, 1, "cdf0086eeb3d80beb86bd45680d48cb53f555103c2511d7985d903da2f2b0975")
addappid(320142, 1, "8977c37b2473d5ef3beb304d652fb9424ef0ba3aa5515b817558016ec173f1de")
addappid(320143, 1, "4ea8e2b5cd4868b3de6ecbd36d376981aa9512a01c70c80fdc88a773dac2b2f9")

