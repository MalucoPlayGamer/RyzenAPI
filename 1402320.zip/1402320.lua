-- Lua provided by RyzenAPI
-- Game: Medal of Honor™: Above and Beyond

-- MAIN APPLICATION
addappid(1402320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1402321, 1, "59551c0e72daf61029457f14cdfddda74bdf53df1b099d0356bbd79bb7c511ed")

