-- Lua provided by RyzenAPI
-- Game: Submeris

-- MAIN APPLICATION
addappid(3651940)
-- Game: addappid(3651940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3651941, 1, "42c8b5ae2f70f0f23d2456860556747432b6ab666deb494118ed014624bb3f53")
