-- Lua provided by RyzenAPI
-- Game: Game: TEKKEN 8 - DEMO

-- MAIN APPLICATION
addappid(2524440)
-- Game: addappid(2524440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524441, 1, "032fd255f852233015c9501b693c1f8e09c7faae6ee46ae642111d61f5557a40")
