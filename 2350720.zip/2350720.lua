-- Lua provided by RyzenAPI
-- Game: 2350720

-- MAIN APPLICATION
addappid(2350720)
-- Game: addappid(2350720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350721, 1, "163a014822d84cae1873fafb7afd309d6bddd8193f625fe6be33edd6f3bc8ea2")
