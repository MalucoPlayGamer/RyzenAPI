-- Lua provided by RyzenAPI
-- Game: Fabledom Demo

-- MAIN APPLICATION
addappid(2289800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2289801, 1, "c991bc9ad282b9d6ad942f047f05bca3720f104d2e87c92ed6b1da5e419dafb9")
