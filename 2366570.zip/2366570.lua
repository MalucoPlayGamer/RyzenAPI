-- Lua provided by RyzenAPI
-- Game: Desta: The Memories Between - Digital Art Book

-- MAIN APPLICATION
addappid(2366570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2366571, 1, "6503d20b78534146df7884449308ad4c3fed9d707598c1ef8d7f8fc42b9a1aa6")

