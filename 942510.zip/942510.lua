-- Lua provided by RyzenAPI
-- Game: AppID 942510

-- MAIN APPLICATION
addappid(942510)

-- MAIN APP DEPOTS / PACKAGES
addappid(942511, 1, "c1ec2dc4549f4b0c25ad20c6bcd97bf759cf3a24f3a87ddba0f51add33d6069f")
