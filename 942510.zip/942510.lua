-- Lua provided by RyzenAPI
-- Game: AppID 942510

-- MAIN APPLICATION
addappid(942510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(942511, 1, "c1ec2dc4549f4b0c25ad20c6bcd97bf759cf3a24f3a87ddba0f51add33d6069f")

