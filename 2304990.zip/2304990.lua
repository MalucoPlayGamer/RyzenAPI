-- Lua provided by RyzenAPI
-- Game: Crypto Miner Tycoon Simulator Starter Edition

-- MAIN APPLICATION
addappid(2304990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304991, 1, "1a2217218286954447e9e7cd133aa65229f3d2aed769fb4d3c903fc613ae16d5")
