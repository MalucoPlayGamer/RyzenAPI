-- Lua provided by RyzenAPI
-- Game: Rainy Season

-- MAIN APPLICATION
addappid(1094420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094421, 1, "9af8f263a1dc20cab7098d4d8605521a783848791646741094cde6ecef4201b8")

