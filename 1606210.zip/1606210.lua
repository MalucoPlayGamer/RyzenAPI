-- Lua provided by RyzenAPI
-- Game: Heck Deck

-- MAIN APPLICATION
addappid(1606210)
-- Game: addappid(1606210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1606211, 1, "c75caacb6b482a886066564602439297cef4d5d08459549c2ab6ddc277fea99a")
