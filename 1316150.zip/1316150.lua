-- Lua provided by RyzenAPI 
-- Game: IVAN POE
addappid(1316150)
addappid(1316151, 1, "45684d6490028c3fbf33817628fd31b6f2ffacbed5a9f359a80c66fa63a07e4f")
addappid(1316154, 1, "9f63418a75d178000e1718dc6fef4fb44f27eb5b435f41678308a0c716776916")
