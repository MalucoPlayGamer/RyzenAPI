-- Lua provided by RyzenAPI
-- Game: IVAN POE

-- MAIN APPLICATION
addappid(1316150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1316151, 1, "45684d6490028c3fbf33817628fd31b6f2ffacbed5a9f359a80c66fa63a07e4f")
addappid(1316154, 1, "9f63418a75d178000e1718dc6fef4fb44f27eb5b435f41678308a0c716776916")

