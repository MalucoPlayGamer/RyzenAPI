-- Lua provided by RyzenAPI
-- Game: Game: AppID 506730

-- MAIN APPLICATION
addappid(506730)
-- Game: addappid(506730)

-- MAIN APP DEPOTS / PACKAGES
addappid(506731, 1, "23b0c1b18b1011501f5c96fc0c92f68575f27e5f082e0bce9ae85ac32390f37f")
addappid(506732, 1, "424aab24f962de8f8d6b4ec2b3ac93929beb8db2cc95fe53b1042e60a6160984")
addappid(506733, 1, "4633db457845ec548c1c9ab1a2ac4b836ec2858b799bf30f37ae23492e260bdb")
addappid(506734, 1, "3d88a8f9dda015932b4fbc662adef41e67ed0b1ef9369fb3c61e02e5e96fd6dc")
