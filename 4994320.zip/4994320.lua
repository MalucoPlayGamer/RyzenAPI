-- 4994320's Lua and Manifest Created by Hubcap Manifest
-- Attack of the Zektoids!
-- Created: August 21, 2026 at 22:56:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4994320) -- Attack of the Zektoids!
-- MAIN APP DEPOTS
addappid(4994321, 1, "7002eec21ffce869eb702f60d904e292f2ce47bf60e8e618d7b37f6e51cc6e21") -- Depot 4994321
setManifestid(4994321, "1168762037134664713", 517985002)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)