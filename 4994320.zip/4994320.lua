-- Lua provided by RyzenAPI
-- Game: Attack of the Zektoids!

-- MAIN APPLICATION
addappid(4994320) -- Attack of the Zektoids!

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(4994321, 1, "7002eec21ffce869eb702f60d904e292f2ce47bf60e8e618d7b37f6e51cc6e21") -- Depot 4994321

