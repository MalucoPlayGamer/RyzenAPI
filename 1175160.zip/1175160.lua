-- Lua provided by RyzenAPI
-- Game: AppID 1175160

-- MAIN APPLICATION
addappid(1175160)
-- Game: addappid(1175160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175161, 1, "8b8e8ef6db74cddc55baf1d7a4f44bc103b92fc35e762e0959931075eac4cfe8")
