-- Lua provided by RyzenAPI
-- Game: addappid(1276800)

-- MAIN APPLICATION
addappid(1276800)
addappid(2074170)
addappid(2074171)
addappid(2074172)

-- MAIN APP DEPOTS / PACKAGES
addappid(1276801, 1, "5bc865dcb4b9355a76c881857f0319f31ab8155e02a1a2d78cee13f5edea20fc")
addappid(2413100, 0, "10a1570c1b4248acb2478e2352fe6162f597422207754715fb4ed8b8fcc8de5b")
