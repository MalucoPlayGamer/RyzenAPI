-- Lua provided by RyzenAPI 
-- Game: DOCAAY
addappid(3182450)
addappid(3182451, 1, "c214ab463cfa5bca52d5cbf5d2ee584622c3e8783cd9c264173f5ff74445a08c")
