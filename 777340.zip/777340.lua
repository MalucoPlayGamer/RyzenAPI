-- Lua provided by RyzenAPI
-- Game: Animals Memory: Underwater Kingdom

-- MAIN APPLICATION
addappid(777340)

-- MAIN APP DEPOTS / PACKAGES
addappid(777341,0,"76da3b252526ea3cd88233cacc64d6aad16e1516e252bc5a613bb32ee1171ddf")

