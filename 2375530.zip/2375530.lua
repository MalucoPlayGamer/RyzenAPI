-- Lua provided by RyzenAPI
-- Game: Descenders Next

-- MAIN APPLICATION
addappid(2375530)
-- Game: addappid(2375530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375531, 1, "95ca2114d0a93ae20d7ebf2f46e6219130f1c3dabc5543fab754c7c0e56f9fb0")
