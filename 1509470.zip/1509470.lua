-- Lua provided by RyzenAPI
-- Game: The land of the nether world

-- MAIN APPLICATION
addappid(1509470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509471, 1, "2de03162ccac00f8467539bc340aad17bc94ae43d9c341afa24cdcf01e703d6b")
