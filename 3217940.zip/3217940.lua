-- Lua provided by RyzenAPI
-- Game: Fate Trigger Playtest

-- MAIN APPLICATION
addappid(3217940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3217941, 1, "0a82e156098902860aba1c0a9c3d4ef45d31f7c9f1d9fbddc4cfbe3389ec4c6a")

