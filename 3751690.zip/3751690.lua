-- Lua provided by RyzenAPI
-- Game: addappid(3751690)

-- MAIN APPLICATION
addappid(3751690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3751691, 1, "2e0621fc8704941bcbfea6710ee5f7e5d84d04427aea17219e3e40a676ce8613")
