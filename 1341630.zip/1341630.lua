-- Lua provided by RyzenAPI
-- Game: Go, Go Cowboy

-- MAIN APPLICATION
addappid(1341630)
-- Game: addappid(1341630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341631, 1, "f2c11bb93dcbcc99fa529e4232997d8554c8c9572e4d8c906bbf5f441b797e69")
