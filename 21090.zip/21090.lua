-- Lua provided by RyzenAPI
-- Game: AppID 21090

-- MAIN APPLICATION
addappid(21090)
-- Game: addappid(21090)

-- MAIN APP DEPOTS / PACKAGES
addappid(21091, 1, "1df364cb738cb58b23727f9f7e40884522090c881afb5915e7315e779f9b9472")
