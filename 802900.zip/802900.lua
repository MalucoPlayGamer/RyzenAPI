-- Lua provided by RyzenAPI 
-- Game: Hollow Steps
addappid(802900)
addappid(802901, 1, "2085ae43abb9ae6f4e2c82271745aba3b81a062af4c2f9f4b67de91a8f187302")
