-- Lua provided by RyzenAPI
-- Game: Game: Smack Studio

-- MAIN APPLICATION
addappid(1739300)
-- Game: addappid(1739300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1739301, 1, "e59c0563006a66e87c6e0fdd92b5e9fb53fb3ac408c53de6e81e4d3e8d46b99a")
