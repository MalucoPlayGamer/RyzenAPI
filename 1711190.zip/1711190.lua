-- Lua provided by RyzenAPI
-- Game: addappid(1711190)

-- MAIN APPLICATION
addappid(1711190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1711191, 1, "bb3272a682bfbffb0181a832a0c6cd0d48d347d58adedd564cee4245a61cd8db")
