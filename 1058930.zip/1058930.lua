-- Lua provided by SkyAPI 
-- Game: AppID 1058930
addappid(1058930)
addappid(1058931, 1, "d9ca73d7a39e4155b106e8d95d52f76d9f440b1ff13e07fdd1946ea4628ee425")
