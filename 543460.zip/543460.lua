-- Lua provided by RyzenAPI
-- Game: Dead Rising 4

-- MAIN APPLICATION
addappid(543460)
addappid(592700)
addappid(593050)
addappid(593051)
addappid(593052)
addappid(593053)
addappid(593054)
addappid(593055)
addappid(593056)
addappid(593057)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(543461, 1, "fd710d4ae9142dd7e6f3edc29645cbb95e8f50eac5f28840ecdf6558f5bb7404")
addappid(543464, 1, "7e9abdd73d4685c62108621fe954c39de62c9f785638a2267853d237f1c41a2b")

