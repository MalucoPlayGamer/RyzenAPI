-- Lua provided by RyzenAPI
-- Game: Game: Dead Rising 4

-- MAIN APPLICATION
addappid(543460)
-- Game: addappid(543460)

-- MAIN APP DEPOTS / PACKAGES
addappid(543461, 1, "fd710d4ae9142dd7e6f3edc29645cbb95e8f50eac5f28840ecdf6558f5bb7404")
addappid(543464, 1, "7e9abdd73d4685c62108621fe954c39de62c9f785638a2267853d237f1c41a2b")
