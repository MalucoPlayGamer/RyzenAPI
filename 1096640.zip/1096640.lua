-- 1096640's Lua and Manifest Created by Hubcap Manifest
-- Vital Signs: Emergency Department
-- Created: August 10, 2026 at 15:53:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 9

-- MAIN APPLICATION
addappid(1096640, 1, "881352813091153b86b0ca5ed4d84eb20e807777196663805bf39ee2fb5a2f70") -- Vital Signs: Emergency Department
-- MAIN APP DEPOTS
addappid(1096641, 1, "b831b42b111f4745fd6c847b7b4b0447bb433be79ffcd2b19ea84f2deb3e381b") -- Vital Signs: ED Content
setManifestid(1096641, "9060461962276576412", 276720288)
addappid(1096642, 1, "ef5150c50f1bbd7011f1a9c0d78b1e7c3d4b1dbcd406e4c76b1662df149f6430") -- Vital Signs: Emergency Department Depot (MAC)
setManifestid(1096642, "3407721584083266665", 246524811)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1156140) -- Vital Signs ED - Injuries Package 1
addappid(1156270) -- Vital Signs ED - Injuries Package 2
addappid(1156271) -- Vital Signs ED - Pediatric Common Disease Package
addappid(1156272) -- Vital Signs ED - Pediatric Rare Disease Package
addappid(1156273) -- Vital Signs ED - Pediatric Respiratory Disease Package
addappid(1161560) -- Vital Signs ED - Pediatric Digestive Disease Package
addappid(1161561) -- Vital Signs ED - Pediatric Infant Cases Package
addappid(1201820) -- Vital Signs ED - Infections Package
addappid(1201821) -- Vital Signs ED - Older Adult Cases Package
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1156140) -- Depot 1156140 (empty depot)
-- addappid(1156270) -- Depot 1156270 (empty depot)
-- addappid(1156271) -- Depot 1156271 (empty depot)
-- addappid(1156272) -- Depot 1156272 (empty depot)
-- addappid(1156273) -- Depot 1156273 (empty depot)