-- Lua provided by RyzenAPI
-- Game: Vital Signs: Emergency Department

-- MAIN APPLICATION
addappid(1156140) -- Vital Signs ED - Injuries Package 1
addappid(1156270) -- Vital Signs ED - Injuries Package 2
addappid(1156271) -- Vital Signs ED - Pediatric Common Disease Package
addappid(1156272) -- Vital Signs ED - Pediatric Rare Disease Package
addappid(1156273) -- Vital Signs ED - Pediatric Respiratory Disease Package
addappid(1161560) -- Vital Signs ED - Pediatric Digestive Disease Package
addappid(1161561) -- Vital Signs ED - Pediatric Infant Cases Package
addappid(1201820) -- Vital Signs ED - Infections Package
addappid(1201821) -- Vital Signs ED - Older Adult Cases Package
-- addappid(1156140) -- Depot 1156140 (empty depot)
-- addappid(1156270) -- Depot 1156270 (empty depot)
-- addappid(1156271) -- Depot 1156271 (empty depot)
-- addappid(1156272) -- Depot 1156272 (empty depot)
-- addappid(1156273) -- Depot 1156273 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096640, 1, "881352813091153b86b0ca5ed4d84eb20e807777196663805bf39ee2fb5a2f70") -- Vital Signs: Emergency Department
addappid(1096641, 1, "b831b42b111f4745fd6c847b7b4b0447bb433be79ffcd2b19ea84f2deb3e381b") -- Vital Signs: ED Content
addappid(1096642, 1, "ef5150c50f1bbd7011f1a9c0d78b1e7c3d4b1dbcd406e4c76b1662df149f6430") -- Vital Signs: Emergency Department Depot (MAC)

