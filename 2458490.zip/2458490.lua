-- Lua provided by RyzenAPI
-- Game: Fallen Shinobi

-- MAIN APPLICATION
addappid(2458490)
-- Game: addappid(2458490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2458491, 1, "27d3d0f1c3e000bba5c84d8fd3c883ee148ec06e067b1d9f9559065ccfb4e529")
addappid(2458492, 1, "3a2ea55a1af4cc2aab188650c6b52a6f7316f42f05127c63838117e5b4598dbe")
addappid(2458493, 1, "aad3f74c786de6ea901bc9e82b20051c0497f8110f4824bdaef44ddebea47ccb")
addappid(2458494, 1, "cc9e5a7872d6cf8739971db347550e95e648899997811ac053cf255d3b2b9e2f")
