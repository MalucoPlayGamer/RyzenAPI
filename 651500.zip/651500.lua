-- Lua provided by RyzenAPI
-- Game: AppID 651500

-- MAIN APPLICATION
addappid(651500)

-- MAIN APP DEPOTS / PACKAGES
addappid(651501, 1, "c1fba0e5494018205aff5ed94de953d06a098f1326502098678123dee8425ed7")
addappid(651502, 1, "fa97598fd2c7ebd4b65bdc74811fb2a21835cbbc4921d1765e6080ff557cd547")
addappid(651503, 1, "597edb67d60921a05391ed7b2e46229675064515189f3e474b28f1f83e8acf85")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(945790)
