-- Lua provided by RyzenAPI
-- Game: Game: AppID 1081840

-- MAIN APPLICATION
addappid(1081840)
-- Game: addappid(1081840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081841, 1, "6a3c0d8bc696c923c3efe3ad3791ba192268154040601b16335df7828ea483e1")
