-- Lua provided by RyzenAPI
-- Game: SCP-3008: Infinite Store

-- MAIN APPLICATION
addappid(4224460)

-- MAIN APP DEPOTS / PACKAGES
addappid(4224461,0,"70d58d2c93e31ae1464dd5a03d965e1e8c363ab2a2649e299f9106bd7edf07ce")

