-- Lua provided by RyzenAPI
-- Game: Beat Saber - Imagine Dragons - "Believer"

-- MAIN APPLICATION
addappid(1099561)
-- Game: addappid(1099561)

-- MAIN APP DEPOTS / PACKAGES
addappid(1099561,0,"77435e6ef6278fe9545d0222245e615a3409506054319a23d53c79496ccddf56")
