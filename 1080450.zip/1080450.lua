-- Lua provided by RyzenAPI
-- Game: 1080450

-- MAIN APPLICATION
addappid(1080450)
-- Game: addappid(1080450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1080451, 1, "8740e84b1fd1df5618ef9a873d4a70032fd097f7800719ab3dde56fe051c4d0f")
