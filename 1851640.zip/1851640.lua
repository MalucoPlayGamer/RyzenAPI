-- Lua provided by RyzenAPI
-- Game: AppID 1851640

-- MAIN APPLICATION
addappid(1851640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851641, 1, "f95716c2fac1e8e15c8e8570a2cefe39822dce5393ee8b092e3d39f7b657f91c")

