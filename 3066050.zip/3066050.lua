-- Lua provided by RyzenAPI
-- Game: addappid(3066050)

-- MAIN APPLICATION
addappid(3066050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3066050,0,"782ce55c3d99ccdc5fc1ff682408fa0b136cb75dd524a870f591d732ce9e9b76")
