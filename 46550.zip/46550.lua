-- Lua provided by RyzenAPI
-- Game: AppID 46550

-- MAIN APPLICATION
addappid(46550)

-- MAIN APP DEPOTS / PACKAGES
addappid(46551, 1, "a375712edccb2cdf7467791c7ee08b82b86faafaa3b99501a5f37533a9075913")
addappid(46552, 1, "93a3dd910a8c27617d81c4981ced7f87cb93c2447d1db7169e5f52aac1a094c4")
addappid(46553, 1, "5ed343bcbed1778e2523613bf17049b50cba53bff697308a5a616d8f039c1b73")
addappid(46554, 1, "03b5ea9946117565ec00305b8f6bdedda7ec5ced8143b634a5d6fccf20b86f78")
addappid(46555, 1, "7cf08bec54ec90ec0e512d8fbbba42b528a7c90bf8a82938ba1b2bba392ae8d9")
addappid(46556, 1, "9a8f6a7912b36e1ec0ab908e00ae19cef1a7b04782e064b3cb33bfc10fc52c5c")
addappid(46557, 1, "bd9cf60376b9da55dcb8bad048e68c2acd0020b55d87d9ab8934593ce004ed26")

