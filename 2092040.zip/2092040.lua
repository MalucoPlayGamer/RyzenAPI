-- Lua provided by RyzenAPI
-- Game: 2092040

-- MAIN APPLICATION
addappid(2092040)
addappid(2175680)
-- Game: addappid(2092040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2092041, 1, "caf04f82374a16acdab9672960c5eadb43cd54b9137d667f3141f8d69c1991e1")
