-- Lua provided by RyzenAPI 
-- Game: AppID 2019830
addappid(2019830)
addappid(2019831, 1, "92d34c187988880e425709f3b48444b3f38fe5ba9edd123fdd4b8b658af22fa6")
