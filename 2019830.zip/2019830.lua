-- Lua provided by RyzenAPI
-- Game: Game: AppID 2019830

-- MAIN APPLICATION
addappid(2019830)
-- Game: addappid(2019830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2019831, 1, "92d34c187988880e425709f3b48444b3f38fe5ba9edd123fdd4b8b658af22fa6")
