-- Lua provided by RyzenAPI
-- Game: Weird West: Definitive Edition

-- MAIN APPLICATION
addappid(1097350)
addappid(1781470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1097351, 1, "77d35d8bc6e68f2ccced7ca6a30cc5f078c00132b84bf57330f38cdea6e4702f")
addappid(1097352, 1, "d22d42504aa77b998102d10c9eba3fc812819846a43e60a95659b4cb75455462")

