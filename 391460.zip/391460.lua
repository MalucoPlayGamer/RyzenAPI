-- Lua provided by RyzenAPI 
-- Game: WARMODE
addappid(391460)
addappid(391461, 1, "0c53927df2d008bfd4fa2f9a4525108ec6c42a86f13793133f7a1b87b1119004")
