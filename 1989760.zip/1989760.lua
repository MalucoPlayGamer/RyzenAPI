-- Lua provided by RyzenAPI
-- Game: AppID 1989760

-- MAIN APPLICATION
addappid(1989760)
-- Game: addappid(1989760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989761, 1, "179baa77102a4e8a9ef108fda237b240f492841de6ac4699d94afea26aed6608")
