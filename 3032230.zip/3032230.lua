-- Lua provided by RyzenAPI
-- Game: 3032230

-- MAIN APPLICATION
addappid(3032230)
-- Game: addappid(3032230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3032231, 1, "3a11eae7c8ceedee1c4e881c9e7daf4cb61c8bc56e19dafb9bc17be887bbb06c")
