-- Lua provided by RyzenAPI
-- Game: Game: In Between

-- MAIN APPLICATION
addappid(388420)
addappid(391080)
-- Game: addappid(388420)

-- MAIN APP DEPOTS / PACKAGES
addappid(388421, 1, "0ee09d91380933987df5bf1f966c589f81167dd29a54acec40d77f144889f2c2")
addappid(388422, 1, "63296122c63853c9b408ef494b002873e38654d97e4cc04e4c34a647520e7e84")
addappid(388423, 1, "91d797c4200d3d0c0c9ff5b6bd851978e6f9485a5b9ba9815baf566f31ee2fc0")
