-- Lua provided by RyzenAPI
-- Game: Supreme Race on Highway

-- MAIN APPLICATION
addappid(1927710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1927711,0,"ec1aa3504a600f3140e550506c9a2211cf06432ebdb69ebbbd3ccd764c4a9c28")

