-- Lua provided by RyzenAPI
-- Game: TRIBE NINE

-- MAIN APPLICATION
addappid(2376580)
-- Game: addappid(2376580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2376581, 1, "9529c75bff5b33fcc97f5e0533787f0933efd77a1a6d01a721b9986aab800dd3")
