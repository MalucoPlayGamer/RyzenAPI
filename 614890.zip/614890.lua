-- Lua provided by SkyAPI 
-- Game: AppID 614890
addappid(614890)
addappid(614891, 1, "ffc93a4ac85ebcd6214ce0fda44e1a7711168c0fbc165ba4aabdbd0708945736")
