-- Lua provided by RyzenAPI
-- Game: AppID 614890

-- MAIN APPLICATION
addappid(614890)

-- MAIN APP DEPOTS / PACKAGES
addappid(614891, 1, "ffc93a4ac85ebcd6214ce0fda44e1a7711168c0fbc165ba4aabdbd0708945736")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(617380)
