-- Lua provided by RyzenAPI
-- Game: AppID 614890

-- MAIN APPLICATION
addappid(614890)

-- MAIN APP DEPOTS / PACKAGES
addappid(614891, 1, "ffc93a4ac85ebcd6214ce0fda44e1a7711168c0fbc165ba4aabdbd0708945736")

