-- Lua provided by RyzenAPI
-- Game: Cuit

-- MAIN APPLICATION
addappid(614890)
addappid(617380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(614891, 1, "ffc93a4ac85ebcd6214ce0fda44e1a7711168c0fbc165ba4aabdbd0708945736")
