-- Lua provided by RyzenAPI
-- Game: Game: Serious Sam: Siberian Mayhem

-- MAIN APPLICATION
addappid(1792250)
-- Game: addappid(1792250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1792251, 1, "591d4d1b755777aa24cd810702df4a20be18539dff139ccc38894ca0e4401acd")
addappid(1792253, 1, "0b0c877da86cd001236a26bdd71b00feaa77bbe5e8761181108769af63ae6d3b")
addappid(1792254, 1, "63c2d6f64ae0c7908cc971ff2cfb252241701434219270717faffc57c8d73e6d")
addappid(1792255, 1, "b0dd2b2491732dc2e0a716b4fe63e987bf450aa7d47c0dcff86a9efc01439f35")
