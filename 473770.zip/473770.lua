-- Lua provided by RyzenAPI
-- Game: Game: BallisticNG

-- MAIN APPLICATION
addappid(473770)
-- Game: addappid(473770)

-- MAIN APP DEPOTS / PACKAGES
addappid(473771, 1, "71af2036c0ca4d22db4835aa09ab4c787c858a885a575eb47aa8a252f49287d0")
addappid(473774, 1, "de088ed37d45bb860a3addb118fe151c3a731b363663acd192eaa7e2c2974df3")
addappid(473776, 1, "f3c370d407ce764c9627b27a60d837b8e52e38c6d6a7a9320971c75edce84ec0")
addappid(473777, 1, "03d1e67b401ec3e6ea7583be4485e2f65f607c5bdcf3562c1cd11f2a124d76b6")
addappid(473778, 1, "7da9689c80e35b9a9609b495759b2aa9453f2dc75c11d2a955c4f2f0dc5bf259")
addappid(473779, 1, "24ae779fad54913ad9625612aaf45004dad8af7ff06c9bb0dbf78e5d009158fe")
addappid(580180, 0, "44dd0a75dd62c7e7a7b9c450e31eec9983ed1c2b58afbadfbb0b1f673aaee03f")
addappid(1090110, 0, "fc2152aa742deb16ade0fce1f613eda4791f3b3c8507810b791f461d730ee656")
addappid(1165070, 0, "6366c283f1699156f85e65f2cf17428aaeecadc9689a2a8a991cb04de4566662")
