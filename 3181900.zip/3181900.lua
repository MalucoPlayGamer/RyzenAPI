-- Lua provided by RyzenAPI
-- Game: 3181900

-- MAIN APPLICATION
addappid(3181900)
-- Game: addappid(3181900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3181901, 1, "15f40be661ff2d6b3e6e03aa2b6229fbf6a3b303f63d56cd3411992be3652195")
