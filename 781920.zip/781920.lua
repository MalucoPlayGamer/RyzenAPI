-- Lua provided by RyzenAPI
-- Game: The Haunted House of Doom

-- MAIN APPLICATION
addappid(781920)

-- MAIN APP DEPOTS / PACKAGES
addappid(781922,0,"954870725e163004046914d7117df05724d7c17fcb2ab2ee20d375dd8d5bca13")

