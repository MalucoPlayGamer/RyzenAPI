-- Lua provided by RyzenAPI
-- Game: AppID 48190

-- MAIN APPLICATION
addappid(48190)
addappid(228982)

-- MAIN APP DEPOTS / PACKAGES
addappid(48191, 1, "07b66cd56c14adc4368fc36622308a39eb66af717af87f63a706fb5095cc1058")
addappid(48192, 1, "8cabeaf38cd688184bab6bdbbd34d0dbce4c751eaaf7c7f0878847359bc6543a")
addappid(48193, 1, "92734ca4ad50878769fab352e45b48131110f53494ecc4708db34b7e0ce942c1")
addappid(48194, 1, "46f9e1c0a5284ed561b7f88c1105921c5be7d5e281a1b4d6436c7ab5420ec029")
addappid(48199, 1, "5484ca1e7b74d883623916099c96dc87402fcd62247952d2fcef3e18633eadc3")
addappid(48200, 1, "74773d98cb00b55c6bf498196ef57756d25f070ab28a25eb5dd8c998930dded6")
addappid(48201, 1, "68693fb573b07160d0ea85fb3683c682d46e810a16a0013e22777dea8e4e843d")
addappid(48202, 1, "1cf3d330157141da11d9dc1ffaafaa9b72ad42a1f9418c9d994a916d1a8e5c15")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(48195)
addappid(48196)
addappid(48197)
addappid(48198)
