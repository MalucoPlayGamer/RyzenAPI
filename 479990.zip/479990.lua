-- Lua provided by RyzenAPI
-- Game: AppID 479990

-- MAIN APPLICATION
addappid(479990)

-- MAIN APP DEPOTS / PACKAGES
addappid(479991, 1, "e8177415bc9e2601e93a6cf48d516e347fdbf17d44dea92a861769c2ae7de8fe")
