-- Lua provided by RyzenAPI
-- Game: AppID 479990

-- MAIN APPLICATION
addappid(479990)

-- MAIN APP DEPOTS / PACKAGES
addappid(479991, 1, "e8177415bc9e2601e93a6cf48d516e347fdbf17d44dea92a861769c2ae7de8fe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
