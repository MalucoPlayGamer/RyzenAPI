-- Lua provided by SkyAPI 
-- Game: HITMAN 3 Playtest
addappid(2183750)
addappid(2183751, 1, "07d4faa0aa258455d9140e165f3463656cfc4ba41c8ff91eb2bef721881cf049")
