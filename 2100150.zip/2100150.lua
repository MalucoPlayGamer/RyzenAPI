-- Lua provided by RyzenAPI
-- Game: addappid(2100150)

-- MAIN APPLICATION
addappid(2100150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2100151, 1, "4c275f0c8c843b7c9d9636e1929dd2cd1ee1ce0f1d0ffb0746cc2c0468f2b161")
