-- Lua provided by RyzenAPI
-- Game: Nine-Tailed Okitsune Tale

-- MAIN APPLICATION
addappid(2348650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2348652,0,"4b7e06263c0bb8fa10ae773beb741f5039219bb79358e2b37d9b8aee5cc0b083")
addappid(2348654,0,"4e052bf5604ba1fe7d3f202eb6448d691802bbed25315dfb50d14fc642f38ea1")
addappid(2348656,0,"716f66529793af9cccdae46b5c1e1590cd005cd2aaf62c87b8bd04c8f010e6bb")

