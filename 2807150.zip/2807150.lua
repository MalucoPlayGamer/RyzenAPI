-- Lua provided by RyzenAPI
-- Game: addappid(2807150)

-- MAIN APPLICATION
addappid(2807150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2807151, 1, "1969ccb9a84fc59a5a2e4c3ea8f3ef0d00ce746e5fe05f2dec27cc4583a45de3")
