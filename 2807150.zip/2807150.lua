-- Lua provided by RyzenAPI
-- Game: Worshippers of Cthulhu

-- MAIN APPLICATION
addappid(2807150)
addappid(3912590)
addappid(3964220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2807151, 1, "1969ccb9a84fc59a5a2e4c3ea8f3ef0d00ce746e5fe05f2dec27cc4583a45de3")

