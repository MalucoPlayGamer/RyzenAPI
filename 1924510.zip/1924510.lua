-- Lua provided by RyzenAPI
-- Game: Parabellum Beta

-- MAIN APPLICATION
addappid(1924510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924511, 1, "26cb8ca92dce806ac72dc097aaa137ae9f51e69b1b5e4122853a034f00729f44")
addappid(1924512, 1, "dca67fa6422a5990d7f9a2a0634dd57d7c5617f3365e1edd3be3ed5bd243448f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
