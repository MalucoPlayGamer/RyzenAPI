-- Lua provided by RyzenAPI
-- Game: 1632260

-- MAIN APPLICATION
addappid(1632260)
-- Game: addappid(1632260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632261, 1, "505494348944a26505c7fa17014cb25fb5dace6bda4d174f356f0f0091e11d22")
