-- Lua provided by RyzenAPI
-- Game: Great Houses of Calderia

-- MAIN APPLICATION
addappid(1812910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812911, 1, "12e25bf77aa594051f466d85a8a41d7d2f4294298b8abd0a4737565158da6aa9")
addappid(2492900, 0, "ff4b259093147a855de81c2024abbd9058b6827503f2c3d6a65df07f9aa14add")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
