-- Lua provided by RyzenAPI 
-- Game: Great Houses of Calderia
addappid(1812910)
addappid(1812911, 1, "12e25bf77aa594051f466d85a8a41d7d2f4294298b8abd0a4737565158da6aa9")
addappid(2492900, 0, "ff4b259093147a855de81c2024abbd9058b6827503f2c3d6a65df07f9aa14add")
