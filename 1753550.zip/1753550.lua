-- Lua provided by RyzenAPI
-- Game: 1753550

-- MAIN APPLICATION
addappid(1753550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753550,0,"ce2abc5f63e69023f976b1c81d9dc967632ca683e8bf40ce1a2bc80ee00aa4e0")
