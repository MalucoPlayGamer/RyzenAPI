-- Lua provided by RyzenAPI
-- Game: 2741260

-- MAIN APPLICATION
addappid(2741260)
-- Game: addappid(2741260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2741261, 1, "230b041115fa631767e161da678adb5102cbd71ff034f3f2ba62e54c2c952ad5")
