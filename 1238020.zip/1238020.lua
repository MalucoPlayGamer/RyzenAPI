-- Lua provided by RyzenAPI
-- Game: AppID 1238020

-- MAIN APPLICATION
addappid(1238020)
addappid(1238030)
addappid(1317470)
addappid(1317471)
addappid(1317472)
addappid(1317473)
addappid(1317474)
addappid(1317475)
addappid(1317476)
addappid(1317481)
addappid(1317482)
addappid(1317483)
addappid(1317484)
addappid(1317485)
addappid(1317486)
addappid(1317487)
addappid(1317488)
addappid(1317489)
addappid(1317490)
addappid(1317491)
addappid(1317493)
addappid(1317494)
addappid(1317495)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
addappid(1238021, 1, "e997f7dbfb86ef4f47e7cd765bf63931f554188b44b91c3afff856e446a0e4a4")
addappid(1238022, 1, "3cb7a121dab6ddfa948d20dae46362c14551ac652e12f6a61734a512fb0bd2e7")
addappid(1238023, 1, "321db027fcd7979b66e4c0c918934ac3bf9f484159e1d6d6f131ed83064de2a9")
addappid(1238024, 1, "c5c9739b981702ca866e9fc3423da7b0bd575bdfa4fc480aa44cf6a2f60a62ef")
addappid(1238026, 1, "52596a79fa4b3ecd7d273f43eddb91a2629d8d95dfc0f4245b842c0329758286")

