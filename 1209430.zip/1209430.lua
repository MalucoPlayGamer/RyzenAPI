-- Lua provided by RyzenAPI
-- Game: 1209430

-- MAIN APPLICATION
addappid(1209430)
-- Game: addappid(1209430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209431, 1, "aba7b1e80fe5f55454a16e49289b419d14f53df36aa3d09f5c8a0e62f7101359")
