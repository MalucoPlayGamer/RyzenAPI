-- Lua provided by RyzenAPI
-- Game: Pussylympics

-- MAIN APPLICATION
addappid(3595490)
-- Game: addappid(3595490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3595491, 1, "c0ff831e315de66207c0ea2aa6ef983aa858355c8bf7d4a34c3dc2b427ecc910")
