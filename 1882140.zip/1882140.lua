-- Lua provided by RyzenAPI
-- Game: Decisive Campaigns: Ardennes Offensive

-- MAIN APPLICATION
addappid(1882140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1882141, 1, "4f85ae994707f5c3552abf83ff58493d8dbfd2a9110c0ca40ce34467a74abfa4")
addappid(1882142, 1, "ffb5ee4010812a5e0d5bbdd604e6a0a620d5e177f8195eb460298328e7fc8b09")

