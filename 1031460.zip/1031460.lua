-- Lua provided by RyzenAPI
-- Game: Game: Sail Forth

-- MAIN APPLICATION
addappid(1031460)
addappid(2737630)
-- Game: addappid(1031460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031461, 1, "ea023f87109d8f082fc3cc0500f1ffc1f5303f86947128bb4c04261197145615")
