-- Lua provided by RyzenAPI
-- Game: addappid(3593650)

-- MAIN APPLICATION
addappid(3593650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3593651, 1, "cdac6a93224f65139edcce3b7fb21a294db38b14f5cf1b5e5f96687a45f35f0b")
