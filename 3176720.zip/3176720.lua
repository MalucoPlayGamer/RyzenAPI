-- 3176720's Lua and Manifest Created by Hubcap Manifest
-- Royalty Free-For-All
-- Created: August 12, 2026 at 00:03:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3176720, 1, "d3c563d830fc0c0e2452f27ba13eabd9915ab0c96928c62252e3f83f1f510bbb") -- Royalty Free-For-All
-- MAIN APP DEPOTS
addappid(3176726, 1, "59dbf28062c276a8416a9aa78d351577bd47316e9e10c0a660eb51cf8c54c1ed") -- Depot 3176726
setManifestid(3176726, "5493733135279405929", 2468864404)
addappid(3176727, 1, "abde5eb05c7725c010753ef2891417b89534126bc3630858ce892f939142bb54") -- Depot 3176727
setManifestid(3176727, "5299288052382856015", 2513093874)
addappid(3176728, 1, "1b7a51efa98db63c2b5b18a5a25de1e4af17d66bfab5da057d5f73b7ef1e1df6") -- Depot 3176728
setManifestid(3176728, "5665171082005294647", 2467885172)