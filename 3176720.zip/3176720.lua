-- Lua provided by RyzenAPI
-- Game: Royalty Free-For-All

-- MAIN APP DEPOTS / PACKAGES
addappid(3176720, 1, "d3c563d830fc0c0e2452f27ba13eabd9915ab0c96928c62252e3f83f1f510bbb") -- Royalty Free-For-All
addappid(3176726, 1, "59dbf28062c276a8416a9aa78d351577bd47316e9e10c0a660eb51cf8c54c1ed") -- Depot 3176726
addappid(3176727, 1, "abde5eb05c7725c010753ef2891417b89534126bc3630858ce892f939142bb54") -- Depot 3176727
addappid(3176728, 1, "1b7a51efa98db63c2b5b18a5a25de1e4af17d66bfab5da057d5f73b7ef1e1df6") -- Depot 3176728

