-- Lua provided by RyzenAPI
-- Game: Crea

-- MAIN APPLICATION
addappid(280520)

-- MAIN APP DEPOTS / PACKAGES
addappid(280521, 1, "500701b7960dbb419bc87e688b1f12212f3348cb30cf5feb9d4d5d5cb506a36a")
addappid(280522, 1, "d30651fa11201fbf6b90ee4e415c0f58621b5ea4e8df079b80e9d520837ad05c")
addappid(280523, 1, "c10c8ca9c8ab70ddd3aeb11d39082328cf8a321fe9d0c3c1b4bd33beea87a324")
addappid(280524, 1, "a0d491dec7467a4f45c0728eb0ffbe5e3a2fe73d1fbbebda8234b8a62175da50")
addappid(280525, 1, "fc1dd295d09a0b1f222660e51c4db0e67241953f802f0ad6dc4f046f52b68687")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
