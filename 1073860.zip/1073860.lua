-- Lua provided by RyzenAPI
-- Game: Idle Guardians

-- MAIN APPLICATION
addappid(1073860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1073861, 1, "b6ac41ee795fa2d7b4b9b5259b3376eb747eb8f57638c374a5c1feb198a5bc59")
addappid(1073862, 1, "769df76699a602ecd6072b558817fab85b423782d4ad0f1de17063581b43dd7b")
