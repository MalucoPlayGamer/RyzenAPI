-- Lua provided by RyzenAPI
-- Game: AppID 386940

-- MAIN APPLICATION
addappid(386940)

-- MAIN APP DEPOTS / PACKAGES
addappid(386941, 1, "468fd966fb446f6751ea67a25687b0e423fea61638f6b942a41ed6f8eb7f073a")
addappid(386942, 1, "6050a40c785f778d78655ff43408f770ba44ed0f0b066bc88591e84746c3820e")
addappid(386943, 1, "eda580fb43750c674790357a3d78df444c272da9003b5a6638e44a102a8b3b63")
addappid(386944, 1, "7e59c8157c276f6ef0cbccb7ba16cad1cbe5d0a40e8938aec309c71b07715321")
addappid(386945, 1, "836fe7f1c616c04e425ce816245609bfb5cbe8ea683172027557902b9e0ddbcb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
