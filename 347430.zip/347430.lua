-- Lua provided by RyzenAPI
-- Game: Frankenstein: Master of Death

-- MAIN APPLICATION
addappid(347430)

-- MAIN APP DEPOTS / PACKAGES
addappid(347431, 1, "4a47395fef83912173ada889b02f8a2f51890a97c487da9c255ff58665645458")
addappid(347432, 1, "b9ce2fbb94bf777ef6ebba9c89275f2c9cd22f1787d1f6668726282f73bff9e9")
addappid(347433, 1, "e691037dc7f68000222e643a883fc9e0e96be17c56079fe75a836c6d70f0e483")
