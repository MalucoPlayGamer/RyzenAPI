-- Lua provided by RyzenAPI
-- Game: addappid(656820)

-- MAIN APPLICATION
addappid(656820)

-- MAIN APP DEPOTS / PACKAGES
addappid(656821, 1, "0fcaaed7faef1fd1571f51485d617362e62da3dfffa192f15aa2fe79c51fcd4c")
