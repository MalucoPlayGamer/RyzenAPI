-- Lua provided by RyzenAPI 
-- Game: AppID 656820
addappid(656820)
addappid(656821, 1, "0fcaaed7faef1fd1571f51485d617362e62da3dfffa192f15aa2fe79c51fcd4c")
