-- Lua provided by RyzenAPI
-- Game: Game: Hidden Magic Town

-- MAIN APPLICATION
addappid(1828940)
-- Game: addappid(1828940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828941, 1, "7f7f67c207a7954637034b052f4c5cf8d500601e3e59bdc2a453df0dab0f3e0d")
