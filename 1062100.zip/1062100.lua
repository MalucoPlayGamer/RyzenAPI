-- Lua provided by RyzenAPI
-- Game: 1062100

-- MAIN APPLICATION
addappid(1062100)
-- Game: addappid(1062100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062101, 1, "0933dab347f41bc054e9249715c889b7262a97dae8895c5ac0b3a8d5bfb31b93")
