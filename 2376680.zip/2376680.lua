-- Lua provided by RyzenAPI
-- Game: addappid(2376680)

-- MAIN APPLICATION
addappid(2376680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2376680,0,"6730eaccec954f07d577f306eb359a3f71288e5b3059632a7ce9b8d85a986c50")
