-- Lua provided by RyzenAPI
-- Game: Game: Snowballs

-- MAIN APPLICATION
addappid(1198860)
-- Game: addappid(1198860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1198861, 1, "420d786187677685e1f47a3c725bffb167f8257941cad595c9f66a47374f27e3")
