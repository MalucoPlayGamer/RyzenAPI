-- Lua provided by RyzenAPI 
-- Game: Snowballs
addappid(1198860)
addappid(1198861, 1, "420d786187677685e1f47a3c725bffb167f8257941cad595c9f66a47374f27e3")
