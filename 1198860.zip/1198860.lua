-- Lua provided by RyzenAPI
-- Game: Snowballs

-- MAIN APPLICATION
addappid(1198860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1198861, 1, "420d786187677685e1f47a3c725bffb167f8257941cad595c9f66a47374f27e3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
