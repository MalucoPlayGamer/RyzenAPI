-- Lua provided by RyzenAPI
-- Game: Super Clown: Lost Diamonds

-- MAIN APPLICATION
addappid(1820160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820161, 1, "b5ca0454cda90b1b2ba1971d304142eee9109a3affba05d3b111215849d1e440")
