-- Lua provided by RyzenAPI
-- Game: Super Clown: Lost Diamonds

-- MAIN APPLICATION
addappid(1820160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820161, 1, "b5ca0454cda90b1b2ba1971d304142eee9109a3affba05d3b111215849d1e440")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
