-- Lua provided by RyzenAPI
-- Game: Game: AppID 1712150

-- MAIN APPLICATION
addappid(1712150)
-- Game: addappid(1712150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1712151, 1, "7725f3211431ea4ac9ad8117d6e74155737cb0a40f9989acfe320216565b56db")
