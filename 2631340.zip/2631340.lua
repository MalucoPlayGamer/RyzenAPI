-- Lua provided by RyzenAPI
-- Game: Lewd Gym Artbook

-- MAIN APPLICATION
addappid(2631340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631341, 1, "edc26cbea089eb8f58f30e8e961e47e45b23ff5535e630ce24da8a63d1ac93cf")

