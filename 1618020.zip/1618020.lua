-- Lua provided by SkyAPI 
-- Game: Hentai War
addappid(1618020)
addappid(1618021, 1, "2e4dfb246a7f9265cdd4635a92a4fd18f22ed8f8b4c01d65e2e9a2a010fddc31")
