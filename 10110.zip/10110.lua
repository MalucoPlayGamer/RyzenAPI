-- Lua provided by RyzenAPI
-- Game: 10110

-- MAIN APPLICATION
addappid(10110)
-- Game: addappid(10110)

-- MAIN APP DEPOTS / PACKAGES
addappid(10111, 1, "056f45ae586fab78657ae4208f696042f5867f94d1673e3f3b2776a0c970aacc")
