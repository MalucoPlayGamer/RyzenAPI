-- Lua provided by SkyAPI 
-- Game: Quickie: Fantasy Adventure
addappid(2668050)
addappid(2668051, 1, "a12dbdf9ca50b91faeb8a48189ae2d537e08b970c35a96c21710d1a036d3348c")
addappid(2668052, 1, "617810698dd75ca7ff882a69af1c20565f0096a37f7c79036e84739aeeb0bbc7")
addappid(2668053, 1, "576e1308d562081c0bbd3982e138dfa93408b97300c70d5b80ad9f643a2c886c")
addappid(2701470)
