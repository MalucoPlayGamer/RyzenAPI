-- Lua provided by RyzenAPI
-- Game: addappid(876870)

-- MAIN APPLICATION
addappid(876870)

-- MAIN APP DEPOTS / PACKAGES
addappid(876872,0,"80f2bacfae1b11d1ced5d9ba3a7529b20cde8a07c4a905c2c56f8a7ecc0c25e6")
