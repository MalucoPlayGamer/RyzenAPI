-- Lua provided by RyzenAPI
-- Game: TinkerQuarry

-- MAIN APPLICATION
addappid(651280)

-- MAIN APP DEPOTS / PACKAGES
addappid(651281,0,"c6192a6d80ac6a9d45e20e515293e3efe0f292703d2396ec5fa209aa66b79bbd")

