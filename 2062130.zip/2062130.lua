-- Lua provided by RyzenAPI
-- Game: addappid(2062130)

-- MAIN APPLICATION
addappid(2062130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2062131, 1, "c2f76c4da272fbdcc3b2d64e12809127996a46ed9d762c95d2800e843f438e33")
