-- Lua provided by RyzenAPI
-- Game: 仙道孤旅

-- MAIN APPLICATION
addappid(2209790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2209791, 1, "0af2839bc5cc37a0f7dab2935bc707e44eec6e1972c3b3595b897e44083ced79")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
