-- Lua provided by RyzenAPI
-- Game: addappid(2209790)

-- MAIN APPLICATION
addappid(2209790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2209791, 1, "0af2839bc5cc37a0f7dab2935bc707e44eec6e1972c3b3595b897e44083ced79")
