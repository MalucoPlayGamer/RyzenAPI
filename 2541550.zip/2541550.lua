-- Lua provided by RyzenAPI
-- Game: One Box One Goal

-- MAIN APPLICATION
addappid(2541550)
-- Game: addappid(2541550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2541551, 1, "3a4b6ca453abaaaabcfd75b47093e50bab391189ab0f20b10ae659cd6a90619b")
