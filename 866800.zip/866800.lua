-- Lua provided by RyzenAPI
-- Game: The Walking Dead: The Final Season

-- MAIN APPLICATION
addappid(866800)

-- MAIN APP DEPOTS / PACKAGES
addappid(866801, 1, "c91a387a7c8c0709153b2a0061cc4f00d1d44dbbbc1f158def00002f4b8efc11")
addappid(866802, 1, "c700314dfc6084a3d2ac7f5d49967d8c03c9c8a81b62a1202f46c566015a3bcf")
addappid(866803, 1, "8c201fd576a32c29ff1c27ee5f9dd73724592888d43a3a7d97f10861f4c1a991")
addappid(866804, 1, "c48653e9018c515c45f97dba12ea4963090ae2fb7b5f5f33861ab9fd5440b47a")
addappid(866805, 1, "700590f3b4d153f7ff898cbd67898613dc2ad7fd41ff36c2b6bced86bb9512ee")
addappid(866806, 1, "244115f4ec833dcee56eecab569befb8e5e1708d0248cc4a03a1c6592ec045ab")
addappid(866807, 1, "63f4f9d34a381a679791d74ec3285db0346f186ad3ba6ccf7c9a1141603835b5")
addappid(866808, 1, "8956919f3e55014971c59f96a326a0db1a7dc2c98be308d129bdd47054794b64")
addappid(866809, 1, "4cf9080ed18d6712513f4d84662aa95e37675f9a970ad5ba16fb875b1a22bdfe")
addappid(943400, 0, "14177c07c9071a84f82ad890788618bbccd44959568fb41afc9e178064a5404b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
