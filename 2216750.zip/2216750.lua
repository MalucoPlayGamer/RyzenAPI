-- Lua provided by RyzenAPI
-- Game: Clay Soldiers

-- MAIN APPLICATION
addappid(2216750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216751, 1, "4a9042bf1bc0395a133ccd5f2311b3c0ece726de6cfdd1e2f59a174800d1ee53")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2312290)
addappid(2312291)
addappid(2312292)
