-- Lua provided by RyzenAPI
-- Game: Game: Ruthless Safari

-- MAIN APPLICATION
addappid(685790)
-- Game: addappid(685790)

-- MAIN APP DEPOTS / PACKAGES
addappid(685791, 1, "ee63c54eb37b8162f8f3e6d8da7f214e2eeb6dbc7be21ff68055d4aefff329f3")
