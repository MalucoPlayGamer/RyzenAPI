-- Lua provided by RyzenAPI
-- Game: AppID 581120

-- MAIN APPLICATION
addappid(581120)
-- Game: addappid(581120)

-- MAIN APP DEPOTS / PACKAGES
addappid(581121, 1, "b250f7302912e091915b19448b7b4b7eead2d3af6a9524f701bacab00b7bf85a")
addappid(581122, 1, "29a955d3715e89148f1799dbd2a961387170eea922565b6cda6c544adaab2ca2")
addappid(581123, 1, "0e47fce75fb9ce0b9daa2f386c69005c013b84a7d5ecb11a2884ff7d718c73e5")
