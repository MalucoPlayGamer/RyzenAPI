-- Lua provided by RyzenAPI
-- Game: Griptape Backbone

-- MAIN APPLICATION
addappid(581120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(581121, 1, "b250f7302912e091915b19448b7b4b7eead2d3af6a9524f701bacab00b7bf85a")
addappid(581122, 1, "29a955d3715e89148f1799dbd2a961387170eea922565b6cda6c544adaab2ca2")
addappid(581123, 1, "0e47fce75fb9ce0b9daa2f386c69005c013b84a7d5ecb11a2884ff7d718c73e5")

