-- Lua provided by RyzenAPI
-- Game: Game: Macro golf

-- MAIN APPLICATION
addappid(1472260)
-- Game: addappid(1472260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1472261, 1, "eb56c3c167f9993b5941995c470dc5e86d0a0a51526efb185d1944613d57d1db")
