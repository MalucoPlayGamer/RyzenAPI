-- Lua provided by RyzenAPI 
-- Game: AppID 619880
addappid(619880)
addappid(619881, 1, "3a26d60bf8a2cb268f63534f2b461ae7c5a9204c5dd75560bee58f222ba56338")
