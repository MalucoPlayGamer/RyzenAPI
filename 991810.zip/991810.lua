-- Lua provided by RyzenAPI
-- Game: Strategic Mind: The Pacific

-- MAIN APPLICATION
addappid(991810)
-- Game: addappid(991810)

-- MAIN APP DEPOTS / PACKAGES
addappid(991811, 1, "9f978767eee7b025b518e2945d9ff574f03d7d6828e5e070a41968237b5fe796")
