-- Lua provided by RyzenAPI
-- Game: The Game of Squids: Ultimate Parody Game

-- MAIN APPLICATION
addappid(1450210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1450212,0,"d1b6982f5c6ceb98a2e29705d1eeee78a8d6ea4a0e47c39510160bd851fe78ea")

