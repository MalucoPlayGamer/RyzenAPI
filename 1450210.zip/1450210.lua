-- Lua provided by RyzenAPI
-- Game: The Game of Squids: Ultimate Parody Game

-- MAIN APPLICATION
addappid(1450210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450212,0,"d1b6982f5c6ceb98a2e29705d1eeee78a8d6ea4a0e47c39510160bd851fe78ea")

