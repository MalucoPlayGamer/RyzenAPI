-- Lua provided by RyzenAPI
-- Game: addappid(1839880)

-- MAIN APPLICATION
addappid(1839880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839881, 1, "8e044d9d287eecba989eb3c12389ec1c29e7f9abccda063c4e038c6f2e553bc1")
