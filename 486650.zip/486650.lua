-- Lua provided by RyzenAPI
-- Game: 486650

-- MAIN APPLICATION
addappid(486650)
-- Game: addappid(486650)

-- MAIN APP DEPOTS / PACKAGES
addappid(486651, 1, "cced78d8b684fc953e1e81dffc7b06153f7ff01d0bc0791ef6d9347c6cad49e5")
