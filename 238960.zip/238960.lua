-- Lua provided by RyzenAPI 
-- Game: Path of Exile
addappid(238960)
addappid(238961, 1, "8319cbd1718aa9f81b90037841ffe877f7e6c84e18cd42995a0b78e997d056e5")
addappid(238962, 1, "d48bb40c224da3beff055dce713045517e9786f9503d6bc4910a32b29f5b7aa7")
addappid(238963, 1, "b9ae6523b9469329a2647f1c754f994b3381b188105ca5accefda3df6a2e6fc2")
