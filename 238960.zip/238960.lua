-- Lua provided by RyzenAPI
-- Game: Path of Exile

-- MAIN APPLICATION
addappid(238960)
addappid(3803470)
addappid(3803480)
addappid(3803490)
addappid(3803500)
addappid(3803510)
addappid(3803520)
addappid(4095530)
addappid(4095540)
addappid(4095550)
addappid(4095560)
addappid(4095570)
addappid(4095580)
addappid(4426790)
addappid(4426800)
addappid(4426810)
addappid(4426820)
addappid(4426830)
addappid(4426840)
addappid(4941640)
addappid(4941650)
addappid(4941660)
addappid(4941670)
addappid(4941680)
addappid(4941690)

-- MAIN APP DEPOTS / PACKAGES
addappid(238961,0,"8319cbd1718aa9f81b90037841ffe877f7e6c84e18cd42995a0b78e997d056e5")
addappid(238962,0,"d48bb40c224da3beff055dce713045517e9786f9503d6bc4910a32b29f5b7aa7")
addappid(238963,0,"b9ae6523b9469329a2647f1c754f994b3381b188105ca5accefda3df6a2e6fc2")

