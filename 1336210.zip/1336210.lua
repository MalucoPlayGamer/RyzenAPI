-- Lua provided by RyzenAPI
-- Game: The ER: Patient Typhon

-- MAIN APPLICATION
addappid(1336210)
-- Game: addappid(1336210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336211, 1, "4872bc0a8a5c3d3e7fb1ae1cfd22c8fc0c8911fd68a96149aefcd7abcd64bc03")
