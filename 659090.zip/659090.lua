-- Lua provided by RyzenAPI
-- Game: Game: AppID 659090

-- MAIN APPLICATION
addappid(659090)
-- Game: addappid(659090)

-- MAIN APP DEPOTS / PACKAGES
addappid(659091, 1, "5335009143aa24463dc4e630d4611f85fbb7604d7278198ec66f2c6453844ccf")
