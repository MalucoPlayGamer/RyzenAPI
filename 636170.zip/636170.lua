-- Lua provided by RyzenAPI
-- Game: 636170

-- MAIN APPLICATION
addappid(636170)
-- Game: addappid(636170)

-- MAIN APP DEPOTS / PACKAGES
addappid(636171, 1, "6ead59d7c6c9938cbd91417e9b91e340cf004b721e34a376570c1186613b0477")
