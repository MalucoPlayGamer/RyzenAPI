-- Lua provided by RyzenAPI
-- Game: AppID 636170

-- MAIN APPLICATION
addappid(636170)

-- MAIN APP DEPOTS / PACKAGES
addappid(636171, 1, "6ead59d7c6c9938cbd91417e9b91e340cf004b721e34a376570c1186613b0477")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
