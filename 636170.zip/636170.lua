-- Lua provided by SkyAPI 
-- Game: AppID 636170
addappid(636170)
addappid(636171, 1, "6ead59d7c6c9938cbd91417e9b91e340cf004b721e34a376570c1186613b0477")
