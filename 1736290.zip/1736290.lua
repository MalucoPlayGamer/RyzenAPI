-- Lua provided by RyzenAPI
-- Game: Crime O'Clock

-- MAIN APPLICATION
addappid(1736290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1736291, 1, "f3e8c632c00a6f004f26fd6dbae5e73a86a4401b3109e7927dc2b91951f98b33")

