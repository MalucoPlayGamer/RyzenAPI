-- Lua provided by RyzenAPI
-- Game: AppID 609760

-- MAIN APPLICATION
addappid(609760)

-- MAIN APP DEPOTS / PACKAGES
addappid(609761, 1, "f6a3802abdecfca4a1d4c04464d68cd694fa8f2b2eae674acc993769294a522b")
