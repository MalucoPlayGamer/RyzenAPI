-- Lua provided by RyzenAPI
-- Game: 1195020

-- MAIN APPLICATION
addappid(1195020)
addappid(1251870)
-- Game: addappid(1195020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1195021, 1, "f09129cec70e04532a511a18f8efd3ac4d1e9891756a91aab42f93940ce7e72a")
