-- Lua provided by RyzenAPI
-- Game: Game: Bejeweled 2 Deluxe

-- MAIN APPLICATION
addappid(3300)
-- Game: addappid(3300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3301, 1, "841f974a9a1b0bc51e4a3c33929940088fd06ab659489a4501f63bb320edb442")
addappid(3303, 1, "17798cd2a49fd2daa94233db3231e47e794c31814331bd22f64d9b650f80c638")
addappid(3304, 1, "06a1b8a4e32994712dece5f43cee1e62d8b85d138024f005268a176f11250a09")
addappid(3305, 1, "5bb2d24b2b2a0c65a068a7909beeb254b47bd01878f659c64a6ad5ba6bcda4af")
addappid(3306, 1, "47fbfc6677bdd900c422eaf127adb93a39ca504878b8b311466afb1edeb32594")
addappid(3307, 1, "c489e8313a0a36979fb58c209bc463e67ebb76ea29c324f1ec22339009c62666")
