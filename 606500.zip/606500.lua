-- Lua provided by SkyAPI 
-- Game: AppID 606500
addappid(606500)
addappid(606501, 1, "1403ec1da465ad7c7f307b1fb7922f5677340ed48ed5fa6e0f8cec95c6f2e707")
