-- Lua provided by SkyAPI 
-- Game: Dark Light
addappid(1652260)
addappid(1652261, 1, "c5f07b93cfddfd1e47f5b6771acb718703250c67f0a3edbb4ac5ce1c95793f8a")
