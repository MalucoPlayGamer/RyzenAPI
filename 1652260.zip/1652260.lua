-- Lua provided by RyzenAPI
-- Game: Dark Light

-- MAIN APPLICATION
addappid(1652260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652261, 1, "c5f07b93cfddfd1e47f5b6771acb718703250c67f0a3edbb4ac5ce1c95793f8a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
