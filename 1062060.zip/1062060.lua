-- Lua provided by RyzenAPI
-- Game: Game: AppID 1062060

-- MAIN APPLICATION
addappid(1062060)
-- Game: addappid(1062060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1062061, 1, "378512e884af2379fdcdf1e9637360d1eb44444955ae438c026c3142c8cd206d")
