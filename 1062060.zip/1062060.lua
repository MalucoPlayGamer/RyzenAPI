-- Lua provided by SkyAPI 
-- Game: AppID 1062060
addappid(1062060)
addappid(1062061, 1, "378512e884af2379fdcdf1e9637360d1eb44444955ae438c026c3142c8cd206d")
