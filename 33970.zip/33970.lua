-- Lua provided by RyzenAPI
-- Game: addappid(33970)

-- MAIN APPLICATION
addappid(33970)

-- MAIN APP DEPOTS / PACKAGES
addappid(33971, 1, "18dd91ab4b9dcbc56cdc33aff47304818342402c77ee38f0c0ce1a8889de4686")
