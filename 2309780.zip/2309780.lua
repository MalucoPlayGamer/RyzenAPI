-- Lua provided by RyzenAPI
-- Game: Game: 太古试炼 Demo

-- MAIN APPLICATION
addappid(2309780)
-- Game: addappid(2309780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2309781, 1, "1cae38b24715359e630ae3dbddb4b028934a395123f6d54623e9abdeacac9808")
