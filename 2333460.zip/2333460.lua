-- Lua provided by RyzenAPI
-- Game: Game: Volar

-- MAIN APPLICATION
addappid(2333460)
-- Game: addappid(2333460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2333461, 1, "0c08bed0b9af225d29fd82426fb4cd18ffe2f741cbf260b84a68d58e242bb6e9")
