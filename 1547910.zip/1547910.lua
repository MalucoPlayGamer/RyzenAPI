-- Lua provided by RyzenAPI
-- Game: 1547910

-- MAIN APPLICATION
addappid(1547910)
-- Game: addappid(1547910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547911, 1, "cb2b7475e40953eb6bb8e26e8552b099d9e893ff337a566b817ccea00d79c557")
