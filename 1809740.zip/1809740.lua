-- Lua provided by RyzenAPI
-- Game: FurstDate: A Furry Dating Simulator 🐾

-- MAIN APPLICATION
addappid(1809740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809741, 1, "cf835fcad3465c7b87cd99ff0c428ae1c23fa8175ca9ccd9c1a4921d1bde1e97")

