-- Lua provided by RyzenAPI
-- Game: Royal Merchant

-- MAIN APPLICATION
addappid(1087330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1087331, 1, "14431963a004b7d7f8161eccb320a7e271f6eea4e91b88f3649a5ee435973230")

