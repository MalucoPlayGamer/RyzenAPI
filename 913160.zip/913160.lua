-- Lua provided by RyzenAPI 
-- Game: AppID 913160
addappid(913160)
addappid(913161, 1, "85490faa2fd569b5a587407911d282626e4da829cfc2cf309a717b9aa250fd57")
addappid(1022200, 0, "f144b683801b261ad083a754f0026d39ac628513fc65b48fd0d7c17a5d242c0a")
