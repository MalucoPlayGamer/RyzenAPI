-- Lua provided by RyzenAPI
-- Game: Velocity Riders

-- MAIN APPLICATION
addappid(3698360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3698361, 1, "0da39b945460979322689742b12cb61d2b7cbc582029332cd241e5fe1987f528")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
