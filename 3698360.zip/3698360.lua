-- Lua provided by RyzenAPI
-- Game: Game: Velocity Riders

-- MAIN APPLICATION
addappid(3698360)
-- Game: addappid(3698360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3698361, 1, "0da39b945460979322689742b12cb61d2b7cbc582029332cd241e5fe1987f528")
