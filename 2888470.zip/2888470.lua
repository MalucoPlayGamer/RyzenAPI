-- Lua provided by RyzenAPI
-- Game: 2888470

-- MAIN APPLICATION
addappid(2888470)
-- Game: addappid(2888470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2888471, 1, "665e828f5874910f033f726b580e908a2d8cb2953cf0f88ebceac398947d78ae")
