-- Lua provided by RyzenAPI
-- Game: AppID 2732520

-- MAIN APPLICATION
addappid(2732520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2732521, 1, "badaae17456a8b55059ad11e586dac52fdc974ebb1e4e8b04852cd9cf9db52d4")

