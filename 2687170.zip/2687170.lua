-- Lua provided by RyzenAPI
-- Game: 儒林外史·范进篇 Demo

-- MAIN APPLICATION
addappid(2687170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2687171, 1, "450164bfe51bb877b8219c683273e34acf3c2dd4472dc0d2e01a2016e836af81")

