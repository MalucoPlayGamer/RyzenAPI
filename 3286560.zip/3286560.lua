-- Lua provided by RyzenAPI
-- Game: addappid(3286560)

-- MAIN APPLICATION
addappid(3286560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3286561, 1, "336b3b52c092d51859b2604ae2aca05d5b23cd331bca1f0379479e2683cfb5b7")
