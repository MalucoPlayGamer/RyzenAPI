-- Lua provided by RyzenAPI
-- Game: Neon Fantasy: Predators

-- MAIN APPLICATION
addappid(2717240)
-- Game: addappid(2717240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717241, 1, "8195cfb3c2c95276d60fbc23a66490b90c2c77965965baebb712ba748a528c8a")
