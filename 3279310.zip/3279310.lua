-- Lua provided by RyzenAPI
-- Game: addappid(3279310)

-- MAIN APPLICATION
addappid(3279310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3279311, 1, "395b82fc8c12bd2a37a0af374974bb6d3c906dc1b925cebaa96ea07b17c16596")
