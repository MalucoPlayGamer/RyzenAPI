-- Lua provided by RyzenAPI
-- Game: Eaten Alive

-- MAIN APPLICATION
addappid(403560)
addappid(406360)

-- MAIN APP DEPOTS / PACKAGES
addappid(403561, 1, "d3d711fbb04ae6fa67a2e1db8bab4dd2af7f0f6399c8dfb6f51caad7eef54c55")
