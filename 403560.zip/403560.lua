-- Lua provided by SkyAPI 
-- Game: Eaten Alive
addappid(403560)
addappid(403561, 1, "d3d711fbb04ae6fa67a2e1db8bab4dd2af7f0f6399c8dfb6f51caad7eef54c55")
addappid(406360)
