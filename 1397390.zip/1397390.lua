-- Lua provided by RyzenAPI
-- Game: The Break-In

-- MAIN APPLICATION
addappid(228988)
addappid(1397390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397392,0,"d0d92dae796cdbdb47de6b3d30879a3791866a281b5c2ccf5da7c90033324fc6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
