-- 4423110's Lua and Manifest Created by Hubcap Manifest
-- Don’t Pull Me!
-- Created: August 23, 2026 at 04:19:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4423110, 1, "6e1178ee654585fcf1f496bb977b75d31bd60058c5880f85a1cc413c247f1155") -- Don’t Pull Me!
-- MAIN APP DEPOTS
addappid(4423112, 1, "0ccb10c87f47b5451fc4fe1b223854da81b4417bdf5ce2df5cfb6276ff08cf45") -- Depot 4423112
setManifestid(4423112, "3304673046264506790", 1453705018)
addappid(4423113, 1, "f2aa6b4f8b28b6b24d8c9a3fa0c4602df4c5dfcebb2fddd7385df9372ea9827f") -- Depot 4423113
setManifestid(4423113, "125141259433708493", 1302270456)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)