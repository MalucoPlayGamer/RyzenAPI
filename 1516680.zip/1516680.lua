-- Lua provided by RyzenAPI 
-- Game: AppID 1516680
addappid(1516680)
addappid(1516681, 1, "7bd718dfbcca0aa1ed9d685f4adf8aea93b929908133a2993e91718e5962ef69")
