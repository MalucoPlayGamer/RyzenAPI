-- Lua provided by RyzenAPI
-- Game: Deceive Inc.

-- MAIN APPLICATION
addappid(820520)
addappid(2283550)
addappid(2285910)
addappid(2851380)
addappid(2851390)
addappid(2851400)
addappid(3038170)

-- MAIN APP DEPOTS / PACKAGES
addappid(820521,0,"afd495a7aca2ae1065ca8255c2e7955599b6d62d9431f9de332981638179361f")

