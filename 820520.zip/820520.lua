-- Lua provided by RyzenAPI
-- Game: 820520

-- MAIN APPLICATION
addappid(820520)
-- Game: addappid(820520)

-- MAIN APP DEPOTS / PACKAGES
addappid(820521, 1, "afd495a7aca2ae1065ca8255c2e7955599b6d62d9431f9de332981638179361f")
