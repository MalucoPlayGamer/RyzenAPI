-- Lua provided by RyzenAPI
-- Game: Fantasia of the Wind 2 风之幻想曲 第二部

-- MAIN APPLICATION
addappid(1006400)
addappid(1007341)

-- MAIN APP DEPOTS / PACKAGES
addappid(1006401, 1, "e18fb5776d0cfeef46eef762368c16490373c431a50025b65e9fbb63425e691b")

