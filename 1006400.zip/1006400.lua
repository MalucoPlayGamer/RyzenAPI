-- Lua provided by SkyAPI 
-- Game: AppID 1006400
addappid(1006400)
addappid(1006401, 1, "e18fb5776d0cfeef46eef762368c16490373c431a50025b65e9fbb63425e691b")
