-- Lua provided by RyzenAPI
-- Game: addappid(1006400)

-- MAIN APPLICATION
addappid(1006400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1006401, 1, "e18fb5776d0cfeef46eef762368c16490373c431a50025b65e9fbb63425e691b")
