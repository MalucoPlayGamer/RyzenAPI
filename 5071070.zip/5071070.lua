-- Lua provided by RyzenAPI
-- Game: City 33

-- MAIN APPLICATION
addappid(5071070) -- City 33

-- MAIN APP DEPOTS / PACKAGES
addappid(5071071, 1, "ea06b3380f81b3ccef0e4be806a71362dfcdc2885e4d761362d068c208e3ba9c") -- Depot 5071071

