-- Lua provided by RyzenAPI
-- Game: METAL GEAR SOLID 3: Snake Eater - Master Collection Version

-- MAIN APPLICATION
addappid(2131650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2131651, 1, "0073fe0583da7d2329aee1439801c51c48ee664444fa0f669155c1e51d331fe8")
addappid(2131652, 1, "65ab5efe73d2ad271b6038a0632621f95755aa433619ed4223eb115634d035ff")
addappid(2131654, 1, "5a546c87b8553c36c0b7c7ad9ea7aed11c225ff288a3077f0ce9236dababfa09")
addappid(2314280, 0, "1741d8bab672cba92e86f4f476a811e7e9e39685a9269a7040437c907492d334")
addappid(2314281, 0, "5267831e9c74001101fdcd5e5987108b01c2c9fc3a3ad44c53f9bce2a3468e77")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2314282)
