-- Lua provided by RyzenAPI
-- Game: Wake the Beacon

-- MAIN APPLICATION
addappid(4650570) -- Wake the Beacon

-- MAIN APP DEPOTS / PACKAGES
addappid(4650571, 1, "6c3c2520651751c815cb3bfc20060c0bc7e20a1cd07a967d493b0f1157be0193") -- Depot 4650571

