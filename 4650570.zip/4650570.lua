-- 4650570's Lua and Manifest Created by Hubcap Manifest
-- Wake the Beacon
-- Created: August 17, 2026 at 16:15:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4650570) -- Wake the Beacon
-- MAIN APP DEPOTS
addappid(4650571, 1, "6c3c2520651751c815cb3bfc20060c0bc7e20a1cd07a967d493b0f1157be0193") -- Depot 4650571
setManifestid(4650571, "7712482594407952322", 162675712)