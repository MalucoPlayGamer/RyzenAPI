-- Lua provided by RyzenAPI
-- Game: The NewZealand Story: Untold Adventure

-- MAIN APPLICATION
addappid(4193730)

-- MAIN APP DEPOTS / PACKAGES
addappid(4193731,0,"187beac403d0f6586645d844f8032050da54be2731577905805d302bce330785")

