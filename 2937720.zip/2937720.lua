-- Lua provided by SkyAPI 
-- Game: Jötunn's Greed Playtest
addappid(2937720)
addappid(2937721, 1, "58ffc8acfdf75a85b0b0cde4386a2c2d495f5f656b483833474b66a7f345677f")
