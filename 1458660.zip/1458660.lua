-- Lua provided by RyzenAPI
-- Game: addappid(1458660)

-- MAIN APPLICATION
addappid(1458660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1458661, 1, "b960ff9ce0d8e0ff9007df72c6066b49be1db9e7f07c4385d3dc0d626095ac07")
