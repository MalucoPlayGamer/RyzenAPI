-- Lua provided by RyzenAPI
-- Game: From The Other Side

-- MAIN APPLICATION
addappid(3247990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3247991, 1, "674d9061e37184f51897c22eb85d176015577b07eaa4fbf235351cc7fb59d56f")

