-- Lua provided by SkyAPI 
-- Game: From The Other Side
addappid(3247990)
addappid(3247991, 1, "674d9061e37184f51897c22eb85d176015577b07eaa4fbf235351cc7fb59d56f")
