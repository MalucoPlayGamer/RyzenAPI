-- Lua provided by SkyAPI 
-- Game: Folklands
addappid(2282890)
addappid(2282891, 1, "7c9c7c8375fb8bd11b85c3299da5ea2fbb018ab5740c2b4dbd5f94063f6e1413")
addappid(2282892, 1, "79c266a32e4385c60f6094869d0074d5135c7b4863d15b4c704d1c789ef44fa3")
addappid(2282893, 1, "785b1a60b2b10dd7c957ef2d68bafea1e02e0c06d8d55150f4687fc05ce9ee7c")
addappid(3596590)
