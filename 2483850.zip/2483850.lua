-- Lua provided by RyzenAPI
-- Game: 2483850

-- MAIN APPLICATION
addappid(2483850)
-- Game: addappid(2483850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2483851, 1, "0a60cbbe629a18e2bb9f893067cbcb33bc004e1a4996d2d1002d9b522e4d4cb4")
