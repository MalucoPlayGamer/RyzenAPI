-- Lua provided by RyzenAPI 
-- Game: Wizard of Legend 2
addappid(2193540)
addappid(2193541, 1, "0b38693b47350ed1df704c576d67dd2d05ce6e286543e940c52a95a6f7b3b812")
