-- Lua provided by RyzenAPI 
-- Game: Take the Cake
addappid(500440)
addappid(500441, 1, "7417b8a3931fee2d8716375ff8d00f62e547ca267424cf30458ff9c26f0e7051")
