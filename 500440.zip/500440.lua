-- Lua provided by RyzenAPI
-- Game: 500440

-- MAIN APPLICATION
addappid(500440)
-- Game: addappid(500440)

-- MAIN APP DEPOTS / PACKAGES
addappid(500441, 1, "7417b8a3931fee2d8716375ff8d00f62e547ca267424cf30458ff9c26f0e7051")
