-- Lua provided by RyzenAPI
-- Game: 1999090

-- MAIN APPLICATION
addappid(1999090)
-- Game: addappid(1999090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999091, 1, "b4a83cf329ec4e881a53bac84ab303829dd666990df2c5a15c4649fd6663360c")
