-- Lua provided by RyzenAPI
-- Game: Ultimate Fighters

-- MAIN APPLICATION
addappid(1999090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1999091, 1, "b4a83cf329ec4e881a53bac84ab303829dd666990df2c5a15c4649fd6663360c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
