-- Lua provided by RyzenAPI
-- Game: heXtreaming:Deep

-- MAIN APPLICATION
addappid(2106050) -- heXtreaming:Deep

-- MAIN APP DEPOTS / PACKAGES
addappid(2106051, 1, "fc0e2e205356ec748f3a57c9ee69b10b10228c4d35cd2df0bb5e0206c88ac31a") -- Depot 2106051



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5075200)
addappid(5075210)
