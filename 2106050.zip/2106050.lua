-- 2106050's Lua and Manifest Created by Hubcap Manifest
-- heXtreaming:Deep
-- Created: August 15, 2026 at 22:35:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2106050) -- heXtreaming:Deep
-- MAIN APP DEPOTS
addappid(2106051, 1, "fc0e2e205356ec748f3a57c9ee69b10b10228c4d35cd2df0bb5e0206c88ac31a") -- Depot 2106051
setManifestid(2106051, "709519811886677295", 2954320324)