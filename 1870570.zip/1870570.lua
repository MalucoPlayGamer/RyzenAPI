-- Lua provided by RyzenAPI
-- Game: Hyper Road Carnage

-- MAIN APPLICATION
addappid(1870570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1870571, 1, "8f65878556ca074911e2829867452148c139b20bfe82dfeff209d9ea724946b8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
