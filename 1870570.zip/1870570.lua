-- Lua provided by SkyAPI 
-- Game: Hyper Road Carnage
addappid(1870570)
addappid(1870571, 1, "8f65878556ca074911e2829867452148c139b20bfe82dfeff209d9ea724946b8")
