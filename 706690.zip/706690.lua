-- Lua provided by RyzenAPI
-- Game: Megatronic Void

-- MAIN APPLICATION
addappid(706690)

-- MAIN APP DEPOTS / PACKAGES
addappid(706691,0,"168cc8c04c4b0880b26e78ab681f1cb4de99ffe8a0a2c0fa0d523deeefce51e9")

