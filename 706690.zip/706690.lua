-- Lua provided by RyzenAPI
-- Game: Megatronic Void

-- MAIN APPLICATION
addappid(706690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(706691,0,"168cc8c04c4b0880b26e78ab681f1cb4de99ffe8a0a2c0fa0d523deeefce51e9")

