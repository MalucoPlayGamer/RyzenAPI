-- Lua provided by RyzenAPI
-- Game: Sheva

-- MAIN APP DEPOTS / PACKAGES
addappid(3337620, 1, "fed416336de8c7fe63aa93476fb1a4acd97cfff8f16dc2e42bd0b82453615bb5") -- Sheva
addappid(3337621, 1, "f64a2182cf91926b3fcbac18ec9d2ccb37ccd9a65aad133444758d16a8d9b707") -- Depot 3337621
addappid(3337623, 1, "36cdbc7df4261ba8441cefbcba70bbd9ac20b0e3da1a28b1a19ae1bfa81f5ecf") -- Depot 3337623
addappid(3337624, 1, "29bd6bdec89a51425a7098ddd636865d5ad8599e0a2bcfd290cf79e2e517ff9a") -- Depot 3337624
addappid(3337625, 1, "0b4100b4c080af869628d738e935c43ce5f725b7eecc65cbecf5753433274723") -- Depot 3337625

