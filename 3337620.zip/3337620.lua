-- 3337620's Lua and Manifest Created by Hubcap Manifest
-- Sheva
-- Created: August 14, 2026 at 11:14:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3337620, 1, "fed416336de8c7fe63aa93476fb1a4acd97cfff8f16dc2e42bd0b82453615bb5") -- Sheva
-- MAIN APP DEPOTS
addappid(3337621, 1, "f64a2182cf91926b3fcbac18ec9d2ccb37ccd9a65aad133444758d16a8d9b707") -- Depot 3337621
setManifestid(3337621, "4174895883198363774", 1187544140)
addappid(3337623, 1, "36cdbc7df4261ba8441cefbcba70bbd9ac20b0e3da1a28b1a19ae1bfa81f5ecf") -- Depot 3337623
setManifestid(3337623, "4665872907057777228", 1103430814)
addappid(3337624, 1, "29bd6bdec89a51425a7098ddd636865d5ad8599e0a2bcfd290cf79e2e517ff9a") -- Depot 3337624
setManifestid(3337624, "6265213463336976649", 1007844437)
addappid(3337625, 1, "0b4100b4c080af869628d738e935c43ce5f725b7eecc65cbecf5753433274723") -- Depot 3337625
setManifestid(3337625, "5207970750029744477", 974272258)