-- Lua provided by RyzenAPI
-- Game: addappid(1477450)

-- MAIN APPLICATION
addappid(1477450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477451, 1, "dc99942037b229e893828ec41fc658278eed61a95771cc3bd9ceb52e800cf105")
