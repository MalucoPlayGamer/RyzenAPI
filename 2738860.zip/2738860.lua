-- Lua provided by RyzenAPI 
-- Game: Seductive Shadows
addappid(2738860)
addappid(2738861, 1, "3d2529d650689bbe9ab6604b9c2fed62c169c874a50653b5c666e3d8813c5d8b")
