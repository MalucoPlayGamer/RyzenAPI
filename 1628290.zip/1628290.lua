-- Lua provided by RyzenAPI
-- Game: The Last Spell - Original Soundtrack

-- MAIN APPLICATION
addappid(1628290)
-- Game: addappid(1628290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1628292,0,"983af86878cd73d94aadf987f6483f85c8656c351a11937b1142553d07b7ccd3")
