-- Lua provided by RyzenAPI
-- Game: The Away Team: Lost Exodus

-- MAIN APPLICATION
addappid(426290)

-- MAIN APP DEPOTS / PACKAGES
addappid(426291, 1, "7b10ae8d6e1da654a90b66ca8a7b077a5d66011ed0508ec14fea04b7db70f4ed")
addappid(426295, 1, "677f0185a35d848e073e8c870984bf551f4b2af0ed0d4cb2cadb81249b55e75a")
addappid(426297, 1, "6b7a926de419bddfa614bbe7024d14792a90c9ef71c007f932cfb3286455b093")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
