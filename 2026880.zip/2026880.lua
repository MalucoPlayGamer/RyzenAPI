-- Lua provided by RyzenAPI
-- Game: Game: Deadly Night

-- MAIN APPLICATION
addappid(2026880)
-- Game: addappid(2026880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2026881, 1, "e9c48858e8c9f19392a7e1a92ea52d3c9258066b5350c65e1e48cbccc5342967")
