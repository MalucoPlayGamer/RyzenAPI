-- Lua provided by RyzenAPI
-- Game: AppID 452180

-- MAIN APPLICATION
addappid(452180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(452181, 1, "6008cf6d0ea8db120a74c944820ecc8499effffc743d63f0d975e2c5e738c04c")

