-- Lua provided by RyzenAPI
-- Game: addappid(452180)

-- MAIN APPLICATION
addappid(452180)

-- MAIN APP DEPOTS / PACKAGES
addappid(452181, 1, "6008cf6d0ea8db120a74c944820ecc8499effffc743d63f0d975e2c5e738c04c")
