-- Lua provided by RyzenAPI
-- Game: RuneScape: The Orchestral Collection

-- MAIN APPLICATION
addappid(1418170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418172,0,"aa6d03907ccbaefcdd305021a5f4631ef6f0f4fb1b62ad13d60c80c2a0b009d5")
addappid(1418173,0,"7af19425d08f6555a79af58773b526bd8b4548c204a777c810b7777621c72680")
