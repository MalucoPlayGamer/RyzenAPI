-- Lua provided by RyzenAPI
-- Game: FPV Battleground: Combat Drone Simulator 

-- MAIN APPLICATION
addappid(3273420)
addappid(4296580)
addappid(4381050)
addappid(4543450)
addappid(4543460)
addappid(4804780)
addappid(4804790)
addappid(4804800)
addappid(4804810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3273421,0,"4e4efe7954c8629f3b6c6932d5caf2befadccfcf820cb9c4871867095e7818ab")

