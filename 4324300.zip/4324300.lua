-- Lua provided by RyzenAPI
-- Game: My Little Cosmos

-- MAIN APPLICATION
addappid(4324300) -- My Little Cosmos
addappid(4358230) -- My Little Cosmos Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4324301, 1, "06afe742de370ce9310bf05a7ed3c44940d5368cfdb634028f0aee46499457a2") -- Depot 4324301

