-- 4324300's Lua and Manifest Created by Hubcap Manifest
-- My Little Cosmos
-- Created: August 07, 2026 at 23:04:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4324300) -- My Little Cosmos
-- MAIN APP DEPOTS
addappid(4324301, 1, "06afe742de370ce9310bf05a7ed3c44940d5368cfdb634028f0aee46499457a2") -- Depot 4324301
setManifestid(4324301, "1195071083315042611", 831819595)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4358230) -- My Little Cosmos Supporter Pack