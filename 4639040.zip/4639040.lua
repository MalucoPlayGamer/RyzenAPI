-- 4639040's Lua and Manifest Created by Hubcap Manifest
-- MINERALS: Deep Core Mining
-- Created: August 12, 2026 at 09:12:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4639040) -- MINERALS: Deep Core Mining
-- MAIN APP DEPOTS
addappid(4639041, 1, "10de8bc4f8c98bc1982a14e813ba008234af6a0a761835df4a6ee5456e2f68c2") -- Depot 4639041
setManifestid(4639041, "5385044286339968345", 445617109)