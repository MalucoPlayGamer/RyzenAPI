-- Lua provided by RyzenAPI
-- Game: MINERALS: Deep Core Mining

-- MAIN APPLICATION
addappid(4639040) -- MINERALS: Deep Core Mining

-- MAIN APP DEPOTS / PACKAGES
addappid(4639041, 1, "10de8bc4f8c98bc1982a14e813ba008234af6a0a761835df4a6ee5456e2f68c2") -- Depot 4639041

