-- Lua provided by RyzenAPI
-- Game: addappid(1048900)

-- MAIN APPLICATION
addappid(1048900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048901, 1, "0c895c646abdf7c559db0dc722b6cfd3377f2f307eac2be8f9e9f5b5d66e71c5")
