-- Lua provided by RyzenAPI
-- Game: 403220

-- MAIN APPLICATION
addappid(403220)

-- MAIN APP DEPOTS / PACKAGES
addappid(403220,0,"7fd2808f0b35bd3e7f96c0e3bd8d8a10f9be82bc96d6bfc1198edf74857bfdc8")
