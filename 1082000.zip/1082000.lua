-- Lua provided by RyzenAPI
-- Game: A Night at the Races

-- MAIN APPLICATION
addappid(1082000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1082001, 1, "9246bb8d3bed4cc802d0edd07a6fdc990286b1d0bfe707965d5a485763eacb62")

