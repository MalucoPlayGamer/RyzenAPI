-- Lua provided by RyzenAPI
-- Game: addappid(2804620)

-- MAIN APPLICATION
addappid(2804620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804621, 1, "86e0d9bab1a9a0539f170e26da7e45fb5e204012ec8faba4c542f9b682323fbb")
