-- Lua provided by RyzenAPI
-- Game: addappid(1280010)

-- MAIN APPLICATION
addappid(1280010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280011, 1, "d5ef1a938fcf4ced0bfef35883a2985666650760646dba0d589a693e41b87dde")
