-- Lua provided by RyzenAPI
-- Game: GOT Simulator

-- MAIN APPLICATION
addappid(2856870)
-- Game: addappid(2856870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2856871, 1, "f58fc3f060cd9b6d6fc52b6e16c5a1e7c2ce6ba4113c4baf222c90bbe1b2190f")
