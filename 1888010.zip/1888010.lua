-- Lua provided by RyzenAPI
-- Game: Towards Future

-- MAIN APPLICATION
addappid(1888010)
addappid(1888090)

