-- Lua provided by RyzenAPI
-- Game: Towards Future

-- MAIN APPLICATION
addappid(1888010)
