-- Lua provided by RyzenAPI
-- Game: Towards Future

-- MAIN APPLICATION
addappid(1888010)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1888090)
