-- Lua provided by RyzenAPI
-- Game: Epic Vampire

-- MAIN APPLICATION
addappid(1945970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945971, 1, "e3a1b59e333ec1fcf2b9c7f2d47ee9ce1019adb50a1c4cae21e986f4ae2d2cbc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
