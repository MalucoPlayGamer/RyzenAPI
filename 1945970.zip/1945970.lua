-- Lua provided by RyzenAPI
-- Game: addappid(1945970)

-- MAIN APPLICATION
addappid(1945970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945971, 1, "e3a1b59e333ec1fcf2b9c7f2d47ee9ce1019adb50a1c4cae21e986f4ae2d2cbc")
