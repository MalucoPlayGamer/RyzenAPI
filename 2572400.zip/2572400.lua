-- Lua provided by RyzenAPI 
-- Game: Kingdom, Dungeon, and Hero
addappid(2572400)
addappid(2572401, 1, "6b02f6c33c4cff2fa7972bfb8a9c87cea0a6c9fd70e1d6db6bd68b442b46c2b7")
