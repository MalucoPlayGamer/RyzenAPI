-- Lua provided by RyzenAPI
-- Game: Kisaragi no Hougyoku

-- MAIN APPLICATION
addappid(502990)
-- Game: addappid(502990)

-- MAIN APP DEPOTS / PACKAGES
addappid(502991, 1, "da2a152887a46f31148e1a6d1e6648ff48f95976e5ea41db56ccbb094d762fbd")
