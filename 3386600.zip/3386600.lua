-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - UI Icon Set

-- MAIN APPLICATION
addappid(3386600)
-- Game: addappid(3386600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3386600,0,"2eac132ff85cbba6f809dc936a80030cc967ade2fcfdefa0d65a8ad5a410d461")
