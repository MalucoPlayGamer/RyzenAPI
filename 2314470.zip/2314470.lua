-- Lua provided by RyzenAPI
-- Game: addappid(2314470)

-- MAIN APPLICATION
addappid(2314470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314471, 1, "e63d3f6bb2e8cfbfe66d921ece43fc2948e91f65815a9a098cf2bb4f3f0c9a91")
