-- Lua provided by RyzenAPI
-- Game: Minigames Master

-- MAIN APPLICATION
addappid(2314470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2314471, 1, "e63d3f6bb2e8cfbfe66d921ece43fc2948e91f65815a9a098cf2bb4f3f0c9a91")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
