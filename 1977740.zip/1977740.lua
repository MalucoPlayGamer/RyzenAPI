-- Lua provided by RyzenAPI
-- Game: My Little Sister's Special Place

-- MAIN APPLICATION
addappid(1977740)
-- Game: addappid(1977740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1977741, 1, "e5bba55019ded21b8e14dfc2a768239cdc7fd5ba11bd35f21668b4b7516ce18d")
