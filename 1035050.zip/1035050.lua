-- Lua provided by RyzenAPI
-- Game: Alt-Frequencies

-- MAIN APPLICATION
addappid(1035050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035051, 1, "c78f6a03ac66fd2538667c45efa3e87f156e7eefb1b3c761b4ea7a1be3bd63b3")
addappid(1035052, 1, "302fda2c2f4b6242844b1d568b97b0fcc9828d197167295cc74f67416053834b")
addappid(1035053, 1, "e91012987bbe217dde3f3dbfc5891aa42e48710a4b7bfdf1630e3486ede3f4d6")

