-- Lua provided by RyzenAPI
-- Game: Game: Draconia

-- MAIN APPLICATION
addappid(1295900)
-- Game: addappid(1295900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295901, 1, "c0d279495752c84a0904db347b03b01004415fc4e31a7664f0f9f4755102b56a")
addappid(1295902, 1, "1885c9965c99d8d841eae4379c7addfae49fe24f53f2177ddac623d6d19ebda1")
