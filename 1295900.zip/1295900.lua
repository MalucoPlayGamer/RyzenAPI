-- Lua provided by RyzenAPI
-- Game: Draconia

-- MAIN APPLICATION
addappid(1295900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295901, 1, "c0d279495752c84a0904db347b03b01004415fc4e31a7664f0f9f4755102b56a")
addappid(1295902, 1, "1885c9965c99d8d841eae4379c7addfae49fe24f53f2177ddac623d6d19ebda1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
