-- Lua provided by RyzenAPI
-- Game: Battle Jacked

-- MAIN APPLICATION
addappid(1367980)
-- Game: addappid(1367980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367981, 1, "71126485e95f9341acf25588c4122534dccb46ddd6d6906fc681a8b8d5744379")
