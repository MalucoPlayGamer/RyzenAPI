-- Lua provided by RyzenAPI
-- Game: Battle Jacked

-- MAIN APPLICATION
addappid(1367980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367981, 1, "71126485e95f9341acf25588c4122534dccb46ddd6d6906fc681a8b8d5744379")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
