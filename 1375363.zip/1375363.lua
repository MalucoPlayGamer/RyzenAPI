-- Lua provided by RyzenAPI
-- Game: Beat Saber - Linkin Park - "Given Up"

-- MAIN APPLICATION
addappid(1375363)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375363,0,"01188e2f653465a4cccf2d7c03a6576e1b924b727f519fc14e2057e945c5e5b9")

