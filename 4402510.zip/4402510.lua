-- 4402510's Lua and Manifest Created by Hubcap Manifest
-- Deep Sea Idle: Infinity Abyss
-- Created: July 26, 2026 at 13:14:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4402510) -- Deep Sea Idle: Infinity Abyss
-- MAIN APP DEPOTS
addappid(4402511, 1, "58590fcc44462ff6882fa99bf2fbc41ac93cfe536c813f3efeaff0e03595205c") -- Depot 4402511
setManifestid(4402511, "3160854847004235541", 484713922)