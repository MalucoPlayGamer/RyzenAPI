-- Lua provided by RyzenAPI
-- Game: illWill

-- MAIN APPLICATION
addappid(1567000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567001, 1, "398b0e54ad1cd83c04e5d676f9405a9346d59fe851ac0c5ea78b218511553d51")

