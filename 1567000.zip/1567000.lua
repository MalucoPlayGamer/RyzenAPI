-- Lua provided by RyzenAPI
-- Game: illWill

-- MAIN APPLICATION
addappid(1567000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1567001, 1, "398b0e54ad1cd83c04e5d676f9405a9346d59fe851ac0c5ea78b218511553d51")

