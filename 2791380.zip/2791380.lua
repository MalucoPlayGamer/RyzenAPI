-- Lua provided by RyzenAPI
-- Game: addappid(2791380)

-- MAIN APPLICATION
addappid(2791380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791381, 1, "288aa6b4a9d4e405cb1a9279bbfb871f36fe1696186e0c4def1e02394340eb51")
