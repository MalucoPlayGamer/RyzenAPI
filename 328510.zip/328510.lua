-- Lua provided by RyzenAPI
-- Game: setManifestid(328512,"8507099481698448722")

-- MAIN APPLICATION
addappid(328510)
-- Game: addappid(328510)

-- MAIN APP DEPOTS / PACKAGES
addappid(328512,0,"fbd32d8c4d35cafceabdba191e8cbec79cbf5209e471ac780b95b43111fb1589")
