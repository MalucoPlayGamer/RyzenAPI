-- Lua provided by RyzenAPI
-- Game: 328510

-- MAIN APPLICATION
addappid(328510)

-- MAIN APP DEPOTS / PACKAGES
addappid(328512,0,"fbd32d8c4d35cafceabdba191e8cbec79cbf5209e471ac780b95b43111fb1589")

