-- Lua provided by RyzenAPI
-- Game: 206760

-- MAIN APPLICATION
addappid(206760)
-- Game: addappid(206760)

-- MAIN APP DEPOTS / PACKAGES
addappid(206761, 1, "f1dbf7f42ce3daa1e64925117efbc41cd74cde110855b8ad366fca050c7a029a")
addappid(206762, 1, "9afa74abbe066349fd5f54cb97beaf9400c6cd558dfb723991411b8e255945d0")
addappid(206763, 1, "5fdd48ecdd66e030921c3b9ab2b83be4d3aa1e919591e9eed0545715c23a0e1a")
addappid(206764, 1, "b0a6e3dbdceb72c9324308c0deaa8f1da8db200706c972908bedee6755f8be75")
addappid(206765, 1, "a4c48943c0cdc04b59621eb42f5d2e536aa5e4df904eb7a90df815890c72e8fd")
