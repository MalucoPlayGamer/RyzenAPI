-- Lua provided by RyzenAPI
-- Game: addappid(3464020)

-- MAIN APPLICATION
addappid(3464020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3464021, 1, "5fa06b011b183e4b78a990af3874f5521a3369846510a9a2bdd00ecce89230a8")
