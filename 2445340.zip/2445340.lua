-- Lua provided by RyzenAPI
-- Game: Love n Life: Lucky Teacher

-- MAIN APPLICATION
addappid(2445340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2445341, 1, "abd0d78162f8690db2b855ea021f3a15eef0d8150644b9a529e5fb3aaa21d326")

