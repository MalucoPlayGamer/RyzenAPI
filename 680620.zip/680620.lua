-- Lua provided by RyzenAPI
-- Game: 680620

-- MAIN APPLICATION
addappid(680620)
addappid(739160)
-- Game: addappid(680620)

-- MAIN APP DEPOTS / PACKAGES
addappid(680621, 1, "1618f4342c5aff1e958d99249ebe6c1df74a5324c15bf6f66a6801e7f8dfe059")
