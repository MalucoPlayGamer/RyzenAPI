-- Lua provided by RyzenAPI
-- Game: 8infinity

-- MAIN APPLICATION
addappid(526540)

-- MAIN APP DEPOTS / PACKAGES
addappid(526541, 1, "53c5ca86df8c0138611c5a25bc4a297fb9b74dff60eebccbb7555568da276afc")
addappid(526542, 1, "81af2c31b9a94f86c8420181076a34ef2aa8e920efbae166c2b743d66ddab0f7")
addappid(526543, 1, "0e5d47941559ac3a9d91f9d2b830a4effe5bafdb7d106acc84fdf911841a9c50")
