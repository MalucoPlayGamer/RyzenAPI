-- Lua provided by RyzenAPI
-- Game: Game: Mistward

-- MAIN APPLICATION
addappid(2618090)
-- Game: addappid(2618090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2618091, 1, "18ac2a4b2883e039ee352a3ede91d68ac1979f0f6efcccac442b1703d14cb3db")
