-- Lua provided by RyzenAPI
-- Game: Project Drift

-- MAIN APPLICATION
addappid(2305520)
-- Game: addappid(2305520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2305521, 1, "75ff461e935b4c8fac41f25e6b40aae40dc706c93061c56350903481c2215fe2")
