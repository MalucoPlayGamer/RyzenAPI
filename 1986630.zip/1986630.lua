-- Lua provided by RyzenAPI
-- Game: Royal Legends: Raised in Exile Collector's Edition

-- MAIN APPLICATION
addappid(1986630)
-- Game: addappid(1986630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986631, 1, "4c5d652d86d9248e29f8870d2a0994171496db429134b57cc4de51eb4b496f30")
