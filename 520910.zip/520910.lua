-- Lua provided by RyzenAPI
-- Game: Kokurase Episode 1

-- MAIN APPLICATION
addappid(520910)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(558640)
addappid(558641)
