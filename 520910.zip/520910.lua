-- Lua provided by RyzenAPI
-- Game: Kokurase Episode 1

-- MAIN APPLICATION
addappid(520910)

