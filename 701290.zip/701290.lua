-- Lua provided by SkyAPI 
-- Game: AppID 701290
addappid(701290)
addappid(701291, 1, "56e734609fe2ec5e8bcc6860a11701ac2ce447a6d680d85600592fd699d76f03")
