-- Lua provided by RyzenAPI
-- Game: Blue Funk

-- MAIN APPLICATION
addappid(2187030)
-- Game: addappid(2187030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187031, 1, "54f3aa1d7bf7467148ff2f8835724c7fd28a8005939d7fd58a357b9cf82cf6c7")
