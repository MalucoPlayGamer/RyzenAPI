-- Lua provided by RyzenAPI
-- Game: Phantom Thief Angels: Twin Angel - Labyrinth of Time and World - Re:light [Demo]

-- MAIN APPLICATION
addappid(3227220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227221, 1, "483fb5ecf0c1492237ecc8d6e27d9f53520aa9cb344b123559630246bef0908d")
