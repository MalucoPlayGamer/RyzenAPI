-- Lua provided by RyzenAPI
-- Game: 1158690

-- MAIN APPLICATION
addappid(1158690)
-- Game: addappid(1158690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158691, 1, "bc81bcd28e405ab64c77b6801c5474f383fe74fd0ce4627c86fecd386e4c5585")
