-- Lua provided by RyzenAPI
-- Game: Fortoresse

-- MAIN APPLICATION
addappid(1489840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1489841, 1, "cc39e6ebcdb0406693c42fe4ab4a174a2d306eca7f8abde422f685adea913973")
