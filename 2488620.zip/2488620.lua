-- Lua provided by RyzenAPI
-- Game: F1® 24

-- MAIN APPLICATION
addappid(2488620)
addappid(2751140)
addappid(2751150)
addappid(2751160)
addappid(2751170)
addappid(2751180)
addappid(2751190)
addappid(2791190)
addappid(2807940)
addappid(2994700)
addappid(3075400)
addappid(3335270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2488620,0,"703777a80cf4d7e480beff412e25cdbdb698d1ec6fa6bc3ef1920437e590d6ce")
addappid(2488621,0,"631754f71ffa45dd53c6375d1e093a58315b5c7468e7dae0b1c1f168b1e3b062")
addappid(2488622,0,"3bb5b95c44afb22626dfe7f4717d1a8c829e93cf3bfad336352103c304cb4378")
addappid(2488623,0,"e2f55053a31b74536dc064d80009d8fb3905a66be6c1c4809a522f27166f609c")
addappid(2488624,0,"13515b2f09f7b81529a2c82c13692f6148e80f4aea11fde68100e35560e67a60")
addappid(3893181,0,"7f675c2fe8e758d16f3cf8d3b493956afaee78e96d78cdb668a5edb8ac1580f6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
