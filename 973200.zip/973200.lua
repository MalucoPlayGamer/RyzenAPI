-- Lua provided by RyzenAPI
-- Game: Case Simulator Weapons and Armors

-- MAIN APPLICATION
addappid(973200)
addappid(974780)

-- MAIN APP DEPOTS / PACKAGES
addappid(973201, 1, "4ecdc51ecf9a65867e86bedeb5365210babdbd342ea9e321b1d0afd90533160b")
