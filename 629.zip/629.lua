-- Lua provided by RyzenAPI
-- Game: 629

-- MAIN APPLICATION
addappid(621)
addappid(629)

-- MAIN APP DEPOTS / PACKAGES
addappid(629,0,"f31199dad679ff85cd65c9b8fefa8457f19691609668a9cf2835efab3acc24bb")
