-- Lua provided by RyzenAPI
-- Game: Milky Way Map

-- MAIN APPLICATION
addappid(806020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(806021, 1, "dfd5d27483457af5c4d0f0c6dd0de91fa5e9cf9987bbaf7db0bd8ed3ce734fa5")

