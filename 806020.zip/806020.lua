-- Lua provided by RyzenAPI
-- Game: 806020

-- MAIN APPLICATION
addappid(806020)
-- Game: addappid(806020)

-- MAIN APP DEPOTS / PACKAGES
addappid(806021, 1, "dfd5d27483457af5c4d0f0c6dd0de91fa5e9cf9987bbaf7db0bd8ed3ce734fa5")
