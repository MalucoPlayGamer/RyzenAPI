-- Lua provided by RyzenAPI
-- Game: Painkiller: Black Edition

-- MAIN APPLICATION
addappid(39530)
-- Game: addappid(39530)

-- MAIN APP DEPOTS / PACKAGES
addappid(39531, 1, "8d85eb8a8b0a09e0e13a877287aa217f385f83e47395590683ca78e2f5f3bde5")
addappid(39532, 1, "f4e13c135faadce6cdd4406a70142618cf360346f1c8e01dcc3410e79570286f")
addappid(39533, 1, "689c8d0e0a9b1c5dbd910128ad1b148abbcd1b9aa1c729f0b032af6626fbacd1")
addappid(39534, 1, "cbc206b5c5d1a157d25c9cd645c94fb6e8273d7d98b26ff282ee742c9372edfd")
