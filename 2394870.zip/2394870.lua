-- Lua provided by RyzenAPI
-- Game: Game: Blood of a Demon

-- MAIN APPLICATION
addappid(2394870)
-- Game: addappid(2394870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2394871, 1, "1ac7acbdc7885916763fc9038ecc640e838f1938ac040406ab5796a3d814e698")
