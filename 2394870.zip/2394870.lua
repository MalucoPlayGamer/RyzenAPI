-- Lua provided by SkyAPI 
-- Game: Blood of a Demon
addappid(2394870)
addappid(2394871, 1, "1ac7acbdc7885916763fc9038ecc640e838f1938ac040406ab5796a3d814e698")
