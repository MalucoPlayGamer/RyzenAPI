-- Lua provided by RyzenAPI
-- Game: Fuck You Witch Soundtrack

-- MAIN APPLICATION
addappid(2822410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2822411, 1, "45c0db601a6bd5d5cbccf490ccbc4e81bc0f9a13dd77f54f596c1f91992f2e4f")
addappid(2822412, 1, "c09d4551139155751fc12bcc21c1ce7de04a654408918d522657390526e8e766")
