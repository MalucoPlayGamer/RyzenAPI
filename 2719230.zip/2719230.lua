-- Lua provided by RyzenAPI
-- Game: Wheelie King 5 Demo

-- MAIN APPLICATION
addappid(2719230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2719231, 1, "ef3c7a37fb101b7aec7950e474ea440e4d7f6c5e1ffd7f3c12c53cd299540788")
