-- Lua provided by RyzenAPI
-- Game: Game: WordWar

-- MAIN APPLICATION
addappid(1981090)
-- Game: addappid(1981090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981091, 1, "108885c4a88e3ea29050ee6d19320995383e978a8375e6c464f57f47fff1cf5d")
