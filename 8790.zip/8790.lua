-- Lua provided by RyzenAPI
-- Game: Game: GTR 2 FIA GT Racing Game

-- MAIN APPLICATION
addappid(8790)
-- Game: addappid(8790)

-- MAIN APP DEPOTS / PACKAGES
addappid(8791, 1, "a06cac07e45b67b68182034f069896536f6f5553aaa734500f7eca4d1a7120c6")
