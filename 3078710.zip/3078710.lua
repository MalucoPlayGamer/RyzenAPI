-- Lua provided by RyzenAPI
-- Game: addappid(3078710)

-- MAIN APPLICATION
addappid(3078710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3078711, 1, "89dcdecf777f594fc623c8a45ea151d019b4f3bc52afd3f5be2e1f3d3d56681c")
