-- Lua provided by RyzenAPI
-- Game: addappid(1925963)

-- MAIN APPLICATION
addappid(1925963)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925963,0,"0b8e84a0582bcebf8ae6e07aa7ea85132b257ba1c76b81628ef3fb1cc98f1450")
