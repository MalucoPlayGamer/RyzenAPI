-- Lua provided by RyzenAPI
-- Game: addappid(1006600)

-- MAIN APPLICATION
addappid(1006600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1006601, 1, "19b66c19227e6aa1c43009dde3bf757b141ea5086fd96ae2734effd9a804a392")
