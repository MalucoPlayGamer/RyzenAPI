-- Lua provided by RyzenAPI
-- Game: Atlantis 2: Beyond Atlantis

-- MAIN APPLICATION
addappid(362920)
-- Game: addappid(362920)

-- MAIN APP DEPOTS / PACKAGES
addappid(362921, 1, "c0408c95a4cbc7379e785b20c288fe8446788aff08b5041cdbf077313dc06492")
addappid(362922, 1, "c1f6b0f66623cb295a52596bd9bb7b870d5c82238150b5129932c0f10cfe950a")
