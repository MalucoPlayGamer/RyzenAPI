-- Lua provided by RyzenAPI
-- Game: 2654420

-- MAIN APPLICATION
addappid(2654420)
-- Game: addappid(2654420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654421, 1, "e80b9e45192a75d874144f1fc8babf2cbdea70e897f6a30ad594d88912d542af")
