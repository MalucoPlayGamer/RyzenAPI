-- Lua provided by SkyAPI 
-- Game: 求婚失败了，我还不知道她的名字
addappid(2654420)
addappid(2654421, 1, "e80b9e45192a75d874144f1fc8babf2cbdea70e897f6a30ad594d88912d542af")
