-- Lua provided by SkyAPI 
-- Game: The Cleaner
addappid(1389020)
addappid(1389021, 1, "824f0e80bc27a1bb9f98ade703ad6e4f2594327a9b8446882afebe0e6821643e")
