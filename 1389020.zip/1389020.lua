-- Lua provided by RyzenAPI
-- Game: The Cleaner

-- MAIN APPLICATION
addappid(1389020)
-- Game: addappid(1389020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389021, 1, "824f0e80bc27a1bb9f98ade703ad6e4f2594327a9b8446882afebe0e6821643e")
