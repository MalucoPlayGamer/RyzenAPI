-- Lua provided by RyzenAPI
-- Game: Game: Airborne Kingdom

-- MAIN APPLICATION
addappid(982290)
-- Game: addappid(982290)

-- MAIN APP DEPOTS / PACKAGES
addappid(982291, 1, "d796913bd3e83d1a7823643a5b4e31ac1d478b1f2efca47f8a28801891ba858a")
addappid(982293, 1, "3c8748a5677eb714231452bd4c52799bd76b4ae6b6ef01bd0f07a2e26c64c667")
