-- Lua provided by RyzenAPI
-- Game: Game: Hentai Aina

-- MAIN APPLICATION
addappid(3381080)
-- Game: addappid(3381080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3381081, 1, "e91116d27d3277fa3a334e1263bad668af46cb5a699c90c58e5a91e02e8e22ec")
