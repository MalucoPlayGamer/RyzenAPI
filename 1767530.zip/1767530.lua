-- Lua provided by RyzenAPI
-- Game: Gatedelvers Demo

-- MAIN APPLICATION
addappid(1767530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1767531, 1, "0fa4beeb1e40a4041a248e83d783b0a6155b38debd4f5d1caa8c457e0e0f8ec2")
