-- Lua provided by RyzenAPI
-- Game: Game: AppID 771500

-- MAIN APPLICATION
addappid(771500)
-- Game: addappid(771500)

-- MAIN APP DEPOTS / PACKAGES
addappid(771501, 1, "68aef07a48dc169d542c74196f8533c9d319a9965c419f8224f0b0415b7f88b2")
addappid(771502, 1, "c808fd8bb63367d1862e5d133ddf42b8db7b1239711ea762e09e570b4e4ecca3")
