-- Lua provided by SkyAPI 
-- Game: Capcom Arcade 2nd Stadium: Mini-Album Track 10 - A.K.A Knights of the Round - Start Waiting Screen
addappid(2087760)
addappid(2087761, 1, "1861f485b406912f8f15ac0aa2bb5da5617145d8fb93575f3d1d65a44931d625")
addappid(2087762, 1, "5a1b5a9c4202ed26b416fe8342c75314804a7eee7e714f94f85bcc4705327d3d")
addappid(2087763, 1, "93683c1d4e5932bfc31c5322d50c3bac8a374a225192605a8019251ea2c3761f")
addappid(2087764, 1, "d4a7b6e914b42899a290e21ad9389fe8a7bb97ce4fa8e0ab8b6795f5b93bfc31")
addappid(2087765, 1, "6b9efdad64f44fbff8c211828c4cf8e32ea019c58ea61fb7aa5702b849e03932")
addappid(2087766, 1, "7b64e6503eadaa25233f915841a5b4a58f79b37358a9b73af39b12ddf94ce38e")
