-- Lua provided by RyzenAPI
-- Game: Game: AppID 2506700

-- MAIN APPLICATION
addappid(2506700)
-- Game: addappid(2506700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506701, 1, "2e7b1a7da8244ce6c7d7634f0a14875be4d72242198f19350fbdbf9e40194529")
