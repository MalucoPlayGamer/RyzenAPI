-- Lua provided by RyzenAPI
-- Game: Run TavernQuest

-- MAIN APPLICATION
addappid(808610)

-- MAIN APP DEPOTS / PACKAGES
addappid(808611,0,"9c7f66e64ab0b275185f90b3506acad70925d103892da67fa3314824fc6a29a4")

