-- Lua provided by RyzenAPI
-- Game: Delve Diver

-- MAIN APPLICATION
addappid(3024960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3024961, 1, "92d84a28794bc29ee2346a5f269730c208b27a8d77f7cb9d13fe1420d6a3f019")
