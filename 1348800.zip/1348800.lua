-- Lua provided by SkyAPI 
-- Game: PROJECTIONS
addappid(1348800)
addappid(1348801, 1, "482e978b98b935320443622754af061b10482a8899fb5607fb2aaa9d8c7d8a88")
