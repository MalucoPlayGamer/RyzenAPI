-- Lua provided by RyzenAPI
-- Game: 1795110

-- MAIN APPLICATION
addappid(1795110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1795112,0,"e694bd4ecd658daa4fd04b8612a7f3bc67ee3f7c5a61e4fab20dc3c00995042e")

