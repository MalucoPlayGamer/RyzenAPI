-- Lua provided by RyzenAPI
-- Game: Game: AppID 914190

-- MAIN APPLICATION
addappid(914190)
-- Game: addappid(914190)

-- MAIN APP DEPOTS / PACKAGES
addappid(914191, 1, "75c024b53df58a7219d72d0a372f5540de50976b7b41ca0d43e53aaf1dc9e8ec")
