-- Lua provided by RyzenAPI
-- Game: The Emperor and State

-- MAIN APPLICATION
addappid(2716930)
addappid(3060960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2716931, 1, "0c32344f8dbf49426e7b6da2cb1ddd972e3e2883a1ffbcac7dbdb9a9eb2d53eb")
