-- Lua provided by RyzenAPI
-- Game: 异族再起扩展包（Monster Sect Part 2）- 山门与幻境TheLostVillage

-- MAIN APPLICATION
addappid(3348000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3348000,0,"137af1b6a775c42a78e9b1386d97ed46074f1296114ef4983770b48ab2b7653a")
