-- Lua provided by RyzenAPI
-- Game: I Am a Rock

-- MAIN APPLICATION
addappid(1762400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1762401, 1, "71d7bce7fcaab2b4a7917aaf8d2efd911c58a4445388ced7a478ebb070245ead")
addappid(1762402, 1, "c5849a20f4e67b5f32de3c8293bc6eb5e84cd30b845c0508ea2cb5b46afbea54")

