-- Lua provided by RyzenAPI
-- Game: addappid(1700800)

-- MAIN APPLICATION
addappid(1700800)
addappid(1700801)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010831,0,"6d19969a3a15e68565b161f41243a10fca5085ee00d6615c356c5f6fc8a7eb83")
