-- Lua provided by RyzenAPI
-- Game: Electoral Carnage

-- MAIN APPLICATION
addappid(3706810)

