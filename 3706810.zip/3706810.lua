-- Lua provided by RyzenAPI
-- Game: Electoral Carnage

-- MAIN APPLICATION
addappid(3706810)
addappid(4909010)
addappid(5160580)

