-- Lua provided by RyzenAPI
-- Game: Super Grower

-- MAIN APPLICATION
addappid(991750)
addappid(1039720)

-- MAIN APP DEPOTS / PACKAGES
addappid(991751, 1, "0a356d8c08c10903d4a5db43c38cd2648dc693b8c56a6e352f5346324a5569ef")
