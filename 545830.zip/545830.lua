-- Lua provided by RyzenAPI
-- Game: Game: Princess of Tavern Collector's Edition

-- MAIN APPLICATION
addappid(545830)
-- Game: addappid(545830)

-- MAIN APP DEPOTS / PACKAGES
addappid(545831, 1, "70ff84898b08b2040fb402999599bd6d289de71202f7b016b4e70b22db30c5b3")
addappid(545832, 1, "a7dcff3ecc629e430623ba908ebc41f0111cc5192f6f83402d1234da1be33072")
