-- Lua provided by RyzenAPI
-- Game: 1990060

-- MAIN APPLICATION
addappid(1990060)
-- Game: addappid(1990060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990061, 1, "f37b750e06f96e6aac549a33e7ebcc14d8e766cfb3d10c757ebc0868c28d8869")
