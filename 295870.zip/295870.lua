-- Lua provided by RyzenAPI
-- Game: AppID 295870

-- MAIN APPLICATION
addappid(295870)
-- Game: addappid(295870)

-- MAIN APP DEPOTS / PACKAGES
addappid(295871, 1, "5ff7fbb34b983eda800be6521fe0df9c56e2e5dd299977bb6c73c0ed14f61845")
