-- Lua provided by RyzenAPI
-- Game: AppID 41000

-- MAIN APPLICATION
addappid(41000)
addappid(228990)
-- Game: addappid(41000)

-- MAIN APP DEPOTS / PACKAGES
addappid(41001, 1, "593a6a1065170f4ea997822ef0acfd7a0904e5ca448ff230cb2f22309e0d4da7")
addappid(41002, 1, "11bf74591536053deaa2f352f9d2826f4ba5947de21b8a8cfd93b066e8c24eef")
addappid(41003, 1, "0ef23f92bf89ce91eb3bf325fb0a3157b1fd3245e269ee7d7feb43ebe6519b74")
