-- Lua provided by RyzenAPI
-- Game: Necrosphere64

-- MAIN APPLICATION
addappid(2836010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2836011, 1, "2b3c0bef32c1fa48fc0eb7f220b7d03de8a2a923668a016798e15328db5edff6")
addappid(2836012, 1, "14c1113ac15415eda66831d8724ad4aafbdffec68a06e6df38ec204ded1c2585")
addappid(2836013, 1, "0c173c6b2c55f25353b390cdaa245a283180a2ccb58201747df7d589974116d2")
addappid(2836014, 1, "a898fc54b8c752fda35158145fa85037e130650e2ec0c4a54bfe322e2bebe8db")
addappid(2836016, 1, "9d16fbafcc1c1430ee3f7da4592659ad9aec499835fe44cd233ca5be38a6005d")

