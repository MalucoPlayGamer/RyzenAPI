-- Lua provided by RyzenAPI
-- Game: 2215160

-- MAIN APPLICATION
addappid(2215160)
-- Game: addappid(2215160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215161, 1, "4619b9c15b09efd39b3237e78e5f7feb6f68a575353457f5061c466fa73dda7d")
