-- Lua provided by RyzenAPI
-- Game: The Iron Oath

-- MAIN APPLICATION
addappid(699330)
-- Game: addappid(699330)

-- MAIN APP DEPOTS / PACKAGES
addappid(699331, 1, "9e4bfde164a398fbe9012226452ab1d79eccc1dc1625697a31144f3b39a3d7b2")
