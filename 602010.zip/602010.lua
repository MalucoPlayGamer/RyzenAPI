-- Lua provided by RyzenAPI 
-- Game: AppID 602010
addappid(602010)
addappid(602011, 1, "c2ccd11969cedc862baa105480a7a72b8507272f5b5d22cf44a37b909660033e")
