-- Lua provided by RyzenAPI
-- Game: Game: ELEVATED

-- MAIN APPLICATION
addappid(1882330)
-- Game: addappid(1882330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1882331, 1, "87fdf30bb861e27d3e28f923cf74de5df37534357b2fb6206bd3a286e148d3c6")
