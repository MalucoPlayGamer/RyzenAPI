-- Lua provided by RyzenAPI 
-- Game: ELEVATED
addappid(1882330)
addappid(1882331, 1, "87fdf30bb861e27d3e28f923cf74de5df37534357b2fb6206bd3a286e148d3c6")
