-- Lua provided by RyzenAPI
-- Game: Quest For Wartorn Brotherhood

-- MAIN APPLICATION
addappid(1076830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(1076831, 1, "4a24189f4e7e4ddc88da2a6d19e61bc6b31711415c73a7e9bc95a5614684acc6")

