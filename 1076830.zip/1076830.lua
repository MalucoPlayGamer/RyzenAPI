-- Lua provided by RyzenAPI
-- Game: Quest For Wartorn Brotherhood

-- MAIN APPLICATION
addappid(1076830)
-- Game: addappid(1076830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076831, 1, "4a24189f4e7e4ddc88da2a6d19e61bc6b31711415c73a7e9bc95a5614684acc6")
