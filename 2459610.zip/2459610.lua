-- Lua provided by RyzenAPI 
-- Game: AppID 2459610
addappid(2459610)
addappid(2459611, 1, "7859a923d4cc943d734cdf7ef1a28000e0e0d05564aebd39356462f5e4b96d77")
