-- Lua provided by RyzenAPI
-- Game: 96400

-- MAIN APPLICATION
addappid(96400)
-- Game: addappid(96400)

-- MAIN APP DEPOTS / PACKAGES
addappid(96402,0,"b6a8ef694c70d8a85327041c527a9ae8b5b297a06a79b7758c2e06e20b4548fb")
