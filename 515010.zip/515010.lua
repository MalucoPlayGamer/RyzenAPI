-- Lua provided by RyzenAPI
-- Game: A Duel Hand Disaster: Trackher

-- MAIN APPLICATION
addappid(515010)

-- MAIN APP DEPOTS / PACKAGES
addappid(515011,0,"3c9c856c20f5a3a5256236a302e90acc83164bdf031df406d3b491f670d242f3")
addappid(515013,0,"7c234d2ca348e79bc7773b84ae56b2468856418b044c6cc76ed67eae6ae7a75d")

