-- Lua provided by SkyAPI 
-- Game: SKETCHY MASSAGE
addappid(3408850)
addappid(3408851, 1, "a1146dd02e576f966b13b8ab3e056e38e01644ee84eebff26e6c93450fe3ffdb")
