-- Lua provided by RyzenAPI
-- Game: SKETCHY MASSAGE

-- MAIN APPLICATION
addappid(3408850)
-- Game: addappid(3408850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3408851, 1, "a1146dd02e576f966b13b8ab3e056e38e01644ee84eebff26e6c93450fe3ffdb")
