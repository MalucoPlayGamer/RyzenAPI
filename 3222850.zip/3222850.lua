-- Lua provided by RyzenAPI
-- Game: Doctor Dash ASMR Hospital

-- MAIN APPLICATION
addappid(3222850)
addappid(3792700)
addappid(3798080)
addappid(3798090)
addappid(3798100)
addappid(3798110)
addappid(3798120)
addappid(3798130)
addappid(3798140)
addappid(3798150)
addappid(3798160)
addappid(3798170)

