-- Lua provided by RyzenAPI
-- Game: Doctor Dash ASMR Hospital

-- MAIN APPLICATION
addappid(3222850)

