-- Lua provided by RyzenAPI
-- Game: 2130000

-- MAIN APPLICATION
addappid(2130000)
addappid(2130150)
-- Game: addappid(2130000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2130001, 1, "d2e98d594111b64f9da0b8503610f9748b81089c2c17b0a105be8cce3bb7d1a9")
