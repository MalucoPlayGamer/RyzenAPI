-- Lua provided by RyzenAPI
-- Game: 100 Cats Lost In Poland Find & Color

-- MAIN APPLICATION
addappid(3766160)

