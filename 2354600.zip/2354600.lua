-- Lua provided by RyzenAPI
-- Game: Game: Renfield: Bring Your Own Blood

-- MAIN APPLICATION
addappid(2354600)
-- Game: addappid(2354600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2354601, 1, "069074db5cf04934352d7a74550fd3d20271cce899151e671fbaa778b0cb0185")
