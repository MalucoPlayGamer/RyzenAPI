-- Lua provided by RyzenAPI
-- Game: TripTrip

-- MAIN APPLICATION
addappid(859820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(859821, 1, "7aecde5e890e5ca8cb33819c2a347515ab65c1abac0d36230e668d04f073306f")

