-- Lua provided by RyzenAPI
-- Game: AppID 859820

-- MAIN APPLICATION
addappid(859820)

-- MAIN APP DEPOTS / PACKAGES
addappid(859821, 1, "7aecde5e890e5ca8cb33819c2a347515ab65c1abac0d36230e668d04f073306f")
