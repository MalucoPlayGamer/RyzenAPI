-- Lua provided by RyzenAPI
-- Game: There's No Monsters

-- MAIN APPLICATION
addappid(3071520)
-- Game: addappid(3071520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3071521, 1, "2cf1228fc65961462447879df754fcc5fc760f7a0269b4d4e2afe2741cd7f413")
