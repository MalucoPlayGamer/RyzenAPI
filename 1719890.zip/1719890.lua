-- Lua provided by RyzenAPI
-- Game: Mummy, mummy, mummy!

-- MAIN APPLICATION
addappid(1719890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719891, 1, "778a003feb4874bc4d79a1a78484229c7a7a226c2fd22c73c2ce880b7600a6cb")

