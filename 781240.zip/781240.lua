-- Lua provided by RyzenAPI
-- Game: Game: Mystical

-- MAIN APPLICATION
addappid(781240)
-- Game: addappid(781240)

-- MAIN APP DEPOTS / PACKAGES
addappid(781241, 1, "0083ed9a41fefcb3ae35f36de7fe7ab1e6c77851ebfda34941ca58d10a8685ee")
