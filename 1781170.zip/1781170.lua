-- Lua provided by RyzenAPI
-- Game: Game: The Flow Experience

-- MAIN APPLICATION
addappid(1781170)
-- Game: addappid(1781170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781171, 1, "35cee310d39f579c6a8e5cbf9a896da280090e252ab781f36f1de8342a5b6129")
addappid(1781172, 1, "b9b0a273a6474361073ce8b578cd93bb4f80c3632e9bed4dfe929f4381d1a294")
addappid(1781173, 1, "d1c6021a320ab684fedc40821f7181ec0abe125171ba510750b982c2e12705fc")
