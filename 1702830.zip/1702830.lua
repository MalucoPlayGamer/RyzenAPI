-- Lua provided by RyzenAPI
-- Game: BLACKJACK and WAIFUS Hentai Version

-- MAIN APPLICATION
addappid(1702830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702831, 1, "4d2eb7042a14475df5e2fad1199d925037010f09d4527eb5179ce2508110bd98")
addappid(1702832, 1, "337a87c18d5aa94b98b0d2b4697426ebb1af2b77505a02c570b00fbaeed69a02")
addappid(1702833, 1, "febe536e1371251a3a65916a6ef2ee94d36231fea953174e3247c4642903f455")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1900190)
