-- Lua provided by RyzenAPI
-- Game: 猟奇リスナー ～ 狙われた姫配信者 ～ Lunatic Viewer - Streamer Girl at Risk -

-- MAIN APPLICATION
addappid(2095040)
-- Game: addappid(2095040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095041, 1, "889cdf3b7bfbf328a3d9bdbff426c263c8258d5dec46a4c0b5e893d978764f03")
