-- Lua provided by RyzenAPI
-- Game: addappid(2345440)

-- MAIN APPLICATION
addappid(2345440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2345441, 1, "59294fb5c869f855e939cd86f0e991061cae9ea3db46d8a60f7a59578e97988a")
