-- Lua provided by RyzenAPI
-- Game: Project Almighty

-- MAIN APPLICATION
addappid(566250)

-- MAIN APP DEPOTS / PACKAGES
addappid(566251,0,"dbd82ca503963b26f8b9f393df9d01112988a9039a1603454f89007b49b2e9b0")

