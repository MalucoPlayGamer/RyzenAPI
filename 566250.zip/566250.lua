-- Lua provided by RyzenAPI
-- Game: Project Almighty

-- MAIN APPLICATION
addappid(566250)

-- MAIN APP DEPOTS / PACKAGES
addappid(566251,0,"dbd82ca503963b26f8b9f393df9d01112988a9039a1603454f89007b49b2e9b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
