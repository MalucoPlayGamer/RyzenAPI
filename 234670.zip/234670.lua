-- Lua provided by RyzenAPI
-- Game: NARUTO SHIPPUDEN: Ultimate Ninja STORM 3 Full Burst HD

-- MAIN APPLICATION
addappid(234670)

-- MAIN APP DEPOTS / PACKAGES
addappid(234671, 1, "132185278774455f9ac417b8e8938131b4d9d8821ebd9c2bc0d02d9883069405")
addappid(234672, 1, "393c2dd43be41a8598a40b492a0ad8a41baf91379b6fa948de855f7f94db31f3")
addappid(234673, 1, "68c6e38f4e45def7ae51cb544f9d433a7c0e8a21141dfeada88fec37b5b2f462")
addappid(234674, 1, "500459fca252625c182791972170e28807a7095bc745b9503a56cf5e5adea361")
addappid(543890, 0, "025485ca898026fa8c5bb1088c516831d0c299276661cd847c0f8e5b8ed0bb05")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
