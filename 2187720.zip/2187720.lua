-- Lua provided by RyzenAPI
-- Game: addappid(2187720)

-- MAIN APPLICATION
addappid(2187720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187721, 1, "ea4be623e1285a94d6f4d2e6ef20c62625c9a300bffa5a5b89d53c2f0ab1c773")
