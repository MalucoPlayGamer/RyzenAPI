-- Lua provided by RyzenAPI
-- Game: Spirit City: Lofi Sessions

-- MAIN APPLICATION
addappid(2113850)
addappid(2374850)
addappid(3210380)
addappid(3349330)
addappid(3815280)
addappid(4242210)
addappid(4734690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2113851, 1, "c96341ff6c37bb63b6a46045e820f5c956aeea66a47703fb62c8476f09300ae9")
addappid(2113852, 1, "554e69a56122534ea8d5ddaab8928c69bcd639fd5ca10425459c1617d2f3f908")

