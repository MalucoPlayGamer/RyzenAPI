-- Lua provided by RyzenAPI
-- Game: FitStrike

-- MAIN APPLICATION
addappid(1863960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863961, 1, "6fabda48dc709102727e43d50429a627fd2daaee1c069039d6a37e9db948852f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
