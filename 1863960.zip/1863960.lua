-- Lua provided by SkyAPI 
-- Game: FitStrike
addappid(1863960)
addappid(1863961, 1, "6fabda48dc709102727e43d50429a627fd2daaee1c069039d6a37e9db948852f")
