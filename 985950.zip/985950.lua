-- Lua provided by RyzenAPI
-- Game: Operencia: The Stolen Sun

-- MAIN APPLICATION
addappid(985950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(985951, 1, "153e038b734127e187909af39b86144b93d62d1a839d85e6b284449c9ce920d7")
