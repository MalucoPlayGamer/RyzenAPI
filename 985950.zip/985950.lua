-- Lua provided by RyzenAPI
-- Game: Game: AppID 985950

-- MAIN APPLICATION
addappid(985950)
-- Game: addappid(985950)

-- MAIN APP DEPOTS / PACKAGES
addappid(985951, 1, "153e038b734127e187909af39b86144b93d62d1a839d85e6b284449c9ce920d7")
