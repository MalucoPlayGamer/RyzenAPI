-- Lua provided by RyzenAPI
-- Game: AppID 767810

-- MAIN APPLICATION
addappid(767810)
addappid(972150)
addappid(992150)
addappid(992160)
addappid(1020630)
addappid(1020631)

-- MAIN APP DEPOTS / PACKAGES
addappid(767811, 1, "27316af2b9fa5074629db5d054b51cd10f336945bac5785d8d4319039e68ab22")
