-- Lua provided by RyzenAPI
-- Game: 459840

-- MAIN APPLICATION
addappid(459840)

-- MAIN APP DEPOTS / PACKAGES
addappid(459842,0,"232f70ebdab4acd8a48c7d7c21110482d025dcd4e1b2f0ca784db080e425f70e")

