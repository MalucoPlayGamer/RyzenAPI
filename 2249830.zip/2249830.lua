-- Lua provided by RyzenAPI
-- Game: 2249830

-- MAIN APPLICATION
addappid(2249830)
-- Game: addappid(2249830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249831, 1, "b3ddb5c0af434b9606f9a3803af38e2a20755e95d1e4748963cabaedb7e10e65")
