-- Lua provided by RyzenAPI
-- Game: 《奇门遁甲》

-- MAIN APPLICATION
addappid(2249830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249831, 1, "b3ddb5c0af434b9606f9a3803af38e2a20755e95d1e4748963cabaedb7e10e65")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
