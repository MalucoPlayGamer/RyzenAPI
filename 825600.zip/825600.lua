-- Lua provided by RyzenAPI
-- Game: addappid(825600)

-- MAIN APPLICATION
addappid(825600)

-- MAIN APP DEPOTS / PACKAGES
addappid(825601, 1, "350a90b41baaf4b378b77f4086e64b1d70299023ee3e078f959203e3e47439ac")
