-- Lua provided by RyzenAPI
-- Game: Game: AppID 1186400

-- MAIN APPLICATION
addappid(1186400)
-- Game: addappid(1186400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186401, 1, "ffc507108b6acf54e5396db6739d7f24634ec55a3d71152c4872d2acafa8999a")
addappid(1190610, 0, "9e2b6b9bdfc16dbbef97f09982f9059b5ac9bd0b11e3f5bfc0e2e495e6e620c3")
addappid(1581780, 0, "fc8c7ad2d8d5ecba90a6a4bc40200b270656f11f94bae486f2a0669278d9449d")
