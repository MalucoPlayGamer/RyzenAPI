-- Lua provided by RyzenAPI
-- Game: addappid(934500)

-- MAIN APPLICATION
addappid(934500)

-- MAIN APP DEPOTS / PACKAGES
addappid(934501, 1, "0627e8793c8273b57edec8bf88729fc33a09470c2ab700b7bfeac8645abdc834")
