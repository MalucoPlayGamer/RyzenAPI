-- Lua provided by RyzenAPI
-- Game: addappid(2108560)

-- MAIN APPLICATION
addappid(2108560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2108561, 1, "ec670f112235d2dae7a9810bba99607970bd601d9c4d4536dd3e505c9906cabe")
