-- Lua provided by RyzenAPI
-- Game: Game: Ignition

-- MAIN APPLICATION
addappid(577990)
-- Game: addappid(577990)

-- MAIN APP DEPOTS / PACKAGES
addappid(577991, 1, "6a2759a6f45be3210ddd55d7e5e098b5f797d13af09d8113d9613707e049ab19")
