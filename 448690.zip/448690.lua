-- Lua provided by RyzenAPI
-- Game: 448690

-- MAIN APPLICATION
addappid(448690)
-- Game: addappid(448690)

-- MAIN APP DEPOTS / PACKAGES
addappid(448691, 1, "0c1121dcf8c277e29de281b43ec323dfb07b5f381714863c30b5f6c9c93b7c79")
