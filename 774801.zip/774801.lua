-- Lua provided by RyzenAPI
-- Game: Crab Champions

-- MAIN APPLICATION
addappid(774801)

-- MAIN APP DEPOTS / PACKAGES
addappid(774803,0,"4d6ebe88cccaf7a68764d8cb7920d2df3756ca029f4f690113fcc02dc41bac1d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
