-- Lua provided by RyzenAPI
-- Game: 774801

-- MAIN APPLICATION
addappid(774801)
-- Game: addappid(774801)

-- MAIN APP DEPOTS / PACKAGES
addappid(774803,0,"4d6ebe88cccaf7a68764d8cb7920d2df3756ca029f4f690113fcc02dc41bac1d")
