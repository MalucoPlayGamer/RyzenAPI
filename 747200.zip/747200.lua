-- Lua provided by RyzenAPI 
-- Game: AppID 747200
addappid(747200)
addappid(747201, 1, "59c30bb44de686590f0440cede1fe03783d86de3d2055dea8f3f7506888c6fea")
addappid(747202, 1, "aac1314839f807b46a2ab8110f745d25078188285912f45d9035eed58c58b354")
