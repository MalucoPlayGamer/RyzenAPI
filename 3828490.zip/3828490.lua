-- Lua provided by RyzenAPI
-- Game: Game: Monster Destroyer

-- MAIN APPLICATION
addappid(3828490)
-- Game: addappid(3828490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3828491, 1, "f7680e2ef7ad42a23a8eade497dce2e3cae243719a3c98e81797f39577e92755")
