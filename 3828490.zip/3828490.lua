-- Lua provided by RyzenAPI 
-- Game: Monster Destroyer
addappid(3828490)
addappid(3828491, 1, "f7680e2ef7ad42a23a8eade497dce2e3cae243719a3c98e81797f39577e92755")
