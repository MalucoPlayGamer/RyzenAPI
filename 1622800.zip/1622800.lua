-- Lua provided by RyzenAPI
-- Game: Game: Super Dungeon Maker

-- MAIN APPLICATION
addappid(1622800)
-- Game: addappid(1622800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1622801, 1, "f6dd014ad8ae2e70e59fde42a7d3c170f591108535ca8fc417d1d2ae00266273")
