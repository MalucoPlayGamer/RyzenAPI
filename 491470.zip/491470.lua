-- Lua provided by RyzenAPI
-- Game: PRINCIPIA: Master of Science

-- MAIN APPLICATION
addappid(491470)
-- Game: addappid(491470)

-- MAIN APP DEPOTS / PACKAGES
addappid(491471, 1, "c7e83d7578b831b90cdd6914ccc5b52e966956b65aef4e5bf755fb756da266ce")
addappid(491472, 1, "14ca1c072e93e8c2ea52521901870c531ad1b3832866438664cb93b3d99b3d4d")
