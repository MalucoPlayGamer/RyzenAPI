-- Lua provided by RyzenAPI
-- Game: addappid(3440910)

-- MAIN APPLICATION
addappid(3440910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3440911, 1, "c4b2df632d4dc6ca220223db6842bd7039b55d9f7d2da63b1700cf4289ff1d00")
