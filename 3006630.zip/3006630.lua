-- Lua provided by RyzenAPI
-- Game: Loser Simulator

-- MAIN APPLICATION
addappid(3006630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3006631, 1, "5d3728ab6b863c0debd90a159a6e3151c96c004cdd252a2361fc8e16c4462497")

