-- Lua provided by RyzenAPI
-- Game: 3006630

-- MAIN APPLICATION
addappid(3006630)
-- Game: addappid(3006630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3006631, 1, "5d3728ab6b863c0debd90a159a6e3151c96c004cdd252a2361fc8e16c4462497")
