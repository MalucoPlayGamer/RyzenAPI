-- Lua provided by RyzenAPI
-- Game: addappid(792230)

-- MAIN APPLICATION
addappid(792230)

-- MAIN APP DEPOTS / PACKAGES
addappid(792231, 1, "a853acadaab04970abec1319ada4022ed9388640985afe89b2bb81ad7cec12cc")
