-- Lua provided by RyzenAPI 
-- Game: Zombie Serial Killer Incident
addappid(792230)
addappid(792231, 1, "a853acadaab04970abec1319ada4022ed9388640985afe89b2bb81ad7cec12cc")
