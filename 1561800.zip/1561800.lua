-- Lua provided by RyzenAPI
-- Game: ROUGH KUTS: Night of the Living Dead

-- MAIN APPLICATION
addappid(1561800)
addappid(1573140)
addappid(1573141)
addappid(1594240)
addappid(1599750)
addappid(1604170)
addappid(1611330)
addappid(1620400)
addappid(1694400)
addappid(1699470)
addappid(1761610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1561801, 1, "a5ace97f95cc7f5ff48f8fcb82f2c95d69c91e2b00fa62860211a48de63f3bb1")

