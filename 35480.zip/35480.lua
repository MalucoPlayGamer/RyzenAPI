-- Lua provided by RyzenAPI
-- Game: AppID 35480

-- MAIN APPLICATION
addappid(35480)

-- MAIN APP DEPOTS / PACKAGES
addappid(35481, 1, "82334f20ad9a8e04605a28aa837203fe9bbb45f299a23887f2070423b78afaff")
addappid(35482, 1, "643b4fafeb85d17750a5dd9298f8337b9dd5fb851c1a65e4896766d3f0eefbf4")
addappid(35483, 1, "acaa1aee83ea8024168c5fc830cf6855ce4d2e5d438c623f83520b9410879145")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(35485)
