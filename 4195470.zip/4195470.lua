-- Lua provided by RyzenAPI
-- Game: Taimanin Squad

-- MAIN APPLICATION
addappid(4195470)
