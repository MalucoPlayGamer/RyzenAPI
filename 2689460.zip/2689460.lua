-- Lua provided by RyzenAPI
-- Game: Strange Pong

-- MAIN APPLICATION
addappid(2689460)
addappid(3523340)

