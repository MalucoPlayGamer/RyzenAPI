-- Lua provided by RyzenAPI
-- Game: Strange Pong

-- MAIN APPLICATION
addappid(2689460)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3523340)
