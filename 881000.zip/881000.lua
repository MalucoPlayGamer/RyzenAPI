-- Lua provided by RyzenAPI
-- Game: AppID 881000

-- MAIN APPLICATION
addappid(881000)
-- Game: addappid(881000)

-- MAIN APP DEPOTS / PACKAGES
addappid(881001, 1, "f085af18d541baa9ea1e28898fde33df3149f83cb3594b82baaa45ffb7ec3e5a")
