-- Lua provided by RyzenAPI
-- Game: Game: Klaroro - Abyss of the Soul

-- MAIN APPLICATION
addappid(2822010)
-- Game: addappid(2822010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2822011, 1, "79ce645312960253edd0606b5396c1c0bc92f77afdaa1b0b1b0c7ea4c01300fa")
addappid(2822012, 1, "328938a49c160d21861b1bfb7f659d1f6c07ec3f08e894e26c47b9fbbbda9450")
