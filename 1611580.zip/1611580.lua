-- Lua provided by RyzenAPI
-- Game: Behind Glass: Aquarium Simulator

-- MAIN APPLICATION
addappid(1611580)
addappid(3656810)
-- Game: addappid(1611580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611581, 1, "4af546b0cd0313d1c1985bf32793b2ca9d51668f94def04e95da7296ac38e555")
