-- Lua provided by RyzenAPI
-- Game: Behind Glass: Aquarium Simulator

-- MAIN APPLICATION
addappid(1611580)
addappid(3656810)
addappid(4809580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611580,0,"3ec83635fa054968fb2f27254a29202113a9a9ae359d4ce2f34733062beafb9e")
addappid(1611581,0,"4af546b0cd0313d1c1985bf32793b2ca9d51668f94def04e95da7296ac38e555")

