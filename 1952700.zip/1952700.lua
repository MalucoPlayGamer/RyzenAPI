-- Lua provided by RyzenAPI
-- Game: 抵抗魅魔-被魔紋侵蝕的女騎士的末路 Demo

-- MAIN APPLICATION
addappid(1952700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952701, 1, "acfe8e700faeb17c1e7eae519f0cd88059e1077726432cc55cf4d44b896aeaa1")

