-- Lua provided by RyzenAPI
-- Game: A-Escape VR

-- MAIN APPLICATION
addappid(538330)

-- MAIN APP DEPOTS / PACKAGES
addappid(538331, 1, "ce9feda21ec39a4e5900faf08c882b316600e49876f0409f80c9e74e6e6d4046")
