-- Lua provided by RyzenAPI 
-- Game: AppID 385460
addappid(385460)
addappid(385461, 1, "412190a110e240f81ce20c2f300880cfd687fbd768c874f9f0143fbe75f3118d")
