-- Lua provided by RyzenAPI
-- Game: 1022520

-- MAIN APPLICATION
addappid(1022520)
-- Game: addappid(1022520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022520,0,"6c805cabae3bed7f05e2f4b0f32ef438c883d3cadc225ff56e9ba74a933a98ae")
addtoken(1022520,"18446350535204808546")
