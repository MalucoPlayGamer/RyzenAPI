-- Lua provided by RyzenAPI
-- Game: Game: Gift Collector [ギフトコレクター]

-- MAIN APPLICATION
addappid(3344150)
-- Game: addappid(3344150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3344151, 1, "f1c6362979190f75050e9a30b13a60912afdeb63fb9ee9f6292f87f6ae3198c3")
