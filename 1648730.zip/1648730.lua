-- Lua provided by RyzenAPI
-- Game: S.O.T.A 2

-- MAIN APPLICATION
addappid(1648730)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(1648731, 1, "6e4346f4edb7f95f69781e6678d97a7df1c5c9ddaba0872e45c78b0fa6849ef2")

