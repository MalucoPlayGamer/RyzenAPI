-- Lua provided by RyzenAPI
-- Game: Game: cyberpunkdreams

-- MAIN APPLICATION
addappid(1361680)
-- Game: addappid(1361680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361681, 1, "926a0c342cef5750ae1620b7c9a4934a7e191f2b6edc24a94f57cc015351c214")
addappid(1361682, 1, "f1481019272b5fa7e2f9f2263edf94649643e11403a0f71ad2818a1417c13e2d")
