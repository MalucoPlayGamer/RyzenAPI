-- Lua provided by RyzenAPI
-- Game: cyberpunkdreams

-- MAIN APPLICATION
addappid(1361680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361681, 1, "926a0c342cef5750ae1620b7c9a4934a7e191f2b6edc24a94f57cc015351c214")
addappid(1361682, 1, "f1481019272b5fa7e2f9f2263edf94649643e11403a0f71ad2818a1417c13e2d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1555170)
addappid(1845940)
addappid(2371870)
addappid(2376180)
addappid(2376181)
addappid(2376182)
addappid(2376183)
addappid(2376184)
addappid(2376185)
addappid(2376186)
addappid(2652020)
addappid(3387820)
addappid(3387830)
addappid(3387840)
addappid(3387850)
