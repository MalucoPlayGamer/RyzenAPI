-- Lua provided by RyzenAPI
-- Game: 768510

-- MAIN APPLICATION
addappid(768510)
-- Game: addappid(768510)

-- MAIN APP DEPOTS / PACKAGES
addappid(768511, 1, "9120f5fb4b745064897ce50dbcf559d4975058ab722a1c0d43f5be42a1e12e13")
