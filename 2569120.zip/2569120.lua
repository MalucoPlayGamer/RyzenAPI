-- Lua provided by RyzenAPI
-- Game: AppID 2569120

-- MAIN APPLICATION
addappid(2569120)
-- Game: addappid(2569120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2569121, 1, "5217e7febf1d1cffcc1614a0d5a9c2ba23e5bd7db064641cd04785db68895c65")
