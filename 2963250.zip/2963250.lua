-- Lua provided by SkyAPI 
-- Game: Taxi Rush: Prologue
addappid(2963250)
addappid(2963251, 1, "b42b4cf0f798b6da2d239ed3bc3a8af65b22f3b4979ed7505f659e0e893a2eae")
