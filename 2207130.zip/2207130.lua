-- Lua provided by SkyAPI 
-- Game: AppID 2207130
addappid(2207130)
addappid(2207131, 1, "5dc8d5b940741516a3927c4fa16b23ae45dacf5c32e9c54b0d52e14f9274d67e")
