-- Lua provided by RyzenAPI
-- Game: Stickman League

-- MAIN APPLICATION
addappid(1094010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094011, 1, "d5e3477be070480725a50dd53706cd495f8baf2be0b402c310e3cf0659f5ea77")

