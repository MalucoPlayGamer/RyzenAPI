-- Lua provided by RyzenAPI
-- Game: Game: AppID 848960

-- MAIN APPLICATION
addappid(848960)
-- Game: addappid(848960)

-- MAIN APP DEPOTS / PACKAGES
addappid(848961, 1, "d652bf85e470ee00e0f420269a15251810e92cbc0a213c0a82716db41dc48d6a")
