-- Lua provided by SkyAPI 
-- Game: AppID 1460270
addappid(1460270)
addappid(1460271, 1, "6bb9f4a7df982bae779950167cb995132d0928b146f6c6a8e97c3c665fa52f55")
addappid(1460272, 1, "fb7827f51eb97ea93e3a3b657bacd5e0b4a57fd0dc7064ec14d5ebbf3da676a3")
