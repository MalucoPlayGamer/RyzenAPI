-- Lua provided by RyzenAPI
-- Game: 1664510

-- MAIN APPLICATION
addappid(1664510)
-- Game: addappid(1664510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664511, 1, "49b475ebaa79f00108ea2436fc29ac2431b4c9a3202399736e4c8aed79fe43e4")
