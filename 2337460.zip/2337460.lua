-- Lua provided by RyzenAPI
-- Game: Gym Manager

-- MAIN APPLICATION
addappid(2337460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337462,0,"8b7dce504dcc238385186f0ca1e2f5afe741794235a37dbf493268a6b052e754")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
