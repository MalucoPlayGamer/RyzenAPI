-- Lua provided by RyzenAPI
-- Game: Gym Manager

-- MAIN APPLICATION
addappid(2337460)
-- Game: addappid(2337460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337462,0,"8b7dce504dcc238385186f0ca1e2f5afe741794235a37dbf493268a6b052e754")
