-- Lua provided by RyzenAPI
-- Game: AppID 3029500

-- MAIN APPLICATION
addappid(3029500)
-- Game: addappid(3029500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3029501, 1, "4e2888d71aa0854dd126581eb5a982465f151bd145a8b66ba5ec98984ccb56fd")
