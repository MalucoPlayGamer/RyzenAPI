-- Lua provided by RyzenAPI
-- Game: Game: Men of War: Red Tide

-- MAIN APPLICATION
addappid(3130)
-- Game: addappid(3130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3131, 1, "27c605eebe45864a7f583e899652dfdd29bdc33b3a0517575163900f83f89e5f")
addappid(3132, 1, "ea3370a4cb715f29fd7eedeee273f0b378d1c42d6fe42fb0151948237441cb8f")
addappid(3133, 1, "8b61ed604bcb649d668e7feb16c95d068ea559fd4313d9bb087f50417e1b2c01")
addappid(3134, 1, "98cf603a3339ba27e0a41bab75c170a24999b9e4a55fb3ca59bf59729b158f86")
addappid(3135, 1, "9ec7971ad125eabfda6d6109fa241621bcb62d338e8598edde16cfb5115a391b")
addappid(3136, 1, "94727b245281b2b45acf2b5483ab4c628ea2976b5ef69d9282da874586a8e356")
