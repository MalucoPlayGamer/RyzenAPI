-- Lua provided by RyzenAPI
-- Game: Touhou Chireiden ~ Subterranean Animism.

-- MAIN APPLICATION
addappid(1100150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1100151, 1, "b048c2a00cf76bf14ce58f855c649cdf79144acabcc068ba7e3eba42a9cdd521")

