-- Lua provided by RyzenAPI
-- Game: addappid(1100150)

-- MAIN APPLICATION
addappid(1100150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1100151, 1, "b048c2a00cf76bf14ce58f855c649cdf79144acabcc068ba7e3eba42a9cdd521")
