-- Lua provided by RyzenAPI
-- Game: Bildo

-- MAIN APPLICATION
addappid(674390)

-- MAIN APP DEPOTS / PACKAGES
addappid(674391,0,"20bc82053c1addb2da572a9d5ebd7a3b4c77b39f3a3c9bf95c63e8b0a575fe05")

