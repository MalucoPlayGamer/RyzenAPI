-- Lua provided by RyzenAPI
-- Game: Deck of Souls

-- MAIN APPLICATION
addappid(2088770)
-- Game: addappid(2088770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088771, 1, "1b98a46447bba27b446810848e389e88f6c19b604705abcf08f624b4688edf34")
