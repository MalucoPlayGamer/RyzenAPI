-- Lua provided by RyzenAPI
-- Game: addappid(1493110)

-- MAIN APPLICATION
addappid(1493110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493110,0,"d7edb5181acacdacdb58cd47ba924fec772e049899cfa9f69183a2c76503222a")
