-- Lua provided by RyzenAPI
-- Game: Game: AppID 1288850

-- MAIN APPLICATION
addappid(1288850)
-- Game: addappid(1288850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1288851, 1, "7b785f39cfa101714c6197f825d0a7ac56b07ac05d0edc286bfeeeb86a12c911")
