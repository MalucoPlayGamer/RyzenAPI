-- Lua provided by SkyAPI 
-- Game: AppID 31230
addappid(31230)
addappid(31231, 1, "366060ed9cc0d8b36dacb2788566688c52c4188bcd9c4cf603b38697f5fdb92a")
addappid(31232, 1, "3aa77d35d08257330d07d57234f0561365275ad1eb3cc89083fecf800807dbb4")
