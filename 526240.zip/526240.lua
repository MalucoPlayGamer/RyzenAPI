-- Lua provided by RyzenAPI
-- Game: CloudBound

-- MAIN APPLICATION
addappid(526240)

-- MAIN APP DEPOTS / PACKAGES
addappid(526241,0,"4c8fd43d8fbb2c262a4e833c3cc291ada62a0cb73b5d3e8993157483c3981aad")

