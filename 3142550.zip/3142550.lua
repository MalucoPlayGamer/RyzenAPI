-- Lua provided by RyzenAPI
-- Game: Backrooms: Lost Tape Soundtrack

-- MAIN APPLICATION
addappid(3142550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3142551, 1, "75e2bae0d0448382e7225c383ec0e00b6fe3aa7cc49ba2ad748cf18e56ee9442")

