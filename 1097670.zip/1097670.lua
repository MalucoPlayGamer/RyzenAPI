-- Lua provided by RyzenAPI
-- Game: Game: AppID 1097670

-- MAIN APPLICATION
addappid(1097670)
-- Game: addappid(1097670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097671, 1, "c4d14f79f3505d5047febbf84a364e68c263b625e28ad87eef09a0b6ac1fbf84")
