-- Lua provided by RyzenAPI
-- Game: Transiruby

-- MAIN APPLICATION
addappid(1522930)
addappid(1823420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522931, 1, "bc9aed9934f7dc276f745ab9a4958c1377648086ac7aa4db652b7875e79dd876")
