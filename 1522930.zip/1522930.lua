-- Lua provided by RyzenAPI
-- Game: Transiruby

-- MAIN APPLICATION
addappid(1522930)
addappid(1823420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1522931, 1, "bc9aed9934f7dc276f745ab9a4958c1377648086ac7aa4db652b7875e79dd876")

