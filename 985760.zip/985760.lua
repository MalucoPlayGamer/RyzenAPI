-- Lua provided by RyzenAPI
-- Game: 3D Custom Lady Maker

-- MAIN APPLICATION
addappid(985760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(985761, 1, "7fd519dba539e1297feee6336d866c817ada9c106b60908d51097f3b27446eb2")
addappid(1065140, 0, "57ca7bf72db9fbdbb3bc204548ff82afdeaf7514161ca2b16f5767730b18bdd0")
addappid(1096890, 0, "782b195d11b6bb9b62173d2202b68022ccb8cdeb4353df39d5824c07789f0351")