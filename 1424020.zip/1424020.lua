-- Lua provided by RyzenAPI
-- Game: 1424020

-- MAIN APPLICATION
addappid(1424020)
-- Game: addappid(1424020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424021, 1, "ae0390d366967f1ebc4938bacfb2d02c059e28b2a7560888f80b87a4fd9da381")
