-- Lua provided by RyzenAPI
-- Game: addappid(1423270)

-- MAIN APPLICATION
addappid(1423270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1423271, 1, "cfe3203d1ffdf23080d4365524095f5ce37d55bf70860eb54ba430c71234e398")
