-- Lua provided by RyzenAPI
-- Game: Ghost Stories 2

-- MAIN APPLICATION
addappid(1423270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1423271, 1, "cfe3203d1ffdf23080d4365524095f5ce37d55bf70860eb54ba430c71234e398")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
