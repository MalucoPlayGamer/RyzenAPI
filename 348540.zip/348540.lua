-- Lua provided by RyzenAPI
-- Game: Divine Slice of Life

-- MAIN APPLICATION
addappid(348540)

-- MAIN APP DEPOTS / PACKAGES
addappid(348541, 1, "2c95bd5b99012e9aa51c352a903f6b539986ea460dd0ffad0610499403292410")
addappid(390470, 0, "25ed79fbb0f2ad2ed3302903a829079f95d05b9c56b4ba3edc75082b71322ae9")

