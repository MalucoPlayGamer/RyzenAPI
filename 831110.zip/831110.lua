-- Lua provided by RyzenAPI
-- Game: Unconventional Warfare

-- MAIN APPLICATION
addappid(831110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(831111, 1, "fa9aab1af8ca117e288b58e8fa18f983bf727f3a96f6939e2faf58fa2b8177b2")
addappid(831112, 1, "7f05feceb14e504694b876d16c8af70b0b42b9ae8f838e3d99951dd622540402")

