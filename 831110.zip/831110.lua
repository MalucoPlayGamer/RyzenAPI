-- Lua provided by RyzenAPI
-- Game: Game: Unconventional Warfare

-- MAIN APPLICATION
addappid(831110)
-- Game: addappid(831110)

-- MAIN APP DEPOTS / PACKAGES
addappid(831111, 1, "fa9aab1af8ca117e288b58e8fa18f983bf727f3a96f6939e2faf58fa2b8177b2")
addappid(831112, 1, "7f05feceb14e504694b876d16c8af70b0b42b9ae8f838e3d99951dd622540402")
