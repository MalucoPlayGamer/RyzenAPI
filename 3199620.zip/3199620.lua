-- Lua provided by RyzenAPI
-- Game: addappid(3199620)

-- MAIN APPLICATION
addappid(3199620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3199621, 1, "813c9f6c6a5dd5df62f1fc388768930b98e0a1e69c9524d1ff8a485559ceda2e")
