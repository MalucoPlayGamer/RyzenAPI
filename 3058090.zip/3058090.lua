-- Lua provided by RyzenAPI
-- Game: GOOOAL

-- MAIN APPLICATION
addappid(3058090)
-- Game: addappid(3058090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3058092,0,"1e33c7fae769e6908482bd3279fac380c60b9cf6eb224aca795a8e5abf113f00")
