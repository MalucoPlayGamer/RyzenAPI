-- Lua provided by RyzenAPI
-- Game: Islands & Trains

-- MAIN APPLICATION
addappid(1957760)
-- Game: addappid(1957760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1957761, 1, "70a29765745ef9af9b4e8d04fc1934826c9e26c3ac9e548cd7f1aabc02553567")
