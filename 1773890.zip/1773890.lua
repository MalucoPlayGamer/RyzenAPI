-- Lua provided by RyzenAPI
-- Game: 100 hidden dogs

-- MAIN APPLICATION
addappid(1773890)
-- Game: addappid(1773890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1773891, 1, "6778f362489446a65a67525d5946d4f818b3bb3348ab06631913212b65aab796")
