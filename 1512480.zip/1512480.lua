-- Lua provided by RyzenAPI
-- Game: addappid(1512480)

-- MAIN APPLICATION
addappid(1512480)
addappid(2293690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1512481, 1, "e49a5243fa8b0d1b3ca52108ea31f9028f760ec91723ce97ecf69fa0df09c6aa")
