-- Lua provided by RyzenAPI
-- Game: SpunkStock: Music Festival Demo

-- MAIN APPLICATION
addappid(2161020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2161021, 1, "2fc9c21994603b871295540534d1cd077e75a0768bc95d948bf664262e8ae93d")

