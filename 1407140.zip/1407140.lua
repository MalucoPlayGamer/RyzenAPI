-- Lua provided by RyzenAPI
-- Game: Furry house

-- MAIN APPLICATION
addappid(1407140)
-- Game: addappid(1407140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407142,0,"651997a83d0aeea61a97bc0fcfe4e277079660666e24640fa869e6b730a165b0")
