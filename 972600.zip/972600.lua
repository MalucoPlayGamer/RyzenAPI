-- Lua provided by RyzenAPI
-- Game: Block Pooper 9

-- MAIN APPLICATION
addappid(972600)

-- MAIN APP DEPOTS / PACKAGES
addappid(972601, 1, "0a6e8f8870cd0f82c51efb68bb94cae44b560ea92e04866408657c5307dba0f9")
