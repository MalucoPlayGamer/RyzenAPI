-- Lua provided by RyzenAPI
-- Game: Paint By Numbers

-- MAIN APPLICATION
addappid(1605290)
-- Game: addappid(1605290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1605291, 1, "c794b208adce8758fcb5b1fe4b4e80cf7c036e13c4327ba7951e207afa6d7de5")
