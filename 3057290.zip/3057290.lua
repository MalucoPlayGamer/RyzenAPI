-- Lua provided by RyzenAPI
-- Game: Furry Adventure Club and the Holy Grail 🦁

-- MAIN APPLICATION
addappid(3057290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3057291, 1, "728aa49b1fe454fa72a413bcb66ed683a59cf32f6151b70810ddce0dd2399c98")
addappid(3332610, 0, "74ced397e8500bf263fd75722ca69bfa9b9315935cbe5f9e81a72b809f194a47")
addappid(3358050, 0, "02a894f94e0da123bdaa0ccf1e94009b3d5de9bab6c14627dfb67dd30e92193a")
addappid(3768840, 0, "35e0b1cb12f68967f43e88aae377fbdbf63d0ebf2bb22ccf1c3dd710cbf13f81")
