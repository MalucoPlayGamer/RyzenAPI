-- Lua provided by RyzenAPI
-- Game: Game: AppID 1102100

-- MAIN APPLICATION
addappid(1102100)
-- Game: addappid(1102100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1102101, 1, "485990aa773cab63e92e8888b397ab7aeaa39a523cd309b8e195c4e7163ab723")
