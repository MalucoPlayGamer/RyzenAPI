-- Lua provided by RyzenAPI
-- Game: TINY METAL: FULL METAL RUMBLE

-- MAIN APPLICATION
addappid(1261860)
addappid(1261861)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
addappid(1102100, 1, "946d12ade0bd674e06769a329d342d28226eb39f26a6b8ec4b72ffcff50b4bf7") -- TINY METAL: FULL METAL RUMBLE
addappid(1102101, 1, "485990aa773cab63e92e8888b397ab7aeaa39a523cd309b8e195c4e7163ab723") -- TINY METAL: FULL METAL RUMBLE Content
addappid(1261860, 1, "c9a361844a3e8d245d87d5d00a4b20f3bca20ef6a2f78c904640107f8c9dec7e") -- TINY METAL Will of the Shogun - TINY METAL: Will of the Shogun Depot
addappid(1261861, 1, "22c43669c90faa3a119b0af33c23ee53b47f2af7dd70d76f1ae880ae7c3d45a6") -- TINY METAL Caesers Rescue - TINY METAL: Caeser's Rescue Depot

