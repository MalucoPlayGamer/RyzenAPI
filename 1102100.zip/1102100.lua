-- 1102100's Lua and Manifest Created by Hubcap Manifest
-- TINY METAL: FULL METAL RUMBLE
-- Created: January 15, 2026 at 10:48:20 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 2
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(1102100, 1, "946d12ade0bd674e06769a329d342d28226eb39f26a6b8ec4b72ffcff50b4bf7") -- TINY METAL: FULL METAL RUMBLE
-- MAIN APP DEPOTS
addappid(1102101, 1, "485990aa773cab63e92e8888b397ab7aeaa39a523cd309b8e195c4e7163ab723") -- TINY METAL: FULL METAL RUMBLE Content
setManifestid(1102101, "2613369801001502245", 894885658)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)
-- DLCS WITH DEDICATED DEPOTS
-- TINY METAL Will of the Shogun (AppID: 1261860)
addappid(1261860)
addappid(1261860, 1, "c9a361844a3e8d245d87d5d00a4b20f3bca20ef6a2f78c904640107f8c9dec7e") -- TINY METAL Will of the Shogun - TINY METAL: Will of the Shogun Depot
setManifestid(1261860, "5132321321627741134", 32)
-- TINY METAL Caesers Rescue (AppID: 1261861)
addappid(1261861)
addappid(1261861, 1, "22c43669c90faa3a119b0af33c23ee53b47f2af7dd70d76f1ae880ae7c3d45a6") -- TINY METAL Caesers Rescue - TINY METAL: Caeser's Rescue Depot
setManifestid(1261861, "1363981756881676852", 13)