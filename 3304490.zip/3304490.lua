-- Lua provided by RyzenAPI
-- Game: The Japanese Calligraphy

-- MAIN APPLICATION
addappid(3304490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3304491, 1, "de72eb07898794f917d855e334a00cf6ee606c01421656e5e7c39677e3060cff")
