-- Lua provided by RyzenAPI
-- Game: 3754500

-- MAIN APPLICATION
addappid(3754500)
-- Game: addappid(3754500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3754501, 1, "8ee2cab247c16204b61c7f32a4d162582e9f407f84ca1c5268ea4629d620a22b")
