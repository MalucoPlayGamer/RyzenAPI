-- Lua provided by RyzenAPI
-- Game: addappid(1341160)

-- MAIN APPLICATION
addappid(1341160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341161, 1, "7dfd2c1d0a80f14ba8a05f58e2240bb9e57b0d67ffe3c0ddc0b88668248eeaa5")
addappid(1341162, 1, "17e73ef8c3f9e0161b787a57a0034b8868d017e9ef4257df27e7791aa0b7e1c9")
