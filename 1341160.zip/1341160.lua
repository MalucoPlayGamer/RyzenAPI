-- Lua provided by RyzenAPI
-- Game: Infinite Tournament Paintball

-- MAIN APPLICATION
addappid(1341160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341161, 1, "7dfd2c1d0a80f14ba8a05f58e2240bb9e57b0d67ffe3c0ddc0b88668248eeaa5")
addappid(1341162, 1, "17e73ef8c3f9e0161b787a57a0034b8868d017e9ef4257df27e7791aa0b7e1c9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
