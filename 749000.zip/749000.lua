-- Lua provided by RyzenAPI
-- Game: Final Cut: Homage Collector's Edition

-- MAIN APPLICATION
addappid(749000)

-- MAIN APP DEPOTS / PACKAGES
addappid(749001,0,"60f91276df5b1bf1434ee0682eb39fd72b40e2bd7aea25d2ad9cc7f5698f6369")

