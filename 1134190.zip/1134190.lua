-- Lua provided by RyzenAPI
-- Game: 1134190

-- MAIN APPLICATION
addappid(1134190)
-- Game: addappid(1134190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134191, 1, "45ecb5cda5be3d414b08e30c90e2d7b3ede8db503ad0be3851ff9048e2555df4")
