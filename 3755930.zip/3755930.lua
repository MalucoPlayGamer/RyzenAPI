-- 3755930's Lua and Manifest Created by Hubcap Manifest
-- The Severed Gods
-- Created: August 11, 2026 at 12:35:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3755930) -- The Severed Gods
-- MAIN APP DEPOTS
addappid(3755931, 1, "693b2e159a9a0f6dba150fb79b24d2aeb8a4af91e2cf5c85b0bb5a30dddce5ea") -- Depot 3755931
setManifestid(3755931, "1428572681677236797", 4905616277)