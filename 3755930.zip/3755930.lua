-- Lua provided by RyzenAPI
-- Game: The Severed Gods

-- MAIN APPLICATION
addappid(3755930) -- The Severed Gods

-- MAIN APP DEPOTS / PACKAGES
addappid(3755931, 1, "693b2e159a9a0f6dba150fb79b24d2aeb8a4af91e2cf5c85b0bb5a30dddce5ea") -- Depot 3755931

