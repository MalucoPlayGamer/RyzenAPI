-- Lua provided by RyzenAPI
-- Game: Silver Creek Falls: Chapter 1

-- MAIN APPLICATION
addappid(392450)
addappid(405940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(392451, 1, "8acc1e16488d282f9fbb5ce18cc04a27454d8d8ee4b0dab16b45a0c507cb3b6c")

