-- Lua provided by RyzenAPI
-- Game: addappid(392450)

-- MAIN APPLICATION
addappid(392450)
addappid(405940)

-- MAIN APP DEPOTS / PACKAGES
addappid(392451, 1, "8acc1e16488d282f9fbb5ce18cc04a27454d8d8ee4b0dab16b45a0c507cb3b6c")
