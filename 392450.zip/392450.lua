-- Lua provided by RyzenAPI 
-- Game: Silver Creek Falls: Chapter 1
addappid(392450)
addappid(392451, 1, "8acc1e16488d282f9fbb5ce18cc04a27454d8d8ee4b0dab16b45a0c507cb3b6c")
addappid(405940)
