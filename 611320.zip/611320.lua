-- Lua provided by RyzenAPI
-- Game: Think To Die 3

-- MAIN APPLICATION
addappid(611320)

-- MAIN APP DEPOTS / PACKAGES
addappid(611321, 1, "0d105a8a970f0f5205baab918cd8c957e66d672febc0ee99dffe28c1331e78b6")
