-- Lua provided by RyzenAPI
-- Game: Heavy Fire: Afghanistan

-- MAIN APPLICATION
addappid(305980)

-- MAIN APP DEPOTS / PACKAGES
addappid(305981, 1, "8fa92476fddcb139f1e99394da92e091c04d9ed3371e76b235382d83d9f44ee6")

