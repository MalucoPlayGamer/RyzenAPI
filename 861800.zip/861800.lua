-- Lua provided by RyzenAPI
-- Game: addappid(861800)

-- MAIN APPLICATION
addappid(861800)

-- MAIN APP DEPOTS / PACKAGES
addappid(861801, 1, "88ba52fae3de69e7a39adb93fe05ace294dcdd49b3dcaa59f0f4ab42f15aa5ad")
