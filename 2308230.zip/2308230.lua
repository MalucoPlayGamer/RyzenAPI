-- Lua provided by RyzenAPI
-- Game: AppID 2308230

-- MAIN APPLICATION
addappid(2308230)
-- Game: addappid(2308230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2308231, 1, "bed2ab27f7e28819572cd9cf194a16cb3e50e1d992e9e9e758d83f7d5caf076c")
