-- Lua provided by RyzenAPI
-- Game: Graviteam Tactics: Furtive Spring

-- MAIN APPLICATION
addappid(1158490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1158490,0,"52dc09c13f01c7730b94c8882727549667ed25b5950a361d148fece1449b8a0a")
