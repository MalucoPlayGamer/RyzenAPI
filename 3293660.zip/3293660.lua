-- Lua provided by RyzenAPI
-- Game: 3293660

-- MAIN APPLICATION
addappid(3293660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3293662,0,"c7c158277a4221a34e8a77b79badc1dda2ec27f727fa035a9e8ff11ebc8e7ff2")
