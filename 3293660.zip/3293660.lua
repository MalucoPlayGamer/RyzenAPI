-- Lua provided by RyzenAPI
-- Game: Cartier 06

-- MAIN APPLICATION
addappid(3293660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3293662,0,"c7c158277a4221a34e8a77b79badc1dda2ec27f727fa035a9e8ff11ebc8e7ff2")

