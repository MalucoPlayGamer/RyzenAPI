-- Lua provided by RyzenAPI
-- Game: Teddy Floppy Ear - Kayaking

-- MAIN APPLICATION
addappid(340310)
-- Game: addappid(340310)

-- MAIN APP DEPOTS / PACKAGES
addappid(340311, 1, "937bc1b20c6c193c974d9f087897918b8b47e783ad8df3fec3a3f918a571b17f")
addappid(340312, 1, "755ac3833d08ae8e8f6722894f8c5d783b7e18ac30062fdd601bd5ffb904f8fa")
addappid(340313, 1, "b0b40ebc0c366e311cccad40f32ac8454be2d6e2d69246c9278e90d856365f67")
