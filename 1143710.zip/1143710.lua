-- Lua provided by RyzenAPI
-- Game: Тёмное отражение (Dark Reflection)

-- MAIN APPLICATION
addappid(1143710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1143711, 1, "cee3bcc91d3fe0fbe143f28e1dc3793cad77e9c64a15e872893a9966f4cc414c")

