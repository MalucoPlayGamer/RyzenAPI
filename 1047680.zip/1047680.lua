-- Lua provided by RyzenAPI 
-- Game: 亚利利亚的精灵们 ALILIA
addappid(1047680)
addappid(1047681, 1, "a37fc7844451dbc46d5cb8d4a81e291130c0b9730e9aadbe416826ea04884022")
addappid(1075210, 0, "8cba5a29e9384f492732b1616f6dfaad302541a1d7f3658680e4f621f832c4f2")
addappid(1075217)
