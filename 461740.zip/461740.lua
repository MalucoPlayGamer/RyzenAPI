-- Lua provided by RyzenAPI
-- Game: Tower Unite - Original Soundtrack

-- MAIN APPLICATION
addappid(461740)
-- Game: addappid(461740)

-- MAIN APP DEPOTS / PACKAGES
addappid(461740,0,"90afe5f0f8ade74799ef9880269451bbfc44a7c7a75d459569649178c05e9474")
