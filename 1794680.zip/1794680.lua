-- 1794680's Lua and Manifest Created by Hubcap Manifest
-- Vampire Survivors
-- Created: August 28, 2026 at 14:59:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 28
-- Total DLCs: 8
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1794680, 1, "4d6aeb4ef64d8f10cf5cc1e532efa20f212f3ec624394ae50b9c18782332b07e") -- Vampire Survivors
-- MAIN APP DEPOTS
addappid(1794681, 1, "a2ae9bd3450da7127b7298a3e66264d71b8413bd7bacd674788ca98df20ee262") -- Vampire Survivors Content
setManifestid(1794681, "326041828055578897", 1224183541)
addappid(1794684, 1, "a9134bad97d12f2af38c1f3fda9df5c1441e987c3931aed6bcbc8a28d76f2ec9") -- Vampire Survivors Mac
setManifestid(1794684, "6504697067018038478", 1170000808)
addappid(1794685, 1, "b84475f8ff35397bf450e3fd9e2b62d63058277871f676dcb7fb506c9b89a599") -- Vampire Survivors Linux
setManifestid(1794685, "8945643991792611088", 1130287809)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
-- DLCS WITH DEDICATED DEPOTS
-- Vampire Survivors Legacy of the Moonspell (AppID: 2230760)
addappid(2230760)
addappid(2230761, 1, "26cf4b06368265325ad0ab20b00118e4a2c1af2a291be8589017fcb6fbb3b42f") -- Vampire Survivors Legacy of the Moonspell - DLC - Legacy of the Moonspell
setManifestid(2230761, "7674937276999197104", 0)
addappid(2230762, 1, "637f60f36d912d8ec9b7e5709787d344cf90850231d771501e903c47c4dd7391") -- Vampire Survivors Legacy of the Moonspell - Depot 2230762
setManifestid(2230762, "157004476975978298", 0)
addappid(2230763, 1, "6a08bb534780032b81fac9fd77e339d7691e64978534c04ee5ce80342112e510") -- Vampire Survivors Legacy of the Moonspell - Depot 2230763
setManifestid(2230763, "8197371098964655276", 15302817)
-- Vampire Survivors Tides of the Foscari (AppID: 2313550)
addappid(2313550)
addappid(2313551, 1, "adde095c43621ed1f47b4d76bc65191b5bb3cf09a92e70cd11c97c46350fc378") -- Vampire Survivors Tides of the Foscari - DLC - Tides of the Foscari
setManifestid(2313551, "6298930804943469542", 0)
addappid(2313552, 1, "a7b5b861ccf517e0c14ce63f873786764694c151a527fe75ec81e02d2c4078a3") -- Vampire Survivors Tides of the Foscari - Depot 2313552
setManifestid(2313552, "8113761075626417808", 0)
addappid(2313553, 1, "da82ac8729e1fe259dfdd0201ec6c0844448797142f1a16ad4161057eb8666be") -- Vampire Survivors Tides of the Foscari - Depot 2313553
setManifestid(2313553, "1834948645539404906", 22739509)
-- Vampire Survivors Emergency Meeting (AppID: 2690330)
addappid(2690330)
addappid(2690331, 1, "09822b168eeb05c438b31f60b76fd5950c7c14544a39134692c129d6f4c7e105") -- Vampire Survivors Emergency Meeting - DLC - Emergency Meeting
setManifestid(2690331, "4436524135990262943", 0)
addappid(2690332, 1, "994a55d68c41e8619e392b1f6b218aa5db3741f0db1c0dc50f278ad7296f6b4e") -- Vampire Survivors Emergency Meeting - Depot 2690332
setManifestid(2690332, "822390797121391660", 0)
addappid(2690333, 1, "7df8a8ddc5c8e37e64f2f59972fdc175a5f78246b38fcfd3280fd945746db92e") -- Vampire Survivors Emergency Meeting - Depot 2690333
setManifestid(2690333, "8681188772200827962", 19246264)
-- Vampire Survivors Operation Guns (AppID: 2887680)
addappid(2887680)
addappid(2887681, 1, "d3b3c80802a7007f3395fc2878accfc81fed7321a08b7ad295c50bbf10b9751b") -- Vampire Survivors Operation Guns - DLC - Operation Guns
setManifestid(2887681, "7723457880087459442", 0)
addappid(2887682, 1, "7883e4a2141db966f23677062d3c440c1b5e639a0dc7166104a00a78a4b468db") -- Vampire Survivors Operation Guns - DLC - Operation Guns macOS
setManifestid(2887682, "4983207104560696957", 0)
addappid(2887683, 1, "8fae317404eb07fb5ef79a30d864888ec98d54c2ba86d3aa73cb68c24833eaca") -- Vampire Survivors Operation Guns - DLC - Operation Guns Linux
setManifestid(2887683, "2372003192776274544", 36499146)
-- Vampire Survivors Ode to Castlevania (AppID: 3210350)
addappid(3210350)
addappid(3210351, 1, "20bd752769ea846ec3f34122e7dd6f794271ddd9b92b26d40fff8ec626b96712") -- Vampire Survivors Ode to Castlevania - DLC - Ode to Castlevania
setManifestid(3210351, "9083880375047846634", 0)
addappid(3210352, 1, "06faab96cfe4d11f9039207877895bfc277af9fc1170a9aca3526a454b673f81") -- Vampire Survivors Ode to Castlevania - DLC - Ode to Castlevania macOS
setManifestid(3210352, "6084200570634034628", 0)
addappid(3210353, 1, "742b108aa899a7b540833b12635802c7af80429baec59fda51e5872ea0bb0462") -- Vampire Survivors Ode to Castlevania - DLC - Ode to Castlevania Linux
setManifestid(3210353, "8567368620925892149", 333782911)
-- Vampire Survivors Emerald Diorama (AppID: 3451100)
addappid(3451100)
addappid(3451101, 1, "f1fb7a83af500f4b37e49abab974a6c77db031e8d0eee2a288d1bea11aacd689") -- Vampire Survivors Emerald Diorama - Depot 3451101
setManifestid(3451101, "6247679012594139133", 0)
addappid(3451102, 1, "6990834d031cf75fb872c26b3449027664654e2bf1fe786c790ef57e1acdf967") -- Vampire Survivors Emerald Diorama - Depot 3451102
setManifestid(3451102, "4477532991522409767", 51802238)
addappid(3451103, 1, "64e0c2caee02183f5f83faa5ada8f355df5a4f88c7fb639a8a350961cc31c474") -- Vampire Survivors Emerald Diorama - Depot 3451103
setManifestid(3451103, "3399867216081719292", 0)
-- Vampire Survivors Ante Chamber (AppID: 3929770)
addappid(3929770)
addappid(3929771, 1, "809079707c75f9e1be161bf803bc9ce3a6351f2e87fc969f9c3fa60384fe96f2") -- Vampire Survivors Ante Chamber - Depot 3929771
setManifestid(3929771, "5671806173523215542", 0)
addappid(3929772, 1, "6d7fe71d8acb5efc7a9069f832a56e83e726eb99463e65d7bf0278606c895572") -- Vampire Survivors Ante Chamber - Depot 3929772
setManifestid(3929772, "8202018605663686404", 5010778)
addappid(3929773, 1, "008cdc7bf0ddab9c5b18b353dcdd9d65c8e4de2ffe0b9d522007fc5bfa2e06de") -- Vampire Survivors Ante Chamber - Depot 3929773
setManifestid(3929773, "8923528696351680416", 0)
-- Vampire Survivors Legacy of the Bloodmoon (AppID: 4781330)
addappid(4781330)
addappid(4781331, 1, "c8debe4aa47d525d28900ab7e95177beca0269d59eab86cbdb142c233d6c831b") -- Vampire Survivors Legacy of the Bloodmoon - Depot 4781331
setManifestid(4781331, "4326968107382995632", 0)
addappid(4781332, 1, "4974758173f168fd7dd766a8439d057a1109d647bc8ba003a54b788062c25836") -- Vampire Survivors Legacy of the Bloodmoon - Depot 4781332
setManifestid(4781332, "4909566786934603274", 0)
addappid(4781333, 1, "43c9b9c87844f16471874083e1d2ac0fa972c172213fabf609bee970e9b6172c") -- Vampire Survivors Legacy of the Bloodmoon - Depot 4781333
setManifestid(4781333, "3565143859592918628", 0)