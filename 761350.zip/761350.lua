-- Lua provided by RyzenAPI
-- Game: Booth: A Dystopian Adventure

-- MAIN APPLICATION
addappid(761350)
-- Game: addappid(761350)

-- MAIN APP DEPOTS / PACKAGES
addappid(761351, 1, "6e411f2e8c761bc526f4a71452834778a68df565cdac944cf484de20c5e8a975")
