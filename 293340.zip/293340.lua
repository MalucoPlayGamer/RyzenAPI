-- Lua provided by RyzenAPI
-- Game: 293340

-- MAIN APPLICATION
addappid(293340)
-- Game: addappid(293340)

-- MAIN APP DEPOTS / PACKAGES
addappid(293342,0,"de41adfed54f375d03d32b227b6383842e6751da14ed7fb4ada89ce0297e114f")
addappid(293343,0,"def2be9dcf7757c796fd3cb27a98584dad3da0b31d555d4177ac9d17826d9911")
