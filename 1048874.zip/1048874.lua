-- Lua provided by RyzenAPI
-- Game: Beat Saber - RIOT - "Overkill"

-- MAIN APPLICATION
addappid(1048874)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048874,0,"496f28e037161e535e26c7712b0613439bf1a188d03efc14b61c131873214767")

