-- Lua provided by RyzenAPI
-- Game: addappid(2653260)

-- MAIN APPLICATION
addappid(2653260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653261, 1, "1ce20fb63cc61f51e5c2f66c753129efcc0859122b42f1a2560e45f52bd9440c")
