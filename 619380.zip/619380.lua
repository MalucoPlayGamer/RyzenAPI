-- Lua provided by RyzenAPI
-- Game: The little vampir

-- MAIN APPLICATION
addappid(619380)

-- MAIN APP DEPOTS / PACKAGES
addappid(619381,0,"16b71e11a2918b041082ddfd5039828be2a7b8fcdeedad4eaf32f7467c070f0b")

