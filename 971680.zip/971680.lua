-- Lua provided by RyzenAPI
-- Game: Montaro : RE

-- MAIN APPLICATION
addappid(971680)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(971681, 1, "04d804456985886a898242a5e11ece88b395981a3787dc1e81741ee9683a6bb8")
addappid(971682, 1, "30d2f16b383c9867b79f26dab6b90af95e8952a03ce88b438f63a7855d5cace6")
