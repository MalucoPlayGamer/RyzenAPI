-- Lua provided by RyzenAPI
-- Game: Hidden Pets: 101 Cats in New York

-- MAIN APPLICATION
addappid(3454220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3454221, 1, "7a3ecf66aedceb26c31a892bbe60fc79348492bdd45d17f7bfba867c2c73d497")
