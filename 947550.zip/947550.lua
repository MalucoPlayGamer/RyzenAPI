-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(947550)
-- Game: addappid(947550)

-- MAIN APP DEPOTS / PACKAGES
addappid(947550,0,"1deee04857ecf7ae60b626690586614307c0331e863a8b780e7b0e2c94c90c77")
