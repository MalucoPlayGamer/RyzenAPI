-- Lua provided by RyzenAPI
-- Game: Game: Degraman: Act II. Victor

-- MAIN APPLICATION
addappid(2563440)
-- Game: addappid(2563440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2563441, 1, "7dd5a07145515711e9a9e500498b559b0454c842ca9d0e5712966c064a2b87a6")
