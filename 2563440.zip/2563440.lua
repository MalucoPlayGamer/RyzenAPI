-- Lua provided by SkyAPI 
-- Game: Degraman: Act II. Victor
addappid(2563440)
addappid(2563441, 1, "7dd5a07145515711e9a9e500498b559b0454c842ca9d0e5712966c064a2b87a6")
