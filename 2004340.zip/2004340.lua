-- Lua provided by RyzenAPI
-- Game: Eternal

-- MAIN APPLICATION
addappid(2004340)
-- Game: addappid(2004340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004341, 1, "48f327aea87dc8d82fa9b3c98501779eb451b48c8b02e109da8db597c99d6c73")
