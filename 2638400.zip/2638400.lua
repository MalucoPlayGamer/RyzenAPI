-- Lua provided by RyzenAPI
-- Game: AppID 2638400

-- MAIN APPLICATION
addappid(2638400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2638401, 1, "32476abaf712d30e2c0f0b4cabe90bc3b88dc1c93bc8bccdc4fedc7676e35c12")
