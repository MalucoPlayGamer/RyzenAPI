-- Lua provided by RyzenAPI 
-- Game: Chicory: A Colorful Tale
addappid(1123450)
addappid(1123451, 1, "b4cd0ce8c522800cd37e1ce4a2f47d6f570fd1ed3df8dd1bf10cef18724104fa")
addappid(1123452, 1, "b75b2188c9f776dde7029006973a4c8a8a69d2fb264e9b90a5e1d677a8b22cb0")
addappid(2446380, 0, "b2ec39abef34edb0378b8e336fb50e9b942e92070128b508af9b3e0b017f7759")
