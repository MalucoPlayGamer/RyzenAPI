-- Lua provided by RyzenAPI
-- Game: Deliverance

-- MAIN APPLICATION
addappid(3339450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3339451, 1, "2799bea0abedd628c0701769963ae1b476a5282b7a1d0c567b4ec070c7ec5371")
