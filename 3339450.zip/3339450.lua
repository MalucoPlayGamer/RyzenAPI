-- Lua provided by RyzenAPI
-- Game: Deliverance

-- MAIN APPLICATION
addappid(3339450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3339451, 1, "2799bea0abedd628c0701769963ae1b476a5282b7a1d0c567b4ec070c7ec5371")

