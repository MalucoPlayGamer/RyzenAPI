-- Lua provided by SkyAPI 
-- Game: Agarest: Generations of War
addappid(237890)
addappid(237891, 1, "e180633d64da4ebeed6a7e39d01161298145007473daece7e86b6ad89e209321")
addappid(260960, 0, "c7364c452037b369601db69ecc615a613f160772af5c1396b317dc7207e6fdbd")
