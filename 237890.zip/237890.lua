-- Lua provided by RyzenAPI
-- Game: Agarest: Generations of War

-- MAIN APPLICATION
addappid(237890) -- Agarest: Generations of War
addappid(239860) -- Agarest - Basic Pack DLC
addappid(239880) -- Agarest - Upgrade Pack 1 DLC
addappid(239890) -- Agarest - Offense-Defense Pack DLC
addappid(239900) -- Agarest - Additional-Points Pack 1 DLC
addappid(239920) -- Agarest - Add-on Dungeon 1 DLC
addappid(239940) -- Agarest - Add-on Dungeon 2 DLC
addappid(239950) -- Agarest - Recovery Skill Pack DLC
addappid(240020) -- Agarest - Jack Pack DLC
addappid(240040) -- Agarest - Magic Fight Pack DLC
addappid(240060) -- Agarest - Tonights Dinner DLC
addappid(240070) -- Agarest - Fishy Pack 1 DLC
addappid(240080) -- Agarest - Additional-Points Pack 2 DLC
addappid(240100) -- Agarest - Basic Adventure Pack DLC
addappid(240110) -- Agarest - Rumored Adventure Pack DLC
addappid(240120) -- Agarest - Legendary Adventure Pack DLC
addappid(240130) -- Agarest - Fishy Pack 2 DLC
addappid(240140) -- Agarest - Additional-Points Pack 3 DLC
addappid(240150) -- Agarest - Additional-Points Pack 4 DLC
addappid(240840) -- Agarest - Fallen Angel Pack DLC
addappid(240850) -- Agarest - Dull-Things Pack DLC
addappid(240860) -- Agarest - Legendary-Monster Pack DLC
addappid(240870) -- Agarest - Additional-PP Pack 1 DLC
addappid(240880) -- Agarest - Amateur-Breeder Pack DLC
addappid(240890) -- Agarest - Seasoned-Breeder Pack DLC
addappid(240910) -- Agarest - Top-Breeder Pack DLC
addappid(240930) -- Agarest - Elegant-Holiday Pack DLC
addappid(240940) -- Agarest - Carrot-and-Stick Pack DLC
addappid(240950) -- Agarest - Secret-Society Pack DLC
addappid(240990) -- Agarest - Ceremony Pack DLC
addappid(241040) -- Agarest - Additional-TP Pack DLC
addappid(241050) -- Agarest - Ultimate Equipment Pack DLC
addappid(241060) -- Agarest - Playful Cat Pack DLC
addappid(241120) -- Agarest - Rebellious Pack DLC
addappid(241130) -- Agarest - Additional-PP Pack 2 DLC
addappid(241140) -- Agarest - Unlock Gallery DLC
addappid(241150) -- Agarest - Unlock Voices DLC
addappid(260960)
addappid(307820) -- Agarest Generations of War DLC Bundle 1
addappid(307821) -- Agarest Generations of War DLC Bundle 2
addappid(307822) -- Agarest Generations of War DLC Bundle 3
addappid(307823) -- Agarest Generations of War DLC Bundle 4
addappid(307824) -- Agarest Generations of War DLC Bundle 5
addappid(307825) -- Agarest Generations of War DLC Bundle 6

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(237891, 1, "e180633d64da4ebeed6a7e39d01161298145007473daece7e86b6ad89e209321") -- Agarest: Generations of War Content
addappid(260960, 1, "c7364c452037b369601db69ecc615a613f160772af5c1396b317dc7207e6fdbd") -- Agarest Generations of War Premium Edition Upgrade - Agarest - Collector's Content (260960) Depot

