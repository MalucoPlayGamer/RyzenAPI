-- Lua provided by RyzenAPI
-- Game: Agarest: Generations of War

-- MAIN APPLICATION
addappid(237890)

-- MAIN APP DEPOTS / PACKAGES
addappid(237891, 1, "e180633d64da4ebeed6a7e39d01161298145007473daece7e86b6ad89e209321")
addappid(260960, 0, "c7364c452037b369601db69ecc615a613f160772af5c1396b317dc7207e6fdbd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
