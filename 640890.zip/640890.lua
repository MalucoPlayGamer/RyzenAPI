-- Lua provided by RyzenAPI
-- Game: Will Glow the Wisp

-- MAIN APPLICATION
addappid(640890)
addappid(1216520)

-- MAIN APP DEPOTS / PACKAGES
addappid(640891, 1, "0f5a65a32d861cde2eb706ceba94ed3fc445fef7ba8de0412d911bb124fe82a2")
addappid(640892, 1, "c0e0a27b6b7b7dcd6d3eefc6d1fc427b941d7fdaa98342ac9348c789936a3e3f")
