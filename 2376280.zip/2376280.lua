-- Lua provided by RyzenAPI
-- Game: Whisker Witchery

-- MAIN APPLICATION
addappid(2376280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2376281, 1, "e00a8a4d8d72b23266ecebbb65fd7140f15532afac43810cc5bd7273e28f7867")

