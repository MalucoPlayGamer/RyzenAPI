-- Lua provided by RyzenAPI
-- Game: Whisker Witchery

-- MAIN APPLICATION
addappid(2376280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2376281, 1, "e00a8a4d8d72b23266ecebbb65fd7140f15532afac43810cc5bd7273e28f7867")
