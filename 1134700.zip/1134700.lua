-- Lua provided by RyzenAPI
-- Game: Wild Terra 2: New Lands

-- MAIN APPLICATION
addappid(1134700)
-- Game: addappid(1134700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134701, 1, "4760fc3eb52b780e294b15f3c907e77081c0e04233d5495645c3ac1ff3b6dfc8")
