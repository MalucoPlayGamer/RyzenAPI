-- Lua provided by RyzenAPI
-- Game: Wild Terra 2: New Lands

-- MAIN APPLICATION
addappid(1134700)
addappid(1785760)
addappid(1853210)
addappid(2157370)
addappid(2157371)
addappid(2250730)
addappid(2631620)
addappid(3371670)
addappid(4162100)
addappid(4280510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134701,0,"4760fc3eb52b780e294b15f3c907e77081c0e04233d5495645c3ac1ff3b6dfc8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5058360)
