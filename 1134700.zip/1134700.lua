-- Lua provided by RyzenAPI
-- Game: Wild Terra 2: New Lands

-- MAIN APPLICATION
addappid(1134700)
addappid(1785760)
addappid(1853210)
addappid(2157370)
addappid(2157371)
addappid(2250730)
addappid(2631620)
addappid(3371670)
addappid(4162100)
addappid(4280510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134701,0,"4760fc3eb52b780e294b15f3c907e77081c0e04233d5495645c3ac1ff3b6dfc8")

