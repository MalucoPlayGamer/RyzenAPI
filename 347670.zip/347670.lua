-- Lua provided by RyzenAPI
-- Game: 347670

-- MAIN APPLICATION
addappid(347670)
-- Game: addappid(347670)

-- MAIN APP DEPOTS / PACKAGES
addappid(347671, 1, "01504f734d199d864133be14f8eee7c23bddb08c14d30d6b62f6a44d4c724fb7")
