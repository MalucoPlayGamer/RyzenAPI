-- Lua provided by RyzenAPI 
-- Game: AppID 347670
addappid(347670)
addappid(347671, 1, "01504f734d199d864133be14f8eee7c23bddb08c14d30d6b62f6a44d4c724fb7")
