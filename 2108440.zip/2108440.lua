-- Lua provided by RyzenAPI
-- Game: Lawless West

-- MAIN APPLICATION
addappid(2108440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2108441, 1, "a631c9cfc688af1cbfd72d409116899357f0b7551f9207bbbe5f883e161f84f6")

