-- Lua provided by RyzenAPI
-- Game: YOU DON'T KNOW JACK Vol. 1 XL

-- MAIN APPLICATION
addappid(252730)

-- MAIN APP DEPOTS / PACKAGES
addappid(252731, 1, "1467acfe89363382508e7ad3e26451599b09a3151217452316558b23fafcdc97")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
