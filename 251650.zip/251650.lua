-- Lua provided by RyzenAPI
-- Game: Game: AppID 251650

-- MAIN APPLICATION
addappid(251650)
-- Game: addappid(251650)

-- MAIN APP DEPOTS / PACKAGES
addappid(251651, 1, "bc09f70c2e509ca724be6d0b76c97aca1bf01c46233d2bbeed4af1cce2dbd7fa")
