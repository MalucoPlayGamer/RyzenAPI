-- Lua provided by RyzenAPI
-- Game: Game: AppID 19030

-- MAIN APPLICATION
addappid(19030)
-- Game: addappid(19030)

-- MAIN APP DEPOTS / PACKAGES
addappid(19031, 1, "0d86055c3e3cae3cb6e9cc2513a7281b97b1aca167261ee78d911c052b00d403")
