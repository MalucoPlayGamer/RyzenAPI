-- Lua provided by RyzenAPI 
-- Game: AppID 1996080
addappid(1996080)
addappid(1996081, 1, "1eba7740b5d148853514265e35dd0ae8c97f9188ac4707da421c2807f4c8b8b6")
