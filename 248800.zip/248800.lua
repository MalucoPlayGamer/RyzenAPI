-- Lua provided by RyzenAPI
-- Game: Dysfunctional Systems: Learning to Manage Chaos

-- MAIN APPLICATION
addappid(248800)

-- MAIN APP DEPOTS / PACKAGES
addappid(248801, 1, "5d004f205d374bfbb5b8857f0cbbda05c33e900d5702ab9130d39d4437539b84")
