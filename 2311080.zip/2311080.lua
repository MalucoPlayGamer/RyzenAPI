-- Lua provided by RyzenAPI
-- Game: 2311080

-- MAIN APPLICATION
addappid(2311080)
-- Game: addappid(2311080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311081, 1, "3c8452b4ef48c0b9add00273f4192b94ca6b9172b992a92965918befadd24fe6")
