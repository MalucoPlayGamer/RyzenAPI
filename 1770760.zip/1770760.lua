-- Lua provided by RyzenAPI
-- Game: addappid(1770760)

-- MAIN APPLICATION
addappid(1770760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770761, 1, "2b46a4a36401dddd4494beb26985712efa3d1e449064a8064accf151b69fb0cb")
