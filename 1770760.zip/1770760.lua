-- Lua provided by RyzenAPI
-- Game: Codename: TIARAS

-- MAIN APPLICATION
addappid(1770760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1770761, 1, "2b46a4a36401dddd4494beb26985712efa3d1e449064a8064accf151b69fb0cb")

