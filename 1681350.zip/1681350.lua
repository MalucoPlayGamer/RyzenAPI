-- Lua provided by RyzenAPI
-- Game: Game: 时空梦魇Ⅰ代号608

-- MAIN APPLICATION
addappid(1681350)
-- Game: addappid(1681350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681351, 1, "494435032705250cdb498c4a7e86386aee26198849f4ffe4810c953a5e3f5b54")
