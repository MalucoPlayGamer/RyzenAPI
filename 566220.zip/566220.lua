-- Lua provided by RyzenAPI
-- Game: Brain In My Head

-- MAIN APPLICATION
addappid(566220)

-- MAIN APP DEPOTS / PACKAGES
addappid(566221, 1, "7ff4185a422ae3b30edf810fa29565b44042a436c05aa630c936b9e6807748bd")

