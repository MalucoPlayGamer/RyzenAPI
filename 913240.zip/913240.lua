-- Lua provided by RyzenAPI
-- Game: 913240

-- MAIN APPLICATION
addappid(913240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2704040,0,"8cc2ef0dfd751a9a14d9b6cf29ee927fdeafa051d40601068245b90a2e1b77ee")

