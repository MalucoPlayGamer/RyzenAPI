-- Lua provided by RyzenAPI
-- Game: Pacific Drive: Official Game Soundtrack

-- MAIN APPLICATION
addappid(2790060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2790061, 1, "4b45f62f8977e5f5008cab1d6992a8584a2bdf7ae9c0d1051ae4ff2a1878727c")
addappid(2790062, 1, "05206f1d9154f9166ae13b06af88fcf8fce4b618464872130f3a6508ea5cb622")

