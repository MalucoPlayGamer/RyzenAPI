-- Lua provided by RyzenAPI
-- Game: Hovercars 3077: Underground Demo

-- MAIN APPLICATION
addappid(1964700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964702,0,"25d841c1229041e000f1daa31bb4fcf0e7e6b9c9b099877e38f692b9e6f8681c")

