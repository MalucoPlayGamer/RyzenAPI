-- Lua provided by RyzenAPI
-- Game: Crayon Computer Demo

-- MAIN APPLICATION
addappid(2782940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2782941, 1, "2e1e6a7b4c3c10a9a3b85a3ae53d613cc81e3362012751f90b94472fbaffcbed")
