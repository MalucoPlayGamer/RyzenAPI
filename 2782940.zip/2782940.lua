-- Lua provided by SkyAPI 
-- Game: Crayon Computer Demo
addappid(2782940)
addappid(2782941, 1, "2e1e6a7b4c3c10a9a3b85a3ae53d613cc81e3362012751f90b94472fbaffcbed")
