-- Lua provided by RyzenAPI
-- Game: Extreme-G 2

-- MAIN APPLICATION
addappid(582260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(582261, 1, "3a08db270146682d07e54951a93a74bb9e3e3eb2753685feff9c16f21ce85ce9")

