-- Lua provided by RyzenAPI
-- Game: Game: Extreme-G 2

-- MAIN APPLICATION
addappid(582260)
-- Game: addappid(582260)

-- MAIN APP DEPOTS / PACKAGES
addappid(582261, 1, "3a08db270146682d07e54951a93a74bb9e3e3eb2753685feff9c16f21ce85ce9")
