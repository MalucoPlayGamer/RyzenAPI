-- Lua provided by RyzenAPI
-- Game: AppID 247830

-- MAIN APPLICATION
addappid(247830)
-- Game: addappid(247830)

-- MAIN APP DEPOTS / PACKAGES
addappid(247831, 1, "132066d8c2d5db71f2418ecf8e16d214aeee4ce69a273ec1f2e288cb0f20dc36")
addappid(247832, 1, "6e8c1cf95ccbd6f552548070e9a8242b8beed44783edc9bb13d2fc2866803498")
addappid(247833, 1, "567bf71da422b9c1c758e83b8f6feb85d98f14175a51f28c3d341ca0cf49d0c6")
addappid(247834, 1, "75dc3812af417ee5ea7fcd2a9decf5c4dd458b617f41c06e298d07c74c4d7d54")
addappid(247835, 1, "977a81e3b8776f95ff7ef81ff2f15d4684e0701d7d336625829d3325395cf6c0")
addappid(247836, 1, "ba53cfaa1a6a5e42edd6fbdb374c29ecfeed935e1ff62f5736b025db990afa3c")
