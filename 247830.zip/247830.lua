-- 247830's Lua and Manifest Created by Hubcap Manifest
-- Aerena
-- Created: September 28, 2025 at 21:35:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 7
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(247830) -- Aerena
-- MAIN APP DEPOTS
addappid(247831, 1, "132066d8c2d5db71f2418ecf8e16d214aeee4ce69a273ec1f2e288cb0f20dc36") -- Aerena Content
setManifestid(247831, "4476776056318260476", 223910762)
addappid(247832, 1, "6e8c1cf95ccbd6f552548070e9a8242b8beed44783edc9bb13d2fc2866803498") -- Aerena Depot OSX
setManifestid(247832, "1360634581125691069", 228422070)
addappid(247833, 1, "567bf71da422b9c1c758e83b8f6feb85d98f14175a51f28c3d341ca0cf49d0c6") -- Aerena Depot English
setManifestid(247833, "8777475457613766587", 173820)
addappid(247834, 1, "75dc3812af417ee5ea7fcd2a9decf5c4dd458b617f41c06e298d07c74c4d7d54") -- Aerena Depot English OSX
setManifestid(247834, "8254043018193782014", 173820)
addappid(247835, 1, "977a81e3b8776f95ff7ef81ff2f15d4684e0701d7d336625829d3325395cf6c0") -- Aerena Depot German
setManifestid(247835, "2790876943194909420", 172223)
addappid(247836, 1, "ba53cfaa1a6a5e42edd6fbdb374c29ecfeed935e1ff62f5736b025db990afa3c") -- Aerena Depot German OSX
setManifestid(247836, "4669430164094136352", 172223)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 242743889)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(277580) -- AERENA Deluxe Founders Package
addappid(277581) -- AERENA Base Founders Package
addappid(294300) -- AERENA PAX Pack
addappid(294301) -- AERENA Starter Pack
addappid(294302) -- AERENA Supporter Pack
addappid(294303) -- AERENA Fan Pack
addappid(294304) -- AERENA Pilot Pack