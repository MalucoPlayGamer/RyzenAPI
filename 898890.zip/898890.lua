-- Lua provided by RyzenAPI
-- Game: Endling - Extinction is Forever

-- MAIN APPLICATION
addappid(898890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(898891,0,"49b1a896b32b802b6dc329d1fca3442dea746ae257bec563de03cd985989cd96")
addappid(2081531,0,"f1738038675b3a68fa8fddb46a7eeb21bd45a7a733410a71851c8c9d2ced7eb2")

