-- Lua provided by RyzenAPI
-- Game: Endling - Extinction is Forever

-- MAIN APPLICATION
addappid(898890)

-- MAIN APP DEPOTS / PACKAGES
addappid(898891, 1, "49b1a896b32b802b6dc329d1fca3442dea746ae257bec563de03cd985989cd96")

