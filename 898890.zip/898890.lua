-- Lua provided by RyzenAPI
-- Game: Endling - Extinction is Forever

-- MAIN APPLICATION
addappid(898890)

-- MAIN APP DEPOTS / PACKAGES
addappid(898891,0,"49b1a896b32b802b6dc329d1fca3442dea746ae257bec563de03cd985989cd96")
addappid(2081531,0,"f1738038675b3a68fa8fddb46a7eeb21bd45a7a733410a71851c8c9d2ced7eb2")

