-- Lua provided by RyzenAPI
-- Game: The Chemist

-- MAIN APPLICATION
addappid(716380)

-- MAIN APP DEPOTS / PACKAGES
addappid(716381,0,"17d96a8234798b1a5172c2e93dc65ddfb9fcf804ae3eee4150bbf0b82178f840")

