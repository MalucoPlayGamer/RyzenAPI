-- Lua provided by RyzenAPI
-- Game: Game: Gunner, HEAT, PC!

-- MAIN APPLICATION
addappid(1705180)
-- Game: addappid(1705180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705181, 1, "9dba2a78017b5384c4cc0cf599c6b3fe252c3635dcef818c04f98aa9ea9374e9")
