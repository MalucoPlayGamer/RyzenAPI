-- Lua provided by RyzenAPI
-- Game: The Mobius: Apartment

-- MAIN APPLICATION
addappid(2499270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499271, 1, "f3115fe2c3d8f97d61c412bf99d1cdc5776e480927d0682c97ad1b5a4f38cf98")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
