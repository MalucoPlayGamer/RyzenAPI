-- Lua provided by RyzenAPI
-- Game: 2499270

-- MAIN APPLICATION
addappid(2499270)
-- Game: addappid(2499270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499271, 1, "f3115fe2c3d8f97d61c412bf99d1cdc5776e480927d0682c97ad1b5a4f38cf98")
