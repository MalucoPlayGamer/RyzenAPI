-- Lua provided by RyzenAPI
-- Game: Super Jagua

-- MAIN APPLICATION
addappid(514890)
-- Game: addappid(514890)

-- MAIN APP DEPOTS / PACKAGES
addappid(514891, 1, "1c4cbeb85248cdba1576f95cd3793402895c734479b443368c380b26d8d1f5c3")
addappid(514892, 1, "a42941c0235117fa010773d1f2aa430b42efc0f9e3910af07ce2db21fe4a91e9")
addappid(514893, 1, "ad574e9945587d0caa8a3770a220f951519ddb1e6852c7b1c1e16de637e08d56")
