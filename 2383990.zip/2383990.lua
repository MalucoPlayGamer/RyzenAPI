-- Lua provided by RyzenAPI
-- Game: Ghostbusters: Spirits Unleashed Ecto Edition

-- MAIN APPLICATION
addappid(2383990)
addappid(2624240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383991, 1, "7859749405f0254218686a9d95a6b301216c512b3dd29f4eca423e8d0f18d534")
