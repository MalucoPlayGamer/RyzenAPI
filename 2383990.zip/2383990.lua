-- Lua provided by RyzenAPI
-- Game: Ghostbusters: Spirits Unleashed Ecto Edition

-- MAIN APPLICATION
addappid(2383990)
addappid(2624240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2383991, 1, "7859749405f0254218686a9d95a6b301216c512b3dd29f4eca423e8d0f18d534")

