-- Lua provided by RyzenAPI
-- Game: World of Tanks Blitz Playtest

-- MAIN APPLICATION
addappid(3341250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3341251, 1, "d9e54e45120c44253288be4379eeb5543ff8597db00808d2d7a0ab0442a988cc")
