-- Lua provided by RyzenAPI 
-- Game: Three Days
addappid(375580)
addappid(375581, 1, "f047e7d807a0e01cd00b4b841e3c6363cea3ef8eac8cc6ff5830be5e7bef9d0b")
