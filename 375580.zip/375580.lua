-- Lua provided by RyzenAPI
-- Game: Three Days

-- MAIN APPLICATION
addappid(375580)

-- MAIN APP DEPOTS / PACKAGES
addappid(375581, 1, "f047e7d807a0e01cd00b4b841e3c6363cea3ef8eac8cc6ff5830be5e7bef9d0b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
