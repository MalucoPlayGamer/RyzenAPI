-- 4300870's Lua and Manifest Created by Hubcap Manifest
-- Gods & Gore
-- Created: August 05, 2026 at 22:36:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4300870) -- Gods & Gore
-- MAIN APP DEPOTS
addappid(4300871, 1, "262047185d66cd2bd6391e11a30071bff1ce8479d7c888195eb408e989bb6be3") -- Depot 4300871
setManifestid(4300871, "2512977747896768988", 2596553956)