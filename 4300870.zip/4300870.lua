-- Lua provided by RyzenAPI
-- Game: Gods & Gore

-- MAIN APPLICATION
addappid(4300870) -- Gods & Gore

-- MAIN APP DEPOTS / PACKAGES
addappid(4300871, 1, "262047185d66cd2bd6391e11a30071bff1ce8479d7c888195eb408e989bb6be3") -- Depot 4300871

