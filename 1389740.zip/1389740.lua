-- Lua provided by RyzenAPI
-- Game: Accel Magician Mimi

-- MAIN APPLICATION
addappid(1389740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389741, 1, "39d6d161ebbe1279647b35c2eb3fa626148d7543d367cbe5eb300253c7663291")
