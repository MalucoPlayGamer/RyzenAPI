-- Lua provided by RyzenAPI
-- Game: AppID 312220

-- MAIN APPLICATION
addappid(312220)

-- MAIN APP DEPOTS / PACKAGES
addappid(312221, 1, "9a2c35438fadfe5370ef30b6ee0457f8c4406db3c7156d8b03bd03c8d129dcaa")

