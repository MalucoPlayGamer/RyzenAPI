-- Lua provided by RyzenAPI 
-- Game: Sex Adventures - The SPA
addappid(1897720)
addappid(1897721, 1, "732df567d62e651501aa041f40c5e1924fb0ec652a05938c5b3d296a4408b19c")
