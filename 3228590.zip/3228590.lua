-- Lua provided by RyzenAPI
-- Game: 3228590

-- MAIN APPLICATION
addappid(3228590)
addappid(3897660)
-- Game: addappid(3228590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3228591, 1, "ff50f696309f1bdaedc819a0dfc5ad20497d9884179b19683f5ceba047094567")
