-- Lua provided by SkyAPI 
-- Game: AppID 3228590
addappid(3228590)
addappid(3228591, 1, "ff50f696309f1bdaedc819a0dfc5ad20497d9884179b19683f5ceba047094567")
addappid(3897660)
