-- Lua provided by RyzenAPI
-- Game: AppID 3228590

-- MAIN APPLICATION
addappid(3228590)
addappid(3897660)
addappid(4208730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3228591, 1, "ff50f696309f1bdaedc819a0dfc5ad20497d9884179b19683f5ceba047094567")

