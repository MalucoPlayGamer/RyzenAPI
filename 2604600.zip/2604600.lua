-- Lua provided by RyzenAPI
-- Game: Loi The Lover

-- MAIN APPLICATION
addappid(2604600)
-- Game: addappid(2604600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2604601, 1, "8367f98469ce4d662d3997d374c72a571a235421d0db4a1e86dd39b7d7006192")
