-- Lua provided by RyzenAPI
-- Game: addappid(3273090)

-- MAIN APPLICATION
addappid(3273090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3273091, 1, "b3ee16ef947a5fb4ab9272897d8553215f113687a6ad2566be13b6a861bd9d31")
