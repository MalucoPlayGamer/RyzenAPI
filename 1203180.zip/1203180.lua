-- Lua provided by RyzenAPI
-- Game: Game: Breakwaters: Crystal Tides

-- MAIN APPLICATION
addappid(1203180)
-- Game: addappid(1203180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203181, 1, "6ffb43431f0aec5a29ce2f7fdd4329543359bebbcc709820c713a4d4b028e0f3")
