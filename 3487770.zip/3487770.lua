-- Lua provided by RyzenAPI
-- Game: addappid(3487770)

-- MAIN APPLICATION
addappid(3487770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3487771, 1, "8e340f79eabdfbd32fa3d170f02cf8220158ff3fe1ed7dcb0d0198076b79e682")
