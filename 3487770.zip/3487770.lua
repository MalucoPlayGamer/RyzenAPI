-- Lua provided by RyzenAPI 
-- Game: Idle Commonwealth
addappid(3487770)
addappid(3487771, 1, "8e340f79eabdfbd32fa3d170f02cf8220158ff3fe1ed7dcb0d0198076b79e682")
