-- Lua provided by RyzenAPI
-- Game: AppID 2022430

-- MAIN APPLICATION
addappid(2022430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022431, 1, "f3b3b1dac1ba39be9e5ccb51affe6706782130da45bf8eb0ebcac0d1d2515864")

