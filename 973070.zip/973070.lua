-- Lua provided by RyzenAPI
-- Game: addappid(973070)

-- MAIN APPLICATION
addappid(973070)

-- MAIN APP DEPOTS / PACKAGES
addappid(973071, 1, "455a9b67d102340d32c2eb97c7f901d7f2dc86e2c2ec0c20a627f6db8856c42a")
