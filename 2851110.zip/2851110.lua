-- Lua provided by RyzenAPI
-- Game: addappid(2851110)

-- MAIN APPLICATION
addappid(2851110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2851111, 1, "6718e61ce79ef7d7d856bf2d86783274b7d6155e9552bb92b05d47ea07c4d5ab")
