-- Lua provided by RyzenAPI 
-- Game: Islets Defense
addappid(3235170)
addappid(3235171, 1, "3711a03f0a3dd4f433eb05be626294fe2206997d92c41f9d85ab305240224859")
