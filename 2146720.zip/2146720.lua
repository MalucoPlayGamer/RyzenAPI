-- Lua provided by RyzenAPI 
-- Game: EON Fighter
addappid(2146720)
addappid(2146721, 1, "c9817d89ec4aef7769c42dfa195224f3b621892dbf5f42c58b4302762c2d5b51")
