-- Lua provided by RyzenAPI
-- Game: AUDICA - asms - "Methane Breather"

-- MAIN APPLICATION
addappid(1240301)
-- Game: addappid(1240301)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240301,0,"8cb6a0990f09c8df81431e571c586099133fb93c7c09785413646b63c15698e2")
