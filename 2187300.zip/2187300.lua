-- Lua provided by SkyAPI 
-- Game: Active Soccer 3
addappid(2187300)
addappid(2187301, 1, "ce8a07c2b9ff39e806eea3b6b6c90c35a021d76a8544131fea2731c09fe53172")
