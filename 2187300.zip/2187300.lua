-- Lua provided by RyzenAPI
-- Game: Active Soccer 3

-- MAIN APPLICATION
addappid(2187300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187301, 1, "ce8a07c2b9ff39e806eea3b6b6c90c35a021d76a8544131fea2731c09fe53172")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
