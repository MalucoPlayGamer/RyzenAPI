-- Lua provided by RyzenAPI
-- Game: Game: Active Soccer 3

-- MAIN APPLICATION
addappid(2187300)
-- Game: addappid(2187300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187301, 1, "ce8a07c2b9ff39e806eea3b6b6c90c35a021d76a8544131fea2731c09fe53172")
