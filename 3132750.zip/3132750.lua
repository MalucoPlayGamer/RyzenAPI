-- Lua provided by RyzenAPI
-- Game: Magical Bakery Demo

-- MAIN APPLICATION
addappid(3132750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3132751, 1, "c784c9fa9b02d700aed3ca90f17343689bf636867fdc8bd05f0b42b613844b07")
