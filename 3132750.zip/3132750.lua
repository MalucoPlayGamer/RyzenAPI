-- Lua provided by SkyAPI 
-- Game: Magical Bakery Demo
addappid(3132750)
addappid(3132751, 1, "c784c9fa9b02d700aed3ca90f17343689bf636867fdc8bd05f0b42b613844b07")
