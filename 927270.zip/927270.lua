-- Lua provided by RyzenAPI
-- Game: Game: Accounting+

-- MAIN APPLICATION
addappid(927270)
-- Game: addappid(927270)

-- MAIN APP DEPOTS / PACKAGES
addappid(927271, 1, "8b0090517051888b4f4237a34aae0d4bc474ccc806bd6946e3fe4384828878dd")
