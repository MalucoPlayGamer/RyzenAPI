-- Lua provided by RyzenAPI
-- Game: AppID 1934850

-- MAIN APPLICATION
addappid(1934850)
-- Game: addappid(1934850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1934851, 1, "aff52813c167a7b9af401d124eb156d6adf23c6f52eab1678a5794d19f451c26")
