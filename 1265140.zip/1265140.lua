-- Lua provided by SkyAPI 
-- Game: AppID 1265140
addappid(1265140)
addappid(1265141, 1, "8bd1bf7eef11e5dd37323daac28d724df3cf245d7954424018a9db076324eea4")
