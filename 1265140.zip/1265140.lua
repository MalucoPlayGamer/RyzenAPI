-- Lua provided by RyzenAPI
-- Game: 1265140

-- MAIN APPLICATION
addappid(1265140)
-- Game: addappid(1265140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265141, 1, "8bd1bf7eef11e5dd37323daac28d724df3cf245d7954424018a9db076324eea4")
