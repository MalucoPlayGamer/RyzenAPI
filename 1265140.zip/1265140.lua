-- Lua provided by RyzenAPI
-- Game: Get Gem

-- MAIN APPLICATION
addappid(1265140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1265141, 1, "8bd1bf7eef11e5dd37323daac28d724df3cf245d7954424018a9db076324eea4")

