-- Lua provided by RyzenAPI
-- Game: Game: Arcanbreak

-- MAIN APPLICATION
addappid(1402400)
-- Game: addappid(1402400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1402401, 1, "308fe704583c34f2aec22d00b64e5c429a0e0cf5612140ff925b5876972b9ca2")
