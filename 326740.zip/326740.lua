-- Lua provided by SkyAPI 
-- Game: AppID 326740
addappid(326740)
addappid(326741, 1, "c269a209acf75f311e3111a46fe1e021ba92dda70b8ae7d65e8d3c7e23333e4f")
