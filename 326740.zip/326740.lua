-- Lua provided by RyzenAPI
-- Game: Black Fire

-- MAIN APPLICATION
addappid(326740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(326741, 1, "c269a209acf75f311e3111a46fe1e021ba92dda70b8ae7d65e8d3c7e23333e4f")
