-- Lua provided by RyzenAPI
-- Game: AppID 483490

-- MAIN APPLICATION
addappid(483490)
-- Game: addappid(483490)

-- MAIN APP DEPOTS / PACKAGES
addappid(483491, 1, "9ad3b627e036261e8ea26eaeabc371ea505ae52a41af601df0d30d2d3c28088f")
