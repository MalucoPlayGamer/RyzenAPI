-- Lua provided by RyzenAPI
-- Game: Gotham Knights

-- MAIN APPLICATION
addappid(1496790)
addappid(2074431)

-- MAIN APP DEPOTS / PACKAGES
addappid(1496791, 1, "40ad1c77c16c71b4c353e1a71b9d7c7a5c2cc1474a2333926db9842c70a45df3")
addappid(1496792, 1, "a6bf3c458159607d503b73d7d8868d88b25b0cd748f9641d25a4af3cd9d773e7")
