-- Lua provided by RyzenAPI
-- Game: 2089980

-- MAIN APPLICATION
addappid(2089980)
-- Game: addappid(2089980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089981, 1, "5373f2e2eddeefa6ec7bb22bd940c35cc36e8b5ecab7f222c7a6bc0abecbd38e")
