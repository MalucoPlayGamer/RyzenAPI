-- Lua provided by RyzenAPI 
-- Game: Scalak
addappid(858760)
addappid(858761, 1, "91e4d771ea8734f537e8bba85da843d647d91b521eeb9ab77e9557574f82c8dc")
addappid(858762, 1, "c36bf78074eb75670464c059ce463d871087f99afd78696108c05c63372c7691")
