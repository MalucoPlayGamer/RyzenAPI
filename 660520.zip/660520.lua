-- Lua provided by RyzenAPI
-- Game: AppID 660520

-- MAIN APPLICATION
addappid(660520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(660521, 1, "997015167f364426d338495f38c7eb69d7b294fff418994b2840e5c9aec50ffc")

