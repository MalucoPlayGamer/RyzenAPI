-- Lua provided by RyzenAPI
-- Game: 660520

-- MAIN APPLICATION
addappid(660520)
-- Game: addappid(660520)

-- MAIN APP DEPOTS / PACKAGES
addappid(660521, 1, "997015167f364426d338495f38c7eb69d7b294fff418994b2840e5c9aec50ffc")
