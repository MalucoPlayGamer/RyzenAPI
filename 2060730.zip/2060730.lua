-- Lua provided by RyzenAPI
-- Game: Yandere Goddess: A Snatch Made in Heaven

-- MAIN APPLICATION
addappid(2060730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060731, 1, "404634700032275318ef6cfbd4087083f5c05c2d78993120c2b92cd42382799c")

