-- Lua provided by RyzenAPI
-- Game: Opus Castle

-- MAIN APPLICATION
addappid(1725660)
addappid(1793470)
addappid(3320990)
addappid(3654290)
addappid(3654300)
addappid(3654310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1725661, 1, "d755b80ab7f9bae0f9e07bfadc52daf887a8974ba6f3f9a4ffb625ce43ac2b76")

