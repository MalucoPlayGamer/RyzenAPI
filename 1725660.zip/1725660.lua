-- Lua provided by RyzenAPI
-- Game: 1725660

-- MAIN APPLICATION
addappid(1725660)
-- Game: addappid(1725660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1725661, 1, "d755b80ab7f9bae0f9e07bfadc52daf887a8974ba6f3f9a4ffb625ce43ac2b76")
