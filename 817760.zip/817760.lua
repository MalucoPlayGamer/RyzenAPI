-- Lua provided by RyzenAPI
-- Game: AppID 817760

-- MAIN APPLICATION
addappid(817760)
-- Game: addappid(817760)

-- MAIN APP DEPOTS / PACKAGES
addappid(817761, 1, "47faa606aaeb1ccb87021f6e0fb25b72299f890ee410546abf1236826bbe136d")
