-- Lua provided by RyzenAPI
-- Game: Game: COCOON

-- MAIN APPLICATION
addappid(1497440)
-- Game: addappid(1497440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497441, 1, "3cef947e85b4c01e51727a736bb830ae92bd9e014c9a3d60b0b5d78ac45f3697")
