-- Lua provided by RyzenAPI
-- Game: Pro Basketball Manager 2022

-- MAIN APPLICATION
addappid(1609870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1609871, 1, "a84a731cd0a639fde68a7026c5dcd9f51619619eae4289bff0b581044bc389ec")

