-- Lua provided by RyzenAPI
-- Game: Pro Basketball Manager 2022

-- MAIN APPLICATION
addappid(1609870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1609871, 1, "a84a731cd0a639fde68a7026c5dcd9f51619619eae4289bff0b581044bc389ec")
