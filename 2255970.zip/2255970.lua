-- Lua provided by RyzenAPI
-- Game: Nacht-sama is quitting being the demon king!

-- MAIN APPLICATION
addappid(2255970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2255972,0,"e3c5bdc7fd7dbaa8b6e05704985712e6b12294ea2842a95e46ff585b69fa4273")
addappid(2255973,0,"f9046d70d5e623e4f7cee4fea341036a3a1ed5823a5592de4f4b02e800e6d02c")

