-- Lua provided by RyzenAPI
-- Game: Game: Beyond Flesh and Blood

-- MAIN APPLICATION
addappid(391550)
-- Game: addappid(391550)

-- MAIN APP DEPOTS / PACKAGES
addappid(391551, 1, "3b6f646baf6168179837b9a40632252c0da1b133582720661ef85b411fca080b")
