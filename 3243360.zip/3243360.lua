-- Lua provided by RyzenAPI
-- Game: Game: AppID 3243360

-- MAIN APPLICATION
addappid(3243360)
-- Game: addappid(3243360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3243361, 1, "44945aa58eb09a3b8c14b368b90613d6fbeca6aa5448ece3f5fca4d01c5769df")
