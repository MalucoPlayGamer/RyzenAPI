-- Lua provided by SkyAPI 
-- Game: AppID 3243360
addappid(3243360)
addappid(3243361, 1, "44945aa58eb09a3b8c14b368b90613d6fbeca6aa5448ece3f5fca4d01c5769df")
