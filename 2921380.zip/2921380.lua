-- Lua provided by RyzenAPI
-- Game: Game: Caribbean Crashers

-- MAIN APPLICATION
addappid(2921380)
-- Game: addappid(2921380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2921381, 1, "6035c51fcfc56c2982c15f32fa04f1a4f2e3d72786d255b8d628ffe5c8df0779")
