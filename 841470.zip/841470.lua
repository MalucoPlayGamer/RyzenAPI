-- Lua provided by RyzenAPI 
-- Game: greenTech+ Legacy Edition
addappid(841470)
addappid(841471, 1, "632936df363ab6d9f356994102b3e94393a218a797b4d4694b05413c79cf8b25")
