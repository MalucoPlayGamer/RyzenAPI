-- Lua provided by RyzenAPI
-- Game: GRID Legends

-- MAIN APPLICATION
addappid(1307710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307711, 1, "60b113c0bab9f60878b8f651772e080a6b1f3ec17ab744fc73bd6231333bd405")
addappid(1307712, 1, "0ba8d9b81078ca25cc230006282e584220ec3cfbe464952aed5f4419129f9dfe")
addappid(1307713, 1, "511b87ae7f5570dc0f291b454510aff69b900489cf96dc8483380eaa3dfd25aa")
addappid(1307715, 1, "20864623f4ca814d91f55495e3b329f05594ea804851d28f88df7eb81c2f8425")
addappid(1307716, 1, "fc4c2999bba1c8617d347556400a1263e3c97e4e5b683a56984ae3450f4ac795")
addappid(1307717, 1, "3b5710bbf8a9042c4850d166cea5a90e57407d49d8f70e0cc14b25c473166540")
addappid(1307718, 1, "1a044e0cabda05f5a5bc6b3b06c61952a842a56469c3aa6ccc109c922f985fbd")
addappid(1307719, 1, "905886c285e11db9316f59d20498dc8bf7436aef17f4ceb1cabc0ccaf488ec3e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1745470)
addappid(1745471)
addappid(1745472)
addappid(1745473)
addappid(1745474)
addappid(1745475)
addappid(1745476)
addappid(1745477)
addappid(1918160)
