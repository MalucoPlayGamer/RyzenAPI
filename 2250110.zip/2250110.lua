-- Lua provided by RyzenAPI 
-- Game: AppID 2250110
addappid(2250110)
addappid(2250111, 1, "7a93bba30f5325871114ced1b85af66ff435182b19702d487e4fae1d0d5c5ca9")
