-- Lua provided by RyzenAPI
-- Game: addappid(2250110)

-- MAIN APPLICATION
addappid(2250110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2250111, 1, "7a93bba30f5325871114ced1b85af66ff435182b19702d487e4fae1d0d5c5ca9")
