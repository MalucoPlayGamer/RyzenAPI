-- Lua provided by RyzenAPI
-- Game: Starlink: Battle for Atlas

-- MAIN APPLICATION
addappid(950050)
addappid(1044400)
addappid(1075450)
addappid(1075451)
addappid(1075452)
addappid(1075453)
addappid(1075520)
addappid(1075521)
addappid(1079220)
addappid(1079221)
addappid(1079240)

-- MAIN APP DEPOTS / PACKAGES
addappid(950051,0,"c31833eb6039c37bfcf691ba8f0cdf9ee2361bfe135c7a8d09b43e5052e4d99b")

