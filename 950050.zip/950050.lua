-- Lua provided by RyzenAPI
-- Game: Game: AppID 950050

-- MAIN APPLICATION
addappid(950050)
-- Game: addappid(950050)

-- MAIN APP DEPOTS / PACKAGES
addappid(950051, 1, "c31833eb6039c37bfcf691ba8f0cdf9ee2361bfe135c7a8d09b43e5052e4d99b")
