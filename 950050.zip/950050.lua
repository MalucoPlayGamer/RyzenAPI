-- Lua provided by RyzenAPI
-- Game: Starlink: Battle for Atlas

-- MAIN APPLICATION
addappid(950050)
addappid(1044400)
addappid(1075450)
addappid(1075451)
addappid(1075452)
addappid(1075453)
addappid(1075520)
addappid(1075521)
addappid(1079220)
addappid(1079221)
addappid(1079240)

-- MAIN APP DEPOTS / PACKAGES
addappid(950051,0,"c31833eb6039c37bfcf691ba8f0cdf9ee2361bfe135c7a8d09b43e5052e4d99b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
