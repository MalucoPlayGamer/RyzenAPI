-- Lua provided by RyzenAPI
-- Game: VirtuaVerse

-- MAIN APPLICATION
addappid(1019310)
-- Game: addappid(1019310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019311, 1, "437da3652759cd83c620281798827a92a4e9a84c330bf83240f250c0f4a107cd")
addappid(1019312, 1, "736633116cacaeb8cfa8dfd8f52aa64b459f79412a05d6c3a8852e55c71a3ff3")
addappid(1019313, 1, "5948696e7de7889af8d90dcd886e32747e6b8adaa6c3bb9c5f8456b9367ec50c")
