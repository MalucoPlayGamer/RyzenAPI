-- Lua provided by RyzenAPI 
-- Game: Sword of Atlas
addappid(1840130)
addappid(1840131, 1, "e3dccb4f503baeeca1ce2e9b7e1768750fb670e4ff0bcff17361d2dc02dc4b96")
