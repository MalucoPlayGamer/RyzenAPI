-- Lua provided by RyzenAPI
-- Game: 1840130

-- MAIN APPLICATION
addappid(1840130)
-- Game: addappid(1840130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1840131, 1, "e3dccb4f503baeeca1ce2e9b7e1768750fb670e4ff0bcff17361d2dc02dc4b96")
