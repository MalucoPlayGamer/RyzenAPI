-- Lua provided by RyzenAPI
-- Game: Sword of Atlas

-- MAIN APPLICATION
addappid(1840130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1840131, 1, "e3dccb4f503baeeca1ce2e9b7e1768750fb670e4ff0bcff17361d2dc02dc4b96")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
