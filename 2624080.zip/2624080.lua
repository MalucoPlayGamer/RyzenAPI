-- Lua provided by RyzenAPI
-- Game: MycoRelic

-- MAIN APPLICATION
addappid(2624080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2624081,0,"bb75fa0f712706175cd0af75ac246a74367321715a3466abf04d54df27cea61b")

