-- Lua provided by RyzenAPI
-- Game: Game: Golems TD

-- MAIN APPLICATION
addappid(1473850)
-- Game: addappid(1473850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473851, 1, "c87f0254128844369ae949395d981938c5e7a675fdb85e126e142857385e3b0a")
