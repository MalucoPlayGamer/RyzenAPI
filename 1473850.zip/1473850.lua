-- Lua provided by RyzenAPI
-- Game: Golems TD

-- MAIN APPLICATION
addappid(1473850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1473851, 1, "c87f0254128844369ae949395d981938c5e7a675fdb85e126e142857385e3b0a")

