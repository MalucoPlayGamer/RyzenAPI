-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(423852)
-- Game: addappid(423852)

-- MAIN APP DEPOTS / PACKAGES
addappid(423852,0,"67b4b465e5a7105b24c5b996696901047c48bcb06a65da3c8415c37b58dbe9ea")
addappid(2501440,0,"bbe867cae1866bf5a889613e18e4433c378e7527211cda7ed93d997336898d96")
