-- Lua provided by RyzenAPI
-- Game: Shadow Strikers

-- MAIN APPLICATION
addappid(2622240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2622241,0,"97a65f9b772c4d51b905a1c38ec3ea3281bdca1c69ac1abb827b818eb9cb5b68")

