-- Lua provided by RyzenAPI
-- Game: Rainy Day

-- MAIN APPLICATION
addappid(3192360)

