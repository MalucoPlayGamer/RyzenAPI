-- Lua provided by RyzenAPI
-- Game: Rainy Day

-- MAIN APPLICATION
addappid(3192360)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3486640)
