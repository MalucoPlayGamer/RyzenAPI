-- Lua provided by RyzenAPI
-- Game: Mining And Achievements 挖矿与成就 Demo

-- MAIN APPLICATION
addappid(3176700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3176701, 1, "69d393369af25a197afa97160c83eed3db415d221c976c1bcb3539f98231917e")

