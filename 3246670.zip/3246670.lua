-- Lua provided by RyzenAPI
-- Game: AppID 3246670

-- MAIN APPLICATION
addappid(3246670)
-- Game: addappid(3246670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3246671, 1, "b6ee8eb12eee93f6e195b1838655d3e6df96ecd7bc9e5bbc37ed56cce40bbda0")
