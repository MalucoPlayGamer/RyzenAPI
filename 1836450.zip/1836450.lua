-- Lua provided by RyzenAPI
-- Game: Monster Hunter Rise: Sunbreak Demo

-- MAIN APPLICATION
addappid(1836450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1836451, 1, "c19ddc833f834536776ad2aee3c707d6a35f1c3e389bb09efc8689f7ed131c09")

