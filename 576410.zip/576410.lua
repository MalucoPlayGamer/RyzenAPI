-- Lua provided by RyzenAPI
-- Game: 576410

-- MAIN APPLICATION
addappid(576410)
addappid(581990)
-- Game: addappid(576410)

-- MAIN APP DEPOTS / PACKAGES
addappid(576411, 1, "7c38e7b06986ba78c06bda1e52ae208bef19efc35b89356463db2e8bd267be3a")
