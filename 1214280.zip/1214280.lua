-- Lua provided by RyzenAPI
-- Game: AppID 1214280

-- MAIN APPLICATION
addappid(1214280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214281, 1, "353f55f5660eb2d5df771a70172b8dd55891dce4b887effc3955875c75ffcc24")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
