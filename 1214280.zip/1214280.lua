-- Lua provided by RyzenAPI
-- Game: Game: AppID 1214280

-- MAIN APPLICATION
addappid(1214280)
-- Game: addappid(1214280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214281, 1, "353f55f5660eb2d5df771a70172b8dd55891dce4b887effc3955875c75ffcc24")
