-- Lua provided by SkyAPI 
-- Game: AppID 1214280
addappid(1214280)
addappid(1214281, 1, "353f55f5660eb2d5df771a70172b8dd55891dce4b887effc3955875c75ffcc24")
