-- Lua provided by RyzenAPI
-- Game: LEGO® 2K Drive

-- MAIN APPLICATION
addappid(1451810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451811, 1, "f948c98d4d77df363d73427d4e1731afdfb10dc09a157b6256abcb15664c4f0f")
