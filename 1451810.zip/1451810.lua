-- Lua provided by SkyAPI 
-- Game: LEGO® 2K Drive
addappid(1451810)
addappid(1451811, 1, "f948c98d4d77df363d73427d4e1731afdfb10dc09a157b6256abcb15664c4f0f")
