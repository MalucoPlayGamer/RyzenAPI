-- Lua provided by RyzenAPI
-- Game: LEGO® 2K Drive

-- MAIN APPLICATION
addappid(1451810)
addappid(2353080)
addappid(2353081)
addappid(2353082)
addappid(2353083)
addappid(2353140)
addappid(2353142)
addappid(2353143)
addappid(2353144)
addappid(2353150)
addappid(2353151)
addappid(2353152)
addappid(2353153)
addappid(2353154)
addappid(2353155)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1451811, 1, "f948c98d4d77df363d73427d4e1731afdfb10dc09a157b6256abcb15664c4f0f")

