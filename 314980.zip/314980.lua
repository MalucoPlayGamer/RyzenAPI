-- Lua provided by RyzenAPI
-- Game: Supreme Ruler Ultimate

-- MAIN APPLICATION
addappid(314980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(314981, 1, "bc8b22c5e02271fe6caf325809df56e3ef07faf6d309c6a75bff988df747106c")
addappid(494110, 0, "eb22ceb22e416a374ffd2802452bb599f219858c5919a971e42e1ccfd9df42d4")
addappid(700230, 0, "4446634cd4e2086b7bada9f1cd7c596b1d484cad1eda73202bf6626e3b14a11f")

