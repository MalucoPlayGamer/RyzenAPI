-- Lua provided by RyzenAPI
-- Game: Game: Supreme Ruler Ultimate

-- MAIN APPLICATION
addappid(314980)
-- Game: addappid(314980)

-- MAIN APP DEPOTS / PACKAGES
addappid(314981, 1, "bc8b22c5e02271fe6caf325809df56e3ef07faf6d309c6a75bff988df747106c")
addappid(494110, 0, "eb22ceb22e416a374ffd2802452bb599f219858c5919a971e42e1ccfd9df42d4")
addappid(700230, 0, "4446634cd4e2086b7bada9f1cd7c596b1d484cad1eda73202bf6626e3b14a11f")
