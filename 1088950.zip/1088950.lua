-- Lua provided by RyzenAPI
-- Game: Game: Touring Karts

-- MAIN APPLICATION
addappid(1088950)
-- Game: addappid(1088950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088951, 1, "38879ca07dabf8150370342f1961605ba35f42ddf5dca66a6aeadb62a2f93dba")
