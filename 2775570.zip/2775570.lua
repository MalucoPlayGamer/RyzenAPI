-- Lua provided by RyzenAPI
-- Game: addappid(2775570)

-- MAIN APPLICATION
addappid(2775570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2775571, 1, "51046a5d04302c3b58aafcdc25726bedafc195991873430570cf04a243035add")
