-- Lua provided by RyzenAPI
-- Game: Bachelairs

-- MAIN APPLICATION
addappid(2948380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2948381, 1, "a4212c153e9312570d0f9bcea546b4979c9a94855da21cdf64ec90752384bbeb")
addappid(2948383, 1, "e315bbd78304e82d2751e497517ea8be9b5cf2757ab89ac60f9c9a3257ab3800")

