-- Lua provided by RyzenAPI
-- Game: addappid(467320)

-- MAIN APPLICATION
addappid(467320)

-- MAIN APP DEPOTS / PACKAGES
addappid(467321, 1, "02a3d6568248a4e29f050236b81bcb61adb3a99b681626048014561f3dd61793")
addappid(467322, 1, "e288f5ec0bbcad7a8bcd63e8c4c4bcc1dc6ef668bc5a63276d45755ab5407e17")
