-- Lua provided by RyzenAPI
-- Game: ERISLE

-- MAIN APPLICATION
addappid(493480)

-- MAIN APP DEPOTS / PACKAGES
addappid(493481, 1, "e6ff4aa4ec1858762cf6e5990afef6a6acb14fedbc0df40c6a61b81aaec7cddc")
