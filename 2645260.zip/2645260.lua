-- Lua provided by RyzenAPI 
-- Game: Orb Hunter
addappid(2645260)
addappid(2645261, 1, "3f03ed12e75bcb217eae45343869839826ba121c00d7ed977a4f27cbe637c52f")
