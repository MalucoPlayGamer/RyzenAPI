-- Lua provided by RyzenAPI
-- Game: Orb Hunter

-- MAIN APPLICATION
addappid(2645260)
-- Game: addappid(2645260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2645261, 1, "3f03ed12e75bcb217eae45343869839826ba121c00d7ed977a4f27cbe637c52f")
