-- Lua provided by RyzenAPI
-- Game: Leyline Knights

-- MAIN APPLICATION
addappid(1560260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560261, 1, "46f512d4fc4fa7efd860f6f8e53d2ca154d5e54e0b1078c4541c3cbb5cf60f01")
