-- Lua provided by SkyAPI 
-- Game: Leyline Knights
addappid(1560260)
addappid(1560261, 1, "46f512d4fc4fa7efd860f6f8e53d2ca154d5e54e0b1078c4541c3cbb5cf60f01")
