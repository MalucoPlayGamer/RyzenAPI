-- Lua provided by RyzenAPI
-- Game: Leyline Knights

-- MAIN APPLICATION
addappid(1560260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560261, 1, "46f512d4fc4fa7efd860f6f8e53d2ca154d5e54e0b1078c4541c3cbb5cf60f01")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
