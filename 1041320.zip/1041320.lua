-- Lua provided by RyzenAPI
-- Game: Lords Mobile: Kingdom Wars

-- MAIN APPLICATION
addappid(1041320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1041321, 1, "a7ed5a46f6788ec47446eca93a16f8b3afc300bf6157c2c268bee55fc30902f1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
