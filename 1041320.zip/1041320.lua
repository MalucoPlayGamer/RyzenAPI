-- Lua provided by SkyAPI 
-- Game: Lords Mobile: Kingdom Wars
addappid(1041320)
addappid(1041321, 1, "a7ed5a46f6788ec47446eca93a16f8b3afc300bf6157c2c268bee55fc30902f1")
