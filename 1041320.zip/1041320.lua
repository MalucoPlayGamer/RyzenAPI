-- Lua provided by RyzenAPI
-- Game: 1041320

-- MAIN APPLICATION
addappid(1041320)
-- Game: addappid(1041320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1041321, 1, "a7ed5a46f6788ec47446eca93a16f8b3afc300bf6157c2c268bee55fc30902f1")
