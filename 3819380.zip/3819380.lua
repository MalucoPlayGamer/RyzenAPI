-- Lua provided by RyzenAPI
-- Game: 3819380

-- MAIN APPLICATION
addappid(3819380)
-- Game: addappid(3819380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3819381, 1, "135960d1d48dc49c1c29939feaa5449a4b58ea1c14a7113e8e55a0560ada9397")
