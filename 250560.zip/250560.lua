-- Lua provided by RyzenAPI 
-- Game: Fight The Dragon
addappid(250560)
addappid(250561, 1, "63fb94b46b38f49e41256617077fcb618513164589c03840a6c3aad2b30b29af")
addappid(250562, 1, "cdac37318cef4b31e293602535c8a407f29edbbec4a1bdcefb7342f4a1472bd1")
addappid(250563, 1, "7dcb2d715e052ed1590c689652754cb29130b47d2d7b6449fab619a277812a7e")
