-- Lua provided by RyzenAPI
-- Game: Piworld

-- MAIN APPLICATION
addappid(3167710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3167712,0,"36db888e0d2b03466037c438fbe0fa69e7d2fc251434c29ba5641cd8b1b12ae2")
