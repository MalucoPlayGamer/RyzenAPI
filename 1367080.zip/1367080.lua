-- Lua provided by RyzenAPI
-- Game: MOBILE SUIT GUNDAM BATTLE OPERATION 2

-- MAIN APPLICATION
addappid(1367080)
addappid(2261981)
addappid(2261982)
addappid(2261983)
addappid(2564280)
addappid(2564290)
addappid(2564300)
addappid(2564310)
addappid(2786460)
addappid(2804600)
addappid(2911780)
addappid(3211100)
addappid(3211110)
addappid(3222900)
addappid(3413200)
addappid(3638770)
addappid(3979180)
addappid(4267100)
addappid(4629510)
addappid(4629520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1367081, 1, "c4d042df35bc384da63fa862e16cf856f221e8efa04e3f256c1379054db969cb")

