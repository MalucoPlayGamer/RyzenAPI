-- Lua provided by RyzenAPI
-- Game: 1367080

-- MAIN APPLICATION
addappid(1367080)
-- Game: addappid(1367080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367081, 1, "c4d042df35bc384da63fa862e16cf856f221e8efa04e3f256c1379054db969cb")
