-- Lua provided by RyzenAPI
-- Game: Oh! Edo Towns

-- MAIN APPLICATION
addappid(2019370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2019371, 1, "69ac44825ed2e1d9aedcabfe97519561c7769c625a16852fbafc18acdfaf0acb")

