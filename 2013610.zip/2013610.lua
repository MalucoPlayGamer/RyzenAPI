-- Lua provided by RyzenAPI
-- Game: Game: AppID 2013610

-- MAIN APPLICATION
addappid(2013610)
-- Game: addappid(2013610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2013611, 1, "5e8b03383d0eef9e75cee4d33dccff47b405175c076adfe174776320cae8a69d")
