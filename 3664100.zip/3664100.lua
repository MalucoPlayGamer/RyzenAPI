-- Lua provided by RyzenAPI
-- Game: Game: Hentai Mika

-- MAIN APPLICATION
addappid(3664100)
-- Game: addappid(3664100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3664101, 1, "d39883da6f62ffae7fe5e8b47c410645d62ddf7a1d80373e58ebf29f58fc9e3f")
