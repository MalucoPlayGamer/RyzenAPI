-- Lua provided by RyzenAPI
-- Game: Majin Woman

-- MAIN APPLICATION
addappid(895180)

-- MAIN APP DEPOTS / PACKAGES
addappid(895181, 1, "14ac44cd48e3a15ce7b7a2402d3cbf56f02adf79e09fe801d6a33c4906adb794")
