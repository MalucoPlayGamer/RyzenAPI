-- Lua provided by SkyAPI 
-- Game: Don't Flee
addappid(2304540)
addappid(2304541, 1, "05e9ec7b8e9eaf575688868c135f1e39248c0d50726da63602a3db3b39901e82")
