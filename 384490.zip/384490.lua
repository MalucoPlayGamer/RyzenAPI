-- Lua provided by RyzenAPI
-- Game: NECROPOLIS: BRUTAL EDITION

-- MAIN APPLICATION
addappid(384490)

-- MAIN APP DEPOTS / PACKAGES
addappid(384491, 1, "1e7ea108b07c1a8508c5ff2067db722c65731ea500c9b16d997417ae1eb3ee97")
addappid(384493, 1, "af8d62161cd3d037809eef3d5fe85fd3f52e260a49a06569c87538e237a0f9cf")
addappid(384494, 1, "17d65f52c06f158347fbdf9d4447da3d97b7bd77b727d32a65c1c99bbc76c2d5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(438700)
