-- Lua provided by RyzenAPI 
-- Game: NECROPOLIS: BRUTAL EDITION
addappid(384490)
addappid(384491, 1, "1e7ea108b07c1a8508c5ff2067db722c65731ea500c9b16d997417ae1eb3ee97")
addappid(384493, 1, "af8d62161cd3d037809eef3d5fe85fd3f52e260a49a06569c87538e237a0f9cf")
addappid(384494, 1, "17d65f52c06f158347fbdf9d4447da3d97b7bd77b727d32a65c1c99bbc76c2d5")
