-- Lua provided by RyzenAPI
-- Game: 101 Cats in Rome

-- MAIN APPLICATION
addappid(3347070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3347071, 1, "cfc28284b6526cebaaa43e7d31a2f4c545d7a36c40c5d09e29277db1e72fdacb")

