-- Lua provided by RyzenAPI 
-- Game: AppID 27940
addappid(27940)
addappid(27941, 1, "430f86553554e962dd71ead730f2816538067ae25b240ca9416a42a2f977c91e")
