-- Lua provided by RyzenAPI
-- Game: Dead Horde

-- MAIN APPLICATION
addappid(27940)

-- MAIN APP DEPOTS / PACKAGES
addappid(27941, 1, "430f86553554e962dd71ead730f2816538067ae25b240ca9416a42a2f977c91e")

