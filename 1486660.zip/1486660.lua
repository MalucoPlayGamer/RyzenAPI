-- Lua provided by RyzenAPI
-- Game: AppID 1486660

-- MAIN APPLICATION
addappid(1486660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1486661, 1, "e5cd62215cacdda0bf8ca6f439140b97af70b1b31a547a4996b714e9357f6b9c")
