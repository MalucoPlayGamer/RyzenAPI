-- Lua provided by RyzenAPI
-- Game: Game: AppID 723390

-- MAIN APPLICATION
addappid(723390)
-- Game: addappid(723390)

-- MAIN APP DEPOTS / PACKAGES
addappid(723391, 1, "29372aa10cf85ded05c12283142dbc490e8c54a934a784e0cf2240a65b4c59ed")
addappid(723392, 1, "b1ffa7e05f317c27cd2ad391edcdeab0a04e00f66dd4060a89c67dc0ba96baae")
