-- Lua provided by RyzenAPI
-- Game: AppID 723390

-- MAIN APPLICATION
addappid(723390)

-- MAIN APP DEPOTS / PACKAGES
addappid(723391, 1, "29372aa10cf85ded05c12283142dbc490e8c54a934a784e0cf2240a65b4c59ed")
addappid(723392, 1, "b1ffa7e05f317c27cd2ad391edcdeab0a04e00f66dd4060a89c67dc0ba96baae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
