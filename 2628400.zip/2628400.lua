-- Lua provided by RyzenAPI
-- Game: Cozy Island Idle

-- MAIN APPLICATION
addappid(2628400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2628401, 1, "cdac2142aa1b876cd9e7f4812fa494045277637a51da09309f080da012d6bc94")
