-- Lua provided by RyzenAPI
-- Game: 1991590

-- MAIN APPLICATION
addappid(1991590)
-- Game: addappid(1991590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991591, 1, "a0675a888c74babc72bc4bfc6c491353cb9317866e4da70437d0f3c9766a6c5f")
