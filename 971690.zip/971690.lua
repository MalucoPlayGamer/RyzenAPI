-- Lua provided by RyzenAPI
-- Game: 971690

-- MAIN APPLICATION
addappid(971690)
-- Game: addappid(971690)

-- MAIN APP DEPOTS / PACKAGES
addappid(971691, 1, "a93074f036ef2788f076100a65f687f43f32429eebba2a07cb859ae3f6b392e5")
