-- Lua provided by RyzenAPI
-- Game: 377900

-- MAIN APPLICATION
addappid(228985)
addappid(377900)
addappid(377901)
addappid(377903)
addappid(377904)
addappid(377905)
addappid(412430)
-- Game: addappid(377900)

-- MAIN APP DEPOTS / PACKAGES
addappid(377902,0,"863ba5dffb1fb28b880119ae25e28a19d191b505b949b2b9f832a64f9e9e8839")
