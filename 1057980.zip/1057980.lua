-- Lua provided by RyzenAPI
-- Game: 1057980

-- MAIN APPLICATION
addappid(1057980)
-- Game: addappid(1057980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057981, 1, "abbf0a44d8c5f352181683d4806da20d84435402380be91c6a15188227ceccd8")
