-- Lua provided by RyzenAPI
-- Game: 3430300

-- MAIN APPLICATION
addappid(3430300)
-- Game: addappid(3430300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3430301, 1, "49f55dfa1e0fe61db960b070c933655967af6c5784b392999810aaefbe47dae2")
