-- Lua provided by RyzenAPI
-- Game: Vengeful Guardian: Moonrider

-- MAIN APPLICATION
addappid(1942010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1942011, 1, "f6619d6255fcd9221fe6ed6d1cd120dd83255437c7aab1e50945d63fa344f1d9")

