-- Lua provided by RyzenAPI
-- Game: Vengeful Guardian: Moonrider

-- MAIN APPLICATION
addappid(1942010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1942011, 1, "f6619d6255fcd9221fe6ed6d1cd120dd83255437c7aab1e50945d63fa344f1d9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
