-- Lua provided by RyzenAPI
-- Game: Twilight Phenomena: The Lodgers of House 13 Collector's Edition

-- MAIN APPLICATION
addappid(609340)

-- MAIN APP DEPOTS / PACKAGES
addappid(609341,0,"04c1ab78ca491e62c0841ec0d034a240d4f368014e0c86382abbf701dbf67da0")

