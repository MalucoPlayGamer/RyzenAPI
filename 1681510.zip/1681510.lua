-- Lua provided by RyzenAPI
-- Game: Game: Trenches - World War 1 Horror Survival Game

-- MAIN APPLICATION
addappid(1681510)
-- Game: addappid(1681510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681511, 1, "45a23493b9f54bb6ea314cac02ec9718588af80b02e5065a1cd29d7b093d25c4")
