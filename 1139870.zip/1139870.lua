-- Lua provided by RyzenAPI
-- Game: The Dark Eye : Book of Heroes

-- MAIN APPLICATION
addappid(1139870)
-- Game: addappid(1139870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1139871, 1, "c90874ce5a04b049e32ea78473b8d18ca7d001575189794c28482ddf280c6b3f")
