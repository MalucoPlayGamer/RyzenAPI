-- Lua provided by RyzenAPI
-- Game: 583500

-- MAIN APPLICATION
addappid(583500)
-- Game: addappid(583500)

-- MAIN APP DEPOTS / PACKAGES
addappid(583501, 1, "9dbd0c415473ca7885ad8cbf428d59270eaf0a9fd1928ca9ad5c90947f9ef4c5")
