-- Lua provided by RyzenAPI 
-- Game: Galaxis Wars
addappid(583500)
addappid(583501, 1, "9dbd0c415473ca7885ad8cbf428d59270eaf0a9fd1928ca9ad5c90947f9ef4c5")
