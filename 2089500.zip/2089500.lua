-- Lua provided by RyzenAPI
-- Game: addappid(2089500)

-- MAIN APPLICATION
addappid(2089500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089501, 1, "4b09a98f2e1c49429cddf4080f9bbae2511bfa1ece91b4901f457d642823834d")
