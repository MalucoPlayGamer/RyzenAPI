-- Lua provided by RyzenAPI
-- Game: Game: Juice Galaxy

-- MAIN APPLICATION
addappid(1708150)
-- Game: addappid(1708150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1708151, 1, "350e0a3bacd9f9a558fb952336912411ebc1dd3ea4e13cbc54ffd50c3805e7dd")
addappid(1708152, 1, "a416649c4590909ce21411bbcd5f73de11da733340669e152b74afe1d29c3c34")
addappid(1708153, 1, "4dcaaabed510cd6e63b04067324896dc8713d7da881cf453e3c99c4a43952f9d")
addappid(1708154, 1, "995798dc31b8d22a5405ecef2a8ccb4ad415514fc8b869d9a438e1f1e9acd54c")
addappid(2608730, 0, "81059967d4d512535581edd47d545aaf05ea7990ab3b2a09a931ff0a9f36f250")
