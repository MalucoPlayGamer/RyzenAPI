-- Lua provided by RyzenAPI
-- Game: Wild Animal Sports Day

-- MAIN APPLICATION
addappid(741990)

-- MAIN APP DEPOTS / PACKAGES
addappid(741992,0,"1d04858c72b07c8ba755b45f6be054adc3f90c0404050014ef5a2799d7cced0e")

