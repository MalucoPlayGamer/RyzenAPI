-- Lua provided by RyzenAPI
-- Game: 2072400

-- MAIN APPLICATION
addappid(2072400)
-- Game: addappid(2072400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072401, 1, "18fa81a13517cebf71302e19417c21edd3b4d8c9c66dc539374c7c3a7d59f1ca")
