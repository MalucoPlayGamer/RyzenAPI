-- Lua provided by SkyAPI 
-- Game: SCP: Labrat
addappid(1402020)
addappid(1402021, 1, "37b3528728469583f7773d13abd78ce83d7e4023c5cca168780460652c28dd31")
