-- Lua provided by RyzenAPI
-- Game: Game: Netorare Wife -Yukiko- 20 Years After Marriage

-- MAIN APPLICATION
addappid(2351810)
-- Game: addappid(2351810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2351811, 1, "4ddc6a01364880f706b73ab66ef04284a204655c35a38b899eec4ddc30211080")
addappid(3687690, 0, "cb47a7ef735ff4ea1d56072c17e980d0a40a63ebe4a5dba50ac244e01c7053bc")
