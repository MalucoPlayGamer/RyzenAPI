-- Lua provided by RyzenAPI
-- Game: 1769770

-- MAIN APPLICATION
addappid(1769770)
-- Game: addappid(1769770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1769771, 1, "a22d7f50e46be14e3b47a73fef04e9b38126dc7f4d9b53e930469e50651b25e8")
