-- Lua provided by RyzenAPI
-- Game: Sid Meier's Civilization® III Complete

-- MAIN APPLICATION
addappid(3910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3911, 1, "45df2775d2b6c0fa3afada3b3058410ebb57f90a5924c1b76353e78cf07509e2")
addappid(3912, 1, "138aa36baa3df8233cfa1d8a6a67bac4264c4a94473ed70fe038f787265ee098")
