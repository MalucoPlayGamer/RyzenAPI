-- Lua provided by RyzenAPI
-- Game: Snakelike

-- MAIN APPLICATION
addappid(845110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(845112,0,"64305cc60a6aa0fa789e33b624c7df3afd1294a75f883a4157c4f98c24078eff")
addappid(845113,0,"058dfa2c4f331f59b64bfa265f1016a0d9d777c3255d841ab7afaf90a940f8aa")

