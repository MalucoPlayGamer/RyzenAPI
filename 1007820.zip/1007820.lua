-- Lua provided by RyzenAPI
-- Game: Brawl

-- MAIN APPLICATION
addappid(1007820)
-- Game: addappid(1007820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1007821, 1, "df0d3a0a1350a2941398b755e2679a439a9c61717790b84e9529e3e5388c40b6")
addappid(1007822, 1, "18d094b46f7339826acb14cf34ecaf6ebaef9a46dd744d1051ab5a888325aae4")
addappid(1007823, 1, "e68918ac2e0f05b1db06b6fd144c8baa63bd0c326a49c27a26da598a168ce6c6")
