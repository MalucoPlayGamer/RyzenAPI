-- Lua provided by SkyAPI 
-- Game: Close Combat: Cross of Iron
addappid(1367320)
addappid(1367321, 1, "d03df1749f11e116457cf3b2cefa73d32648e8467b81a2ae270bd469c4835556")
addappid(1367322, 1, "a7075fc30b3f12bf4c9701702c6a5ed02ffcea015c15534357b25503378f6e60")
