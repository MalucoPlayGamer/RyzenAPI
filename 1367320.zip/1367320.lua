-- Lua provided by RyzenAPI
-- Game: Close Combat: Cross of Iron

-- MAIN APPLICATION
addappid(1367320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367321, 1, "d03df1749f11e116457cf3b2cefa73d32648e8467b81a2ae270bd469c4835556")
addappid(1367322, 1, "a7075fc30b3f12bf4c9701702c6a5ed02ffcea015c15534357b25503378f6e60")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
