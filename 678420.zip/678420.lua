-- Lua provided by RyzenAPI
-- Game: Fierce Tales: Marcus' Memory Collector's Edition

-- MAIN APPLICATION
addappid(678420)

-- MAIN APP DEPOTS / PACKAGES
addappid(678421,0,"7717b9b301f45ac629bce9d4b90e32977cb55c03b084e536feb76533d9da113d")

