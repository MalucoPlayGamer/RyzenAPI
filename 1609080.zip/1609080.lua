-- Lua provided by RyzenAPI
-- Game: Summer of '58

-- MAIN APPLICATION
addappid(1609080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1609081, 1, "39dd98df1ed684811bc0483ce6a7b480650d5a95c554c2a3dda45d96440667e9")

