-- Lua provided by RyzenAPI
-- Game: Summer of '58

-- MAIN APPLICATION
addappid(1609080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1609081, 1, "39dd98df1ed684811bc0483ce6a7b480650d5a95c554c2a3dda45d96440667e9")
