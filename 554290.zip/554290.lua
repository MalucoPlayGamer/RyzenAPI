-- Lua provided by RyzenAPI
-- Game: Himawari - The Sunflower -

-- MAIN APPLICATION
addappid(554290)
-- Game: addappid(554290)

-- MAIN APP DEPOTS / PACKAGES
addappid(554292,0,"1712991c364f41ea02e201be55b700aa1b99b3301a76b44f47aa1d03e7b6ea8b")
