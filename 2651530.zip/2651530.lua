-- Lua provided by RyzenAPI
-- Game: addappid(2651530)

-- MAIN APPLICATION
addappid(2651530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651531, 1, "d7596ff5ad3ce043041d79adabb84af953eaed760e20e205f14ed2bc3f95dd4d")
