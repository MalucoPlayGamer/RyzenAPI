-- Lua provided by RyzenAPI
-- Game: 899910

-- MAIN APPLICATION
addappid(899910)
-- Game: addappid(899910)

-- MAIN APP DEPOTS / PACKAGES
addappid(899910,0,"8c1e307bb61bc31785aeaa116d293a0c242339041631bbba5e772e5aca560546")
