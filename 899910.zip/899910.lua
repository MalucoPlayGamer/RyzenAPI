-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Bass - Easy String Skipping Exercise 1

-- MAIN APPLICATION
addappid(899910)

-- MAIN APP DEPOTS / PACKAGES
addappid(899910,0,"8c1e307bb61bc31785aeaa116d293a0c242339041631bbba5e772e5aca560546")

