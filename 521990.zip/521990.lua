-- Lua provided by RyzenAPI
-- Game: addappid(521990)

-- MAIN APPLICATION
addappid(521990)

-- MAIN APP DEPOTS / PACKAGES
addappid(521991, 1, "dbe6ee713711585e7dc53e6831a87af1baf6668007d5769d01e588fa325c8a61")
