-- Lua provided by RyzenAPI 
-- Game: AppID 521990
addappid(521990)
addappid(521991, 1, "dbe6ee713711585e7dc53e6831a87af1baf6668007d5769d01e588fa325c8a61")
