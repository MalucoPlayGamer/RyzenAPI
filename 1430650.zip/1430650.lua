-- Lua provided by RyzenAPI
-- Game: AppID 1430650

-- MAIN APPLICATION
addappid(1430650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1430651, 1, "7eaa254aee85e4702143c98dbd5f2fe3678adc6d0b7edb71a61bbd40ae1da20e")
