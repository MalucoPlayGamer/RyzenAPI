-- Lua provided by RyzenAPI 
-- Game: Streaming ON! VTuber Training
addappid(3470480)
addappid(3470481, 1, "4db4d036f2b4128883b039838cf27142f2d6b9e7a8d26828dd0bd969c9b30189")
