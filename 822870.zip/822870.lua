-- Lua provided by RyzenAPI
-- Game: addappid(822870)

-- MAIN APPLICATION
addappid(822870)

-- MAIN APP DEPOTS / PACKAGES
addappid(822871, 1, "b9891f04f587cb3af9c4715ef6501fd77ba43fc7554ee3b9f36b9cffb7cc037e")
