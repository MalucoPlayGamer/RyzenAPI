-- Lua provided by RyzenAPI
-- Game: Mr Rabbit's Jigsaw Puzzle

-- MAIN APPLICATION
addappid(685040)

-- MAIN APP DEPOTS / PACKAGES
addappid(685041, 1, "bdc89c614d2d15cc93f4b298e1fa3e35e2e6839b0318211ae10521f6fef701af")
addappid(685042, 1, "5542b85ba4252e5fd4602ae9be2c945199ae6b2012abd29ff4dbf0f74e54fb75")

