-- Lua provided by SkyAPI 
-- Game: AppID 849520
addappid(849520)
addappid(849521, 1, "c541c2028ff1cc36a6799cacf96343c6a80a4d0e6bbc00b044a359a1c07a852b")
