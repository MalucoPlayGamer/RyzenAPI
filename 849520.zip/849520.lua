-- Lua provided by RyzenAPI
-- Game: Rheum

-- MAIN APPLICATION
addappid(849520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(849521, 1, "c541c2028ff1cc36a6799cacf96343c6a80a4d0e6bbc00b044a359a1c07a852b")
