-- Lua provided by RyzenAPI
-- Game: AppID 849520

-- MAIN APPLICATION
addappid(849520)
-- Game: addappid(849520)

-- MAIN APP DEPOTS / PACKAGES
addappid(849521, 1, "c541c2028ff1cc36a6799cacf96343c6a80a4d0e6bbc00b044a359a1c07a852b")
