-- Lua provided by RyzenAPI
-- Game: 2589970

-- MAIN APPLICATION
addappid(2589970)
-- Game: addappid(2589970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589971, 1, "bcac96be5f6d7942ec3816a8f665e71dfb9749f6f7f51537c790fb241b975e9d")
