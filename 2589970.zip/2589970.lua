-- Lua provided by RyzenAPI
-- Game: Oh Yeah

-- MAIN APPLICATION
addappid(2589970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2589971, 1, "bcac96be5f6d7942ec3816a8f665e71dfb9749f6f7f51537c790fb241b975e9d")
