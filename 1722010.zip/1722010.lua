-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1722010)
-- Game: addappid(1722010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1722010,0,"1de3b370d33fe1172664642a284de559d169a5117bda5158b7aab20102486092")
