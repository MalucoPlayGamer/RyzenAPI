-- Lua provided by RyzenAPI
-- Game: Destiny's Princess: A War Story, A Love Story

-- MAIN APPLICATION
addappid(447170)

-- MAIN APP DEPOTS / PACKAGES
addappid(447171, 1, "1a01fea67db6a1d24194bf4ad4ed13c7aa0e7657bb1dd591a035612081e2a23f")
addappid(449900, 0, "b934e71d8b5f7666bb60a7677412a082a0e88baff22ae383fba38dfddcc3d07b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
