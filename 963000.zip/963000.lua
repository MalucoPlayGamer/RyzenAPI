-- Lua provided by RyzenAPI
-- Game: Frog Detective 1: The Haunted Island

-- MAIN APPLICATION
addappid(963000)

-- MAIN APP DEPOTS / PACKAGES
addappid(963001, 1, "810e3049968166a5d211e0045aa0990eb7250421a18015fe3193ac3e848a61f9")
addappid(963002, 1, "26eff2f465f15bf75788213d4038c6b75cf9c80d350dac9499202293d1e6102c")

