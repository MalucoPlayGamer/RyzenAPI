-- Lua provided by RyzenAPI
-- Game: TacoFace

-- MAIN APPLICATION
addappid(570060)

-- MAIN APP DEPOTS / PACKAGES
addappid(570061,0,"d7f942a28d231720dba6fc5e313f0dc9484a127c03d2bed3c8990bc7c7a9100d")

