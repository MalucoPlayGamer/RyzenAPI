-- Lua provided by RyzenAPI
-- Game: Brunch Club

-- MAIN APPLICATION
addappid(1045120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045121, 1, "31fb858a6a39de5a1c526dbb15fbb65537cd1b5b2340fe16a5a53b86e39252e4")
