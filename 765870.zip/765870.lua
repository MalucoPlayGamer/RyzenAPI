-- Lua provided by RyzenAPI
-- Game: Leisure Suit Larry - Wet Dreams Don't Dry

-- MAIN APPLICATION
addappid(765870)

-- MAIN APP DEPOTS / PACKAGES
addappid(765871, 1, "93e21949ba95d930ab5863f6014c8dd93a534b75a8144aacf43304d091991628")
addappid(765872, 1, "8661abc0334463781a39f4febdda9dd6b4aacfe38762dd0de0a52581431dc62e")
