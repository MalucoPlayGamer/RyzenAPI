-- Lua provided by RyzenAPI 
-- Game: Handyman Legend 水電工傳說 Demo
addappid(2271870)
addappid(2271871, 1, "6cae60f1ff8b213235234f6dbbfdf8bc9ab08689794ef544d909ba2fe3b2f1f0")
