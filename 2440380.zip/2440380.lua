-- Lua provided by RyzenAPI
-- Game: Game: Megaloot

-- MAIN APPLICATION
addappid(2440380)
-- Game: addappid(2440380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2440381, 1, "def2da358b14cdc00d139af62c7d7275bb0a1eab0c9409d162edcac2ad5842ea")
