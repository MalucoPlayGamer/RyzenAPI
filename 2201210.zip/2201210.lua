-- Lua provided by RyzenAPI
-- Game: Cursor Engine

-- MAIN APPLICATION
addappid(2201210)
-- Game: addappid(2201210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2201211, 1, "d54b7361bd978e14c2427d119e9c0e6a0e5b7ec5bba6a5de0e6c4b4cbc764afb")
