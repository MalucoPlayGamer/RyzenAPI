-- Lua provided by SkyAPI 
-- Game: Bots Are Stupid
addappid(1578160)
addappid(1578161, 1, "fb8d6b8466c7740cf3ceb2ad8238f6b04a7c991686a70739b98efc2a14c1f598")
addappid(1578163, 1, "5b108ad1dc387745c0fe5458623ca22497ff4c53622da72be9b9ce47609ec54d")
addappid(1578164, 1, "c5f21bdbafbf480ddb5fa931930eb93d18645927e54b7842adb5459705ef996a")
