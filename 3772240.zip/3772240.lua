-- 3772240's Lua and Manifest Created by Hubcap Manifest
-- Void Miner – Asteroid Roguelite
-- Created: May 01, 2026 at 09:32:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3772240, 1, "9835738796c1f2e4e9a1656ab981cd522828ff56665a89b689869d72497f30f1") -- Void Miner – Asteroid Roguelite
-- MAIN APP DEPOTS
addappid(3772241, 1, "346186593a6cf9902ac3f4780356570168eed645bb63361fa9e7a9b773a2fbf8") -- Depot 3772241
setManifestid(3772241, "3442295486524212214", 1316615396)
addappid(3772243, 1, "9f3be98c0354f7ecd5e0cf103cdc674f499d02a068abdc2e7aad7627fe304a53") -- Depot 3772243
setManifestid(3772243, "3262483697897053351", 248269352)