-- Lua provided by RyzenAPI
-- Game: Dementium II HD

-- MAIN APPLICATION
addappid(217100)
addappid(228982)
addappid(228983)

-- MAIN APP DEPOTS / PACKAGES
addappid(217101, 1, "0ca67e4d028a7f0591ba1b4b60bac0ba80d916444bb00c316689b394d2ee997f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(217115)
