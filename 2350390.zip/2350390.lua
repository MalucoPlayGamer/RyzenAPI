-- Lua provided by RyzenAPI
-- Game: addappid(2350390)

-- MAIN APPLICATION
addappid(2350390)
addappid(2370820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350391, 1, "38a31525eb46fd4bc39911bcfe69279eec1dab7b7181d8b5acab527da8628454")
