-- Lua provided by RyzenAPI
-- Game: Furry Pride

-- MAIN APPLICATION
addappid(1626900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1626901, 1, "d38ce135703a6975f739b9b8623f191a49a99a4f16a6e14d2b4c8922e798511f")
