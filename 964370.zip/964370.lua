-- Lua provided by RyzenAPI
-- Game: Party Hard 2 OST

-- MAIN APPLICATION
addappid(964370)

-- MAIN APP DEPOTS / PACKAGES
addappid(964371, 1, "ff456f62f9fc17b4e89b7245a8dfb83a14299b95c359d074fcd5f77dc40e3437")
