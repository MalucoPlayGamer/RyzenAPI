-- Lua provided by RyzenAPI
-- Game: addappid(619540)

-- MAIN APPLICATION
addappid(619540)
addappid(4407720)

-- MAIN APP DEPOTS / PACKAGES
addappid(619541, 1, "3d62f69ab132eb4e3000cf6783cb97d993c4e8c0557d86203c59e4a3bcf03ae9")
