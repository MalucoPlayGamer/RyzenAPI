-- Lua provided by RyzenAPI
-- Game: AppID 3145080

-- MAIN APPLICATION
addappid(3145080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3145081, 1, "14b21a28083af33c2e8155b6fcdf1b44747b11467dccaaf1a5b7fed720ec4beb")

