-- Lua provided by RyzenAPI
-- Game: Realities

-- MAIN APPLICATION
addappid(452710)
addappid(708620)
addappid(708621)
addappid(708622)
addappid(736990)
addappid(819310)
addappid(837160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(452711, 1, "acf6afac156d3db002db86600335de9c058bf7957b8878788ea41af813cdbe5c")

