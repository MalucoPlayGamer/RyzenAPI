-- Lua provided by RyzenAPI 
-- Game: Realities
addappid(452710)
addappid(452711, 1, "acf6afac156d3db002db86600335de9c058bf7957b8878788ea41af813cdbe5c")
