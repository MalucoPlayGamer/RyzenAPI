-- Lua provided by RyzenAPI
-- Game: The Tool

-- MAIN APPLICATION
addappid(1436870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1436871, 1, "feaf5b04f8dc4c59541b9ff6fe2bc6c5d0599e4cc61d588449762cf14f3ab9b5")
addappid(1436872, 1, "e47f948b5efe5b335efb8cefe1fe91327a9cf25ded4f726166a5417523959e43")

