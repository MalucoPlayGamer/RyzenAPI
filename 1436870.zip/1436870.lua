-- Lua provided by RyzenAPI
-- Game: Game: The Tool

-- MAIN APPLICATION
addappid(1436870)
-- Game: addappid(1436870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1436871, 1, "feaf5b04f8dc4c59541b9ff6fe2bc6c5d0599e4cc61d588449762cf14f3ab9b5")
addappid(1436872, 1, "e47f948b5efe5b335efb8cefe1fe91327a9cf25ded4f726166a5417523959e43")
