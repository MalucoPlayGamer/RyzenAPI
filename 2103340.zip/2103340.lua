-- Lua provided by RyzenAPI
-- Game: Paragon Pioneers

-- MAIN APPLICATION
addappid(2103340)
-- Game: addappid(2103340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103342,0,"5ab5ec7f12d07ceb1c7b6ad474549aac901666b56f6c651ae9144ef188e859ba")
addappid(2103343,0,"772771ed592abe5f222aa1179c5f6a90ee5e865bc876340f8494cecfa4644175")
addappid(2103344,0,"0933939a7516844883f25795fb13de46b578d96690e9ab3b1c8b8b97ef5db9df")
