-- Lua provided by RyzenAPI 
-- Game: Snake Crush
addappid(2574030)
addappid(2574031, 1, "f6fdc1f54b2e596584e32e9b07a1005112ab73bf37a2e85da4992632354bb0aa")
