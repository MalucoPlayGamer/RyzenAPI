-- Lua provided by RyzenAPI
-- Game: E.X.P.L.O.R.™: A New World

-- MAIN APPLICATION
addappid(1387120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1387121, 1, "f1eb3fa652b9a2c35195207d85dc9ee50b517f9abe11c9643d51ba7e444cf121")

