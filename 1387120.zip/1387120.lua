-- Lua provided by RyzenAPI 
-- Game: E.X.P.L.O.R.™: A New World
addappid(1387120)
addappid(1387121, 1, "f1eb3fa652b9a2c35195207d85dc9ee50b517f9abe11c9643d51ba7e444cf121")
