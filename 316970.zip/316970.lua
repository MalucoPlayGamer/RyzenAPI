-- Lua provided by RyzenAPI
-- Game: Game: The Waste Land

-- MAIN APPLICATION
addappid(316970)
-- Game: addappid(316970)

-- MAIN APP DEPOTS / PACKAGES
addappid(316971, 1, "366c6378e5700db398a25ec955a691f1b68ffc676cc7487d681452bb5830bea6")
