-- Lua provided by RyzenAPI
-- Game: Girls' civilization

-- MAIN APPLICATION
addappid(960740)

-- MAIN APP DEPOTS / PACKAGES
addappid(960741, 1, "f02f3f418d4446db71e6d3ad5ccdf352760138625ce5c147ae93509537a38c26")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
