-- Lua provided by RyzenAPI
-- Game: addappid(1609300)

-- MAIN APPLICATION
addappid(1609300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1609302,0,"6fc9984cc33cf2f39ecd45e6b31b5cce794814f04d4d28701754f56cbde3d4e6")
addappid(1609303,0,"38e43f16cfa7206f74fc0b1ad43e9d2280c64fe8b4c06ab0e65411dc481b2f91")
