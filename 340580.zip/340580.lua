-- Lua provided by SkyAPI 
-- Game: AppID 340580
addappid(340580)
addappid(340581, 1, "cf388faaa065e844ae222cb9cfea6e97e16d07a1c3b5ae41379a34ec0f7d4281")
