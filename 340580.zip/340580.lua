-- Lua provided by RyzenAPI
-- Game: Armed with Wings: Rearmed

-- MAIN APPLICATION
addappid(340580)

-- MAIN APP DEPOTS / PACKAGES
addappid(340581, 1, "cf388faaa065e844ae222cb9cfea6e97e16d07a1c3b5ae41379a34ec0f7d4281")
