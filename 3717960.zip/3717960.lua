-- Lua provided by RyzenAPI 
-- Game: AppID 3717960
addappid(3717960)
addappid(3717961, 1, "122ad1b3c64b71b1440fc3cb727a4f6cd907ef479de026349ecfcf63107bc0c8")
addappid(3717962, 1, "5bc470285e8ce83ba8858d73031d2f0f0e4d337d5b70ae72877b9826019339ff")
