-- Lua provided by RyzenAPI
-- Game: addappid(3036000)

-- MAIN APPLICATION
addappid(3036000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3036001, 1, "7f73ccf55b319e583fd1ccdf731d5d88ddc91bf198ad7445752cc9a04ff03121")
