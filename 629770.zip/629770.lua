-- Lua provided by RyzenAPI
-- Game: AppID 629770

-- MAIN APPLICATION
addappid(629770)
-- Game: addappid(629770)

-- MAIN APP DEPOTS / PACKAGES
addappid(629771, 1, "6bdfbb27eadef2f58174e9b49229286fbaf7fc3dab83975433b58724d1980cde")
addappid(629772, 1, "6d38cbb58763f84b66b6e694e8d5c9a23b6c9e6ace9b51f68916dddcec39e692")
addappid(629773, 1, "91635602066c29d3f8d1c2c791ffd04eabd1af807241ed73b1df6e9635950c02")
addappid(629774, 1, "a7f596f13441c1bffc1f43196e7261b5e8f2974e28335dad9dc9cb5b38f977de")
