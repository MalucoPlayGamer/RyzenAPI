-- Lua provided by RyzenAPI
-- Game: Born Into Fear

-- MAIN APPLICATION
addappid(1705930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705931, 1, "6057f03a991a79e4716ab587d767d3e52e01a6a06fd3c6bbec5a288b24d9af23")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
