-- Lua provided by RyzenAPI
-- Game: Born Into Fear

-- MAIN APPLICATION
addappid(1705930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705931, 1, "6057f03a991a79e4716ab587d767d3e52e01a6a06fd3c6bbec5a288b24d9af23")
