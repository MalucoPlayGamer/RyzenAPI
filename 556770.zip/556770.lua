-- Lua provided by RyzenAPI
-- Game: Star Phoenix

-- MAIN APPLICATION
addappid(556770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(556771, 1, "2bf1285307fd95822bd32b6bb7564c06acf22cf2a295075025a2fe022e5a39cd")

