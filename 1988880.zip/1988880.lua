-- Lua provided by RyzenAPI 
-- Game: BOX RUSH 2: Ice worlds
addappid(1988880)
addappid(1988881, 1, "3cfdc81513b585aac3692b408eada2f4dac0d37f2d8e808efc3dd4ff69a62b0e")
