-- Lua provided by RyzenAPI
-- Game: AppID 924970

-- MAIN APPLICATION
addappid(924970)
addappid(1598440)
addappid(1598441)
addappid(1598442)
addappid(1840320)
addappid(2015180)
addappid(2101940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(924971, 1, "783767a483d935235bc2a46262a58b4acc3524bdf6d52116f090fcccc0a89024")
addappid(924972, 1, "ec1e4f563086da2780fdcb3f167c056d76e0c9ca49b6418b26d34ce26660ada7")
addappid(924973, 1, "a729a752e939faa9c74e578c69b357cddf7d34ccd6c8564129117a16193fb003")
addappid(924974, 1, "28ab0aa9e98d603cd572c921b820931dedcf94882988a8d4aaaf5374394ec9d8")
addappid(924975, 1, "59f5fe1e63f36b4a43383d0f3eeef896f1375ff3a1d18bf5cd27c5756ff710fc")
addappid(924976, 1, "1acba27ad19b4dd77a3130a775f5adeeebd0aa40ed3353f5cb80bfae583e60fd")
addappid(924977, 1, "bea7e2008e44c61676a5e44b067e4c637be848c3719337acb2cd55a1f7976693")

