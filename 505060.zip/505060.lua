-- Lua provided by RyzenAPI
-- Game: Warcube

-- MAIN APPLICATION
addappid(505060)
-- Game: addappid(505060)

-- MAIN APP DEPOTS / PACKAGES
addappid(505061, 1, "6901018609feb8e19f9b17abf102551ebb1f807a5fe1fdc4242047033b1c1b10")
