-- Lua provided by RyzenAPI
-- Game: Project Gravity

-- MAIN APPLICATION
addappid(1392140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392141, 1, "4603d43e4e120d6702d57b7ee2f9fbf080d348cdb1bebc8e85aa39b1cf2f6033")
