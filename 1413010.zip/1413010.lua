-- Lua provided by RyzenAPI
-- Game: Cube Gothic

-- MAIN APPLICATION
addappid(1413010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1413011, 1, "cb875d97ce28f27d4c7532ae13a4d0f0253b27775ae3d85f14399dffa99c7823")
