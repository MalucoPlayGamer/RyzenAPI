-- Lua provided by SkyAPI 
-- Game: 冒险之路(Adventure Road)
addappid(703090)
addappid(703091, 1, "a62cc44031c6ee12e15c4d67ee48a49d796ec56039854e25e8a4a70c8de1a263")
