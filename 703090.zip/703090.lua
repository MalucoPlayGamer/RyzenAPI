-- Lua provided by RyzenAPI
-- Game: 冒险之路(Adventure Road)

-- MAIN APPLICATION
addappid(703090)

-- MAIN APP DEPOTS / PACKAGES
addappid(703091, 1, "a62cc44031c6ee12e15c4d67ee48a49d796ec56039854e25e8a4a70c8de1a263")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
