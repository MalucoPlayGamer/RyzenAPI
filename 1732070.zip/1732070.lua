-- Lua provided by RyzenAPI 
-- Game: ZHP: Unlosing Ranger vs. Darkdeath Evilman
addappid(1732070)
addappid(1732071, 1, "16bcf29a39b8b68b7d222ba5c1d07fb382f3e09c1da82be8138b76b63a21c335")
