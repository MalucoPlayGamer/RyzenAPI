-- Lua provided by RyzenAPI
-- Game: POSTZ: ZOMBIES VR

-- MAIN APPLICATION
addappid(458180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(458182,0,"6a13ce9a7ad4149397ad4e391ecf4519e1ae03c0052923a91cec194f75c1d179")

