-- Lua provided by RyzenAPI
-- Game: setManifestid(458182,"593105560757478289")

-- MAIN APPLICATION
addappid(458180)
-- Game: addappid(458180)

-- MAIN APP DEPOTS / PACKAGES
addappid(458182,0,"6a13ce9a7ad4149397ad4e391ecf4519e1ae03c0052923a91cec194f75c1d179")
