-- Lua provided by RyzenAPI
-- Game: 3545650

-- MAIN APPLICATION
addappid(3545650)
-- Game: addappid(3545650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3545650,0,"1a887c81c2964d53677b8df12131c52197b7275f957eb9a557d6be4ccecd354d")
