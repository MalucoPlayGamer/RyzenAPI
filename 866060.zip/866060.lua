-- Lua provided by RyzenAPI
-- Game: Warhammer: Vermintide 2 SDK

-- MAIN APPLICATION
addappid(866060)

-- MAIN APP DEPOTS / PACKAGES
addappid(866061, 1, "5a7891dd2572397562002a8e48dc2016027f1799acde25fcb1e989328ea9b694")
