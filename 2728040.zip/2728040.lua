-- Lua provided by SkyAPI 
-- Game: AppID 2728040
addappid(2728040)
addappid(2728041, 1, "acb3c4bc2e20c4bc25009b9889b7464437e31bfb48c193dddc5e75bf5ad05eb7")
