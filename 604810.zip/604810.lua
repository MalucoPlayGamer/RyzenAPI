-- Lua provided by RyzenAPI
-- Game: AppID 604810

-- MAIN APPLICATION
addappid(604810)
-- Game: addappid(604810)

-- MAIN APP DEPOTS / PACKAGES
addappid(604811, 1, "8e0db3435e86f7455cd7f6003688c1fb1d5b1c52a1304a998293894703ecab97")
