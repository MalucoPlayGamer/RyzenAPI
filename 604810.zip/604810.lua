-- Lua provided by SkyAPI 
-- Game: AppID 604810
addappid(604810)
addappid(604811, 1, "8e0db3435e86f7455cd7f6003688c1fb1d5b1c52a1304a998293894703ecab97")
