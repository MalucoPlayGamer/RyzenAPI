-- Lua provided by RyzenAPI
-- Game: AppID 812450

-- MAIN APPLICATION
addappid(812450)
-- Game: addappid(812450)

-- MAIN APP DEPOTS / PACKAGES
addappid(812451, 1, "c8fba72c7c7aa5b4829b04ab1f93d82595bd5157b36894171b410ccd4021e4bd")
