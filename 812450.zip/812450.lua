-- Lua provided by RyzenAPI
-- Game: The m0rg VS keys

-- MAIN APPLICATION
addappid(812450)
addappid(828430)

-- MAIN APP DEPOTS / PACKAGES
addappid(812451,0,"c8fba72c7c7aa5b4829b04ab1f93d82595bd5157b36894171b410ccd4021e4bd")
addappid(828430,0,"df612ba9083d035d5ea34dceba244ba6d7fbfba26c15b98c59dd397d4bd2c5d5")

