-- Lua provided by RyzenAPI
-- Game: 1717020

-- MAIN APPLICATION
addappid(1717020)
-- Game: addappid(1717020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717021, 1, "ea8785ccea32fe78b225286a0d6ce9cb1b4325ecada578edd70c417724aa75cb")
