-- Lua provided by RyzenAPI
-- Game: Ed-0: Zombie Uprising

-- MAIN APPLICATION
addappid(1717020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717021, 1, "ea8785ccea32fe78b225286a0d6ce9cb1b4325ecada578edd70c417724aa75cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2389160)
