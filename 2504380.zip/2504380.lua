-- Lua provided by RyzenAPI
-- Game: Survival Nation: Lost Horizon

-- MAIN APPLICATION
addappid(2504380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2504381, 1, "d8878ea740497b20fb22b7ef4fbcce6278e3d6da15b0c765ccf340f527510c1a")
