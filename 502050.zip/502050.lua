-- Lua provided by RyzenAPI
-- Game: 502050

-- MAIN APPLICATION
addappid(502050)
-- Game: addappid(502050)

-- MAIN APP DEPOTS / PACKAGES
addappid(502051, 1, "feb8fa0fd902935d71d38c7a38feeffcbed6b61b3eea552b2bf08e98bc074510")
