-- Lua provided by RyzenAPI
-- Game: FIELD BREAKING

-- MAIN APPLICATION
addappid(639840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(639841, 1, "18ea458eff02eb4b815be659c81b2e44aeb750e00554c53ce35a68599322fc95")
addappid(639842, 1, "8514ec7373e3689777379efe76615beef5aae5c845456aec16fceab02ffcec78")
addappid(639843, 1, "003df408030491af27c664769478649082e01ab9f79536c986b9d9026168d6cd")
addappid(639844, 1, "0ddc4dfdc138b9a2b4ab7d79c41a4c6dbf8268e2350466db0c79a2e6c5ca2610")

