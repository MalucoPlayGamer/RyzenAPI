-- Lua provided by RyzenAPI
-- Game: Nemesis: Race Against The Pandemic

-- MAIN APPLICATION
addappid(1497180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497181, 1, "ecae189684a9c46c076899afe25e359771db6c1bf57b33a7eeb47bfd9ee5ef78")
