-- Lua provided by RyzenAPI
-- Game: Game: Storm Tale

-- MAIN APPLICATION
addappid(1119940)
-- Game: addappid(1119940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1119941, 1, "221498a6b9b64e1d6f15b02bdf7bb4f9609c3659d20b5c5e7bfd4075e4725d74")
