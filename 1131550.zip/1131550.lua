-- Lua provided by RyzenAPI
-- Game: AppID 1131550

-- MAIN APPLICATION
addappid(1131550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131551, 1, "4804501f7b21605d1c423dc05366fb39aa60889d06535a529dfd4786211302c1")
addappid(1131552, 1, "f535aa556d7cb4adfea67a6705b92ab3c9578e0b3106cad6393954aaf09e67c4")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1475320)
