-- Lua provided by RyzenAPI
-- Game: Pepper's Puzzles

-- MAIN APPLICATION
addappid(642650)

-- MAIN APP DEPOTS / PACKAGES
addappid(642651,0,"1e1e5610e13f4e2f15f4730fa0273e55176af78ec45e69af5c9570a85e568d65")

