-- Lua provided by RyzenAPI
-- Game: Game: Jewel Match Aquascapes Collector's Edition

-- MAIN APPLICATION
addappid(2313420)
-- Game: addappid(2313420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2313421, 1, "9922cd91720fb12345fcae952ba1d0be4a35255c66374e42423d738ef035e8fd")
