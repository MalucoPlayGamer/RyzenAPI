-- Lua provided by SkyAPI 
-- Game: Zombie Defense Shelter
addappid(1245550)
addappid(1245551, 1, "032ec8f9db366114e4947ffbb807b5d150574728b5dc6901f502a685cd2fd462")
