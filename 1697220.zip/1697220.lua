-- Lua provided by RyzenAPI
-- Game: 1697220

-- MAIN APPLICATION
addappid(1697220)
-- Game: addappid(1697220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1697220,0,"8aa670847a09170eaf0dc8c5877e6a5738c3032ebeeb53476e69a1b6fd0ff200")
