-- Lua provided by RyzenAPI
-- Game: Game: Magdalena

-- MAIN APPLICATION
addappid(432470)
addappid(456120)
-- Game: addappid(432470)

-- MAIN APP DEPOTS / PACKAGES
addappid(432471, 1, "6579a5645bbf5179b0a034ec17b14b7b143eab8f894f6297ae124db000265e64")
