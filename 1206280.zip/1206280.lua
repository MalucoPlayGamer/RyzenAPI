-- Lua provided by RyzenAPI
-- Game: Thunderflash

-- MAIN APPLICATION
addappid(1206280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1206281, 1, "f2269b5ac877e2bb4012fff244f2704789242bad880f213e8e3e2198c7070bfd")
