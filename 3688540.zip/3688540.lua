-- Lua provided by SkyAPI 
-- Game: Pocket Hoes
addappid(3688540)
addappid(3688541, 1, "5d806edacbaa0fd9363404f6b168043767fa8fb94ec09f295c42c8fefdb9b023")
