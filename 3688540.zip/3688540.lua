-- Lua provided by RyzenAPI
-- Game: Game: Pocket Hoes

-- MAIN APPLICATION
addappid(3688540)
-- Game: addappid(3688540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3688541, 1, "5d806edacbaa0fd9363404f6b168043767fa8fb94ec09f295c42c8fefdb9b023")
