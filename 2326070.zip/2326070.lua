-- Lua provided by RyzenAPI
-- Game: Rush for the Ages

-- MAIN APPLICATION
addappid(2326070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2326071,0,"4e23195558d701b377db4cff76bef48017df42fa7fe83ed777814623c94da7ec")
addappid(2326072,0,"fc4a64b199247b371e02dfe2d7e567d21ebc1c08c9e5c1d943be103b179f2d22")
addappid(2326073,0,"cfa8370dfcf6de8ae17eff4c7b1969f597232e4f9224b131dc119813cfc2b0cc")

