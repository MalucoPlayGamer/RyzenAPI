-- Lua provided by RyzenAPI 
-- Game: 封神榜2024
addappid(3225970)
addappid(3225971, 1, "20736836ee781c40a4b50828e87681a664f2bade60914b02729080f522de119b")
