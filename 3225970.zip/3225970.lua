-- Lua provided by RyzenAPI
-- Game: 封神榜2024

-- MAIN APPLICATION
addappid(3225970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3225971, 1, "20736836ee781c40a4b50828e87681a664f2bade60914b02729080f522de119b")

