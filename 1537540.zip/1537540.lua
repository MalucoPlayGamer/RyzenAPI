-- Lua provided by RyzenAPI
-- Game: AppID 1537540

-- MAIN APPLICATION
addappid(1537540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1537541, 1, "5119c7077728fa646917d05271a8938f0ef17d4fa1b92579fb6beb642841499e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
