-- Lua provided by RyzenAPI
-- Game: Post Scriptum CTG: Collectible Token Game

-- MAIN APPLICATION
addappid(1189650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189651, 1, "fd8f4f02418547291c6935669e6538152442a65152c1636fdef48ffb7443828b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
