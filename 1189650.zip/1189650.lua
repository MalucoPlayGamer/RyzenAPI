-- Lua provided by RyzenAPI
-- Game: Post Scriptum CTG: Collectible Token Game

-- MAIN APPLICATION
addappid(1189650)
-- Game: addappid(1189650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189651, 1, "fd8f4f02418547291c6935669e6538152442a65152c1636fdef48ffb7443828b")
