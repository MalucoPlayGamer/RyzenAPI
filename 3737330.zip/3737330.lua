-- Lua provided by RyzenAPI
-- Game: Medical Layers

-- MAIN APPLICATION
addappid(3737330)
-- Game: addappid(3737330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3737331, 1, "3e84ae64879382a91805ded4653b1d371d2b483499c73935b8fabe2a4148f08d")
