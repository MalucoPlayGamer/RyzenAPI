-- Lua provided by RyzenAPI
-- Game: Medical Layers

-- MAIN APPLICATION
addappid(3737330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3737331, 1, "3e84ae64879382a91805ded4653b1d371d2b483499c73935b8fabe2a4148f08d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
