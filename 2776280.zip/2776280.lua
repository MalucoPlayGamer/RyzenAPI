-- Lua provided by RyzenAPI
-- Game: Goblin

-- MAIN APPLICATION
addappid(2776280)
-- Game: addappid(2776280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2776281, 1, "4431671061681d9723cdba955be5f151397e287cfa374d1e036e2441042c2b52")
