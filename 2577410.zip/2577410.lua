-- Lua provided by RyzenAPI
-- Game: AppID 2577410

-- MAIN APPLICATION
addappid(2577410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2577411, 1, "efe5323708fd2fd7dea0a7ccbb85198fb814a48775401074f51db3a2adbbed59")

