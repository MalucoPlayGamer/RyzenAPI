-- Lua provided by RyzenAPI
-- Game: Modern Assault Tanks

-- MAIN APPLICATION
addappid(612230)

-- MAIN APP DEPOTS / PACKAGES
addappid(612231, 1, "4b1ba7a1a3b4c97e8e80ed39b07ff471a6b4c476eba02ccdde8ffe21f604cd01")
addappid(612232, 1, "8d143a1844fe38a36f4235edcae9290b5c64571e85bb26d8e003d095c687edfa")
addappid(612233, 1, "9bcdf974b5730e811647c84640c0add32684d0e8a1eab7363ee3dbe883dc4830")
