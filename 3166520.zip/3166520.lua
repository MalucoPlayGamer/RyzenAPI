-- Lua provided by SkyAPI 
-- Game: Frontier: Battle Royale
addappid(3166520)
addappid(3166521, 1, "14495825ef6848f744d426f6932a72ea8dcb8fcfe182cf37343e63fec22b640a")
