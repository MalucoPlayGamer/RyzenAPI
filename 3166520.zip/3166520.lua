-- Lua provided by RyzenAPI
-- Game: Frontier: Battle Royale

-- MAIN APPLICATION
addappid(3166520)
-- Game: addappid(3166520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3166521, 1, "14495825ef6848f744d426f6932a72ea8dcb8fcfe182cf37343e63fec22b640a")
