-- Lua provided by RyzenAPI
-- Game: Game: amazin' George Remastered

-- MAIN APPLICATION
addappid(1849870)
addappid(1853110)
-- Game: addappid(1849870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849871, 1, "b7b8ed9a9b9fe5ab0847dee7417727e4cafa495a626f7b5780d5493bedda0491")
