-- Lua provided by RyzenAPI
-- Game: amazin' George Remastered

-- MAIN APPLICATION
addappid(1849870)
addappid(1853110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1849871, 1, "b7b8ed9a9b9fe5ab0847dee7417727e4cafa495a626f7b5780d5493bedda0491")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
