-- Lua provided by RyzenAPI
-- Game: Game: Virtual Exhibition

-- MAIN APPLICATION
addappid(1318980)
-- Game: addappid(1318980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1318981, 1, "0c497e0093332737eb55bd78b2d9ad685a8468aa2d5a95269571b7937b535420")
addappid(1318982, 1, "4c86c09e6f598f95c1703e1636e3d4783df389aa0af0b24dc46ec4701609751c")
