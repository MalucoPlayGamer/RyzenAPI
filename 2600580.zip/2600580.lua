-- Lua provided by RyzenAPI
-- Game: Game: The shadow of the evil tower

-- MAIN APPLICATION
addappid(2600580)
-- Game: addappid(2600580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2600581, 1, "51323b66487a2fe3e96e13f1592811317d131dc9f32a43ad8a18b5491a6ab8f3")
