-- Lua provided by RyzenAPI
-- Game: Game: Stolen Hearts: Wolf Knight Demo

-- MAIN APPLICATION
addappid(2570670)
-- Game: addappid(2570670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570671, 1, "e9e4fff42565efb849f80dbaa44c3596c3a3d1e8414beaf7bbc16c3cefe2f82a")
