-- Lua provided by RyzenAPI
-- Game: Game: ROGUE FLIGHT

-- MAIN APPLICATION
addappid(2784620)
-- Game: addappid(2784620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2784621, 1, "876d6619d7dd81c6b63a28f3d90a1f09fb0cc35f75d50b8c5e9d2c92a89fbc99")
