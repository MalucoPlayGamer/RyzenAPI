-- Lua provided by RyzenAPI 
-- Game: Find Love or Die Trying: Til Death Do Us Part
addappid(3329650)
addappid(3329651, 1, "ee3d884b255d27196b012f6ef992ecf33e7d03b846060cc10cf9df663f1f39b1")
addappid(3408080, 0, "bb7934b73e0c57cc14c1e6f0694c8444052d2c9e425da92dcb8d42f92832edca")
