-- Lua provided by RyzenAPI
-- Game: 2668910

-- MAIN APPLICATION
addappid(2668910)
-- Game: addappid(2668910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668911, 1, "7af8795092286b0e0325fdb4eb350b82637fac1049a3ca19ba2080364c75f4ce")
