-- Lua provided by RyzenAPI
-- Game: Skybox3D

-- MAIN APPLICATION
addappid(1549660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549661, 1, "210f7cad0799146d4dc66678b5342fd7aa7d2fc9cad97c2cabc3d92bb62812ee")
addappid(1549662, 1, "c7486dcd9ffdd510ea6c2097b005cdb86761897d40167846a291a6ce04b2d289")
addappid(1549663, 1, "25c7f6ca225d7e1b4e7e9fdc62910f25a4e0682abdb2465968264942e3613841")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
