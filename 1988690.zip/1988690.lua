-- Lua provided by RyzenAPI
-- Game: Portal Dungeon Demo

-- MAIN APPLICATION
addappid(1988690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988691, 1, "6a636905f2d69ca1510de32f8941a9855cf1e1ceb36924151a25a36dae0800b1")
