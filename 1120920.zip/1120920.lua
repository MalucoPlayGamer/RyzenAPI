-- Lua provided by RyzenAPI
-- Game: Game: AppID 1120920

-- MAIN APPLICATION
addappid(1120920)
-- Game: addappid(1120920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1120921, 1, "2e126bc2ec862ff98ab8ff2f1947bc011750a7d624909c99776bdd9d2c4be329")
addappid(1120923, 1, "fc46cc61f44e3e07073e685c2f01a16c38ce8d68d8706f3d8b51bd6eecfc470a")
