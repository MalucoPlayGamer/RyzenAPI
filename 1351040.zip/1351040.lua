-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Character Generator Pack

-- MAIN APPLICATION
addappid(1351040)
-- Game: addappid(1351040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351040,0,"4c00ed433e1931a05c7f8bae44a5ce2caf87304cb2c2c29b4b099b0baea41a1a")
addtoken(1351040,"15757198256129292306")
