-- Lua provided by RyzenAPI
-- Game: 2522350

-- MAIN APPLICATION
addappid(2522350)
-- Game: addappid(2522350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2522352,0,"19c31642cb92b5d61d6501bb4afabb0dfbf9a8c4799c924ffac5668049f06b83")
