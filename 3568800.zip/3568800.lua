-- Lua provided by RyzenAPI 
-- Game: Welcome to the Chop House
addappid(3568800)
addappid(3568801, 1, "a2755979ac9b41d501868380a876eb7ede348beb22797a998e666d8bdec8eeef")
