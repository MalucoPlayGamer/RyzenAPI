-- Lua provided by RyzenAPI 
-- Game: AppID 733770
addappid(733770)
addappid(733771, 1, "2e6b5872d81474b2052bedce5af480c4d79d9dee60eb5489e2c9fab9496ace5e")
