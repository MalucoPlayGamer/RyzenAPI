-- Lua provided by RyzenAPI
-- Game: NeverSynth

-- MAIN APPLICATION
addappid(2131200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2131201, 1, "895d17125067b447762973d3ff7b33b9dde2b47839a15d5cd4634daf168a8473")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
