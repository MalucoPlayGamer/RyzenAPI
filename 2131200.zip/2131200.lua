-- Lua provided by RyzenAPI 
-- Game: NeverSynth
addappid(2131200)
addappid(2131201, 1, "895d17125067b447762973d3ff7b33b9dde2b47839a15d5cd4634daf168a8473")
