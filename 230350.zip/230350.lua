-- Lua provided by RyzenAPI
-- Game: AppID 230350

-- MAIN APPLICATION
addappid(230350)

-- MAIN APP DEPOTS / PACKAGES
addappid(230351, 1, "26a8cd8cdf13f8476ce6a1b50132b3322eb1d191662678e53de548ca28e4a526")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(237250)
addappid(237270)
