-- Lua provided by RyzenAPI
-- Game: addappid(230350)

-- MAIN APPLICATION
addappid(230350)

-- MAIN APP DEPOTS / PACKAGES
addappid(230351, 1, "26a8cd8cdf13f8476ce6a1b50132b3322eb1d191662678e53de548ca28e4a526")
