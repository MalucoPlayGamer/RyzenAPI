-- Lua provided by RyzenAPI
-- Game: 白夜博物馆-一周年+二周年纪念刊

-- MAIN APPLICATION
addappid(3763530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3763530,0,"8641c30863bd53e8064eec2cc7f7f194943629d281d7b99e37700934373fe743")
