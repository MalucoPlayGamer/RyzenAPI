-- Lua provided by RyzenAPI
-- Game: 3304750

-- MAIN APPLICATION
addappid(3304750)
-- Game: addappid(3304750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3304751, 1, "e0e071fd7c0716e5cc5ebcf9b5dc7f25f71ce34ce77c0976956f084fd9fb38a1")
