-- Lua provided by RyzenAPI
-- Game: AppID 3037780

-- MAIN APPLICATION
addappid(3037780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3037781, 1, "987c9c5efeccd53a760f2e51e9e5bf60a223d2d0458861ed86e4fae4df18a750")

