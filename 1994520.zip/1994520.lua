-- Lua provided by RyzenAPI
-- Game: Akapulka - The Rainbow

-- MAIN APPLICATION
addappid(1994520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1994521, 1, "ddaf89e8952ed7544b8108a3d1166e115959bcb9704fc30774082aa9dda04518")

