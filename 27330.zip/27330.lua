-- Lua provided by RyzenAPI
-- Game: Game: Blacklight: Tango Down

-- MAIN APPLICATION
addappid(27330)
-- Game: addappid(27330)

-- MAIN APP DEPOTS / PACKAGES
addappid(27331, 1, "c81284bbb1b2d92f6490002c6d6cdefbc413eec6a6700ac3f39cbbb38afef18c")
