-- Lua provided by RyzenAPI
-- Game: HENTAI GIRL PUZZLE

-- MAIN APPLICATION
addappid(1036970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036972,0,"1d3c8ae42b3c1ed219bdb12166abea4173103f1826b2d032dcfd0f5beae0d5fd")

