-- Lua provided by RyzenAPI
-- Game: AppID 767690

-- MAIN APPLICATION
addappid(767690)

-- MAIN APP DEPOTS / PACKAGES
addappid(767691, 1, "bde0068ddcbaf8c278261fe801f2888091d100f3373f2b086bc8c913e4f708da")

