-- Lua provided by RyzenAPI
-- Game: plink

-- MAIN APPLICATION
addappid(4851600) -- plink

-- MAIN APP DEPOTS / PACKAGES
addappid(4851601, 1, "7853f19079573f8532b813a24a4431e5d80aa44c688df74a3b2cd9f462241517") -- Depot 4851601
addappid(4851602, 1, "47bd4e2e15f076ae97fe64f8c02ff8738bf548a19444d1a389cc8fdfe29b46ef") -- Depot 4851602
