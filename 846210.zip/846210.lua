-- Lua provided by RyzenAPI
-- Game: 846210

-- MAIN APPLICATION
addappid(846210)
-- Game: addappid(846210)

-- MAIN APP DEPOTS / PACKAGES
addappid(846211, 1, "4116cb7164587835b3da3f262c79c1e64b8fdedf3029f4dc25a0567614106bed")
