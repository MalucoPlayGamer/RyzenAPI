-- Lua provided by RyzenAPI
-- Game: Game: Innoquous 5

-- MAIN APPLICATION
addappid(453830)
-- Game: addappid(453830)

-- MAIN APP DEPOTS / PACKAGES
addappid(453831, 1, "6efbd7e6e7e347e50ee3e56a5308de71ef69aaf42413a552c8ec1fca388e6ee7")
