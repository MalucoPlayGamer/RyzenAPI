-- Lua provided by RyzenAPI 
-- Game: ProTubeVR Companion-App
addappid(2649770)
addappid(2649771, 1, "d23ef8f51235759a2743f06df00f8db0c7d95200bc1e78063c88edcf0885553d")
