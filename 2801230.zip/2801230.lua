-- Lua provided by RyzenAPI
-- Game: GRR BOO I

-- MAIN APPLICATION
addappid(2801230)
-- Game: addappid(2801230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2801231, 1, "76e5fabcf80b486da0f68ef8554cd10d4f042ca2ccb42a4a7741074bc82a436c")
