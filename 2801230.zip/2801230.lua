-- Lua provided by RyzenAPI
-- Game: GRR BOO I

-- MAIN APPLICATION
addappid(2801230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2801231, 1, "76e5fabcf80b486da0f68ef8554cd10d4f042ca2ccb42a4a7741074bc82a436c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
