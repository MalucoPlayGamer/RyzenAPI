-- Lua provided by SkyAPI 
-- Game: AppID 3801490
addappid(3801490)
addappid(3801491, 1, "b88be771dd6e21c1b635b3662a71357a3f0a22e71f17260f78df028f3eec4108")
