-- Lua provided by RyzenAPI
-- Game: Woolfe - The Red Hood Diaries

-- MAIN APPLICATION
addappid(281940)

-- MAIN APP DEPOTS / PACKAGES
addappid(281941, 1, "0684f296633e3a3dad6b524bd987e6189efa2aa95c858bc407121d64c157fb0d")
addappid(281946, 1, "c5a2a7dc59095c4ef4ee4716774834b119c1228052cf9ddb70739b70fe1782de")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
