-- Lua provided by RyzenAPI 
-- Game: Woolfe - The Red Hood Diaries
addappid(281940)
addappid(281941, 1, "0684f296633e3a3dad6b524bd987e6189efa2aa95c858bc407121d64c157fb0d")
addappid(281946, 1, "c5a2a7dc59095c4ef4ee4716774834b119c1228052cf9ddb70739b70fe1782de")
