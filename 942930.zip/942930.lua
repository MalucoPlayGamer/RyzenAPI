-- Lua provided by RyzenAPI
-- Game: AppID 942930

-- MAIN APPLICATION
addappid(942930)
-- Game: addappid(942930)

-- MAIN APP DEPOTS / PACKAGES
addappid(942931, 1, "bd2c4dc4faaa23317df36efcc7c39e3b6b0ffc48b32ff7fd2142ce0b7837e259")
addappid(1002570, 0, "63b17c8ac079287038acc6d8a4d0a308a16dd6f429215a39afbc0475d9ae17f9")
addappid(1002571, 0, "631a763e14f3f681c645d26f90802a26f8bc53189c1ea5d51e7fb48840a61c04")
