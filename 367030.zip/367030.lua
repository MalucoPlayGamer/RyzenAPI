-- Lua provided by RyzenAPI
-- Game: Lootfest

-- MAIN APPLICATION
addappid(367030)

-- MAIN APP DEPOTS / PACKAGES
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(367031, 1, "651d1d515a1bf1b04bb72821f2a449a2f868bbc3972d25be877d65e1bda12567")
