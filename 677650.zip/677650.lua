-- Lua provided by RyzenAPI
-- Game: 677650

-- MAIN APPLICATION
addappid(677650)
-- Game: addappid(677650)

-- MAIN APP DEPOTS / PACKAGES
addappid(677651, 1, "58c35536d34c39e84a66f65cc172c03f02d3d8f04dafddb2fcfce9314d8168d2")
