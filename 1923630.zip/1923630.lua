-- Lua provided by RyzenAPI
-- Game: HexTD

-- MAIN APPLICATION
addappid(1923630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1923631,0,"779591033f1a2f9c7c5bcd3cc379dfbaafb60b21232b62d5d71bcfb247dcf4b3")

