-- Lua provided by RyzenAPI
-- Game: BORIS the Mutant Bear with a Gun

-- MAIN APPLICATION
addappid(879060)

-- MAIN APP DEPOTS / PACKAGES
addappid(879061, 1, "7a071d3b1ce85b5ee0237122eeb0b20a3f82b70e4dc78e679eb750db6ad69d4d")
addappid(879062, 1, "a6c232c7448b4586da999ed943abc514b545682246760c8545f87301d31781d3")

