-- Lua provided by SkyAPI 
-- Game: Bout
addappid(1883710)
addappid(1883711, 1, "ad645836bf22ad71ae95559d10558f81ca2c5123839ffddd2d0e3e495d3f36aa")
