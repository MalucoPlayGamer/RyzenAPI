-- Lua provided by RyzenAPI
-- Game: 2668540

-- MAIN APPLICATION
addappid(2668540)
-- Game: addappid(2668540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2668541, 1, "3ef7dfdd127d7c182267ce02774de9a1486ce406f6deb76399d362f3b612304b")
