-- Lua provided by RyzenAPI
-- Game: addappid(1059260)

-- MAIN APPLICATION
addappid(1059260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1059261, 1, "be740b481dcd9291d4f597fe2b9b14211d4a94e30eaa0cd08c9834f0a1bbc390")
