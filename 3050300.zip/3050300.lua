-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - REFMAP Fantasy Character Pack 1

-- MAIN APPLICATION
addappid(3050300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3050300,0,"83e9395be8385b95119879ae4819e0f69b80e016cea5a74c7d4826c3865a04ea")

