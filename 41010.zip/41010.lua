-- Lua provided by RyzenAPI
-- Game: Serious Sam HD: The Second Encounter

-- MAIN APPLICATION
addappid(41010)
addappid(41014)
addappid(228990)

-- MAIN APP DEPOTS / PACKAGES
addappid(41011, 1, "b1ab14c69f4a5961db225c8d1e1138e20f179346a4dbb8188f5c514cd23462da")
addappid(41012, 1, "d5d0cc76868cf52e91e5ce07dee28168630817b71ce89d42b2dd352a36420e80")
addappid(41013, 1, "9938f107057c61903f84278371f0b0797b861672043f2e683956bdf241ec8f86")
addappid(41017, 1, "58aa202f3d63667e5da173ed6ebca70a5de8fe9e22292ff3bc2a6ba2b6386cf9")
addappid(41018, 1, "586035d7019c2809d4aaadfd10b093184dbc0d46ed2a504b185d591d7dff40a2")
addappid(41019, 1, "b16df31dcb22162810dfb42f9f932cb22cb12c16e0fd7b498b356a688baaf00f")
addappid(41045, 0, "e40738d86a41081eb8d851e30df2ad375c346fc7f244717dbdaa5084cd14ee64")
addappid(41046, 0, "85e24b1e03b211b7c98f82d80ea309c013474a4b7b1c0118faefdd7cee67d3b4")

