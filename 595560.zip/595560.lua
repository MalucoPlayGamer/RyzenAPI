-- Lua provided by RyzenAPI 
-- Game: Legend of Hand
addappid(595560)
addappid(595561, 1, "5d1974b4cc61a0150d6629ee2a7f9c890770821b54361c1de0bc5e1ebc402cfd")
