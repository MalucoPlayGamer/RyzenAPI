-- Lua provided by RyzenAPI
-- Game: Legend of Hand

-- MAIN APPLICATION
addappid(595560)

-- MAIN APP DEPOTS / PACKAGES
addappid(595561, 1, "5d1974b4cc61a0150d6629ee2a7f9c890770821b54361c1de0bc5e1ebc402cfd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(714830)
addappid(714831)
