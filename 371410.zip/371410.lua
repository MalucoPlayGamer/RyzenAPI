-- Lua provided by RyzenAPI
-- Game: addappid(371410)

-- MAIN APPLICATION
addappid(371410)

-- MAIN APP DEPOTS / PACKAGES
addappid(371411, 1, "07d30ccac13eaca49403f558dc70c2df54b16d45593ffc5e90c01fdba7cec6e9")
