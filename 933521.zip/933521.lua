-- Lua provided by RyzenAPI
-- Game: 933521

-- MAIN APPLICATION
addappid(933521)
-- Game: addappid(933521)

-- MAIN APP DEPOTS / PACKAGES
addappid(933521,0,"f7e803ca7875d15be8618e732bdb82e16770f22b6442e1f3cb1e09ec683b86c7")
