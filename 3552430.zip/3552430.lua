-- Lua provided by SkyAPI 
-- Game: Dead Silence - Echoes of the Damned
addappid(3552430)
addappid(3552431, 1, "50a4388ad1adc5c3158a9e0558a9a9381b3b3c316d08150c2a955e421924920e")
