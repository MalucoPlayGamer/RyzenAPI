-- Lua provided by RyzenAPI 
-- Game: FINAL FANTASY X Original Soundtrack
addappid(3372120)
addappid(3372121, 1, "3bd80adfc871870071ca757459f1091e3b57cc640bc239ed834d840aa2699b34")
