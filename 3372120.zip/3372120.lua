-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY X Original Soundtrack

-- MAIN APPLICATION
addappid(3372120)
-- Game: addappid(3372120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372121, 1, "3bd80adfc871870071ca757459f1091e3b57cc640bc239ed834d840aa2699b34")
