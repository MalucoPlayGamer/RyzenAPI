-- Lua provided by RyzenAPI
-- Game: What have you done, Father?

-- MAIN APPLICATION
addappid(2584260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2584261, 1, "46b3183b6c045f4e16e26d11693b528bda0fc55815e5a648c5ddbdf344529a1e")

