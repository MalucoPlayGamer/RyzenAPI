-- Lua provided by RyzenAPI
-- Game: DOGWALK

-- MAIN APPLICATION
addappid(3775050)
addappid(3833380)

