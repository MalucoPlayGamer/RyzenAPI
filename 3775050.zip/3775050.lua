-- Lua provided by RyzenAPI
-- Game: DOGWALK

-- MAIN APPLICATION
addappid(3775050)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3833380)
