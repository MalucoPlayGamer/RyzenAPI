-- Lua provided by RyzenAPI
-- Game: Eastern Exorcist - Digital Artbook

-- MAIN APPLICATION
addappid(1764630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1764630,0,"4d381efb990ec6231562a7b89a0f3f34bdd224615307a1730f0c23ffe094fcb5")
