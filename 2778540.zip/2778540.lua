-- Lua provided by RyzenAPI
-- Game: 勇者救魔神—阿奎拉尼大陆战记

-- MAIN APPLICATION
addappid(2778540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2778541, 1, "7b1813833b2e7ab5e39e64b4ec50dcb48e3da09ba8484b0dac00982f4759e825")

