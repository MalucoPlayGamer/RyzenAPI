-- Lua provided by RyzenAPI
-- Game: Brain Break

-- MAIN APPLICATION
addappid(1459360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1459361, 1, "5fb85af0462c2bfa98839635831ddd400ef3a57fc4efaeddff99b563d01993e5")

