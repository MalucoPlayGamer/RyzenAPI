-- Lua provided by RyzenAPI 
-- Game: GRIP: Combat Racing
addappid(396900)
addappid(396901, 1, "785f46f11585c0e8acc28e4b70f1fecfa9a9b08f6082d5a3d6977a79cdca2954")
