-- Lua provided by RyzenAPI
-- Game: GRIP: Combat Racing

-- MAIN APPLICATION
addappid(396900)
addappid(942350)
addappid(942351)
addappid(942352)
addappid(942353)
addappid(942354)
addappid(942355)
addappid(942356)
addappid(953100)
addappid(953101)
addappid(953106)
addappid(958950)
addappid(1011520)
addappid(1011521)
addappid(1011522)
addappid(1011523)
addappid(1011524)
addappid(1024620)
addappid(1087830)
addappid(1094310)
addappid(1102590)
addappid(1102610)
addappid(1102620)
addappid(1102630)
addappid(1102640)
addappid(1382700)

-- MAIN APP DEPOTS / PACKAGES
addappid(396901, 1, "785f46f11585c0e8acc28e4b70f1fecfa9a9b08f6082d5a3d6977a79cdca2954")

