-- Lua provided by RyzenAPI
-- Game: AppID 2432080

-- MAIN APPLICATION
addappid(2432080)
-- Game: addappid(2432080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2432081, 1, "0644defb8aa168afbea50fb64379f9a3c27324e110f1d92c0648237db18a3c5d")
