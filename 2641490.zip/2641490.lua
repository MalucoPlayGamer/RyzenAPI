-- Lua provided by RyzenAPI
-- Game: Blood Running

-- MAIN APPLICATION
addappid(2641490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641491, 1, "43ecebb96b5ec703b426313e74d89074771dff28f98bc5cca174f8d42d6a6fd8")
addappid(3331820, 0, "696db94719bbd17b91222766034a9aae4dab574516133a4e01260b5ad42f34bc")
