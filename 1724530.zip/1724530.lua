-- Lua provided by RyzenAPI
-- Game: AppID 1724530

-- MAIN APPLICATION
addappid(1724530)
-- Game: addappid(1724530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724531, 1, "a5861173b87630454acbaec8fcffe1867a3083c434524c0eaccb7927ed31411f")
