-- Lua provided by RyzenAPI
-- Game: 咕噜咕噜海洋馆

-- MAIN APPLICATION
addappid(3739700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3739701, 1, "fa8e6859c771f38d9b4bb862172935ae3e8187cb3033ec4219f1d679af5da9e5")
