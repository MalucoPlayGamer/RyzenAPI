-- Lua provided by RyzenAPI
-- Game: AppID 1196170

-- MAIN APPLICATION
addappid(1196170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1196171, 1, "fd8d464f9d2088b9b58ce3012f1ba7a198124d5a5759c0adff123415beb62fec")
