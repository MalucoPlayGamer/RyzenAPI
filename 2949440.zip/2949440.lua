-- Lua provided by RyzenAPI
-- Game: 2949440

-- MAIN APPLICATION
addappid(2949440)
-- Game: addappid(2949440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2949441, 1, "c937238ffb302b2f7dd5920fe37e93e01743ba7ae1e4423b26ec5bd0efb55b1a")
