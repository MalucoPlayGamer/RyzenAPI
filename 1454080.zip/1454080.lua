-- Lua provided by RyzenAPI
-- Game: Game: Dino Galaxy Tennis

-- MAIN APPLICATION
addappid(1454080)
-- Game: addappid(1454080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454081, 1, "3811765d04459e493332cc9e6a07a4aff1c4d5485c14dd55f2dd50e08e0eeb2d")
