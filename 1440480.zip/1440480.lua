-- Lua provided by RyzenAPI
-- Game: I Am Dead - Original Soundtrack

-- MAIN APPLICATION
addappid(1440480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440481, 1, "318cfb5b1535343a6c1d6f2cdd0c1e2ca6afbcb02031a014ea6c454b122bfe81")

