-- Lua provided by RyzenAPI
-- Game: addappid(1353270)

-- MAIN APPLICATION
addappid(1353270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1353271, 1, "ac4d0ec8bc374e7f1c24492b30e177ee172dce050aa5b1d8d3b2ca91bd6cd90e")
addappid(1353272, 1, "7868dadc919ec3ae0e5870c1671b76844ce309b4bbb82d3dd1cf7add3bec6bd9")
addappid(1353273, 1, "5bfc0d02f09e7aaabec997385a534d4c07969ef93b6df776eee89e3eac3e380a")
addappid(1353274, 1, "3dbbe77a78566c015ccc96c72bd5e1cfafce430c1a19c8d611666cf03317914c")
