-- Lua provided by RyzenAPI
-- Game: Game: AppID 628290

-- MAIN APPLICATION
addappid(628290)
-- Game: addappid(628290)

-- MAIN APP DEPOTS / PACKAGES
addappid(628291, 1, "ff617b0a6083fcefa4ccf529ced56a392f97cd5ff95374c13edef71640e563d4")
addappid(628292, 1, "e397319d931ed588d21a308c23391b459e22609227770f7fd23e3756ecfadad4")
addappid(628293, 1, "3803eebf8594aa36d594fe8de3098a31c48f82c1b9a19b916bdc2634106d13ac")
