-- Lua provided by RyzenAPI
-- Game: addappid(1452700)

-- MAIN APPLICATION
addappid(1452700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1452701, 1, "d154a4aec95fc69da5c7ac69d6f3bd3c197604351e72eb12aba00a14aa855f6e")
