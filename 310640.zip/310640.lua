-- Lua provided by SkyAPI 
-- Game: European Fishing
addappid(310640)
addappid(310641, 1, "4e39e801201a42309dc5f832054a4568ee26fcfcd081e82dab16e0e77d781293")
addappid(310642, 1, "8aac61eaf8d9f8bb6a818c914b0267dbcdfa2419456142428d5f71ddef05bcb3")
addappid(310643, 1, "1460b48cc89e2a02dcb4b3373ceeeb332bcd73b2ec9f2a38843a7f943cd84d29")
