-- Lua provided by RyzenAPI
-- Game: Game: Bane of Asphodel

-- MAIN APPLICATION
addappid(831810)
-- Game: addappid(831810)

-- MAIN APP DEPOTS / PACKAGES
addappid(831811, 1, "6af8cdf6a04313766f4b9ae54f0d6c08be5906cf2506b851816c3bd607204ecc")
