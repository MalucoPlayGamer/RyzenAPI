-- Lua provided by RyzenAPI 
-- Game: Bane of Asphodel
addappid(831810)
addappid(831811, 1, "6af8cdf6a04313766f4b9ae54f0d6c08be5906cf2506b851816c3bd607204ecc")
