-- Lua provided by RyzenAPI 
-- Game: CUSTOM ORDER MAID 3D2 Sexy and Ladylike Woman GP-02
addappid(2684990)
addappid(2684991, 1, "0c64f90d43f2cb53ee8136b2654b1b473bd45ff867931a0e3bf70c352f96ee97")
