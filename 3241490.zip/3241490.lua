-- Lua provided by RyzenAPI
-- Game: 下一个就是你

-- MAIN APPLICATION
addappid(3241490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241491, 1, "a8f003c38928098e1498ded63ced9b3dd68e3b2e067e5d878efdbcbca74eb8d2")
