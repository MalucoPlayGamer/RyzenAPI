-- Lua provided by RyzenAPI
-- Game: Adventures of Hooi

-- MAIN APPLICATION
addappid(563140)

-- MAIN APP DEPOTS / PACKAGES
addappid(563141, 1, "8cb9f1890663158f986cf70024f5aa0a630bb4691407b76b90df9e97b9648757")
