-- Lua provided by RyzenAPI
-- Game: 1454910

-- MAIN APPLICATION
addappid(1454910)
-- Game: addappid(1454910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454911, 1, "523e01239196ef9bfeac665c5b79ec87ca2e1f000e4348e7bbff2d335ad64f79")
