-- Lua provided by RyzenAPI
-- Game: Substance 3D Designer 2021

-- MAIN APPLICATION
addappid(1454910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454911, 1, "523e01239196ef9bfeac665c5b79ec87ca2e1f000e4348e7bbff2d335ad64f79")
