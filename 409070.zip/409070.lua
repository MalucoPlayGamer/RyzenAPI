-- Lua provided by RyzenAPI
-- Game: Fist Slash: Of Ultimate Fury

-- MAIN APPLICATION
addappid(409070)
-- Game: addappid(409070)

-- MAIN APP DEPOTS / PACKAGES
addappid(409071, 1, "7e9976e24604c12a032347dc342ce8cd3b134d1f328fce1607bda9c3517b4d46")
