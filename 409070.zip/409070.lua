-- Lua provided by SkyAPI 
-- Game: Fist Slash: Of Ultimate Fury
addappid(409070)
addappid(409071, 1, "7e9976e24604c12a032347dc342ce8cd3b134d1f328fce1607bda9c3517b4d46")
