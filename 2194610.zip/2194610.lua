-- Lua provided by RyzenAPI
-- Game: addappid(2194610)

-- MAIN APPLICATION
addappid(2194610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194611, 1, "9211f3f5dda994d887e48d6d808ad9b5cb72a2ee7bcaec04dd59aa666d97e577")
