-- Lua provided by RyzenAPI
-- Game: Eriksholm: The Stolen Dream Soundtrack

-- MAIN APPLICATION
addappid(3829100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3829101, 1, "36c2856472f87dd4e730999b92dddcef516b567c108b3c2155a4c8f6cb50a583")
addappid(3829102, 1, "065f091174b33dbd3f5c793b05f50fced601d042f92378619548473a7cffe72a")
