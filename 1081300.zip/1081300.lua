-- Lua provided by RyzenAPI
-- Game: 1081300

-- MAIN APPLICATION
addappid(1081300)
-- Game: addappid(1081300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081301, 1, "96033ddc5fed5310d0569e5ec8b4983ade23472946d1acc073f2e1d32dea5801")
