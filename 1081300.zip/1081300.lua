-- Lua provided by RyzenAPI
-- Game: Sacre Bleu

-- MAIN APPLICATION
addappid(1081300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1081301, 1, "96033ddc5fed5310d0569e5ec8b4983ade23472946d1acc073f2e1d32dea5801")

