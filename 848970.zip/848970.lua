-- Lua provided by RyzenAPI
-- Game: Squad 44 Soundtrack & Art Book

-- MAIN APPLICATION
addappid(848970)

-- MAIN APP DEPOTS / PACKAGES
addappid(848970,0,"a7f02143ae9aa346fc9a1aa3d89ce32d5873e6b0c80940258c4469afeb5e8123")
