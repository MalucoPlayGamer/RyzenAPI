-- Lua provided by RyzenAPI
-- Game: CORPSE FACTORY

-- MAIN APPLICATION
addappid(1414250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414251, 1, "327a05a39e762f86e6d7c7a20318cf99820be17d6eb8956427583f1cac1287a4")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2009170)
