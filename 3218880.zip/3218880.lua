-- Lua provided by RyzenAPI
-- Game: The Succession of Changing Kings

-- MAIN APPLICATION
addappid(3218880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3218881, 1, "70be3f3ae31aec799cf86dd26077b949ec4dd722003b83df64557ec0076f558d")

