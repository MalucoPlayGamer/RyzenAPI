-- Lua provided by RyzenAPI
-- Game: GlitchPets

-- MAIN APPLICATION
addappid(886630)

-- MAIN APP DEPOTS / PACKAGES
addappid(886634,0,"1609f035de75cefcf3ba772e184176aa05a8e7f25431363acaeba7d177a7e2fd")
addappid(886639,0,"057727d1fe1d1598a87fb2b668ee91f43b978db86f2d15e8aea3002342f00942")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
