-- Lua provided by RyzenAPI
-- Game: GlitchPets

-- MAIN APPLICATION
addappid(886630)
-- Game: addappid(886630)

-- MAIN APP DEPOTS / PACKAGES
addappid(886634,0,"1609f035de75cefcf3ba772e184176aa05a8e7f25431363acaeba7d177a7e2fd")
addappid(886639,0,"057727d1fe1d1598a87fb2b668ee91f43b978db86f2d15e8aea3002342f00942")
