-- Lua provided by RyzenAPI
-- Game: Landscaper Simulator

-- MAIN APPLICATION
addappid(3959530) -- Landscaper Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(3959531, 1, "381af5364ad26fcb30552cd60904593ad13cc1fc45fc5ff310833699227f6756") -- Depot 3959531

