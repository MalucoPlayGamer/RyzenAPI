-- 3959530's Lua and Manifest Created by Hubcap Manifest
-- Landscaper Simulator
-- Created: August 11, 2026 at 23:22:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3959530) -- Landscaper Simulator
-- MAIN APP DEPOTS
addappid(3959531, 1, "381af5364ad26fcb30552cd60904593ad13cc1fc45fc5ff310833699227f6756") -- Depot 3959531
setManifestid(3959531, "1077111923121132317", 1246744697)