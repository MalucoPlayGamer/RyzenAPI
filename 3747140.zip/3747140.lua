-- Lua provided by RyzenAPI
-- Game: Fourmiworld

-- MAIN APPLICATION
addappid(3747140)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3837130)
