-- Lua provided by RyzenAPI
-- Game: Fourmiworld

-- MAIN APPLICATION
addappid(3747140)
