-- Lua provided by RyzenAPI
-- Game: Burst Hero

-- MAIN APPLICATION
addappid(2220480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2220481, 1, "079fd4b76fce4a1a8dada38c27566bc2f230466c651c31db28ccf5ecc1535653")

