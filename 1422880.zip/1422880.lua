-- Lua provided by RyzenAPI
-- Game: setManifestid(1422882,"1984725925811960408")

-- MAIN APPLICATION
addappid(1422880)
-- Game: addappid(1422880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1422882,0,"51268c85db2defa3e7f5167cb44c69edc1ca16fb43895ad88ff1b7b8b9816ed7")
