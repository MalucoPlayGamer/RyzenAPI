-- Lua provided by RyzenAPI
-- Game: addappid(1185270)

-- MAIN APPLICATION
addappid(1185270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1185271, 1, "eef35f836f36b2330ac07d2e30a0aaf309ebb1aeb3ace6127806899c62c729bf")
