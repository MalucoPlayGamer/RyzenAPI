-- Lua provided by RyzenAPI
-- Game: Game: Aristocunts II Re:ERECTION

-- MAIN APPLICATION
addappid(2017700)
-- Game: addappid(2017700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2017701, 1, "0977e26baa12d7de3c9bbe3f500f310a4b22dac153d97db3ab9e075a1135da30")
