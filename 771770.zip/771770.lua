-- Lua provided by RyzenAPI
-- Game: Game: AppID 771770

-- MAIN APPLICATION
addappid(771770)
-- Game: addappid(771770)

-- MAIN APP DEPOTS / PACKAGES
addappid(771771, 1, "ceac78013795704c52f0ff56715b94f415ebb195980b09e6b544852811ef5df9")
