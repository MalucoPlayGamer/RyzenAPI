-- Lua provided by SkyAPI 
-- Game: AppID 771770
addappid(771770)
addappid(771771, 1, "ceac78013795704c52f0ff56715b94f415ebb195980b09e6b544852811ef5df9")
