-- Lua provided by RyzenAPI
-- Game: SVFI - Professional

-- MAIN APPLICATION
addappid(1718750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718751, 1, "ab0615136b7d6c19dc1ab67b3a44f44f0abee36fb3ec3f05b88bc5443a3b1c77")
addappid(1718752, 1, "456ab3c8b1bce017b615cbc8161d9e4a6c3613f65e5efa3eecb18f72ae205559")

