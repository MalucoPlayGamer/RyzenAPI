-- Lua provided by RyzenAPI
-- Game: AUDICA - James Landino - "Funky Computer"

-- MAIN APPLICATION
addappid(1221851)
-- Game: addappid(1221851)

-- MAIN APP DEPOTS / PACKAGES
addappid(1221851,0,"4d6d77aac1e20af3823452886833fdfb9bf457223342d3fa5978b78c45857215")
