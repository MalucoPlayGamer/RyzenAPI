-- Lua provided by RyzenAPI
-- Game: addappid(3418930)

-- MAIN APPLICATION
addappid(3418930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3418931, 1, "bc8a965300fd25acf163522c1c16582bab9fa6f2fefc974f11e531c657bdb79c")
