-- Lua provided by RyzenAPI
-- Game: 吞食天地之乱舞三国

-- MAIN APPLICATION
addappid(3418930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3418931, 1, "bc8a965300fd25acf163522c1c16582bab9fa6f2fefc974f11e531c657bdb79c")

