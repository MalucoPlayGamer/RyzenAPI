-- Lua provided by RyzenAPI
-- Game: Save the Earth

-- MAIN APPLICATION
addappid(2236920)
-- Game: addappid(2236920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2236921, 1, "3a91e1731254334aeb94321247bc270fda86be2376b66fce3ff896acc09a2cac")
