-- Lua provided by RyzenAPI
-- Game: Super Mayor

-- MAIN APPLICATION
addappid(2534930)
-- Game: addappid(2534930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2534931, 1, "1ece2a88341776cabcdd73c30c1f013cc0df02c12c52bcd21def512fa186a4f7")
