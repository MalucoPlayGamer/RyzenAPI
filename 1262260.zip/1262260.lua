-- Lua provided by SkyAPI 
-- Game: AppID 1262260
addappid(1262260)
addappid(1262261, 1, "75c4ab1715d9329d38e40fa1308457374195f0d385a3d2e29ba49061281a13d6")
