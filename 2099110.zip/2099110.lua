-- Lua provided by RyzenAPI
-- Game: The Classrooms

-- MAIN APPLICATION
addappid(2099110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2099111, 1, "f72beb8416791f32f5214aeca544d8e2b30321b3310de239f9ae824182d2a5a7")
