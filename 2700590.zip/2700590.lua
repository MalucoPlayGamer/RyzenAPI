-- Lua provided by RyzenAPI
-- Game: Hentai: Nude Quest

-- MAIN APPLICATION
addappid(2700590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2700591, 1, "3b3b5f009696dda10c5785f8e5bd778fb34ac147e353f77269309d67ee517b9e")
