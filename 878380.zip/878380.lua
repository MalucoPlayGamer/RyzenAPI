-- Lua provided by RyzenAPI
-- Game: 878380

-- MAIN APPLICATION
addappid(878380)
-- Game: addappid(878380)

-- MAIN APP DEPOTS / PACKAGES
addappid(878381, 1, "1084f8d115eae1f2a984f037c57d24e376258520ca4ecfbcda25374536205bb6")
