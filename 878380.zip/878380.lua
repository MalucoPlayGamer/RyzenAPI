-- Lua provided by RyzenAPI
-- Game: Touhou Big Big Battle

-- MAIN APPLICATION
addappid(878380)
addappid(923720)
addappid(930920)
addappid(932700)
addappid(939030)
addappid(939040)
addappid(984000)
addappid(1000420)
addappid(1019640)
addappid(1021910)
addappid(1024550)
addappid(1024551)
addappid(1024554)
addappid(1367570)

-- MAIN APP DEPOTS / PACKAGES
addappid(878381, 1, "1084f8d115eae1f2a984f037c57d24e376258520ca4ecfbcda25374536205bb6")

