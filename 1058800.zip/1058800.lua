-- Lua provided by RyzenAPI
-- Game: addappid(1058800)

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1058800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058802,0,"afc351d32bbd05e1a4b20c8ddf695a0fe54df60d89d700f7e41040ff83d04219")
