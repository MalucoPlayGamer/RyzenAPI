-- Lua provided by SkyAPI 
-- Game: AppID 2401930
addappid(2401930)
addappid(2401931, 1, "be0afb50137b53777419054565b069cb4896942cf8af8b8d9c3d54ccb212fbdf")
