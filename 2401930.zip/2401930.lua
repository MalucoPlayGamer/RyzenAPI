-- Lua provided by RyzenAPI
-- Game: Game: AppID 2401930

-- MAIN APPLICATION
addappid(2401930)
-- Game: addappid(2401930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2401931, 1, "be0afb50137b53777419054565b069cb4896942cf8af8b8d9c3d54ccb212fbdf")
