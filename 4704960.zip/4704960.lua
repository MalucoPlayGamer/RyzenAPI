-- 4704960's Lua and Manifest Created by Hubcap Manifest
-- Mythopolis
-- Created: August 06, 2026 at 23:52:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4704960) -- Mythopolis
-- MAIN APP DEPOTS
addappid(4704961, 1, "238c0b72a6f4fad1f3d6d039c789c30a70dabb1d27063294399a16144ba26614") -- Depot 4704961
setManifestid(4704961, "3063769717144262146", 840036670)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)