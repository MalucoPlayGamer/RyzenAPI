-- Lua provided by RyzenAPI
-- Game: Mythopolis

-- MAIN APPLICATION
addappid(4704960) -- Mythopolis

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4704961, 1, "238c0b72a6f4fad1f3d6d039c789c30a70dabb1d27063294399a16144ba26614") -- Depot 4704961

