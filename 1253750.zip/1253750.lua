-- Lua provided by RyzenAPI
-- Game: Movavi Video Editor Plus 2020 Effects - Cinematic Set

-- MAIN APPLICATION
addappid(1253750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253750,0,"7fdb6d668fade9337208949f177517419a75a1973666bf9b09b233cbba82a913")
