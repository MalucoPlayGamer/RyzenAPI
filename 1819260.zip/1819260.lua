-- Lua provided by RyzenAPI
-- Game: Game: AppID 1819260

-- MAIN APPLICATION
addappid(1819260)
-- Game: addappid(1819260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1819261, 1, "ed4ee6bb6b0b9e0193ba226422bc79c3bdc2295af712ebbe502e560b26991329")
