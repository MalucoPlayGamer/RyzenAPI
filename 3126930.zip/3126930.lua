-- Lua provided by RyzenAPI
-- Game: Game: Level Zero: Extraction Soundtrack

-- MAIN APPLICATION
addappid(3126930)
-- Game: addappid(3126930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3126931, 1, "a43129a396c8ee820e6d80f9fec7f72062b77d21ff7ed0a40fb251d476ce6f59")
