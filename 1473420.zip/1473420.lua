-- Lua provided by SkyAPI 
-- Game: AppID 1473420
addappid(1473420)
addappid(1473421, 1, "20021ebb8e358df13611a0c9e90a31c8a7ca6e1e2a78b7cc1d4cf8a297c7648e")
