-- Lua provided by RyzenAPI
-- Game: Forgive Me Father 2

-- MAIN APPLICATION
addappid(2272250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2272251, 1, "baf5fc4fa3c34c4aeb5144bd32e44e94faa17af0db343b1ef4006fd1ffe273c4")
addappid(2272252, 1, "834bcda1fdce38a9d8cbb5c1b490711653a2e4f423e30844962ab32caab30c0a")
addappid(3297180, 0, "6442724b499e5e2fede61b0460259b6dfc06ff484abfa51db3a235d895f001c4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4110790)
