-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1654380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1654380,0,"7f703297aa111ea8c0c382121509b176b30848d102fa258c78880287d6f86397")

