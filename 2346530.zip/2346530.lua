-- Lua provided by RyzenAPI
-- Game: Foresia -The Lust Curse-

-- MAIN APPLICATION
addappid(2346530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2346531, 1, "2ace4b16b6f77551d885c86657e3e5b74e09df76af8eefeeda1a81ca9c0df911")
addappid(2346532, 1, "50099bd4872580e6aaa1bc63a800d666c05db5168c6baf70f13f3629c2f3be9c")
addappid(2346533, 1, "fd2eee9d9534cb470605bc504049edc7dee0ccca45fd137f4baebe638dfd4c10")

