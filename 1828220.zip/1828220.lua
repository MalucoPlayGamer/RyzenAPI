-- Lua provided by RyzenAPI
-- Game: addappid(1828220)

-- MAIN APPLICATION
addappid(1828220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828221, 1, "34e7791526c890ae597f0a7af042aded34b781b5b850df561629ca5709bc1d71")
