-- Lua provided by RyzenAPI 
-- Game: The Emptiness Deluxe Edition
addappid(356160)
addappid(356161, 1, "9671b5f1cde9c033db1144efb95a4467b517897ffa4ef8b4fb209ffacafe2aa4")
