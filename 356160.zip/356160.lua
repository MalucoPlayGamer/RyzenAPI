-- Lua provided by RyzenAPI
-- Game: The Emptiness Deluxe Edition

-- MAIN APPLICATION
addappid(356160)
-- Game: addappid(356160)

-- MAIN APP DEPOTS / PACKAGES
addappid(356161, 1, "9671b5f1cde9c033db1144efb95a4467b517897ffa4ef8b4fb209ffacafe2aa4")
