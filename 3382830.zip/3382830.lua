-- Lua provided by SkyAPI 
-- Game: Zombie Escape
addappid(3382830)
addappid(3382831, 1, "fe7355478e6a33463c762d34342adba75d655a88f646155915f25efb986cfd18")
