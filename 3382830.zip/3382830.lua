-- Lua provided by RyzenAPI
-- Game: Zombie Escape

-- MAIN APPLICATION
addappid(3382830)
-- Game: addappid(3382830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3382831, 1, "fe7355478e6a33463c762d34342adba75d655a88f646155915f25efb986cfd18")
