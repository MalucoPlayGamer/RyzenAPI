-- Lua provided by RyzenAPI
-- Game: INCARNAGE

-- MAIN APPLICATION
addappid(2073280)
-- Game: addappid(2073280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073281, 1, "784d4f8a3162cf84d82e3daa0732c6d0dda0da5bf945600ad7c0d34261ab65dd")
