-- Lua provided by RyzenAPI
-- Game: Project 5: Sightseer

-- MAIN APPLICATION
addappid(655780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(655781, 1, "6817e0a654146a91c8172efe4abce3c987a53a633f73b822d19592c3d1dbc33e")
addappid(655782, 1, "ea95888c14ea3fb13c33831fb71d9e41809f7641eddf6dd8e7c9b02515b8740b")
addappid(655783, 1, "9ab64aa409b3a9f36779a9f56d14fb5a5522f80ffd39b8844495553aaee2325b")

