-- Lua provided by RyzenAPI
-- Game: Rogue Warrior

-- MAIN APPLICATION
addappid(22310)
-- Game: addappid(22310)

-- MAIN APP DEPOTS / PACKAGES
addappid(22311, 1, "e3d298a8486aeed4bf943feedc163c9be9da87fad4802f8d9561cd7b94492e70")
addappid(22312, 1, "ac04e5058f4fafb7f6075ddf0f20d1f891b6d24fece88de414591f23548041e4")
addappid(22313, 1, "3ecdff31f8be4949af5987ff032509bacdea7ed6aa0fdd80ae1496a89f5dafb1")
addappid(22314, 1, "2911454730ab05271a69966d5d7a1b756cb049d8c2a64b18b4eb6189762cec73")
addappid(22315, 1, "8f2274f75ddabbfa9a650e4a1c214f0da62ca47f24f3453ff8f77903aa713444")
addappid(22316, 1, "51798363c194752dc1d95d53ad518dbed7d9785f9091fe84915eb58739242912")
