-- Lua provided by RyzenAPI
-- Game: Game: AppID 1089290

-- MAIN APPLICATION
addappid(1089290)
-- Game: addappid(1089290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089291, 1, "9fbd5772b08dd84fd320083fd1e3ee463591922666d93259f24510342c4cbb52")
