-- Lua provided by SkyAPI 
-- Game: AI Escort
addappid(834070)
addappid(834071, 1, "3202b0ef8719a0f27c48b8a130b365f63dc52348e3d137a9ada58118c7f1b42f")
