-- Lua provided by RyzenAPI
-- Game: KUNKUNKUN

-- MAIN APPLICATION
addappid(2791570)
-- Game: addappid(2791570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791571, 1, "895abd54517ece0fea57aed7d07b3bdc4611d2eed7a99b78727c1cdad4866a78")
