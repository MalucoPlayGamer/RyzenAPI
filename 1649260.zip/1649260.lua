-- Lua provided by RyzenAPI
-- Game: VIVE Hub

-- MAIN APPLICATION
addappid(1649260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1649261, 1, "bdccc7d97fd547d724d01b31a5b08ff49257aeff55cf00b92b5f2a91c6691206")

