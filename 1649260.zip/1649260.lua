-- Lua provided by SkyAPI 
-- Game: VIVE Hub
addappid(1649260)
addappid(1649261, 1, "bdccc7d97fd547d724d01b31a5b08ff49257aeff55cf00b92b5f2a91c6691206")
