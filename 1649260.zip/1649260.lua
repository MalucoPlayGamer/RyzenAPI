-- Lua provided by RyzenAPI
-- Game: Game: VIVE Hub

-- MAIN APPLICATION
addappid(1649260)
-- Game: addappid(1649260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1649261, 1, "bdccc7d97fd547d724d01b31a5b08ff49257aeff55cf00b92b5f2a91c6691206")
