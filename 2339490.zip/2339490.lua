-- Lua provided by RyzenAPI
-- Game: Game: Pirate Patrol

-- MAIN APPLICATION
addappid(2339490)
-- Game: addappid(2339490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2339491, 1, "40ed5bd901378db5b48a3b3a25a54384c8d46abf9741143802195aaac28f9670")
