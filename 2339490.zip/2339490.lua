-- Lua provided by SkyAPI 
-- Game: Pirate Patrol
addappid(2339490)
addappid(2339491, 1, "40ed5bd901378db5b48a3b3a25a54384c8d46abf9741143802195aaac28f9670")
