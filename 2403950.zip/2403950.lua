-- Lua provided by RyzenAPI
-- Game: Double Cheeseburger, Medium Fries

-- MAIN APPLICATION
addappid(2403950)
