-- Lua provided by RyzenAPI
-- Game: 3295200

-- MAIN APPLICATION
addappid(3295200)
addappid(3295201)

-- MAIN APP DEPOTS / PACKAGES
addappid(3295200,0,"dc8e7206a9b7395dc1bdbe862657af4fba36797fef2cc56c89f84e59b59d7743")
