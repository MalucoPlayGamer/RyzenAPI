-- Lua provided by RyzenAPI
-- Game: Game: AppID 787690

-- MAIN APPLICATION
addappid(787690)
-- Game: addappid(787690)

-- MAIN APP DEPOTS / PACKAGES
addappid(787691, 1, "35c524cb6867b93ae31439083c4e037f4c5431ca4e791b9d76f11cbda6536a13")
