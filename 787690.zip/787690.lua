-- Lua provided by SkyAPI 
-- Game: AppID 787690
addappid(787690)
addappid(787691, 1, "35c524cb6867b93ae31439083c4e037f4c5431ca4e791b9d76f11cbda6536a13")
