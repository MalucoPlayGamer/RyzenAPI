-- Lua provided by RyzenAPI
-- Game: Aquarium Designer – Sea Life

-- MAIN APPLICATION
addappid(1939750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939751, 1, "0ba8c5a592eb9ca6ad837915f34a6184268be788e3b52a4584afbcc65b7583d7")

