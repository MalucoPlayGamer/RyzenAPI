-- Lua provided by RyzenAPI
-- Game: AppID 1300940

-- MAIN APPLICATION
addappid(1300940)
addappid(1307060)
addappid(1307061)
addappid(1307062)
addappid(1307063)
addappid(1307064)
addappid(1307065)

-- MAIN APP DEPOTS / PACKAGES
addappid(1300941, 1, "3e98598af786e1f565302ac704619c5d50272b8be25464512d77fa0b74e52d16")
addappid(1300942, 1, "2c1c815a6454b0edea172a53124c52cf8692c43b0a5c313e831c1fa335cbe0b4")
addappid(1300943, 1, "3c0efce58f9bc263bf93f91de390db80b34aa33c39a013cc24732cc620a270a3")
addappid(1300944, 1, "bce60cd9f9ce22b16ff93ff0e91322ae731d9c22b113b7ae37cf15193f1f0dd9")
addappid(1300945, 1, "946d4122e39f309ee607ab3f36d0732d8ad274f5510e34afab0091aa0640431c")
addappid(1300946, 1, "199e9f0c10a964c849b0c9c0aeed6d59e83a0f12d204c3f42e498cdb01c3c9be")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
