-- Lua provided by RyzenAPI
-- Game: Wayout

-- MAIN APPLICATION
addappid(551110)

-- MAIN APP DEPOTS / PACKAGES
addappid(551111, 1, "4e2eb344b95355566ae736668709a3da75f1d37dcbdda740da43cc0665db2d93")
addappid(551112, 1, "bfdc92ef816f88134afa383e2049583260fbe3e00130a926ffe292e1c5c36e8f")
addappid(551113, 1, "af133ace2bae8c64c26ee016b4d5b79b52b1e060493e6b71e825cccd3f3e77d8")

