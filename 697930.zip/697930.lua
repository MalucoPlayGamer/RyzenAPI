-- Lua provided by SkyAPI 
-- Game: AppID 697930
addappid(697930)
addappid(697931, 1, "94ac2556729b53a77c0183c7d0d71afd5d5df43679ae9e801defbf2ed1bde736")
