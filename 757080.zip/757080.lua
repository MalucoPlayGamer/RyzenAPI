-- Lua provided by RyzenAPI
-- Game: addappid(757080)

-- MAIN APPLICATION
addappid(757080)

-- MAIN APP DEPOTS / PACKAGES
addappid(757081, 1, "5ed432289ab473ae4706965ab0a58a05a183027fad3e472f458944b2024eabba")
