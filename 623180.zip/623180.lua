-- Lua provided by RyzenAPI
-- Game: Game: Zombie Solitaire 2 Chapter 3

-- MAIN APPLICATION
addappid(623180)
-- Game: addappid(623180)

-- MAIN APP DEPOTS / PACKAGES
addappid(623181, 1, "604dcc58314edbc6c970e789eeae94bad8dfa784f4afed0863bf71b6fa32adcf")
addappid(623184, 1, "c426f2dcac6bfa2b5a1e8d851b0435b9d614d72d360fdc7c956037a3a39fc5b7")
