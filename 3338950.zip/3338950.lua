-- Lua provided by RyzenAPI
-- Game: The Scouring

-- MAIN APPLICATION
addappid(3338950)
addappid(3896510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3338951, 1, "8b76cee96290d22f7fef71f6920eb44d7544f63956ff688808e68dbcae407b3c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
