-- Lua provided by RyzenAPI
-- Game: Game: The Scouring

-- MAIN APPLICATION
addappid(3338950)
addappid(3896510)
-- Game: addappid(3338950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3338951, 1, "8b76cee96290d22f7fef71f6920eb44d7544f63956ff688808e68dbcae407b3c")
