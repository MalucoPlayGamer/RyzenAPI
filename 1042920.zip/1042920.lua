-- Lua provided by RyzenAPI
-- Game: addappid(1042920)

-- MAIN APPLICATION
addappid(1042920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042921, 1, "8ebe5ba45a3b1390b2097403069459e651b21a67cb1ef92d9fc443b76ca06dbe")
