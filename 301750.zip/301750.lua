-- Lua provided by RyzenAPI
-- Game: 301750

-- MAIN APPLICATION
addappid(301750)
addappid(739620)
-- Game: addappid(301750)

-- MAIN APP DEPOTS / PACKAGES
addappid(301751, 1, "7131b5e740275ec488d9d3e0ad17e0dbd6cef6c7a47944d2cd0fc3a366a22d6a")
