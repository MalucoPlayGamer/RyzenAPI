-- Lua provided by RyzenAPI
-- Game: RADical ROACH Remastered

-- MAIN APPLICATION
addappid(301750)
addappid(739620)

-- MAIN APP DEPOTS / PACKAGES
addappid(301751, 1, "7131b5e740275ec488d9d3e0ad17e0dbd6cef6c7a47944d2cd0fc3a366a22d6a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
