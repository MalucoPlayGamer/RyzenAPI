-- Lua provided by RyzenAPI 
-- Game: AppID 1374170
addappid(1374170)
addappid(1374171, 1, "d96f073a161ab3257f1cff0a6a7747f512a98b8a86695f317a5cd00a0cb2fa5b")
