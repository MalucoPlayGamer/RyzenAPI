-- Lua provided by RyzenAPI
-- Game: addappid(340340)

-- MAIN APPLICATION
addappid(340340)

-- MAIN APP DEPOTS / PACKAGES
addappid(340341, 1, "e8d1eae9f651b77bf974c07b1b9053468756af4a9d091f096ebeb81133751165")
