-- Lua provided by RyzenAPI
-- Game: Fuzoku Frame [18+]

-- MAIN APPLICATION
addappid(1822040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1822041, 1, "74c0ab48e0d448c1be9f7e5ed1b8d679c66d09a1230b8abfd4429f8bcc938197")
