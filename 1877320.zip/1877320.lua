-- Lua provided by RyzenAPI
-- Game: The Walking Dead: Betrayal

-- MAIN APPLICATION
addappid(1877320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1877321, 1, "6d803475f030b35ac1519ebb89d2fa3d5fc10cee2bcb101a8eaa10e7fd5c869f")

