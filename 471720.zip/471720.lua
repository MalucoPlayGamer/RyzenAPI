-- Lua provided by RyzenAPI
-- Game: K Station

-- MAIN APPLICATION
addappid(471720)

-- MAIN APP DEPOTS / PACKAGES
addappid(471721, 1, "7e05ddf0ffbbb10a66df93ff71d43e04f4f6bba34ce80f0bfab6b25407948886")
