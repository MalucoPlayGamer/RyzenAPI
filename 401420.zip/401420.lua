-- Lua provided by RyzenAPI
-- Game: Match 3 Revolution

-- MAIN APPLICATION
addappid(401420)

-- MAIN APP DEPOTS / PACKAGES
addappid(401421, 1, "284fda46f53ba8b8f9328509827af05f45157f7e5872ef61895d9b44124f4a53")

