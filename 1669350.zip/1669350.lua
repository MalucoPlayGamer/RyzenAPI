-- Lua provided by RyzenAPI 
-- Game: Fingun
addappid(1669350)
addappid(1669351, 1, "e192606688398045f6187eed5cc33acff672e5da0f925a1787369727ff160228")
