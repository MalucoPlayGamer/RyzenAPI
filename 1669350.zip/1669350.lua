-- Lua provided by RyzenAPI
-- Game: Game: Fingun

-- MAIN APPLICATION
addappid(1669350)
-- Game: addappid(1669350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669351, 1, "e192606688398045f6187eed5cc33acff672e5da0f925a1787369727ff160228")
