-- Lua provided by RyzenAPI
-- Game: Galaxy on Fire 2™ Full HD

-- MAIN APPLICATION
addappid(212010)

-- MAIN APP DEPOTS / PACKAGES
addappid(212011, 1, "dd3488556b41c0ad54abb267eba9145ec5f93d5f199b561716c73865716b111a")
