-- Lua provided by RyzenAPI
-- Game: addappid(2396590)

-- MAIN APPLICATION
addappid(2396590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396591, 1, "dfe48407f253ffadc7523b9b5baf56259d598e4c430bb5c92b47bb450cec200d")
