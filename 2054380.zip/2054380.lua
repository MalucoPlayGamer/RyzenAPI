-- Lua provided by RyzenAPI
-- Game: Game: SONOKUNI

-- MAIN APPLICATION
addappid(2054380)
-- Game: addappid(2054380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2054381, 1, "915e40b68289cef96ca293aa184495a1d5139e262beb756b135e80ab1be8cba8")
