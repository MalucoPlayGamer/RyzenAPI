-- Lua provided by SkyAPI 
-- Game: SONOKUNI
addappid(2054380)
addappid(2054381, 1, "915e40b68289cef96ca293aa184495a1d5139e262beb756b135e80ab1be8cba8")
