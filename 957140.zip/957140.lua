-- Lua provided by RyzenAPI
-- Game: 新世勇者传 Newera Heroes' Chronicle

-- MAIN APPLICATION
addappid(957140)
addappid(1003080)
addappid(4725730)

-- MAIN APP DEPOTS / PACKAGES
addappid(957141, 1, "ad0cab8616874d07a9bbbf96a09564e3e37da642d969bf422942d3a096d1def6")

