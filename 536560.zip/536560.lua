-- Lua provided by RyzenAPI
-- Game: addappid(536560)

-- MAIN APPLICATION
addappid(536560)

-- MAIN APP DEPOTS / PACKAGES
addappid(536561, 1, "ebbd4ba17c60dd6cace658d9d9aa0fee688e3519cbf475cd4c7e8996e06066a3")
