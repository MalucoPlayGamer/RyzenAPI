-- Lua provided by RyzenAPI
-- Game: CHAOS CODE -NEW SIGN OF CATASTROPHE-

-- MAIN APPLICATION
addappid(536560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(536561, 1, "ebbd4ba17c60dd6cace658d9d9aa0fee688e3519cbf475cd4c7e8996e06066a3")

