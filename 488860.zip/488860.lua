-- Lua provided by RyzenAPI
-- Game: MADNESS: Project Nexus

-- MAIN APPLICATION
addappid(488860)
-- Game: addappid(488860)

-- MAIN APP DEPOTS / PACKAGES
addappid(488861, 1, "d63cfdd3553f33bbd71bd9c5430eb5c4b09085a05e602d8ee428f1fef3399b75")
