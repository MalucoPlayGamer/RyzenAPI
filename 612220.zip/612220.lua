-- Lua provided by RyzenAPI
-- Game: setManifestid(612222,"2047564997325901351")

-- MAIN APPLICATION
addappid(612220)

-- MAIN APP DEPOTS / PACKAGES
addappid(612222,0,"18892e92994aaff14e0eeb4fea22b2cb3ec6b1a4cba1d6ee7620fc8c1e738585")
