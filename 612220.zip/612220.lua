-- Lua provided by RyzenAPI
-- Game: Chaos Edge

-- MAIN APPLICATION
addappid(612220)

-- MAIN APP DEPOTS / PACKAGES
addappid(612222,0,"18892e92994aaff14e0eeb4fea22b2cb3ec6b1a4cba1d6ee7620fc8c1e738585")

