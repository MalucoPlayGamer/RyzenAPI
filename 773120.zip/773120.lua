-- Lua provided by RyzenAPI
-- Game: Christmas Santa Troubles

-- MAIN APPLICATION
addappid(773120)
-- Game: addappid(773120)

-- MAIN APP DEPOTS / PACKAGES
addappid(773121, 1, "f44de46cc0b67fc111bee0a894478efcac5eac0c0dc54ee95393a83790fbfae0")
