-- Lua provided by RyzenAPI
-- Game: Game: Slaves of Rome

-- MAIN APPLICATION
addappid(1380070)
-- Game: addappid(1380070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380071, 1, "35bbeb039ac8fcae5ecedb7bf9592c5fbead89187c78e7fca100ccc0b85d39a9")
