-- Lua provided by RyzenAPI
-- Game: 琉隐 Demo

-- MAIN APPLICATION
addappid(1496940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1496941, 1, "3f542bfee112398d48bc16898f81d952abd80527bd7ea64f69a440b5a33da3dd")
