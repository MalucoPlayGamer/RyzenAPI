-- Lua provided by RyzenAPI
-- Game: Fury Of The Gods

-- MAIN APPLICATION
addappid(373460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(373461, 1, "dc30c0242772ac04b9a015b4cef707cceea1a8d1cd56cfcf6316287de70930bf")
