-- Lua provided by RyzenAPI
-- Game: 373460

-- MAIN APPLICATION
addappid(373460)
-- Game: addappid(373460)

-- MAIN APP DEPOTS / PACKAGES
addappid(373461, 1, "dc30c0242772ac04b9a015b4cef707cceea1a8d1cd56cfcf6316287de70930bf")
