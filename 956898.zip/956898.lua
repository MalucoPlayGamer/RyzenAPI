-- Lua provided by RyzenAPI
-- Game: Xu Shu - Officer Ticket / 徐庶使用券

-- MAIN APPLICATION
addappid(956898)

-- MAIN APP DEPOTS / PACKAGES
addappid(956898,0,"fea9b6a3e14ae60906b4a0824a6b6080d3c0fabb4cb4dd7406a9bbe281ef7b6a")

