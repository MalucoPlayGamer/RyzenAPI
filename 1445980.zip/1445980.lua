-- Lua provided by RyzenAPI 
-- Game: Tiny Traffic
addappid(1445980)
addappid(1445981, 1, "ac1ec206756f2e02e684950f482b8794b9d17f37a633afc01cfa68a639cc4439")
