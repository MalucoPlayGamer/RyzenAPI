-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - MV Enemies - character sprites

-- MAIN APPLICATION
addappid(1648520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648520,0,"61093405b9befa786c63cd5d741d7b9d46bbaef3d5bea15fb25b35dc4574dae6")

