-- Lua provided by SkyAPI 
-- Game: Backrooms: The Others
addappid(3585080)
addappid(3585081, 1, "c6607c2ab15afa32ca357a0f964af7318fd71bdb737108198e827f4f4609f418")
