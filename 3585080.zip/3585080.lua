-- Lua provided by RyzenAPI
-- Game: Backrooms: The Others

-- MAIN APPLICATION
addappid(3585080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3585081, 1, "c6607c2ab15afa32ca357a0f964af7318fd71bdb737108198e827f4f4609f418")

