-- Lua provided by RyzenAPI
-- Game: Lost Legends: The Weeping Woman Collector's Edition

-- MAIN APPLICATION
addappid(397440)

-- MAIN APP DEPOTS / PACKAGES
addappid(397441, 1, "a79a3ecf52ceb4085842716134275728829dd0de562a2210724438280a06c819")
addappid(397442, 1, "5a3765122d777d19585ff57b38e6f17ac20eb174b31ee80fd84e0e3e015e0b65")
addappid(397443, 1, "0d5a8fe7331e4c4ecb10e5518bb5759dd29e45e8f72fce26a02891053e0bd9eb")
addappid(397444, 1, "02101494eb46ea33be9ccc251e3dcf5e31d49187a545fadac77c43c7ed419011")
addappid(397445, 1, "98ed99f5486e08d2829cc8d4c2e65d1d8003ca5976704a22f5b838cd9530585e")
addappid(397446, 1, "e6da1f6b25f1c1bdd73ba6a7f2bff905663c6e44e4cdcf52a05ee8fc53c9b81f")

