-- Lua provided by RyzenAPI
-- Game: Urban Rivals

-- MAIN APPLICATION
addappid(715310)

-- MAIN APP DEPOTS / PACKAGES
addappid(715311, 1, "f67c1b6bbaa78bdbde86ff8dda202b885b61a12d840e714fa0882f5b902a9c51")
addappid(715312, 1, "b8d1dc1579f74f60cdea99ede2769e727d16785ba26d14983f7e728befcce175")
addappid(715313, 1, "298aad182351fbdaedd04a8aaa880cfdead13fa1f6bdbb81b5262a550dbe201d")
