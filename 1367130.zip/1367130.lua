-- Lua provided by RyzenAPI
-- Game: Game: FoxVoltex

-- MAIN APPLICATION
addappid(1367130)
-- Game: addappid(1367130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367131, 1, "ccb32e69db6353760944dbe8b82b732f3332952a93ad954e24fdfe4bf1324800")
