-- Lua provided by RyzenAPI 
-- Game: H Chan
addappid(1063130)
addappid(1063131, 1, "01b6dec58f746d89d74e38ed23ffe3813f4ed8691bf5113f67fe49d7ed727b72")
