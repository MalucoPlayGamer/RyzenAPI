-- Lua provided by RyzenAPI
-- Game: 神魔契约

-- MAIN APPLICATION
addappid(1700180)
addappid(1700181)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700182,0,"b546fda9fdbd95e2c760ec2d427dc146fc3022ae3b6d5a48dbcf70114f0e36a1")
addtoken(1700180,3527824433820616999)

