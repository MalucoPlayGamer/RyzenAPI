-- Lua provided by SkyAPI 
-- Game: The Survival Test VR: Defend To Death
addappid(718530)
addappid(718531, 1, "9119f70aa9b19e5d5ff09f0f9083b4be5b49048954390b262e5c2a7e66eac7a4")
