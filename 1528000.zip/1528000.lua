-- Lua provided by RyzenAPI
-- Game: Game: Natsuki's Life In Prison

-- MAIN APPLICATION
addappid(1528000)
-- Game: addappid(1528000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1528001, 1, "0b8c2189941e58375347b4db74d9c5c4b72bbcb450b70feb6a45ef976a784876")
