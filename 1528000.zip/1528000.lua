-- Lua provided by SkyAPI 
-- Game: Natsuki's Life In Prison
addappid(1528000)
addappid(1528001, 1, "0b8c2189941e58375347b4db74d9c5c4b72bbcb450b70feb6a45ef976a784876")
