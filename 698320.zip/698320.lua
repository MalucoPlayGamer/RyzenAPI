-- Lua provided by RyzenAPI
-- Game: NanoScape

-- MAIN APPLICATION
addappid(698320)
addappid(698390)

-- MAIN APP DEPOTS / PACKAGES
addappid(698321, 1, "5095d2536d6a1213ce13d8203968cff03b84e704332f327e9475849d2c1568f2")

