-- Lua provided by RyzenAPI
-- Game: 2142790

-- MAIN APPLICATION
addappid(2142790)
-- Game: addappid(2142790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142791, 1, "b0773c2441743d1c8975c20922ec8e1bfc9122d75cff9bb8cdb6e99ba5c0d030")
