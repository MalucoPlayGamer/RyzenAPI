-- Lua provided by RyzenAPI
-- Game: Arcane Blast

-- MAIN APPLICATION
addappid(2628230)
-- Game: addappid(2628230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2628231, 1, "c67f344ac93372dabfb352c27eae11c79d8409b0c46156689ddff1c0c814accd")
