-- Lua provided by RyzenAPI
-- Game: Game: Blind Drive Original Soundtrack

-- MAIN APPLICATION
addappid(1932110)
-- Game: addappid(1932110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1932111, 1, "2cf20ac82fe008297a789dd355858612f091ec92cc4528c4aa837bd22e495b52")
addappid(1932112, 1, "00145e1d94d2205377437db89a5f93556ac62703cf8795d3c444a0f6b42a03c6")
