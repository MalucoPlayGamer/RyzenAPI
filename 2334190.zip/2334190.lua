-- Lua provided by RyzenAPI
-- Game: addappid(2334190)

-- MAIN APPLICATION
addappid(2334190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334191, 1, "c62c734d40d847ff3b52699cc6c2fda80ea4bf320f74cf104783c3ae724bc851")
