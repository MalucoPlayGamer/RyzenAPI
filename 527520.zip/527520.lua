-- Lua provided by RyzenAPI
-- Game: Strike Force: Arctic Storm

-- MAIN APPLICATION
addappid(527520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(527521, 1, "07c0aff19d93fe8126e578e8aeecd3f04a308456d2517836971cbe86e9530af8")

