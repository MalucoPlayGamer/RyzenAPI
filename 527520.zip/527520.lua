-- Lua provided by RyzenAPI
-- Game: Strike Force: Arctic Storm

-- MAIN APPLICATION
addappid(527520)

-- MAIN APP DEPOTS / PACKAGES
addappid(527521, 1, "07c0aff19d93fe8126e578e8aeecd3f04a308456d2517836971cbe86e9530af8")

