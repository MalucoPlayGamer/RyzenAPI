-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1405560)
addappid(1405560,0,"566d0aaac62f99b1b015b1da13ff06915ae4d058c4f1cf1eb54592bf2d62eac0")
-- setManifestid(1405560,"7422013228994442404")