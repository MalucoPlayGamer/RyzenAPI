-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1405560)
-- Game: addappid(1405560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1405560,0,"566d0aaac62f99b1b015b1da13ff06915ae4d058c4f1cf1eb54592bf2d62eac0")
