-- Lua provided by SkyAPI 
-- Game: つばめの世代
addappid(3190720)
addappid(3190721, 1, "8bb5d362494b0ff491a27eea057a523af4c0c6bbfb86321d3ca2ea3d5c593d9f")
