-- Lua provided by RyzenAPI 
-- Game: Rise of Koreth
addappid(2474460)
addappid(2474461, 1, "44b5f06ade54f5de6ebd154ebfb87aaa4086c3e79497c7d0a5723ab25bf055e0")
