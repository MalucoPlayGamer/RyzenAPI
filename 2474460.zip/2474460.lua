-- Lua provided by RyzenAPI
-- Game: Rise of Koreth

-- MAIN APPLICATION
addappid(2474460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2474461, 1, "44b5f06ade54f5de6ebd154ebfb87aaa4086c3e79497c7d0a5723ab25bf055e0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
