-- Lua provided by RyzenAPI
-- Game: 661240

-- MAIN APPLICATION
addappid(661240)
-- Game: addappid(661240)

-- MAIN APP DEPOTS / PACKAGES
addappid(661241, 1, "a08624e7eb5ba3e27706e581a250512aa461a69f8a17b4542a85b45fcfb52b1e")
