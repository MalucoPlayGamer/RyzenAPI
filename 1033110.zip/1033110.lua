-- Lua provided by RyzenAPI
-- Game: Forgotten Trace: Thanatos in Nostalgia - Chapter 1 Complete Edition

-- MAIN APPLICATION
addappid(1033110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1033111, 1, "c82ecb554cbf2bf0dd716a7d8f6d98d07b178a5b0499afaf11c26841755f8407")
