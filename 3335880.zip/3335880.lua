-- Lua provided by RyzenAPI
-- Game: 3335880

-- MAIN APPLICATION
addappid(3335880)
-- Game: addappid(3335880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3335881, 1, "7aa775b9176b111e7d06ce245aee7d5a647b331ef876bfac490e535533b90436")
