-- Lua provided by SkyAPI 
-- Game: NIGHT STORE SIMULATOR
addappid(3335880)
addappid(3335881, 1, "7aa775b9176b111e7d06ce245aee7d5a647b331ef876bfac490e535533b90436")
