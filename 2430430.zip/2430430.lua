-- Lua provided by RyzenAPI
-- Game: Game: Dicefolk Demo

-- MAIN APPLICATION
addappid(2430430)
-- Game: addappid(2430430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430431, 1, "a1cd29ed5d6e0dca19fc3ecbd9ec3d236f15ab5aeafa2f5edf3405c3169a9ab3")
