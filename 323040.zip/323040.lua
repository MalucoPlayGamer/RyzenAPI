-- Lua provided by SkyAPI 
-- Game: Laserlife
addappid(323040)
addappid(323041, 1, "425ac14bab46ab18e0c1948890ec3fc92d3b04baa20e47d0ac1d732c30cabfd7")
