-- Lua provided by RyzenAPI
-- Game: Laserlife

-- MAIN APPLICATION
addappid(323040)

-- MAIN APP DEPOTS / PACKAGES
addappid(323041, 1, "425ac14bab46ab18e0c1948890ec3fc92d3b04baa20e47d0ac1d732c30cabfd7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
