-- Lua provided by RyzenAPI
-- Game: Game: Laserlife

-- MAIN APPLICATION
addappid(323040)
-- Game: addappid(323040)

-- MAIN APP DEPOTS / PACKAGES
addappid(323041, 1, "425ac14bab46ab18e0c1948890ec3fc92d3b04baa20e47d0ac1d732c30cabfd7")
