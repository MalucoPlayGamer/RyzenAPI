-- Lua provided by SkyAPI 
-- Game: Wildrise
addappid(3225790)
addappid(3225791, 1, "a12357c5c4118d0ac6332a002698bc28186c7177e631c64a2a3616b84a271bd6")
