-- Lua provided by RyzenAPI
-- Game: Game: Loot and Shoot

-- MAIN APPLICATION
addappid(2397260)
-- Game: addappid(2397260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2397261, 1, "f8cdf315244b30dc1ae695f28e0d959b86851c551c4b0a541622c60c30c93f22")
