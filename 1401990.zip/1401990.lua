-- Lua provided by RyzenAPI 
-- Game: AppID 1401990
addappid(1401990)
addappid(1401991, 1, "1a6752491517371a2618599555bc63c3dd4e231a674eac70c09555b2a3d837cb")
