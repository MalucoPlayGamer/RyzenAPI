-- Lua provided by RyzenAPI
-- Game: Missing Features: 2D

-- MAIN APPLICATION
addappid(1401990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1401991, 1, "1a6752491517371a2618599555bc63c3dd4e231a674eac70c09555b2a3d837cb")
