-- Lua provided by RyzenAPI
-- Game: Game: AppID 1325680

-- MAIN APPLICATION
addappid(1325680)
-- Game: addappid(1325680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325681, 1, "7c0c9118739281cc7d5126b9941a5b538059c393fb438c2a12ffb38a2ee00c03")
