-- Lua provided by RyzenAPI
-- Game: FRONTIERS

-- MAIN APPLICATION
addappid(293480)

-- MAIN APP DEPOTS / PACKAGES
addappid(293481, 1, "30dc99ec676283aff20d69da2fb9325985ec1baf188f1f8d03b7949d0cff225f")
addappid(293482, 1, "64677da61a1fb32ac7730d94c02f942a650dab8a6b7adad9861bba593b847ffe")
addappid(293483, 1, "e64ded49053f07bc6a6b1f78bcaaa8f561051035edad02d5b249d1cb0f799214")
addappid(293484, 1, "6a4bdbaa3bb0e5b5dfee9d9b4095fa353afffb8cb4bdb56fac5d3d72ba2b41af")
addappid(293485, 1, "22c24995daee974d9c0544a37983841273eda4bddea308e3c1762a8a2cdb9381")
addappid(293486, 1, "843c6b5b20bbce80505c8a030c10aa45ab74c370662d6e3d77ed8304b76f6f17")
addappid(293488, 1, "def8c2a061a8f4cb3984159d46a67fd610ac5e8e90957f42a46ad70573ecc7a1")

