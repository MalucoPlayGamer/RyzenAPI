-- Lua provided by RyzenAPI
-- Game: FrankenStorm TD: Prologue

-- MAIN APPLICATION
addappid(1672920)
-- Game: addappid(1672920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1672921, 1, "126f5b1aa68412cb5d3b3d157b2733e3daa49d54bb20eb25a6f0521dbd11c242")
