-- Lua provided by RyzenAPI
-- Game: Spiritle

-- MAIN APPLICATION
addappid(1493260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493262,0,"110af8d3951df8dbc0b5c4c9bd29212122febb18261eaa9a2638a4596db401ea")
