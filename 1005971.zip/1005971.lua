-- Lua provided by RyzenAPI
-- Game: iVRy Driver for SteamVR (PSVR Premium Edition)

-- MAIN APPLICATION
addappid(1005971)
-- Game: addappid(1005971)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005971,0,"94ccf3272b8560103307bbe340d12d31304f39b2e1562a74fb837bd466398db3")
