-- Lua provided by RyzenAPI
-- Game: 2983260

-- MAIN APPLICATION
addappid(2983260)
-- Game: addappid(2983260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983261, 1, "fc7aefde9e91edf2316bbf9a8c87ca37c357afe87e857325f1e6558d3b913038")
