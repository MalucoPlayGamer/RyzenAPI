-- Lua provided by RyzenAPI
-- Game: The Crown of Leaves

-- MAIN APPLICATION
addappid(604330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(604331, 1, "93cf6dd90398f7eabad693e1f080103e2b1fac009e95e5ef22f7d45038c76385")
addappid(1160540, 0, "c2d36fac3a1a6469f3147ad3316eb8876b89fa96d17f5005d9ebf1aac74dd2b4")
