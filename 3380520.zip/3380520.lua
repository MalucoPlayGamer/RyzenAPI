-- Lua provided by RyzenAPI
-- Game: ToHeart

-- MAIN APPLICATION
addappid(3380520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3380521, 1, "76ab56f6f887226caa5e5f8453facba45a2f5df5475fd6788484b6dec37a3f76")
addappid(3452830, 0, "fd45547b3fdd8e458e1d728122680ed85bb38fb479684086aa6186554ce77dd8")

