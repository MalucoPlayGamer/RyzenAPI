-- Lua provided by RyzenAPI
-- Game: Hog Hunter 2021

-- MAIN APPLICATION
addappid(1583280)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1617380)
