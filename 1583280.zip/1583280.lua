-- Lua provided by RyzenAPI
-- Game: Hog Hunter 2021

-- MAIN APPLICATION
addappid(1583280)
addappid(1617380)

