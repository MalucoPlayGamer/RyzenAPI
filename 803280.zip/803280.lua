-- Lua provided by RyzenAPI
-- Game: Briquid

-- MAIN APPLICATION
addappid(803280)

-- MAIN APP DEPOTS / PACKAGES
addappid(803281, 1, "8fe995ed7bb73301bffa6c1495fda03608d7da154adf4f41a4ed0a657d716545")

