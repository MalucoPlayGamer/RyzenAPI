-- Lua provided by RyzenAPI
-- Game: A Perfect Day Demo

-- MAIN APPLICATION
addappid(1098050)
-- Game: addappid(1098050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098051, 1, "9747f62037a7531be3af63d49a643a94fb2727f84691c21178e8842149f137f7")
