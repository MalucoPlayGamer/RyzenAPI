-- Lua provided by RyzenAPI
-- Game: Minotaur

-- MAIN APPLICATION
addappid(680590)

-- MAIN APP DEPOTS / PACKAGES
addappid(680591, 1, "ef69d8c08afa141054d09c56eddc9748df002563ca58ae0f27c07af13081867c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
