-- Lua provided by RyzenAPI
-- Game: Minotaur

-- MAIN APPLICATION
addappid(680590)

-- MAIN APP DEPOTS / PACKAGES
addappid(680591, 1, "ef69d8c08afa141054d09c56eddc9748df002563ca58ae0f27c07af13081867c")
