-- Lua provided by RyzenAPI
-- Game: Beta Runner

-- MAIN APPLICATION
addappid(656020)

-- MAIN APP DEPOTS / PACKAGES
addappid(656022,0,"120ed038d0fddea2a1de94966e643a34aa4a3f02d4e423b74976fc107d739727")

