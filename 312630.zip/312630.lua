-- Lua provided by RyzenAPI
-- Game: AppID 312630

-- MAIN APPLICATION
addappid(312630)
addappid(317230)
addappid(317240)

-- MAIN APP DEPOTS / PACKAGES
addappid(312631, 1, "5ddd10c763f25d63a74d5ad86ce8fcdc3f6ba91e104e974d37af9dc56ddaf771")
addappid(312632, 1, "80d0063a7277b59e28e430edfa661352fce06c87bca1ab67c48ec000d74adfeb")
addappid(312633, 1, "12e07a0f4f952033c7cbf91f204f2833d71000c8bbd8d432d1a183f70201c9f4")
addappid(312634, 1, "f1997334b0c2192f910e4e2fb6cbd11cecd27e6167c80cc0257573326530e388")
addappid(312635, 1, "223847191362b83838120796d64dc0476c4c037d304368907d9cc8a14723db8f")
addappid(312636, 1, "863508f95fbfc571cc4f98da500627a9cfa8a9c55fc3fbe5eade7866fb3424b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
