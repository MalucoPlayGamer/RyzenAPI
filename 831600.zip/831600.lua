-- Lua provided by RyzenAPI
-- Game: AppID 831600

-- MAIN APPLICATION
addappid(831600)

-- MAIN APP DEPOTS / PACKAGES
addappid(831601, 1, "06b024a7286fad3c47db25644f95d0796cbd61e5cb97db09c42f39edb56351d4")

