-- Lua provided by RyzenAPI
-- Game: addappid(756360)

-- MAIN APPLICATION
addappid(756360)

-- MAIN APP DEPOTS / PACKAGES
addappid(756361, 1, "b664ffbad41e87068550d98f93521ea27a0d2c963fdfc31572400a7461c384c6")
