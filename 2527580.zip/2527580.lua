-- Lua provided by RyzenAPI
-- Game: Teenage Mutant Ninja Turtles Arcade: Wrath of the Mutants

-- MAIN APPLICATION
addappid(2527580)
-- Game: addappid(2527580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2527581, 1, "9403833f48217fafbb748b5ea0129db38de6f221f4ad096f14786deb8d706456")
