-- Lua provided by RyzenAPI
-- Game: AppID 690850

-- MAIN APPLICATION
addappid(690850)
-- Game: addappid(690850)

-- MAIN APP DEPOTS / PACKAGES
addappid(690851, 1, "3ce2fea22bfba355f0cf6b862545683aec1d84480f9c75e2ac2f5590c83ed7d3")
