-- Lua provided by RyzenAPI
-- Game: Medieval Battlefields

-- MAIN APPLICATION
addappid(459040)

-- MAIN APP DEPOTS / PACKAGES
addappid(459043,0,"124aeac6205b2d40cce8797b69a141ce7830c4f45c57eef5d1868dbf8456b58a")
