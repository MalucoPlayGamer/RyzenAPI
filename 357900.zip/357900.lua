-- Lua provided by RyzenAPI
-- Game: Game: Make it indie!

-- MAIN APPLICATION
addappid(357900)
-- Game: addappid(357900)

-- MAIN APP DEPOTS / PACKAGES
addappid(357901, 1, "13230130f9c547274e94a322d96cf18fc095c676bd3ff1390baa64c9c54773db")
addappid(357902, 1, "87f5592f027571dd81680866637b912e3e1f0d81e8a2d5eceb3b143af05b8b35")
addappid(357903, 1, "d590af52402c12e5e005f32a9e2387cb2ad0012f9aba1cb1f9358f45206bc84e")
