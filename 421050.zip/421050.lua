-- Lua provided by RyzenAPI
-- Game: Deponia Doomsday

-- MAIN APPLICATION
addappid(421050)

-- MAIN APP DEPOTS / PACKAGES
addappid(421051, 1, "b550b3076c1e35339a45742ff70d41bd9e7d6141a6abb893dcd83031712cec63")
addappid(421052, 1, "d19e6041aebf0f6a102015321efa02acb9514a62aaa7a9c558bdd217bd772d27")
addappid(421053, 1, "7d2329c0370e41451fbc466181967b5782fbc40b2403e8affab17de9bb58bef7")
addappid(421054, 1, "88104538bace4b8d73bb8d22787a54a0312dec08c95deab1ebbc386cdd236ea6")
addappid(421055, 1, "8d7ee4eade45af880e2674e8d5b23565f31462bb85f9daea5c3d182349bc1b1a")
addappid(421056, 1, "1bc350c089c2a16f5962535ce99f709310022ff748c35122363dbeb9a4841c40")
addappid(421057, 1, "16c43121a02873c1da01a6cc7f9f30c3519b9a13648a76998c4e0be596a371bd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
