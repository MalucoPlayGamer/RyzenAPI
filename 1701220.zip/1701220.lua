-- Lua provided by RyzenAPI
-- Game: Game: AppID 1701220

-- MAIN APPLICATION
addappid(1701220)
-- Game: addappid(1701220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701221, 1, "437e9a92eed7ad55d3adf93f1dbd2f25b262e9e409b18ace216ef0307df715a1")
