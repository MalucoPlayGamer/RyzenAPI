-- Lua provided by RyzenAPI 
-- Game: Steel Rampart
addappid(2380620)
addappid(2380621, 1, "136e6491aa3a8aa85a30248c8a1edad41f4ad172bef3e95907b70e9491216bf3")
