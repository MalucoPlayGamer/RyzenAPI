-- Lua provided by RyzenAPI
-- Game: Game: Steel Rampart

-- MAIN APPLICATION
addappid(2380620)
-- Game: addappid(2380620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2380621, 1, "136e6491aa3a8aa85a30248c8a1edad41f4ad172bef3e95907b70e9491216bf3")
