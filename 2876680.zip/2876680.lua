-- Lua provided by RyzenAPI
-- Game: Game: Fluxed

-- MAIN APPLICATION
addappid(2876680)
-- Game: addappid(2876680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2876681, 1, "b381ab57555eb78dfda730d1a54feba8ea554dacb1e70c17efc8e5377a477298")
