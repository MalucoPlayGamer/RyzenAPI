-- Lua provided by RyzenAPI
-- Game: AppGameKit Classic: Easy Game Development

-- MAIN APPLICATION
addappid(325180)
addappid(345720)
addappid(410530)
addappid(410531)
addappid(411010)
addappid(468510)
addappid(473430)
addappid(491780)
addappid(496900)
addappid(602720)
addappid(623100)
addappid(623270)
addappid(650840)
addappid(710830)
addappid(744150)
addappid(802000)
addappid(2123750)

-- MAIN APP DEPOTS / PACKAGES
addappid(325181, 1, "6c0edbd8d7a8ad48841e8f80ef03786b676e1264faafb0b92c710f617f9ff960")
addappid(325182, 1, "40436563225e9602f7a54d97f71b65f0c695dbfa54c170b1c2b81743e872cecc")
addappid(325183, 1, "1af060e6c3b618e5f7efb096b1a66cc50809e8710eea9cc3600d142c2c4d23a6")

