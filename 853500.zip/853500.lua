-- Lua provided by RyzenAPI
-- Game: Quarantine Circular

-- MAIN APPLICATION
addappid(853500)

-- MAIN APP DEPOTS / PACKAGES
addappid(853501, 1, "3045e72941c3f84414ad32040037c3b61c330d6e4c64bc6ae41532c347f6b941")
