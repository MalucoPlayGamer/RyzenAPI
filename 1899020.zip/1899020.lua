-- Lua provided by SkyAPI 
-- Game: Jerez's Arena Ⅱ -Original Sountrack-
addappid(1899020)
addappid(1899021, 1, "f1d1c5c844c7726d583eddb3d686e64b93d07767db5ae1691a0b8377e6e6f9aa")
addappid(1899022, 1, "49be47d2bb792734beb9b40a0fe84ad13ddf42a004ce96c11bdd924ab1f3afa5")
