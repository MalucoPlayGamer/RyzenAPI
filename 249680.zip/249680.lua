-- Lua provided by RyzenAPI
-- Game: AppID 249680

-- MAIN APPLICATION
addappid(249680)

-- MAIN APP DEPOTS / PACKAGES
addappid(249681, 1, "ad3582be68fbdb988296cea08a9560a10d49dc1976cace5a02cdcc444d215aeb")
