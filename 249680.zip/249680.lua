-- Lua provided by RyzenAPI
-- Game: AppID 249680

-- MAIN APPLICATION
addappid(249680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(249681, 1, "ad3582be68fbdb988296cea08a9560a10d49dc1976cace5a02cdcc444d215aeb")

