-- Lua provided by RyzenAPI
-- Game: Shaped Beats

-- MAIN APPLICATION
addappid(1783180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1783181, 1, "2beab4f5a5892c20d66fd602a33a3765c923a6f01b082452161a5c2b027867aa")
