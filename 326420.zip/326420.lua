-- Lua provided by RyzenAPI
-- Game: Sam Glyph: Private Eye!

-- MAIN APPLICATION
addappid(326420)

-- MAIN APP DEPOTS / PACKAGES
addappid(326421, 1, "ed43ecf4443be67744027809eb09a71024b5ed8a98737b7bd6140e5dde2498d8")
