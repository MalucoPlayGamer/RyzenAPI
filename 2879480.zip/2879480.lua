-- Lua provided by RyzenAPI
-- Game: addappid(2879480)

-- MAIN APPLICATION
addappid(2879480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2879481, 1, "ee0c645c4d94d152546cdc307d49a146a4841981d60ef8ed09cd63f8802adb59")
