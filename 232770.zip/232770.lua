-- Lua provided by SkyAPI 
-- Game: POSTAL
addappid(232770)
addappid(232771, 1, "0b3f5b747a013904638183986855f8b765d1b10511e01b47ab925bfde5e8e53f")
addappid(232772, 1, "b5903d85c4944c3fabf3e8dde5605f844dd40e486ef7e470469b8aed1e70ded2")
addappid(232773, 1, "45dc820b369b0449f1be5fe2eae2ba13e602422a26d9f2809a0c0dea00000ebb")
