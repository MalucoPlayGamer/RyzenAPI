-- Lua provided by SkyAPI 
-- Game: AppID 3714790
addappid(3714790)
addappid(3714791, 1, "c94f48c59024ca40c5626894e894fd4d336f5f7a10267f1a47c921bbae248b57")
