-- Lua provided by RyzenAPI
-- Game: addappid(3714790)

-- MAIN APPLICATION
addappid(3714790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3714791, 1, "c94f48c59024ca40c5626894e894fd4d336f5f7a10267f1a47c921bbae248b57")
