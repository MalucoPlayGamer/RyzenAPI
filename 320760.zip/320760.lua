-- Lua provided by RyzenAPI
-- Game: Tokyo School Life

-- MAIN APPLICATION
addappid(320760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(320761, 1, "e61ac7091046ffbc9b8c4e3f1d76cc8cf7009b7ba4fa7435b555eedbe4bd928c")
addappid(374880, 0, "014160b4a19a0ef252e625189b479353bc963361aa559bb2a74ca85d16c2052e")

