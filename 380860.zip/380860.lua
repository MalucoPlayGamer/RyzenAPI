-- Lua provided by SkyAPI 
-- Game: AppID 380860
addappid(380860)
addappid(380861, 1, "ede974d78f98e7f677822f98eefa850b9b570eb1479cd54a869473101277a77d")
addappid(380862, 1, "ac5f8a1c15aacfc4816c1298544359c93a2b39bde3495f032ef2a234d232e7a8")
