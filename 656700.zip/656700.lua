-- Lua provided by RyzenAPI
-- Game: addappid(656700)

-- MAIN APPLICATION
addappid(656700)

-- MAIN APP DEPOTS / PACKAGES
addappid(656701, 1, "d841c9f49a847c80bb5a8ed861812525fcd05d78d838e331ceda44011b9cd980")
addappid(1177830, 0, "1f07f63d2de641faa3bf6cc2d51ab3c8fdf2948077fe85785cd365c2db6e1944")
