-- Lua provided by RyzenAPI
-- Game: Sportsfriends

-- MAIN APPLICATION
addappid(277850)

-- MAIN APP DEPOTS / PACKAGES
addappid(277851, 1, "ac590f1ada9f958b298af817789dd63f25d648296c94e4aebac6a8812f53c417")
addappid(277852, 1, "652af8013ee97b7754bb63c2329f84b7263d2651216dd7615ff1dffdec21c1f9")
addappid(277853, 1, "491894c027dd9b99dd800d924c2953769929a0c40da197001e360431cf56b854")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
