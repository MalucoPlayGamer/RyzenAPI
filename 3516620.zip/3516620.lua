-- Lua provided by RyzenAPI
-- Game: Game: MAGICAL BEAT

-- MAIN APPLICATION
addappid(3516620)
-- Game: addappid(3516620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3516621, 1, "fb6691d0b58f62cc11ac75fb533eb5d072742572b9391ca2866a8c48c0095855")
