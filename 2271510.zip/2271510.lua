-- Lua provided by RyzenAPI
-- Game: 2271510

-- MAIN APPLICATION
addappid(2271510)
-- Game: addappid(2271510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2271510,0,"75c27fe22b3c83b54f9a58b0309b30e61d6cc7bbcceec5733c297628bac248d2")
