-- Lua provided by RyzenAPI
-- Game: Baby Storm

-- MAIN APPLICATION
addappid(2176400)
-- Game: addappid(2176400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2176401, 1, "0b2380415c2002ca913d9b215dbe62d55bd9704b9022b980ca9b4a951bcdfa7c")
