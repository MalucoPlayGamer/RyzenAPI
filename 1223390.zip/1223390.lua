-- Lua provided by RyzenAPI
-- Game: A Player's Heart

-- MAIN APPLICATION
addappid(1223390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223391, 1, "5337f8adcf1461c4337ac5203edb42c9e4c0682f42aa21a7f1d6d2b098863643")
