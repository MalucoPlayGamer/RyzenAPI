-- Lua provided by RyzenAPI
-- Game: Mesozoic Dawn

-- MAIN APPLICATION
addappid(4334840)
