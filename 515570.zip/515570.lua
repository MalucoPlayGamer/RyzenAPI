-- Lua provided by RyzenAPI
-- Game: Game: AppID 515570

-- MAIN APPLICATION
addappid(515570)
-- Game: addappid(515570)

-- MAIN APP DEPOTS / PACKAGES
addappid(515571, 1, "4ec85cb7bc19fc9f0f9dad9078e19e566dac44613d509da6a86d31f46a79a4df")
addappid(515572, 1, "1d34d9f1469b757d35bf357a37887b080a353afe153dbf7c4c1c1db01e2b4e55")
