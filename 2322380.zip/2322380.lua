-- Lua provided by SkyAPI 
-- Game: SpongeBob SquarePants™: The Patrick Star Game
addappid(2322380)
addappid(2322381, 1, "9efe8fb3f3b218efa48040eccf7d8318e888c265da84563cbb343ce6c34b4fd9")
