-- Lua provided by RyzenAPI
-- Game: Old Roots

-- MAIN APPLICATION
addappid(2004730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2004732,0,"92a5f639616ddb708542067d02cadee7b7a2d4bfcbee9bb554c0b5f602463d2b")
