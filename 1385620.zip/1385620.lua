-- Lua provided by SkyAPI 
-- Game: Model Sisters
addappid(1385620)
addappid(1385621, 1, "57a3203b403d6076e5f0ab480293ccc0a709e540f72f1d7c19791cb5bfa79c58")
