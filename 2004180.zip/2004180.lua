-- Lua provided by RyzenAPI
-- Game: DAGURI: Gambling Apocalypse

-- MAIN APPLICATION
addappid(2004180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2004181, 1, "6d4b87845c1255576324cfd4f308b40bb9d839d6abc00431401a6b798cb53ae7")
