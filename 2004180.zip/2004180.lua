-- Lua provided by SkyAPI 
-- Game: AppID 2004180
addappid(2004180)
addappid(2004181, 1, "6d4b87845c1255576324cfd4f308b40bb9d839d6abc00431401a6b798cb53ae7")
