-- Lua provided by RyzenAPI
-- Game: AppID 294040

-- MAIN APPLICATION
addappid(294040)

-- MAIN APP DEPOTS / PACKAGES
addappid(294041, 1, "294aece83ee4502b1de296d4b34b412fe9796d89b425cfe9c707abfeb1cf5736")

