-- Lua provided by SkyAPI 
-- Game: AppID 294040
addappid(294040)
addappid(294041, 1, "294aece83ee4502b1de296d4b34b412fe9796d89b425cfe9c707abfeb1cf5736")
