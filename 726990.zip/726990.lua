-- Lua provided by RyzenAPI
-- Game: Succubus Rem

-- MAIN APPLICATION
addappid(726990)

-- MAIN APP DEPOTS / PACKAGES
addappid(726991, 1, "a3f13e4f4e7d76d1333e0dab815d09acf460b3dcd92ea04c9095aef708243df0")
addappid(726992, 1, "289f6159375f06c588ea15a5c2665ebf1ecdec6982e411f64362ed55ac48e426")
addappid(726993, 1, "c0428e842d70383beec86ea62101e8421ef929159a58e7f06e5aeb423c40d1f8")

