-- Lua provided by RyzenAPI
-- Game: 愛神餐館MAX

-- MAIN APPLICATION
addappid(1249980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1249981, 1, "fadde5fb899ae026a8f6f634849c66cfb0faff9495af5b4f2a0cd9463d900618")

