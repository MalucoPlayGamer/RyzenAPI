-- Lua provided by RyzenAPI
-- Game: 1249980

-- MAIN APPLICATION
addappid(1249980)
-- Game: addappid(1249980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1249981, 1, "fadde5fb899ae026a8f6f634849c66cfb0faff9495af5b4f2a0cd9463d900618")
