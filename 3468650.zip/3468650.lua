-- Lua provided by RyzenAPI
-- Game: Cricket 26 - The Official Game of the Ashes

-- MAIN APPLICATION
addappid(3468650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3468651, 1, "9c1e6d72e07e9b0e0e260a7cac56c505135405ba8acf982a10fa869049cca61d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
