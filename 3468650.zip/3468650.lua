-- Lua provided by RyzenAPI 
-- Game: Cricket 26 - The Official Game of the Ashes
addappid(3468650)
addappid(3468651, 1, "9c1e6d72e07e9b0e0e260a7cac56c505135405ba8acf982a10fa869049cca61d")
