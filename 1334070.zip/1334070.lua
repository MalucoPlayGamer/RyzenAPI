-- Lua provided by RyzenAPI
-- Game: Sleep

-- MAIN APPLICATION
addappid(1334070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334071, 1, "f1a8e56c41c049ee28f487543a1c22b75ea43191bf38d82665d0b5f9d65c3b7f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
