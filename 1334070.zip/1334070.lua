-- Lua provided by RyzenAPI
-- Game: Sleep

-- MAIN APPLICATION
addappid(1334070)
-- Game: addappid(1334070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334071, 1, "f1a8e56c41c049ee28f487543a1c22b75ea43191bf38d82665d0b5f9d65c3b7f")
