-- Lua provided by RyzenAPI
-- Game: 2259040

-- MAIN APPLICATION
addappid(2259040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259040,0,"d23bf85c2d6360990b438b6d1fd2c63b5d7c24cb01c1a120c8b7dd221dccfb46")
