-- Lua provided by RyzenAPI
-- Game: NOYO-!

-- MAIN APPLICATION
addappid(1093300)
-- Game: addappid(1093300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1093301, 1, "5690a3c5135610c821816cc1e3c45058b5caf5c297cd6cde39c1693b4fba60f3")
