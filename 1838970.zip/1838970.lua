-- Lua provided by RyzenAPI
-- Game: addappid(1838970)

-- MAIN APPLICATION
addappid(1838970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1838971, 1, "edb62a7a71389bec1d1501f8e16c9c0fa3b11c811e6940fcd905e5fc04b1119f")
