-- Lua provided by RyzenAPI
-- Game: Batallas Galacticas

-- MAIN APPLICATION
addappid(1345390)
-- Game: addappid(1345390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345391, 1, "a1ab171cedb54fae8be0b2c8f06b9f221598a3c84dd2a022af72372a6fe7820c")
