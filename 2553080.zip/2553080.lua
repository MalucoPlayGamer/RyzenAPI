-- Lua provided by RyzenAPI
-- Game: Beneath the Bleeding Moon

-- MAIN APPLICATION
addappid(2553080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2553081,0,"c61c3a74aca9a57ac7192e7b48fb9c786c77e1f5fa0798c3d879fee124b66738")

