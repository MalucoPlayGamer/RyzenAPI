-- Lua provided by RyzenAPI
-- Game: Game: AppID 1247140

-- MAIN APPLICATION
addappid(1247140)
-- Game: addappid(1247140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247141, 1, "e99459835ac42a72c5bc407fab1d177a84043f76d4cb4cd94897ba25bf2be18f")
addappid(1247142, 1, "6669573a70eec9f322a8d38a6deca195ed0fe61480bc3c29eb70631a59c0fb48")
