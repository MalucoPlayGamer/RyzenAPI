-- Lua provided by RyzenAPI
-- Game: addappid(459370)

-- MAIN APPLICATION
addappid(459370)

-- MAIN APP DEPOTS / PACKAGES
addappid(459371, 1, "727a87fc5430bea94dba21722eda5c5db81c1d596f8b55f970abba4cab61778d")
