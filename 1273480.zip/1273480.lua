-- Lua provided by RyzenAPI
-- Game: addappid(1273480)

-- MAIN APPLICATION
addappid(1273480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273481, 1, "00f9a620dab7ccfd76083e360e69f050b80c9eb4c2e9950f41af85680097c08c")
