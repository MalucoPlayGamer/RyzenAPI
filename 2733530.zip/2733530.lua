-- Lua provided by RyzenAPI
-- Game: addappid(2733530)

-- MAIN APPLICATION
addappid(2733530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2733531, 1, "1d344432dd091005e000084dde9b60c6722ddeebf3a25b3daca472340de728e5")
