-- Lua provided by RyzenAPI
-- Game: addappid(1912000)

-- MAIN APPLICATION
addappid(1912000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912001, 1, "1d73cce304fbce4e38a2f5141bcbd8f6d157627979289a7852027af3153b9343")
