-- Lua provided by RyzenAPI
-- Game: The Endless Journey

-- MAIN APPLICATION
addappid(715650)
addappid(1015860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(715651, 1, "6f14f38581a461ab957d7d82fcbc8d84896b7e1a853cdb05fc4ce65c82d54921")
addappid(715652, 1, "241958b17f30cc6b291dae5e58a56b5ec49549e1208c604a40bf85d7a6ada616")
addappid(715654, 1, "07c86dedc953ccdaf461ab8a96ec5a65cdd31f0ecbbb06fc8f15c5f7f285871b")
addappid(776570, 0, "d303fc95e8f310b0537d42287d910e1c4226514314b814351ff27fb3ed78b695")

