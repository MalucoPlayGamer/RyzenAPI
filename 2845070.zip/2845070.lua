-- Lua provided by RyzenAPI
-- Game: addappid(2845070)

-- MAIN APPLICATION
addappid(2845070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2845071, 1, "bbb57c675dcf4daaa0bc609a9371578cd5f884274689fe7dde5820e50f33bb3a")
