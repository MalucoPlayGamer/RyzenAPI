-- Lua provided by RyzenAPI
-- Game: Count Pumpcula

-- MAIN APPLICATION
addappid(1995930)
-- Game: addappid(1995930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995931, 1, "df776ad38464f9409634f4dda2f3af253a293c04bb5c4017fa2596a9f023eb52")
addappid(1995932, 1, "b71fea2e1d58e1260dcc1ea0f02afba2cb509c67a20d4e2b093335f7aa3d7ea2")
addappid(1995933, 1, "3889db90ddf882f290ae3e60566a218c2cc915295ea3932740ae999a531e5b5f")
