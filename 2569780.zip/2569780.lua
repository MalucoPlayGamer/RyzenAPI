-- Lua provided by RyzenAPI
-- Game: Tiki Tandems

-- MAIN APPLICATION
addappid(2569780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2569781, 1, "71086f5a2e57415673fe4a4f359c5375b0752c0b822307fd683b67e054830707")
