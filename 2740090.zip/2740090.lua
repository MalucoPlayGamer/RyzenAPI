-- Lua provided by RyzenAPI
-- Game: Oil Strike '75

-- MAIN APPLICATION
addappid(2740090)
addappid(4080770)
addappid(4080780)
addappid(4081030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

