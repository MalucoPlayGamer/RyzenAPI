-- Lua provided by RyzenAPI
-- Game: Oil Strike '75

-- MAIN APPLICATION
addappid(2740090)

