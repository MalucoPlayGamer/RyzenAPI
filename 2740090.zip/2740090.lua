-- Lua provided by RyzenAPI
-- Game: Oil Strike '75

-- MAIN APPLICATION
addappid(2740090)



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4080770)
addappid(4080780)
addappid(4081030)
