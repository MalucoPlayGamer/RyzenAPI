-- Lua provided by RyzenAPI
-- Game: 1707890

-- MAIN APPLICATION
addappid(1707890)
-- Game: addappid(1707890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707891, 1, "6e8525b842dfefae1a520b3e4de77cee1e364e9d2ac77ed375350e87b60bbafe")
