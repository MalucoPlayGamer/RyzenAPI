-- Lua provided by SkyAPI 
-- Game: Bacteria Wars
addappid(1707890)
addappid(1707891, 1, "6e8525b842dfefae1a520b3e4de77cee1e364e9d2ac77ed375350e87b60bbafe")
