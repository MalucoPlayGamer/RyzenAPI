-- Lua provided by RyzenAPI
-- Game: Game: AppID 1027230

-- MAIN APPLICATION
addappid(1027230)
-- Game: addappid(1027230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1027231, 1, "9b6c68ff2c687fed89b163c331e727641e3082b1038bd2212a716d42d417d323")
