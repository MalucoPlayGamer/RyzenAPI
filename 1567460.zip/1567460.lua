-- Lua provided by RyzenAPI 
-- Game: AppID 1567460
addappid(1567460)
addappid(1567461, 1, "6d134fbb3119447164b490c04f85b2a6b75fce2917a7e5cd0fc90a0d156c866e")
