-- Lua provided by RyzenAPI
-- Game: Sir Christopher

-- MAIN APPLICATION
addappid(1567460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567461, 1, "6d134fbb3119447164b490c04f85b2a6b75fce2917a7e5cd0fc90a0d156c866e")

