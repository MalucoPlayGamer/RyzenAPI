-- Lua provided by RyzenAPI
-- Game: blackhole simulator

-- MAIN APPLICATION
addappid(3502300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3502301, 1, "1649bacf75c59d44e9736c903db557519564e4953566143fe770aa315a7614e5")
