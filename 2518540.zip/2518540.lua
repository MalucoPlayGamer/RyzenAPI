-- Lua provided by RyzenAPI
-- Game: 可可味大冒险

-- MAIN APPLICATION
addappid(2518540)
-- Game: addappid(2518540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2518541, 1, "e4aa4921bf42f4be854eb1946ed79cc5d1fd851a9297dbfe435689268a803252")
