-- Lua provided by RyzenAPI
-- Game: AppID 1620720

-- MAIN APPLICATION
addappid(1620720)
-- Game: addappid(1620720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620721, 1, "d052096ad75216c93e1f3c20597e5da834dfacf02b381608e9e31b5009ac3d2f")
