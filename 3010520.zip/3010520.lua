-- Lua provided by RyzenAPI
-- Game: Pub Sim

-- MAIN APPLICATION
addappid(3010520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3010521, 1, "877cf606b46e20683d68b3e173bb538fd5711121346035a798c28478abfeffcd")
