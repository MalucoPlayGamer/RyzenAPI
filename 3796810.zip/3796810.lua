-- Lua provided by RyzenAPI
-- Game: Nightingale Dedicated Server

-- MAIN APPLICATION
addappid(3796810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2834901,0,"19017e82480e010d2b1bd4df327956ac12921ff4f73ffac6005d34f77899581b")

