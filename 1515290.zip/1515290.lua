-- Lua provided by RyzenAPI
-- Game: AppID 1515290

-- MAIN APPLICATION
addappid(1515290)
-- Game: addappid(1515290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515291, 1, "0622299db1e3f74ca4e632cbd0bb002538aca4b306a448175700b3a15179ed9a")
addappid(1515292, 1, "cd2e2f48ed6d94f7e6bde970fa53f461eea6b85ab40e4d64fb1c3c42a4919856")
addappid(1515293, 1, "8e1c8a42e5b07af859bc2fbf3247d4dbd40cafab21d3ec11da31943e2b4b0f25")
