-- Lua provided by RyzenAPI
-- Game: AppID 1047160

-- MAIN APPLICATION
addappid(1047160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1047161, 1, "c68275b7e12a02b4c638f3a8585b09251177ee6709c2dbe00139eaefb8d1da1b")
addappid(1057260, 0, "603b862b3040250d21da550815bd3109228b54a75f14d2ed8ce425250e6f3d42")
addappid(1057261, 0, "b685ab386d6903725b7400ea71785d6adcd0a6ec20758e53931e483390fc7db1")
addappid(1057262, 0, "c5e75f732e069f465cc108970d36dd8475547ae5f6845ade501177e7edf9c32b")
addappid(1057263, 0, "1c6575978db2b1f96fc29d24b0d636a524e936b38a37dd7c59a04c9a71435239")
addappid(1057264, 0, "7a0d4c10a4422187e6287568d6987e9064f37c6602d7d4b7a0cc2c7ce5ef7490")
addappid(1057265, 0, "75b3bb52931e24d521a351def6608f8d12879d0d9ad69a924ae8cb9140fda6df")
addappid(1106020, 0, "f50f14f9dce21819169af7fc453ecffb7f9b6c61e462f310e57a56c7f9e93212")
addappid(1106021, 0, "06c9835dd8ebdaea5f2d1f114d3e2668e3961771c05b829f0f965258aaa5de24")
addappid(1106022, 0, "9f61cafb33a84ca67c3a4431d130c8f86fba4dd80b05e9375df8f39d07f4e99d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1106023)
addappid(3347160)
addappid(3860160)
addappid(3860170)
addappid(4248950)
