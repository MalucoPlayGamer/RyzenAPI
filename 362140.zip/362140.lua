-- Lua provided by RyzenAPI
-- Game: 362140

-- MAIN APPLICATION
addappid(362140)
-- Game: addappid(362140)

-- MAIN APP DEPOTS / PACKAGES
addappid(362141, 1, "2056086461cbd134c68b7e7c83c38e0ffab30ca68efbe52cb799ede1da4c19c5")
