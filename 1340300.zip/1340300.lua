-- Lua provided by RyzenAPI
-- Game: Crazy Kung Fu

-- MAIN APPLICATION
addappid(1340300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340301, 1, "1e5f55cbb8018ebb3e6dcf05c7d12592dfe09975832816b8b0bd5c157d4e7f47")
