-- Lua provided by SkyAPI 
-- Game: City Tales - Medieval Era
addappid(3265070)
addappid(3265071, 1, "99837f4a232e18331a37fd5d351812a874dfeee77bb0daadd001ff23cd431d06")
addappid(3645240, 0, "dab48827dcd4099a7709d7069180aeed4de70b2d8fa4b7418f51cf28b48e0aef")
