-- Lua provided by RyzenAPI
-- Game: City Tales - Medieval Era

-- MAIN APPLICATION
addappid(3265070)
-- Game: addappid(3265070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3265071, 1, "99837f4a232e18331a37fd5d351812a874dfeee77bb0daadd001ff23cd431d06")
addappid(3645240, 0, "dab48827dcd4099a7709d7069180aeed4de70b2d8fa4b7418f51cf28b48e0aef")
