-- Lua provided by RyzenAPI
-- Game: Pew Dew Redemption

-- MAIN APPLICATION
addappid(1063770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1063771, 1, "aee7d93f22e982483c7039575ac2052815d094dce91493259a09888a14c98d8c")

