-- Lua provided by RyzenAPI
-- Game: addappid(3163520)

-- MAIN APPLICATION
addappid(3163520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3163521, 1, "8ba267de6dc443754f76d154abc1a41261b2ce90b2a3fe4cf53d1f0d18d2856f")
