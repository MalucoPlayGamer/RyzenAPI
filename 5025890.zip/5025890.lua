-- Lua provided by RyzenAPI
-- Game: A Mystic Journey With Solara

-- MAIN APPLICATION
addappid(5025890) -- A Mystic Journey With Solara

-- MAIN APP DEPOTS / PACKAGES
addappid(5025891, 1, "fb3e1884e85af6019fab6eec5b80ef2cebf112df6d06e072e3dc9bc41d570c8d") -- Depot 5025891

