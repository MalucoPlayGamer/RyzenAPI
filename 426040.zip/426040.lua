-- Lua provided by RyzenAPI
-- Game: Goodnight Butcher

-- MAIN APPLICATION
addappid(426040)

-- MAIN APP DEPOTS / PACKAGES
addappid(426041, 1, "b0c7c2224c761a31fef5d6d2c81a9682ad0626f7f1a0ea5136543339dfcdb395")

