-- Lua provided by RyzenAPI
-- Game: 928960

-- MAIN APPLICATION
addappid(928960)
-- Game: addappid(928960)

-- MAIN APP DEPOTS / PACKAGES
addappid(928961, 1, "52c5db3fe7a6259c90c21abe8005fd39d327085dbdaeda78579d084d143a0cb7")
