-- Lua provided by SkyAPI 
-- Game: Godfall Ultimate Edition
addappid(928960)
addappid(928961, 1, "52c5db3fe7a6259c90c21abe8005fd39d327085dbdaeda78579d084d143a0cb7")
