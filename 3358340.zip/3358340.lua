-- 3358340's Lua and Manifest Created by Hubcap Manifest
-- Witchblood
-- Created: August 14, 2026 at 00:45:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3358340) -- Witchblood
-- MAIN APP DEPOTS
addappid(3358342, 1, "56903198a569538266308b60028d2659db0f7eadfc029fe36d8d30a816f6916d") -- Depot 3358342
setManifestid(3358342, "598650188271653038", 16193439635)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)