-- Lua provided by RyzenAPI
-- Game: Game: Gob

-- MAIN APPLICATION
addappid(1300680)
-- Game: addappid(1300680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1300681, 1, "58584c8eb223090b610e98ac4e4f461ef54346455d3f7d819d5643b15477ed8e")
