-- Lua provided by RyzenAPI 
-- Game: Gob
addappid(1300680)
addappid(1300681, 1, "58584c8eb223090b610e98ac4e4f461ef54346455d3f7d819d5643b15477ed8e")
