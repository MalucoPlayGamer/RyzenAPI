-- Lua provided by RyzenAPI
-- Game: addappid(2281200)

-- MAIN APPLICATION
addappid(2281200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2281201, 1, "3171a1f4263f08da0d127605a0f5fcb84790828fad6c0e32bb6ac347b7772edf")
