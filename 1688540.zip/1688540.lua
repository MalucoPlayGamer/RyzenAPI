-- Lua provided by RyzenAPI
-- Game: addappid(1688540)

-- MAIN APPLICATION
addappid(1688540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1688540,0,"59f1fea6b227caccbdbbe138c48d0c2b169772f94a35ddb13140c73b1bcfe98a")
