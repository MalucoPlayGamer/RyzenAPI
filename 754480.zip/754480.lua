-- Lua provided by SkyAPI 
-- Game: Dummy!
addappid(754480)
addappid(754481, 1, "182fe78095292b5d770423a824806e615a340cb8d2af8228872392f7358df946")
