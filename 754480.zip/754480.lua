-- Lua provided by RyzenAPI
-- Game: Game: Dummy!

-- MAIN APPLICATION
addappid(754480)
-- Game: addappid(754480)

-- MAIN APP DEPOTS / PACKAGES
addappid(754481, 1, "182fe78095292b5d770423a824806e615a340cb8d2af8228872392f7358df946")
