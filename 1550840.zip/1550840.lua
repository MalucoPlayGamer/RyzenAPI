-- Lua provided by RyzenAPI
-- Game: 1550840

-- MAIN APPLICATION
addappid(1550840)
-- Game: addappid(1550840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1550841, 1, "a339bcae53dbba335fe103b04bc5675167508b6ba52d5a27cd6b75e6aea5f395")
