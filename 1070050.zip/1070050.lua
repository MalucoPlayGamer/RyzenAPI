-- Lua provided by RyzenAPI
-- Game: Crystar - Mirai’s Clothes

-- MAIN APPLICATION
addappid(1070050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070050,0,"4df8975922ef123efe5d6d99eb6fcb79ccf3104d44d225fe6438f7699410f39c")

