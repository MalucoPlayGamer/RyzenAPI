-- Lua provided by RyzenAPI
-- Game: Game: Swords of Edo Kinetic Novel

-- MAIN APPLICATION
addappid(1320260)
-- Game: addappid(1320260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1320261, 1, "9b974eb3309d06c8ab9503dcf09583c8bfc4b9722266ee6f918e29d4764c5cd3")
