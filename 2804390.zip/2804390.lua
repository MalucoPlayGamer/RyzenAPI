-- Lua provided by RyzenAPI
-- Game: Game: AppID 2804390

-- MAIN APPLICATION
addappid(2804390)
-- Game: addappid(2804390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804391, 1, "43b2aefb799398a95e68726278e3c44bd2568ffdfd3c396cc2e79d5639a81883")
