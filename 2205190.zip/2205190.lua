-- Lua provided by RyzenAPI
-- Game: Clown Of Duty

-- MAIN APPLICATION
addappid(2205190)
-- Game: addappid(2205190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2205191, 1, "9042fb3912e4ea3639fb1504818d2108c6a68d1a67b88f16e5835cd85852880d")
