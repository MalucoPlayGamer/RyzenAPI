-- Lua provided by SkyAPI 
-- Game: Clown Of Duty
addappid(2205190)
addappid(2205191, 1, "9042fb3912e4ea3639fb1504818d2108c6a68d1a67b88f16e5835cd85852880d")
