-- Lua provided by RyzenAPI
-- Game: Mini Motorways

-- MAIN APPLICATION
addappid(1127500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127501, 1, "c1b7fefed0a17bebcfa13ab61bafc384337f754070c6416f49f01aed46681347")
addappid(1127502, 1, "f07e3a41d1d1604a0f30e31b8af4d25bb59a61e0938696f75b2a774502c19e4f")
