-- Lua provided by SkyAPI 
-- Game: Call of Cthulhu: Shadow of the Comet
addappid(389470)
addappid(389471, 1, "787f9f21599710d4235b92942abca05a2b62309bab4d068b743d1ce62e95bdf7")
