-- Lua provided by RyzenAPI
-- Game: 389470

-- MAIN APPLICATION
addappid(389470)
-- Game: addappid(389470)

-- MAIN APP DEPOTS / PACKAGES
addappid(389471, 1, "787f9f21599710d4235b92942abca05a2b62309bab4d068b743d1ce62e95bdf7")
