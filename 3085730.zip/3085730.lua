-- Lua provided by RyzenAPI
-- Game: Bulletrooms - Backrooms Shooter Game

-- MAIN APPLICATION
addappid(3085730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3085731, 1, "a2df9a2d4ba66762557ab66f963bf55053b2565df8c7a67e01a17b5405f2f687")

