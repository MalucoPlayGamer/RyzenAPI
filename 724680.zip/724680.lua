-- Lua provided by SkyAPI 
-- Game: AppID 724680
addappid(724680)
addappid(724681, 1, "89913c4bdf54a558de5b568e164f9bbcecf71a673093c4432ab6d47dd6458cb9")
