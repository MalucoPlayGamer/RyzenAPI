-- Lua provided by RyzenAPI
-- Game: addappid(724680)

-- MAIN APPLICATION
addappid(724680)

-- MAIN APP DEPOTS / PACKAGES
addappid(724681, 1, "89913c4bdf54a558de5b568e164f9bbcecf71a673093c4432ab6d47dd6458cb9")
