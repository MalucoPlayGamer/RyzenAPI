-- Lua provided by RyzenAPI
-- Game: 3223360

-- MAIN APPLICATION
addappid(3223360)
-- Game: addappid(3223360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3223361, 1, "dbf7ca316ceade7c30618c5f580889da3de7c8130866751b4758fc0ca7812f5b")
