-- Lua provided by SkyAPI 
-- Game: Split Brain Demo
addappid(3223360)
addappid(3223361, 1, "dbf7ca316ceade7c30618c5f580889da3de7c8130866751b4758fc0ca7812f5b")
