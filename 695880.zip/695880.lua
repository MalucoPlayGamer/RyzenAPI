-- Lua provided by RyzenAPI
-- Game: Game: AppID 695880

-- MAIN APPLICATION
addappid(695880)
-- Game: addappid(695880)

-- MAIN APP DEPOTS / PACKAGES
addappid(695881, 1, "414cfc681827331764b3a982cdae1ef0828725a1c70494e292e075329a7894ce")
