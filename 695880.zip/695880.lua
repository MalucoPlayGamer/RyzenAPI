-- Lua provided by RyzenAPI
-- Game: The Flying Turtle Jewel Quest

-- MAIN APPLICATION
addappid(695880)

-- MAIN APP DEPOTS / PACKAGES
addappid(695881, 1, "414cfc681827331764b3a982cdae1ef0828725a1c70494e292e075329a7894ce")
