-- Lua provided by RyzenAPI
-- Game: GUNFIELD

-- MAIN APPLICATION
addappid(2305900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2305901, 1, "42d049270e3ebae28f1391b05aab389cedb0d63916edfa8b0a6e43dee14694bf")
