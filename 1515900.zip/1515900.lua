-- Lua provided by RyzenAPI
-- Game: Heaven Dust 2

-- MAIN APPLICATION
addappid(1515900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515901, 1, "3d807e205a7ae7a2c70eeb7fe919c52f17c54a5d642efc4269db0b837bc211d0")

