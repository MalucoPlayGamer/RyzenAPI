-- Lua provided by RyzenAPI
-- Game: Asgard's Fall — Viking Survivors

-- MAIN APPLICATION
addappid(2780710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780711, 1, "ce8573abf7cb9dce3fadc20eb458cf15fc247b3fa958b24e26e337400ccb096b")

