-- Lua provided by RyzenAPI
-- Game: Gordon Streaman

-- MAIN APPLICATION
addappid(1131810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131811, 1, "4c640c3be375327f08b45c53ab52a87de5e90e763675e5cbadc6cfb2540b8546")

