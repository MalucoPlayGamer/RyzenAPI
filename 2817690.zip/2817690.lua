-- Lua provided by RyzenAPI
-- Game: 天呐！找不到真爱就扑街！

-- MAIN APPLICATION
addappid(2817690)
-- Game: addappid(2817690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817691, 1, "7184109bfa0c73fba6465215de484b3c681300a6383f1fe10a6652457df06e30")
