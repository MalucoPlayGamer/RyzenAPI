-- Lua provided by RyzenAPI
-- Game: 天呐！找不到真爱就扑街！

-- MAIN APPLICATION
addappid(2817690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2817691, 1, "7184109bfa0c73fba6465215de484b3c681300a6383f1fe10a6652457df06e30")

