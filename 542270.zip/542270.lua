-- Lua provided by RyzenAPI
-- Game: Project Alpha 002

-- MAIN APPLICATION
addappid(542270)

-- MAIN APP DEPOTS / PACKAGES
addappid(542271,0,"118c45491d9803e86fbda7c1d6f5578930a3e916cd9a4dd0964adf0b415a1a9c")

