-- Lua provided by RyzenAPI
-- Game: Hero Survival

-- MAIN APPLICATION
addappid(2247620)
-- Game: addappid(2247620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247622,0,"b9994587a9567828026667122357556ca4a1fd2c406712fc96a0f3f2ce7eb843")
