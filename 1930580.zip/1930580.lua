-- Lua provided by RyzenAPI
-- Game: Devil's 5 Days Mischief Game

-- MAIN APPLICATION
addappid(1930580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1930581, 1, "fb0588400b733d34ea0cd9d11d60d0922d0e6a8b80d3ffef6c826701a811253a")
addappid(1930582, 1, "9cd1f3f053bb0c2b0e9ffd64369fe114d0269d3884c4ac197f1c5a4e0ee61d5d")
addappid(1930584, 1, "8e6ba058f0bd620e4302c681c03946eb14fe0c388b6b61ef9680affc3122808d")
