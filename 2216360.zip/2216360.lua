-- Lua provided by RyzenAPI
-- Game: Game: Disaster Band

-- MAIN APPLICATION
addappid(2216360)
-- Game: addappid(2216360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216361, 1, "23a25c3c3df61a098c9013088bcb3a550395f1359b791465ea09669054dc7c18")
