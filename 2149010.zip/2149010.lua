-- Lua provided by RyzenAPI 
-- Game: Little Nightmares Enhanced Edition
addappid(2149010)
addappid(2149011, 1, "05e1f184ed87ed48da9f886fc92f683a735242e8265dc6ff8a289deaeddc7ba2")
