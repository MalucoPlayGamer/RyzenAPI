-- Lua provided by RyzenAPI
-- Game: Little Nightmares Enhanced Edition

-- MAIN APPLICATION
addappid(2149010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2149011, 1, "05e1f184ed87ed48da9f886fc92f683a735242e8265dc6ff8a289deaeddc7ba2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2187770)
addappid(2187780)
addappid(2187800)
