-- Lua provided by RyzenAPI
-- Game: 女神之战

-- MAIN APPLICATION
addappid(2819120)
addappid(3068350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2819121, 1, "387799990af83efe3dd88df1ed2f249e1c6b171277f1b52d2685026aec755170")
