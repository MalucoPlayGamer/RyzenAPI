-- Lua provided by RyzenAPI
-- Game: Little Miss Lonely

-- MAIN APPLICATION
addappid(651820)

-- MAIN APP DEPOTS / PACKAGES
addappid(651821,0,"fc31d9ee2d7c04e3f173eadd71a526836f8b8c9fd8972d0291579c152744e7ba")

