-- Lua provided by RyzenAPI
-- Game: Game: Storyteller - Original Soundtrack

-- MAIN APPLICATION
addappid(2362450)
-- Game: addappid(2362450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362451, 1, "574d5a8c36d8c7ac8f3d5f359aa689f9f9f54395b5a4996d6684b0a63871d492")
addappid(2362452, 1, "e0415ff38cd281e00f628177295b34f0ccd3f17902bafee4645d9b9904dda085")
