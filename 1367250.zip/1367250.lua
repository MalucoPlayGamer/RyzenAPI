-- Lua provided by RyzenAPI
-- Game: Game: Arabel

-- MAIN APPLICATION
addappid(1367250)
-- Game: addappid(1367250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367251, 1, "3d1eaf1fc9e4f24f289f7ae5e9cd4e47ad5bad38a1e08ce9fe2024c680837850")
