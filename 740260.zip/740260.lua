-- Lua provided by RyzenAPI
-- Game: Crimson Imprint plus -Nonexistent Christmas-

-- MAIN APPLICATION
addappid(740260)

-- MAIN APP DEPOTS / PACKAGES
addappid(740261, 1, "17bc450383c9428e44c6947617794723bcb0ddda76e053f4c2af7d170e4f4fb6")
addappid(769090, 0, "bd00fdbefc39e68d76feba4ae15ea2d6fa935901b8a75cc8bf22dbcea4dd94b4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
