-- Lua provided by RyzenAPI 
-- Game: AppID 756050
addappid(756050)
addappid(756051, 1, "1017813c7959fc0bd8e8de5514463dd90d91749adfc0b5643044b5d3196e8d4c")
