-- Lua provided by RyzenAPI
-- Game: Beat Saber - Queen - One Vision

-- MAIN APPLICATION
addappid(2407766)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407766,0,"63b4cfc67d86f3b0ba4ae2615151a913cdf55388b50be817080c46aec49571a3")
