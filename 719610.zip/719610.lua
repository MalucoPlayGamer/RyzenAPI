-- Lua provided by RyzenAPI
-- Game: Free Bowling 3D

-- MAIN APPLICATION
addappid(719610)

-- MAIN APP DEPOTS / PACKAGES
addappid(719611, 1, "add7848cb4b472afa5e6701d556f762b177da9bbbec1f065fcba49b367e60d66")
