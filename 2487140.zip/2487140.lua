-- Lua provided by RyzenAPI
-- Game: Exorcist Simulator

-- MAIN APPLICATION
addappid(2487140)
-- Game: addappid(2487140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2487141, 1, "a2081ac1d24edc7dd247ed808500e4db92dc00f12312e2325910bae51a0b0006")
