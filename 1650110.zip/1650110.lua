-- Lua provided by RyzenAPI
-- Game: Furry Lust

-- MAIN APPLICATION
addappid(1650110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1650111, 1, "1e88504be854635a98f71fc2b6922c30d2b9697cd62a8afabab68818d1b82a99")
