-- Lua provided by RyzenAPI
-- Game: Green Hell VR

-- MAIN APPLICATION
addappid(1782330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782331, 1, "dc44ae9fd137aeb8b0fe67b1a27201ec97e6bba6d8f39a56543334d8ea109c96")
