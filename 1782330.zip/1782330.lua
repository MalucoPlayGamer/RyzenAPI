-- Lua provided by RyzenAPI 
-- Game: Green Hell VR
addappid(1782330)
addappid(1782331, 1, "dc44ae9fd137aeb8b0fe67b1a27201ec97e6bba6d8f39a56543334d8ea109c96")
