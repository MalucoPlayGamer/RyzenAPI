-- Lua provided by SkyAPI 
-- Game: A New World: Kingdoms
addappid(628650)
addappid(628651, 1, "20d9f4bc469856ba63677a705be75adba352f5828f9c3740aa9cdfc01d458ddb")
