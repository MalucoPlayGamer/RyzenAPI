-- Lua provided by RyzenAPI
-- Game: A New World: Kingdoms

-- MAIN APPLICATION
addappid(628650)
-- Game: addappid(628650)

-- MAIN APP DEPOTS / PACKAGES
addappid(628651, 1, "20d9f4bc469856ba63677a705be75adba352f5828f9c3740aa9cdfc01d458ddb")
