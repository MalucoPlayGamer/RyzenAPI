-- Lua provided by RyzenAPI
-- Game: A New World: Kingdoms

-- MAIN APPLICATION
addappid(628650)

-- MAIN APP DEPOTS / PACKAGES
addappid(628651, 1, "20d9f4bc469856ba63677a705be75adba352f5828f9c3740aa9cdfc01d458ddb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
