-- Lua provided by RyzenAPI
-- Game: AppID 1098140

-- MAIN APPLICATION
addappid(1098140)
-- Game: addappid(1098140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098141, 1, "e4da72c00daa4a88d246e14b0d59774460c4c6cb768b680ce0053a0a9eca1b61")
