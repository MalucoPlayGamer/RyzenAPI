-- Lua provided by RyzenAPI
-- Game: Game: No Creeps Were Harmed TD Demo

-- MAIN APPLICATION
addappid(2371200)
-- Game: addappid(2371200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2371201, 1, "0dc3beef38ca1450d1ea7cbbdfec4cdf06e426d63a70605e6f2d31c90353f093")
