-- Lua provided by RyzenAPI
-- Game: Let It Flow

-- MAIN APPLICATION
addappid(958850)

-- MAIN APP DEPOTS / PACKAGES
addappid(958852,0,"9886b9b33c2c894dea8bf46956e982260f7940c312be20818788525090b20152")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
