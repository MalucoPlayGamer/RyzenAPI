-- Lua provided by RyzenAPI
-- Game: Let It Flow

-- MAIN APPLICATION
addappid(958850)
-- Game: addappid(958850)

-- MAIN APP DEPOTS / PACKAGES
addappid(958852,0,"9886b9b33c2c894dea8bf46956e982260f7940c312be20818788525090b20152")
