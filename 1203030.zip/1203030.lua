-- Lua provided by RyzenAPI
-- Game: Tales of Beasteria

-- MAIN APPLICATION
addappid(1203030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203031, 1, "4c0ecaa5f4b7f5ec0eb2c0ab464062cc3e1784c3319450abbfecad9142411dde")

