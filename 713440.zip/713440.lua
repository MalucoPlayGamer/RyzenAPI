-- Lua provided by RyzenAPI
-- Game: CYCOM: Cybernet Combat

-- MAIN APPLICATION
addappid(713440)

-- MAIN APP DEPOTS / PACKAGES
addappid(713441, 1, "739ae28ba77914cbe85ccb84c22aeef436e3b657200dd379245377c127163411")

