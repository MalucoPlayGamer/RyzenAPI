-- Lua provided by RyzenAPI 
-- Game: AppID 1137900
addappid(1137900)
addappid(1137901, 1, "3c9e27b7a529fccf3007f5a03a5fd9fb500b78adc849eaf50cdb4719385170c2")
