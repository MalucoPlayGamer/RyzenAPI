-- Lua provided by RyzenAPI
-- Game: I Am Gooey

-- MAIN APPLICATION
addappid(1137900)
-- Game: addappid(1137900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137901, 1, "3c9e27b7a529fccf3007f5a03a5fd9fb500b78adc849eaf50cdb4719385170c2")
