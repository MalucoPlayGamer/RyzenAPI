-- Lua provided by RyzenAPI
-- Game: AppID 1137900

-- MAIN APPLICATION
addappid(1137900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(1137901, 1, "3c9e27b7a529fccf3007f5a03a5fd9fb500b78adc849eaf50cdb4719385170c2")

