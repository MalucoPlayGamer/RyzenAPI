-- Lua provided by SkyAPI 
-- Game: AppID 1426440
addappid(1426440)
addappid(1426441, 1, "769b95c53b3043b557137ff583db01e318d0bcbc7e22256bfece767e941c63dc")
