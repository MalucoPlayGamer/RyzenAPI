-- Lua provided by RyzenAPI
-- Game: MICROVOLTS: Recharged

-- MAIN APPLICATION
addappid(1426440)
addappid(2549210)
addappid(2779940)
addappid(2779950)
addappid(2989620)
addappid(2989630)
addappid(2989640)
addappid(3404740)
addappid(3404750)
addappid(3404760)
addappid(3557500)
addappid(3557510)
addappid(3557520)
addappid(3830990)
addappid(3831000)
addappid(3831010)
addappid(4044740)
addappid(4044750)
addappid(4044760)
addappid(4249430)
addappid(4249440)
addappid(4249450)
addappid(4493580)
addappid(4493600)
addappid(4493610)
addappid(4881160)
addappid(4881170)
addappid(4881180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1426441, 1, "769b95c53b3043b557137ff583db01e318d0bcbc7e22256bfece767e941c63dc")

