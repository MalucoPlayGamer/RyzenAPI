-- Lua provided by RyzenAPI
-- Game: The Night of the Scissors

-- MAIN APPLICATION
addappid(1975180)
-- Game: addappid(1975180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1975181, 1, "9ce368f7aae7dd750ee6a8a4d81610080b9beccddbe752f0d4925ef902d61569")
