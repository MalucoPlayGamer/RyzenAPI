-- Lua provided by RyzenAPI 
-- Game: Angel's Gear
addappid(2241560)
addappid(2241561, 1, "b2a962aa63c5541671509084d385e086577ac6bae40fc1359eac5149b0482b56")
