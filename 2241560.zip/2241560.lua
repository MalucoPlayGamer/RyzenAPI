-- Lua provided by RyzenAPI
-- Game: Game: Angel's Gear

-- MAIN APPLICATION
addappid(2241560)
-- Game: addappid(2241560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2241561, 1, "b2a962aa63c5541671509084d385e086577ac6bae40fc1359eac5149b0482b56")
