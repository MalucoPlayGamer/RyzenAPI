-- Lua provided by RyzenAPI
-- Game: Game: Slybots: Frantic Zone

-- MAIN APPLICATION
addappid(384100)
-- Game: addappid(384100)

-- MAIN APP DEPOTS / PACKAGES
addappid(384101, 1, "e9effc5769d9417cd0ba04346113fcf99f854104f230d7274e32288d2eff7357")
addappid(384102, 1, "bc78f8f8ed14af56ed93b26ec8e81670070590b55e877799c14a7347f811f754")
addappid(384103, 1, "18e55fda51de6e17c300d0976171912ef490b67a3a68d7a2f3dcfef0e0ace199")
addappid(384104, 1, "b6d03f4a119e7a14b40183619ced1e523b6c9e508c10c6389cacff4d3b02a68c")
