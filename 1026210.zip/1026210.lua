-- Lua provided by RyzenAPI
-- Game: BAD BILLY 2D VR

-- MAIN APPLICATION
addappid(1026210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1026211, 1, "802abf1abcfcc66dbbaec2af990c11c23bd83833ba5c1afb3ad9c334df03ba8d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
