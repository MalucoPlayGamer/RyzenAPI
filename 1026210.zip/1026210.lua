-- Lua provided by RyzenAPI
-- Game: Game: BAD BILLY 2D VR

-- MAIN APPLICATION
addappid(1026210)
-- Game: addappid(1026210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1026211, 1, "802abf1abcfcc66dbbaec2af990c11c23bd83833ba5c1afb3ad9c334df03ba8d")
