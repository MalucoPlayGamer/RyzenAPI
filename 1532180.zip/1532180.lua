-- Lua provided by RyzenAPI
-- Game: addappid(1532180)

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1532180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532182,0,"61bd1727172de62a45084b1b6a2f80ca6c1d2874458916aac3b78b2d0829f7e3")
