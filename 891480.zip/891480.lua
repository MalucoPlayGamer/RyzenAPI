-- Lua provided by RyzenAPI
-- Game: Idle Expanse

-- MAIN APPLICATION
addappid(891480)
addappid(1028070)
addappid(1247180)
addappid(1285880)
addappid(1368610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(891481, 1, "ec2373dd36ef08e5b64917e7f6ce90c9cbe6cffe46aa4869038694c92f5d7a24")
