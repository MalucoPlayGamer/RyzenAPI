-- Lua provided by RyzenAPI
-- Game: Game: AppID 891480

-- MAIN APPLICATION
addappid(891480)
-- Game: addappid(891480)

-- MAIN APP DEPOTS / PACKAGES
addappid(891481, 1, "ec2373dd36ef08e5b64917e7f6ce90c9cbe6cffe46aa4869038694c92f5d7a24")
