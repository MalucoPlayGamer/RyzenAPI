-- Lua provided by RyzenAPI
-- Game: Game: 吞食天地2：誕生Reborn

-- MAIN APPLICATION
addappid(2396910)
-- Game: addappid(2396910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396911, 1, "7e5367783cda8232327ba6448bafc4480bb83971eadbdf88ef38afdd76e4d0ec")
