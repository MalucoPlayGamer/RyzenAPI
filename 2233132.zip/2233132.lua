-- Lua provided by RyzenAPI
-- Game: 2233132

-- MAIN APPLICATION
addappid(2233132)
-- Game: addappid(2233132)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233132,0,"82a4eddaf8483d8c59f67230bdbcca4177c243b105a5ce390de85306a784def2")
