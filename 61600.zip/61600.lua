-- Lua provided by RyzenAPI
-- Game: Zen Bound 2

-- MAIN APPLICATION
addappid(61600)
-- Game: addappid(61600)

-- MAIN APP DEPOTS / PACKAGES
addappid(61601, 1, "2c43c909403bf4b3cd87b67e6be08ca7c32f321fcf0b3717dd8d7eabe794876a")
addappid(61602, 1, "d98adc824d0f18c1ac013f4ace453530b5c453301f1d6b5be5bb5f00951d6a83")
addappid(61603, 1, "e17718dfe6a345cb7951d1de331286428523b1ce19e7bc986be2b1d58175d5aa")
addappid(61604, 1, "3552cb27c24a864ce675d7f6e4f5046fc2ea825a72f207c64904ed734a318331")
