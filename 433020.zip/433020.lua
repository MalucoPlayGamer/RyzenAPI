-- Lua provided by RyzenAPI
-- Game: 433020

-- MAIN APPLICATION
addappid(433020)
-- Game: addappid(433020)

-- MAIN APP DEPOTS / PACKAGES
addappid(433020,0,"0ca67f34a11a34905054772435c37387d26171a4db8bd1fd8508cd922a6bfde2")
