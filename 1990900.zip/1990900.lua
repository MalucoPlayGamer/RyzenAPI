-- Lua provided by RyzenAPI 
-- Game: 方境战记BlockFight
addappid(1990900)
addappid(1990901, 1, "2891b12b42bed9a3e4c8efb1679c56e48b6f8e70f8579c03d87c37420ab57c6f")
