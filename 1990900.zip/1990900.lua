-- Lua provided by RyzenAPI
-- Game: 1990900

-- MAIN APPLICATION
addappid(1990900)
-- Game: addappid(1990900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990901, 1, "2891b12b42bed9a3e4c8efb1679c56e48b6f8e70f8579c03d87c37420ab57c6f")
