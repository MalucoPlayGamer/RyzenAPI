-- Lua provided by SkyAPI 
-- Game: AppID 3042480
addappid(3042480)
addappid(3042481, 1, "519d1cbf0c18d6d0702124d7cb0aa678386b94d2007e82732d3b6ebdf1a8120a")
