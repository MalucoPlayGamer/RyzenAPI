-- Lua provided by RyzenAPI
-- Game: Age of Defense: Prehistory

-- MAIN APPLICATION
addappid(3042480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3042481, 1, "519d1cbf0c18d6d0702124d7cb0aa678386b94d2007e82732d3b6ebdf1a8120a")

