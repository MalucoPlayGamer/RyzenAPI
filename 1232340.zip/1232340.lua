-- Lua provided by RyzenAPI
-- Game: 1232340

-- MAIN APPLICATION
addappid(1232340)
addappid(1232341)
addappid(1232342)
addappid(1232343)
-- Game: addappid(1232340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232340,0,"23102145acb52a1b33fb9cd1930f51d277cabb7ba230b00e5f300e7c9bd6c349")
