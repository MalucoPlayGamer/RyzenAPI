-- Lua provided by RyzenAPI
-- Game: Crawlspace Multiplayer

-- MAIN APPLICATION
addappid(2585530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2585531, 1, "ccf35675721a073125a90cc25ba3c6e6b69e99996c0866281cb3bb22b148bd1d")

