-- Lua provided by RyzenAPI
-- Game: addappid(848450)

-- MAIN APPLICATION
addappid(848450)

-- MAIN APP DEPOTS / PACKAGES
addappid(848452,0,"2faf06aaa2ceea761e8a38f7f8f72d4c64e3768d5e94c600e3c671f2eeffa17e")
addappid(848453,0,"396d4aced9c9e5f7fa7f07f8971b1f0d673438dc324831ebd79a9cce5ae693b8")
