-- Lua provided by RyzenAPI
-- Game: Subnautica: Below Zero

-- MAIN APPLICATION
addappid(848450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(848452,0,"2faf06aaa2ceea761e8a38f7f8f72d4c64e3768d5e94c600e3c671f2eeffa17e")
addappid(848453,0,"396d4aced9c9e5f7fa7f07f8971b1f0d673438dc324831ebd79a9cce5ae693b8")

