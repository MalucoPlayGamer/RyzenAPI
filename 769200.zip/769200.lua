-- Lua provided by RyzenAPI
-- Game: Game: AppID 769200

-- MAIN APPLICATION
addappid(769200)
-- Game: addappid(769200)

-- MAIN APP DEPOTS / PACKAGES
addappid(769201, 1, "b17fa6c1e3124ada5c91b7b6810ef8695530bec2ccea69496e74cc6920a30ed8")
