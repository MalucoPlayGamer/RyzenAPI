-- Lua provided by RyzenAPI
-- Game: Fireflies

-- MAIN APPLICATION
addappid(396530)
-- Game: addappid(396530)

-- MAIN APP DEPOTS / PACKAGES
addappid(396531, 1, "133c384c17d906ea04a460526961078b47cceadd1edd26f8ab99a634d2fc7e7a")
