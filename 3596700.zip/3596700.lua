-- Lua provided by RyzenAPI
-- Game: TerraTech Legion

-- MAIN APPLICATION
addappid(3596700)
addappid(4443500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3596701,0,"d620ed413ea58b0f277c6368ac8ed8eca41cb975f7b56bcd5a9bc976f4602f4d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
