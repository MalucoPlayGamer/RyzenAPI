-- Lua provided by RyzenAPI
-- Game: TerraTech Legion

-- MAIN APPLICATION
addappid(3596700)
addappid(4443500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3596701,0,"d620ed413ea58b0f277c6368ac8ed8eca41cb975f7b56bcd5a9bc976f4602f4d")

