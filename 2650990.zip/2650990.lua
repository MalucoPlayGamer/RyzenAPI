-- Lua provided by RyzenAPI
-- Game: Beat Saber - The Rolling Stones - "Sympathy For The Devil"

-- MAIN APPLICATION
addappid(2650990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2650990,0,"69329785d36b7ddd5070430ddc95d81b4bab57f401ea5f05734ec714baf7432a")

