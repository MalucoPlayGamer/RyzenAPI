-- Lua provided by RyzenAPI
-- Game: Space Supermarket Simulator

-- MAIN APPLICATION
addappid(1841050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1841051,0,"6999a9a120a61be5a070a63456a32c004a1a3c0c37255eeecea314014d117ce7")

