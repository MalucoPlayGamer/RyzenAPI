-- Lua provided by RyzenAPI
-- Game: Space Supermarket Simulator

-- MAIN APPLICATION
addappid(1841050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1841051,0,"6999a9a120a61be5a070a63456a32c004a1a3c0c37255eeecea314014d117ce7")

