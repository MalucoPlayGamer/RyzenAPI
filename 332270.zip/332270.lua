-- Lua provided by RyzenAPI
-- Game: Gunmetal Arcadia

-- MAIN APPLICATION
addappid(332270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(332271, 1, "a804dd1d4a87bec2d729f50430e09c6a9a0a11593c9c596bbefdc7b5ee711dad")
addappid(332274, 1, "f74ebed667a95dd8d9087e5e0c45ca5463925d312d93f3afd949dda632071d33")

