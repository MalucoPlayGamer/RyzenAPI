-- Lua provided by RyzenAPI
-- Game: Sea of Lies: Burning Coast Collector's Edition

-- MAIN APPLICATION
addappid(786060)

-- MAIN APP DEPOTS / PACKAGES
addappid(786061,0,"8139cba900ef672c2f10a85231cec544d7cd5c4de29cd4f49cc80f21b7cca7c0")

