-- Lua provided by RyzenAPI
-- Game: 2195470

-- MAIN APPLICATION
addappid(2195470)
-- Game: addappid(2195470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195470,0,"f1bcf2678370204f6238bbf31f53737efcc0fed3775ec24fc90ba0eb4104ab66")
