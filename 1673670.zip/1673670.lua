-- Lua provided by RyzenAPI
-- Game: addappid(1673670)

-- MAIN APPLICATION
addappid(1673670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1673671, 1, "d9eddab25ce54669903e5ead12d4d5f61cb6803efc68eee379c3fe3c1bfe5b6a")
