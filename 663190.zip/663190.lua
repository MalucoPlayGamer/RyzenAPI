-- Lua provided by RyzenAPI
-- Game: 663190

-- MAIN APPLICATION
addappid(663190)
-- Game: addappid(663190)

-- MAIN APP DEPOTS / PACKAGES
addappid(663191, 1, "e242927e2e9df41d99db4b86721bedd4855692e6489ce57fa3d19172f6f98ce7")
