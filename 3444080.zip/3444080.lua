-- Lua provided by RyzenAPI
-- Game: Game: Bakery Cafe Simulator

-- MAIN APPLICATION
addappid(3444080)
-- Game: addappid(3444080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3444081, 1, "11ced1ac7e5218140e0c3802ac74011ca3d2ccc2979f5be29b709cf33ef1175b")
