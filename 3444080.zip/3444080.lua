-- Lua provided by SkyAPI 
-- Game: Bakery Cafe Simulator
addappid(3444080)
addappid(3444081, 1, "11ced1ac7e5218140e0c3802ac74011ca3d2ccc2979f5be29b709cf33ef1175b")
