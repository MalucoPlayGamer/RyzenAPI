-- Lua provided by RyzenAPI
-- Game: WRC 9 FIA World Rally Championship

-- MAIN APPLICATION
addappid(1267540)
addappid(1530500)
addappid(1530501)
addappid(1530502)
addappid(1530503)
addappid(1530504)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1267541, 1, "AF197905780602FD49B05BCCF6E8F59A872A943619B0AA7C563B2BC9E48E3EE7")

