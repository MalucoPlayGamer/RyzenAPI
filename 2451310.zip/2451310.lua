-- Lua provided by RyzenAPI
-- Game: Monster Mop Up

-- MAIN APPLICATION
addappid(2451310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2451311, 1, "ff797f3d5a5a8ed1f0df9a696dc854d86e74e312de303e70794765b9a49d75d4")

