-- Lua provided by RyzenAPI
-- Game: 1645

-- MAIN APPLICATION
addappid(1641)
addappid(1642)
addappid(1643)
addappid(1644)
addappid(1645)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
