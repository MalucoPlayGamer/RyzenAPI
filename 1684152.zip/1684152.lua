-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1684152)
-- Game: addappid(1684152)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684152,0,"92c16da2b623c120f3a9c93160e7059da852f67ce5db9a2ab984b88a37828d50")
