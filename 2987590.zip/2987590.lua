-- Lua provided by RyzenAPI
-- Game: KAKU: Ancient Seal - Launch Exclusive Content

-- MAIN APPLICATION
addappid(2987590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2987590,0,"2d772ceb4a91f072b19ea1ae0ea489020a0af6e6828cef0e68994db2cb714fb8")
