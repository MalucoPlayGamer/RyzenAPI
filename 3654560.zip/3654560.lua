-- Lua provided by RyzenAPI
-- Game: Plants vs. Zombies™: Replanted

-- MAIN APPLICATION
addappid(3654560)
addappid(3802680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3654561, 1, "6fc167060f8d59e04b1336aa831531599eba25b5d81a6d659408e1d69b65b456")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
