-- Lua provided by RyzenAPI
-- Game: 3654560

-- MAIN APPLICATION
addappid(3654560)
addappid(3802680)
-- Game: addappid(3654560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3654561, 1, "6fc167060f8d59e04b1336aa831531599eba25b5d81a6d659408e1d69b65b456")
