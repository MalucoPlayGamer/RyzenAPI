-- Lua provided by RyzenAPI
-- Game: Jung's Labyrinth

-- MAIN APPLICATION
addappid(709710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(709712,0,"6aa28ab392fb17d9b0d0b94207cc0aaa830408e9e6a2f256da818d7ecee0fdaa")

