-- Lua provided by RyzenAPI
-- Game: Jung's Labyrinth

-- MAIN APPLICATION
addappid(709710)

-- MAIN APP DEPOTS / PACKAGES
addappid(709712,0,"6aa28ab392fb17d9b0d0b94207cc0aaa830408e9e6a2f256da818d7ecee0fdaa")

