-- Lua provided by RyzenAPI
-- Game: addappid(1234120)

-- MAIN APPLICATION
addappid(1234120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234121, 1, "31da404d97fba8ee99cd301ddf62449f78c06a72e979e613ab6e87e83a8cb216")
