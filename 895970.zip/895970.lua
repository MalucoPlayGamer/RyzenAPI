-- Lua provided by RyzenAPI
-- Game: BlackShot Revolution

-- MAIN APPLICATION
addappid(895970)

-- MAIN APP DEPOTS / PACKAGES
addappid(895971, 1, "a6ce55c9a935d5f2fb2e830dab45cfa32f36cab4e741cdb0b9710c47d0e80112")

