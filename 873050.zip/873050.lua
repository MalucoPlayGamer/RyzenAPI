-- Lua provided by RyzenAPI
-- Game: Crescent Hollow

-- MAIN APPLICATION
addappid(873050)

-- MAIN APP DEPOTS / PACKAGES
addappid(873051,0,"79201638bb663626ab32ceea8d115f27e74baea4e3de293e13bf3565fcfee450")

