-- Lua provided by RyzenAPI
-- Game: Faptastic Journey

-- MAIN APPLICATION
addappid(1284610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284611, 1, "376fbee1de70f4fbc2ec2d914b155d6074b53081101265c465f2037c9d66dcf9")

