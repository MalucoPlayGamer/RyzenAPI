-- Lua provided by RyzenAPI 
-- Game: Alien Planet Explorer
addappid(1617020)
addappid(1617021, 1, "964b5c18b073ae01900f6978fec3459349637931fcddac33d4087e09e132d40c")
