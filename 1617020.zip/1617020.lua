-- Lua provided by RyzenAPI
-- Game: Alien Planet Explorer

-- MAIN APPLICATION
addappid(1617020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1617021, 1, "964b5c18b073ae01900f6978fec3459349637931fcddac33d4087e09e132d40c")

