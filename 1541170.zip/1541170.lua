-- Lua provided by RyzenAPI
-- Game: TIC-TAC: Twelve o'clock Demo

-- MAIN APPLICATION
addappid(1541170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1541171, 1, "2a768a4749fe7c3a552039fcf946c3705eea19dc20145dbbe48f7d57e07e7ca2")
