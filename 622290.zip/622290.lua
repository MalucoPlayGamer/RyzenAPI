-- Lua provided by RyzenAPI
-- Game: 1 multi screen media player gallery video wall photo slideshow wizard app

-- MAIN APPLICATION
addappid(622290)

-- MAIN APP DEPOTS / PACKAGES
addappid(622291, 1, "80b394cad2d960a6d3070109389f491292152947fd08a27cd71b97edc7e3f13d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(632660)
