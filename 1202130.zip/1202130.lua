-- Lua provided by SkyAPI 
-- Game: Starship Troopers: Terran Command
addappid(1202130)
addappid(1202131, 1, "28a081ad85c863582f56872daad3d316892beee330bcc62a27ca912cf7cfd226")
addappid(1202132, 1, "6e24c6ec9775c2b1690167d77e3d3c417eeac3b77adb6e54f300c3ea21a361f3")
addappid(2139990, 0, "b094cedf4d4b6d0dcdb32b49508a903c6803f24bd9101fde0c075016d4c6335d")
addappid(2139991, 0, "87efb75b2b1c8aba0522c08711f875ddced3af1c52511819d1eb018482c52e1f")
