-- Lua provided by RyzenAPI
-- Game: Game: Ploc

-- MAIN APPLICATION
addappid(1891840)
-- Game: addappid(1891840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1891841, 1, "74275d13155e4acb4e6e5aa2cc5b6e2809357ef8815a6fe30f044dc892183e54")
