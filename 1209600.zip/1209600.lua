-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1209600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209600,0,"11599408f1d24e83b76a54024efc5c2bad03170670c3de23c11abc0725140ad6")
