-- Lua provided by RyzenAPI 
-- Game: AppID 655120
addappid(655120)
addappid(655121, 1, "3ffef8265654af7cd03d6e9c64860ba1ebd11d3341693497a32d45d389da0a4e")
