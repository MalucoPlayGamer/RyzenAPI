-- Lua provided by RyzenAPI
-- Game: Polygon Arena

-- MAIN APPLICATION
addappid(2607610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2607611, 1, "2ca51c6c22abc7fbe6ee9c363aab762c13d0b09ad441e37b9dd8b274b78f8643")

