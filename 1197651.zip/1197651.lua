-- Lua provided by RyzenAPI
-- Game: Barotrauma - Soundtrack

-- MAIN APPLICATION
addappid(1197651)
-- Game: addappid(1197651)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197651,0,"880374e21d84e1b54d094f73147f62e9aef49552b1e0a9a2f0bbfc04ae2ac069")
addappid(1670640,0,"1e35785f229c02d68d16234645fcccb600afc2be5783df82a77896c835d4759b")
