-- Lua provided by RyzenAPI
-- Game: Game: Strange world

-- MAIN APPLICATION
addappid(2669160)
-- Game: addappid(2669160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2669161, 1, "f1368fd1899ed8dc6b43a91de3d712b94dbf48289d6da0e1100747504df64986")
