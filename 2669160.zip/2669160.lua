-- Lua provided by RyzenAPI 
-- Game: Strange world
addappid(2669160)
addappid(2669161, 1, "f1368fd1899ed8dc6b43a91de3d712b94dbf48289d6da0e1100747504df64986")
