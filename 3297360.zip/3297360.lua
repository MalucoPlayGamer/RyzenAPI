-- Lua provided by RyzenAPI
-- Game: We're Here, Papa

-- MAIN APPLICATION
addappid(3297360)
-- Game: addappid(3297360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3297361, 1, "56442f62d5822cca521039634c8284cf33d7851350018a63c95a40b96c7364de")
