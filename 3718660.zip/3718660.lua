-- Lua provided by RyzenAPI
-- Game: Game: Coin Hunter

-- MAIN APPLICATION
addappid(3718660)
-- Game: addappid(3718660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3718661, 1, "b7c44d51610401882bfbd12f1c951c79d9124c1de3ad6fd8d3a33c3fee2773d3")
