-- Lua provided by RyzenAPI
-- Game: Coin Hunter

-- MAIN APPLICATION
addappid(3718660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3718661, 1, "b7c44d51610401882bfbd12f1c951c79d9124c1de3ad6fd8d3a33c3fee2773d3")

