-- Lua provided by RyzenAPI
-- Game: The Star Named EOS

-- MAIN APPLICATION
addappid(1619230)
-- Game: addappid(1619230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1619232,0,"04b46f04b6d5546e73a2bbe8090fad727e319f7d9a012a14414782c925835a38")
