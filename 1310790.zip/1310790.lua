-- Lua provided by RyzenAPI
-- Game: The Adventures of Eggbert

-- MAIN APPLICATION
addappid(1310790)
-- Game: addappid(1310790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1310791, 1, "65c9411b4d29617993fb8563e7e15419a151042af094b4d4423613dde3b002bd")
