-- Lua provided by RyzenAPI
-- Game: 花落冬陽 Snowdreams -lost in winter-

-- MAIN APPLICATION
addappid(987480)

-- MAIN APP DEPOTS / PACKAGES
addappid(987481, 1, "fe2417b3a9299099ee0cfed0695bab55dfb9337facc01047807cf2025402f5f6")
addappid(1887130, 0, "d5d4ca49d3cbb53b394bf8f2dc7d53946e49900066e0b0e469eff5e870c24cbf")
addappid(1887140, 0, "bb0dce0774374e6d2c3b5b2e94844e826eb07f7260af3d0d39955a2936e9e69f")

