-- Lua provided by SkyAPI 
-- Game: AppID 1205060
addappid(1205060)
addappid(1205061, 1, "2c5b4cd4c578e5bed2d93d53062bb35f8946452edabe194434db4739d3f45c5b")
