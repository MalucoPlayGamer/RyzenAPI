-- Lua provided by RyzenAPI
-- Game: Shoemaker

-- MAIN APPLICATION
addappid(914070)

-- MAIN APP DEPOTS / PACKAGES
addappid(914071, 1, "28afc5618865e131dc14ad495698cd7119c0f147a259e52ff5cca1edc70a7ae5")
addappid(914072, 1, "70fa23a7c89b011c6f63b8caab82267d11a5ade942a510bdaa9cefcc810a749d")
addappid(914073, 1, "9ed71b6811ae5771aa2a2c772f94fb881c5f9e02d03b92a5fc4bcfc8f647a5af")
addappid(914074, 1, "9f92df9584c8c87c9e6a6806886c0b23d5ad124d3649a318f8da218962b970b1")

