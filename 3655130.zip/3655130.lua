-- Lua provided by RyzenAPI
-- Game: Shadow of the Orient Soundtrack

-- MAIN APPLICATION
addappid(3655130)
-- Game: addappid(3655130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3655132,0,"278f2ab7c1679fa5797c083f8ea0577babf49f665180045bb5931012a16d76aa")
addappid(3655133,0,"fd55a8e25490debe81d2337ed3cbe10ceea24ee2ab7610264b1840d973f30e0c")
