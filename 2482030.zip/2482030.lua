-- Lua provided by RyzenAPI
-- Game: Aikagura

-- MAIN APPLICATION
addappid(2482030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2482031, 1, "0ac9d3f8b428233921d353ca12f76a6685636c7322bea0800b7bdffef8b41b0b")
addappid(2494010, 0, "6cbf474deebbb372727bf32a673ac2f8e0b60e83ee5628ad617de9c2a056a378")
