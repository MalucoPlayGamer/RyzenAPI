-- Lua provided by RyzenAPI
-- Game: addappid(1124830)

-- MAIN APPLICATION
addappid(1124830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124831, 1, "34c5540a811b29618ec5f056644e154685cb13b0b663aa2b1c32cbfcffaa7e99")
