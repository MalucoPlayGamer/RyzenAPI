-- Lua provided by RyzenAPI
-- Game: 东方华彩乱战 ~ Touhou Blooming Chaos

-- MAIN APPLICATION
addappid(1124830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1124831, 1, "34c5540a811b29618ec5f056644e154685cb13b0b663aa2b1c32cbfcffaa7e99")

