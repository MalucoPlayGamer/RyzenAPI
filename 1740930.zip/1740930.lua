-- Lua provided by RyzenAPI
-- Game: JellyCar Worlds

-- MAIN APPLICATION
addappid(1740930)
-- Game: addappid(1740930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1740931, 1, "cc486935ac58fd11a4919c4b73fc58446b2114a73f34b202ae216db0c6021c82")
