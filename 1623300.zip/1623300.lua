-- Lua provided by RyzenAPI
-- Game: Game: Model Building Restoration

-- MAIN APPLICATION
addappid(1623300)
-- Game: addappid(1623300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623301, 1, "cec862ef2d5bc52d78d9ebfccd0662924db3dcc2e0b93880f2f66e093dc04a87")
