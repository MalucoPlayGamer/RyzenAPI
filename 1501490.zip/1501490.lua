-- Lua provided by RyzenAPI
-- Game: Ship Handling Simulator

-- MAIN APPLICATION
addappid(1501490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501491, 1, "503df4ffa5e89b24fd784e5443f3e8f896f5ba2dcdf77a55e5df7eeefb3e4b6f")
