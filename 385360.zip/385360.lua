-- Lua provided by RyzenAPI
-- Game: addappid(385360)

-- MAIN APPLICATION
addappid(385360)

-- MAIN APP DEPOTS / PACKAGES
addappid(385361, 1, "7c815337f73abc2e5af1949f1ee0def8fe3140504ba769be66add45afc1ce82b")
