-- Lua provided by RyzenAPI
-- Game: 2147070

-- MAIN APPLICATION
addappid(2147070)
-- Game: addappid(2147070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2147071, 1, "3a82cbfff78e28abaf6a7bd13633cbd9e8e31b824f07e346226683cba1d1a2e1")
