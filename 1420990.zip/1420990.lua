-- Lua provided by RyzenAPI
-- Game: Creepy Girls

-- MAIN APPLICATION
addappid(1420990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420991, 1, "74c39be5e5b8e0a27d9aa49194793322af4659e1ffaf6a7058138178376523ef")
