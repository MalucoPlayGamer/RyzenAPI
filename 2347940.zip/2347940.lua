-- Lua provided by RyzenAPI
-- Game: Sea of Survivors

-- MAIN APPLICATION
addappid(2347940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2347941, 1, "e410306c57c6526ec83c792aebf473ad2c7eee992387c41b99d6e511e1cd5ebf")

