-- Lua provided by RyzenAPI
-- Game: Touken Ranbu Warriors - Uchiban Outfit "Namazuo Toushiro"

-- MAIN APPLICATION
addappid(1912082)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912082,0,"51f24163381c5fd7432c940ec6538931ca20fa38b8b80d57cd4640852b73339b")
