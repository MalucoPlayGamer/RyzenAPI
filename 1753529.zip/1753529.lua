-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1753529)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753529,0,"5b6c9abc1ca43f9859b21cdcf3b24b976e7328068b0a07c3b9faf70e90bf1c13")

