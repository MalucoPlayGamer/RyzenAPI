-- Lua provided by RyzenAPI
-- Game: Corner Kitchen Fast Food Simulator

-- MAIN APPLICATION
addappid(3357250)
-- Game: addappid(3357250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3357251, 1, "7156f71d76fb0864b54a9d43d870b985a491337e4ea4a94370bcf94c670722c5")
