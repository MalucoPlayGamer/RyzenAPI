-- Lua provided by RyzenAPI
-- Game: addappid(988621)

-- MAIN APPLICATION
addappid(988621)

-- MAIN APP DEPOTS / PACKAGES
addappid(988621,0,"56664a71a61e397948e15f41cdc7abbd01eb741827f612262c82da206385fd2d")
