-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(988621)

-- MAIN APP DEPOTS / PACKAGES
addappid(988621,0,"56664a71a61e397948e15f41cdc7abbd01eb741827f612262c82da206385fd2d")
