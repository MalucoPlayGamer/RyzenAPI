-- Lua provided by RyzenAPI
-- Game: addappid(2429590)

-- MAIN APPLICATION
addappid(2429590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429592,0,"124896a58868970ac6e2900fdb283692c4f867abfcf0fa3f8fe035c1b5a9d81f")
