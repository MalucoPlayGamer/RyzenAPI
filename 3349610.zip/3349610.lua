-- Lua provided by RyzenAPI
-- Game: Leafing Home

-- MAIN APPLICATION
addappid(3349610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3349611, 1, "db654b036dc63d299e466cefe9d33d8574469190fd6c5b932490139ee50bc7c4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
