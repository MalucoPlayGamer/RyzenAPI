-- Lua provided by RyzenAPI
-- Game: addappid(834800)

-- MAIN APPLICATION
addappid(834800)

-- MAIN APP DEPOTS / PACKAGES
addappid(834801, 1, "103b2dd1eebc0aa19417e979134d1299d9f693f0f03d2e8fb9e32e8b4e64ca9b")
