-- Lua provided by RyzenAPI
-- Game: 2051550

-- MAIN APPLICATION
addappid(2051550)
-- Game: addappid(2051550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2051551, 1, "a966e823d9535742e8b9f835a912cc6ec70f2dd27779ebc1b9a27170d4ffc8e0")
