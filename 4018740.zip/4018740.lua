-- Lua provided by RyzenAPI
-- Game: Hariti

-- MAIN APPLICATION
addappid(4018740)

-- MAIN APP DEPOTS / PACKAGES
addappid(4018741,0,"6f6c6d6807f3af3b3c842e71aac1a35f82d46a0f9a862a9791d1a84689f9eef5")

