-- Lua provided by RyzenAPI
-- Game: Hariti

-- MAIN APPLICATION
addappid(4018740)

-- MAIN APP DEPOTS / PACKAGES
addappid(4018741,0,"6f6c6d6807f3af3b3c842e71aac1a35f82d46a0f9a862a9791d1a84689f9eef5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
