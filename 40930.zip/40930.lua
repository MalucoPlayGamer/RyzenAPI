-- Lua provided by RyzenAPI
-- Game: The Misadventures of P.B. Winterbottom

-- MAIN APPLICATION
addappid(40930)
-- Game: addappid(40930)

-- MAIN APP DEPOTS / PACKAGES
addappid(40931, 1, "48ef4067726b0e8eac1118b49c546faadaa58b27eaa230eae3c8a8391b60aafd")
