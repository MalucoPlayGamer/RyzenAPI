-- Lua provided by RyzenAPI
-- Game: Gamebook Edgar A. Poe: The Oval Portrait

-- MAIN APPLICATION
addappid(1992120)
-- Game: addappid(1992120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1992121, 1, "ef89970e74fddb73f1760a80539ab5816162256564db318ff5658abc57753de0")
