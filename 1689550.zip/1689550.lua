-- Lua provided by RyzenAPI
-- Game: addappid(1689550)

-- MAIN APPLICATION
addappid(1689550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689551, 1, "7018191441904152f765e19933d5455ba9ac26eecbd68ff3fb3b20a0887ed30e")
