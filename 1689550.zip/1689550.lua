-- Lua provided by RyzenAPI 
-- Game: Your Adventure
addappid(1689550)
addappid(1689551, 1, "7018191441904152f765e19933d5455ba9ac26eecbd68ff3fb3b20a0887ed30e")
