-- Lua provided by RyzenAPI
-- Game: Game: METAL BEANS

-- MAIN APPLICATION
addappid(2792960)
-- Game: addappid(2792960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2792961, 1, "f4f743bd6e4cc3774c29c0beb63b3d29611f9c6d23c4112e97bbeef39c6c3d3e")
