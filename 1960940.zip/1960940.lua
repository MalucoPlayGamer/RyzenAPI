-- Lua provided by RyzenAPI
-- Game: Rise Of The White Sun Demo

-- MAIN APPLICATION
addappid(1960940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960941, 1, "59260c8290ceb20c7c548ae3ba161e8c8728881a67e00c2455fe79a31ca3c7e3")

