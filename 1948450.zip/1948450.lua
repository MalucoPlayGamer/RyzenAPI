-- Lua provided by RyzenAPI
-- Game: addappid(1948450)

-- MAIN APPLICATION
addappid(1948450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948451, 1, "cbf3112f8ea4f55627828f036dc614ac52c6f603f6131cb141ad5fd15707316e")
