-- Lua provided by RyzenAPI
-- Game: Finding Hannah

-- MAIN APPLICATION
addappid(2362120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362121, 1, "03be45161c124c97475e4fb96f77a348f805c442fc5c38631fbbfbea8974ad3c")
