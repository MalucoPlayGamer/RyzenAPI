-- Lua provided by RyzenAPI
-- Game: Putt-Putt® and Fatty Bear's Activity Pack

-- MAIN APPLICATION
addappid(294720)
-- Game: addappid(294720)

-- MAIN APP DEPOTS / PACKAGES
addappid(294721, 1, "c33e59b17d3c37295ad97e16fbe7c866478c5fba85026de85c8c82f6875b9733")
addappid(294724, 1, "a26398b622ad10db238cef4304ac6ed84779e346c9f33a48e2d37c316a15161c")
addappid(294725, 1, "1ac55a1d2e39e513fce6edc339b5e43519264c1865389168bfdd6fd446568e56")
