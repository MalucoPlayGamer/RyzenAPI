-- Lua provided by RyzenAPI
-- Game: Top Secret

-- MAIN APPLICATION
addappid(613980)

-- MAIN APP DEPOTS / PACKAGES
addappid(613981, 1, "2c1c6f6c4f3ad7755a4a874bba753c880a1393fe589ec8cf6fd8975f958d9309")
