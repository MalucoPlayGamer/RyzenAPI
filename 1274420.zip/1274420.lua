-- Lua provided by RyzenAPI
-- Game: addappid(1274420)

-- MAIN APPLICATION
addappid(1274420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274421, 1, "619748feb8ec717a484d7ea2f3845e6f99b564d8d550811414d4818b5a9faa57")
