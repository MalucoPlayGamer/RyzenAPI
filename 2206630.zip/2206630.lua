-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Soldier Character Pack

-- MAIN APPLICATION
addappid(2206630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206630,0,"42991590914811223566e79792669f270a3b4f449439d9545e250ef9eadc3bc3")

