-- Lua provided by RyzenAPI
-- Game: 3595930

-- MAIN APPLICATION
addappid(3595930)
-- Game: addappid(3595930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3595930,0,"d7bd563f47b269e38ea17014fd2cd6456378fbbfde50a5f172d04c750511ff7f")
