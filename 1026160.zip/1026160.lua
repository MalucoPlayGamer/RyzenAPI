-- Lua provided by RyzenAPI
-- Game: Misadventures of Laura Silver

-- MAIN APPLICATION
addappid(1026160)
-- Game: addappid(1026160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1026161, 1, "8b16d60fb8114566333bd6ae126427297d4200eb15e812a49fe0c7db5e1ae059")
addappid(1181170, 0, "f0c2eb0c8275d7459811670b6f0e48c138ce3cc06c851d6d394d9864bb9709c1")
