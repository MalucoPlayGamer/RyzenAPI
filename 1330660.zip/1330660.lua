-- Lua provided by RyzenAPI
-- Game: AppID 1330660

-- MAIN APPLICATION
addappid(1330660)
-- Game: addappid(1330660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330661, 1, "fd30ed39664ca6cd3ffd28962acac5155d8486e254c47c221471b1c67660aeec")
