-- Lua provided by RyzenAPI
-- Game: Everyday Genius: SquareLogic

-- MAIN APPLICATION
addappid(32150)

-- MAIN APP DEPOTS / PACKAGES
addappid(32151, 1, "c900d8c10e647d9bf87c0c3e1b06db8fd453ac0dd19e4306ba39af341a589373")

