-- Lua provided by SkyAPI 
-- Game: Everyday Genius: SquareLogic
addappid(32150)
addappid(32151, 1, "c900d8c10e647d9bf87c0c3e1b06db8fd453ac0dd19e4306ba39af341a589373")
