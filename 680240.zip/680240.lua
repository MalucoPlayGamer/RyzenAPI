-- Lua provided by RyzenAPI 
-- Game: AppID 680240
addappid(680240)
addappid(680241, 1, "821fe4fac9e439fb38ec10ba1d107e18435cb56978cdc85f449b679ee16143d5")
