-- Lua provided by RyzenAPI 
-- Game: Cam Op Simulator
addappid(3155080)
addappid(3155081, 1, "aff8b8510c3d089039aa8231676e1a2f90bd99ee8dd438df04513cb25879bd2e")
