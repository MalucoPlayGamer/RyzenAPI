-- Lua provided by RyzenAPI
-- Game: Cam Op Simulator

-- MAIN APPLICATION
addappid(3155080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3155081, 1, "aff8b8510c3d089039aa8231676e1a2f90bd99ee8dd438df04513cb25879bd2e")

