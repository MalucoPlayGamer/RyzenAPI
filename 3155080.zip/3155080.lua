-- Lua provided by RyzenAPI
-- Game: 3155080

-- MAIN APPLICATION
addappid(3155080)
-- Game: addappid(3155080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3155081, 1, "aff8b8510c3d089039aa8231676e1a2f90bd99ee8dd438df04513cb25879bd2e")
