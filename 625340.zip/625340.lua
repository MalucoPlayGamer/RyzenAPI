-- Lua provided by RyzenAPI
-- Game: AppID 625340

-- MAIN APPLICATION
addappid(625340)

-- MAIN APP DEPOTS / PACKAGES
addappid(625341, 1, "1eddf9b5cd370e3b8a89092717ade28ba32a809b8b237de3d075898ba64ae3bd")

