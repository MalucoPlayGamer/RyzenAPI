-- Lua provided by RyzenAPI
-- Game: AppID 625340

-- MAIN APPLICATION
addappid(625340)

-- MAIN APP DEPOTS / PACKAGES
addappid(625341, 1, "1eddf9b5cd370e3b8a89092717ade28ba32a809b8b237de3d075898ba64ae3bd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(997680)
addappid(1069420)
addappid(1069421)
addappid(1069422)
addappid(1079670)
addappid(1079671)
addappid(1641160)
addappid(1641161)
