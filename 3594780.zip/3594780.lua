-- Lua provided by RyzenAPI
-- Game: Blackjack 21: Blackjackist

-- MAIN APPLICATION
addappid(3594780)
