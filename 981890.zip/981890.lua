-- Lua provided by RyzenAPI
-- Game: AppID 981890

-- MAIN APPLICATION
addappid(981890)

-- MAIN APP DEPOTS / PACKAGES
addappid(981891, 1, "9da779d82b2a62043e5fef763724f86270c7b14295c5544faa0bb130debd91c4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
