-- Lua provided by RyzenAPI
-- Game: addappid(981890)

-- MAIN APPLICATION
addappid(981890)

-- MAIN APP DEPOTS / PACKAGES
addappid(981891, 1, "9da779d82b2a62043e5fef763724f86270c7b14295c5544faa0bb130debd91c4")
