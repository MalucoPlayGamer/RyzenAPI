-- Lua provided by RyzenAPI
-- Game: Qbeh-1: The Atlas Cube

-- MAIN APPLICATION
addappid(228983)
addappid(252550)
addappid(252551)
addappid(252552)
addappid(252555)
addappid(344210)
addappid(344211)

-- MAIN APP DEPOTS / PACKAGES
addappid(252553,0,"ac364a5278ef4d9965b49d0e2386f76fa530b6ab0387a3a31c207b755a4b779d")
addappid(252554,0,"e32fc0b648362e6ae1bad556f3e18aeebfbfaf50388860be7bc3aadc68cbe461")
