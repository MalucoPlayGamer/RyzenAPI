-- Lua provided by RyzenAPI
-- Game: Royal Revolt Survivors Demo

-- MAIN APPLICATION
addappid(3136050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3136052,0,"f06465b649c8436421f08ad828aff67cfc2420399597d9ac989503a724bf9095")

