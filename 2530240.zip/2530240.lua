-- Lua provided by RyzenAPI
-- Game: Top Jump: Prologue

-- MAIN APPLICATION
addappid(2530240)
-- Game: addappid(2530240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2530241, 1, "ec9a635546a5b4794fa762ba7bdaa54ec492d3a82b6b5d1bafecf56d74568b02")
