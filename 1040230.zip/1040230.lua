-- Lua provided by RyzenAPI
-- Game: Curious Expedition 2

-- MAIN APPLICATION
addappid(1040230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1040231, 1, "4ebe56b93d6a345a94b181f5445fb2fbcb68ef7c3e4b5b79ec0126db0d6485ef")
addappid(1690330, 0, "5f55fde1cc50f4886d8204a0a9a8a7cf6aac27999fd6e58f2288481d5dc08e44")
addappid(1751920, 0, "3c5a9e91db4c08ace3bf960ab55f446892ec4d979880364d57e9f61dda449ab4")
addappid(1751921, 0, "eb103c1514009f9e4dd6c5c83bda41c8a6114660388289dfdc83e7cde9680c82")

