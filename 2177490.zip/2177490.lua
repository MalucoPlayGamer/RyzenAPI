-- Lua provided by RyzenAPI
-- Game: Game: Spring X Elixir

-- MAIN APPLICATION
addappid(2177490)
addappid(2202860)
-- Game: addappid(2177490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2177491, 1, "7632a40d4566d4ca986a94edfb3994707894c2f3440398d3e7f078e398ce79f4")
