-- Lua provided by RyzenAPI
-- Game: Banana Shooter Dedicated Server

-- MAIN APPLICATION
addappid(2406780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406781, 1, "a5dca4014a42a2f426617dc96e96a22a7cbf8da3b07c3c03fabd6a1dff5375c5")
addappid(2406782, 1, "db93ebd345fe461912d9030f74c72398deb75817e3d1fe2080ec68c14634faf8")
