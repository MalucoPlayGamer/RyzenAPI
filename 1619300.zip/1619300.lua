-- Lua provided by RyzenAPI
-- Game: Subnautica Original Soundtrack

-- MAIN APPLICATION
addappid(1619300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1619301, 1, "462060463aa5916ef318a23bb44c53ce357929744fcbf66ac08bbf6a70edf846")
