-- Lua provided by RyzenAPI
-- Game: Saikyo Robots: Prologue

-- MAIN APPLICATION
addappid(2379530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2379534,0,"33d1fbe21110b6a25b3091eb8525c168e6b66f1ce692a968ef560bfe0749fa37")
