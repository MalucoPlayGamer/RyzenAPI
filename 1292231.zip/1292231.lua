-- Lua provided by RyzenAPI
-- Game: Devilish Girl - Original Soundtrack

-- MAIN APPLICATION
addappid(1292231)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292231,0,"feecebd5797de9f96bcba965cd76c6e865e8a121e91ba78e8a99cabc227c4d04")
