-- Lua provided by RyzenAPI
-- Game: 1023390

-- MAIN APPLICATION
addappid(1023390)
-- Game: addappid(1023390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023391, 1, "53b094d89b76b18a60ae006727bd10a069059e86b974dc7df8f323bef0f3dcf9")
