-- Lua provided by RyzenAPI
-- Game: 3042090

-- MAIN APPLICATION
addappid(3042090)
-- Game: addappid(3042090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3042091, 1, "5745caa06cc6e35068ec395d702f7d86d1f3eccf5613a8d8135ee2e5dee3dc19")
