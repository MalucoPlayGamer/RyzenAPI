-- Lua provided by RyzenAPI
-- Game: Squareface

-- MAIN APPLICATION
addappid(517350)
-- Game: addappid(517350)

-- MAIN APP DEPOTS / PACKAGES
addappid(517351, 1, "6a3e08d76d94d4b49a73233ebad01cac18a958cf788e64f0a28497c3ec476947")
addappid(540520, 0, "502544a77f81155dc2f0bb40410e51e90a6dc845c768579a354628ec565e6bee")
