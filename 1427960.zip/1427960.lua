-- Lua provided by RyzenAPI
-- Game: Game: Jigsaw Boom

-- MAIN APPLICATION
addappid(1427960)
-- Game: addappid(1427960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1427961, 1, "84c802ef8f778a959962044ea89bd253ba35a862c8795a7f0879e5c34ffe620e")
addappid(1427962, 1, "7ed7ed45a06d4a1e96e89d4a7dcbd34ad0fb1e384596e6e01a0e2d52d363ad36")
addappid(1427963, 1, "35007c98419f1e9689edfebb2e7cffc1da6e089fe02ae5dbd20340189356de2a")
addappid(1427964, 1, "97357a0d0b00c9835f9ed6f4581c2d46f3ab362481eb02dc90c8085cbe917f41")
