-- Lua provided by SkyAPI 
-- Game: Four Winds Fantasy
addappid(1915170)
addappid(1915171, 1, "7e69f82e8a99e8de158f168c7ce474d7902a9b022d8bebf6d9e8267855ceeecd")
