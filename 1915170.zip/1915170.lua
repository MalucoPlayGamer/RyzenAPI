-- Lua provided by RyzenAPI
-- Game: Four Winds Fantasy

-- MAIN APPLICATION
addappid(1915170)
-- Game: addappid(1915170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1915171, 1, "7e69f82e8a99e8de158f168c7ce474d7902a9b022d8bebf6d9e8267855ceeecd")
