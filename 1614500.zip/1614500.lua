-- Lua provided by SkyAPI 
-- Game: Run and Jump Little Vico
addappid(1614500)
addappid(1614501, 1, "13a8e07f7b5fcaab3a029a8775db174599a4da3e5b258baea49765510f949c09")
