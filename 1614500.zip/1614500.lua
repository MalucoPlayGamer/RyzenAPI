-- Lua provided by RyzenAPI
-- Game: Run and Jump Little Vico

-- MAIN APPLICATION
addappid(1614500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1614501, 1, "13a8e07f7b5fcaab3a029a8775db174599a4da3e5b258baea49765510f949c09")
