-- Lua provided by RyzenAPI
-- Game: Criticality

-- MAIN APPLICATION
addappid(4144990)

-- MAIN APP DEPOTS / PACKAGES
addappid(4144991,0,"eba317d1f901baf614abf06d42a4279c56fffb865aa172f4ecba083f1bbeaf26")

