-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(461030)
addappid(461031)
addappid(461032)
addappid(461034)
addappid(461035)
addappid(461036)

-- MAIN APP DEPOTS / PACKAGES
addappid(461033,0,"40ccdfcca1638978782db3f87efeddee8d6ceb482cf93dc6f9e60119ebac66a4")

