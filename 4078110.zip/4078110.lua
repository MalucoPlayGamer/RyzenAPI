-- 4078110's Lua and Manifest Created by Hubcap Manifest
-- Suncraft
-- Created: July 28, 2026 at 14:08:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4078110) -- Suncraft
-- MAIN APP DEPOTS
addappid(4078111, 1, "24104cc5a04abe551a2a6222439f6a30c2b6c3c379236124456abfeca6f29c0e") -- Depot 4078111
setManifestid(4078111, "8097118406790289133", 345620367)
addappid(4078112, 1, "822531e9254eb026d08cedf374bc09f22e9ce138a7e10b72e0371610101988fd") -- Depot 4078112
setManifestid(4078112, "3114113697974558202", 405706511)
addappid(4078113, 1, "fd968a0afe958b9cd086a25ef040102319e8bd842a3c6a3856b2ba12e99ccecc") -- Depot 4078113
setManifestid(4078113, "8185311913466269848", 514276792)