-- Lua provided by RyzenAPI 
-- Game: AppID 358030
addappid(358030)
addappid(358031, 1, "8f2f036feed378114f319866587b53dd2177cce9254abb725c86c6baf0e9d549")
