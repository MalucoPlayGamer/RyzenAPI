-- Lua provided by RyzenAPI
-- Game: AppID 358030

-- MAIN APPLICATION
addappid(358030)

-- MAIN APP DEPOTS / PACKAGES
addappid(358031, 1, "8f2f036feed378114f319866587b53dd2177cce9254abb725c86c6baf0e9d549")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
