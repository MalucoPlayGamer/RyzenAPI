-- Lua provided by RyzenAPI
-- Game: 1160410

-- MAIN APPLICATION
addappid(1160410)
addappid(3167380)
-- Game: addappid(1160410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1160411, 1, "7dc4c5d4bcb7df43d9fc1bc9a7a35920101da61912daf05b38d1177c18bdb05e")
