-- Lua provided by RyzenAPI
-- Game: Mysterious School

-- MAIN APPLICATION
addappid(2084940)
-- Game: addappid(2084940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2084941, 1, "a7c4fa8309b8b1b5a830883a8ff70182027e193e5011c8b6593785c95db34df1")
