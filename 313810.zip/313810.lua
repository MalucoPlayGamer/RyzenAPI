-- Lua provided by RyzenAPI
-- Game: Legend of Kay Anniversary

-- MAIN APPLICATION
addappid(313810)

-- MAIN APP DEPOTS / PACKAGES
addappid(313811, 1, "0e7d5c3a10e87a4ec205ff47dc1d447f0e9a7d02d854220797c2f7fe99c48b4d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
