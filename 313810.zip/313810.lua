-- Lua provided by RyzenAPI
-- Game: Legend of Kay Anniversary

-- MAIN APPLICATION
addappid(313810)

-- MAIN APP DEPOTS / PACKAGES
addappid(313811, 1, "0e7d5c3a10e87a4ec205ff47dc1d447f0e9a7d02d854220797c2f7fe99c48b4d")

