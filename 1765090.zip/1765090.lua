-- Lua provided by SkyAPI 
-- Game: Legends of Crystal
addappid(1765090)
addappid(1765091, 1, "6beac563f0f345226fc7762bd98a0427be79c593b5f9f0396e962b34ec956790")
