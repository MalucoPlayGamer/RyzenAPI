-- Lua provided by RyzenAPI
-- Game: Legends of Crystal

-- MAIN APPLICATION
addappid(1765090)
-- Game: addappid(1765090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1765091, 1, "6beac563f0f345226fc7762bd98a0427be79c593b5f9f0396e962b34ec956790")
