-- Lua provided by RyzenAPI 
-- Game: Bounce Ball: Neon Party Arcade
addappid(1822300)
addappid(1822301, 1, "52cd0c41bdc7f65edc5b928714a426c14b590d306670b9d837e991bdc03a24a5")
