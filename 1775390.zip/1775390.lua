-- Lua provided by RyzenAPI
-- Game: addappid(1775390)

-- MAIN APPLICATION
addappid(228988)
addappid(1775390)
addappid(1775393)
addappid(1775394)

-- MAIN APP DEPOTS / PACKAGES
addappid(1775392,0,"2405c2cd9353a87e87110431703cae555a6ef9a41d484fa9e3288059144bab30")
