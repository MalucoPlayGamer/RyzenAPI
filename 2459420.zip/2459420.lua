-- Lua provided by RyzenAPI
-- Game: Game: Mushoku Tensei: Jobless Reincarnation Quest of Memories

-- MAIN APPLICATION
addappid(2459420)
-- Game: addappid(2459420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2459421, 1, "73a87df86ca8e806923eeb8c95e92c9bc1a3f0a75b82743b00019d499310553a")
