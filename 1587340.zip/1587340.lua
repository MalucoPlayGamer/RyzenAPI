-- Lua provided by RyzenAPI 
-- Game: AppID 1587340
addappid(1587340)
addappid(1587341, 1, "026ffcd8e82f7a2673ba5972a4015f74e28f131bff88bc017aecd4eea23313fe")
