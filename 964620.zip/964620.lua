-- Lua provided by RyzenAPI
-- Game: AppID 964620

-- MAIN APPLICATION
addappid(964620)

-- MAIN APP DEPOTS / PACKAGES
addappid(964621, 1, "3f31cb527227fa3b1c04917db4800bffa56816302557fae0e7af9ec30cec638c")
