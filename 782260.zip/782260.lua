-- 782260's Lua and Manifest Created by Hubcap Manifest
-- Rogue Eclipse
-- Created: August 15, 2026 at 03:17:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(782260, 1, "ccc82ad2b274ae61dbad7ceb976c229c6b277047d8205fb65cb918194a363850") -- Rogue Eclipse
-- MAIN APP DEPOTS
addappid(782261, 1, "27cd197d9ca84001b1588c4ee8d0d36398fa578a91ab24fce5462249ec42d9bf") -- Depot 782261
setManifestid(782261, "8748523165180473385", 4490723318)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)