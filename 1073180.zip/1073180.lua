-- Lua provided by RyzenAPI
-- Game: 1073180

-- MAIN APPLICATION
addappid(1073180)
-- Game: addappid(1073180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1073180,0,"8a68ff2b6f057eeb8260ad3d72ededf773dc220e963b972354addc757994c3c7")
