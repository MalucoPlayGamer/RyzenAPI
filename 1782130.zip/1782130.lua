-- Lua provided by RyzenAPI
-- Game: 1/2 Red Riding Hood

-- MAIN APPLICATION
addappid(1782130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782131, 1, "453aebff8b3f5346ea9bd8053560e200846905eabb5d49affa8df4e999a0c21a")