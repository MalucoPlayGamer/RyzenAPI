-- Lua provided by RyzenAPI
-- Game: Commander Tiberius Troubleson

-- MAIN APPLICATION
addappid(2341710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2341711, 1, "192758e9e55dd81906d55f3d10da7e143deb3d9c099a15de141a17576c8ebe1a")

