-- Lua provided by SkyAPI 
-- Game: Gargoyles Remastered
addappid(1928020)
addappid(1928021, 1, "721e8c00bbbcddd7140933d34a23e88ff4fd2ee80ca79b7d3ef5e16840e57fde")
