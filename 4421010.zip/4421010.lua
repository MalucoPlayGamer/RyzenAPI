-- Lua provided by RyzenAPI
-- Game: Bills Must Be Paid

-- MAIN APPLICATION
addappid(5020040) -- Bills Must Be Paid - Supporter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(4421010, 1, "d4498a5e8f21f1b5d64df4737a56df8d5dcb372982757215170308a33112d914")
addappid(4421011, 1, "11e5390201ab27a5ff5ccd0a0c03136ba3b4e50f0c08b187d14b36a2a23896d6") -- (windows)
addappid(4421012, 1, "59e5144afe91bf9c7914f4df2297cdb42b37b584ee885cbbc7f8b4fd6155a156") -- (macos)

