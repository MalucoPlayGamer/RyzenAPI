-- Generated with Luie @ https://lua.tools/
-- 4421010 - Bills Must Be Paid
-- Generated 2026-08-22 06:39:51 UTC
-- # Depots (Total/DLC/Shared): 2/0/0

-- Main AppID
addappid(4421010, 1, "d4498a5e8f21f1b5d64df4737a56df8d5dcb372982757215170308a33112d914")

-- Main Depots
addappid(4421011, 1, "11e5390201ab27a5ff5ccd0a0c03136ba3b4e50f0c08b187d14b36a2a23896d6") -- (windows)
setManifestid(4421011, "6848976417670468762", 1467445905)
addappid(4421012, 1, "59e5144afe91bf9c7914f4df2297cdb42b37b584ee885cbbc7f8b4fd6155a156") -- (macos)
setManifestid(4421012, "4644916239143317778", 1598762135)

-- DLC's (no depot keys required)
addappid(5020040) -- Bills Must Be Paid - Supporter Pack
