-- Lua provided by RyzenAPI
-- Game: Project Morpheus: Prologue

-- MAIN APPLICATION
addappid(1414430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414431, 1, "ce99896332d452211b162e88936ab060f0838303bd56d3d6f8369a4e279dbb66")

