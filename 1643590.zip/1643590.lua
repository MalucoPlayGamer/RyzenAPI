-- Lua provided by RyzenAPI
-- Game: Project PULSE

-- MAIN APPLICATION
addappid(1643590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643591, 1, "5cd403dcc5c8a298d09e30d66faf4ed95116cf6b2fc581a77abc67949c69481b")

