-- Lua provided by RyzenAPI
-- Game: Demon Corporation: Onboarding

-- MAIN APPLICATION
addappid(2607260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2607262,0,"22032f72da989bcb26049e02bc2e7577a545c8aa23559adb5fe917b17898c911")

