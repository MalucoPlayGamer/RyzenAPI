-- Lua provided by RyzenAPI
-- Game: addappid(1004860)

-- MAIN APPLICATION
addappid(1004860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004861, 1, "9b98b7eb390e1bae64eff37a0829e0bd86b82c0d08e15a1ee0062ebb3adcd71d")
