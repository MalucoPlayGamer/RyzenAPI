-- Lua provided by RyzenAPI
-- Game: I took away my idol friend's virginity,and did something similar to NTR

-- MAIN APPLICATION
addappid(3027670)
-- Game: addappid(3027670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3027672,0,"c5fd09f87869781bd32d8c78c8acf9e458a3e5e6b9a1a7c0a28b521e10be3c57")
