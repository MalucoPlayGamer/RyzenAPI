-- Lua provided by RyzenAPI
-- Game: Jolly's Park

-- MAIN APPLICATION
addappid(3289600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3289601, 1, "b072756a364a223706f1e78f665a33ca5b09dd88bb7cddb056701c46917aa50c")
