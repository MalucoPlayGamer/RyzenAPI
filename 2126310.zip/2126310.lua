-- Lua provided by RyzenAPI
-- Game: Stunts Contest Super Bike

-- MAIN APPLICATION
addappid(2126310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2126311, 1, "9611d2569fb9d4304d41b73cb7fa7b5721b09469e986acbe9d785fd8ecd7db48")

