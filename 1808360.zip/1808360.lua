-- Lua provided by RyzenAPI
-- Game: addappid(1808360)

-- MAIN APPLICATION
addappid(1808360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808361, 1, "3c0a7bb5b72b49cfb7b5f15a2f8ed0922ea5185516449832d501c3479f8b59ea")
addappid(1808362, 1, "7217cd745fdfc0804c1ca2357853c0b46ee0ea638fb16b3aa1cf085cd5b2f8b6")
