-- Lua provided by RyzenAPI
-- Game: Death Unphased

-- MAIN APPLICATION
addappid(2198590)
-- Game: addappid(2198590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2198591, 1, "e64b734c103d5141963948b6b31bcae6831964dd253d80052e799f4ef1977a2d")
