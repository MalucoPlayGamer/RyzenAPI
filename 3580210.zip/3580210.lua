-- Lua provided by RyzenAPI
-- Game: Game: Strangers Lurk

-- MAIN APPLICATION
addappid(3580210)
-- Game: addappid(3580210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3580211, 1, "0802a9874201162224f3c861c23ad7e2725698179fea158e3a066a41f9b28995")
