-- Lua provided by RyzenAPI 
-- Game: Strangers Lurk
addappid(3580210)
addappid(3580211, 1, "0802a9874201162224f3c861c23ad7e2725698179fea158e3a066a41f9b28995")
