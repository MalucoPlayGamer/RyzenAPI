-- Lua provided by RyzenAPI
-- Game: AppID 1706440

-- MAIN APPLICATION
addappid(1706440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706441, 1, "4bc3ad5e3697c127fd95a473528560b04f3c29a47aacc5d6690a2b4aeae7afe5")
