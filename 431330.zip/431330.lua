-- Lua provided by RyzenAPI
-- Game: Game: Dungeons Are Random

-- MAIN APPLICATION
addappid(431330)
-- Game: addappid(431330)

-- MAIN APP DEPOTS / PACKAGES
addappid(431331, 1, "017632741e6f2b1b56f37d7319b1de4f0a15594522ba478def8ef3f3ce6e1816")
addappid(431332, 1, "bb6f13a000a754fc8ae2d2f7249d2c08bf7e74f9efc5d1c7bb4cea437736237f")
addappid(431333, 1, "e89e705fa50fc091964e6f74b1f9c740c6f03552706f7467c3385700e379d70c")
