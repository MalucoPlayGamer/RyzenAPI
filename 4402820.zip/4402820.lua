-- Lua provided by RyzenAPI
-- Game: WuLin Showdown

-- MAIN APPLICATION
addappid(4402820) -- WuLin Showdown

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4402821, 1, "10bbf7438ffd4cba85d016be3e26d737d5a28234278df1c92583dd23b9e10b79") -- Depot 4402821

