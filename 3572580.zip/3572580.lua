-- Lua provided by RyzenAPI
-- Game: Game: Hachishaku

-- MAIN APPLICATION
addappid(3572580)
-- Game: addappid(3572580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3572581, 1, "b0ca124ae5018d1edd1987ae01a800a4de5e0bd18fee2ff27ea588b1740813d3")
