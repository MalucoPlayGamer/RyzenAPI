-- Lua provided by RyzenAPI
-- Game: Game: AppID 2423190

-- MAIN APPLICATION
addappid(2423190)
-- Game: addappid(2423190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2423191, 1, "f8153467778cc297c128ca38f79ccfe5b78b55ba488f3373dcce640c3cb69557")
