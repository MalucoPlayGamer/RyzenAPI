-- Lua provided by RyzenAPI
-- Game: Hidden Through Time

-- MAIN APPLICATION
addappid(524910)
addappid(524911)
addappid(524913)
addappid(1286510)

-- MAIN APP DEPOTS / PACKAGES
addappid(524912,0,"8eca0741d927f96f2bb6e71082d8231e7fbac6d3d78e9b79449ab9ed9e06a0a9")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1395100)
addappid(1536700)
addappid(1536701)
addappid(1962200)
