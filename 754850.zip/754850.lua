-- Lua provided by SkyAPI 
-- Game: The Spy Who Shrunk Me
addappid(754850)
addappid(754851, 1, "c06add878cdeff1c8b79b70d4bef2366c4925fc4710752f18673c2ba3892dac9")
