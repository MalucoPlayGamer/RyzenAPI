-- Lua provided by RyzenAPI
-- Game: AppID 383080

-- MAIN APPLICATION
addappid(383080)

-- MAIN APP DEPOTS / PACKAGES
addappid(383081, 1, "ac3e25541a4c53a442eac5e3fe11f36de134ae80b981fc14c5aa8b57491ae4cc")
