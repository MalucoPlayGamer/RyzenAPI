-- Lua provided by RyzenAPI
-- Game: AppID 383080

-- MAIN APPLICATION
addappid(383080)
addappid(393020)
addappid(393021)
addappid(393022)
addappid(393023)
addappid(393024)
addappid(393025)
addappid(393026)
addappid(393040)
addappid(393041)
addappid(393042)
addappid(393043)

-- MAIN APP DEPOTS / PACKAGES
addappid(383081, 1, "ac3e25541a4c53a442eac5e3fe11f36de134ae80b981fc14c5aa8b57491ae4cc")

