-- Lua provided by RyzenAPI
-- Game: Harvest Moon: One World

-- MAIN APPLICATION
addappid(1246870)
addappid(1423950)
addappid(1423951)
addappid(1423952)
addappid(1423953)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246871, 1, "6370da18e8218e6dd79df3c69cc65dafadacbc92c0a4c17b00a4597440ed776f")

