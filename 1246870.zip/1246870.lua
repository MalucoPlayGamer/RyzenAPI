-- Lua provided by RyzenAPI
-- Game: addappid(1246870)

-- MAIN APPLICATION
addappid(1246870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246871, 1, "6370da18e8218e6dd79df3c69cc65dafadacbc92c0a4c17b00a4597440ed776f")
