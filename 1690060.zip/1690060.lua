-- Lua provided by RyzenAPI
-- Game: Gelly Break Deluxe

-- MAIN APPLICATION
addappid(1690060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1690061, 1, "33ad491e6f9e3e75254d3c96a7fc9105ae6610ef86e3038ae66c25f9509755b1")

