-- Lua provided by SkyAPI 
-- Game: Gelly Break Deluxe
addappid(1690060)
addappid(1690061, 1, "33ad491e6f9e3e75254d3c96a7fc9105ae6610ef86e3038ae66c25f9509755b1")
