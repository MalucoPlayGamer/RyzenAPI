-- Lua provided by RyzenAPI
-- Game: addappid(1690060)

-- MAIN APPLICATION
addappid(1690060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1690061, 1, "33ad491e6f9e3e75254d3c96a7fc9105ae6610ef86e3038ae66c25f9509755b1")
