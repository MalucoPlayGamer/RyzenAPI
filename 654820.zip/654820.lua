-- Lua provided by RyzenAPI
-- Game: 654820

-- MAIN APPLICATION
addappid(654820)
-- Game: addappid(654820)

-- MAIN APP DEPOTS / PACKAGES
addappid(654821, 1, "9137f18cc7cc861534c6ef2004ad6a528b7a6af4d370f90e376b6d1d9e10909d")
