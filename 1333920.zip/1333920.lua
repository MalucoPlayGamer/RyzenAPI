-- Lua provided by RyzenAPI
-- Game: A Place, Forbidden

-- MAIN APPLICATION
addappid(1333920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333921, 1, "b7eb0dbb49e307340a6429742e971a1a0c5594f52c5b24709282cdf229c964c7")

