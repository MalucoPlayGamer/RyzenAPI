-- Lua provided by RyzenAPI
-- Game: AppID 1097590

-- MAIN APPLICATION
addappid(1097590)
-- Game: addappid(1097590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097591, 1, "3b2a54923bc7c758365a05abbc605243cd9d94fcc230172e25d5a8c773af60ba")
