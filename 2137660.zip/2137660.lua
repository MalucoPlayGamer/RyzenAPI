-- Lua provided by RyzenAPI
-- Game: addappid(2137660)

-- MAIN APPLICATION
addappid(2137660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137661, 1, "8aa4b9111b5c939e8626375e9306e9cf8f2c45ebb5efaed4010c8121e337086c")
