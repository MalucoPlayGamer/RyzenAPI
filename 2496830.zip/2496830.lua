-- Lua provided by RyzenAPI
-- Game: 2496830

-- MAIN APPLICATION
addappid(2496830)
-- Game: addappid(2496830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2496831, 1, "87c0de37c34fb7cde418e0c1f6aaaaa587163d2d27a76951c33a87b64c3ce561")
