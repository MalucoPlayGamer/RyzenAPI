-- Lua provided by RyzenAPI
-- Game: Lawnmower Game 2: Drifter

-- MAIN APPLICATION
addappid(749550)

-- MAIN APP DEPOTS / PACKAGES
addappid(749551, 1, "fdd43f44eedb3cee93e708becae4add3b548f7eb5e9e4c59da3a43a2b0f06c74")
