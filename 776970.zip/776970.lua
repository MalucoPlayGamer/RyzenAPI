-- Lua provided by SkyAPI 
-- Game: AppID 776970
addappid(776970)
addappid(776971, 1, "163f091e3780040893c26085ebf5a1d2069554932e9f4966c879d008459758c6")
