-- Lua provided by RyzenAPI
-- Game: Scary new year

-- MAIN APPLICATION
addappid(776970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(776971, 1, "163f091e3780040893c26085ebf5a1d2069554932e9f4966c879d008459758c6")

