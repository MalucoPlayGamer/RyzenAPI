-- Lua provided by RyzenAPI
-- Game: Red Haze

-- MAIN APPLICATION
addappid(428860)
addappid(1553270)

-- MAIN APP DEPOTS / PACKAGES
addappid(428861, 1, "1d77a40ba6e74f4d5f551ff866d493db0ba661f270d570710e818c5363f3b693")
