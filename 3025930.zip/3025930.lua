-- Lua provided by RyzenAPI
-- Game: Game: AppID 3025930

-- MAIN APPLICATION
addappid(3025930)
-- Game: addappid(3025930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3025931, 1, "55e1044468f704bf3b822deb8d1b9729cab3f57cb0b61dcad7e2cdcd608e8a51")
