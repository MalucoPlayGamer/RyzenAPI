-- Lua provided by RyzenAPI
-- Game: TWA - First Haul

-- MAIN APPLICATION
addappid(3694620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3694621, 1, "6aafbfbd8b7058cd9abc8e2285a3f1dff2c85d8b1f9000106692739cb5ea02e1")
