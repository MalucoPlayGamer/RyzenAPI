-- Lua provided by RyzenAPI
-- Game: ALTAIR BREAKER

-- MAIN APPLICATION
addappid(1909820)
addappid(2123130)
addappid(2137230)
addappid(2162640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1909821, 1, "57f97c40822b53dc9ae7f5f1907a2c1a06ba49b96c991ae2d3efd3ee45059fec")

