-- Lua provided by RyzenAPI 
-- Game: ALTAIR BREAKER
addappid(1909820)
addappid(1909821, 1, "57f97c40822b53dc9ae7f5f1907a2c1a06ba49b96c991ae2d3efd3ee45059fec")
