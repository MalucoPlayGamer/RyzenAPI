-- Lua provided by RyzenAPI
-- Game: AppGameKit Studio - MEGA Media Pack

-- MAIN APPLICATION
addappid(1107700)
-- Game: addappid(1107700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1107700,0,"6c34ccbd06a212f91ce657b4111f5e6d2a05de411b576da741c5f84de903d31e")
