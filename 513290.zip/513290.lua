-- Lua provided by RyzenAPI
-- Game: Game: AppID 513290

-- MAIN APPLICATION
addappid(513290)
-- Game: addappid(513290)

-- MAIN APP DEPOTS / PACKAGES
addappid(513291, 1, "6425e4416cefc0fe94d6337364cc6749165a2912c7e469709aa2a259febad6bc")
