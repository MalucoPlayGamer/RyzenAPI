-- Lua provided by RyzenAPI
-- Game: addappid(2011230)

-- MAIN APPLICATION
addappid(2011230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011231, 1, "a556a281fada2c98e1be704951cc48c63df24ebc4a61dc3283073bbd7845d348")
