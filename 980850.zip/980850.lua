-- Lua provided by RyzenAPI
-- Game: AppID 980850

-- MAIN APPLICATION
addappid(980850)
addappid(1018670)

-- MAIN APP DEPOTS / PACKAGES
addappid(980851, 1, "bea55918c9d1edb079dc439619ad7cdefc8232faa81f6920eeef16964ea8dd41")

