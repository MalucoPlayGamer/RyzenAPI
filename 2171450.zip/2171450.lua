-- Lua provided by RyzenAPI
-- Game: Bizarr Adventure

-- MAIN APPLICATION
addappid(2171450)
-- Game: addappid(2171450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171451, 1, "d9a28f239ecfab8f3d84dbc644c6cfb8664d45822fe21bd67383c5b8836a996d")
