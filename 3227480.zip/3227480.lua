-- Lua provided by RyzenAPI
-- Game: 虎狼入侵（Monster Sect）- 山门与幻境

-- MAIN APPLICATION
addappid(3227480)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227480,0,"ba1dbc2707196bda0ba7d451b6a81412ed21c6d4f581d5c411674292da812ef3")
