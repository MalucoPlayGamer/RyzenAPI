-- Lua provided by RyzenAPI
-- Game: Russian roulette

-- MAIN APPLICATION
addappid(949630)

-- MAIN APP DEPOTS / PACKAGES
addappid(949631, 1, "d3cf2898899462e44b01338dc3c84d36e7d5b6b923444151cc16ebbcb3c1c553")
