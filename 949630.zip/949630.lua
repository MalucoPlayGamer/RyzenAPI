-- Lua provided by SkyAPI 
-- Game: Russian roulette
addappid(949630)
addappid(949631, 1, "d3cf2898899462e44b01338dc3c84d36e7d5b6b923444151cc16ebbcb3c1c553")
