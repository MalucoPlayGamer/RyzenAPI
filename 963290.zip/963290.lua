-- Lua provided by RyzenAPI
-- Game: Heroes of Fortunia

-- MAIN APPLICATION
addappid(963290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(963291, 1, "1bd930963c654e15acd6cdaf6308ebcc086bc48a9b250179e0df4628e2949468")
