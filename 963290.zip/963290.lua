-- Lua provided by RyzenAPI
-- Game: Game: AppID 963290

-- MAIN APPLICATION
addappid(963290)
-- Game: addappid(963290)

-- MAIN APP DEPOTS / PACKAGES
addappid(963291, 1, "1bd930963c654e15acd6cdaf6308ebcc086bc48a9b250179e0df4628e2949468")
