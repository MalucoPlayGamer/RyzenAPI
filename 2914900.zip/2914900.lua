-- Lua provided by RyzenAPI
-- Game: addappid(2914900)

-- MAIN APPLICATION
addappid(2914900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2914901, 1, "03388eeb53afccb2c2f23198aec94273a51c8ee9c74984ad2b22d124cd6d63b6")
addappid(2914902, 1, "339734b6a82d24d9d82f4477ec85e03bd30616bc1e3b3bc72adffe09ed4cb36e")
