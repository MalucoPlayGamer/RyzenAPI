-- Lua provided by RyzenAPI
-- Game: TORIDAMA: Brave Challenge

-- MAIN APPLICATION
addappid(2365880)
-- Game: addappid(2365880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2365881, 1, "a06c81a16b534fc89a648cb85cafa8b6aaa93bb0fe9e2aac2fe7c193ce643b8a")
