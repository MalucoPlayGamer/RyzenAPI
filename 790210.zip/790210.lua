-- Lua provided by RyzenAPI
-- Game: addappid(790210)

-- MAIN APPLICATION
addappid(790210)

-- MAIN APP DEPOTS / PACKAGES
addappid(790211, 1, "50f2e91042ddecd605f7336d1acf6b57c9b4a01944136af2808d66a964c07412")
