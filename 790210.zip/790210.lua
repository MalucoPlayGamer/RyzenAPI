-- Lua provided by RyzenAPI 
-- Game: AppID 790210
addappid(790210)
addappid(790211, 1, "50f2e91042ddecd605f7336d1acf6b57c9b4a01944136af2808d66a964c07412")
