-- Lua provided by RyzenAPI
-- Game: AppID 1209330

-- MAIN APPLICATION
addappid(1209330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1209331, 1, "a7aabfeca0db515fc7fcdbd6fe151eb42a71b0894bc953cfbf078398b471735c")
