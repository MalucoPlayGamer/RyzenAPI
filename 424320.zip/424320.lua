-- Lua provided by SkyAPI 
-- Game: Anomaly 1729
addappid(424320)
addappid(424321, 1, "99bc7f962c257234a8bd1b60bece74efe90fe18744bf0507c045be23825c9755")
