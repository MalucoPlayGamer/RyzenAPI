-- Lua provided by RyzenAPI
-- Game: Anomaly 1729

-- MAIN APPLICATION
addappid(424320)

-- MAIN APP DEPOTS / PACKAGES
addappid(424321, 1, "99bc7f962c257234a8bd1b60bece74efe90fe18744bf0507c045be23825c9755")

