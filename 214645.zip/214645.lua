-- Lua provided by RyzenAPI
-- Game: 214645

-- MAIN APPLICATION
addappid(214645)
-- Game: addappid(214645)

-- MAIN APP DEPOTS / PACKAGES
addappid(214645,0,"6b22dcf0120eec6c5325356e6f881820c99d077ce7a358b2bf7023447f51f672")
