-- Lua provided by RyzenAPI 
-- Game: Potion Tycoon
addappid(1485690)
addappid(1485691, 1, "74a35a5e7fd10a48ec9f16870df9575e1389402128f49fef01a6e5ca65a3a282")
addappid(2239080, 0, "845274ae026e4eee4d1f9acab311bbffe8fcb552b8a878898066b472e97c20c5")
addappid(2239081, 0, "82c4137c68eaaabd30476fe11bdcee3b17fb3831d13ea0236a03b48154d6b63b")
