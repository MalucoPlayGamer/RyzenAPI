-- Lua provided by RyzenAPI
-- Game: 1403190

-- MAIN APPLICATION
addappid(1403190)
-- Game: addappid(1403190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403191, 1, "b77b80cdacd339fb34175a257e0791b4ec7a6ea668d5f256bbf3a69a7c482075")
