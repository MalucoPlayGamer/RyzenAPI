-- Lua provided by RyzenAPI
-- Game: AppID 1403190

-- MAIN APPLICATION
addappid(1403190)
addappid(1430770)
addappid(1430830)
addappid(1430840)
addappid(1430850)
addappid(1430860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1403191, 1, "b77b80cdacd339fb34175a257e0791b4ec7a6ea668d5f256bbf3a69a7c482075")

