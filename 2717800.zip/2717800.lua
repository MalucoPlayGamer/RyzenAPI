-- Lua provided by RyzenAPI
-- Game: Project Vic

-- MAIN APPLICATION
addappid(2717800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2717801, 1, "af19ba5634d6c9ac83c3c683bacb32d20adcaf557fa0e85ee4a41698611576a8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
