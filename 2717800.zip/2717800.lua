-- Lua provided by SkyAPI 
-- Game: Project Vic
addappid(2717800)
addappid(2717801, 1, "af19ba5634d6c9ac83c3c683bacb32d20adcaf557fa0e85ee4a41698611576a8")
