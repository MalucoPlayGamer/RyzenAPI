-- Lua provided by RyzenAPI
-- Game: Shell Girls in Puzzle Skulls

-- MAIN APPLICATION
addappid(1926340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926341, 1, "50efd465219316943ca455521b27292ab4c214f6f72a21181947e5f22f920b3d")
