-- Lua provided by RyzenAPI
-- Game: Membrillo Hid My Socks

-- MAIN APPLICATION
addappid(4075590)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4693670)
