-- Lua provided by RyzenAPI
-- Game: Membrillo Hid My Socks

-- MAIN APPLICATION
addappid(4075590)
addappid(4693670)

