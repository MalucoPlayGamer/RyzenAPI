-- Lua provided by RyzenAPI
-- Game: Sandboxels

-- MAIN APPLICATION
addappid(3664820)

-- MAIN APP DEPOTS / PACKAGES
addappid(3664821, 1, "a5f074a366a8dd4ab0bd26ffde13a7503f5081b8a683e089237f418194ee04c3")
