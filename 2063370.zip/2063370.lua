-- Lua provided by RyzenAPI
-- Game: Once in Yaissor 3

-- MAIN APPLICATION
addappid(2063370)
-- Game: addappid(2063370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063371, 1, "acc08ccaa8b0cb0e537f82ce043e2bf3cbcc7be44f432397916a5d8039cc80f2")
