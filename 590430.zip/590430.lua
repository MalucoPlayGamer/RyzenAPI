-- Lua provided by SkyAPI 
-- Game: AppID 590430
addappid(590430)
addappid(590431, 1, "b0a4e46545d9579446566b34a9a52ef13b98ee03c3ca183beec957a9f09f70d3")
