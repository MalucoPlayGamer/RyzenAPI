-- Lua provided by RyzenAPI
-- Game: addappid(590430)

-- MAIN APPLICATION
addappid(590430)

-- MAIN APP DEPOTS / PACKAGES
addappid(590431, 1, "b0a4e46545d9579446566b34a9a52ef13b98ee03c3ca183beec957a9f09f70d3")
