-- Lua provided by RyzenAPI
-- Game: 963330

-- MAIN APPLICATION
addappid(963330)
-- Game: addappid(963330)

-- MAIN APP DEPOTS / PACKAGES
addappid(963331, 1, "1ec456d2b2ea38bf43172e6b6d65af62aeb687266322ffc1df8482d9069984ec")
