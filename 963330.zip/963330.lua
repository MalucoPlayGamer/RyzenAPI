-- Lua provided by RyzenAPI
-- Game: Nya Nya Nya Girls (ʻʻʻ)_(=^･ω･^=)_(ʻʻʻ)

-- MAIN APPLICATION
addappid(963330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(963331,0,"1ec456d2b2ea38bf43172e6b6d65af62aeb687266322ffc1df8482d9069984ec")
addappid(997470,0,"20fd1e228c01c6db82299fdef85f1f7d60f6a4447e1020795c646cd7967c3fbf")
addappid(1082040,0,"a9276e0f4b44786a04eeab742d5e6d998f9ca859d1181bce1e12ca2591802a6a")

