-- Lua provided by RyzenAPI
-- Game: Nya Nya Nya Girls (ʻʻʻ)_(=^･ω･^=)_(ʻʻʻ)

-- MAIN APPLICATION
addappid(963330)

-- MAIN APP DEPOTS / PACKAGES
addappid(963331,0,"1ec456d2b2ea38bf43172e6b6d65af62aeb687266322ffc1df8482d9069984ec")
addappid(997470,0,"20fd1e228c01c6db82299fdef85f1f7d60f6a4447e1020795c646cd7967c3fbf")
addappid(1082040,0,"a9276e0f4b44786a04eeab742d5e6d998f9ca859d1181bce1e12ca2591802a6a")

