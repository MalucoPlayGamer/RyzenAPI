-- Lua provided by SkyAPI 
-- Game: AppID 963330
addappid(963330)
addappid(963331, 1, "1ec456d2b2ea38bf43172e6b6d65af62aeb687266322ffc1df8482d9069984ec")
