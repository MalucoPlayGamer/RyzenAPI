-- Lua provided by RyzenAPI
-- Game: Taxi Simulator

-- MAIN APPLICATION
addappid(1711120)
-- Game: addappid(1711120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1711121, 1, "83252a9580adb0191ce22ae296a2cd64458c106724357215619005cbde3de46c")
