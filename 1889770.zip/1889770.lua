-- Lua provided by SkyAPI 
-- Game: BALLYGON
addappid(1889770)
addappid(1889771, 1, "e0b2da74643a188e4948a67b28b28a6404ffc5606ca5c9a97bab8b60266c3953")
