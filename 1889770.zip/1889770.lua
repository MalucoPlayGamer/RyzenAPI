-- Lua provided by RyzenAPI
-- Game: 1889770

-- MAIN APPLICATION
addappid(1889770)
-- Game: addappid(1889770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889771, 1, "e0b2da74643a188e4948a67b28b28a6404ffc5606ca5c9a97bab8b60266c3953")
