-- Lua provided by RyzenAPI
-- Game: Game: AppID 1018830

-- MAIN APPLICATION
addappid(1018830)
addappid(2177070)
-- Game: addappid(1018830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018831, 1, "9cfd46decc3bdc0ad8d28547e5b9733cc47af33a38fa98294c00150ce3afcc06")
