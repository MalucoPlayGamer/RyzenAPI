-- Lua provided by RyzenAPI
-- Game: Game: AppID 580990

-- MAIN APPLICATION
addappid(580990)
-- Game: addappid(580990)

-- MAIN APP DEPOTS / PACKAGES
addappid(580991, 1, "3251b1c4d72ea17c9e45b3b94e0341a61fe5305d9f0dabc93f6b7b8892d19636")
