-- Lua provided by RyzenAPI
-- Game: Eternity Warriors VR

-- MAIN APPLICATION
addappid(664090)
-- Game: addappid(664090)

-- MAIN APP DEPOTS / PACKAGES
addappid(664091, 1, "e43aeec7bee1f7eac7efb986cd02eb3c50cb96d7dd5d002bb8d34db2a0366c7d")
