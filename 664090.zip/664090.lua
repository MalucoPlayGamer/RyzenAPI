-- Lua provided by RyzenAPI
-- Game: Eternity Warriors VR

-- MAIN APPLICATION
addappid(664090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(664091, 1, "e43aeec7bee1f7eac7efb986cd02eb3c50cb96d7dd5d002bb8d34db2a0366c7d")

