-- Lua provided by RyzenAPI
-- Game: Conductor

-- MAIN APPLICATION
addappid(584930)

-- MAIN APP DEPOTS / PACKAGES
addappid(584931,0,"b3ff265d01eca26fa1289a89e238a9c211fdcc4acf7eae359cfbadf698bc05e0")

