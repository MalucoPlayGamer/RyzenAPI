-- Lua provided by RyzenAPI
-- Game: Game: Samurai Sword Stage

-- MAIN APPLICATION
addappid(2294030)
-- Game: addappid(2294030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2294031, 1, "8d7f26a798fbde151da0a80c6765b6af6408ab1f86eab90a7ff76c4cc871fcda")
