-- Lua provided by RyzenAPI
-- Game: Cave Runner

-- MAIN APPLICATION
addappid(763400)

-- MAIN APP DEPOTS / PACKAGES
addappid(763401, 1, "c9768ec5d0c930d243520f68b0c8e8339313457c3d80f416a16dc2981e5d31b0")

