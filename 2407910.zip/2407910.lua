-- Lua provided by RyzenAPI
-- Game: Racket Club

-- MAIN APPLICATION
addappid(2407910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407911, 1, "8b22b457d184fd412504af6682eced1b534e6b2042feb067d176cc77141634ed")

