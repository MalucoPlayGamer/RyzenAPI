-- Lua provided by RyzenAPI 
-- Game: inbento
addappid(1567440)
addappid(1567441, 1, "7862bab972fb6ed6a047521f8b3ff72ad9d65a6ef6faeb111e0c5770a0d09e13")
addappid(1567442, 1, "c20f8243e93de7de9ed30da5a83fee6a153585d1dbd90d5074f8afd27188f110")
