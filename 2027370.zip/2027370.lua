-- Lua provided by RyzenAPI
-- Game: Ball Torture

-- MAIN APPLICATION
addappid(2027370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027371, 1, "c63bd45e0a08fe3f0bfc59e0ddb8fae755b0b3b4f5cd85bcd315ea331f715254")

