-- Lua provided by RyzenAPI
-- Game: Unusual Findings

-- MAIN APPLICATION
addappid(1605320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1605321, 1, "68809fc4a9984429e02d397a88d444b851fc39f3aaf1caf8cd10d2d099b0b8b0")

