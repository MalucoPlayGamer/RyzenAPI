-- Lua provided by RyzenAPI
-- Game: Master Magistrate

-- MAIN APPLICATION
addappid(1066630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066631, 1, "4833965e25fac60c05374b668fbbbad07d4a6166cbe4e9d81c48282b45cb8d8d")

