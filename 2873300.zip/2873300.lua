-- Lua provided by RyzenAPI
-- Game: Mannequin House

-- MAIN APPLICATION
addappid(2873300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2873301, 1, "ec002e5421a2e4fe27d776c281c5ead0ad85f03355dd8197d171c2b1161d3393")

