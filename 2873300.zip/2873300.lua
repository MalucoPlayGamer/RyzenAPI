-- Lua provided by RyzenAPI
-- Game: Mannequin House

-- MAIN APPLICATION
addappid(2873300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2873301, 1, "ec002e5421a2e4fe27d776c281c5ead0ad85f03355dd8197d171c2b1161d3393")

