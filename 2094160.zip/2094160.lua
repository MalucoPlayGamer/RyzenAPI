-- Lua provided by RyzenAPI
-- Game: GHOSTKEEPER

-- MAIN APPLICATION
addappid(2094160)
-- Game: addappid(2094160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094161, 1, "acab1f2e550394dc00626fb9703cd8bbf4c210805864d2d33a158496c3ce4f3d")
