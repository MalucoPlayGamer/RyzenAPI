-- Lua provided by SkyAPI 
-- Game: PAL
addappid(2174080)
addappid(2174081, 1, "02de5065256fa0915ecbd70c674684325b93b94529e6e36ae3982a5f88e4ddc5")
