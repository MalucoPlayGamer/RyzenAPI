-- Lua provided by RyzenAPI
-- Game: addappid(2174080)

-- MAIN APPLICATION
addappid(2174080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2174081, 1, "02de5065256fa0915ecbd70c674684325b93b94529e6e36ae3982a5f88e4ddc5")
