-- Lua provided by RyzenAPI
-- Game: 348860

-- MAIN APPLICATION
addappid(348860)
-- Game: addappid(348860)

-- MAIN APP DEPOTS / PACKAGES
addappid(348861, 1, "ae57d53f69945830a7790c9c83f9c7b01c0463a0b77a29a8b2ef26f3f7064667")
addappid(348864, 1, "cbd34d8420ed236681af4b15eb8c31e1e86ce0e9dde0fc51d0e9aa78ed3ea773")
