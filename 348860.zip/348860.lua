-- Lua provided by RyzenAPI
-- Game: MyDream

-- MAIN APPLICATION
addappid(348860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(348861, 1, "ae57d53f69945830a7790c9c83f9c7b01c0463a0b77a29a8b2ef26f3f7064667")
addappid(348864, 1, "cbd34d8420ed236681af4b15eb8c31e1e86ce0e9dde0fc51d0e9aa78ed3ea773")
