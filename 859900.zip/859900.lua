-- Lua provided by RyzenAPI
-- Game: Owen to have fun!

-- MAIN APPLICATION
addappid(859900)

-- MAIN APP DEPOTS / PACKAGES
addappid(859901, 1, "28a7382b16272a0a9b03fc605b8c242ff0c69487391faa224c94217940405654")

