-- Lua provided by RyzenAPI
-- Game: Hentai Fetish Tycoon

-- MAIN APPLICATION
addappid(1147670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147672,0,"910b431ed5f6d8b87fe4c8e432ba68f47e83bd47a76200d6113f6b2b2f62ffea")

