-- Lua provided by RyzenAPI
-- Game: Game: AppID 1143680

-- MAIN APPLICATION
addappid(1143680)
-- Game: addappid(1143680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1143681, 1, "4d4d21b4d16328cb0a119f873976f735e18fb2acaf76a6ec2346a58ca0962896")
