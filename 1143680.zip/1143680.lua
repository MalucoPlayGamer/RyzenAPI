-- Lua provided by SkyAPI 
-- Game: AppID 1143680
addappid(1143680)
addappid(1143681, 1, "4d4d21b4d16328cb0a119f873976f735e18fb2acaf76a6ec2346a58ca0962896")
