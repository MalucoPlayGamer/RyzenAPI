-- Lua provided by RyzenAPI
-- Game: Game: Chiyo

-- MAIN APPLICATION
addappid(2220660)
-- Game: addappid(2220660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2220661, 1, "0c17849a8d0ca827ccb51d7d3f94c2cf005ad1c8dec28d65209f20e38e786a0c")
