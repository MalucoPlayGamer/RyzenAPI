-- Lua provided by RyzenAPI
-- Game: Chiyo

-- MAIN APPLICATION
addappid(2220660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2220661, 1, "0c17849a8d0ca827ccb51d7d3f94c2cf005ad1c8dec28d65209f20e38e786a0c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
