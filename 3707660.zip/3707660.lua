-- Lua provided by RyzenAPI
-- Game: Horrorillo Brainrotillo

-- MAIN APPLICATION
addappid(3707660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3707661, 1, "c66a0f27cc7080109aae3c0c8e587b94e9f49ed091024484fa05d4d8fb7409b4")

