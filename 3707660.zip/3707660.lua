-- Lua provided by SkyAPI 
-- Game: Horrorillo Brainrotillo
addappid(3707660)
addappid(3707661, 1, "c66a0f27cc7080109aae3c0c8e587b94e9f49ed091024484fa05d4d8fb7409b4")
