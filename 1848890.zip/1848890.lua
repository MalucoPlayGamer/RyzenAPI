-- Lua provided by RyzenAPI
-- Game: Game: AppID 1848890

-- MAIN APPLICATION
addappid(1848890)
-- Game: addappid(1848890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1848891, 1, "ae5e54070087a7b77f96e4e0446d87e26e23132754ad0b2f390ffcce0bbbf093")
