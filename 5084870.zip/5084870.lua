-- Lua provided by RyzenAPI
-- Game: Judge SIM 2 Precedent

-- MAIN APPLICATION
addappid(5084870) -- Judge SIM 2 Precedent

-- MAIN APP DEPOTS / PACKAGES
addappid(5084871, 1, "acce8899edb6f5f6570481766feaf6512f3c5014e05ee9a5037fcddd9217e327") -- Depot 5084871
