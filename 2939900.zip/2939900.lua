-- Lua provided by SkyAPI 
-- Game: Chupacabra Hunt
addappid(2939900)
addappid(2939901, 1, "07046aa062f4951907487e746145b2542362cd8b7d58d481257d8164fea0ce14")
addappid(3030540, 0, "78639d49216c93555d8b69a4ffceffc719c2cc74c7a4a6b7fae312fce6a6f212")
