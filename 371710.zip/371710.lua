-- Lua provided by RyzenAPI
-- Game: 371710

-- MAIN APPLICATION
addappid(371710)
-- Game: addappid(371710)

-- MAIN APP DEPOTS / PACKAGES
addappid(371711, 1, "eb98460f4f99f3f02aa151f5e594e9ca9bd257cf671c73f2a12912dee5d717fd")
