-- Lua provided by RyzenAPI
-- Game: MGCM Combat Edition

-- MAIN APPLICATION
addappid(2509830)
addappid(2655200)
addappid(2841100)
addappid(3056210)
addappid(3384460)
addappid(3969040)
addappid(4252190)
addappid(4903590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2509831, 1, "ddf9418ea56745fc28d1367963fc9aa06199028f40612a60e932f339fb9e4e53")

