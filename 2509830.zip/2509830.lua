-- Lua provided by RyzenAPI
-- Game: MGCM Combat Edition

-- MAIN APPLICATION
addappid(2509830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2509831, 1, "ddf9418ea56745fc28d1367963fc9aa06199028f40612a60e932f339fb9e4e53")

