-- Lua provided by RyzenAPI
-- Game: Amber City

-- MAIN APPLICATION
addappid(1979320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1979321, 1, "acbb7f2b7917baba597c6abf590b8aa6ed5eb42de29142eac08aab17a52d01fa")
