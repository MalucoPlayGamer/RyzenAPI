-- Lua provided by RyzenAPI
-- Game: addappid(1299170)

-- MAIN APPLICATION
addappid(1299170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299171, 1, "502957fb11cef8433db5c052857c97adab082add8bb8688dcc50c2eea1e366ff")
