-- Lua provided by RyzenAPI
-- Game: Sexual Massage Shop - AKARI -

-- MAIN APPLICATION
addappid(2395530)
-- Game: addappid(2395530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395531, 1, "4a728881c5be5c3ff0ee37b7403b3d3ef0353bb618d594abe298cf291722444a")
