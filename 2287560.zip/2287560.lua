-- Lua provided by RyzenAPI
-- Game: Vengeance of Mr. Peppermint

-- MAIN APPLICATION
addappid(2287560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2287563,0,"14144bac03728ac79ff652a87d76d307a0a90957f3573a09113d6e407637c7d0")

