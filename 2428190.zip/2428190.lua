-- Lua provided by RyzenAPI
-- Game: 2428190

-- MAIN APPLICATION
addappid(2428190)
-- Game: addappid(2428190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2428192,0,"3ca1a4517bc0236c5f7a70d8efc6972b78faced5c49f9ad7f9e799be32e6d1a6")
addappid(2428193,0,"bed7b691ae8b0b6334cddccd538bc2846f79c155214fc2f4af5cd6b760cc76ff")
addappid(2428194,0,"a5e19ae5e5e370a2ba0887b185065908e9b71042cace1e3cb204b18a207da695")
