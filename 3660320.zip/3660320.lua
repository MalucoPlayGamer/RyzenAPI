-- Lua provided by RyzenAPI
-- Game: SkullX: Aibohphobia

-- MAIN APPLICATION
addappid(3660320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3660322,0,"0e6a3b170ed03b03253322ca30a349540560c582c11f6f53f63ee29265805b7d")

