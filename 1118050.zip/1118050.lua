-- Lua provided by RyzenAPI
-- Game: Terminal squad: Sentinel

-- MAIN APPLICATION
addappid(1118050)
-- Game: addappid(1118050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118051, 1, "d1a232f7a30663e5a3e76ba06752ff559929c389151fa7c72042827a05601f44")
