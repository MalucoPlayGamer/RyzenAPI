-- Lua provided by RyzenAPI
-- Game: addappid(1563850)

-- MAIN APPLICATION
addappid(1563850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563851, 1, "54334ae68ae55897974771e22665fd0750f2d8fc7cb6e35b2238ca572c40b3bd")
