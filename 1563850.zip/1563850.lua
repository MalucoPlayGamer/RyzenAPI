-- Lua provided by RyzenAPI
-- Game: DIY MY LADY

-- MAIN APPLICATION
addappid(1563850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563851, 1, "54334ae68ae55897974771e22665fd0750f2d8fc7cb6e35b2238ca572c40b3bd")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1698790)
addappid(1716090)
addappid(1719920)
addappid(1723640)
addappid(1733470)
addappid(1738250)
