-- Lua provided by SkyAPI 
-- Game: AppID 2610610
addappid(2610610)
addappid(2610611, 1, "d82ad8e824146a9c4254971b312d07500d8441a354f9a92b95dc861d8751afb4")
