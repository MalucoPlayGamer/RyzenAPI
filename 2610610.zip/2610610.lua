-- Lua provided by RyzenAPI
-- Game: Game: AppID 2610610

-- MAIN APPLICATION
addappid(2610610)
-- Game: addappid(2610610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2610611, 1, "d82ad8e824146a9c4254971b312d07500d8441a354f9a92b95dc861d8751afb4")
