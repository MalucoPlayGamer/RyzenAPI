-- Lua provided by RyzenAPI
-- Game: Everlasting Flowers - Where there is a will, there is a way

-- MAIN APPLICATION
addappid(2795270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2795271, 1, "e00d32ebb7c1f128f15517fd49a3bfca69057463a902f8228a09d52a334e71f9")
