-- Lua provided by RyzenAPI
-- Game: Guacamelee! Super Turbo Championship Edition

-- MAIN APPLICATION
addappid(275390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(275391, 1, "0790e1a35f308d218529fbc7247ea83010a8adc1e8f37db7c3af8568b2fe5ed7")
addappid(275392, 1, "05bd71ebc8fa55fcd9cad1b468a14d6af94fd1b6c2c1e6c2843e629a3c0b3301")

