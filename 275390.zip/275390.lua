-- Lua provided by RyzenAPI 
-- Game: Guacamelee! Super Turbo Championship Edition
addappid(275390)
addappid(275391, 1, "0790e1a35f308d218529fbc7247ea83010a8adc1e8f37db7c3af8568b2fe5ed7")
addappid(275392, 1, "05bd71ebc8fa55fcd9cad1b468a14d6af94fd1b6c2c1e6c2843e629a3c0b3301")
