-- Lua provided by RyzenAPI
-- Game: Hyperspacer

-- MAIN APPLICATION
addappid(2893850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2893851, 1, "91996985c8498057d83a1049ccfe9f2260f6031e201dcc8c99265bea6636994d")
