-- Lua provided by RyzenAPI
-- Game: 哀哭竜のメモリア

-- MAIN APPLICATION
addappid(2499210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499211, 1, "29ae41e0e106466569f5a84b5e22086b8f70fbddb2c809dcdbebe2e88683100d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
