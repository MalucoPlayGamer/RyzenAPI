-- Lua provided by RyzenAPI
-- Game: Game: 哀哭竜のメモリア

-- MAIN APPLICATION
addappid(2499210)
-- Game: addappid(2499210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2499211, 1, "29ae41e0e106466569f5a84b5e22086b8f70fbddb2c809dcdbebe2e88683100d")
