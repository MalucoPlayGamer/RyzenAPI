-- Lua provided by RyzenAPI
-- Game: 935930

-- MAIN APPLICATION
addappid(935930)
-- Game: addappid(935930)

-- MAIN APP DEPOTS / PACKAGES
addappid(935931, 1, "28e17d6e1d0b4279dc3d402d42b6c9b404e9dafc8a6694a86f57e3a38fe3e858")
