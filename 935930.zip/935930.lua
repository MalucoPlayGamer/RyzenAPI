-- Lua provided by RyzenAPI
-- Game: Reignfall

-- MAIN APPLICATION
addappid(935930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(935931, 1, "28e17d6e1d0b4279dc3d402d42b6c9b404e9dafc8a6694a86f57e3a38fe3e858")
