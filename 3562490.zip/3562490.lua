-- Lua provided by RyzenAPI
-- Game: Text To Speech

-- MAIN APPLICATION
addappid(3562490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3562491,0,"52556e6503a8cf98d0962242ab0b08639aa1c03b688626e16c2dac6ebbf496ab")

