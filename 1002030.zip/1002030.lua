-- Lua provided by RyzenAPI
-- Game: Hentai beautiful girls

-- MAIN APPLICATION
addappid(1002030)
-- Game: addappid(1002030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002031, 1, "daac047b0af91f9a3e22933021c64ae093b7127d23a39f399834f209748ff5d7")
addappid(1022190, 0, "e487d92b130bb51ee98ce4278837e6dfffeb9c98f4234456dc19724062f5402b")
addappid(1030050, 0, "aff6d553c92e0765a049e051cb8f8b9c547dc4cda2b14f5b095e5213ff114c07")
