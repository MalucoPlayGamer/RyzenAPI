-- Lua provided by RyzenAPI
-- Game: Sex with Teachers

-- MAIN APPLICATION
addappid(2109400)
-- Game: addappid(2109400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109401, 1, "cce54ea5047d276039b590bc3e621e6344ac68ad6f9cffeea2eea270f58069f5")
