-- Lua provided by RyzenAPI
-- Game: Interstate Drifter 1999

-- MAIN APPLICATION
addappid(1383770)

