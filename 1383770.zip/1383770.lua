-- Lua provided by RyzenAPI
-- Game: Interstate Drifter 1999

-- MAIN APPLICATION
addappid(1383770)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2705520)
