-- Lua provided by RyzenAPI 
-- Game: Crystal Cosmos
addappid(496590)
addappid(496591, 1, "cc0a8c7e29432199dcc76a61a31f50e71e31730eadfe82fb7b49aa4c96f9dc3f")
addappid(496592, 1, "c16ebc7634d60cdc894aa5c5c30806818dbc3c8a15aa1d3e6a30b52df58b007d")
addappid(496593, 1, "03f2a6c2f1fadb4ffecdd99eefa21b393d996ed471102dd58bb428acde126ee0")
