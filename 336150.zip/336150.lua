-- Lua provided by RyzenAPI
-- Game: Game: Virtual Pool 4

-- MAIN APPLICATION
addappid(336150)
-- Game: addappid(336150)

-- MAIN APP DEPOTS / PACKAGES
addappid(336151, 1, "3d37d0b2d4a76e71e7ae1269caee62742cb8fd2b3767ec34e71e7d25a9238487")
