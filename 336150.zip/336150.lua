-- Lua provided by SkyAPI 
-- Game: Virtual Pool 4
addappid(336150)
addappid(336151, 1, "3d37d0b2d4a76e71e7ae1269caee62742cb8fd2b3767ec34e71e7d25a9238487")
