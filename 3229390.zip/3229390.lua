-- Lua provided by SkyAPI 
-- Game: AppID 3229390
addappid(3229390)
addappid(3229391, 1, "2393ddeee05d1712a7c5b96cd20c51fbe690f6c797a8b3e2f8cc42e5ee73861c")
