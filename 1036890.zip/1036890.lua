-- Lua provided by RyzenAPI
-- Game: Shadow Warrior 3: Definitive Edition

-- MAIN APPLICATION
addappid(1036890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036891, 1, "7ca2b6eb406d1229cdcc327de2e3a707404c8478b4c1f063fbf144ee6f4b84c4")
addappid(1036892, 1, "1d2022c805822c1f5354bd6c971485ca02c01bf2f7345325c1535e08650f3713")

