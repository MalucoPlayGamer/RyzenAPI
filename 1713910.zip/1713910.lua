-- Lua provided by RyzenAPI
-- Game: Game: Robo-Boy  Risky Venture

-- MAIN APPLICATION
addappid(1713910)
-- Game: addappid(1713910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1713911, 1, "807a9ada45257059f5247a57a6368dc683f8ed1fb570b6328501b54251cd01e8")
