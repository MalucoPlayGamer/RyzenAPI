-- Lua provided by RyzenAPI
-- Game: Game: Subterraneus

-- MAIN APPLICATION
addappid(854120)
-- Game: addappid(854120)

-- MAIN APP DEPOTS / PACKAGES
addappid(854121, 1, "df19ddb224975dab266e7972b1148c2a3d8533ead4a4917bef58f7565eca7334")
