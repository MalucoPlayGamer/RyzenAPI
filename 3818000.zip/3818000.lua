-- Lua provided by RyzenAPI
-- Game: Guns and Nuns: Storming Hell

-- MAIN APPLICATION
addappid(3818000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3818001,0,"e4abb414e0a13a035d88a76c60fe8418c3c9b373e2e5adad24c0fc4032f48bac")

