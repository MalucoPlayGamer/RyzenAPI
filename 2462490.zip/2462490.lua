-- Lua provided by RyzenAPI
-- Game: addappid(2462490)

-- MAIN APPLICATION
addappid(2462490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2462491, 1, "aeb1f526b6194e9aff41a089faf5a9bfdfcb5e570eea8beb6a25716e63184e9f")
