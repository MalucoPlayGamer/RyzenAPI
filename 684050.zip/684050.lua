-- Lua provided by RyzenAPI
-- Game: addappid(684050)

-- MAIN APPLICATION
addappid(684050)

-- MAIN APP DEPOTS / PACKAGES
addappid(684051, 1, "2ec2f7df0694addc324ebbc27e41a28fd74eb5ed2d686363622eb678ae9abb28")
