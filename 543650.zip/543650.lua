-- Lua provided by RyzenAPI 
-- Game: Last Days
addappid(543650)
addappid(543651, 1, "3abf0c316186392b75441f9557b3250a3a80623c8da43636ffd8272480a326d3")
