-- Lua provided by RyzenAPI
-- Game: Dual Bus Simulator

-- MAIN APPLICATION
addappid(2616050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2616051, 1, "92d1bee6359d61678475aba746602ddcee1d2b50e66bd1fddaf632719431cc8d")

