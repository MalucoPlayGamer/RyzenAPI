-- Lua provided by SkyAPI 
-- Game: Make Way
addappid(1445790)
addappid(1445791, 1, "443955ed94898f46baf7dffc42b6771e7c8992f09619b9d62b22630a6693a721")
addappid(4060690)
