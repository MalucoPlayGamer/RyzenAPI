-- Lua provided by RyzenAPI
-- Game: 1445790

-- MAIN APPLICATION
addappid(1445790)
addappid(4060690)
-- Game: addappid(1445790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1445791, 1, "443955ed94898f46baf7dffc42b6771e7c8992f09619b9d62b22630a6693a721")
