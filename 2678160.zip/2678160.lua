-- Lua provided by RyzenAPI
-- Game: Pearls of Atlantis: The Cove

-- MAIN APPLICATION
addappid(2678160)
addappid(3980670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2678161, 1, "832ffe59e2094c634b63a0758f0d45f4adbd7dca659f649cd78948de146a2c83")

