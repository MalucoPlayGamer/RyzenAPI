-- Lua provided by RyzenAPI
-- Game: addappid(2413550)

-- MAIN APPLICATION
addappid(2413550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413550,0,"277b5a9cf4822906001b55cfb9ed099be873e7c56841773b4474bd6cb7fcf45f")
