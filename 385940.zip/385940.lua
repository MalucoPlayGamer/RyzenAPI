-- Lua provided by SkyAPI 
-- Game: Battles of the Ancient World
addappid(385940)
addappid(385941, 1, "50955d3a65f05a0cff46b9aeef0ff45a50886d8905da8c91a88b52c8698a5383")
addappid(385942, 1, "64138d41c613a2c9fa415b43144c3505c64ae4e12f787b479053f54747365926")
