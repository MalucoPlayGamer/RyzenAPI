-- Lua provided by RyzenAPI
-- Game: Battles of the Ancient World

-- MAIN APPLICATION
addappid(385940)

-- MAIN APP DEPOTS / PACKAGES
addappid(385941, 1, "50955d3a65f05a0cff46b9aeef0ff45a50886d8905da8c91a88b52c8698a5383")
addappid(385942, 1, "64138d41c613a2c9fa415b43144c3505c64ae4e12f787b479053f54747365926")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
