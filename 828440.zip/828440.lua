-- Lua provided by RyzenAPI
-- Game: 828440

-- MAIN APPLICATION
addappid(828440)
-- Game: addappid(828440)

-- MAIN APP DEPOTS / PACKAGES
addappid(828441, 1, "fc010e5d1110eb960705aab10f411679e16a9e723c5c5588df0b57fb7860f7c3")
