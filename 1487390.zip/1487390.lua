-- Lua provided by SkyAPI 
-- Game: ANVIL
addappid(1487390)
addappid(1487391, 1, "13cffd4a21a9b4679b7fef87794875191e677f670d35e697bd002aef9f1b1b38")
