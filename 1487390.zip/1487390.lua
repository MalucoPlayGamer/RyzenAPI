-- Lua provided by RyzenAPI
-- Game: ANVIL

-- MAIN APPLICATION
addappid(1487390)
addappid(1944170)
addappid(1944180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1487391, 1, "13cffd4a21a9b4679b7fef87794875191e677f670d35e697bd002aef9f1b1b38")

