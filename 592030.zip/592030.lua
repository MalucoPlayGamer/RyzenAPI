-- Lua provided by SkyAPI 
-- Game: AppID 592030
addappid(592030)
addappid(592031, 1, "9ef17ec21def7cbf39c6e6b7523aa9a514fd229d741a4a0f05a7cf7ebfb764f1")
