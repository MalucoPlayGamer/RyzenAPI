-- Lua provided by RyzenAPI
-- Game: Just In Time Incorporated

-- MAIN APPLICATION
addappid(592030)

-- MAIN APP DEPOTS / PACKAGES
addappid(592031, 1, "9ef17ec21def7cbf39c6e6b7523aa9a514fd229d741a4a0f05a7cf7ebfb764f1")

