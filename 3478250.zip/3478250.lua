-- Lua provided by RyzenAPI
-- Game: Tempest Rising - Digital Artbook

-- MAIN APPLICATION
addappid(3478250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3478250,0,"9e5ff25c95b392c64f062155f91ef29f7378057b6e0f5e2742daf764e74f0aa4")
addtoken(3478250,"832652260017266002")

