-- Lua provided by RyzenAPI
-- Game: The Falconeer: Revolution Remaster - Game Guide

-- MAIN APPLICATION
addappid(1434030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1434032,0,"8c54348f1a55488c827920fc9d4031bb7d6145c9f3903d5491a458cf7d15fe03")

