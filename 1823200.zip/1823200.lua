-- Lua provided by RyzenAPI
-- Game: Jumanji: Wild Adventures

-- MAIN APPLICATION
addappid(1823200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823201, 1, "497682a0fab5e4905582d39a019a05f4c5fed5585ee04cdeef91e797b8618328")
