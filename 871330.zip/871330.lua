-- Lua provided by RyzenAPI
-- Game: 871330

-- MAIN APPLICATION
addappid(871330)
-- Game: addappid(871330)

-- MAIN APP DEPOTS / PACKAGES
addappid(871331, 1, "055e702df730ff6718149cb388c00f7576c8e8008abab4bc61fa96f1f3a6f961")
addappid(871332, 1, "bbc297682da25cb70dc11d617c064f301ae1e3fdbefbf3d415976a3ee94f3840")
