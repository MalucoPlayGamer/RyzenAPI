-- Lua provided by RyzenAPI
-- Game: 1375370

-- MAIN APPLICATION
addappid(1375370)
-- Game: addappid(1375370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375370,0,"1150bc27f8bb7cd06b195b217b9ff9382635e74d30e1cb5e2c987a2839acb8c6")
