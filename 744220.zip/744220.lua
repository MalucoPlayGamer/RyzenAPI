-- Lua provided by RyzenAPI
-- Game: AI Dummy

-- MAIN APPLICATION
addappid(744220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(744221, 1, "fca089dddaf80a1965a5a3a7a16b56df96cbbc17aa32f80f6c617cd7e0a65657")

