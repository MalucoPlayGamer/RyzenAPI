-- Lua provided by RyzenAPI
-- Game: addappid(1699200)

-- MAIN APPLICATION
addappid(1699200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1699201, 1, "37a870a225e212ebbe9f8b8800411a43a6560969e6eb3d079cabf0d2b3b1d23f")
