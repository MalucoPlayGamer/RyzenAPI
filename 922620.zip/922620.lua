-- Lua provided by RyzenAPI
-- Game: addappid(922620)

-- MAIN APPLICATION
addappid(922620)

-- MAIN APP DEPOTS / PACKAGES
addappid(922621, 1, "0eecb44f9d8c5964d08dc78b0ed935869fe809d7382a6a35d9f3673eec1c4ceb")
