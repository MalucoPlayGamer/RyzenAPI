-- Lua provided by SkyAPI 
-- Game: Kingshunt
addappid(922620)
addappid(922621, 1, "0eecb44f9d8c5964d08dc78b0ed935869fe809d7382a6a35d9f3673eec1c4ceb")
