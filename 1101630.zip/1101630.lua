-- Lua provided by RyzenAPI
-- Game: A maze in Citadel

-- MAIN APPLICATION
addappid(1101630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101631, 1, "298f44cc01c20061b77417eaba54910eb6d66fb52a910d23a146e3c31cd589cf")
