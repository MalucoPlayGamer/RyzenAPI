-- Lua provided by RyzenAPI
-- Game: 779570

-- MAIN APPLICATION
addappid(779570)
-- Game: addappid(779570)

-- MAIN APP DEPOTS / PACKAGES
addappid(779571, 1, "2dfeb2284f192eddba1cd36110c24ae7708d3b4bc731536773c0a34a8c5d7f97")
