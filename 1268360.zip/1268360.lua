-- Lua provided by RyzenAPI 
-- Game: AppID 1268360
addappid(1268360)
addappid(1268361, 1, "26b6ec4f9a30cde13e1fef883dc44f0a30c3454cb21682e5a638ab31b6853aeb")
