-- Lua provided by RyzenAPI
-- Game: Meditation ~ Spiritual Journey (Removed From Store)

-- MAIN APPLICATION
addappid(1269870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269871, 1, "c036781fc99ae3863b73df1b641c43cd75721ac52717992d46471e55ce5954bb")

