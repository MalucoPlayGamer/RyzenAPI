-- Lua provided by RyzenAPI
-- Game: addappid(614004)

-- MAIN APPLICATION
addappid(614004)

-- MAIN APP DEPOTS / PACKAGES
addappid(615870,0,"f92d5fb663ffe3a3bda08705efb5368acef41491fdacf2fe29c39b21e49ac5bb")
