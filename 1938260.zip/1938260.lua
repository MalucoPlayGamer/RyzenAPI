-- Lua provided by RyzenAPI
-- Game: 起飞吧！兔兔

-- MAIN APPLICATION
addappid(1938260)
-- Game: addappid(1938260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1938261, 1, "e686298edb895af55199f967bf8c5ae5014b42926d359075e84a87378b8992ec")
