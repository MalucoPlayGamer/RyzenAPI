-- Lua provided by RyzenAPI
-- Game: Game: AppID 861560

-- MAIN APPLICATION
addappid(861560)
-- Game: addappid(861560)

-- MAIN APP DEPOTS / PACKAGES
addappid(861561, 1, "451fae3905ecf4f038d3a496595520525aa8cc4295717726370297a491e7a0a8")
