-- 1081450's Lua and Manifest Created by Hubcap Manifest
-- Criminal Dissidia
-- Created: March 16, 2026 at 15:27:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 11

-- MAIN APPLICATION
addappid(1081450, 1, "c597fd81b29f6e331122f6cc99f7ed3c0879e0d9048705f27f24f4de22a8dc3c") -- Criminal Dissidia
-- MAIN APP DEPOTS
addappid(1081451, 1, "9a926de7c5ce32c942698beecf0e5a0b8536cc887227d048e8ea70fb93839bc2") -- Depot 1081451
setManifestid(1081451, "5144986533811715502", 1530171236)
-- DLCS WITH DEDICATED DEPOTS
--   (AppID: 2167370)
addappid(2167370)
addappid(2167370, 1, "b3221c429aa257d73a6ad7a623546d272820e277516476d8bf9b51e5c72d47de") --   - Depot 2167370
setManifestid(2167370, "962594172911393207", 20426309)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2187480) -- 
addappid(2187490) -- 
addappid(2187500) -- 
addappid(2187510) -- 
addappid(2187520) -- 
addappid(2187530) -- 
addappid(2223250) -- 
addappid(2404440) -- 
addappid(2404450) -- 
addappid(2404460) -- 