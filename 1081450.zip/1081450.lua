-- Lua provided by RyzenAPI
-- Game: Criminal Dissidia

-- MAIN APPLICATION
addappid(1081450)
addappid(2167370)
addappid(2187480)
addappid(2187490)
addappid(2187500)
addappid(2187510)
addappid(2187520)
addappid(2187530)
addappid(2223250)
addappid(2404440)
addappid(2404450)
addappid(2404460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081451,0,"9a926de7c5ce32c942698beecf0e5a0b8536cc887227d048e8ea70fb93839bc2")
addappid(2167370,0,"b3221c429aa257d73a6ad7a623546d272820e277516476d8bf9b51e5c72d47de")

