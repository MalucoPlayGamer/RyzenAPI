-- Lua provided by SkyAPI 
-- Game: Survivors Will Demo
addappid(2442240)
addappid(2442241, 1, "7e1683354e7e0c64fae69f40af979b3d23234b66c239ba89d0ef10c30c825dfa")
