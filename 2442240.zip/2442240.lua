-- Lua provided by RyzenAPI
-- Game: Survivors Will Demo

-- MAIN APPLICATION
addappid(2442240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442241, 1, "7e1683354e7e0c64fae69f40af979b3d23234b66c239ba89d0ef10c30c825dfa")

