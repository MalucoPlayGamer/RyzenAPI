-- Lua provided by RyzenAPI
-- Game: Last Escape

-- MAIN APPLICATION
addappid(1398570)
-- Game: addappid(1398570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398571, 1, "4538ee9eceae821c37f6d743cfcabdf917b720738556b7644fbb0efbd615e96d")
