-- Lua provided by SkyAPI 
-- Game: Last Escape
addappid(1398570)
addappid(1398571, 1, "4538ee9eceae821c37f6d743cfcabdf917b720738556b7644fbb0efbd615e96d")
