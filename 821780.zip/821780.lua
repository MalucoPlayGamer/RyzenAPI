-- Lua provided by RyzenAPI
-- Game: AppID 821780

-- MAIN APPLICATION
addappid(821780)
-- Game: addappid(821780)

-- MAIN APP DEPOTS / PACKAGES
addappid(821781, 1, "2f362a1c8c0d76e0b8407803ab2e77c4b9be29a629febb3a6df702c4d0e13710")
