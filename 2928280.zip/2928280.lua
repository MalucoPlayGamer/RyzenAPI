-- Lua provided by RyzenAPI
-- Game: Crime Simulator: Playgrounds

-- MAIN APPLICATION
addappid(2928280)
-- Game: addappid(2928280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928281, 1, "420803afcfa6aad0d49ab5c933d63f73a2a541bd6d20c1e2030c53113c844006")
