-- Lua provided by RyzenAPI
-- Game: Breaking Survivors

-- MAIN APPLICATION
addappid(2468060)
-- Game: addappid(2468060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2468061, 1, "e5df1bfa140bf32e2fc97547145ac3341a868d1bb69f13eb0b68806fc25e112d")
