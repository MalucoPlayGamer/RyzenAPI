-- Lua provided by RyzenAPI
-- Game: Game: AX : PORTAL SLAYERS

-- MAIN APPLICATION
addappid(2879030)
-- Game: addappid(2879030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2879031, 1, "43f82ce42a946db193c8a40377ef2b45e200b63ecb1d48be26e571c44488e2bf")
