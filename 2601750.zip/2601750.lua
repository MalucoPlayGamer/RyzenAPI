-- Lua provided by RyzenAPI
-- Game: 2601750

-- MAIN APPLICATION
addappid(2601750)
-- Game: addappid(2601750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2601751, 1, "8674b89e1a4fffdb71d5b3db305bcbba1e34e7fcc706ed62e6a89a793b5e3206")
