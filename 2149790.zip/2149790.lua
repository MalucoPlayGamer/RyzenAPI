-- Lua provided by RyzenAPI
-- Game: Beautiful Mystic Survivors: Prologue

-- MAIN APPLICATION
addappid(2149790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2149791, 1, "fbfcd22986ecb22d5a40e37304d3e5e135fef23dfcff014baa3c578a983fa963")
