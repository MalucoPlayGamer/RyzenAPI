-- Lua provided by RyzenAPI
-- Game: addappid(2288990)

-- MAIN APPLICATION
addappid(2288990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2288991, 1, "f7acedbd8e057ea92305a15153939e0d43a2c6befd3ae4229959901fa3a716ad")
