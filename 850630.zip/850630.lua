-- Lua provided by RyzenAPI
-- Game: Game: AppID 850630

-- MAIN APPLICATION
addappid(850630)
-- Game: addappid(850630)

-- MAIN APP DEPOTS / PACKAGES
addappid(850631, 1, "30ab83ef73bd7c8d58b269720b4ada560aec73ec00b826636958a44fb814e1bc")
