-- Lua provided by RyzenAPI
-- Game: Escort Alia

-- MAIN APPLICATION
addappid(1265200)
addappid(2336510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1265201, 1, "fe2be6979b2af8e0fb89057f30b6380c90b7b35c501105954cccd100daecf8dd")

