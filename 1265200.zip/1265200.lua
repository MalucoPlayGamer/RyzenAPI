-- Lua provided by RyzenAPI 
-- Game: Escort Alia
addappid(1265200)
addappid(1265201, 1, "fe2be6979b2af8e0fb89057f30b6380c90b7b35c501105954cccd100daecf8dd")
addappid(2336510)
