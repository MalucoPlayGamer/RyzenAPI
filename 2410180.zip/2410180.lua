-- Lua provided by RyzenAPI
-- Game: Portal: Prelude RTX

-- MAIN APPLICATION
addappid(2410180)
-- Game: addappid(2410180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2410181, 1, "5f0784a26fa1f9d8ceeda65d3883465bfb0092ca66033826ff694aca0afc7595")
