-- Lua provided by RyzenAPI
-- Game: addappid(1347110)

-- MAIN APPLICATION
addappid(1347110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347111, 1, "e9ffbb39d926141fd7c399fd03a2f7dedf21c06163bc750b34c792f563b093ae")
