-- Lua provided by SkyAPI 
-- Game: Ice Star
addappid(1347110)
addappid(1347111, 1, "e9ffbb39d926141fd7c399fd03a2f7dedf21c06163bc750b34c792f563b093ae")
