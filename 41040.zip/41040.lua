-- Lua provided by RyzenAPI
-- Game: AppID 41040

-- MAIN APPLICATION
addappid(41040)
-- Game: addappid(41040)

-- MAIN APP DEPOTS / PACKAGES
addappid(41041, 1, "b3b1b34f7121bab962febd868bfb2fbbd12d9268f1e9141ae5f6a418bcc34a6f")
