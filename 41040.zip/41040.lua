-- Lua provided by SkyAPI 
-- Game: AppID 41040
addappid(41040)
addappid(41041, 1, "b3b1b34f7121bab962febd868bfb2fbbd12d9268f1e9141ae5f6a418bcc34a6f")
