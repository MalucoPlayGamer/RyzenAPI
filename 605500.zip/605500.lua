-- Lua provided by RyzenAPI
-- Game: Game: AppID 605500

-- MAIN APPLICATION
addappid(605500)
-- Game: addappid(605500)

-- MAIN APP DEPOTS / PACKAGES
addappid(605501, 1, "2a384c850e5148ce431473edd9a062d9ac7fbb7f642ff32697aeee4c4a1cb9cc")
