-- Lua provided by RyzenAPI
-- Game: AppID 1063530

-- MAIN APPLICATION
addappid(1063530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063531, 1, "ee8435a191bc6c3dba99e02c9f12387ffab2563d1e758f8cbdacb70dd432133b")

