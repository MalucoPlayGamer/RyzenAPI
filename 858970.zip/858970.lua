-- Lua provided by RyzenAPI
-- Game: Omensight - Original Soundtrack

-- MAIN APPLICATION
addappid(858970)

-- MAIN APP DEPOTS / PACKAGES
addappid(858970,0,"a03329468e02d77055a1d9e389fc801d14daa58ff37f70ea338b929a664c19da")
