-- Lua provided by RyzenAPI
-- Game: 混世萌王喵霸霸 Cute Chaos Demon Nyanbaba

-- MAIN APPLICATION
addappid(1191770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191771, 1, "86086cf2867409e1f3ded93ab33728ecf4e1f18eee39818830aa88dd6875a59d")
