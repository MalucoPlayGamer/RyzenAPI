-- Lua provided by RyzenAPI
-- Game: Grand Academy for Future Villains

-- MAIN APPLICATION
addappid(711240)

-- MAIN APP DEPOTS / PACKAGES
addappid(711241,0,"9a41e6695d6fb0611814a9d88e4e216db33edd15f94917c430d47fcf20d760c9")

