-- Lua provided by RyzenAPI 
-- Game: AppID 418070
addappid(418070)
addappid(418071, 1, "ccb9b980a7093c282650ce0ca4576c7a7e9711409cdd4ec934e78fff4d170f80")
addappid(418072, 1, "05acbc37a01c47e7b8e709253fb592c832ce820bdd9047931810722915407a2a")
