-- Lua provided by RyzenAPI
-- Game: 1222130

-- MAIN APPLICATION
addappid(1222130)
-- Game: addappid(1222130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1222131, 1, "e6fd5f119605c819dceccde91f16c1dcfbea07af24e2bf06223d38c68806c517")
