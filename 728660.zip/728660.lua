-- Lua provided by RyzenAPI
-- Game: addappid(728660)

-- MAIN APPLICATION
addappid(728660)

-- MAIN APP DEPOTS / PACKAGES
addappid(728661, 1, "2c2c73bc67725eb23bb725c3e1e9794d99613cd74289a21ecae997cf5a875b69")
