-- Lua provided by RyzenAPI
-- Game: Game: AppID 1260340

-- MAIN APPLICATION
addappid(1260340)
-- Game: addappid(1260340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1260341, 1, "5178035330a225ef8f1c3f629a3964cf3dc71ee105472d9b7b2ad797b31030a3")
