-- Lua provided by RyzenAPI
-- Game: The Dreamlord

-- MAIN APPLICATION
addappid(412290)

-- MAIN APP DEPOTS / PACKAGES
addappid(412291, 1, "8e6ea499152687dbe61e5248e860aa3b114fc97732c2236410ecae4b034bea25")

