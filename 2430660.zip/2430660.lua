-- Lua provided by SkyAPI 
-- Game: MiceGard
addappid(2430660)
addappid(2430661, 1, "5d846d6fb3b61aeacdf7478db3b8ed9639a282a593e62af4adc012801f33dded")
