-- Lua provided by RyzenAPI
-- Game: Drilly Willis Demo

-- MAIN APPLICATION
addappid(1548480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548481, 1, "89d848dd542d01a074f88f026385f26bd3b2c0ebf88c9863adc3a009b5caa8f9")
