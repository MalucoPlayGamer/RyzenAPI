-- 4479130's Lua and Manifest Created by Hubcap Manifest
-- Reveal Ball Pit: Defeated by Tentacles
-- Created: August 13, 2026 at 11:18:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4479130, 1, "45494da797a500bf3c7f2127f6d82ec7b1194e57efe23a10c85a725bf7221297") -- Reveal Ball Pit: Defeated by Tentacles
-- MAIN APP DEPOTS
addappid(4479131, 1, "6d7368f125646ef7e3e340d55dfbd38bd27bee02888df7443377cfa2b1480d80") -- Depot 4479131
setManifestid(4479131, "4035393878379680006", 837651895)