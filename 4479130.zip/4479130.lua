-- Lua provided by RyzenAPI
-- Game: Reveal Ball Pit: Defeated by Tentacles

-- MAIN APPLICATION
addappid(4987470)

-- MAIN APP DEPOTS / PACKAGES
addappid(4479130, 1, "45494da797a500bf3c7f2127f6d82ec7b1194e57efe23a10c85a725bf7221297") -- Reveal Ball Pit: Defeated by Tentacles
addappid(4479131, 1, "6d7368f125646ef7e3e340d55dfbd38bd27bee02888df7443377cfa2b1480d80") -- Depot 4479131

