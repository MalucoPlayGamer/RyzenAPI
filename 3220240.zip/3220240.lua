-- Lua provided by RyzenAPI
-- Game: Scotophobia Demo

-- MAIN APPLICATION
addappid(3220240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3220241, 1, "b9749f1cfbfb445d20ba8430d35c7421491c2505aaadcb2f86f03308481ac521")

