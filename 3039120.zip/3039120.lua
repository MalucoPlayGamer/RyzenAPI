-- Lua provided by RyzenAPI
-- Game: House Flipper 2 - Co-op Playtest

-- MAIN APPLICATION
addappid(3039120)
-- Game: addappid(3039120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3039121, 1, "519473b5e886543ba302de34b290bf1f344d77431094ca561ae419b5515f524f")
