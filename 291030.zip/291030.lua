-- Lua provided by RyzenAPI
-- Game: Always Remember Me

-- MAIN APPLICATION
addappid(291030)
addappid(294340)

-- MAIN APP DEPOTS / PACKAGES
addappid(291031, 1, "239d3d3d1d9daf7d5196d0f499eef4d13c3b11a6f46bf5e0c0a0ab4227e57bcc")
