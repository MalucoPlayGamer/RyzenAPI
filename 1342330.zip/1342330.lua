-- Lua provided by RyzenAPI
-- Game: 1342330

-- MAIN APPLICATION
addappid(1342330)
-- Game: addappid(1342330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1342331, 1, "c75c9cf0a536e729982dd29f2476c784caef6ab9e233d6b9d25c2a1b7327b837")
addappid(1342332, 1, "ead96be4d758e6cf07153cf48e9301ecd2b67ba61c0ee632ff4a96372eb2deca")
