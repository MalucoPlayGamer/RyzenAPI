-- Lua provided by RyzenAPI
-- Game: AppID 838270

-- MAIN APPLICATION
addappid(838270)

-- MAIN APP DEPOTS / PACKAGES
addappid(838271, 1, "fc8bc144c7630a4993203eb17bf5fdd5e62c55b99af3ea1df9af59ce62b5b074")
