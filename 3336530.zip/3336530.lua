-- Lua provided by RyzenAPI
-- Game: Embers Adrift

-- MAIN APPLICATION
addappid(3336530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3336531, 1, "d61eaa9efa46e92dafb506cf8b62380c12d5b52c3b7588e815f71e274b93f18e")
