-- Lua provided by RyzenAPI
-- Game: Q.U.B.E. 2

-- MAIN APPLICATION
addappid(359100)
addappid(822090)
addappid(822091)

-- MAIN APP DEPOTS / PACKAGES
addappid(359101, 1, "6734edf8d9dcee974c994bcbf72f73e70311ae27df15844b5091672e79efbda8")
addappid(822093, 0, "085d195a5f46d405a62255310d13e50942d2cc47f16546b127420a72bb5ea327")
addappid(822094, 0, "e59ea7013a9b1c8b7ad94716c4365e7190ee1168bf35a0860e5d14a53c02e05d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
