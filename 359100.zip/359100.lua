-- Lua provided by RyzenAPI
-- Game: Q.U.B.E. 2

-- MAIN APPLICATION
addappid(359100)
addappid(822090)
addappid(822091)
-- Game: addappid(359100)

-- MAIN APP DEPOTS / PACKAGES
addappid(359101, 1, "6734edf8d9dcee974c994bcbf72f73e70311ae27df15844b5091672e79efbda8")
addappid(822093, 0, "085d195a5f46d405a62255310d13e50942d2cc47f16546b127420a72bb5ea327")
addappid(822094, 0, "e59ea7013a9b1c8b7ad94716c4365e7190ee1168bf35a0860e5d14a53c02e05d")
