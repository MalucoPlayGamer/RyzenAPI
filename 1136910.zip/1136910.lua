-- Lua provided by RyzenAPI
-- Game: addappid(1136910)

-- MAIN APPLICATION
addappid(1136910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1136911, 1, "17cdf07117aa6fe7874dbdb541834d2620123ffde790bd307b160fd95d572d35")
