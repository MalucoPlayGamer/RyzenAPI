-- Lua provided by SkyAPI 
-- Game: Grimhook Soundtrack
addappid(2696290)
addappid(2696291, 1, "9b46debf577a50f6eb5e925a806a3a2adc5646e4584a783b111e5a6b75f6a74a")
