-- Lua provided by SkyAPI 
-- Game: Batterneers
addappid(1407050)
addappid(1407051, 1, "2d2f1510321410569f7f0642aac2fc7ca19a068cd7860cc5f223376abfdacab8")
addappid(1407052, 1, "27351abccde810922f866d0333b1fcc3e4f7af8ea9bc1595983d4bab285e38a1")
addappid(1407053, 1, "8e634459134bbc53c9bf342625b0afaf91b6df9a77e68f60002309922f75f324")
