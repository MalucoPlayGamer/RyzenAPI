-- Lua provided by RyzenAPI
-- Game: Game: Delivery in Space

-- MAIN APPLICATION
addappid(1947050)
-- Game: addappid(1947050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1947051, 1, "a74db282114cfaf97c653d49a2afb3d5dc65af26c49109dfaf8ecaf9ea2cbad4")
