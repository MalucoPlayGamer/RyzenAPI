-- Lua provided by RyzenAPI 
-- Game: Delivery in Space
addappid(1947050)
addappid(1947051, 1, "a74db282114cfaf97c653d49a2afb3d5dc65af26c49109dfaf8ecaf9ea2cbad4")
