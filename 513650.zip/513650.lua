-- Lua provided by RyzenAPI
-- Game: 513650

-- MAIN APPLICATION
addappid(513650)
-- Game: addappid(513650)

-- MAIN APP DEPOTS / PACKAGES
addappid(513651, 1, "be1b5c7465ab3a0e3ad995b4bbc9ece99578097862df250235dc13e0488ec0d5")
