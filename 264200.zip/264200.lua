-- Lua provided by RyzenAPI
-- Game: Game: One Finger Death Punch

-- MAIN APPLICATION
addappid(264200)
-- Game: addappid(264200)

-- MAIN APP DEPOTS / PACKAGES
addappid(264201, 1, "bbe95959e387f13bcbd0ee425ca2648f06dfcae360db177cf908bd52b131606c")
