-- Lua provided by RyzenAPI
-- Game: Steel Alcimus

-- MAIN APPLICATION
addappid(983990)
addappid(999970)

-- MAIN APP DEPOTS / PACKAGES
addappid(983991,0,"25c5935b9a968cf408eb81da9bff5a2638a46c226327daf70ff35c8dc6054e97")
addappid(983992,0,"bfbd154e1380238d4534e7d313093cc86f8b78e321dda23da3d16f55ca22f33d")

