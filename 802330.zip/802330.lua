-- Lua provided by RyzenAPI
-- Game: Badminton Kings VR

-- MAIN APPLICATION
addappid(802330)

-- MAIN APP DEPOTS / PACKAGES
addappid(802331, 1, "067a5b2f493fdecb5a5d0baab41e6b2c5ad28798a424701e4c6b5c791c806c10")
