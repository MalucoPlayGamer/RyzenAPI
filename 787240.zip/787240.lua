-- Lua provided by RyzenAPI
-- Game: AppID 787240

-- MAIN APPLICATION
addappid(787240)
-- Game: addappid(787240)

-- MAIN APP DEPOTS / PACKAGES
addappid(787241, 1, "024e2b8cc57baa826ee74209e17749ad9e14a5df82c690ba7bd45bc56c383584")
