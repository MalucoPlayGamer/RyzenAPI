-- Lua provided by RyzenAPI
-- Game: Cecconoid

-- MAIN APPLICATION
addappid(683310)

-- MAIN APP DEPOTS / PACKAGES
addappid(683311, 1, "bbfb7517a418cd159c402c3bb9e669985f76a8ec43a26072905c966bab2df90b")

