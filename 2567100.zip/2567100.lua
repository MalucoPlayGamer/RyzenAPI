-- Lua provided by RyzenAPI
-- Game: 2567100

-- MAIN APPLICATION
addappid(2567100)
-- Game: addappid(2567100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2567101, 1, "f08581b35abb6215b3c6fac268c4595ecef74e7a727396f0b8d96b7ec3077c1e")
