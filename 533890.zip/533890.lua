-- Lua provided by RyzenAPI
-- Game: ReBoot

-- MAIN APPLICATION
addappid(533890)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(533891,0,"5ca634f485918cf35376732f14e353c3fdf287cda4c846d5962c67996f8377d0")

