-- Lua provided by RyzenAPI
-- Game: Maze Workout - Urban Lost Solo Car Racer

-- MAIN APPLICATION
addappid(1801090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1801091, 1, "03c14b84b7833d9358c4026aa481af81fc30ebc54236a1640aa3259af76e44a5")

