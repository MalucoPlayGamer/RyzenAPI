-- Lua provided by RyzenAPI
-- Game: Offscreen Colonies: VR Edition

-- MAIN APPLICATION
addappid(1086240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1086241, 1, "616bc66c2fd464ad417d03917bec009240734f05bd9c5582884ce277e7c9b9e9")

