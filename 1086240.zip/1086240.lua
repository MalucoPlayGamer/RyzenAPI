-- Lua provided by RyzenAPI
-- Game: Game: Offscreen Colonies: VR Edition

-- MAIN APPLICATION
addappid(1086240)
-- Game: addappid(1086240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1086241, 1, "616bc66c2fd464ad417d03917bec009240734f05bd9c5582884ce277e7c9b9e9")
