-- Lua provided by RyzenAPI
-- Game: Game: AppID 977340

-- MAIN APPLICATION
addappid(977340)
-- Game: addappid(977340)

-- MAIN APP DEPOTS / PACKAGES
addappid(977341, 1, "c91c0c894027d8326bc221685b334d3ade6f1d17010f2d282dc2f991c3299942")
