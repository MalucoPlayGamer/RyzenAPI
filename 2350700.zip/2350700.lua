-- Lua provided by RyzenAPI 
-- Game: Project Apidom
addappid(2350700)
addappid(2350701, 1, "3c020462205d86f6a8801d5e1588dca5f303dd76d857e99838a3042218b0950b")
addappid(2350702, 1, "90dba937ba3fb68e4823d668ff77df8aaa1494a5648654833381beddcdce0cbd")
addappid(2350703, 1, "e8cefa0313b756ddac343b41b38469e72acf80be892722dc93d2f4f4cc4abd39")
