-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: SAM FollowMe

-- MAIN APPLICATION
addappid(1480750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480750,0,"de2adf7c95e25858f3ae3c71435e98af841146c1ee954e8ee53be0a8d62310aa")

