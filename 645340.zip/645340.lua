-- Lua provided by RyzenAPI
-- Game: Relax Walk VR

-- MAIN APPLICATION
addappid(645340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(645341, 1, "d6efe90d8d6bb83e04e69071324ccdbd5764745148f1e147ddcbc790b6c66acd")

