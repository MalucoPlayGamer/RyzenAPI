-- Lua provided by RyzenAPI
-- Game: Game: Relax Walk VR

-- MAIN APPLICATION
addappid(645340)
-- Game: addappid(645340)

-- MAIN APP DEPOTS / PACKAGES
addappid(645341, 1, "d6efe90d8d6bb83e04e69071324ccdbd5764745148f1e147ddcbc790b6c66acd")
