-- Lua provided by RyzenAPI
-- Game: 3703930

-- MAIN APPLICATION
addappid(3703930)
-- Game: addappid(3703930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3703931, 1, "c4fc3df701228f79d52b047b460085f5f7dadab9d3ace37f3bfe4f3cdf36c686")
