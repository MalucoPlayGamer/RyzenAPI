-- Lua provided by SkyAPI 
-- Game: Gym Camp Simulator
addappid(2808950)
addappid(2808951, 1, "02ed88b785d780992d7ae37ec29366f26c4880f0dfbff7e863fb2b36bab45f98")
