-- Lua provided by RyzenAPI
-- Game: Gym Camp Simulator

-- MAIN APPLICATION
addappid(2808950)
-- Game: addappid(2808950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2808951, 1, "02ed88b785d780992d7ae37ec29366f26c4880f0dfbff7e863fb2b36bab45f98")
