-- Lua provided by RyzenAPI
-- Game: The Witch Knight Anna The Black Serpent and the Golden Wind　Demo

-- MAIN APPLICATION
addappid(2500110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2500111, 1, "fcaa3275d0a9d5e65b6a03fa666421693844c1aec370b61249cd2666e7608a6a")

