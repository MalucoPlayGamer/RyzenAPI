-- Lua provided by RyzenAPI
-- Game: Parasite Infection

-- MAIN APPLICATION
addappid(1707780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707781, 1, "c9e0b84d0fa309d7f987f8b998f7cccc1738a4ef002ce5adef093cd3e95c2d0d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
