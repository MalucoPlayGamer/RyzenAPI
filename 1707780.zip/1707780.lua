-- Lua provided by RyzenAPI
-- Game: Parasite Infection

-- MAIN APPLICATION
addappid(1707780)
-- Game: addappid(1707780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707781, 1, "c9e0b84d0fa309d7f987f8b998f7cccc1738a4ef002ce5adef093cd3e95c2d0d")
