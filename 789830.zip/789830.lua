-- Lua provided by RyzenAPI
-- Game: [TDA03] Muv-Luv Unlimited: THE DAY AFTER - Episode 03 REMASTERED

-- MAIN APPLICATION
addappid(789830)
-- Game: addappid(789830)

-- MAIN APP DEPOTS / PACKAGES
addappid(789831, 1, "492f8854d90ab9d192f3f9865a6aec8e0ef667e44330490e9520309f46c6b3e1")
