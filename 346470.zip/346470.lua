-- Lua provided by RyzenAPI
-- Game: Tennis Elbow 2013

-- MAIN APPLICATION
addappid(346470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(346471, 1, "434fbfc437670313405bd744eb11d5907961d2e7f3b7f425177401d584d94587")

