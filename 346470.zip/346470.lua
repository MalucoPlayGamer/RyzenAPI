-- Lua provided by RyzenAPI
-- Game: Tennis Elbow 2013

-- MAIN APPLICATION
addappid(346470)
-- Game: addappid(346470)

-- MAIN APP DEPOTS / PACKAGES
addappid(346471, 1, "434fbfc437670313405bd744eb11d5907961d2e7f3b7f425177401d584d94587")
