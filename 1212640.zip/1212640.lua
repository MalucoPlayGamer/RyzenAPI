-- Lua provided by RyzenAPI
-- Game: A Lanterns Glow

-- MAIN APPLICATION
addappid(1212640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212641, 1, "a36e3495901ebcb076b52a3bed1abc768c9667046bbc44efe938dceec930e35a")

