-- Lua provided by RyzenAPI
-- Game: FlatOut: Ultimate Carnage Collector's Edition

-- MAIN APPLICATION
addappid(12360)
addappid(229005)

-- MAIN APP DEPOTS / PACKAGES
addappid(12361, 1, "b9699fce7e5884072e269f72a7e0f060c047a1e2cf3e26918b984e7ec0bc5ab4")
addappid(12362, 1, "59885ae87dcb0022016d16be2b827ea271a1add3373d8e7f0c560c3bf23e9565")
addappid(12365, 1, "a6400c456f5c87af99f150b722c829c7d623acff03e8960a8633b21f611dfa17")
addappid(12366, 1, "771d47ca9db25a7cb587d6a1f76a95af987cf9a023ab6558f818f76b076ec01e")
addappid(12367, 1, "dfb08099b909078f1cca8d53759b133567531d8079e44f4ffa1c33174c366600")
addappid(12368, 1, "00fb0253ab6b0932da1bc70db7cde57c993aacf0ab5f57993f2443ff96e641ff")
addappid(12369, 1, "5bd752e83fa32d2c0028a3f7f20a1cc7d16b566221c517dbd7bfbccef1c35783")
addappid(2844480, 0, "f6ab7c38d0889978407d80fa8bd44df1ea4347f78c87e2e9d421cd3d455d3af1")
addappid(2844481, 0, "5d576d04613a1614648b08d7d5613b9da316980c8cc862fb95f38b0340acdc5f")
addappid(2844482, 0, "18590c6d545d132fb30058c98939d56fcaabfb4feb39ff59c448ae5ce799a7eb")
addappid(2844484, 0, "785c869781e040456226da6f02deded51bc9e75dd13c8863791af6053c2dba96")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
