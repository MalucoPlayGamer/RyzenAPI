-- Lua provided by RyzenAPI
-- Game: addappid(41520)

-- MAIN APPLICATION
addappid(41501)
addappid(41520)

-- MAIN APP DEPOTS / PACKAGES
addappid(41502,0,"0fcacbfd33c5a51dd9c43d1a90c933b1a05bc517ed71c4648d43c1925fb653c8")
