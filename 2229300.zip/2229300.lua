-- Lua provided by RyzenAPI 
-- Game: AppID 2229300
addappid(2229300)
addappid(2229301, 1, "47abf4ca02fe0aa137624c117749b86fc078781d4cc158df0440c68cf064d107")
