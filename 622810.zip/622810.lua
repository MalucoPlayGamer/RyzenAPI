-- Lua provided by RyzenAPI
-- Game: Game: Invasion

-- MAIN APPLICATION
addappid(622810)
addappid(843770)
-- Game: addappid(622810)

-- MAIN APP DEPOTS / PACKAGES
addappid(622811, 1, "853c08c026953c9059877318d67e8653a4c3d7ff774bbdaf4fbd23cededa2f74")
