-- Lua provided by RyzenAPI
-- Game: Invasion

-- MAIN APPLICATION
addappid(622810)
addappid(843770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(622811, 1, "853c08c026953c9059877318d67e8653a4c3d7ff774bbdaf4fbd23cededa2f74")

