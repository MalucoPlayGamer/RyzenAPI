-- Lua provided by RyzenAPI
-- Game: The Tyrning Combat Challenge

-- MAIN APPLICATION
addappid(1984590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1984591, 1, "b4969b201e5fcb5c053be4d295d2a1baa62690efec56f34a7649de5a0c87c3b9")

