-- Lua provided by RyzenAPI
-- Game: Slate

-- MAIN APPLICATION
addappid(3118780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3118781, 1, "b83c6661da6ac7d37a3993c61f039820f9e9d9295178b1eb08e0c7bae07f03fc")
