-- Lua provided by RyzenAPI
-- Game: CETERIS Paribus

-- MAIN APPLICATION
addappid(2347200)
-- Game: addappid(2347200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2347201, 1, "4556489f8421a45ea65254ab7fdedd70208c81a4f4286df036124778c18eb50c")
