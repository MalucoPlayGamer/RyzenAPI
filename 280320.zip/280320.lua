-- Lua provided by RyzenAPI
-- Game: Game: AppID 280320

-- MAIN APPLICATION
addappid(280320)
addappid(295560)
-- Game: addappid(280320)

-- MAIN APP DEPOTS / PACKAGES
addappid(280321, 1, "18ceebfc3139573602d385635d2891641da1b86dad4462fee58334761104c4ab")
addappid(280323, 1, "e48ade5f5a55b6866be355cf3b54d51d750108ab15a1259566d2ed74bbde4cbe")
