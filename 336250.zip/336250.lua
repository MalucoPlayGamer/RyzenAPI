-- Lua provided by RyzenAPI
-- Game: Monster Jam Battlegrounds

-- MAIN APPLICATION
addappid(336250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(336251, 1, "ae79e8e410a2d251fffa63c5c095ed322b4cff7d35f8277b23c6ac5b6c22c217")

