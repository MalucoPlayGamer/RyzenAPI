-- Lua provided by RyzenAPI
-- Game: Monster Jam Battlegrounds

-- MAIN APPLICATION
addappid(336250)

-- MAIN APP DEPOTS / PACKAGES
addappid(336251, 1, "ae79e8e410a2d251fffa63c5c095ed322b4cff7d35f8277b23c6ac5b6c22c217")

