-- Lua provided by RyzenAPI
-- Game: Feral Blue

-- MAIN APPLICATION
addappid(618100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(618101, 1, "ac5cc19297e1f5793120af340a9b6ad8ac99c0314df7365170bc4dd4d583f5f5")

