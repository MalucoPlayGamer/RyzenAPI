-- Lua provided by RyzenAPI
-- Game: 618100

-- MAIN APPLICATION
addappid(618100)
-- Game: addappid(618100)

-- MAIN APP DEPOTS / PACKAGES
addappid(618101, 1, "ac5cc19297e1f5793120af340a9b6ad8ac99c0314df7365170bc4dd4d583f5f5")
