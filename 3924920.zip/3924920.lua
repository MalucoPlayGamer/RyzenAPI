-- 3924920's Lua and Manifest Created by Hubcap Manifest
-- 保卫粮食 Grain Defense
-- Created: August 12, 2026 at 01:02:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3924920) -- 保卫粮食 Grain Defense
-- MAIN APP DEPOTS
addappid(3924921, 1, "cc95d17d90ad43402eed4dab9aacb551473385286c1594e1afa882daffb52c30") -- Depot 3924921
setManifestid(3924921, "1183871202853081821", 365273939)