-- Lua provided by RyzenAPI
-- Game: Created: August 12, 2026 at 01:02:20 EDT

-- MAIN APPLICATION
addappid(3924920) -- 保卫粮食 Grain Defense

-- MAIN APP DEPOTS / PACKAGES
addappid(3924921, 1, "cc95d17d90ad43402eed4dab9aacb551473385286c1594e1afa882daffb52c30") -- Depot 3924921

