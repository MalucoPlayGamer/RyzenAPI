-- Lua provided by RyzenAPI
-- Game: Risk of Rain Returns Soundtrack

-- MAIN APPLICATION
addappid(2673200)
-- Game: addappid(2673200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2673202,0,"457f75ddb77f33a98c93f0d1c506fd7062f1542c8c67c71032520012706d113f")
addappid(2673203,0,"550145425250a47bb7df6869eed74219bf675ac0786dd21499a3a39d8dd12975")
