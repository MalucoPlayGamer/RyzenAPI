-- Lua provided by RyzenAPI
-- Game: 240320

-- MAIN APPLICATION
addappid(240320)
-- Game: addappid(240320)

-- MAIN APP DEPOTS / PACKAGES
addappid(240321, 1, "b26282fd97ea4483efd24ab53a05cf6a16490baffd178f9cf420e8df825e3ae0")
