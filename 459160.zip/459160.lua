-- Lua provided by RyzenAPI
-- Game: AppID 459160

-- MAIN APPLICATION
addappid(459160)
addappid(477780)
addappid(477781)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(459161, 1, "2f2a2464bea602e75707e369893d4a119f90e06c7099a105fff26d9f3972038a")
addappid(459162, 1, "31ebd075cb14b3f44fc6a5fa42e4eb6a8d0ea9fef21152c49136e8baf9ab6232")
addappid(459163, 1, "d747a7489e15cfb5579f89cc50813a3d1a4092db2bacdfae65ebd2079e6b7029")
addappid(459164, 1, "dc1a5f7c3316583daa95a593f0f2734e1b8ef725db8ee350645d467b49a385ac")

