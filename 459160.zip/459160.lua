-- Lua provided by RyzenAPI
-- Game: Game: AppID 459160

-- MAIN APPLICATION
addappid(459160)
-- Game: addappid(459160)

-- MAIN APP DEPOTS / PACKAGES
addappid(459161, 1, "2f2a2464bea602e75707e369893d4a119f90e06c7099a105fff26d9f3972038a")
addappid(459162, 1, "31ebd075cb14b3f44fc6a5fa42e4eb6a8d0ea9fef21152c49136e8baf9ab6232")
addappid(459163, 1, "d747a7489e15cfb5579f89cc50813a3d1a4092db2bacdfae65ebd2079e6b7029")
addappid(459164, 1, "dc1a5f7c3316583daa95a593f0f2734e1b8ef725db8ee350645d467b49a385ac")
