-- Lua provided by RyzenAPI
-- Game: My succubus Kukula

-- MAIN APPLICATION
addappid(2848420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2848421, 1, "fedf22bb7e1a3e505e1e90d64b8189790bcb07edd621bcbfd2fa66c770689edb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
