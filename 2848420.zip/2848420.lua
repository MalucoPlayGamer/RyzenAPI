-- Lua provided by RyzenAPI
-- Game: addappid(2848420)

-- MAIN APPLICATION
addappid(2848420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2848421, 1, "fedf22bb7e1a3e505e1e90d64b8189790bcb07edd621bcbfd2fa66c770689edb")
