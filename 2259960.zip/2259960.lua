-- Lua provided by SkyAPI 
-- Game: Tongue of Dog Demo
addappid(2259960)
addappid(2259961, 1, "32e58060a8233053c6ad1e9f896cbd21dec048ac781ceaaaccc3dc5758bcef5c")
