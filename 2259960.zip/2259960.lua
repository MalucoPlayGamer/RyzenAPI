-- Lua provided by RyzenAPI
-- Game: Game: Tongue of Dog Demo

-- MAIN APPLICATION
addappid(2259960)
-- Game: addappid(2259960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259961, 1, "32e58060a8233053c6ad1e9f896cbd21dec048ac781ceaaaccc3dc5758bcef5c")
