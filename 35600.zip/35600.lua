-- Lua provided by RyzenAPI
-- Game: addappid(35600)

-- MAIN APPLICATION
addappid(35600)

-- MAIN APP DEPOTS / PACKAGES
addappid(35601, 1, "2e5296427f626402d90f4c504a2fe27dde185213c414d1b3dac4ca24a7ef03d1")
addappid(35602, 1, "a042891b14d786cdb9699f271035be7a3f776fcf2ffba53f9a9e8d326ea266ad")
addappid(35603, 1, "76ddf3dc70b6c24fe77c5a3179f16aa07d62c522c019e0ca2bb1e263258e5b9c")
addappid(35604, 1, "d401ab26b9568e176fd10a2e2b2e40a3effc74233eab13dd0ecceab95e120f79")
addappid(35605, 1, "ecbf2eca5eaebc0074c735d3bedeb8561a0e4d269303b1cea12a1e2c7b96502e")
addappid(35606, 1, "c672519ec3d3c7e4056f7f65169b6dea6fc07a5279b85cfd27bbc12209d10198")
addappid(35607, 1, "f455fe1d3a84394d8edeee1bcb3e1a1acf1016277636584d33b1ee29d68d306c")
