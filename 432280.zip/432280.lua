-- Lua provided by RyzenAPI
-- Game: BattleStorm

-- MAIN APPLICATION
addappid(432280)

-- MAIN APP DEPOTS / PACKAGES
addappid(432281, 1, "27fb05f62748668c048c1d49fa8e5cffbc746bc720f47532feef311b5ef003eb")

