-- Lua provided by RyzenAPI
-- Game: AppID 2571270

-- MAIN APPLICATION
addappid(2571270)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2571271, 1, "e7020e846bbe216313cad9930066ee5a65502b0053ef855877be42601ad21aa0")

