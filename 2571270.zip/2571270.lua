-- Lua provided by SkyAPI 
-- Game: AppID 2571270
addappid(2571270)
addappid(2571271, 1, "e7020e846bbe216313cad9930066ee5a65502b0053ef855877be42601ad21aa0")
