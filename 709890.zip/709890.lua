-- Lua provided by RyzenAPI
-- Game: AppID 709890

-- MAIN APPLICATION
addappid(709890)
-- Game: addappid(709890)

-- MAIN APP DEPOTS / PACKAGES
addappid(709891, 1, "7fad8c0c8bb43ec639fa2c60c0a8a16f49d9ca0a486a6aae27f925e599392f27")
