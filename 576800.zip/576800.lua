-- Lua provided by SkyAPI 
-- Game: Final Bravely
addappid(576800)
addappid(576801, 1, "421aa431a2e46e107407c635d1bcc31d1f16dad5a14a05282aab59c12826237c")
