-- Lua provided by RyzenAPI
-- Game: Final Bravely

-- MAIN APPLICATION
addappid(576800)

-- MAIN APP DEPOTS / PACKAGES
addappid(576801, 1, "421aa431a2e46e107407c635d1bcc31d1f16dad5a14a05282aab59c12826237c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
