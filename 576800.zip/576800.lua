-- Lua provided by RyzenAPI
-- Game: addappid(576800)

-- MAIN APPLICATION
addappid(576800)

-- MAIN APP DEPOTS / PACKAGES
addappid(576801, 1, "421aa431a2e46e107407c635d1bcc31d1f16dad5a14a05282aab59c12826237c")
