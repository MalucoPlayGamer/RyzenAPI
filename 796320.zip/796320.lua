-- Lua provided by RyzenAPI
-- Game: Potatoe

-- MAIN APPLICATION
addappid(796320)

-- MAIN APP DEPOTS / PACKAGES
addappid(796321, 1, "c23da6d4f4ba070a4d90256ee52b33499c256787ab7363df92f71ee0a11c72db")

