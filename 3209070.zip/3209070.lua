-- Lua provided by RyzenAPI
-- Game: AppID 3209070

-- MAIN APPLICATION
addappid(3209070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3209071, 1, "dfde91970593df9332748fed25acf0b0636c9dc92a3587fdbc78c97eb32aec63")

