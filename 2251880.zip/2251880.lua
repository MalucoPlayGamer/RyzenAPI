-- Lua provided by SkyAPI 
-- Game: Subtension Soundtrack
addappid(2251880)
addappid(2251881, 1, "f2c314a43526e917040e93ac0ab8829f422c96c035ddeb583739234015824c49")
addappid(2251882, 1, "502b8d7a8e6c6795572e47d2b1d72263bc0aa18e4f3e2b6f9de07a42b54f176c")
