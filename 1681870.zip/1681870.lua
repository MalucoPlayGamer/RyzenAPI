-- Lua provided by RyzenAPI
-- Game: Game: Cobra Kai 2: Dojos Rising

-- MAIN APPLICATION
addappid(1681870)
addappid(2155150)
-- Game: addappid(1681870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1681871, 1, "5132ed3f503b43ccd590fe9d98c305de97d1b7e5e090106e0f5151cac0b07cc0")
