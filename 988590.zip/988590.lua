-- Lua provided by RyzenAPI
-- Game: SHELL_BREAK

-- MAIN APPLICATION
addappid(988590)
-- Game: addappid(988590)

-- MAIN APP DEPOTS / PACKAGES
addappid(988591, 1, "b22250d35fd22504aa4bc9ea35d742bdf473bfe32590f3e84cec69af822d330e")
