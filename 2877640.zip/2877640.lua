-- Lua provided by RyzenAPI
-- Game: Super Onion Boy+

-- MAIN APPLICATION
addappid(2877640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2877641, 1, "275981ac995eaad3084315a8227c5d42583879a44d3580421ffa1aed198d39cd")

