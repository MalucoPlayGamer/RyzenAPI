-- Lua provided by RyzenAPI
-- Game: Colony Ship: A Post-Earth Role Playing Game

-- MAIN APPLICATION
addappid(648410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(648411, 1, "a97d03641af448aa17fbe2613980631ed39b9eb74e746a8bfd164d5c13affbc7")

