-- Lua provided by RyzenAPI
-- Game: addappid(648410)

-- MAIN APPLICATION
addappid(648410)

-- MAIN APP DEPOTS / PACKAGES
addappid(648411, 1, "a97d03641af448aa17fbe2613980631ed39b9eb74e746a8bfd164d5c13affbc7")
