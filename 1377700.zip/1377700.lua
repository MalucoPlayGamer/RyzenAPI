-- Lua provided by RyzenAPI
-- Game: Empyreal

-- MAIN APPLICATION
addappid(1377700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377701, 1, "3f72bbeb8ff338334ff655e7e9adaefb50459371b5a68078bce3260d04a2c8cb")
