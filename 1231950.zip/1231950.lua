-- Lua provided by RyzenAPI
-- Game: The Innsmouth Case

-- MAIN APPLICATION
addappid(1231950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231951, 1, "11751396b4ed1ac55ea2eea12f23960af70a54718aa265b711dc669b3bccaa2a")
addappid(1231952, 1, "feee79a079b80688505c39fd61768a29c06540f97ef7072688dc7f0e79f9f59c")

