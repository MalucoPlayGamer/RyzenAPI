-- Lua provided by RyzenAPI
-- Game: Funfair Ride Simulator 3

-- MAIN APPLICATION
addappid(497720)
addappid(497721)
addappid(497722)
addappid(497724)

-- MAIN APP DEPOTS / PACKAGES
addappid(497723,0,"198f4570b7e9dd990864507870138224c4a5329370a3b7b0e69cb71f071c8123")
