-- Lua provided by RyzenAPI
-- Game: Chroma Shift

-- MAIN APPLICATION
addappid(860990)

-- MAIN APP DEPOTS / PACKAGES
addappid(860991,0,"60001562aacbbc816cc7d673f9f39257bcd242fa5ca78bc8f00fe381eb5b506c")

