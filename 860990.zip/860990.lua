-- Lua provided by RyzenAPI
-- Game: Chroma Shift

-- MAIN APPLICATION
addappid(860990)

-- MAIN APP DEPOTS / PACKAGES
addappid(860991,0,"60001562aacbbc816cc7d673f9f39257bcd242fa5ca78bc8f00fe381eb5b506c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
