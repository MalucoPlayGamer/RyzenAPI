-- Lua provided by RyzenAPI
-- Game: Gravity's Apple 2

-- MAIN APPLICATION
addappid(3790120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3790121, 1, "52582749cf621a5859c4e96a01fbefe95367cdb53f2c734d77bb4e73bcb8ea64")

