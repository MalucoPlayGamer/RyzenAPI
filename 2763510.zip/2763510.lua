-- Lua provided by RyzenAPI
-- Game: Farmcoz

-- MAIN APPLICATION
addappid(2763510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2763511, 1, "09316ba333764d0cdc2754eca749fd43c4b689722528cceea9daad2e561528a2")

