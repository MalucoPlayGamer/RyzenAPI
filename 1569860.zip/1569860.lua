-- Lua provided by RyzenAPI
-- Game: addappid(1569860)

-- MAIN APPLICATION
addappid(1569860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569860,0,"1e9ea0ac37bd9820815cebcce001c16461252d97b5de32c6e4566fd0dd32c131")
