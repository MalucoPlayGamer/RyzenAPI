-- Lua provided by RyzenAPI
-- Game: Sea Horizon

-- MAIN APPLICATION
addappid(1611420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611421, 1, "91acce8c6e6c2aeaa785ae115268ee3d6689d3384d78dcd2a2bbc5f6255a00e6")

