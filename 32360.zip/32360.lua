-- Lua provided by RyzenAPI
-- Game: Game: AppID 32360

-- MAIN APPLICATION
addappid(32360)
-- Game: addappid(32360)

-- MAIN APP DEPOTS / PACKAGES
addappid(32361, 1, "fd5089821cbba8ab69787411e76a507c36622b013726c62919c62084741d53af")
