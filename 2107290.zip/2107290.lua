-- Lua provided by RyzenAPI
-- Game: Pixxxel

-- MAIN APPLICATION
addappid(2107290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2107291, 1, "e972cbbc959a57d0f3ac146406ef471aeb412bdc64d6e45c1c568f5b05f3125d")
