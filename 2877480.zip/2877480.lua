-- Lua provided by RyzenAPI
-- Game: Game: StarArc Echo

-- MAIN APPLICATION
addappid(2877480)
-- Game: addappid(2877480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2877481, 1, "367b3a2f12228395772f19026cb3f27d7f316868a94468943ac25c99a0b12706")
