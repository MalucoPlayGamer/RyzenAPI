-- Lua provided by RyzenAPI 
-- Game: StarArc Echo
addappid(2877480)
addappid(2877481, 1, "367b3a2f12228395772f19026cb3f27d7f316868a94468943ac25c99a0b12706")
