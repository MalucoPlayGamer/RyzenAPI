-- Lua provided by RyzenAPI
-- Game: Dark Fairies

-- MAIN APPLICATION
addappid(873580)

-- MAIN APP DEPOTS / PACKAGES
addappid(873581, 1, "1255e63d09b7fdf651ecf1e0af9a4d38a1f00b67ae137acd23ef7e0360234879")
addappid(873582, 1, "164a94f808b749001c2d97cbc0607074bdacb9d9af47b909db6aeadf2f00b7ff")
addappid(873600, 1, "43df77842f6ef68cd935618e8dfbcee3eb8d95d66828050cba7b3e6886a0a55c")
