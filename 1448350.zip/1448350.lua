-- Lua provided by RyzenAPI
-- Game: QUANTAAR

-- MAIN APPLICATION
addappid(1448350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448351, 1, "8b1b467d464a742e0e37cc4559d1c0c7b964ef50afafac5e86f1b68f7dbcc23d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
