-- Lua provided by RyzenAPI
-- Game: addappid(1448350)

-- MAIN APPLICATION
addappid(1448350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1448351, 1, "8b1b467d464a742e0e37cc4559d1c0c7b964ef50afafac5e86f1b68f7dbcc23d")
