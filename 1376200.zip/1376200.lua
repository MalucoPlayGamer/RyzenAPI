-- Lua provided by RyzenAPI
-- Game: 1376200

-- MAIN APPLICATION
addappid(1376200)
-- Game: addappid(1376200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1376201, 1, "1612a57180e8cc4027cf689881dbb2601228dee5240b7d697edaa51c164d953e")
