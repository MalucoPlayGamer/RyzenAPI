-- Lua provided by SkyAPI 
-- Game: AppID 1044640
addappid(1044640)
addappid(1044641, 1, "b65dcfe7842a1bb58caba355ad5605476e481355dd83a15939538841164623f7")
