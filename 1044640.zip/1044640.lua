-- Lua provided by RyzenAPI
-- Game: Mundus - Impossible Universe

-- MAIN APPLICATION
addappid(1044640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1044641, 1, "b65dcfe7842a1bb58caba355ad5605476e481355dd83a15939538841164623f7")
