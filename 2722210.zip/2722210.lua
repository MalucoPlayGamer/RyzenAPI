-- Lua provided by RyzenAPI
-- Game: 2722210

-- MAIN APPLICATION
addappid(2722210)
-- Game: addappid(2722210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2722214,0,"f0f33ce8e31bec81fa9ca1a1c9fae6dfceb2a2e803c2e9d1b0ff0da679974028")
