-- Lua provided by RyzenAPI 
-- Game: LUMBERMANCER
addappid(491210)
addappid(491211, 1, "700768866e79c92756ef6c775385a2a7b9f7ea963e8f87c5f1a8d858e4499323")
