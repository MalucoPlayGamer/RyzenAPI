-- Lua provided by RyzenAPI
-- Game: Game: Monster Evo

-- MAIN APPLICATION
addappid(1611550)
-- Game: addappid(1611550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1611551, 1, "488de414e5b884b4282483310e94361d14d7f4f7a236113df8757fd8c91224d4")
