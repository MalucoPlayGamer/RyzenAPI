-- Lua provided by RyzenAPI
-- Game: addappid(436320)

-- MAIN APPLICATION
addappid(436320)

-- MAIN APP DEPOTS / PACKAGES
addappid(436321, 1, "9e019b8c077cfb79c936631e7efb043b7f680de505d7ef543f456916d7dc005b")
