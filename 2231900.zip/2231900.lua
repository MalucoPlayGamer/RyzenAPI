-- Lua provided by RyzenAPI
-- Game: Fateweaver: The Alchemist's Quandary

-- MAIN APPLICATION
addappid(2231900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2231901, 1, "f3050f16507de882501f81bdf073960a792f9f08ccd3909007997d2f40944408")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
