-- Lua provided by RyzenAPI
-- Game: Fateweaver: The Alchemist's Quandary

-- MAIN APPLICATION
addappid(2231900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2231901, 1, "f3050f16507de882501f81bdf073960a792f9f08ccd3909007997d2f40944408")

