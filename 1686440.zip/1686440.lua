-- Lua provided by RyzenAPI
-- Game: Game: Yoshimitsu Hatsumi

-- MAIN APPLICATION
addappid(1686440)
-- Game: addappid(1686440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1686441, 1, "9269f597b89fb8cfc0feb914d9161bc11517514f91451cb6d3b83b225b41635d")
