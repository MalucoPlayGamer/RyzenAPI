-- Lua provided by RyzenAPI
-- Game: AppID 2947740

-- MAIN APPLICATION
addappid(2947740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2947741, 1, "4e4210f76bef476245df5e97a830a7fc189272ef1bb6fe904ff3d63afab03e63")
