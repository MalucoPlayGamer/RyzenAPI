-- Lua provided by RyzenAPI
-- Game: Crisis in the Kremlin: The Cold War

-- MAIN APPLICATION
addappid(1922740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1922741, 1, "e7bf3b11e7458955033fd3b50bf48cc2b0c91c7bede7c8004b40e041e8eb5f9e")
addappid(3637930, 0, "f3b05211f995348aff3e62bb7963e6df69fde2df714a9847bf4c585d92b9de54")

