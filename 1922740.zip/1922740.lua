-- Lua provided by RyzenAPI 
-- Game: Crisis in the Kremlin: The Cold War
addappid(1922740)
addappid(1922741, 1, "e7bf3b11e7458955033fd3b50bf48cc2b0c91c7bede7c8004b40e041e8eb5f9e")
addappid(3637930, 0, "f3b05211f995348aff3e62bb7963e6df69fde2df714a9847bf4c585d92b9de54")
