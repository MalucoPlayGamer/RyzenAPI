-- Lua provided by RyzenAPI
-- Game: Wonderland

-- MAIN APPLICATION
addappid(3928980) -- Wonderland

-- MAIN APP DEPOTS / PACKAGES
addappid(3928981, 1, "155b9c8f49850dc5297dbaca641c3ede9aca4a9307f04fa55d3ee9956e401194") -- Depot 3928981

