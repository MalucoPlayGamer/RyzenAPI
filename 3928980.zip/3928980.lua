-- 3928980's Lua and Manifest Created by Hubcap Manifest
-- Wonderland
-- Created: July 31, 2026 at 23:59:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3928980) -- Wonderland
-- MAIN APP DEPOTS
addappid(3928981, 1, "155b9c8f49850dc5297dbaca641c3ede9aca4a9307f04fa55d3ee9956e401194") -- Depot 3928981
setManifestid(3928981, "6094077761896192823", 854538742)