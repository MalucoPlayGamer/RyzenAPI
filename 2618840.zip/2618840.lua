-- Lua provided by RyzenAPI
-- Game: 末世少女 Zombie Girl

-- MAIN APPLICATION
addappid(2618840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2618841, 1, "aeca517a5f447e537793a4339574f8769577a7c475481ec2a99221a188a4204a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
