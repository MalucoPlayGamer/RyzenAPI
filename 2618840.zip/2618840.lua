-- Lua provided by RyzenAPI
-- Game: Game: 末世少女 Zombie Girl

-- MAIN APPLICATION
addappid(2618840)
-- Game: addappid(2618840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2618841, 1, "aeca517a5f447e537793a4339574f8769577a7c475481ec2a99221a188a4204a")
