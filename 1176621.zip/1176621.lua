-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4 Ultimate - Weapon `Feline Paws`

-- MAIN APPLICATION
addappid(1176621)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176621,0,"0cf8faa9b21ced0f3976f0ed150a3c7994fef7ce0337fed5709168f0e0495b9c")

