-- Lua provided by RyzenAPI
-- Game: Adventures Of Pipi 2 Save Hype

-- MAIN APPLICATION
addappid(860790)

-- MAIN APP DEPOTS / PACKAGES
addappid(860791,0,"0ff229fc04f7dba2b01f4052ac7a4266ae7b1c96c1834905052e48fd74e76132")
addappid(861390,0,"9c0e82e5099da3f30e4edfcff3a108bbe0db3ee7512bbed6e20386127de02a32")

