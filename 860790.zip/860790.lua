-- Lua provided by RyzenAPI
-- Game: Game: AppID 860790

-- MAIN APPLICATION
addappid(860790)
-- Game: addappid(860790)

-- MAIN APP DEPOTS / PACKAGES
addappid(860791, 1, "0ff229fc04f7dba2b01f4052ac7a4266ae7b1c96c1834905052e48fd74e76132")
