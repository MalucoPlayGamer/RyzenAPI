-- Lua provided by RyzenAPI
-- Game: addappid(974390)

-- MAIN APPLICATION
addappid(974390)

-- MAIN APP DEPOTS / PACKAGES
addappid(974391, 1, "88027b34e6e5362067e5a5c6ea188cfbc76bc09f0d667507ebedad5b07f76f5a")
