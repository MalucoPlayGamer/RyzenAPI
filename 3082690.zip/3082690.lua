-- Lua provided by RyzenAPI
-- Game: Game: Dead Soul TowerDefense:Shadow Labyrinth

-- MAIN APPLICATION
addappid(3082690)
-- Game: addappid(3082690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3082691, 1, "58ddc2020aa64a62f40cfa6a53ccf9a31f194f9c22f7687452c1ae63a1479984")
