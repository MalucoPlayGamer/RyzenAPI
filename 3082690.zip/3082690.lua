-- Lua provided by RyzenAPI 
-- Game: Dead Soul TowerDefense:Shadow Labyrinth
addappid(3082690)
addappid(3082691, 1, "58ddc2020aa64a62f40cfa6a53ccf9a31f194f9c22f7687452c1ae63a1479984")
