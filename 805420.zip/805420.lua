-- Lua provided by RyzenAPI
-- Game: Stack & Crack

-- MAIN APPLICATION
addappid(805420)

-- MAIN APP DEPOTS / PACKAGES
addappid(805421,0,"bed32137ea9fa50f603e2de8590ef9e2d663965912f170db73f6dc8149e0a269")

