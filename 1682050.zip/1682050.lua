-- Lua provided by RyzenAPI
-- Game: PropHunter

-- MAIN APPLICATION
addappid(1682050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1682051, 1, "58e23c0641dada74bb23840e67d970301e6c45a424bdc32f3fe75aa29883d752")

