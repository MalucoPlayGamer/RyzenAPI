-- Lua provided by RyzenAPI
-- Game: Thesis of Love 心动论证 Demo

-- MAIN APPLICATION
addappid(3421870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3421871, 1, "76ba36f55b40716f582169052c6c032bf5cde9d926784d94c10109643eaa4fe5")
