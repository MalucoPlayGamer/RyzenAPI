-- Lua provided by RyzenAPI
-- Game: addappid(2258870)

-- MAIN APPLICATION
addappid(2258870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2258871, 1, "b41bf431acae0f3af7e8b4f4fc9ee1b41870689404002fe5b8ca585915061429")
