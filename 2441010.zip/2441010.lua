-- Lua provided by RyzenAPI 
-- Game: GanaBlade_Demo
addappid(2441010)
addappid(2441011, 1, "c5c7f1eeffa570ef25a425ab6ad9a56b43e3960f252e965632c6d7abd71ec830")
