-- Lua provided by RyzenAPI
-- Game: Animal Trainer Simulator Demo

-- MAIN APPLICATION
addappid(2765610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2765611, 1, "2f24e55246991074f5bb9002438c008f84c8733c4961549ceb7b0bff336d6f89")
