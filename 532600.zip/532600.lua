-- Lua provided by RyzenAPI
-- Game: Game: AppID 532600

-- MAIN APPLICATION
addappid(532600)
-- Game: addappid(532600)

-- MAIN APP DEPOTS / PACKAGES
addappid(532601, 1, "91da52dd31475c3220b4f5468aebc6f7ab331ab8371f65ed84c96c3849767914")
