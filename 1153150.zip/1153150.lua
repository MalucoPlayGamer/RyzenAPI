-- Lua provided by RyzenAPI
-- Game: PARA♰BELLUM ~ 魔弹帕菈

-- MAIN APPLICATION
addappid(1153150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1153154,0,"da5b88337801b9c4242bafe361f27254c0dd46a82654ebbdeb874d5579f55957")

