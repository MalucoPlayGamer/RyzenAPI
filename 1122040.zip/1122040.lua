-- Lua provided by RyzenAPI
-- Game: Game: Kaede the Eliminator / Eliminator 小枫

-- MAIN APPLICATION
addappid(1122040)
-- Game: addappid(1122040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122041, 1, "3561b6e06a8bc926d054a11857d38b709215099bfd778955111fc446a4310d08")
