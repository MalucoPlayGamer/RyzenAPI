-- Lua provided by RyzenAPI
-- Game: CloudStudy

-- MAIN APPLICATION
addappid(2846260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2846261, 1, "90bd277e0e9d010cb721c5d3cbc3a3845b3cc924f4d92efe4ee11892faa2a156")
