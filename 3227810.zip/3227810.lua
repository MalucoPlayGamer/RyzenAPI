-- Lua provided by RyzenAPI
-- Game: Sucker head: Bodycam

-- MAIN APPLICATION
addappid(3227810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227811, 1, "184d7e6dff6a9e3faf0d863f810c6334c7b1254a22a15dc30ab4cddba7501259")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
