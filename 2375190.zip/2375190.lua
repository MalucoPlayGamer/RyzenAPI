-- Lua provided by RyzenAPI
-- Game: Game: Queen of the Otaku: THERE CAN ONLY BE ONE

-- MAIN APPLICATION
addappid(2375190)
-- Game: addappid(2375190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375191, 1, "30e192f28542e1a485fc3a8c43d25e1303df3afd2722983e24d5901c91b2068f")
