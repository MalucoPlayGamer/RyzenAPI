-- Lua provided by RyzenAPI 
-- Game: Queen of the Otaku: THERE CAN ONLY BE ONE
addappid(2375190)
addappid(2375191, 1, "30e192f28542e1a485fc3a8c43d25e1303df3afd2722983e24d5901c91b2068f")
