-- 4432910's Lua and Manifest Created by Hubcap Manifest
-- Spell Knight: Abyss Cleaver
-- Created: July 27, 2026 at 10:26:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4432910) -- Spell Knight: Abyss Cleaver
-- MAIN APP DEPOTS
addappid(4432911, 1, "dfd5c37d3ebb9dc5872425700c4e18fdaec7b40805d8763e4fcbbe63cfe191f5") -- Depot 4432911
setManifestid(4432911, "8530705796098050802", 318219033)