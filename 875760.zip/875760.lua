-- Lua provided by RyzenAPI
-- Game: 875760

-- MAIN APPLICATION
addappid(875760)
-- Game: addappid(875760)

-- MAIN APP DEPOTS / PACKAGES
addappid(875761, 1, "01ed72abce5e169f278faba80d9600baa46580b7c277b18b6834b06dd25236c3")
