-- Lua provided by SkyAPI 
-- Game: Voxel Tycoon
addappid(732050)
addappid(732051, 1, "27645fbec4e2e2e2ebe1b7c1070fbc67132e1f1a18902f7f879fa59c0ea2ecb4")
addappid(732052, 1, "17f8caf0e9e64513f318cd82fdbf0e6d574754745995b16e65b61d56e2d0e137")
addappid(732053, 1, "128f48efafcf1622a14a8a8ade244c6c39260044b99df1062235976b9ed5eab2")
