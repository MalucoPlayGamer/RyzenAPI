-- Lua provided by RyzenAPI
-- Game: 1360480

-- MAIN APPLICATION
addappid(1360480)
-- Game: addappid(1360480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1360481, 1, "a7254b2ab00c3438f7b37f79ab6441f3f1326ce40862c181a8252d4aa1d6f0b0")
addappid(1360482, 1, "94fbbd233bf20cf8ae2af30c0f6bec09b2542bc8ce868edf4d45711d4bd9dd39")
