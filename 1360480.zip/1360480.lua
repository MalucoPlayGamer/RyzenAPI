-- Lua provided by SkyAPI 
-- Game: 推箱子(Push Box)
addappid(1360480)
addappid(1360481, 1, "a7254b2ab00c3438f7b37f79ab6441f3f1326ce40862c181a8252d4aa1d6f0b0")
addappid(1360482, 1, "94fbbd233bf20cf8ae2af30c0f6bec09b2542bc8ce868edf4d45711d4bd9dd39")
