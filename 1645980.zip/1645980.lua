-- Lua provided by RyzenAPI
-- Game: Zolaris

-- MAIN APPLICATION
addappid(1645980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1645981, 1, "29b61490fa228819679a6fba953b8c2f4c46ead38f6fe68e4823ac9e092b0043")

