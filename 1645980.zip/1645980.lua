-- Lua provided by RyzenAPI
-- Game: Zolaris

-- MAIN APPLICATION
addappid(1645980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1645981, 1, "29b61490fa228819679a6fba953b8c2f4c46ead38f6fe68e4823ac9e092b0043")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
