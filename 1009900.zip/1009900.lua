-- Lua provided by RyzenAPI
-- Game: Date Write

-- MAIN APPLICATION
addappid(1009900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1009901, 1, "cc13de410cccc7e899229d55c216038a7556eee2c8b6910d70549ff1560a1988")

