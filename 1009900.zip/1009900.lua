-- Lua provided by SkyAPI 
-- Game: AppID 1009900
addappid(1009900)
addappid(1009901, 1, "cc13de410cccc7e899229d55c216038a7556eee2c8b6910d70549ff1560a1988")
