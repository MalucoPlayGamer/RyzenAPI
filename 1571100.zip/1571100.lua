-- Lua provided by RyzenAPI
-- Game: Passpartout 2: The Lost Artist

-- MAIN APPLICATION
addappid(1571100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1571101, 1, "657c54d7d827dc736a34b6f04d433fe3e0949b73f593afc2f6eca86f5794f6a8")
addappid(1571102, 1, "a4b61713c34a6550435b91f3543d4bf6ea11006597e353b2557d1dd9a7e9dfbf")
