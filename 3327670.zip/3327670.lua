-- Lua provided by RyzenAPI
-- Game: Grand MALL Simulator

-- MAIN APPLICATION
addappid(3327670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3327671, 1, "a6bff198ac577bef90b1b618254c7ca72707445512d3fb30c6e965a1d337152d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
