-- Lua provided by RyzenAPI
-- Game: 3327670

-- MAIN APPLICATION
addappid(3327670)
-- Game: addappid(3327670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3327671, 1, "a6bff198ac577bef90b1b618254c7ca72707445512d3fb30c6e965a1d337152d")
