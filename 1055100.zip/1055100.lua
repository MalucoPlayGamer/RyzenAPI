-- Lua provided by RyzenAPI
-- Game: 1055100

-- MAIN APPLICATION
addappid(1055100)
-- Game: addappid(1055100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1055101, 1, "1ccb4b3e9f44192ed27e6344e73aa829cb5519e4d3756a62fe885e0fe4675ab5")
