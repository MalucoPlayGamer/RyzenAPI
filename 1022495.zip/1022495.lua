-- Lua provided by RyzenAPI
-- Game: DFF NT: Snobbish Turban Appearance Set for Kefka Palazzo

-- MAIN APPLICATION
addappid(1022495)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022495,0,"869e87e6f08cfcd62ebab8d2a858cd1fcf88c3e430b33d4e5d618eb64955c316")
