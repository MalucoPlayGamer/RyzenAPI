-- Lua provided by RyzenAPI
-- Game: Sparedevil

-- MAIN APPLICATION
addappid(2960500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2960501, 1, "dff1a7d57827161ef8b06fb4ce3efb97b8fdf9353d5e087b13cbddf518eea7c6")

