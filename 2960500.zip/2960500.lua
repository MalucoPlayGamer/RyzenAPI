-- Lua provided by RyzenAPI
-- Game: Sparedevil

-- MAIN APPLICATION
addappid(2960500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2960501, 1, "dff1a7d57827161ef8b06fb4ce3efb97b8fdf9353d5e087b13cbddf518eea7c6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
