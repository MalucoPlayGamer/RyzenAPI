-- Lua provided by RyzenAPI 
-- Game: Hundred Days - Winemaking Simulator
addappid(1042380)
addappid(1042381, 1, "6674f981af8da7936c143330fd466489ce26f95b2be45b5598f8413c2e6a7285")
addappid(1042383, 1, "f3937bbc089688d8651f0a7bc3ebf70bb869c71fc8f1fcacbd6e11539f1453a4")
