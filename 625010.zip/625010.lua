-- Lua provided by RyzenAPI
-- Game: Little Lords of Twilight

-- MAIN APPLICATION
addappid(625010)

-- MAIN APP DEPOTS / PACKAGES
addappid(625011, 1, "b27dd970cdd7a776364712bfa30bf8d3394bb9cadabf5e2a67caccb644662bc1")
addappid(625012, 1, "351e99bfd65bba8a8bcafda7410b5398cc9345b60ce4e2f66a1fa7ba459ccb3f")
