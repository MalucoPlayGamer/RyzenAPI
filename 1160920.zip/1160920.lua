-- Lua provided by RyzenAPI 
-- Game: Food Truck Simulator
addappid(1160920)
addappid(1160921, 1, "e1e2d55d47a6f0844a34dc44aa93d5932205cce6bd1ec0a5e88dabd286d6c27e")
