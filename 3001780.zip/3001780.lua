-- Lua provided by RyzenAPI 
-- Game: Water: Transformer
addappid(3001780)
addappid(3001781, 1, "3fa4d06cf4f581234d2ba4653dd02377caf59dd4f98446ff2bb5fdc84a68ac84")
