-- Lua provided by RyzenAPI 
-- Game: Forest Fortress
addappid(616620)
addappid(616621, 1, "90e242e4e248084f3ae50c2c25a4ac594296d3d8598559446e27eab21e48ad86")
addappid(616623, 1, "0f5f730a25c59796910d78f942b5b5a280587c83fbce8a79198f30c19c88ce2e")
