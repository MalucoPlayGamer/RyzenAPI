-- Lua provided by RyzenAPI
-- Game: Would you like to run an idol café? 3

-- MAIN APPLICATION
addappid(1850790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1850791, 1, "2c15d6e11376efda860a1a80539764b2f9d6dcf3ee2340d62e330e563445e803")

