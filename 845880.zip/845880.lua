-- Lua provided by RyzenAPI
-- Game: Touhou: Scarlet Curiosity

-- MAIN APPLICATION
addappid(845880)

-- MAIN APP DEPOTS / PACKAGES
addappid(845881, 1, "31b65e5a8d81fc3d0d2581248438ad720623d86d5d6f1227e0081c3dbe5d29e5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
