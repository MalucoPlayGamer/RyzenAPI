-- Lua provided by SkyAPI 
-- Game: Touhou: Scarlet Curiosity
addappid(845880)
addappid(845881, 1, "31b65e5a8d81fc3d0d2581248438ad720623d86d5d6f1227e0081c3dbe5d29e5")
