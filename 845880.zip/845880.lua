-- Lua provided by RyzenAPI
-- Game: Touhou: Scarlet Curiosity

-- MAIN APPLICATION
addappid(845880)
-- Game: addappid(845880)

-- MAIN APP DEPOTS / PACKAGES
addappid(845881, 1, "31b65e5a8d81fc3d0d2581248438ad720623d86d5d6f1227e0081c3dbe5d29e5")
