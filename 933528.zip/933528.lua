-- Lua provided by RyzenAPI
-- Game: 933528

-- MAIN APPLICATION
addappid(933528)

-- MAIN APP DEPOTS / PACKAGES
addappid(933528,0,"5eeffbed951d3fd1ba6a61ce8ddc091bb2284d482d140bad42cebcaa5995a9d7")

