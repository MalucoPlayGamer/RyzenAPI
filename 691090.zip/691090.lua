-- Lua provided by RyzenAPI
-- Game: Fates Call: A New Beginning

-- MAIN APPLICATION
addappid(691090)

-- MAIN APP DEPOTS / PACKAGES
addappid(691091,0,"15d9900f79c7dfbe7aa9066809a51aaf9dc17a6862af6fbe0363cba58d143bd1")

