-- Lua provided by RyzenAPI
-- Game: Punch Club 2: Fast Forward - Artbook and Comic Book

-- MAIN APPLICATION
addappid(2470820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2470820,0,"3d45bb02ba7676b784d53c25d4a4fd194f1f5b4d6978c2ea7c068a07430ad233")
