-- Lua provided by RyzenAPI
-- Game: Little Obedient Robot

-- MAIN APPLICATION
addappid(1522540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522541, 1, "66a442b2b5d5fdbbf52e658c5283f71b39b42b6105160a57e3c161037343c793")
