-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1754680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754680,0,"19f21896c7cbe76801f0112566e96cb32d1c6c5efba7b056d7f24985f29ddf69")
addtoken(1754680,2438579537275917386)
