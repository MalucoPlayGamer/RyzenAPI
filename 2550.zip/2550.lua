-- Lua provided by RyzenAPI
-- Game: RIP - Trilogy™

-- MAIN APPLICATION
addappid(2550)
-- Game: addappid(2550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2551, 1, "35d7e52161e063f7358ef9091bda3bd7eacaf4a7b4aab4a55152b38183efaae7")
