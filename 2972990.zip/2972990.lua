-- Lua provided by SkyAPI 
-- Game: hololive Treasure Mountain
addappid(2972990)
addappid(2972991, 1, "ea1cd8602a13532c0c96f3cb78272bc4215facf80bbc9ebe3c9fb822fba7aba7")
