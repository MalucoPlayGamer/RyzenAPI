-- Lua provided by RyzenAPI
-- Game: Game: AbyssalRestaurant

-- MAIN APPLICATION
addappid(3021020)
-- Game: addappid(3021020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3021021, 1, "387981f051ee87b476c499d69a77dace810131995f56cc617fc72822f0bf6836")
