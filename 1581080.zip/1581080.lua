-- Lua provided by RyzenAPI
-- Game: Food Delivery Service

-- MAIN APPLICATION
addappid(1581080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581081, 1, "729422c9859b5addbadefc85cfc03ffdfbdff2a648323f72b0bab307ce667417")

