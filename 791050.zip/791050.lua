-- Lua provided by RyzenAPI
-- Game: I Hate Heroes: Rocket Man

-- MAIN APPLICATION
addappid(791050)

-- MAIN APP DEPOTS / PACKAGES
addappid(791051,0,"ab4254d2d18ae5bb4366a83cca81adae68368bef163b839c947a9d0eeb5b53d4")

