-- Lua provided by RyzenAPI
-- Game: addappid(446870)

-- MAIN APPLICATION
addappid(446870)

-- MAIN APP DEPOTS / PACKAGES
addappid(446871, 1, "86b0eb7c6d6ee3e9743e65d81e3f6ce08c3e475d57a464a82082f7f8d07ccee6")
