-- Lua provided by RyzenAPI
-- Game: Cryptid

-- MAIN APPLICATION
addappid(2444840)
-- Game: addappid(2444840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2444841, 1, "6dea6fdbb2f02fca6fb8cb19aa1f75ceef71bd4c524dabb1ea8ffb44004d4407")
