-- Lua provided by RyzenAPI
-- Game: addappid(2617210)

-- MAIN APPLICATION
addappid(2617210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617211, 1, "e05e91fab79e0ce3c5cc85a807c1c0a20ad54c11035eb9245f7c1cb6237a2fdd")
