-- Lua provided by RyzenAPI
-- Game: Shadows Labyrinth

-- MAIN APPLICATION
addappid(2505200)
-- Game: addappid(2505200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505201, 1, "2af2b5b46c716fcb20f1de5ae89da8831850b243f6b2d4b21b1bd5d3272e5a9a")
