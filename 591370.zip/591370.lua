-- Lua provided by RyzenAPI
-- Game: Production Line

-- MAIN APPLICATION
addappid(591370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(591371, 1, "e01b4075b6a9b8491ae3156422783ee5b348d8a9cf8e4d9e9eba271f6ba7e75b")
addappid(1067630, 0, "0d7c0d5cbfe0fe953b7dacff82b090b4b2257c3465eb983101cdef08a864cb64")
addappid(1174730, 0, "f9d4ffca623dac07d22f80fce3f4722e32d3fc748770623f916d01bc374cafac")
