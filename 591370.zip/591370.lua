-- Lua provided by RyzenAPI
-- Game: addappid(591370)

-- MAIN APPLICATION
addappid(591370)

-- MAIN APP DEPOTS / PACKAGES
addappid(591371, 1, "e01b4075b6a9b8491ae3156422783ee5b348d8a9cf8e4d9e9eba271f6ba7e75b")
addappid(1067630, 0, "0d7c0d5cbfe0fe953b7dacff82b090b4b2257c3465eb983101cdef08a864cb64")
addappid(1174730, 0, "f9d4ffca623dac07d22f80fce3f4722e32d3fc748770623f916d01bc374cafac")
