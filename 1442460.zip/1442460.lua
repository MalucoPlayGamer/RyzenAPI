-- Lua provided by RyzenAPI
-- Game: Game: Cars and Girls

-- MAIN APPLICATION
addappid(1442460)
-- Game: addappid(1442460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442461, 1, "3e6b662159e3b2defd35ddf1cf43c72fd024fcf2abedcf3d533e49ba725fd0b9")
