-- Lua provided by RyzenAPI 
-- Game: BAFF
addappid(1081760)
addappid(1081761, 1, "ab590fae096c56e66f7455a5108db9775f8bb26c7b35303ce2abc089033ce68e")
