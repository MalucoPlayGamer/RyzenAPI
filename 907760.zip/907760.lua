-- Lua provided by RyzenAPI
-- Game: Game: AppID 907760

-- MAIN APPLICATION
addappid(907760)
-- Game: addappid(907760)

-- MAIN APP DEPOTS / PACKAGES
addappid(907761, 1, "f066c8fc33cec6a0ecf73a1f7998fb5a9382c6a68ebea8f354ec20f58d804262")
