-- Lua provided by RyzenAPI
-- Game: ARIDA: Backland's Awakening

-- MAIN APPLICATION
addappid(907760)

-- MAIN APP DEPOTS / PACKAGES
addappid(907761, 1, "f066c8fc33cec6a0ecf73a1f7998fb5a9382c6a68ebea8f354ec20f58d804262")

