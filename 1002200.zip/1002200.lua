-- Lua provided by RyzenAPI
-- Game: Game: AppID 1002200

-- MAIN APPLICATION
addappid(1002200)
-- Game: addappid(1002200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002201, 1, "861ceebe3df7572fd5a96b9f12fcbc8d3c2406e61b042047b1012b920ff808a6")
