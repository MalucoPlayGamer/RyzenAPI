-- Lua provided by SkyAPI 
-- Game: Funk of Titans
addappid(383750)
addappid(383751, 1, "6f39524214e7f9b20659008e1ec2a856c22638a79ef126f537212a1c54147eff")
