-- Lua provided by RyzenAPI
-- Game: Game: Funk of Titans

-- MAIN APPLICATION
addappid(383750)
-- Game: addappid(383750)

-- MAIN APP DEPOTS / PACKAGES
addappid(383751, 1, "6f39524214e7f9b20659008e1ec2a856c22638a79ef126f537212a1c54147eff")
