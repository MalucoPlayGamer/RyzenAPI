-- Lua provided by RyzenAPI
-- Game: Kartoffl Demo

-- MAIN APPLICATION
addappid(1897270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1897271, 1, "fd847cbc04958616d924a952444118f8157e3e963c1031972d31e2b445fe5bd0")

