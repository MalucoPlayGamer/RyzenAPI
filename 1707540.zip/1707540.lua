-- Lua provided by RyzenAPI
-- Game: Escape From Monster

-- MAIN APPLICATION
addappid(1707540)
-- Game: addappid(1707540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707541, 1, "2eada3178ae6150a5aa4008c323d93781ca29bd9537f03d82bf2364e9ec5af08")
