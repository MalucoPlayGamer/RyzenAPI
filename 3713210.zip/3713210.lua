-- Lua provided by RyzenAPI
-- Game: addappid(3713210)

-- MAIN APPLICATION
addappid(3713210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3713211, 1, "639233f7b9046bb93eff8d71e00deadaebdc1f80a3fc26617ac495ba28f7af87")
