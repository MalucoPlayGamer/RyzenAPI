-- Lua provided by RyzenAPI
-- Game: addappid(1732480)

-- MAIN APPLICATION
addappid(1732480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732481, 1, "c9bd313aa085eb4ecbf2829f384e8848b1c3cb63de22a00c53b262a623313156")
addappid(1732482, 1, "d31ab9b5e560a1994c013bd8898048ded9b1b38d0dfd162a8a01fe54b2ca8e6e")
