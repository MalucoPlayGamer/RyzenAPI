-- Lua provided by RyzenAPI
-- Game: Arisen Force: HeroTest Demo

-- MAIN APPLICATION
addappid(2951860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2951861, 1, "fa55ab6f0ed18d8492bd16ff63696ab9d520b94b5ad2eea1fab31ffa18fe6db8")
