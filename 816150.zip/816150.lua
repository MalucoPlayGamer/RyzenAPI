-- Lua provided by RyzenAPI
-- Game: Hardway Party

-- MAIN APPLICATION
addappid(816150)

-- MAIN APP DEPOTS / PACKAGES
addappid(816151,0,"c5834dd9765770060edb6a0bde58ca88056f92e54fe56fa9328dc036415652f8")

