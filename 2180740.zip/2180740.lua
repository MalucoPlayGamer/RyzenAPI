-- Lua provided by RyzenAPI
-- Game: Sex Toys

-- MAIN APPLICATION
addappid(2180740)
-- Game: addappid(2180740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180741, 1, "93145937b519216d8a482a18b49049ac1ba0ecd4706c0d7fefb87777ebeffc27")
