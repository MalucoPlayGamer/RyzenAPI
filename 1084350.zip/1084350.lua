-- Lua provided by RyzenAPI
-- Game: 1084350

-- MAIN APPLICATION
addappid(1084350)
-- Game: addappid(1084350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1084352,0,"e53ca6311d220c45cab111a94e037f352632ff5a6e3f0282f5c1a38bd90a72dd")
