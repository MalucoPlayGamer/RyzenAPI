-- Lua provided by RyzenAPI
-- Game: 2779850

-- MAIN APPLICATION
addappid(2779850)
-- Game: addappid(2779850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779851, 1, "46e50f537ac3f75f9538fd503fce559752eacfc0414091cc7f65b609fc8fc3bf")
