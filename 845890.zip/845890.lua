-- Lua provided by RyzenAPI
-- Game: Moonbreaker

-- MAIN APPLICATION
addappid(845890)
addappid(2055700)
addappid(2704850)

-- MAIN APP DEPOTS / PACKAGES
addappid(845891,0,"4ce048d65af57d04009da0759ebc35be60455db2b879e9fae9ef1b8f5df645b6")
addappid(845892,0,"0c5e2babac508e1e85f11140f289199a966ba36e3544e49d8b9745931460c5b2")

