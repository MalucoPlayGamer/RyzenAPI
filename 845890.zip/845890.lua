-- Lua provided by RyzenAPI
-- Game: 845890

-- MAIN APPLICATION
addappid(845890)
-- Game: addappid(845890)

-- MAIN APP DEPOTS / PACKAGES
addappid(845891, 1, "4ce048d65af57d04009da0759ebc35be60455db2b879e9fae9ef1b8f5df645b6")
