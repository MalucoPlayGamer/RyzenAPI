-- Lua provided by RyzenAPI
-- Game: The Banner Saga

-- MAIN APPLICATION
addappid(237990)
addappid(266800)
addappid(272640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(237991, 1, "beb0f9c424fa33e0ee8c1aa9f9e3894096df841d00854a47e367348e172388cd")
addappid(237992, 1, "c7791498e559d2446503e437f6a6aa363372bd89df7fe5862bf2bfff6c545da7")
addappid(237993, 1, "73f389b58955a47cd17cb4a58f4915554ba87373534d05c7ec23b4a42c7f8a04")
addappid(237994, 1, "0b3e3ef7e227581fd0d2ec69e955842c860eca09cf895a3cbed87da77b4dd196")
addappid(306850, 0, "eeb56c4e308e9f7753f762004d1b817ec42cfe153678e39ecadf62eafb17c34f")

