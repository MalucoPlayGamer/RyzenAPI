-- Lua provided by RyzenAPI
-- Game: addappid(2605500)

-- MAIN APPLICATION
addappid(2605500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605501, 1, "7c8b00f01cb2ea4c4fa31a265df7bd2decfb31ec510fa927122093c5bbf5e0a5")
