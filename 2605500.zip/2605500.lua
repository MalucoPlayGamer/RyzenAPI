-- Lua provided by RyzenAPI
-- Game: Case of the mysterious death of Keiko Haraeda

-- MAIN APPLICATION
addappid(2605500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605501, 1, "7c8b00f01cb2ea4c4fa31a265df7bd2decfb31ec510fa927122093c5bbf5e0a5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
