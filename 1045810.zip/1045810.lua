-- Lua provided by RyzenAPI
-- Game: 1045810

-- MAIN APPLICATION
addappid(1045810)
-- Game: addappid(1045810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045810,0,"42cbce4d859c8cdc41878e6e62e9e0e41ba565dc78b77eac8542a4dc103ad9ce")
