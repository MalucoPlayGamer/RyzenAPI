-- Lua provided by RyzenAPI
-- Game: AppID 968560

-- MAIN APPLICATION
addappid(968560)
-- Game: addappid(968560)

-- MAIN APP DEPOTS / PACKAGES
addappid(968561, 1, "39bf33776d721d4d93e41b96ad6dd74dd3744bdd84dc9b55cd28f0260d1ee880")
