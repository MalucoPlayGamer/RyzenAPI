-- Lua provided by RyzenAPI
-- Game: addappid(1381450)

-- MAIN APPLICATION
addappid(1381450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1381451, 1, "942b94489a89aa47bee987438295a279de72e4f59c2a3d7fb18e69dd9e744602")
