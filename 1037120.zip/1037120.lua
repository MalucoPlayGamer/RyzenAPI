-- Lua provided by RyzenAPI
-- Game: Mutropolis

-- MAIN APPLICATION
addappid(1037120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1037121, 1, "f4b58626839420086a2499a821279733b959df67ddc60baa522eceae03327d4e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1551130)
