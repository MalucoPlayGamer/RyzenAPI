-- Lua provided by RyzenAPI
-- Game: addappid(790260)

-- MAIN APPLICATION
addappid(790260)

-- MAIN APP DEPOTS / PACKAGES
addappid(790261, 1, "f647fa8e5d8f0929a1fbf72ba9b9385f668a81e30ea6261436825897ffa818ba")
