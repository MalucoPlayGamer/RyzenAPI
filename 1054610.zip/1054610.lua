-- Lua provided by RyzenAPI
-- Game: Chocolate makes you happy: Easter

-- MAIN APPLICATION
addappid(1054610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054611, 1, "8b5ef3e62813ec22406bf08efa31d3809b9d7cf01f0906730e271ef7056facd7")

