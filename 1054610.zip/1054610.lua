-- Lua provided by RyzenAPI
-- Game: 1054610

-- MAIN APPLICATION
addappid(1054610)
-- Game: addappid(1054610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054611, 1, "8b5ef3e62813ec22406bf08efa31d3809b9d7cf01f0906730e271ef7056facd7")
