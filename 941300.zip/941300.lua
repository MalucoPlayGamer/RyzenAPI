-- Lua provided by RyzenAPI
-- Game: 东方梦零魂 ~ TouHou Nil Soul

-- MAIN APPLICATION
addappid(941300)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(941301, 1, "14fd6a797d6c5f3ce8a1944820378308c36bfc5cb053ab0711f70cacdc4d60ca")
