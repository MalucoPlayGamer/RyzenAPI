-- Lua provided by RyzenAPI
-- Game: 941300

-- MAIN APPLICATION
addappid(941300)
-- Game: addappid(941300)

-- MAIN APP DEPOTS / PACKAGES
addappid(941301, 1, "14fd6a797d6c5f3ce8a1944820378308c36bfc5cb053ab0711f70cacdc4d60ca")
