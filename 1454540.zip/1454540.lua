-- Lua provided by RyzenAPI
-- Game: addappid(1454540)

-- MAIN APPLICATION
addappid(1454540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1454541, 1, "ba670f543339a838e5d4c449d09bb8a076d0b61190472fca5e86166a9be8961e")
