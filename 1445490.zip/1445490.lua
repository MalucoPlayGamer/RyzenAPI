-- Lua provided by RyzenAPI
-- Game: Game: AppID 1445490

-- MAIN APPLICATION
addappid(1445490)
-- Game: addappid(1445490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1445491, 1, "c252a3ca8b99d396074c445e4c4b28f449188dc055791021427a45ba3b5e8177")
addappid(1445492, 1, "3eaf6e346b9ebf2cd429a879104a34c56fea3a1a55b9a12df145c2da33520ded")
addappid(1445493, 1, "8c68062a8f164cdf1ff3295583caf3dbaa20a07b08b53b3d506beee738f6cd9e")
addappid(1445494, 1, "fe3410b40024a47abbe623d3dbc46778ae5f9fb9c3f6290e28f6c07e32481ad6")
addappid(1445495, 1, "914b46c8fef74cdb5adb2ed29db4402ecf6154a77be2a0003da6aba75b9b5a7e")
