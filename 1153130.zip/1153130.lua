-- Lua provided by RyzenAPI
-- Game: Wurroom

-- MAIN APPLICATION
addappid(1153130)

