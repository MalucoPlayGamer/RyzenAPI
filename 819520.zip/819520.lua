-- Lua provided by RyzenAPI
-- Game: Star Souls

-- MAIN APPLICATION
addappid(819520)
addappid(1369440)

-- MAIN APP DEPOTS / PACKAGES
addappid(819521, 1, "4bb3aaffe1e719d47bfa0d5c623a488af1bbb30070106e5901744228b5391863")
