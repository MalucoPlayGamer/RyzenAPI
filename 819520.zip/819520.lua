-- Lua provided by RyzenAPI
-- Game: AppID 819520

-- MAIN APPLICATION
addappid(819520)

-- MAIN APP DEPOTS / PACKAGES
addappid(819521, 1, "4bb3aaffe1e719d47bfa0d5c623a488af1bbb30070106e5901744228b5391863")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1369440)
