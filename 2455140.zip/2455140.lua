-- Lua provided by RyzenAPI 
-- Game: Wings of Seduction: Bust 'em out!
addappid(2455140)
addappid(2455141, 1, "e56d527feb9f291762063d087cf3b8d957180349512aeb778ae05f1a13234d4b")
addappid(2927450, 0, "576789dddab6f6630416f262c8c48c95e33a95e984fbe982f1e3fa29bd401c86")
