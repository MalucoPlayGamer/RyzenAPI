-- Lua provided by RyzenAPI
-- Game: Chronigma

-- MAIN APPLICATION
addappid(4051150)
