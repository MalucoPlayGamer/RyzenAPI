-- Lua provided by RyzenAPI
-- Game: HoverRace

-- MAIN APPLICATION
addappid(1862020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862021, 1, "68002d660950f33621d1866d2b658a023ffcd369ff6a36b0a67530bf62e3343b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
