-- Lua provided by RyzenAPI
-- Game: HoverRace

-- MAIN APPLICATION
addappid(1862020)
-- Game: addappid(1862020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862021, 1, "68002d660950f33621d1866d2b658a023ffcd369ff6a36b0a67530bf62e3343b")
