-- Lua provided by RyzenAPI
-- Game: Lost in Voice

-- MAIN APPLICATION
addappid(4182770)

-- MAIN APP DEPOTS / PACKAGES
addappid(4182771,0,"194252b78f5b9881277b4dd67ddc68c03ec24b7814cf11c905f77fee26e2e982")

