-- Lua provided by RyzenAPI
-- Game: Lost in Voice

-- MAIN APPLICATION
addappid(4182770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4182771,0,"194252b78f5b9881277b4dd67ddc68c03ec24b7814cf11c905f77fee26e2e982")

