-- Generated with Luie @ https://lua.tools/
-- 3399930 - Roulette Dungeon
-- Generated 2026-07-30 18:00:32 UTC
-- # Depots (Total/DLC/Shared): 2/1/0

-- Main AppID
addappid(3399930)

-- Main Depots
addappid(3399931, 1, "c400a8b9b65b6faf68ab54e44049f4409ffbd97ec3957301210946fe5e9f2143")
setManifestid(3399931, "70468278149460957", 2865464100)

-- DLC's (no depot keys required)
addappid(4755340) -- Roulette Dungeon - Supporter Pack

-- Missing Depots (We don't have the keys yet lol): 4787901
