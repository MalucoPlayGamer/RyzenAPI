-- Lua provided by RyzenAPI
-- Game: Cut it!

-- MAIN APPLICATION
addappid(3621440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3621441, 1, "b7c8e01f34204e2b81fe70104fe51c5e28666c94949f9fa773a1887dd38fc191")

