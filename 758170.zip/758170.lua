-- Lua provided by RyzenAPI
-- Game: Game: Krampus Quest

-- MAIN APPLICATION
addappid(758170)
-- Game: addappid(758170)

-- MAIN APP DEPOTS / PACKAGES
addappid(758171, 1, "04f285781edb8132a6ac8cd3acc5a6d9b5544a0487b3ff6f78b6a329f1e79aac")
