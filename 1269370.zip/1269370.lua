-- Lua provided by SkyAPI 
-- Game: 171
addappid(1269370)
addappid(1269371, 1, "7e1df33a1b894f1b0fc4c79a77610962f3609cf5368826bc77c7ec80241fdf09")
