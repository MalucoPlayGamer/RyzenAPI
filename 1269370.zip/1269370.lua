-- Lua provided by RyzenAPI
-- Game: addappid(1269370)

-- MAIN APPLICATION
addappid(1269370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269371, 1, "7e1df33a1b894f1b0fc4c79a77610962f3609cf5368826bc77c7ec80241fdf09")
