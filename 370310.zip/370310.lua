-- Lua provided by RyzenAPI
-- Game: Tompi Jones

-- MAIN APPLICATION
addappid(370310)

-- MAIN APP DEPOTS / PACKAGES
addappid(370311, 1, "d207abd986e5de80dffa4ab4e3ecf7b67776bfa5d0799bd47ba4467d4993da8d")
