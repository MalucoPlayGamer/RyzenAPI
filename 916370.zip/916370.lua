-- Lua provided by RyzenAPI
-- Game: Tempo Wizard

-- MAIN APPLICATION
addappid(916370)

-- MAIN APP DEPOTS / PACKAGES
addappid(916371, 1, "2c73ec064db18809be942bf668c6beb03a45816da24640f77674b5c7a277064c")
