-- Lua provided by RyzenAPI
-- Game: addappid(3173740)

-- MAIN APPLICATION
addappid(3173740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3173741, 1, "c6a61ad7ecc4eb8cce3d7d9f975bc634b22cfe7757ad16d89b58352f260042e5")
