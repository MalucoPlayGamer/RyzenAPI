-- Lua provided by RyzenAPI
-- Game: Allumeria

-- MAIN APPLICATION
addappid(3516590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3516591, 1, "e53c0e4b1dbfb35537d8a3346bfc40605cb63e072f21158ff4f1a8157c0ed20f")
