-- Lua provided by RyzenAPI
-- Game: 1357560

-- MAIN APPLICATION
addappid(1357560)
-- Game: addappid(1357560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1357561, 1, "bbc5dd4ff46560488015d56d15cffd7a75d9c6ea904f53d17d3d8068bbf43d21")
