-- Lua provided by RyzenAPI
-- Game: Total War: THREE KINGDOMS – The Furious Wild Original Soundtrack

-- MAIN APPLICATION
addappid(1637330)
-- Game: addappid(1637330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1637331, 1, "786118195045d416578fb71a1b78e876b024a85a1f4c19ff61e674f37154d616")
addappid(1637332, 1, "c4334e821101742d5f52bac5928f789616d332f15f4eae18995a2c0c00e82ac6")
