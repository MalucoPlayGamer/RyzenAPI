-- Lua provided by RyzenAPI
-- Game: addappid(1594170)

-- MAIN APPLICATION
addappid(1594170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594171, 1, "1ed61b5acc1a3bdec3bd9f4c20e48c1894caba65e8cd0197beb9afbd1ebbe61b")
