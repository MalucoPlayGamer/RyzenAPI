-- Lua provided by RyzenAPI
-- Game: AppID 575860

-- MAIN APPLICATION
addappid(575860)
-- Game: addappid(575860)

-- MAIN APP DEPOTS / PACKAGES
addappid(575861, 1, "690212534c3b01de5bac0e4fcc452afe154736cc86900c4dd976c9fe045f0722")
