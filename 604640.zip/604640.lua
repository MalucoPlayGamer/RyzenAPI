-- Lua provided by RyzenAPI 
-- Game: AppID 604640
addappid(604640)
addappid(604641, 1, "ab566cc1261717dfc4f61afc9f3ad62493385de557363b12875b71ab68b7cd0c")
