-- Lua provided by RyzenAPI
-- Game: Game: AppID 63710

-- MAIN APPLICATION
addappid(63710)
-- Game: addappid(63710)

-- MAIN APP DEPOTS / PACKAGES
addappid(63711, 1, "df5cb35bf6fb9fb96edf46dbd1580a5da418b3b8e5008274dba67c09c682baef")
addappid(63713, 1, "18e64c00aa559521758cbbab0c11f83b975a0f8926a158309adfb11a7c38a69f")
addappid(202961, 0, "d62b83f76a2e9d5afb086018ef24e074e668f8e7a6d464cc842b4a622b0c2e23")
