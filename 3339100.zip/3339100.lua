-- Lua provided by RyzenAPI
-- Game: Demon Alive

-- MAIN APPLICATION
addappid(3339100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3339101, 1, "ef183af16163ef05d18131a784fbd736fa37ba6795f2d158f277d832c3e9811d")

