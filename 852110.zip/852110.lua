-- Lua provided by RyzenAPI
-- Game: RetroMaze

-- MAIN APPLICATION
addappid(852110)

-- MAIN APP DEPOTS / PACKAGES
addappid(852111, 1, "4785f83fba98f9cc1a653bf22b392921f3493967f96cbfc77617bee05dab5012")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
