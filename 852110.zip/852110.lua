-- Lua provided by RyzenAPI
-- Game: Game: RetroMaze

-- MAIN APPLICATION
addappid(852110)
-- Game: addappid(852110)

-- MAIN APP DEPOTS / PACKAGES
addappid(852111, 1, "4785f83fba98f9cc1a653bf22b392921f3493967f96cbfc77617bee05dab5012")
