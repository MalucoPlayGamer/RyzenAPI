-- Lua provided by RyzenAPI
-- Game: addappid(2824510)

-- MAIN APPLICATION
addappid(2824510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2824511, 1, "6bbc7213f0745eac707d9815e405d552d47edb2deb7a35317ea112f18067ab86")
