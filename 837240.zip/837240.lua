-- Lua provided by RyzenAPI
-- Game: Game: AppID 837240

-- MAIN APPLICATION
addappid(837240)
-- Game: addappid(837240)

-- MAIN APP DEPOTS / PACKAGES
addappid(837241, 1, "1e8530c8753ff62a3fac58e50830844a6e8beb3089c679d5ff292d49efeabf42")
