-- Lua provided by RyzenAPI
-- Game: 906730

-- MAIN APPLICATION
addappid(906730)
-- Game: addappid(906730)

-- MAIN APP DEPOTS / PACKAGES
addappid(906731, 1, "1d83d90cf53a77411bdf5e192ec41ca1e7fe8a8f86f0ada75a7e3af8def3af46")
