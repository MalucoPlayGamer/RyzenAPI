-- Lua provided by RyzenAPI
-- Game: Yes, Your Grace Soundtrack

-- MAIN APPLICATION
addappid(1252080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252081, 1, "e3d15d086086f85533f1dd5bb6405a325bd6f72c53e54eee9d19186c943f52f6")
