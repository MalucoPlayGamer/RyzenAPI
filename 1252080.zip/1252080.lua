-- Lua provided by SkyAPI 
-- Game: Yes, Your Grace Soundtrack
addappid(1252080)
addappid(1252081, 1, "e3d15d086086f85533f1dd5bb6405a325bd6f72c53e54eee9d19186c943f52f6")
