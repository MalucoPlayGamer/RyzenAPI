-- Lua provided by RyzenAPI
-- Game: 风暴行动

-- MAIN APPLICATION
addappid(2167790)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2167791, 1, "cc1bbb151a63dd35b122c73f33eb18b74f050ea7dfac6b7106a357b30775e63a")

