-- Lua provided by RyzenAPI
-- Game: 风暴行动

-- MAIN APPLICATION
addappid(2167790)
-- Game: addappid(2167790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167791, 1, "cc1bbb151a63dd35b122c73f33eb18b74f050ea7dfac6b7106a357b30775e63a")
