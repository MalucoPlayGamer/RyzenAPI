-- Lua provided by RyzenAPI
-- Game: FortressCraft Evolved!

-- MAIN APPLICATION
addappid(254200)
addappid(319580)

-- MAIN APP DEPOTS / PACKAGES
addappid(254201, 1, "6e10492785c310342e8751c13eaeb5713c4a0eeb86f9a0737257adb3c0205d60")
addappid(254203, 1, "47c22dff12b5426388eed23ee1ebb6dcf9faf076b9bf375e4145e17f79819fac")
addappid(254204, 1, "c785997a449d5a5c530be4f37291b37c020d84e04293b08d8b8f2f1328911587")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(400400)
addappid(443690)
addappid(443691)
addappid(590460)
addappid(637130)
