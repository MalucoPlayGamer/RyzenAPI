-- 4655800's Lua and Manifest Created by Hubcap Manifest
-- Slime Soup
-- Created: August 24, 2026 at 15:07:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4655800, 1, "c584df725e03b4c557d0d01b07a6ab71a5a3049059866be0bf4b2e3692194664") -- Slime Soup
-- MAIN APP DEPOTS
addappid(4655801, 1, "1f2393c7cf7a009ed85ba4434ab58f64c67e5d87e41dbc1210b5fde167a6c1a0") -- Depot 4655801
setManifestid(4655801, "2467774336447805615", 170311784)
addappid(4655802, 1, "9884cecead1c016b2f936b8afdc27841e3a3e50a6e1ea750a5dc775cd01992df") -- Depot 4655802
setManifestid(4655802, "8444551209167546878", 143258544)