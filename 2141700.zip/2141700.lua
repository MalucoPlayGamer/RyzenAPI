-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2141700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2141700,0,"28e77d66a65877ef4ce95d5d4354ee2239f9a397af6eebb32eccc5046eebce54")
