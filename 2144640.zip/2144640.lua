-- Lua provided by SkyAPI 
-- Game: Endzone 2
addappid(2144640)
addappid(2144641, 1, "0a49695ed1feda3f6ad84629f01e5139b5793585af34810d1dbd600c5236c9bf")
