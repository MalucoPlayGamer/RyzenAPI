-- Lua provided by RyzenAPI
-- Game: Endzone 2

-- MAIN APPLICATION
addappid(2144640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2144641, 1, "0a49695ed1feda3f6ad84629f01e5139b5793585af34810d1dbd600c5236c9bf")

