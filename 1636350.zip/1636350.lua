-- Lua provided by RyzenAPI
-- Game: Nemezis: Mysterious Journey III Prologue

-- MAIN APPLICATION
addappid(1636350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636351, 1, "2e5a37d59519755bef0407f002ed99195ee89e1bc86d76bddc13483060e7e877")

