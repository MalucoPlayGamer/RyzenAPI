-- Lua provided by RyzenAPI
-- Game: Nemezis: Mysterious Journey III Prologue

-- MAIN APPLICATION
addappid(1636350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636351, 1, "2e5a37d59519755bef0407f002ed99195ee89e1bc86d76bddc13483060e7e877")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
