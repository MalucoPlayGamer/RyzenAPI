-- Lua provided by RyzenAPI
-- Game: EM: Shader Attack

-- MAIN APPLICATION
addappid(527490)

-- MAIN APP DEPOTS / PACKAGES
addappid(527491, 1, "02184fbd7e451ba6964c7eed37ae8a484a7970bf792a64e7ae834923eac63675")

