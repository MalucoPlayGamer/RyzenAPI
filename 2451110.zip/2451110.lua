-- Lua provided by RyzenAPI
-- Game: End of Knights

-- MAIN APPLICATION
addappid(2451110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2451111, 1, "0b6d44bb786eb49233524531da748631806c4a262aaa30fd9c0956ca89df9ed7")
