-- Lua provided by RyzenAPI
-- Game: Nimbus

-- MAIN APPLICATION
addappid(50000)

-- MAIN APP DEPOTS / PACKAGES
addappid(50001, 1, "04a7c995ee93b6faeb80a5ff8e7e637e330b69adde8c14488bed7d319ca99ccb")

