-- Lua provided by RyzenAPI
-- Game: 1394030

-- MAIN APPLICATION
addappid(1394030)
-- Game: addappid(1394030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394031, 1, "0dcc7304c633bd128adb803a405f00a1d337251d4b60cbb58cad3ad1449f159c")
