-- Lua provided by RyzenAPI
-- Game: Puyo Puyo Champions

-- MAIN APPLICATION
addappid(971620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(971621, 1, "c39116e96d03289003e12e5586936f7be1ee80dec41d515f8bc34dc858b22126")
