-- Lua provided by SkyAPI 
-- Game: AppID 971620
addappid(971620)
addappid(971621, 1, "c39116e96d03289003e12e5586936f7be1ee80dec41d515f8bc34dc858b22126")
