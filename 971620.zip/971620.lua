-- Lua provided by RyzenAPI
-- Game: 971620

-- MAIN APPLICATION
addappid(971620)
-- Game: addappid(971620)

-- MAIN APP DEPOTS / PACKAGES
addappid(971621, 1, "c39116e96d03289003e12e5586936f7be1ee80dec41d515f8bc34dc858b22126")
