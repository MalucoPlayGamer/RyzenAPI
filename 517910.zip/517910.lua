-- Lua provided by RyzenAPI
-- Game: Sisyphus Reborn

-- MAIN APPLICATION
addappid(517910)
addappid(520190)
addappid(520192)
addappid(520193)
addappid(530140)
addappid(530142)
addappid(530144)

-- MAIN APP DEPOTS / PACKAGES
addappid(517911, 1, "317c7c67d02f9a1a46f1a581d7934b4fd5a94bd87eab7e79603deb6f2db29883")
addappid(517913, 1, "f7b9313e37ecc79584ae31bb7467a9f88bdefe253d8cc4a0f76c873fe65bb198")
addappid(517915, 1, "e0423f5c35203d2f1525b9ea281514e34b4122c3f2f1fcf41b008b19d5639650")
addappid(517916, 1, "1788ab41bc62ac6b88feea0f3e04274f061fdff5792feb743ee101a45ed6306b")
addappid(517919, 1, "32180e90488285aa75795e82832b87f4cdcfda7db9395b7abb333a83904a2712")
addappid(520191, 0, "6f20b73c670a644c2adec8ce9c2ba4d8fd42960537d0256bfadabc87ab21ec3d")
addappid(530141, 0, "5e52d472832668d639eb290b5e29422059b71d75ffbf754811bf99d49ecf8cda")
addappid(530143, 0, "baa89ee3742ca08e96657dc833e34228d13fc4b86eb3982eebc37648c7454be6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
