-- Lua provided by RyzenAPI
-- Game: AppID 775500

-- MAIN APPLICATION
addappid(775500)
addappid(1590551)
addappid(1590560)
addappid(1590561)
addappid(1590562)
addappid(1590563)
addappid(1590564)
addappid(1590565)
addappid(1590566)
addappid(1590567)
addappid(1767240)
addappid(1790540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(775501, 1, "aa87f6b43f8263958e7662d3e0095761102c84d52e367598ab25b9078f8402d0")

