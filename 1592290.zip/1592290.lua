-- Lua provided by RyzenAPI
-- Game: Game: Paranoia Place: Escape Together

-- MAIN APPLICATION
addappid(1592290)
-- Game: addappid(1592290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592291, 1, "acd2f8b4b5818e8958a6f694789fe7f6c3127753e27e8da0c99dfe11a97bab22")
