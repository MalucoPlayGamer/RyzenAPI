-- Lua provided by RyzenAPI
-- Game: Galactic Rangers VR

-- MAIN APPLICATION
addappid(1151680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1151681, 1, "9c3b090c80f3bae0c68654bb00deba26bc71f3a00917bb4fe45e17c92954f61c")
addappid(1246300, 0, "341d35dc89c1622709eb84177efcfc3ff18259de585ca73e5801f77002d0c143")

