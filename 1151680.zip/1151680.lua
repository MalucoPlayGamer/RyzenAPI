-- Lua provided by RyzenAPI
-- Game: Game: AppID 1151680

-- MAIN APPLICATION
addappid(1151680)
-- Game: addappid(1151680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151681, 1, "9c3b090c80f3bae0c68654bb00deba26bc71f3a00917bb4fe45e17c92954f61c")
addappid(1246300, 0, "341d35dc89c1622709eb84177efcfc3ff18259de585ca73e5801f77002d0c143")
