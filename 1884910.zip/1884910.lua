-- Lua provided by RyzenAPI
-- Game: addappid(1884910)

-- MAIN APPLICATION
addappid(1884910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1884910,0,"f0567f60bb11c1ce5288f953334f27afb249d41a3fb83b0ddf8ef9a272bd178c")
