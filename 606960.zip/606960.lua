-- Lua provided by RyzenAPI
-- Game: Game: CRIMSON METAL Classic 1999

-- MAIN APPLICATION
addappid(606960)
-- Game: addappid(606960)

-- MAIN APP DEPOTS / PACKAGES
addappid(606961, 1, "0178714416f0337d044ae001b33f16e6989a752de6624fef7a0775c52df539d1")
