-- Lua provided by RyzenAPI
-- Game: CRIMSON METAL Classic 1999

-- MAIN APPLICATION
addappid(606960)

-- MAIN APP DEPOTS / PACKAGES
addappid(606961, 1, "0178714416f0337d044ae001b33f16e6989a752de6624fef7a0775c52df539d1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(614610)
addappid(614620)
addappid(614621)
addappid(779520)
addappid(1031750)
