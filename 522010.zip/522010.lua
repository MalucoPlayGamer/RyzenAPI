-- Lua provided by RyzenAPI
-- Game: Lost Crew

-- MAIN APPLICATION
addappid(522010)

-- MAIN APP DEPOTS / PACKAGES
addappid(522011, 1, "7e98bf0c957eb107ea98a0ef37bba18dceb6bbad036760f61be6b5a2967ac39c")

