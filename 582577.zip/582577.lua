-- Lua provided by RyzenAPI
-- Game: addappid(582577)

-- MAIN APPLICATION
addappid(582577)

-- MAIN APP DEPOTS / PACKAGES
addappid(615800,0,"0b217461ff22be91f2a121440dc39c32e8bd3e4e1f0030f15f6f55285e2dac86")
