-- Lua provided by RyzenAPI
-- Game: Another World Quest

-- MAIN APPLICATION
addappid(2083010)
-- Game: addappid(2083010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2083011, 1, "fc93308a5e576cf5cad4bbdd315069504dfdaffa9282ac990a4b65d0828dac6e")
