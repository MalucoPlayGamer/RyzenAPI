-- Lua provided by RyzenAPI
-- Game: Hentai University

-- MAIN APPLICATION
addappid(909000)

-- MAIN APP DEPOTS / PACKAGES
addappid(909001, 1, "acdd7c1fcec9242ac191fa952e068d2964531c4aac6554abc87f9ff3a3f1f059")
addappid(909002, 1, "9b6100abb58212fc1aec925527adc2f360bbc67de17eee8db2102bb1a76b12a9")
addappid(909003, 1, "b973774058225b53ef59bbfd9087d9cc2a9cb257e406bf4c9add8cc6c88feec5")
addappid(1056090, 0, "8e91b5924228d85644ab285aadbb750c0ee567c4123f1ec056b83bc5036ee76d")
addappid(1056100, 0, "5ce8bc870207d637f824d4703c5771ad8360d36ec865ae2df5003c56082521ff")

