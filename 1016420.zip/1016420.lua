-- Lua provided by RyzenAPI
-- Game: Tenebrous Dungeon

-- MAIN APPLICATION
addappid(1016420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016421, 1, "1e85529f2cbce338cdbc427e927b757ba50f17465565477ae5490fa23939ca12")

