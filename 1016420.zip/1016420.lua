-- Lua provided by SkyAPI 
-- Game: AppID 1016420
addappid(1016420)
addappid(1016421, 1, "1e85529f2cbce338cdbc427e927b757ba50f17465565477ae5490fa23939ca12")
