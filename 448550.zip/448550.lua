-- Lua provided by RyzenAPI
-- Game: Minimal

-- MAIN APPLICATION
addappid(448550)

-- MAIN APP DEPOTS / PACKAGES
addappid(448551, 1, "8c6567477d75a732ad163b1f370c22419c3c234f13e3c09fdb6c9dba897c5b29")
addappid(448552, 1, "dedafa3bc5a2a4168a493aa232aa7e982ee1a5564ace5f17589b0a81a5de8466")
addappid(448553, 1, "9a9a730dcacf9a4b898a980094ba7a28d5631d4b980e409cf6406772b498e866")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
