-- Lua provided by SkyAPI 
-- Game: Thunderbolt
addappid(803390)
addappid(803391, 1, "667e9b472c85bc8f64506429212109ff8ad198fff71444fcb175c124adc284f4")
