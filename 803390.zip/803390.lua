-- Lua provided by RyzenAPI
-- Game: addappid(803390)

-- MAIN APPLICATION
addappid(803390)

-- MAIN APP DEPOTS / PACKAGES
addappid(803391, 1, "667e9b472c85bc8f64506429212109ff8ad198fff71444fcb175c124adc284f4")
