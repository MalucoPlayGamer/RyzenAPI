-- Lua provided by RyzenAPI
-- Game: Game: Yappie! Knockout

-- MAIN APPLICATION
addappid(2382770)
-- Game: addappid(2382770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2382771, 1, "42275302be6b5f276e9d3b356bc55df5f4a1b9898f9c7cf1fb4cef09fd97941d")
