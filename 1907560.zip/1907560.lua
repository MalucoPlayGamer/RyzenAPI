-- Lua provided by RyzenAPI
-- Game: AppID 1907560

-- MAIN APPLICATION
addappid(1907560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1907561, 1, "cec7684c2b4b3684d1e25bb87d93ed4ca919b6a22057ad9f93d9872924cece8d")

