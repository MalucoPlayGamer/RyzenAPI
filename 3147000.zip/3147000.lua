-- Lua provided by RyzenAPI
-- Game: 3147000

-- MAIN APPLICATION
addappid(3147000)
-- Game: addappid(3147000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3147001, 1, "7382cc056d7a328ea769e5fdfe7c72ed70dde944b06befa39eb0296cdd1b503a")
