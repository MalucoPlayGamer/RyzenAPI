-- Lua provided by RyzenAPI
-- Game: Bear With Me - Collector's Edition

-- MAIN APPLICATION
addappid(783050)

-- MAIN APP DEPOTS / PACKAGES
addappid(783051, 1, "776b58ad1a8490ac89e3cbccbc9a1cf9a6b278fc73423f8bb35804dfddc86764")
addappid(783052, 1, "c2b5934c7dc2931535ec3339bc19f181bb39d80ad12b5eaacf7b05d4dd8273fc")
addappid(783053, 1, "137b7d6662d39f4c718aa3eda55863c65cc8c52daa213b49b2368edef8b823ef")
addappid(783054, 1, "4fb9b93873409f12ca91ecc2bc8d66558aa0082400b6a894346fdfff77a08a15")
