-- Lua provided by RyzenAPI
-- Game: Game: AppID 2374120

-- MAIN APPLICATION
addappid(2374120)
-- Game: addappid(2374120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2374121, 1, "2da16c7a30045f8f180165096a40f22a635582bb9f5f425bcec715f7a499e50e")
