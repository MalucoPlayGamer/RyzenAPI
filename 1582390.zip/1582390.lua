-- Lua provided by SkyAPI 
-- Game: AppID 1582390
addappid(1582390)
addappid(1582391, 1, "7d413f1c6d6f1ac91865a75fa12fb88391bbe8c484eda4103a5d21e7371f62f7")
