-- Lua provided by RyzenAPI 
-- Game: AppID 1227000
addappid(1227000)
addappid(1227001, 1, "0f19363a13b830c4974247a6c33ac67e67bca8705b106883d2ef883cb154cf2d")
