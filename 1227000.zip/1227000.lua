-- Lua provided by RyzenAPI
-- Game: Black Butterfly

-- MAIN APPLICATION
addappid(1227000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227001, 1, "0f19363a13b830c4974247a6c33ac67e67bca8705b106883d2ef883cb154cf2d")
