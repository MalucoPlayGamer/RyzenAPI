-- Lua provided by RyzenAPI
-- Game: Game: Ace of Spades: Battle Builder

-- MAIN APPLICATION
addappid(224540)
-- Game: addappid(224540)

-- MAIN APP DEPOTS / PACKAGES
addappid(224541, 1, "704fd586612359f2e5aa3c8f21ed07fd527c800ddd627e6a8e6e94041e8eceb5")
addappid(224542, 1, "ad0a1a7f099302089f55a4e657ca91f42af717a4acd33551f288d7a2575538e8")
addappid(224543, 1, "8c3f55ba38d3c0b00c0bd07d014fa756589575bb0c8d8aff7810d39370544387")
