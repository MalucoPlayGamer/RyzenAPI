-- Lua provided by RyzenAPI
-- Game: 1445650

-- MAIN APPLICATION
addappid(1445650)
-- Game: addappid(1445650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1445651, 1, "6661b245ada03a550f79f1e8367fdb8b6b4b819124d1c0d5468be5aed22a37f6")
