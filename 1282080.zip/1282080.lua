-- Lua provided by RyzenAPI
-- Game: Chang'an: The capital of Tang Dynasty

-- MAIN APPLICATION
addappid(1282080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282081, 1, "e9889416b25dc6b37c93685b746a9ee169d4b78ce0988818b0814e8490baeae3")
