-- Lua provided by SkyAPI 
-- Game: AppID 1213210
addappid(1213210)
addappid(1213211, 1, "3468f5d4f6b3e520cbc3f0e07308b1b5d4d78d088198c01827294ae44ca80467")
