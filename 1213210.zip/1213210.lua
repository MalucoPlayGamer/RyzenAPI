-- Lua provided by RyzenAPI
-- Game: AppID 1213210

-- MAIN APPLICATION
addappid(1213210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213211, 1, "3468f5d4f6b3e520cbc3f0e07308b1b5d4d78d088198c01827294ae44ca80467")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
