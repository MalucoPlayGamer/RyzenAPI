-- Lua provided by SkyAPI 
-- Game: Milk Bottle And Monster Girl 2
addappid(1917560)
addappid(1917561, 1, "2dfd79681913506ff98511beae90801a317291befa299c635c2da259357a6a67")
addappid(1928400, 0, "d37a4b6a35897296405a8a9b57fe9daa22a744181bc0a0057ea2a25f15cbe4d8")
