-- Lua provided by RyzenAPI
-- Game: Kromaticube

-- MAIN APPLICATION
addappid(1753440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1753442,0,"d3e088e507525ee851e85845e06b9962caec7311587a7a3b09fac4b866fb8475")

