-- Lua provided by RyzenAPI
-- Game: Boss Crushers

-- MAIN APPLICATION
addappid(773540)

-- MAIN APP DEPOTS / PACKAGES
addappid(773541,0,"4c9b3a31e1ae0bda32e9cfe2deb108372baf8fb8b2de6db9f724646c3ce44016")

