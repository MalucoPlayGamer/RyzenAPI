-- Lua provided by RyzenAPI
-- Game: 1981050

-- MAIN APPLICATION
addappid(1981050)
-- Game: addappid(1981050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981051, 1, "65f70b8ca37cdcb8a937b752195ddf810cfe252ed7c1bf04ee6d85bece63f3ef")
