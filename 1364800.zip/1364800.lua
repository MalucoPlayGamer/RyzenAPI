-- Lua provided by RyzenAPI
-- Game: addappid(1364800)

-- MAIN APPLICATION
addappid(1364800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364801, 1, "5880baf96b7874a142bcfa94c4b0c5c606b49e7eb5fa9634d90e1333d6aed867")
