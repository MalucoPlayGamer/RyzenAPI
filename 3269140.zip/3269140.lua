-- Lua provided by RyzenAPI
-- Game: Re:Flex Demo

-- MAIN APPLICATION
addappid(3269140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3269141, 1, "e8e5845e7a0a185f30085f5a4a345e0f69bdd22a2b5b6f66d31890728dad7abf")
