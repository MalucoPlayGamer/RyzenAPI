-- Lua provided by RyzenAPI
-- Game: Game: Lustful Roommates

-- MAIN APPLICATION
addappid(3556500)
-- Game: addappid(3556500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3556501, 1, "b84cd2cac9aeb8ae940259583cbf467e35e674f7a311e256a2654f2e5628e0b4")
