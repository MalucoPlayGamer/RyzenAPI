-- Lua provided by SkyAPI 
-- Game: AppID 1118740
addappid(1118740)
addappid(1118741, 1, "57c0cea2f3613308a2a0c5cdcf6dde2626aed7f3a988cff4c26dfc3020fe9128")
addappid(1118743, 1, "bf5f667ffd0b54869f55c1a0e6611fc589fc84acce3e15062dbf50024076f505")
