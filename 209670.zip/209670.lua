-- Lua provided by RyzenAPI 
-- Game: AppID 209670
addappid(209670)
addappid(209671, 1, "05870b41f66b3548c520a27504ad74a9b5a5005157556576ebc3266de267fb8b")
addappid(209672, 1, "6185d2cf8fb7b21b74a7905e7715bf75b9c2548c5f34cf849b75b139cd30a279")
addappid(228985)
