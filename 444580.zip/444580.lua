-- Lua provided by RyzenAPI
-- Game: 444580

-- MAIN APPLICATION
addappid(444580)
-- Game: addappid(444580)

-- MAIN APP DEPOTS / PACKAGES
addappid(444581, 1, "d407148d74ee2e4625c40386a6510bb0046c3c15f4da94db91db3dc15bb1a1b0")
