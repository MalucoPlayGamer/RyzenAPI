-- Lua provided by RyzenAPI
-- Game: Neighbours back From Hell

-- MAIN APPLICATION
addappid(1283190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283191, 1, "c482a5a6304d7f7d3df9a771f629969364f0c0019ce2c646d92ababfbf04b889")

