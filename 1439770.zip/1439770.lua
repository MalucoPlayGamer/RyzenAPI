-- Lua provided by RyzenAPI 
-- Game: AppID 1439770
addappid(1439770)
addappid(1439771, 1, "83b99b593aa96594c89cfd45e76900537b86092b02bcb30953f39ce683293053")
