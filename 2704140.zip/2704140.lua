-- Lua provided by RyzenAPI
-- Game: Fresh Story 2

-- MAIN APPLICATION
addappid(2704140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2704141, 1, "eff0692376352d83163a6269514b4c3f22839f5591df159f024d53e2072e265b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4331720)
