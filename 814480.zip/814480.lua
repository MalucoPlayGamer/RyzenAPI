-- Lua provided by RyzenAPI
-- Game: Mini World: Block Art

-- MAIN APPLICATION
addappid(814480)

-- MAIN APP DEPOTS / PACKAGES
addappid(814481, 1, "8a2b85b8d471d0a165cb9ca99e46bfe04eaae758e0c029b0b966a909ebec139b")
