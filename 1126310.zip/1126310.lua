-- Lua provided by RyzenAPI
-- Game: AppID 1126310

-- MAIN APPLICATION
addappid(1126310)
-- Game: addappid(1126310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1126311, 1, "ffede9d3fd8a313ad609dd6a7d13389d61a37a47b78a06c0da1efaba6b26dcc8")
addappid(1145540, 0, "19f377a0129dce6d8bca126066ce6038d6276f7a6dd5088cf328cbc77d5b723a")
addappid(1302500, 0, "6a9aa6e67fb3fb00f2eb6abac8f8bf308c25e4506b3f9b56d7de7386340704c1")
