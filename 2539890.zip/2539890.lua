-- Lua provided by RyzenAPI
-- Game: Game: VR Dinosaur Island Paradise

-- MAIN APPLICATION
addappid(2539890)
-- Game: addappid(2539890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2539891, 1, "d931ef557aaab3612a498e7c09edc0e8299ca14904472379835ff3c0cce08cee")
