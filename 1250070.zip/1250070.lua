-- Lua provided by RyzenAPI 
-- Game: Curtains
addappid(1250070)
addappid(1250071, 1, "27ed2c58a008f1d97b897a2e16611204a860a6ec5bfb55e8eb8114c6270d6998")
