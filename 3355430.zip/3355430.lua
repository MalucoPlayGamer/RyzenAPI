-- Lua provided by RyzenAPI
-- Game: Alice Mesmerizing Episodes of Neurosis (AMEN)

-- MAIN APPLICATION
addappid(3355430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3355431, 1, "a0890a8c5a8d754e41c86e390997241b386953139edb98e36e9d1c01b1dc7235")

