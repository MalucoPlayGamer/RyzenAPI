-- Lua provided by RyzenAPI
-- Game: addappid(2505420)

-- MAIN APPLICATION
addappid(2505420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505420,0,"08b1f4f4621e5de2f6a333d602baa797eb78df23b16ccaa9a1d0107cd8dd9ca6")
