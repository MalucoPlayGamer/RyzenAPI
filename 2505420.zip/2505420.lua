-- Lua provided by RyzenAPI
-- Game: My Lovely Daughter Digital Artbook

-- MAIN APPLICATION
addappid(2505420)
-- Game: addappid(2505420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505420,0,"08b1f4f4621e5de2f6a333d602baa797eb78df23b16ccaa9a1d0107cd8dd9ca6")
