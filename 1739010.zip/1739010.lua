-- Lua provided by RyzenAPI
-- Game: Out of the Park Baseball 23

-- MAIN APPLICATION
addappid(228988)
addappid(1739010)
addappid(1739011)
addappid(1739012)
addappid(1739013)

-- MAIN APP DEPOTS / PACKAGES
addappid(1739014,0,"18d52f6a72ff1362f9f2c6610e017289c007e0d2935a9c4c0c7a06ddb95020ee")
addappid(1739015,0,"3e5fed1e8427178c3a8e7c090bbc7fdde26a39f8dc12ced48bddf4123def79cf")
addappid(1739016,0,"cf50bf58ec9a1da37bcc869bdfaaaff90872e85bf4d13319bd20a523a33a6185")
addappid(1739017,0,"d85ec6ad06e53be9c0135dc797991a8dd6951cf048f8477c8140c85716e3b9ff")

