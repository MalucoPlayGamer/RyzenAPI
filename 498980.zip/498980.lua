-- Lua provided by RyzenAPI 
-- Game: AppID 498980
addappid(498980)
addappid(498981, 1, "7ff28912fbaf74c40904cf63f2cba3da2ed8a3e6cfff3fa286fb5d1f3024f35a")
