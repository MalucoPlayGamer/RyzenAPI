-- Lua provided by RyzenAPI
-- Game: Metanet Hunter CD

-- MAIN APPLICATION
addappid(586570)

-- MAIN APP DEPOTS / PACKAGES
addappid(586571,0,"6f46a45b10454fb82dc37958ef4ad9d594bae5b14379ce20305baec7bbf14ed2")

