-- Lua provided by RyzenAPI
-- Game: 1815400

-- MAIN APPLICATION
addappid(1815400)
-- Game: addappid(1815400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815401, 1, "b84d2d7dcfeb38ae855030889aea94148ad8d71a078ef0a08269550ee14fcb57")
