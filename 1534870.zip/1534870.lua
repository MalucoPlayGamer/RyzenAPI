-- Lua provided by RyzenAPI
-- Game: Game: 风之界限 the border of wind

-- MAIN APPLICATION
addappid(1534870)
-- Game: addappid(1534870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1534871, 1, "54bbe032de69b9dc7ebd89cfea6b312accdd876d0ba060c26cdc43f96336e4dd")
