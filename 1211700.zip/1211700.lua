-- Lua provided by RyzenAPI
-- Game: Trantor: The Last Stormtrooper

-- MAIN APPLICATION
addappid(1211700)
-- Game: addappid(1211700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1211701, 1, "edfd0988fa4642692098e59e942ed6629b09b9463e7958635d5658ac72653b8c")
