-- Lua provided by RyzenAPI
-- Game: Terminator: Resistance

-- MAIN APPLICATION
addappid(954740)

-- MAIN APP DEPOTS / PACKAGES
addappid(954741, 1, "4159d3017619889a426e09a0c6691af103245053c33f26593c6e8e82c54a50d3")
