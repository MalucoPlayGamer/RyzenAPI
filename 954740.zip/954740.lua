-- Lua provided by RyzenAPI
-- Game: Terminator: Resistance

-- MAIN APPLICATION
addappid(954740)
addappid(1451140)
addappid(1755190)

-- MAIN APP DEPOTS / PACKAGES
addappid(954741,0,"4159d3017619889a426e09a0c6691af103245053c33f26593c6e8e82c54a50d3")
addappid(1451140,0,"0d84a68d4032999a6faaf1083923b5edfa13ba853396321cf550b01ae5e0ea3e")

