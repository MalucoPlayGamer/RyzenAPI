-- Lua provided by RyzenAPI
-- Game: Terminator: Resistance

-- MAIN APPLICATION
addappid(954740)
addappid(1451140)
addappid(1755190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(954741,0,"4159d3017619889a426e09a0c6691af103245053c33f26593c6e8e82c54a50d3")
addappid(1451140,0,"0d84a68d4032999a6faaf1083923b5edfa13ba853396321cf550b01ae5e0ea3e")

