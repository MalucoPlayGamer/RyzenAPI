-- Lua provided by SkyAPI 
-- Game: Dreams with Furry 🦊
addappid(2066110)
addappid(2066111, 1, "6b74a2bf3752210aedec7370c71c25724b8fd6972800a57c547d9bd380c875bb")
addappid(2116070, 0, "63e1aeca7795a21a5f8984ba5cd2327024ed2caa5b24af0017a0fde0507a5a2e")
