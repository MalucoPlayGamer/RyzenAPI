-- Lua provided by RyzenAPI
-- Game: 五行乱斗

-- MAIN APPLICATION
addappid(3660520)
-- Game: addappid(3660520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3660521, 1, "5f82c371d61627fd699169169ba9ac6163e71e740b2720b98e9bd44b869aa6de")
