-- Lua provided by RyzenAPI
-- Game: Trinity Dungeon

-- MAIN APPLICATION
addappid(689460)

-- MAIN APP DEPOTS / PACKAGES
addappid(689461,0,"c8911dc538b709b6faa6879c5510d9f13a83f8c5c705531d98e353615eb782d5")

