-- Lua provided by RyzenAPI
-- Game: AppID 2392760

-- MAIN APPLICATION
addappid(2392760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2392761, 1, "888ccb0dce9d1e731dc38b06abfe1647aa78bd84e34c870645311c8a65eb07f6")
addappid(2392762, 1, "8908b8927e200c3d78d80f7673483dc3f25b74a3744f4a1396e36c894a6cb30a")
addappid(2392763, 1, "bace4e0f1f0a739442a644e9dec461cfa033b452d756ee9a0aab8691c3a8584c")
addappid(2392764, 1, "a7415579f559ce85450e5db5cebf1742b820d14b6243a1c1080d664cd965a0ad")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2581090)
addappid(2654500)
