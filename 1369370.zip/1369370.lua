-- Lua provided by RyzenAPI
-- Game: AppID 1369370

-- MAIN APPLICATION
addappid(1369370)
-- Game: addappid(1369370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1369371, 1, "5445c7c1cbae9c80705199a6a257c07177fb5b6964773a8dae4fb1a54ee17d38")
addappid(1369372, 1, "2893a33bd53f6ebb1bebc2664be396ac1f013c6a90d4557ef6dcdeb716883e8b")
