-- Lua provided by RyzenAPI
-- Game: Game: GRAVEN The Purple Moon Prophecy

-- MAIN APPLICATION
addappid(467490)
-- Game: addappid(467490)

-- MAIN APP DEPOTS / PACKAGES
addappid(467491, 1, "69fdbd733d34a3d3ee6a23923dad44f8c476c8cb9ce3d93af3e0743c6b7a6c18")
