-- Lua provided by SkyAPI 
-- Game: GRAVEN The Purple Moon Prophecy
addappid(467490)
addappid(467491, 1, "69fdbd733d34a3d3ee6a23923dad44f8c476c8cb9ce3d93af3e0743c6b7a6c18")
