-- Lua provided by RyzenAPI
-- Game: 1700770

-- MAIN APPLICATION
addappid(1700770)
-- Game: addappid(1700770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700771, 1, "8881c09a325805931b6b94ed76c19c28d08606127dbe2fbb454b1be63dbf6184")
