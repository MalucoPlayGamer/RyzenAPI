-- Lua provided by RyzenAPI
-- Game: Bullet Girls Phantasia

-- MAIN APPLICATION
addappid(1163590)
addappid(1198140)
addappid(1198141)
addappid(1198142)
addappid(1198143)
addappid(1198144)
addappid(1198145)
addappid(1198146)
addappid(1198147)
addappid(1198148)
addappid(1198149)
addappid(1198160)
addappid(1198161)
addappid(1198162)
addappid(1198163)
addappid(1198164)
addappid(1198165)
addappid(1198166)
addappid(1198180)
addappid(1198181)
addappid(1198182)
addappid(1198183)
addappid(1198184)
addappid(1198185)
addappid(1198186)
addappid(1198187)
addappid(1198188)
addappid(1198189)
addappid(1198190)
addappid(1198191)
addappid(1198192)
addappid(1198193)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163591,0,"76df1aad5ccfdd2627b481c9c6f59d19482f48d179e9a47d303797f580e6f592")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
