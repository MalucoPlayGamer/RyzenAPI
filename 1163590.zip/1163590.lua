-- Lua provided by RyzenAPI
-- Game: Game: AppID 1163590

-- MAIN APPLICATION
addappid(1163590)
addappid(1198193)
-- Game: addappid(1163590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1163591, 1, "76df1aad5ccfdd2627b481c9c6f59d19482f48d179e9a47d303797f580e6f592")
