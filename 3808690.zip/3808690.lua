-- Lua provided by RyzenAPI
-- Game: Pathogenic

-- MAIN APPLICATION
addappid(3808690) -- Pathogenic
-- addappid(4814930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3808691, 1, "f7b1f01fda7deb5e4e64a7f5e98b34ce7c2189e7f771bbd522540ef46691d470") -- Depot 3808691
addappid(3808692, 1, "d2974e761461fa81d699bff160c51b78754823236191c80eed6a96af8f441787") -- Depot 3808692
addappid(3808693, 1, "3e4e3791f3cf3f0d18c65d6718aa128dd603a8984dbd6a858b0f575673cfb28c") -- Depot 3808693
