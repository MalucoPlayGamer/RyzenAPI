-- 3808690's Lua and Manifest Created by Hubcap Manifest
-- Pathogenic
-- Created: July 17, 2026 at 15:05:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3808690, 1, "61b1e8e08bb6bd5518a71efe86fdf82d9e5af6afd56a8c482a4b033fac31d6dc") -- Pathogenic
-- MAIN APP DEPOTS
addappid(3808691, 1, "f7b1f01fda7deb5e4e64a7f5e98b34ce7c2189e7f771bbd522540ef46691d470") -- Depot 3808691
setManifestid(3808691, "1249753827228773911", 1690445741)
addappid(3808692, 1, "d2974e761461fa81d699bff160c51b78754823236191c80eed6a96af8f441787") -- Depot 3808692
setManifestid(3808692, "1212823587739416678", 1655959613)
addappid(3808693, 1, "3e4e3791f3cf3f0d18c65d6718aa128dd603a8984dbd6a858b0f575673cfb28c") -- Depot 3808693
setManifestid(3808693, "4036151270279796120", 1910175522)
-- DLCS WITH DEDICATED DEPOTS
-- Pathogenic - Artbook  Soundtrack (AppID: 4814930)
addappid(4814930)
addappid(4814930, 1, "40659977f2e5970114ae54e42c6169ac4c43dadbf13b4df604a0cc6d4bce31ba") -- Pathogenic - Artbook  Soundtrack - Depot 4814930
setManifestid(4814930, "916318396906099037", 1316161496)