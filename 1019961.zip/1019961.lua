-- Lua provided by RyzenAPI
-- Game: addappid(1019961)

-- MAIN APPLICATION
addappid(1019961)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019961,0,"e79dffed0c941b1267b1534a9edaf27876cb25ef2fdc92db2a8d8527ddfa2b22")
