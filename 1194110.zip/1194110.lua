-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228987)
addappid(1194110)
addappid(1194111)
addappid(1194113)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194112,0,"50a5bf0b2cfb7da9052b2cde368d59a0b9514e6668e6c0786f4b038e2551fb63")
