-- Lua provided by RyzenAPI
-- Game: addappid(1095290)

-- MAIN APPLICATION
addappid(1095290)
addappid(2433540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1095291, 1, "df633f5ee25c8023c65d7db7312f6ba0509d2956764bb44e4f1288a654157c4a")
