-- Lua provided by RyzenAPI
-- Game: Cards of Patience

-- MAIN APPLICATION
addappid(1693660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693661, 1, "4bd602a6744307f46589475a4de589ddbc8ae2a4ce9216fef37a1a537ebf1ce9")

