-- Lua provided by RyzenAPI
-- Game: 1423330

-- MAIN APPLICATION
addappid(1423330)
-- Game: addappid(1423330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1423331, 1, "c2565fa044de5c05db05ddfa74f0fbb39e900c8442af4f9bbd73934970085539")
