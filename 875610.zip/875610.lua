-- Lua provided by RyzenAPI
-- Game: Loop-Loop DX

-- MAIN APPLICATION
addappid(875610)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1194021)
