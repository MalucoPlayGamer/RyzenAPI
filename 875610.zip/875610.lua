-- Lua provided by RyzenAPI
-- Game: Loop-Loop DX

-- MAIN APPLICATION
addappid(875610)

