-- Lua provided by RyzenAPI
-- Game: AppID 3044170

-- MAIN APPLICATION
addappid(3044170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3044171, 1, "7f03b8f138a77a21fce55bd8d3fba29795ef32265b591d184dd37aee6e2a769d")

