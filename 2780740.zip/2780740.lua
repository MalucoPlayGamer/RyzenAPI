-- Lua provided by RyzenAPI
-- Game: Mutant Boxing League VR

-- MAIN APPLICATION
addappid(2780740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780741, 1, "295208f0d9266f61a67d22f65e881199cf693acf6ad81e9539813544dc3020dd")

