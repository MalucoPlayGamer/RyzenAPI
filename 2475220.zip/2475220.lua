-- Lua provided by RyzenAPI
-- Game: Deidthraw

-- MAIN APPLICATION
addappid(2475220)
-- Game: addappid(2475220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475221, 1, "96f604cfbf863994ba87f5888a2aece465de93abff2c6c412933975289f13586")
