-- Lua provided by SkyAPI 
-- Game: Dangerous Fellows: Otome Game
addappid(2375040)
addappid(2375041, 1, "8b89de3c4320579d77844c25100625b090f0f58135a16d331b94158fc729344b")
