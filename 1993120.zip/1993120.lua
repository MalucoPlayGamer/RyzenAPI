-- Lua provided by RyzenAPI
-- Game: Death Below

-- MAIN APPLICATION
addappid(1993120)
-- Game: addappid(1993120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1993121, 1, "308823ab2d5fe7bb2b63dfc44de8526d47a3ff157687dff8282e11ae1669a4bf")
