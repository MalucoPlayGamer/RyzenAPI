-- Lua provided by RyzenAPI
-- Game: Death Below

-- MAIN APPLICATION
addappid(1993120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1993121, 1, "308823ab2d5fe7bb2b63dfc44de8526d47a3ff157687dff8282e11ae1669a4bf")

