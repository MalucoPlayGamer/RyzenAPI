-- Lua provided by RyzenAPI
-- Game: AppID 2128490

-- MAIN APPLICATION
addappid(2128490)
-- Game: addappid(2128490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2128491, 1, "8dabde2cf7f1be18489d57bdebefda29f57c1158d1e821f1b174f32da41084f5")
