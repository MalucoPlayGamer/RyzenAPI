-- Lua provided by RyzenAPI
-- Game: Iron Meat Soundtrack

-- MAIN APPLICATION
addappid(3118390)
-- Game: addappid(3118390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3118391, 1, "8d6fd96717862d70b889f1bcc5eedb383f679c7a3d63ff04ad3b401d9c0dd75a")
addappid(3118392, 1, "a78ad305b6debb81bc855958eec0f4c2a72fc7cece093ce8b2cc89af3365f8fa")
