-- Lua provided by RyzenAPI
-- Game: Guns of Succubus

-- MAIN APPLICATION
addappid(1515820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515822,0,"ef89a791e95926163ef11031015d959faabd73aa5ccb1ed3c7e8d9feb192e52c")
addappid(1515823,0,"a1537d2d08bba0fb999da158435ce59342e4dd200769b8dbb91cdd6b34c9d103")

