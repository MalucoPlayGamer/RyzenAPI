-- Lua provided by RyzenAPI
-- Game: Super Bunny Man

-- MAIN APPLICATION
addappid(673750)

-- MAIN APP DEPOTS / PACKAGES
addappid(673751, 1, "ef8e2faa6ce07ab491309abf7236035899b0ffacebb9e67c94c43ef39e9db256")
addappid(673752, 1, "ce41cc79d5435eace9ea012608624c9011832aa19b1177636544a8159ddefcf4")
addappid(673753, 1, "69b83c4681d49f60187dec02af5734fdfe3f5f0d2bd446662abde2a607cf214e")
