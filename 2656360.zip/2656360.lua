-- Lua provided by RyzenAPI
-- Game: Small World

-- MAIN APPLICATION
addappid(2656360)
-- Game: addappid(2656360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2656361, 1, "9871549eecc1e9e4fea89ba5928498ee3f81964c9f2336228f8ae41f6745c6ac")
