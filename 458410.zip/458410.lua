-- Lua provided by RyzenAPI
-- Game: Cabals: Magic & Battle Cards

-- MAIN APPLICATION
addappid(458410)
-- Game: addappid(458410)

-- MAIN APP DEPOTS / PACKAGES
addappid(458411, 1, "90557947cae98e0ff70386012a0ee6d29ad4231e08256ee79737761a58986529")
addappid(458412, 1, "8762a0f738ceeb040901c823999c67b249d1c3c4ba0cba961edf57d10ce8df1c")
