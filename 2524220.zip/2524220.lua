-- Lua provided by RyzenAPI
-- Game: 古魂

-- MAIN APPLICATION
addappid(2524220)
addappid(2604350)
addappid(2607670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524223,0,"f41aaccd2056d49a1f5966672da006ddfd954ae64267191b03d67bbb94ff134e")

