-- Lua provided by RyzenAPI
-- Game: Game: Misha Adventures

-- MAIN APPLICATION
addappid(1683240)
-- Game: addappid(1683240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1683241, 1, "71cd27dfd51f31f2370a87748271cde77b06cc3e9e3917ef61cbd11787a690d0")
