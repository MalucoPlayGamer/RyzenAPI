-- Lua provided by SkyAPI 
-- Game: Middle Age Conquest
addappid(1535190)
addappid(1535191, 1, "0792aad467621f049b279a8a0b667717f97301de79929a34ef4b03ec70ede076")
