-- Lua provided by RyzenAPI 
-- Game: A Promise Best Left Unkept - Aya Edition
addappid(2479300)
addappid(2479301, 1, "c049e29b9c3052c891d0c923a2edf1782883358c664a9d86a26a4ee63531ebc9")
