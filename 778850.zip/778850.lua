-- Lua provided by RyzenAPI
-- Game: Please close the doors

-- MAIN APPLICATION
addappid(778850)

-- MAIN APP DEPOTS / PACKAGES
addappid(778854,0,"3bc5704213e3f18a487dcc2d79d010dae6d5bd24450359cacb5e394d031924ab")
addappid(778855,0,"2bad75481d69237760ca0072232007cdac9f01553b672672b28826bea6f3f62c")

