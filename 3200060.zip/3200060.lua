-- Lua provided by RyzenAPI
-- Game: Game: SANAE's Sylphid Breeze

-- MAIN APPLICATION
addappid(3200060)
-- Game: addappid(3200060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3200061, 1, "eddd5e73653d5081bec25e8b8e6efa84e67583fb0ee16fd51a71472719227be3")
