-- Lua provided by RyzenAPI
-- Game: addappid(1502240)

-- MAIN APPLICATION
addappid(1502240)
addappid(1513850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502241, 1, "56eb3d8c161391117656ed65eeb2be113520a038ab98cef0d34f5e79740f25ac")
