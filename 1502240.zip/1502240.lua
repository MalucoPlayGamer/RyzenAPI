-- Lua provided by SkyAPI 
-- Game: LineArt Jigsaw Puzzle - Erotica Christmas
addappid(1502240)
addappid(1502241, 1, "56eb3d8c161391117656ed65eeb2be113520a038ab98cef0d34f5e79740f25ac")
addappid(1513850)
