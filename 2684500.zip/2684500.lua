-- Lua provided by RyzenAPI
-- Game: Alpha League

-- MAIN APPLICATION
addappid(2684500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684501, 1, "6b3bb823f461438fae22cc4c9a32457c20aaa853ee43ccc230853914f1ba70d1")

