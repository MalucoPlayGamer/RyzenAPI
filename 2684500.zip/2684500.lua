-- Lua provided by RyzenAPI
-- Game: Alpha League

-- MAIN APPLICATION
addappid(2684500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684501, 1, "6b3bb823f461438fae22cc4c9a32457c20aaa853ee43ccc230853914f1ba70d1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
