-- Lua provided by SkyAPI 
-- Game: Tainted Grail: Conquest — Soundtrack
addappid(1738770)
addappid(1738771, 1, "e94f23168b4dee641b392a000c7651ac0432cba6cb6fae6b597bcdb6fad3df59")
addappid(1738772, 1, "0a1d34e36261081b5677d5b2896e21f3c56b31e65609cab15086502f6bf76aad")
