-- Lua provided by RyzenAPI
-- Game: Lies of P : Soundtrack

-- MAIN APPLICATION
addappid(1938420)
-- Game: addappid(1938420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1938421, 1, "3a598dabbe2783774bd506a68f7da2189eabe7234c03bdfce88cefed14bab3d8")
addappid(1938422, 1, "ababb5e54025724a4a56f8f0f08d33282cd3ef1296cb746627419bf317d9baa4")
addappid(1938423, 1, "f1a270c1b76e7723c154a571d3d0e70521e697e67dd1e75fab4d6de0e1199a5d")
addappid(1938424, 1, "27a7a3f53278e69bd81334632b6db38ed9d5b16f4865d48e46bbe78e45543ee0")
