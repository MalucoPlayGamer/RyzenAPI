-- Lua provided by RyzenAPI
-- Game: AppID 521100

-- MAIN APPLICATION
addappid(521100)
-- Game: addappid(521100)

-- MAIN APP DEPOTS / PACKAGES
addappid(521101, 1, "ee185779556d3b529cfbe0b8759d5c373769e7f4ee070376c1ee5f2d86ecae0f")
addappid(521102, 1, "81273babe45a10c4fd1221b30bf278132a522839e392027557d53d232a021fd7")
addappid(521103, 1, "84a302dad6adacbb8546cc1efabfddecb056a530451a35a6b7eaa29e3370e1f6")
addappid(533230, 0, "70c854b8f9a3b4a4b8c219d4e56531ec113cf7bd56dd3cfd3b56ea5430b83c7c")
