-- Lua provided by RyzenAPI
-- Game: Neverlooted Dungeon Demo

-- MAIN APPLICATION
addappid(1394770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394771, 1, "ebf5d745b8501748c06406b1758ffbcbfd334c02d1ac66ccafe6e20d11e148c3")

