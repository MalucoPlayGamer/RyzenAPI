-- Lua provided by RyzenAPI
-- Game: Game: Brotato

-- MAIN APPLICATION
addappid(1942280)
-- Game: addappid(1942280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1942281, 1, "414bbd1359869bcea73f5e7f3a911ba4a8f487dee2cf0290cd2409f9ae410582")
addappid(2868390, 0, "d7b9838655889932b120a4bd3426b37af101b334e6602a5898a1d54e4dc8f0f8")
