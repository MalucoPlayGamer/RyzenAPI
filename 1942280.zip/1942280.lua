-- Lua provided by RyzenAPI
-- Game: Brotato

-- MAIN APPLICATION
addappid(2868390)
addappid(3281080)
addappid(4498220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1942280, 1, "bf5b1b4f28c4d1839b85a86e3bfdabc5435f8cc848ca968aec505c86c6ecb52e")
addappid(1942281, 1, "414bbd1359869bcea73f5e7f3a911ba4a8f487dee2cf0290cd2409f9ae410582") -- (windows)
addappid(1942282, 1, "3494683f2e70afb7ae55048ce6d4c4fd6139904d7d783355a35bbac4d1fd2a3b") -- (linux)
addappid(1942283, 1, "15d4a4598c84d88d00a61ef4baedbd99bbf62e47402a887ead1872b8aa5c89e7") -- (macos)
addappid(2868390, 1, "d7b9838655889932b120a4bd3426b37af101b334e6602a5898a1d54e4dc8f0f8")
addappid(3281081, 1, "e6d0a71df9e37dbb1c69621d45ab42a35f0bc52e1c716e17bac88ffb29fa6cc6")
addappid(3281082, 1, "0b62d5b0ce0ca5679ccbfafa9035fcbd744dccf03d97e6f2305ef8d28bcb8c58")

