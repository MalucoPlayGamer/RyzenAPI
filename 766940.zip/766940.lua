-- Lua provided by RyzenAPI
-- Game: Snares of Ruin

-- MAIN APPLICATION
addappid(766940)

-- MAIN APP DEPOTS / PACKAGES
addappid(766941, 1, "e7bff3957d8b3e5dd3e9ed01593da2e26cfd82e4048935699f17fb4a9ab46783")

