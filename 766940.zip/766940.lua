-- Lua provided by RyzenAPI 
-- Game: AppID 766940
addappid(766940)
addappid(766941, 1, "e7bff3957d8b3e5dd3e9ed01593da2e26cfd82e4048935699f17fb4a9ab46783")
