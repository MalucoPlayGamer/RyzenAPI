-- Lua provided by RyzenAPI 
-- Game: DEEPWATER Demo
addappid(3316560)
addappid(3316561, 1, "260bec9b64f25a1bb1b41759b738d90e5a2da34e57940c7a41a8b88d887fd1a7")
