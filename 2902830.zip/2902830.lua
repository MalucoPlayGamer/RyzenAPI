-- Lua provided by RyzenAPI 
-- Game: Commando Hero 2 : First Blood
addappid(2902830)
addappid(2902831, 1, "725c59a08499b377f26b8789b9d30e17bfd0d543717c4d51a4afab2ce53390fe")
