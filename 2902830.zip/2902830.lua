-- Lua provided by RyzenAPI
-- Game: Commando Hero 2 : First Blood

-- MAIN APPLICATION
addappid(2902830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2902831, 1, "725c59a08499b377f26b8789b9d30e17bfd0d543717c4d51a4afab2ce53390fe")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
