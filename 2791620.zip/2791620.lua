-- Lua provided by RyzenAPI
-- Game: Delicious Donut

-- MAIN APPLICATION
addappid(2791620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2791621, 1, "4fbe2fde3244cb2e4492c6b449d3c7825e06a8cbe72ac04a197985015358af12")
