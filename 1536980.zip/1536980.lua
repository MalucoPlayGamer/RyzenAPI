-- Lua provided by RyzenAPI
-- Game: Glass Masquerade 3: Honeylines

-- MAIN APPLICATION
addappid(1536980)
addappid(2666180)
addappid(3073200)
addappid(3691010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536981, 1, "79d44fbaab425191d7d4dae87062773e4021c88156b2bd41d6c2e3c6d750458e")
addappid(1536982, 1, "ae0e6259d8dcb6b204d425c18874c6a916136698f3b2d8af34521c2bf660c450")

