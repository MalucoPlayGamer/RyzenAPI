-- Lua provided by RyzenAPI
-- Game: Mediterranea Inferno

-- MAIN APPLICATION
addappid(2103680)
-- Game: addappid(2103680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2103681, 1, "1f43b05541f77d6a40e9b83a1c30c4ec2c29c926bd86d4057cd33cf27bb0595a")
addappid(2103682, 1, "cc3f2d4413ba6990f0059f1318a97f171c365da7cf31380f936dcc409374a8b3")
