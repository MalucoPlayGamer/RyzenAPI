-- Lua provided by RyzenAPI
-- Game: 1442000

-- MAIN APPLICATION
addappid(1442000)
-- Game: addappid(1442000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442000,0,"0f6dba0bf31d2984136e3409e1ec45407be5cffd92e98dc0cd4d66e406d28fd1")
