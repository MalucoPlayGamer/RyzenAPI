-- Lua provided by RyzenAPI
-- Game: Dark Void™

-- MAIN APPLICATION
addappid(45710)

-- MAIN APP DEPOTS / PACKAGES
addappid(45711,0,"72e33f82b00ae4adc6c5942963101406d45fb1565c6379bbde4034cdbf13660b")

