-- Lua provided by RyzenAPI
-- Game: 天外武林 (Traveler of Wuxia)

-- MAIN APPLICATION
addappid(2088160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2088161, 1, "9713ad297d1534bc244210d967712dc83b1031b4c7b5ecd8676553b291a35407")
addappid(2088162, 1, "05e5b3ce9e8839bf9446fc6e697ba5d06de8299a53e2c6dd31c8dd4dc88986a0")
addappid(2088163, 1, "5477ede40ae0380eaedb0e963e347119f22065bce1229d3ff188cdb50d593105")
addappid(2088164, 1, "db3b8e0ac593e6f9842466767bde3f12145ce913d20f249f637c260aa9a33668")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
