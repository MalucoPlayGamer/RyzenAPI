-- Lua provided by RyzenAPI
-- Game: AppID 474020

-- MAIN APPLICATION
addappid(474020)
-- Game: addappid(474020)

-- MAIN APP DEPOTS / PACKAGES
addappid(474021, 1, "701b5aa79f8e965c698cfee23fec923ab90e13028c46d82f8c80a3cd0c304ef0")
