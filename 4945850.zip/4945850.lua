-- Generated with Luie @ https://lua.tools/
-- 4945850 - Galumb
-- Generated 2026-08-22 15:57:43 UTC
-- # Depots (Total/DLC/Shared): 3/0/2

-- Main AppID
addappid(4945850)

-- Main Depots
addappid(4945851, 1, "d6db5363b047e5d3dcc579a72704e5276d62b67f2f34095ad043ed638dcf49dd")
setManifestid(4945851, "4927155126455455523", 4132025344)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
