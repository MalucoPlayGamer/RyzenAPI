-- Lua provided by RyzenAPI
-- Game: Albatross

-- MAIN APPLICATION
addappid(2528400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2528401, 1, "7dfb854bd703abcb2729d7d3be03c82f3a535fc7cbd15b4f6358d9570022eaf2")

