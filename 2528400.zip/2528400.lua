-- Lua provided by RyzenAPI
-- Game: Game: Albatross

-- MAIN APPLICATION
addappid(2528400)
-- Game: addappid(2528400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2528401, 1, "7dfb854bd703abcb2729d7d3be03c82f3a535fc7cbd15b4f6358d9570022eaf2")
