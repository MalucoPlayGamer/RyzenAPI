-- Lua provided by RyzenAPI 
-- Game: CantEscapeTheBackrooms
addappid(2169140)
addappid(2169141, 1, "2a3d7d93b40d4c25557bb15e8e938e2e8961f14b5525e10fb1b53309ec40b37b")
