-- Lua provided by RyzenAPI
-- Game: CantEscapeTheBackrooms

-- MAIN APPLICATION
addappid(2169140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2169141, 1, "2a3d7d93b40d4c25557bb15e8e938e2e8961f14b5525e10fb1b53309ec40b37b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
