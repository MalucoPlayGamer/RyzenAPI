-- Lua provided by RyzenAPI
-- Game: CantEscapeTheBackrooms

-- MAIN APPLICATION
addappid(2169140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2169141, 1, "2a3d7d93b40d4c25557bb15e8e938e2e8961f14b5525e10fb1b53309ec40b37b")

