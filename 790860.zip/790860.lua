-- Lua provided by RyzenAPI
-- Game: Game: Chocolate makes you happy 3

-- MAIN APPLICATION
addappid(790860)
-- Game: addappid(790860)

-- MAIN APP DEPOTS / PACKAGES
addappid(790861, 1, "f7c8b5cd4ca36c0689f9d7ca4ef2c20211ce53a1055624aa15ea470aa64801f1")
