-- Lua provided by RyzenAPI
-- Game: Game: Dark Hours: Prologue

-- MAIN APPLICATION
addappid(3064370)
-- Game: addappid(3064370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3064371, 1, "f3547e3fc63c4e013d63d279238704a1fd36d148ea0ccb384ebdaf157496ecc1")
