-- Lua provided by RyzenAPI
-- Game: Succubus Hunt

-- MAIN APPLICATION
addappid(3213010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213011,0,"da4470840166aed8cf0682e178a046ff4278d08bfeaa77a02dfeb1fd866df872")

