-- Lua provided by RyzenAPI 
-- Game: Separated Demo
addappid(3110110)
addappid(3110111, 1, "f1b571ee12775c4f26a9e34475b796353b1983942a1f5b1599d343f2fdb897c5")
