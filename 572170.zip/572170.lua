-- Lua provided by RyzenAPI
-- Game: DeadTruth: The Dark Path Ahead

-- MAIN APPLICATION
addappid(572170)
-- Game: addappid(572170)

-- MAIN APP DEPOTS / PACKAGES
addappid(572171, 1, "0a9a6d6508835e893f98d7895f67c931dc299e74364f7959c9530e20647438d4")
addappid(590540, 0, "92df1235427e94d4a66296a34042e7e529a0edc163b548611f3cd3d47baaf366")
