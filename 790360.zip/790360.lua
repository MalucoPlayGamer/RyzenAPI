-- Lua provided by RyzenAPI 
-- Game: AppID 790360
addappid(790360)
addappid(790361, 1, "896bf9313d14e3c8873ca98325d468517bcff99185cce4c064995761afdb1ca5")
