-- Lua provided by RyzenAPI
-- Game: WarriOrb

-- MAIN APPLICATION
addappid(790360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(790361, 1, "896bf9313d14e3c8873ca98325d468517bcff99185cce4c064995761afdb1ca5")

