-- Lua provided by RyzenAPI
-- Game: addappid(790360)

-- MAIN APPLICATION
addappid(790360)

-- MAIN APP DEPOTS / PACKAGES
addappid(790361, 1, "896bf9313d14e3c8873ca98325d468517bcff99185cce4c064995761afdb1ca5")
