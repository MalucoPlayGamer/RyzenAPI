-- Lua provided by RyzenAPI 
-- Game: AppID 638850
addappid(638850)
addappid(638851, 1, "27739f7ee46f532cbffc9facc8c578cf2cac09bfe5b43e96c7d32405c89e00c8")
addappid(890021, 0, "58ed514960080eb498c4bc5e061b497f1c1405f051d2b7ad560c25e694f7b7bb")
