-- Lua provided by RyzenAPI
-- Game: 昆仑墟

-- MAIN APPLICATION
addappid(2161530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2161531, 1, "dbace5c4667b51302a9a529633f9c2b67de89ba3b0097a48ebf4961a8d9e6557")
