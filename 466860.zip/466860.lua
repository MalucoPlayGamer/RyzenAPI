-- Lua provided by RyzenAPI
-- Game: 上帝之城 I：监狱帝国 [City of God I - Prison Empire]

-- MAIN APPLICATION
addappid(466860)
addappid(851318)
addappid(949610)
addappid(1121390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(466861, 1, "4f514e74b0df3452ee09cfb0e8189dcff9e77a5eebb7bafc693e37837b5e93a6")

