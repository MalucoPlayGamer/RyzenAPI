-- Lua provided by RyzenAPI
-- Game: Game: 上帝之城 I：监狱帝国 [City of God I - Prison Empire]

-- MAIN APPLICATION
addappid(466860)
-- Game: addappid(466860)

-- MAIN APP DEPOTS / PACKAGES
addappid(466861, 1, "4f514e74b0df3452ee09cfb0e8189dcff9e77a5eebb7bafc693e37837b5e93a6")
