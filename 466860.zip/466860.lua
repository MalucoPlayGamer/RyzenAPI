-- Lua provided by RyzenAPI
-- Game: 466860

-- MAIN APPLICATION
addappid(466860)
-- Game: addappid(466860)

-- MAIN APP DEPOTS / PACKAGES
addappid(466861, 1, "4f514e74b0df3452ee09cfb0e8189dcff9e77a5eebb7bafc693e37837b5e93a6")
