-- Lua provided by RyzenAPI
-- Game: BLOCKPOST LEGACY

-- MAIN APPLICATION
addappid(706990)

-- MAIN APP DEPOTS / PACKAGES
addappid(706991, 1, "c4c545ede35b85fd8b39f2a46321eebed69e9a6b5d1090968eba4ed4e0635555")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
