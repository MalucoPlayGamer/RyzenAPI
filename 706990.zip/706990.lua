-- Lua provided by RyzenAPI
-- Game: 706990

-- MAIN APPLICATION
addappid(706990)
-- Game: addappid(706990)

-- MAIN APP DEPOTS / PACKAGES
addappid(706991, 1, "c4c545ede35b85fd8b39f2a46321eebed69e9a6b5d1090968eba4ed4e0635555")
