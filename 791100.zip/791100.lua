-- Lua provided by RyzenAPI
-- Game: Paint Skills

-- MAIN APPLICATION
addappid(791100)

-- MAIN APP DEPOTS / PACKAGES
addappid(791101, 1, "26d4fdcc0112ad402408170d391dc67ea08d9f4237be51ca2a6dcf117776e183")

