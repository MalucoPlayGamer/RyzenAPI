-- Lua provided by RyzenAPI
-- Game: Parasitism

-- MAIN APPLICATION
addappid(4010520)

-- MAIN APP DEPOTS / PACKAGES
addappid(4010521, 1, "a47afa927ed45ff9c6360aaca34a545c70c81218a28fdffbe4447fca9412e4c6")
