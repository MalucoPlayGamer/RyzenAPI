-- Lua provided by SkyAPI 
-- Game: Battle Worlds: Kronos
addappid(237470)
addappid(237471, 1, "de1a9610855cf792b52553017908d2b1364beb9a4366975f22a7b0ab993360d0")
addappid(261590, 0, "49b4fb68bd44ce5191ded01790f801deb74e24b804b11c3574ac5db2ce8d7f3b")
