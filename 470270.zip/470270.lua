-- Lua provided by RyzenAPI
-- Game: Tribal Pass

-- MAIN APPLICATION
addappid(470270)
addappid(703160)

-- MAIN APP DEPOTS / PACKAGES
addappid(470271, 1, "4b47c2d9efb85d87108ca0956a57e6541357b033381aa48341414cfb0e9911e6")
addappid(470272, 1, "0a24ed2e93271aa47819f81cf2dff188eabcf98955c8a68a781aa841d8b7585d")
addappid(470273, 1, "ceb8c395bf1ca768506766c245a1f5e7295b05e4b853bd35dd29eddde379857e")

