-- Lua provided by RyzenAPI
-- Game: 3625000

-- MAIN APPLICATION
addappid(3625000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3625000,0,"8ab670d7c2b5afa80a9ccd8b248c6c7853677aa43dc6932d9fbeee4d7aad6b47")
