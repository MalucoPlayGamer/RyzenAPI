-- Lua provided by SkyAPI 
-- Game: Pocket Oasis
addappid(2348830)
addappid(2348831, 1, "227cf461b3b5f228a6fad3d4f2c9e92433d64d38d918e71908af6e7101264dd0")
