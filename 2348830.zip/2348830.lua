-- Lua provided by RyzenAPI
-- Game: Pocket Oasis

-- MAIN APPLICATION
addappid(2348830)
-- Game: addappid(2348830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2348831, 1, "227cf461b3b5f228a6fad3d4f2c9e92433d64d38d918e71908af6e7101264dd0")
