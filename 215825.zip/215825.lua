-- Lua provided by RyzenAPI
-- Game: Darksiders II - Argul's Tomb

-- MAIN APPLICATION
addappid(215825)

-- MAIN APP DEPOTS / PACKAGES
addappid(215825,0,"a3c0b37126dd56327c69c529a1f32287687c33b0f946da1054fcd5b5fd946a76")

