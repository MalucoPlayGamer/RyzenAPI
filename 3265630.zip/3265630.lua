-- Lua provided by RyzenAPI
-- Game: Holy Shoot Demo

-- MAIN APPLICATION
addappid(3265630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3265631, 1, "cffa84731e76846dd059966d64cd5810558efe0636d518b526163a444b33ef94")

