-- Lua provided by RyzenAPI
-- Game: Disney Tangled

-- MAIN APPLICATION
addappid(318950)
-- Game: addappid(318950)

-- MAIN APP DEPOTS / PACKAGES
addappid(318951, 1, "5834ef176e1a70f1c431d993d7e11926bdd8e2b1502d8e918fb523549a361a43")
addappid(318952, 1, "b147724681763e45f70dae7cf19edd87056d112a6b80804b7437629b45013c00")
addappid(318953, 1, "72cfacc367864b8632d90b23bf884cbcaa8fb0d9ed619b98ce5d7f41872d59bf")
addappid(318955, 1, "a16996c234c5117fed9fffccdb2ad84970742c5e2511e6c8b8eba730770acd9e")
addappid(318956, 1, "ebeadda86a04440722bc4cc6a7448dfc3abd2306a5d20519249b22b673b5a179")
addappid(319110, 0, "704ffaa03db51b6798cf8414ebb89f8ad2ad82d7c75eecbadda7740095a94f17")
