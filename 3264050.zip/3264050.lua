-- Lua provided by SkyAPI 
-- Game: IN THE FACADE WE TRUST™
addappid(3264050)
addappid(3264051, 1, "b7549833b764b6556847f0e311bac067ba9290b94f46232662ba432e9d9dc119")
