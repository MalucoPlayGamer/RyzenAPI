-- Lua provided by RyzenAPI
-- Game: addappid(2065590)

-- MAIN APPLICATION
addappid(2065590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2065591, 1, "f02e6f59e0170377af55718e662064dac9f8a120edf9a10e339893233d6ebbb1")
