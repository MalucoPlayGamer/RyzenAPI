-- Lua provided by RyzenAPI
-- Game: Mad Miner

-- MAIN APPLICATION
addappid(2458700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2458701, 1, "6cd261183db1b50bba7acd51179293836359ecfec8bd8b8d05f8aecc514a03eb")
addappid(2458702, 1, "d87c9d5f22956630255c65e0e3ce70b1cb462ea99ed865efc924a91c3720a9c3")

