-- Lua provided by RyzenAPI
-- Game: Game: AppID 713940

-- MAIN APPLICATION
addappid(713940)
-- Game: addappid(713940)

-- MAIN APP DEPOTS / PACKAGES
addappid(713941, 1, "0fa09babe438791abb6e496e1a025de992867f96893db19fdec9766741b145c9")
