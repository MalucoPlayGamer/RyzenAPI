-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Jiang Wei "Julian Costume" / 姜維「ユリアン風コスチューム」

-- MAIN APPLICATION
addappid(1246843)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246843,0,"22cabe41c03a5414aeb19fc4b1d0d18b5caec5826c688f750f8285448ed0dbf8")

