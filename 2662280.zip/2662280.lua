-- Lua provided by RyzenAPI
-- Game: 2662280

-- MAIN APPLICATION
addappid(2662280)
-- Game: addappid(2662280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2662281, 1, "405f464cb5e18812307f0c37238e90be49a39c32afa009fa64a1a3d277d2364e")
