-- Lua provided by RyzenAPI
-- Game: Immortal Seeker

-- MAIN APPLICATION
addappid(2285570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285571, 1, "f8189daf891e2783c001ef929169afd4b673312efa35c4a76ca38c8f5cd308cc")

