-- Lua provided by RyzenAPI
-- Game: Immortal Seeker

-- MAIN APPLICATION
addappid(2285570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2285571, 1, "f8189daf891e2783c001ef929169afd4b673312efa35c4a76ca38c8f5cd308cc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
