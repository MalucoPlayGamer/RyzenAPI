-- Lua provided by SkyAPI 
-- Game: Immortal Seeker
addappid(2285570)
addappid(2285571, 1, "f8189daf891e2783c001ef929169afd4b673312efa35c4a76ca38c8f5cd308cc")
