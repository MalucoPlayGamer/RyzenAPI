-- Lua provided by RyzenAPI
-- Game: 2988720

-- MAIN APPLICATION
addappid(2988720)
-- Game: addappid(2988720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2988721, 1, "455cb75e5ca8a6fab1dc8f7e9c8d1beb091f0fbda955dd0a16cf05568bb76bed")
