-- Lua provided by RyzenAPI
-- Game: AppID 3109210

-- MAIN APPLICATION
addappid(3109210)
-- Game: addappid(3109210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3109211, 1, "a8f7193aa138da04c6a627e3b7330c450272234e9e9e810aaa80d87e89055f4d")
