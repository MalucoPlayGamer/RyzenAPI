-- Lua provided by RyzenAPI
-- Game: Gravity Light

-- MAIN APPLICATION
addappid(706240)

-- MAIN APP DEPOTS / PACKAGES
addappid(706241,0,"7bda7e9f5cfce7eeb87864a14b98df297bcf705fbdeb9b46a4b2f029e68d53c8")
addappid(706242,0,"68896349456a9890289204c7651ec0d7e5c0517bc2705ad072a1e80a1293b785")

