-- Lua provided by RyzenAPI
-- Game: addappid(130)

-- MAIN APPLICATION
addappid(130)
addappid(228988)

-- MAIN APP DEPOTS / PACKAGES
addappid(131, 1, "467956f135f8f36d998f4208b7b1a5b7d011cf60a4c4cab3fb787514db40d8af")
addappid(132, 1, "991c1bf547e7250dc24cbdaa3863ea3bedd042c08ee47745b5445392f16071ef")
