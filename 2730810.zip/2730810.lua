-- Lua provided by RyzenAPI
-- Game: EVERYBODY'S GOLF HOT SHOTS

-- MAIN APPLICATION
addappid(2730810)
addappid(3675430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(2730811, 1, "57f111c74135e33030a503760d3e9e3c2e6b5f01acbc60cc62e4f231a50435bc")

