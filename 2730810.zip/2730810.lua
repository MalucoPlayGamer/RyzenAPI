-- Lua provided by RyzenAPI
-- Game: addappid(2730810)

-- MAIN APPLICATION
addappid(2730810)
addappid(3675430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2730811, 1, "57f111c74135e33030a503760d3e9e3c2e6b5f01acbc60cc62e4f231a50435bc")
