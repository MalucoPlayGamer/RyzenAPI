-- Lua provided by RyzenAPI
-- Game: Russian Train Trip

-- MAIN APPLICATION
addappid(1785440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1785441, 1, "20602464e4fdea1ab90b634bd0097a4a2e1910bd9b0782b17331b9853d6c85b9")

