-- Lua provided by RyzenAPI
-- Game: Game: Russian Train Trip

-- MAIN APPLICATION
addappid(1785440)
-- Game: addappid(1785440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1785441, 1, "20602464e4fdea1ab90b634bd0097a4a2e1910bd9b0782b17331b9853d6c85b9")
