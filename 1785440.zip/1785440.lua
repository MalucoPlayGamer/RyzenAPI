-- Lua provided by SkyAPI 
-- Game: Russian Train Trip
addappid(1785440)
addappid(1785441, 1, "20602464e4fdea1ab90b634bd0097a4a2e1910bd9b0782b17331b9853d6c85b9")
