-- Lua provided by RyzenAPI
-- Game: TUNNEL DIVERS

-- MAIN APPLICATION
addappid(569720)
addappid(626490)
addappid(626491)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(569721, 1, "634fc7204f951ea87dba55e0f9006127ca40d7fd781865837be7ac7bd9aa211b")
