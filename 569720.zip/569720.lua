-- Lua provided by RyzenAPI
-- Game: TUNNEL DIVERS

-- MAIN APPLICATION
addappid(569720)
-- Game: addappid(569720)

-- MAIN APP DEPOTS / PACKAGES
addappid(569721, 1, "634fc7204f951ea87dba55e0f9006127ca40d7fd781865837be7ac7bd9aa211b")
