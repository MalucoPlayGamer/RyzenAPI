-- Lua provided by RyzenAPI
-- Game: 625580

-- MAIN APPLICATION
addappid(625580)
addappid(723470)
-- Game: addappid(625580)

-- MAIN APP DEPOTS / PACKAGES
addappid(625581, 1, "48dcf17d92c885f25fb61741a3f07cfb2fdfa1a1532d966898cd9cdb5ed7ff16")
