-- Lua provided by RyzenAPI
-- Game: The Cleansing

-- MAIN APPLICATION
addappid(625580)
addappid(723470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(625581, 1, "48dcf17d92c885f25fb61741a3f07cfb2fdfa1a1532d966898cd9cdb5ed7ff16")
