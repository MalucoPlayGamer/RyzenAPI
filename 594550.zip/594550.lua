-- Lua provided by RyzenAPI
-- Game: Arma: Cold War Assault Mac/Linux

-- MAIN APPLICATION
addappid(594550)

-- MAIN APP DEPOTS / PACKAGES
addappid(594551, 1, "c764e47f9b205634824ee96e6606302a6783a041b77e3bfbeb74bcee3137d9d5")
addappid(594552, 1, "3da041ad41439a1112094934761b0379762f42d60e3a23a3027e32972fbb8d7b")
addappid(594553, 1, "a134b24321775b7c8a9425bab3a6c3f0cbddb0db8e4aa410583512764aa31cbe")

