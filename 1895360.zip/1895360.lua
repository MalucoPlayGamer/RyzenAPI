-- Lua provided by RyzenAPI
-- Game: Game: AppID 1895360

-- MAIN APPLICATION
addappid(1895360)
-- Game: addappid(1895360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895361, 1, "cfb3a479bd31653847ad2d4c4c292b56419148d9c86c050d3f61901bd64d65df")
