-- Lua provided by RyzenAPI 
-- Game: AppID 1895360
addappid(1895360)
addappid(1895361, 1, "cfb3a479bd31653847ad2d4c4c292b56419148d9c86c050d3f61901bd64d65df")
