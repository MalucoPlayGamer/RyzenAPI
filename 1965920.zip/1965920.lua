-- Lua provided by RyzenAPI
-- Game: addappid(1965920)

-- MAIN APPLICATION
addappid(1965920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1965921, 1, "b3be2693a3492185073133e008ed2dd35ce40a60680c113ad6a67b12fcd3999f")
