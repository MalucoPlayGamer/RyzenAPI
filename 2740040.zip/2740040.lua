-- Lua provided by RyzenAPI
-- Game: Game: New ZhaoYun

-- MAIN APPLICATION
addappid(2740040)
-- Game: addappid(2740040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2740041, 1, "440c956d94ad1095071ab9112ef8794bb3861d733dc5633b2f186911c2241fd5")
