-- Lua provided by SkyAPI 
-- Game: New ZhaoYun
addappid(2740040)
addappid(2740041, 1, "440c956d94ad1095071ab9112ef8794bb3861d733dc5633b2f186911c2241fd5")
