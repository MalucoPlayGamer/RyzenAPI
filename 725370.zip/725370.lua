-- Lua provided by RyzenAPI
-- Game: Doctor Who Infinity

-- MAIN APPLICATION
addappid(725370)
-- Game: addappid(725370)

-- MAIN APP DEPOTS / PACKAGES
addappid(725372,0,"aa7db16987fab2b62037db41c338198949030f38a5b7539d141c31a14d2982c8")
