-- Lua provided by RyzenAPI
-- Game: addappid(509530)

-- MAIN APPLICATION
addappid(509530)

-- MAIN APP DEPOTS / PACKAGES
addappid(509531, 1, "4fcb01daaa49ac270ed8b633cfd60bd6f88f921d26cd9bb8ea1e4db14d7e2b14")
