-- Lua provided by RyzenAPI
-- Game: Gods and Nemesis: of Ghosts from Dragons

-- MAIN APPLICATION
addappid(509530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(509531, 1, "4fcb01daaa49ac270ed8b633cfd60bd6f88f921d26cd9bb8ea1e4db14d7e2b14")

