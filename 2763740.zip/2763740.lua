-- Lua provided by RyzenAPI
-- Game: Revolution Idle

-- MAIN APPLICATION
addappid(2763740)
-- Game: addappid(2763740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2763741, 1, "6f855378782899f2266505faeb6e87e721fc1c45e1c5aba850b203b0d28d90f1")
