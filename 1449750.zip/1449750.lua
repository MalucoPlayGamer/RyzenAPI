-- Lua provided by RyzenAPI
-- Game: Space Commander: War and Trade

-- MAIN APPLICATION
addappid(1449750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449751, 1, "9e5e31a0beeafafd728634dc859cdbd26528bde801464e8220b59f458aa27622")
addappid(1449752, 1, "0b0179cade03a52ddf484415c599eae5aa0e9121b79af8e5a2eee08ad677defb")
addappid(1449753, 1, "50e52226efa7ef62f37295056df0bd130767423e925ea3b89cccfe8cc1249839")
