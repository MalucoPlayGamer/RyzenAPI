-- Lua provided by RyzenAPI
-- Game: Game: Terror in the Kitchen

-- MAIN APPLICATION
addappid(2443790)
-- Game: addappid(2443790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443791, 1, "7ea86b33456231d7612373a2b5c4cbf6e759532126c624ee4dd480fbdf3b4542")
