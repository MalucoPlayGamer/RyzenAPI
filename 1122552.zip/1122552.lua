-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Guitar - Intermediate Linear Playing Exercise 2

-- MAIN APPLICATION
addappid(1122552)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122552,0,"b125e43d51ee24a8b3cec2db7f6d7c05ab5c7219dbd36a3038438db753866342")

