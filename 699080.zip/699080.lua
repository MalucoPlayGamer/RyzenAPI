-- Lua provided by RyzenAPI
-- Game: AppID 699080

-- MAIN APPLICATION
addappid(699080)
-- Game: addappid(699080)

-- MAIN APP DEPOTS / PACKAGES
addappid(699081, 1, "f4998e93286e660d8bfca1dab32760686468a4ca623649d104ef3bae88649609")
