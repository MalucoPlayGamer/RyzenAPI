-- Lua provided by SkyAPI 
-- Game: AppID 699080
addappid(699080)
addappid(699081, 1, "f4998e93286e660d8bfca1dab32760686468a4ca623649d104ef3bae88649609")
