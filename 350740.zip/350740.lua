-- Lua provided by RyzenAPI
-- Game: Game: AppID 350740

-- MAIN APPLICATION
addappid(350740)
-- Game: addappid(350740)

-- MAIN APP DEPOTS / PACKAGES
addappid(350741, 1, "1f8ccb4df3a78a5999532b831d6bfc81eb9a062a96aa1b7736d0daf094cb0dd2")
addappid(350742, 1, "7a954b1ca794faec525d1751ace6bdda6202d28a0f494c9679037a1748a0884b")
addappid(350743, 1, "ca448f28cba629ddc42d79b9200b230614c8e9519c2f8ee3d0267ca8c22675ec")
