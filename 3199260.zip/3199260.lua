-- Lua provided by RyzenAPI
-- Game: addappid(3199260)

-- MAIN APPLICATION
addappid(3199260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3199261, 1, "039f40569f81c1dc7cf9d23ff1c3a4874aa1a3b74b1771c9f51090a29fbdf3b9")
