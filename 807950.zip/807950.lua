-- Lua provided by RyzenAPI
-- Game: Piano Cat

-- MAIN APPLICATION
addappid(807950)

-- MAIN APP DEPOTS / PACKAGES
addappid(807952,0,"7bcf005473b9248d472cb60f1acbb982d39c42666ed349566e3c6763639fc817")
