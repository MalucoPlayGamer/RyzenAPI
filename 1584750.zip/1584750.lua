-- Lua provided by RyzenAPI
-- Game: Cloud Cutter

-- MAIN APPLICATION
addappid(1584750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1584751, 1, "aa663ee4b810d9402f38a1e6da3b1756d84d365f6aebdc18471a5b00094a8dc0")

