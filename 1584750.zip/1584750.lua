-- Lua provided by RyzenAPI 
-- Game: Cloud Cutter
addappid(1584750)
addappid(1584751, 1, "aa663ee4b810d9402f38a1e6da3b1756d84d365f6aebdc18471a5b00094a8dc0")
