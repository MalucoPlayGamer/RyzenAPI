-- Lua provided by RyzenAPI
-- Game: Demon King Domination - Soundtrack

-- MAIN APPLICATION
addappid(921640)

-- MAIN APP DEPOTS / PACKAGES
addappid(921641, 1, "38f8fa155046ec79324a9809ecc91256af12ef66ad821986ef7554b7378ed7eb")
addappid(921642, 1, "895849a0b8073f217e61ff400fb02e2402bba02da33ec9f1f5188ce4bc296c68")
