-- Lua provided by RyzenAPI
-- Game: addappid(1046070)

-- MAIN APPLICATION
addappid(1046070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046071, 1, "a5f747ebe780e0ba094b8cb37dd7c5a531131c008332644ee19f8c5b747baf77")
