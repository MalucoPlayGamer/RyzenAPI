-- Lua provided by RyzenAPI
-- Game: Dreams Keeper Solitaire

-- MAIN APPLICATION
addappid(1312760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1312761, 1, "65a0dc8bde42de8ef6d4f569a27c7c5c2e6aefc355699dbb5880c5ce0d54107c")
addappid(1312764, 1, "50724d6773dbe476b605de8ae399bee8aab42170643a0fd64076afa2bc1f1a91")
