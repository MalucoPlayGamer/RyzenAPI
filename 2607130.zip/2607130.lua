-- Lua provided by RyzenAPI
-- Game: Fractured Realms - Season 1 Demo

-- MAIN APPLICATION
addappid(2607130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2607131, 1, "2311419b0d0c4e96b57c1a58b00a9d3cb22bbc311c27bccb2257ee5c70a08eb6")

