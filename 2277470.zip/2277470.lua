-- Lua provided by SkyAPI 
-- Game: AppID 2277470
addappid(2277470)
addappid(2277471, 1, "6616f30f6dfa3ba5d83499e164641c63d4bb982839b1eb7544a59c7f0b11616f")
