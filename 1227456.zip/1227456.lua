-- Lua provided by RyzenAPI
-- Game: RetroArch - NeoCD

-- MAIN APPLICATION
addappid(1227456)
-- Game: addappid(1227456)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227456,0,"72e3737e9a6370b793d4d2959f2a9e220b9bc75e706b9ded34ca65784fde7d4e")
addappid(1789980,0,"6604959b3945352f35d33c26702c9a44b889635d643533d47f70dbb0e9e6de67")
addappid(1789981,0,"c7aa1dc3ed69265f7ca9eee008a6aada4d85428a3abfb29180fdbec03a26fa15")
