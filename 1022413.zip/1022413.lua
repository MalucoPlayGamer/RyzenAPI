-- Lua provided by RyzenAPI
-- Game: addappid(1022413)

-- MAIN APPLICATION
addappid(1022413)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022413,0,"57127dc03b79077d4c31bdedfdc4545b6fcced686986341ea6d200e05890a269")
