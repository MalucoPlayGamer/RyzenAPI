-- Lua provided by RyzenAPI
-- Game: 1670240

-- MAIN APPLICATION
addappid(1670240)
-- Game: addappid(1670240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1670241, 1, "27ed1c3a3b5e9a54bb3012c56fb01211d89a5b6ad8bfb0ff75b7270d32194ab5")
addappid(1670242, 1, "9abd8ece6c11f8fc51c1c34c4a01c2829e14d2ee5cf0818738f6b2b7d7a6d601")
addappid(1670243, 1, "e77df32cac3c772334e5edc0dc82f751413f701df92ee9fa75dd90e9538aad59")
