-- Lua provided by RyzenAPI
-- Game: Femdom Waifu

-- MAIN APPLICATION
addappid(1024800)
addappid(1024810) -- Femdom Waifu: Censored Mode
addappid(1055910) -- Femdom Waifu: Foot Fetish Pack
addappid(1083900) -- Femdom Waifu: Netorare Mode
addappid(1106820) -- Femdom Waifu: Swimsuit Pack
addappid(1123540) -- Femdom Waifu: Findom Mode
addappid(1168620) -- Femdom Waifu: Latex Suits Pack
addappid(1294530) -- Femdom Waifu: Shorts and Tops Pack
addappid(1599260) -- Femdom Waifu: Bikini Summer Pack
addappid(2714750) -- Femdom Waifu: Boot Fetish Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(1024801, 1, "412168f03b64cba4d01c9d1dd4e9a1fdd4142a0a491e2e62c2a6eaf542e378bd") -- (windows)

