-- Generated with Luie @ https://lua.tools/
-- 1024800 - Femdom Waifu
-- Generated 2026-08-10 18:57:30 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(1024800)

-- Main Depots
addappid(1024801, 1, "412168f03b64cba4d01c9d1dd4e9a1fdd4142a0a491e2e62c2a6eaf542e378bd") -- (windows)
setManifestid(1024801, "3014388197774881699", 251983984)

-- DLC's (no depot keys required)
addappid(1024810) -- Femdom Waifu: Censored Mode
addappid(1055910) -- Femdom Waifu: Foot Fetish Pack
addappid(1083900) -- Femdom Waifu: Netorare Mode
addappid(1106820) -- Femdom Waifu: Swimsuit Pack
addappid(1123540) -- Femdom Waifu: Findom Mode
addappid(1168620) -- Femdom Waifu: Latex Suits Pack
addappid(1294530) -- Femdom Waifu: Shorts and Tops Pack
addappid(1599260) -- Femdom Waifu: Bikini Summer Pack
addappid(2714750) -- Femdom Waifu: Boot Fetish Pack
