-- Lua provided by RyzenAPI
-- Game: Femdom Waifu

-- MAIN APPLICATION
addappid(1024800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1024801, 1, "412168f03b64cba4d01c9d1dd4e9a1fdd4142a0a491e2e62c2a6eaf542e378bd")
