-- Lua provided by SkyAPI 
-- Game: Contrast Tunnel
addappid(1566370)
addappid(1566371, 1, "2ee72e387ae7e2c4e43b20852f3b24a06f32a2994b840745c7a3b9a978db0baf")
