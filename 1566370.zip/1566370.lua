-- Lua provided by RyzenAPI
-- Game: Contrast Tunnel

-- MAIN APPLICATION
addappid(1566370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1566371, 1, "2ee72e387ae7e2c4e43b20852f3b24a06f32a2994b840745c7a3b9a978db0baf")

