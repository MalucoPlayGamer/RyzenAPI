-- Lua provided by RyzenAPI 
-- Game: The Amazing American Circus
addappid(1433860)
addappid(1433861, 1, "faa04dfc82afe5037e327c340894e33f16e65d36889bd811653c2c58ab8d3e23")
addappid(1641740, 0, "846858aa28ce19b1a188209141060b30623e228d6b0fabb7429a554dc84f2e0e")
addappid(1740030)
