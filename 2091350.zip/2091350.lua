-- Lua provided by RyzenAPI
-- Game: Twistingo Collector's Edition

-- MAIN APPLICATION
addappid(2091350)
-- Game: addappid(2091350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2091351, 1, "a73778a7757c54ad1b5d461cfa666e0aceda3468c462982514fc669d9a3bb260")
