-- Lua provided by RyzenAPI
-- Game: PlanetSide 2

-- MAIN APPLICATION
addappid(218230)

-- MAIN APP DEPOTS / PACKAGES
addappid(218231, 1, "b8c7e8641a5c75093fd1e9f9b4a46b05d730380f288d4938e46236a818aa7e01")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(218240)
addappid(218241)
addappid(218242)
addappid(310580)
addappid(334440)
addappid(334441)
addappid(334442)
addappid(334450)
addappid(429730)
