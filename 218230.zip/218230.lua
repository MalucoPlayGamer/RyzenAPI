-- Lua provided by RyzenAPI
-- Game: Game: PlanetSide 2

-- MAIN APPLICATION
addappid(218230)
-- Game: addappid(218230)

-- MAIN APP DEPOTS / PACKAGES
addappid(218231, 1, "b8c7e8641a5c75093fd1e9f9b4a46b05d730380f288d4938e46236a818aa7e01")
