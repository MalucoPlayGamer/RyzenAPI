-- Lua provided by RyzenAPI
-- Game: Fruit for the Village

-- MAIN APPLICATION
addappid(528930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(528931, 1, "a8943da84db0516d72da720410c81c86e95e3956f66fb801865072d7d6f69395")

