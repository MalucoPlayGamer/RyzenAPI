-- Lua provided by RyzenAPI
-- Game: Fruit for the Village

-- MAIN APPLICATION
addappid(528930)

-- MAIN APP DEPOTS / PACKAGES
addappid(528931, 1, "a8943da84db0516d72da720410c81c86e95e3956f66fb801865072d7d6f69395")

