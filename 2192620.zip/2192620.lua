-- Lua provided by RyzenAPI 
-- Game: ghostpia Season One
addappid(2192620)
addappid(2192621, 1, "8f9989f1eb84753fe67e98a24a7ef3066473ea85b22f63a17ed1746a8456fae8")
