-- Lua provided by RyzenAPI
-- Game: 2931120

-- MAIN APPLICATION
addappid(2931120)
-- Game: addappid(2931120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2931121, 1, "7ae544eb790a7be4f630957d9aff0c8e40ac54a7caeb53be8f0f98f18c4bdc35")
