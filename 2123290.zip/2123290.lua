-- Lua provided by RyzenAPI
-- Game: Game: Wheel Of Naughtiness

-- MAIN APPLICATION
addappid(2123290)
-- Game: addappid(2123290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2123291, 1, "45a0bf55f3b4275bb0b2ec28b2d89e65d75c14d35e2dbb08ede6b789f4d7b606")
