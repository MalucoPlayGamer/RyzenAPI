-- Lua provided by RyzenAPI
-- Game: 3774470

-- MAIN APPLICATION
addappid(3774470)
-- Game: addappid(3774470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3774470,0,"04e032026bf749c8c125a33349ba853dbe99cfc45dd4e6bd7403035c7d559c4d")
