-- Lua provided by RyzenAPI
-- Game: Redd's Runaway

-- MAIN APPLICATION
addappid(1411770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411771, 1, "d770a630bcb6ef8597ec44dbc632a0bcbc61a25615a9416a812e314b1554028d")
