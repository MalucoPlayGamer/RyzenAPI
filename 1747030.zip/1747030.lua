-- Lua provided by RyzenAPI
-- Game: The Trials 1

-- MAIN APPLICATION
addappid(1747030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747031, 1, "65e27e007bc435cbf173453db8e21dcfc9140716d360523106997d1e12dccdae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
