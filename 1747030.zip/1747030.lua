-- Lua provided by RyzenAPI
-- Game: addappid(1747030)

-- MAIN APPLICATION
addappid(1747030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747031, 1, "65e27e007bc435cbf173453db8e21dcfc9140716d360523106997d1e12dccdae")
