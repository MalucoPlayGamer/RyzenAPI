-- Lua provided by RyzenAPI
-- Game: AppID 989340

-- MAIN APPLICATION
addappid(989340)

-- MAIN APP DEPOTS / PACKAGES
addappid(989341, 1, "f0b8fb6b27206054a3620e136f2f84f5def662af4ee6f3fc02c2e401a0dba529")
