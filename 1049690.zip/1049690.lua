-- Lua provided by RyzenAPI
-- Game: Catch the Head

-- MAIN APPLICATION
addappid(1049690)
addappid(1101150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1049691, 1, "0baf4ff891f17f17c59ae8eae8d3bace86d32ef10e90bfef0b355ab92a5004da")
addappid(1049692, 1, "38d91c2147f28fa9669e053b0015917cb1fafceea096ac61e8e43c5a6147d7b2")
