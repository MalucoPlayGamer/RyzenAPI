-- Lua provided by SkyAPI 
-- Game: AppID 1049690
addappid(1049690)
addappid(1049691, 1, "0baf4ff891f17f17c59ae8eae8d3bace86d32ef10e90bfef0b355ab92a5004da")
addappid(1049692, 1, "38d91c2147f28fa9669e053b0015917cb1fafceea096ac61e8e43c5a6147d7b2")
