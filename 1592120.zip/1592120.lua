-- Lua provided by RyzenAPI
-- Game: Game: Paladin Dream

-- MAIN APPLICATION
addappid(1592120)
-- Game: addappid(1592120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592121, 1, "63c578941380f3a1dd36464c73cdf28136d58b3142ba4ed9fe8921dd0f2674c7")
