-- Lua provided by RyzenAPI
-- Game: Game: DragonRoad

-- MAIN APPLICATION
addappid(3380340)
-- Game: addappid(3380340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3380341, 1, "814e2b2b09bf8ded67139879fabda1ccb65d2fd6b7bfa576fa62ddba00839873")
