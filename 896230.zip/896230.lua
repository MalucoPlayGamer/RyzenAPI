-- Lua provided by SkyAPI 
-- Game: Picross Bonbon - Nonogram
addappid(896230)
addappid(896231, 1, "b4ea7778a67869ce502c749bb1ac20e0a9ea6b5aa0fe505e6d0ebade20c845d8")
addappid(896232, 1, "44cf3aa72c8f36246001a4b3898eda537d338ac8ae4093475f4512e0e54a728c")
addappid(896233, 1, "9fbea474a5b8163d9c2261aac91c32aee3182063007bed22b0858e32d4bce1d6")
addappid(896234, 1, "69e0ee60b024cfb3f131cde2a330ac6aef5a21f5edcb57aa33d6cfbf5b7ca922")
