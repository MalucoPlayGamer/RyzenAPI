-- Lua provided by RyzenAPI
-- Game: Game: AppID 2375550

-- MAIN APPLICATION
addappid(2375550)
-- Game: addappid(2375550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375551, 1, "98c80a1e378de4c0c534551cba0c53e74326cd8ff2f9360ad6fa4f5588a4729e")
