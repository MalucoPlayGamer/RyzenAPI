-- Lua provided by RyzenAPI
-- Game: AppID 2375550

-- MAIN APPLICATION
addappid(2375550)
addappid(2438750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2375551, 1, "98c80a1e378de4c0c534551cba0c53e74326cd8ff2f9360ad6fa4f5588a4729e")

