-- Lua provided by RyzenAPI
-- Game: Hello Guest: Hello Neighbor 2 pre-alpha

-- MAIN APPLICATION
addappid(1504150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1504151, 1, "2fd80459a161718ecbd8845566de887961aebb1fe625ff3296e4992b4e2102bf")

