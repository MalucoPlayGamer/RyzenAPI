-- Lua provided by RyzenAPI
-- Game: addappid(1504150)

-- MAIN APPLICATION
addappid(1504150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1504151, 1, "2fd80459a161718ecbd8845566de887961aebb1fe625ff3296e4992b4e2102bf")
