-- Lua provided by SkyAPI 
-- Game: Hello Guest: Hello Neighbor 2 pre-alpha
addappid(1504150)
addappid(1504151, 1, "2fd80459a161718ecbd8845566de887961aebb1fe625ff3296e4992b4e2102bf")
