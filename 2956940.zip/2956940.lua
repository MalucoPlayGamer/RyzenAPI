-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2956940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2956940,0,"1ffea472eaab391be8cdd94937bc67056d5c498406bcbf562196a2893f3af5af")

