-- Lua provided by RyzenAPI
-- Game: 2109270

-- MAIN APPLICATION
addappid(2109270)
-- Game: addappid(2109270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2109271, 1, "159b87c9592c3fcd889e37b4bb9ad67aa87361e8e6f1dc80f56e7013ce994bc0")
addappid(3114870, 0, "784cbcfb5e2c251e30f6ec0a195863de46a66bae7a1ffd86766d8dff261adeca")
