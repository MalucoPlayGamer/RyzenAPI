-- Lua provided by RyzenAPI
-- Game: addappid(1588962)

-- MAIN APPLICATION
addappid(1588962)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588962,0,"f0e2fe89aa6d219be16787550e8dec6b36b888f8277a63285d2e0ba5a68057ec")
