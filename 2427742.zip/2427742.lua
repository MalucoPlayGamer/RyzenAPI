-- Lua provided by RyzenAPI
-- Game: Cities: Skylines II - Creator Pack: Urban Promenades

-- MAIN APPLICATION
addappid(2427742)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427742,0,"10f591eaa4714450e076677b7e7769008213ced4a34ee7d8680ab9e56ef4fe49")
