-- Lua provided by RyzenAPI
-- Game: Quiet Sleep

-- MAIN APPLICATION
addappid(1061240)
-- Game: addappid(1061240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061241, 1, "c024fce05f9e06b7befaec2264ea56d2e06c7dab0063d045ef3bcf8ce2cfb91e")
