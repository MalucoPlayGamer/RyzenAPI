-- Lua provided by RyzenAPI
-- Game: Quiet Sleep

-- MAIN APPLICATION
addappid(1061240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061241, 1, "c024fce05f9e06b7befaec2264ea56d2e06c7dab0063d045ef3bcf8ce2cfb91e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
