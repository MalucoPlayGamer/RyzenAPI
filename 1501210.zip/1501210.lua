-- Lua provided by RyzenAPI
-- Game: ARENIX

-- MAIN APPLICATION
addappid(1501210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501211, 1, "6e9fc843acc225985a9b6da4cd3d02da841d6efdc28d2be87bcf0c288ce37777")
