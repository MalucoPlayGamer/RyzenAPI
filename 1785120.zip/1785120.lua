-- Lua provided by RyzenAPI
-- Game: addappid(1785120)

-- MAIN APPLICATION
addappid(1785120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1785121, 1, "43f933ce51cff727c1543cb3a87919d6d0b42dcbc392e21151dd1faa39e962c6")
