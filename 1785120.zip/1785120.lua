-- Lua provided by RyzenAPI 
-- Game: Forsake: Urban horror
addappid(1785120)
addappid(1785121, 1, "43f933ce51cff727c1543cb3a87919d6d0b42dcbc392e21151dd1faa39e962c6")
