-- Lua provided by RyzenAPI
-- Game: Gunlocked 2

-- MAIN APPLICATION
addappid(3492830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3492831,0,"6ffb3fa62cbbf5658342ecafb1c3f35b68ad6b76c57dd9cf4ec2f7c027682250")

