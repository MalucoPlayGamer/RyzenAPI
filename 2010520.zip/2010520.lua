-- Lua provided by RyzenAPI
-- Game: Martial Story

-- MAIN APPLICATION
addappid(2010520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010521, 1, "20fd045f5e0db542d4ba151a50673ef4b8a83a4ad7097cca3f3068f81d62ba0a")
