-- Lua provided by RyzenAPI
-- Game: AppID 654690

-- MAIN APPLICATION
addappid(654690)

-- MAIN APP DEPOTS / PACKAGES
addappid(654691, 1, "fbe57dd0e123eb3138b7af7294c52c11fcbff36aba8552db9ccd8d345da54fdc")

