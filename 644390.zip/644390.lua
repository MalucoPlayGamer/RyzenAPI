-- Lua provided by RyzenAPI
-- Game: AppID 644390

-- MAIN APPLICATION
addappid(644390)
-- Game: addappid(644390)

-- MAIN APP DEPOTS / PACKAGES
addappid(644391, 1, "8e4fadb80d1b0503ea2721e349689079be6f65af25c5ae462e9e8e4c9b7c8479")
