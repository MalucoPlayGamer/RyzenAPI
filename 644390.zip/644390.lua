-- Lua provided by RyzenAPI
-- Game: D&D Lords of Waterdeep

-- MAIN APPLICATION
addappid(644390)
addappid(645670)
addappid(645671)

-- MAIN APP DEPOTS / PACKAGES
addappid(644391, 1, "8e4fadb80d1b0503ea2721e349689079be6f65af25c5ae462e9e8e4c9b7c8479")

