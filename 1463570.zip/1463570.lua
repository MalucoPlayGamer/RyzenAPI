-- Lua provided by RyzenAPI
-- Game: Eternal Liiivie EP2- Hiding in the dark

-- MAIN APPLICATION
addappid(1463570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463571, 1, "5f5253550237b022b4b56b2d65a6fbf6daf2eba5affa1f1db15c8b8b5e212ea1")
addappid(1463572, 1, "609742bcea2473e50078e38863093f7f59cf6532486390690d912f11cfed4895")
