-- Lua provided by RyzenAPI
-- Game: Doupleri

-- MAIN APPLICATION
addappid(2800760)
-- Game: addappid(2800760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800761, 1, "dbf8f481ccd45ec3663305df1f2c6660cdc7cc9d6dd6ceb90979b8f4e6ce2df7")
