-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1335550)
-- Game: addappid(1335550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1335552,0,"c2353d620da68336bfeb706aae38925a717a1c8bc9bddb62b2fe20c354979ecb")
