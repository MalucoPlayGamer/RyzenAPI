-- Lua provided by RyzenAPI
-- Game: StarDrive

-- MAIN APPLICATION
addappid(220660)
addappid(228983)
addappid(229002)
addappid(229011)
addappid(229012)
-- Game: addappid(220660)

-- MAIN APP DEPOTS / PACKAGES
addappid(220661, 1, "73fc18e13bf3f4ff8030fd28db03892d20fba2cbd08b680f048165afe1257c76")
addappid(220662, 1, "9eb4d5bada11b431947d01f805f7f0acd61818267654ea25f02fe1eb820c5f20")
addappid(229013, 0, "75aeb4e30ec2d6234e1ae43959d4859fcc3d68c8559f11456b5012d7a9c6fa72")
