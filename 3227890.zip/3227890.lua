-- Lua provided by RyzenAPI
-- Game: Game: AppID 3227890

-- MAIN APPLICATION
addappid(3227890)
-- Game: addappid(3227890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227891, 1, "dcf69bee26bb59d0e985fcb27623838c69c1b1a2fd16cb0ae3f4edc4682a6574")
