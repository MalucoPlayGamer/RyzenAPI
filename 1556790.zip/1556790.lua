-- Lua provided by RyzenAPI
-- Game: Isonzo

-- MAIN APPLICATION
addappid(1556790)
addappid(1815510)
addappid(1815511)
addappid(1815512)
addappid(1815513)
addappid(1815514)
addappid(2197970)
addappid(2214670)
addappid(2214671)
addappid(2542150)
addappid(2542160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556791, 1, "7b65e287a471040c1260b7302565bf3674396945c421ef7cbc83772029c0adad")
addappid(1556793, 1, "02b93d00c4e6e073fd797994630d5143372ac19aa01fd28f0246a13583b7e6f1")
addappid(1556794, 1, "02aeb4d814280e19218e5eb232cc29aea2bb2ab1cd569f12c8ab77c66d2023fa")
addappid(2128180, 0, "81e49e6ffde01f30bed96aafefb35befa111b41a9e84c846f39b86b176105d24")
