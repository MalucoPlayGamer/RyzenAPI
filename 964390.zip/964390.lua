-- Lua provided by RyzenAPI
-- Game: Australian Road Trains

-- MAIN APPLICATION
addappid(964390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(964391, 1, "e9963fa262a08e2007425c105ca96b36a5213e6e7c8b8e87ed03d4fb7a417910")

