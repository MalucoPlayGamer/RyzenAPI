-- Lua provided by RyzenAPI
-- Game: Australian Road Trains

-- MAIN APPLICATION
addappid(964390)

-- MAIN APP DEPOTS / PACKAGES
addappid(964391, 1, "e9963fa262a08e2007425c105ca96b36a5213e6e7c8b8e87ed03d4fb7a417910")

