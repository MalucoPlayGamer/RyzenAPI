-- Lua provided by SkyAPI 
-- Game: Australian Road Trains
addappid(964390)
addappid(964391, 1, "e9963fa262a08e2007425c105ca96b36a5213e6e7c8b8e87ed03d4fb7a417910")
