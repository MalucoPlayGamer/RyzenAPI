-- Lua provided by RyzenAPI
-- Game: Tin Hearts

-- MAIN APPLICATION
addappid(1831700)
-- Game: addappid(1831700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1831701, 1, "16607379a87c310cda33c2eab91b481cd1d122152ab0340a8ce953dfd786d883")
addappid(1831702, 1, "e09555f79981d577083e35edb93a90f2445bae3bcab27b579a824d9c824b0860")
