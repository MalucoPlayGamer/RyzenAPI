-- Lua provided by RyzenAPI
-- Game: The Searchers of Legends : Origin

-- MAIN APPLICATION
addappid(1107490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1107491, 1, "38b8a0d7670508282475262769ff2a33a5ceda3cb5136d6c6fb61a3ab61c6beb")
addappid(1123880, 0, "de11a44e5670d5050f077d70a8c252c198d8065626691d469c1567f87f571e83")
