-- Lua provided by RyzenAPI
-- Game: Timber Story

-- MAIN APPLICATION
addappid(1828790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828791, 1, "2a0b49c5739baa4305322f8b7c9670adf6396e470ff707d59f78c26ccdd2b87a")
