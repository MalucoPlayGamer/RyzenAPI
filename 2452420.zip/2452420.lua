-- Lua provided by RyzenAPI
-- Game: Line's Guarder

-- MAIN APPLICATION
addappid(2452420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452421, 1, "6c82c6ed0a7c8ecd79f5e4e4a1c0d6d69d34ede7eaca4da23a2d1aac5dbac419")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
