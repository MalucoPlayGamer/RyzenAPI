-- Lua provided by RyzenAPI 
-- Game: Grab the Beat
addappid(1260480)
addappid(1260481, 1, "d25699b1e3ed2f0756025f4469a3bcce34dde5fbf6560ca915b02f3ce4d442e3")
