-- Lua provided by RyzenAPI
-- Game: BAFF Halloween

-- MAIN APPLICATION
addappid(2619030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2619031, 1, "cb5439f54eda74ff8c965e712143622f00ca96ec462d3302b61e2a22d3a9f45a")
