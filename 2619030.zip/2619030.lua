-- Lua provided by SkyAPI 
-- Game: BAFF Halloween
addappid(2619030)
addappid(2619031, 1, "cb5439f54eda74ff8c965e712143622f00ca96ec462d3302b61e2a22d3a9f45a")
