-- Lua provided by SkyAPI 
-- Game: Yummy Girls 2
addappid(2216170)
addappid(2216171, 1, "58221846f2d45a7571ae94c945a75282217f54ac97f2907d1f58446b70730e4e")
