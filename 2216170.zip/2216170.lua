-- Lua provided by RyzenAPI
-- Game: Game: Yummy Girls 2

-- MAIN APPLICATION
addappid(2216170)
-- Game: addappid(2216170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216171, 1, "58221846f2d45a7571ae94c945a75282217f54ac97f2907d1f58446b70730e4e")
