-- Lua provided by RyzenAPI
-- Game: addappid(2804160)

-- MAIN APPLICATION
addappid(2804160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804161, 1, "caddb04adf771ebe45cf99138fb9f39fbe18b9547efe6b6d0f080a9a6d4b9000")
