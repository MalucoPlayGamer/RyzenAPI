-- Lua provided by RyzenAPI
-- Game: The Witch's Maze

-- MAIN APPLICATION
addappid(1623640)
-- Game: addappid(1623640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1623641, 1, "aae5677bd5ecd426f6c209249912f21de3cf2bdbf182b7d5f9b4089f57c43180")
