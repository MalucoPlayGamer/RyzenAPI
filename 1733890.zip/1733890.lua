-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Battle Sister

-- MAIN APPLICATION
addappid(1733890)
-- Game: addappid(1733890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733891, 1, "7337fd0db646d3bec95a6b7b7f4354c502ffb68295b0696bd434ea6f3a1583b9")
