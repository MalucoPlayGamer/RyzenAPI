-- Lua provided by SkyAPI 
-- Game: War Solution - Casual Math Game
addappid(1083810)
addappid(1083811, 1, "dd8b8c037f0669331369a6a0bb6ffaa26b4bb48a97acab19d58358dd08d3503a")
