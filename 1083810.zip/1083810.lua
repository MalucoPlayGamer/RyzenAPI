-- Lua provided by RyzenAPI
-- Game: War Solution - Casual Math Game

-- MAIN APPLICATION
addappid(1083810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1083811, 1, "dd8b8c037f0669331369a6a0bb6ffaa26b4bb48a97acab19d58358dd08d3503a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
