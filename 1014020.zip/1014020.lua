-- Lua provided by RyzenAPI
-- Game: Successor of the Moon

-- MAIN APPLICATION
addappid(1014020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1014021, 1, "81de4a4b3202a197a2f9cc904d244cac958e86306efed167b5dfc6a4bf37b1c8")
