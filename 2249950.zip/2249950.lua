-- Lua provided by SkyAPI 
-- Game: Nith Realms
addappid(2249950)
addappid(2249951, 1, "f8c8f663e6112ff63635bf9a12d2dc5dd5082493fde4963a250e296722e05751")
