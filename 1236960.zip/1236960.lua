-- Lua provided by RyzenAPI
-- Game: 1236960

-- MAIN APPLICATION
addappid(1236960)
-- Game: addappid(1236960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1236961, 1, "dba2ebcb603286cf434073ef560df5fe456e3795f56be0db80945f1490a2d389")
