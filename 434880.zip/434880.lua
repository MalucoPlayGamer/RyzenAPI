-- Lua provided by RyzenAPI
-- Game: Hieroglyphika

-- MAIN APPLICATION
addappid(434880)

-- MAIN APP DEPOTS / PACKAGES
addappid(434881, 1, "855fa387cb98cc83ce35667bfafa1948119744d6aaf895e1f209a5daa66e1e2c")
addappid(571250, 0, "7e37b8075ac7c7ba272f24b2fb7c8245dc70af8d9228d1ecb62440ee2a32fdbe")

