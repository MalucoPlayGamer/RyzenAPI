-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: 29 Palms/Captain7 - EDDN - Nuernberg XP

-- MAIN APPLICATION
addappid(1281570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281570,0,"cc29afbfb3356771ef81afa0548acfaeaf7ffeb4b3aaec76b556c850c69d6604")
