-- Lua provided by RyzenAPI
-- Game: AppID 1077290

-- MAIN APPLICATION
addappid(1077290)
-- Game: addappid(1077290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1077291, 1, "b30b8d2af0f4f0cc14f6e600c53e8c6c53a84866d558a047ebcaec9ab70facf4")
