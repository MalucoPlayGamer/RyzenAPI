-- Lua provided by RyzenAPI 
-- Game: Way of Heroes
addappid(1309170)
addappid(1309171, 1, "54c8896199ba624a05cd2627d5b8112303393b7eeb159c17091cfcdaacf3d02a")
