-- Lua provided by RyzenAPI
-- Game: Way of Heroes

-- MAIN APPLICATION
addappid(1309170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309171, 1, "54c8896199ba624a05cd2627d5b8112303393b7eeb159c17091cfcdaacf3d02a")

