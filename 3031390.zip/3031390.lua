-- Lua provided by RyzenAPI
-- Game: 3031390

-- MAIN APPLICATION
addappid(3031390)
-- Game: addappid(3031390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3031391, 1, "7027b702d58f9e82070c31a40052be32a04e1813a307cfe44ed7d0b84c342fd2")
