-- Lua provided by RyzenAPI
-- Game: Treasure Tiger

-- MAIN APPLICATION
addappid(3805710)
-- Game: addappid(3805710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3805711, 1, "471f6a8a20c13034b2125826a56049a843eb6072d310f12d95c95f947c8f65dc")
