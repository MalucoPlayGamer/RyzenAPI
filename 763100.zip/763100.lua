-- Lua provided by RyzenAPI
-- Game: Lumberjack Simulator

-- MAIN APPLICATION
addappid(763100)
addappid(2131580)
addappid(2131581)
addappid(2131582)
addappid(2131584)

-- MAIN APP DEPOTS / PACKAGES
addappid(763101,0,"598916dcffae1831be3fdb48e89ea21b8ff9ead02d9d7b6e8643505f9630f9a5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
