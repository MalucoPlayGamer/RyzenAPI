-- Lua provided by SkyAPI 
-- Game: FINAL FANTASY® XI: Ultimate Collection Seekers Edition
addappid(230330)
addappid(230331, 1, "7aa90e305c5d29221be018c8f7c27dd1cbad3771e26086552479c93e537f8fe4")
