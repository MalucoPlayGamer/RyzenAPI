-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY® XI: Ultimate Collection Seekers Edition

-- MAIN APPLICATION
addappid(230330)
addappid(237210)
addappid(237230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(230331, 1, "7aa90e305c5d29221be018c8f7c27dd1cbad3771e26086552479c93e537f8fe4")

