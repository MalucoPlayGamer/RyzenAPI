-- Lua provided by RyzenAPI
-- Game: Black blood

-- MAIN APPLICATION
addappid(1262080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1262081, 1, "311cdd00c34fa77b4aa579acc06c85825ccf7a2c636edc21b89abc1274459b5b")

