-- Lua provided by RyzenAPI
-- Game: Ballance

-- MAIN APPLICATION
addappid(2000770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000771, 1, "cd3e0cb07ab504552cc2159a81353daff01a6d4448632d91ae3b38c9e8a5e9cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
