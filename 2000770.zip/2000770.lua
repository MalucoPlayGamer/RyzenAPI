-- Lua provided by RyzenAPI
-- Game: Ballance

-- MAIN APPLICATION
addappid(2000770)
-- Game: addappid(2000770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000771, 1, "cd3e0cb07ab504552cc2159a81353daff01a6d4448632d91ae3b38c9e8a5e9cb")
