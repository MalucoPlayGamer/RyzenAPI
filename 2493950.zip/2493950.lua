-- Lua provided by RyzenAPI
-- Game: Game: Save The World

-- MAIN APPLICATION
addappid(2493950)
-- Game: addappid(2493950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2493951, 1, "823028b5cc8dabb48857b4a0cd1d8bdd673fcaef149d0e95cbb12934b9bbcafd")
