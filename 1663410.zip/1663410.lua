-- Lua provided by RyzenAPI
-- Game: 1663410

-- MAIN APPLICATION
addappid(1663410)
-- Game: addappid(1663410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663411, 1, "2b623623ecda3c9989a9e3be40c1a5a421866c1631ef346126abaf0606ad424a")
