-- Lua provided by RyzenAPI
-- Game: Game: DEADPOINT

-- MAIN APPLICATION
addappid(2524920)
-- Game: addappid(2524920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2524921, 1, "8dec72278f5537f2f278de39ff317bcdec511919e8621afa8b9db146bee4285c")
