-- Lua provided by RyzenAPI
-- Game: Dark Fracture Demo

-- MAIN APPLICATION
addappid(1269460)
-- Game: addappid(1269460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269461, 1, "0cb1158e8ce289b371ed18f34a5967f3840a9187b410563fc8f76f4020155097")
