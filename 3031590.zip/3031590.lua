-- Lua provided by RyzenAPI
-- Game: 13F

-- MAIN APPLICATION
addappid(3031590)
-- Game: addappid(3031590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3031591, 1, "6a1c0acb6a48a705e14429a4a272d9f7b615272ac4e1e9f878f3734e5e4ffe4f")
