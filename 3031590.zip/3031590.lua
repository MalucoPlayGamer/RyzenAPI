-- Lua provided by RyzenAPI 
-- Game: 13F
addappid(3031590)
addappid(3031591, 1, "6a1c0acb6a48a705e14429a4a272d9f7b615272ac4e1e9f878f3734e5e4ffe4f")
