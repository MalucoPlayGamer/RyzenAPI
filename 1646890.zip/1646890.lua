-- Lua provided by RyzenAPI
-- Game: AppID 1646890

-- MAIN APPLICATION
addappid(1646890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646891, 1, "6653fcaf7e15c5e4568fcf1f727b6d1a3c50a6b5ee5d0c10a1e22df99af0bd31")
