-- Lua provided by RyzenAPI 
-- Game: VOENKOMAT
addappid(1470430)
addappid(1470431, 1, "12cc93466986ef2191038afda88367d02777c226b9c8964ce8b5646cb8a29031")
