-- Lua provided by RyzenAPI
-- Game: Syder Arcade

-- MAIN APPLICATION
addappid(252310)

-- MAIN APP DEPOTS / PACKAGES
addappid(252311, 1, "3fe631aceb14a01252e869985164cf5d81ccb84f4e3db210648154c5bf1dc58c")
addappid(252312, 1, "144d9505bf9f79a0ebc6fcd09664e19b273959ee7f794b778d99b40931fd4c65")
addappid(252313, 1, "6fe8b68bf548e43e56b6021b5b546a635070d39de4cd9bc3b3bd4c80b5afc24f")

