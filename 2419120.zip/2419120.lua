-- Lua provided by RyzenAPI
-- Game: 2419120

-- MAIN APPLICATION
addappid(2419120)
-- Game: addappid(2419120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2419121, 1, "ce3c0518c029877246998f1c1ca6a786f47b0f5d1a8455d3255ea69edddba971")
