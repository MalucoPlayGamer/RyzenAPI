-- Lua provided by RyzenAPI
-- Game: The Pasture

-- MAIN APPLICATION
addappid(567680)

-- MAIN APP DEPOTS / PACKAGES
addappid(567681, 1, "fb014dc2574be359450cb3d2dacacbc6eff9f8b3c6cad4463287aad23bb23b8b")
addappid(567682, 1, "e72d8e5565440655410c1faa3cea7ee4ab5f48ebe1e615e5170a8a893e917237")
addappid(567683, 1, "d86739225a36d0e1b9b45e0534633bc32ca75e6210b48e49b286f25b84c79e64")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
