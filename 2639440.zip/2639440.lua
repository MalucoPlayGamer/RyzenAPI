-- Lua provided by SkyAPI 
-- Game: SGS Overlord
addappid(2639440)
addappid(2639441, 1, "1f51b76c1de456368034c798a34135faff0b11c5a2e425deee595449e06c8839")
addappid(2639443, 1, "38e62168eb11401b5b9736b435926ecf3dcaa529f2ab35c834b2fee56343d409")
