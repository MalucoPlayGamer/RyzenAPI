-- Lua provided by RyzenAPI
-- Game: SGS Overlord

-- MAIN APPLICATION
addappid(2639440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2639441, 1, "1f51b76c1de456368034c798a34135faff0b11c5a2e425deee595449e06c8839")
addappid(2639443, 1, "38e62168eb11401b5b9736b435926ecf3dcaa529f2ab35c834b2fee56343d409")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
