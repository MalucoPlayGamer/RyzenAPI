-- Lua provided by RyzenAPI
-- Game: 486340

-- MAIN APPLICATION
addappid(486340)
addappid(491460)
-- Game: addappid(486340)

-- MAIN APP DEPOTS / PACKAGES
addappid(486341, 1, "19c364dad79e83d75f30be4e56837777b0c9655adcc68ae52813446edbddb99b")
