-- Lua provided by RyzenAPI
-- Game: AppID 1199650

-- MAIN APPLICATION
addappid(1199650)
-- Game: addappid(1199650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1199651, 1, "3789feacecdc5a81a65ba62de1338cca682f79c00265d75eae7e3c25563bd989")
