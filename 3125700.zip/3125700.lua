-- Lua provided by RyzenAPI
-- Game: Planternauts

-- MAIN APPLICATION
addappid(3125700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3125701, 1, "a9862c41289d6fe1a5650a94a74fd4680e06267978c248b5953c95c42e0d55fa")

