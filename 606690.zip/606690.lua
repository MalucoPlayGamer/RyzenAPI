-- Lua provided by RyzenAPI
-- Game: Ecchi Sketch: Draw Cute Girls Every Day!

-- MAIN APPLICATION
addappid(606690)

-- MAIN APP DEPOTS / PACKAGES
addappid(606691, 1, "5127ae50575e752f89b3989b0a96decbb04618090419c00411f8f68132826aff")
