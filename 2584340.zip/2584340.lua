-- Lua provided by RyzenAPI
-- Game: Gabenwood 2: 99 Hidden Euros

-- MAIN APPLICATION
addappid(2584340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2584341, 1, "0f117ec0c6c682fa001bb7179f576022a70610fb74ce7ce9c78290d8a719af9f")

