-- Lua provided by RyzenAPI
-- Game: 2584340

-- MAIN APPLICATION
addappid(2584340)
-- Game: addappid(2584340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2584341, 1, "0f117ec0c6c682fa001bb7179f576022a70610fb74ce7ce9c78290d8a719af9f")
