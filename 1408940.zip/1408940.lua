-- Lua provided by RyzenAPI
-- Game: addappid(1408940)

-- MAIN APPLICATION
addappid(1408940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408941, 1, "f40b30617b924f9c4e77bb1b1f719ac4dabe39b6a381fb4671fee104e755170b")
