-- Lua provided by RyzenAPI
-- Game: 2277330

-- MAIN APPLICATION
addappid(2277330)
-- Game: addappid(2277330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2277331, 1, "6c820a89d43e4ab804af0991b063f1c54ee68f5dc0c1d5438215a0f6eceebe35")
