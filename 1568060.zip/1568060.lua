-- Lua provided by RyzenAPI
-- Game: addappid(1568060)

-- MAIN APPLICATION
addappid(1568060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568061, 1, "c06b1f7c038a18bf327552073cf113900af03621af7c71ce5bcd47cc5e708b33")
