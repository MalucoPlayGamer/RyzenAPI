-- Lua provided by RyzenAPI
-- Game: Twilight Wars

-- MAIN APPLICATION
addappid(1396540)
-- Game: addappid(1396540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1396541, 1, "61d0036670d4b6b4918d40bde24650ff5c849f9d6630fceebb3cdd765ce2457e")
