-- Lua provided by RyzenAPI
-- Game: Three kingdoms story: Conussia

-- MAIN APPLICATION
addappid(1285560)
addappid(1998090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285561, 1, "8e4c8eabf3fac162e0818c92991b9608c3047241d6f4b2b9a4240a4ccc3f7415")
