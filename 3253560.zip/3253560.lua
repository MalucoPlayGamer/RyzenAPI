-- Lua provided by RyzenAPI
-- Game: Shining Princess Lapisphilia

-- MAIN APPLICATION
addappid(3253560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3253563,0,"8ace83849b10752affe8d0b15622b872dfd2cbaa4b1993c2ac0a91edd3c60988")
