-- Lua provided by RyzenAPI
-- Game: Break Stuff With Coins

-- MAIN APPLICATION
addappid(643260)

-- MAIN APP DEPOTS / PACKAGES
addappid(643261,0,"1459e2e9b01ec2bd6a38a86e90b273c7b4f480fda00858e6ba990c03f07e2bda")

