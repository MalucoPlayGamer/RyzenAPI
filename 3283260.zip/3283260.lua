-- Lua provided by RyzenAPI
-- Game: Game: AppID 3283260

-- MAIN APPLICATION
addappid(3283260)
-- Game: addappid(3283260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3283261, 1, "c32c38f7115c77ebada7db8c73d1a9b03795f02da7b75624a70cbb176d2a1d9e")
