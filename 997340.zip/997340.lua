-- Lua provided by SkyAPI 
-- Game: AppID 997340
addappid(997340)
addappid(997341, 1, "85bead7bace17ac7655789e3a026c05b3684190dd74b84f0723e6faeb1276466")
