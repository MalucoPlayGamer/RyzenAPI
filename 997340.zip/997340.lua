-- Lua provided by RyzenAPI
-- Game: Star Destroyer

-- MAIN APPLICATION
addappid(997340)

-- MAIN APP DEPOTS / PACKAGES
addappid(997341, 1, "85bead7bace17ac7655789e3a026c05b3684190dd74b84f0723e6faeb1276466")
