-- Lua provided by RyzenAPI 
-- Game: Reposition Defense
addappid(3636320)
addappid(3636321, 1, "a9a7ff51fb3a051b713d84fec09daaaada6cb31338a8c9947115c06345ac07c9")
