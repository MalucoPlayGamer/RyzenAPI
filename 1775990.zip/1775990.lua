-- Lua provided by RyzenAPI
-- Game: County Hospital 2

-- MAIN APPLICATION
addappid(1775990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1775991, 1, "cd04f6e97785af22ffd93dc9ca2769a9477c04bc56185dae57e303012a970e0b")

