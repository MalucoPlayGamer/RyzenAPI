-- Lua provided by RyzenAPI
-- Game: County Hospital 2

-- MAIN APPLICATION
addappid(1775990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1775991, 1, "cd04f6e97785af22ffd93dc9ca2769a9477c04bc56185dae57e303012a970e0b")

