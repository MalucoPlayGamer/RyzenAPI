-- Lua provided by SkyAPI 
-- Game: Airship: Kingdoms Adrift
addappid(1597310)
addappid(1597311, 1, "0cb22a67e8bdac7870eafa27da25abfc2915597ed7f0a56eb9c0ac66a88ae52a")
