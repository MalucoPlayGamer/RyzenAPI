-- Lua provided by RyzenAPI
-- Game: 1597310

-- MAIN APPLICATION
addappid(1597310)
-- Game: addappid(1597310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597311, 1, "0cb22a67e8bdac7870eafa27da25abfc2915597ed7f0a56eb9c0ac66a88ae52a")
