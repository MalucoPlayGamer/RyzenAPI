-- Lua provided by RyzenAPI
-- Game: Winter Memories

-- MAIN APPLICATION
addappid(2495450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2495451, 1, "16af18f5e3fd7f5ad735d7b0778a3034bd74e40f1db8c0512a63361553a217f8")
addappid(2495452, 1, "8cff64f0eaed597ed5e65daf1192bddb7b7f9a921c2175100e5176d34066e8b9")
addappid(2495453, 1, "a9a51a0ddd91f9d9b3fa601ee5fff51a20eb1862d5cd45033dc40878bc305b0b")
