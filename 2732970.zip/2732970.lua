-- Lua provided by RyzenAPI
-- Game: addappid(2732970)

-- MAIN APPLICATION
addappid(2732970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2732971, 1, "116de22e6cf3f2b308c3104dd1eac702d49a4ff5746985557e1726aca7dd583d")
