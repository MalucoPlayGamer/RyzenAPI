-- Lua provided by RyzenAPI
-- Game: L'Île Archéo

-- MAIN APPLICATION
addappid(2732970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2732971, 1, "116de22e6cf3f2b308c3104dd1eac702d49a4ff5746985557e1726aca7dd583d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
