-- Lua provided by RyzenAPI
-- Game: The Order of the Snake Scale

-- MAIN APPLICATION
addappid(2451470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2451471, 1, "dfe988ce9ceeeaeb2410c0778cf27fa9214d1ddfc3e36b214eb5fa5a48ca703f")

