-- Lua provided by SkyAPI 
-- Game: The Order of the Snake Scale
addappid(2451470)
addappid(2451471, 1, "dfe988ce9ceeeaeb2410c0778cf27fa9214d1ddfc3e36b214eb5fa5a48ca703f")
