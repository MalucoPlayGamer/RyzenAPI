-- Lua provided by RyzenAPI
-- Game: addappid(2263220)

-- MAIN APPLICATION
addappid(2263220)
addappid(3015420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263221, 1, "f7231be6306bf673227d4942a2dbbb8d218ce57dd87f788229d43c4b4b9559b5")
