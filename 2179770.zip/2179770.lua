-- Lua provided by RyzenAPI
-- Game: Unboxing

-- MAIN APPLICATION
addappid(2179770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2179771, 1, "7b489386cbdd65423aa9df6574fbb6944876be02f6688dbb8f61eb2dd982e08c")
addappid(2179773, 1, "d07465be6f4359af81e5ae1bbd06fdf6a966e7a95291207278cd9fc5a7e942a0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
