-- Lua provided by RyzenAPI
-- Game: Koira - Artworks

-- MAIN APPLICATION
addappid(3602300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3602300,0,"0010a78c0a9eac936622be6f046d89b54954e8f95d895c013326cfd6f3bf402b")

