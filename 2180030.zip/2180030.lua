-- Lua provided by RyzenAPI
-- Game: addappid(2180030)

-- MAIN APPLICATION
addappid(2180030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180031, 1, "36c66a9982d30a4e5ac4425697aab2ffcee7a912fe195fa0599cf1e13763268e")
