-- Lua provided by RyzenAPI
-- Game: The Apocalypse

-- MAIN APPLICATION
addappid(1299130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299131, 1, "430ae2862e4ee84b0797ed0177e69411cd761340f83b7641c3064bbccfa6e2e6")
