-- Lua provided by RyzenAPI 
-- Game: My Therapy
addappid(2027550)
addappid(2027551, 1, "501c3b1811f70bdc03335d1e277a00a642443b9176dab05b2411dce765bd692e")
