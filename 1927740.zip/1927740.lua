-- Lua provided by RyzenAPI
-- Game: Monument Valley 2

-- MAIN APPLICATION
addappid(1927740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1927747,0,"46c8879eb3ab767756128d64c73865baabf28f92ee55743a1271a051ef4cf5e0")
