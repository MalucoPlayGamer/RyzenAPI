-- Lua provided by RyzenAPI
-- Game: Mudborne: Frog Management Sim

-- MAIN APPLICATION
addappid(2355150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2355152,0,"caf7211b415a61d4a34e46e4b5108b7bab94b3a02738aa512d7234a25408024f")

