-- Lua provided by RyzenAPI
-- Game: Super Loco World - Cozy Train Automation

-- MAIN APPLICATION
addappid(3109280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3109282,0,"16d0c5f1477947fbe476b9aca37794d8db6fe461adab5d28cc06f7108b81f88b")
