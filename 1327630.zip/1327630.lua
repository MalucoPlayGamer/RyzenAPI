-- Lua provided by RyzenAPI
-- Game: addappid(1327630)

-- MAIN APPLICATION
addappid(1327630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1327630,0,"d27288f6f1beb9821d93779a8ff989fae883f4b2fb0ded26dabbf8f21809ceba")
addtoken(1327630,9472257735358402677)
