-- Lua provided by RyzenAPI
-- Game: Gas Guzzlers: Combat Carnage

-- MAIN APPLICATION
addappid(596620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(596621, 1, "eb0fac3791edc6c5b8668dfb3341482265def1ff866c6ad0fbfa1f8c56f49665")

