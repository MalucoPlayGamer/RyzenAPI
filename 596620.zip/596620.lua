-- Lua provided by SkyAPI 
-- Game: Gas Guzzlers: Combat Carnage
addappid(596620)
addappid(596621, 1, "eb0fac3791edc6c5b8668dfb3341482265def1ff866c6ad0fbfa1f8c56f49665")
