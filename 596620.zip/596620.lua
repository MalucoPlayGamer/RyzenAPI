-- Lua provided by RyzenAPI
-- Game: Game: Gas Guzzlers: Combat Carnage

-- MAIN APPLICATION
addappid(596620)
-- Game: addappid(596620)

-- MAIN APP DEPOTS / PACKAGES
addappid(596621, 1, "eb0fac3791edc6c5b8668dfb3341482265def1ff866c6ad0fbfa1f8c56f49665")
