-- Lua provided by RyzenAPI
-- Game: addappid(2999680)

-- MAIN APPLICATION
addappid(2999680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999681, 1, "547c3a841d357a0babdb8534cb4bafe1b12ef25699c49209812cf115815e4574")
