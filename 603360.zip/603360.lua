-- Lua provided by RyzenAPI
-- Game: 603360

-- MAIN APPLICATION
addappid(603360)
-- Game: addappid(603360)

-- MAIN APP DEPOTS / PACKAGES
addappid(603361, 1, "f355ad3abe80142651b7277ec738b2aafb9a0bd18fd3c4de71b36c02036ddc09")
