-- Lua provided by RyzenAPI
-- Game: AppID 553480

-- MAIN APPLICATION
addappid(553480)

-- MAIN APP DEPOTS / PACKAGES
addappid(553481, 1, "83000179804384884671ad268ef78c0001fadbe095a24eed90103390d4f4e863")
addappid(823261, 0, "b5953c16e8dcf1325b2510f0c7bd9f77bc3b1cd536fa0cca445078ddb3932256")
addappid(823262, 0, "33f950fcbb470ba5daba244538203b13b1e9b9aaa0e0fb51bd4a627adc3e63c1")
addappid(1005793, 0, "c593590d527a8712e0e7f867fed7e02608742a0fb359dfe3c05df0f4b11b7747")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1005790)
