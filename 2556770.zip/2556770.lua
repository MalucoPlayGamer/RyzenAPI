-- Lua provided by RyzenAPI
-- Game: The Mermaid Mask Demo

-- MAIN APPLICATION
addappid(2556770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556771, 1, "b6f81ccebcceb6646596bea609e4cea20d083fcfcb6edd64b9e0767d2c7cb361")

