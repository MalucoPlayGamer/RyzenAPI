-- Lua provided by RyzenAPI
-- Game: 562410

-- MAIN APPLICATION
addappid(562410)
-- Game: addappid(562410)

-- MAIN APP DEPOTS / PACKAGES
addappid(562411, 1, "c4caa2c19b6af84f81f8bf82db272092c31e1d68196571432857249a761585b4")
