-- Lua provided by RyzenAPI
-- Game: Sheba: A New Dawn

-- MAIN APPLICATION
addappid(1682820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1682821, 1, "cad984e8a8c2f530c80aaf583cd09ee93fc2fd2fb7a6dd32a5e9c355733a89ce")

