-- Lua provided by SkyAPI 
-- Game: Greak: Memories of Azur
addappid(1311070)
addappid(1311071, 1, "c566b39c6fb1541771156e7e002676be9f2252773e1c55253cdfd17d707806c0")
addappid(1710650, 0, "4637f7c6c06d23ab98a9405ec95ae8b1b8317a21a426d056e816ab4014b11a2f")
