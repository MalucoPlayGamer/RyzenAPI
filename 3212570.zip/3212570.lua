-- Lua provided by SkyAPI 
-- Game: RIFTSTORM Demo
addappid(3212570)
addappid(3212571, 1, "712f1624e0bceb3854f83a72c49e609e13b1f731406977578f24ff491110f777")
