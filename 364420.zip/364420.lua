-- Lua provided by RyzenAPI
-- Game: addappid(364420)

-- MAIN APPLICATION
addappid(364420)

-- MAIN APP DEPOTS / PACKAGES
addappid(364421, 1, "4b47d84fbdef98a976c9a73db45e2af604f62dafd1ae2561a936dd3f0a21b854")
addappid(364422, 1, "5d0148a31bf3ef6e88a3adf9ee425f2c9792bce2e140d456ddb83a06d1f4f710")
addappid(364423, 1, "e6239a31491d789d4da0023b2601a10e0f1a9b30a083bf17677f8ba98dd7abcf")
