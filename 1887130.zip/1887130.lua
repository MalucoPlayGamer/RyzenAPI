-- Lua provided by RyzenAPI
-- Game: 花落冬陽 Snowdreams - Digital Artbook

-- MAIN APPLICATION
addappid(1887130)
-- Game: addappid(1887130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1887130,0,"d5d4ca49d3cbb53b394bf8f2dc7d53946e49900066e0b0e469eff5e870c24cbf")
