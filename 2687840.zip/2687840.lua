-- Lua provided by RyzenAPI
-- Game: Game: AppID 2687840

-- MAIN APPLICATION
addappid(2687840)
-- Game: addappid(2687840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2687841, 1, "32f79108f24d9dd3fb64bee62d5ee95802ed29c9df9ae2467c2c309016d1cf51")
