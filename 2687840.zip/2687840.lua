-- Lua provided by SkyAPI 
-- Game: AppID 2687840
addappid(2687840)
addappid(2687841, 1, "32f79108f24d9dd3fb64bee62d5ee95802ed29c9df9ae2467c2c309016d1cf51")
