-- Lua provided by SkyAPI 
-- Game: D-Zone
addappid(2957570)
addappid(2957571, 1, "a460ffadfa26fb8cf07bce706360aeff16f93be4810870139fe68bb28515bf3b")
