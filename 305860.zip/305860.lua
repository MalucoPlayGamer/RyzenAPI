-- Lua provided by RyzenAPI
-- Game: Game: AppID 305860

-- MAIN APPLICATION
addappid(305860)
-- Game: addappid(305860)

-- MAIN APP DEPOTS / PACKAGES
addappid(305861, 1, "2f6f56a823b18fb57a0548b53f6b368227b44891b04cac16ee603eef05268efb")
addappid(305862, 1, "c1bdcb248b1ad6b290c47279a9d6aeb3a361b8e18c122f92a4ffaf8ba4d08a1a")
addappid(305863, 1, "ffd0166d00f66e3048b0e113a9f46a59e4b2062e1ce94a8282e23f3bd66e6e7d")
addappid(313320, 0, "d1d5087ed35b0f3f8096261a5ba0a99dc2806ebb3b1ed2fa51d05f6099035b11")
