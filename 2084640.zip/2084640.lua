-- Lua provided by RyzenAPI
-- Game: The Enjenir Demo

-- MAIN APPLICATION
addappid(2084640)
-- Game: addappid(2084640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2084641, 1, "923575e41391c99c8793ab08b4502f236f0ad2dc5d267e9d0326b0c2385a3618")
