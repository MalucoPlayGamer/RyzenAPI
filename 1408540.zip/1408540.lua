-- Lua provided by RyzenAPI
-- Game: 仙境之夜：白兔奇幻记

-- MAIN APPLICATION
addappid(1408540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408541, 1, "895db87b451a5f453a8ae2579413bbc3da47e1a6d78ee8e2243311a1db04509e")

