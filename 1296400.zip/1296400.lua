-- Lua provided by RyzenAPI
-- Game: Game: AppID 1296400

-- MAIN APPLICATION
addappid(1296400)
-- Game: addappid(1296400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296401, 1, "4e7f5f76e4b45de0a1446e15e192444674e32ac61f103d7772d63b2b88e984a2")
