-- Lua provided by RyzenAPI
-- Game: addappid(839920)

-- MAIN APPLICATION
addappid(839920)

-- MAIN APP DEPOTS / PACKAGES
addappid(839921, 1, "a28d3adf5547eb0c4f4b003269d954c2496d0997a8f5b6959af20fed0db8286c")
