-- Lua provided by RyzenAPI 
-- Game: AppID 839920
addappid(839920)
addappid(839921, 1, "a28d3adf5547eb0c4f4b003269d954c2496d0997a8f5b6959af20fed0db8286c")
