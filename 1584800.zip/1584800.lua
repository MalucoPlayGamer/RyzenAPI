-- Lua provided by RyzenAPI
-- Game: Dark Frame

-- MAIN APPLICATION
addappid(1584800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1584801, 1, "ad847f6c4da6694b0e5f2e04e1db3ec36588510f89b102f83aee4e96f612c7a3")
