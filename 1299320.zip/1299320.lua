-- Lua provided by RyzenAPI 
-- Game: AppID 1299320
addappid(1299320)
addappid(1299321, 1, "11d1de1dd11e8583a5adf970135d385cfde9af5f4cae98c06cfdc1b5254765cd")
