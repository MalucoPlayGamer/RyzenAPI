-- Lua provided by RyzenAPI
-- Game: Luckily, My Arm Is A Shotgun

-- MAIN APPLICATION
addappid(2272770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2272771, 1, "880914fa4eb883eec9241151e7dd87106ca0f643c21019472a275ac01cadf593")

