-- Lua provided by RyzenAPI 
-- Game: Luckily, My Arm Is A Shotgun
addappid(2272770)
addappid(2272771, 1, "880914fa4eb883eec9241151e7dd87106ca0f643c21019472a275ac01cadf593")
