-- Lua provided by RyzenAPI 
-- Game: Case Kovacs - Agent 228
addappid(1452410)
addappid(1452411, 1, "eb71868e102a8d9b0434c5c639b58e177a7966cafb1aec2fe74e4ad460d78d8c")
