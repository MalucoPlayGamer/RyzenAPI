-- Lua provided by RyzenAPI
-- Game: Case Kovacs - Agent 228

-- MAIN APPLICATION
addappid(1452410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1452411, 1, "eb71868e102a8d9b0434c5c639b58e177a7966cafb1aec2fe74e4ad460d78d8c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
