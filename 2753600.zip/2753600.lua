-- Lua provided by RyzenAPI
-- Game: Vambrace: Dungeon Monarch

-- MAIN APPLICATION
addappid(2753600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753601,0,"c79707c0a6b3c96c9e1f39f9d6eeda3f26d55486e0db297d9e4d3f68cb0e577c")
addappid(3624980,0,"c8bf85edf32973ec85e17b6d89469e94ebac8cbd41418c069294cc800b10d6f9")
addappid(3624990,0,"95509dc4a951e21dc6d60e48b5ae02ae3aae93de32e030e49cd165129f55617f")
addappid(3625000,0,"8ab670d7c2b5afa80a9ccd8b248c6c7853677aa43dc6932d9fbeee4d7aad6b47")

