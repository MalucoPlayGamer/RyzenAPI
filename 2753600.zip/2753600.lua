-- Lua provided by RyzenAPI
-- Game: Game: Vambrace: Dungeon Monarch

-- MAIN APPLICATION
addappid(2753600)
-- Game: addappid(2753600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753601, 1, "c79707c0a6b3c96c9e1f39f9d6eeda3f26d55486e0db297d9e4d3f68cb0e577c")
