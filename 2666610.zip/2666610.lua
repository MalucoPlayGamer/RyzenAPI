-- Lua provided by RyzenAPI
-- Game: 2666610

-- MAIN APPLICATION
addappid(2666610)
-- Game: addappid(2666610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2666611, 1, "ff88a857f98e14ea67a68cb74d3f38ed09ed406165707f636a0228864f0b594f")
