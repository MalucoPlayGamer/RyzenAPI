-- Lua provided by RyzenAPI
-- Game: addappid(2719840)

-- MAIN APPLICATION
addappid(2719840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2719841, 1, "bb0e5bbdac1eea7b5396e93b43edb4c2135ff77285a7cdade814320493da52e8")
