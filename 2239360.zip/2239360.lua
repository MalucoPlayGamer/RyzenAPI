-- Lua provided by RyzenAPI
-- Game: Siheyuan

-- MAIN APPLICATION
addappid(2239360)
-- Game: addappid(2239360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2239361, 1, "5996add5e64a4eafa0508ca0a7417e05dc19e48bf2958d5ee12056ed3dae8825")
