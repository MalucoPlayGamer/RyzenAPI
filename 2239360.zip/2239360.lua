-- Lua provided by SkyAPI 
-- Game: Siheyuan
addappid(2239360)
addappid(2239361, 1, "5996add5e64a4eafa0508ca0a7417e05dc19e48bf2958d5ee12056ed3dae8825")
