-- Lua provided by RyzenAPI
-- Game: addappid(2361750)

-- MAIN APPLICATION
addappid(2361750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2361751, 1, "1b4db6e23d8dab93bc62aad35cc870a9ce5a3a4848e483b14dafe1dd1b0f8ccf")
