-- Lua provided by RyzenAPI
-- Game: addappid(1210800)

-- MAIN APPLICATION
addappid(1210800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210801, 1, "cb27fb9f49dcb73a382aa83a2e4ff08379720daafa530a9283a00acb71732c2c")
