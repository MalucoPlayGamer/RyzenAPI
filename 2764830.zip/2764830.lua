-- Lua provided by RyzenAPI
-- Game: Shift Legacy Collection

-- MAIN APPLICATION
addappid(2764830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2764831,0,"904cc6d7d2a71c1ad8ff19866e81f8fad25100d96049c31b04dc79a7c302f7b7")

