-- Lua provided by RyzenAPI
-- Game: Darfall

-- MAIN APPLICATION
addappid(1961600)
-- Game: addappid(1961600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961601, 1, "648e64e57df4bde6e9a0e771af2cc97e87617a73b96057c3c67a788fab747bdb")
