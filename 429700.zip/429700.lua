-- Lua provided by RyzenAPI 
-- Game: AppID 429700
addappid(429700)
addappid(429701, 1, "e86d81d9399c211886312a695d30cef0744912bd9258a6bf14bbafe502a357a9")
