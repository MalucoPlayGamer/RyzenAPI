-- Lua provided by RyzenAPI
-- Game: Mushroom Challenge

-- MAIN APPLICATION
addappid(1345150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345151, 1, "fe5a4fc9b9139f9d96112b4305dc24aba1b1b1e02cf0fdefc86613132305c46f")
