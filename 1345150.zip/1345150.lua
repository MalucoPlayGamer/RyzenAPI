-- Lua provided by SkyAPI 
-- Game: AppID 1345150
addappid(1345150)
addappid(1345151, 1, "fe5a4fc9b9139f9d96112b4305dc24aba1b1b1e02cf0fdefc86613132305c46f")
