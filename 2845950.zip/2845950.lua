-- Lua provided by RyzenAPI
-- Game: 2845950

-- MAIN APPLICATION
addappid(2845950)
-- Game: addappid(2845950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2845951, 1, "398b8fdf9e554f25886bb2bf5a8c0b3256565a21bf6627cf2dc527d669793b4e")
