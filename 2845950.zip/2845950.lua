-- Lua provided by SkyAPI 
-- Game: AppID 2845950
addappid(2845950)
addappid(2845951, 1, "398b8fdf9e554f25886bb2bf5a8c0b3256565a21bf6627cf2dc527d669793b4e")
