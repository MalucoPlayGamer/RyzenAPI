-- Lua provided by RyzenAPI
-- Game: Chicken Hero in Wulin

-- MAIN APPLICATION
addappid(1240610)
-- Game: addappid(1240610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240611, 1, "36a37d3a876e97a1a0c7006fd84cedc82a80ce73c5031f9e1f2f8707e8407fc4")
