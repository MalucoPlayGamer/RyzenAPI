-- Lua provided by RyzenAPI
-- Game: Advanced Mechanized Spacecraft

-- MAIN APPLICATION
addappid(763320)

-- MAIN APP DEPOTS / PACKAGES
addappid(763321, 1, "77300c3ca69f1e7a052ef16bf7e746476190791dfc1519df62881e6721d938ae")
addappid(763322, 1, "657095a70d3ab34fd118e010d3f34f55d811dd51dd366c5726a52d9453a72b9e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
