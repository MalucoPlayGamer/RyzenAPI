-- Lua provided by RyzenAPI
-- Game: Advanced Mechanized Spacecraft

-- MAIN APPLICATION
addappid(763320)

-- MAIN APP DEPOTS / PACKAGES
addappid(763321, 1, "77300c3ca69f1e7a052ef16bf7e746476190791dfc1519df62881e6721d938ae")
addappid(763322, 1, "657095a70d3ab34fd118e010d3f34f55d811dd51dd366c5726a52d9453a72b9e")
