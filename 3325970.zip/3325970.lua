-- Lua provided by RyzenAPI
-- Game: 3325970

-- MAIN APPLICATION
addappid(3325970)
-- Game: addappid(3325970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3325971, 1, "903f5d1080ae1c58dec04c2f98ff6a4e599e8cf2266a84a2f94968a574b2223d")
