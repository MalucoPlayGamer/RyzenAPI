-- Lua provided by RyzenAPI
-- Game: Game: Wall of insanity

-- MAIN APPLICATION
addappid(1713720)
-- Game: addappid(1713720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1713721, 1, "fa29614eb693d535d5e5c1ca757410c895c0eb5bf6b2d43a3a10653f12598c10")
