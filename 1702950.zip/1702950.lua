-- Lua provided by RyzenAPI
-- Game: Jupiter Moons: Mecha Demo

-- MAIN APPLICATION
addappid(1702950)
-- Game: addappid(1702950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702951, 1, "ffef2f8b1fbedc6935e0fb0da9ea4526cbfedc1bd99007dc50c00daec88f58fd")
