-- Lua provided by RyzenAPI 
-- Game: Squeaky Clean
addappid(1606950)
addappid(1606951, 1, "fb16ba462743a5ea7e3aea4c0172edf4b85af5b354d0bb5443e943995686811b")
