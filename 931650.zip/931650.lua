-- Lua provided by RyzenAPI
-- Game: Braveland Heroes

-- MAIN APPLICATION
addappid(931650)
