-- Lua provided by RyzenAPI
-- Game: 2198620

-- MAIN APPLICATION
addappid(2198620)
-- Game: addappid(2198620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2198621, 1, "fa461f049f32902aeb8426014f16ecc7c15b27918664dffc1d0ae0f7e516909c")
