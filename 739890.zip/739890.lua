-- Lua provided by RyzenAPI
-- Game: 739890

-- MAIN APPLICATION
addappid(739890)
-- Game: addappid(739890)

-- MAIN APP DEPOTS / PACKAGES
addappid(739891, 1, "e1e6b86cc6f01d8708e03c2334778eff7dc302b33662e40a46f7b12b81d105cd")
