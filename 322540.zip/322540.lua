-- Lua provided by RyzenAPI
-- Game: AppID 322540

-- MAIN APPLICATION
addappid(322540)

-- MAIN APP DEPOTS / PACKAGES
addappid(322541, 1, "2b4573dc9a8f9a9cf04da3ccdbc9f90570b2faff5852275d6f3139ae00698b6d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
