-- Lua provided by RyzenAPI
-- Game: AppID 322540

-- MAIN APPLICATION
addappid(322540)

-- MAIN APP DEPOTS / PACKAGES
addappid(322541, 1, "2b4573dc9a8f9a9cf04da3ccdbc9f90570b2faff5852275d6f3139ae00698b6d")

