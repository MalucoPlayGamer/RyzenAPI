-- Lua provided by RyzenAPI
-- Game: 1355830

-- MAIN APPLICATION
addappid(1355830)
-- Game: addappid(1355830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1355831, 1, "e63ddcb3fbe79dee60ac6daaa50abd3436ab87687da4923ed78bafe447992885")
