-- Lua provided by RyzenAPI
-- Game: Game: AppID 1063420

-- MAIN APPLICATION
addappid(1063420)
-- Game: addappid(1063420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063421, 1, "754b7cae0a06bd6a6391e3fffbbfeca890dd71f7827f8c01544f070518324142")
