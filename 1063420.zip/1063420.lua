-- Lua provided by RyzenAPI
-- Game: Void Crew

-- MAIN APPLICATION
addappid(1063420)
addappid(2445890)
addappid(4714330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063421,0,"754b7cae0a06bd6a6391e3fffbbfeca890dd71f7827f8c01544f070518324142")

