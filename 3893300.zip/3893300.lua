-- Lua provided by RyzenAPI
-- Game: Lovesome Stay

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3893300, 1, "9b5db22ef32cd1ec726e962d08c44b90205e3efd29fe4ccd9d0d5f3bbdab5567") -- Lovesome Stay
addappid(3893301, 1, "6240a2046fc258f5817e2fb0fc0f352ff2d0d3af685a3455937a04466cc6c715") -- Depot 3893301

