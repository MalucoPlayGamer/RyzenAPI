-- Lua provided by RyzenAPI
-- Game: Hyper Simon X

-- MAIN APPLICATION
addappid(878180)
addappid(918760)
-- Game: addappid(878180)

-- MAIN APP DEPOTS / PACKAGES
addappid(878181, 1, "fd256b5d4a780c1403c37405cb9ec1961775ee4701001192809463e12e266f6b")
