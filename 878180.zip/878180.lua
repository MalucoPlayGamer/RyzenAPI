-- Lua provided by SkyAPI 
-- Game: Hyper Simon X
addappid(878180)
addappid(878181, 1, "fd256b5d4a780c1403c37405cb9ec1961775ee4701001192809463e12e266f6b")
addappid(918760)
