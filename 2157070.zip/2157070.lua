-- Lua provided by RyzenAPI
-- Game: Game: Funeral

-- MAIN APPLICATION
addappid(2157070)
-- Game: addappid(2157070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2157071, 1, "26ca6071cb4dd45672dcc7176e77248eb3ffdf5f6c828013f586c3fe613c216a")
