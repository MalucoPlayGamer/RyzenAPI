-- Lua provided by RyzenAPI
-- Game: 2493560

-- MAIN APPLICATION
addappid(2493560)
-- Game: addappid(2493560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2493561, 1, "767aef51ec7c02f63137dce6ad52f210f1a3cfe9362ab2b5a7d750a1effece71")
