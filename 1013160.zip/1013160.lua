-- Lua provided by RyzenAPI
-- Game: 1013160

-- MAIN APPLICATION
addappid(1013160)
-- Game: addappid(1013160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013161, 1, "19067f621c3d55c185092c4bb26585dee61b8b11fc1aaacceec9ab755466f1b7")
