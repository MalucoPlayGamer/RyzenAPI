-- Lua provided by SkyAPI 
-- Game: AppID 3285810
addappid(3285810)
addappid(3285811, 1, "47a6ae8f9c9b9f6b74f943d8cf1803a2f090347671f4ec9dfc17273bfb3fc22e")
