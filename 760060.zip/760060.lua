-- Lua provided by RyzenAPI
-- Game: Mutant Year Zero: Road to Eden

-- MAIN APPLICATION
addappid(760060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(760061, 1, "5705accc1426ce6319b7cba3cfd4b5295ffb60f186880202690355b00bc0d9c2")
addappid(887780, 0, "957717e1f5504d6233b99309e2b35aaf5e245213bd6b262fccac78414ecd5dce")
addappid(1088000, 0, "9e6a77dd3ec5f043f8e35b13a829c0f38f5b3eeb8fac75d9b893b56d321a3e10")

