-- Lua provided by RyzenAPI 
-- Game: Sisters: Last Day of Summer
addappid(2781750)
addappid(2781751, 1, "5c3d679819846ede99cfe58b13c73d35ddee27bded8f5203b49fa3688b0f95f3")
addappid(2781752, 1, "696eef6dd11faa85a97fc12a44f3c36a6f8563d86371b34caa4dc59c7bdc9ccc")
addappid(2781753, 1, "47e21e2adea99605b73608cae350be7f3d47a85b618ba00f4df9fc2138ce3745")
