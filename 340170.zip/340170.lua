-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY TYPE-0™ HD

-- MAIN APPLICATION
addappid(340170)

-- MAIN APP DEPOTS / PACKAGES
addappid(340171, 1, "372bffd8df359c680d2e0f79f79d38d57d27e0fcafbf37ed41c4b162ddc7d9ea")
addappid(340172, 1, "a372daf37c38e724dc2332af25a298ff0badb4aaeb7126867984fe246b5ce568")
addappid(340173, 1, "0fb88dcc067114bbfaba494181096bc97b93364030bb3e2bdd697ab5e4a02894")
addappid(340174, 1, "5adc493a29a74edd92823aa0c1b3dd63626599d6b3fb026f896f38ba1861ad40")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
