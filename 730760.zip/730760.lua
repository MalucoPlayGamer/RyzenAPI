-- Lua provided by RyzenAPI
-- Game: Game: Go! Go! Radio : 8-Bit Edition

-- MAIN APPLICATION
addappid(730760)
-- Game: addappid(730760)

-- MAIN APP DEPOTS / PACKAGES
addappid(730761, 1, "97ca74bbff6c8b185c149fdc4e551a1a2d2664e5db97c904acaaca388bdf545d")
