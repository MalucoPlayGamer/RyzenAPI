-- Lua provided by SkyAPI 
-- Game: Chicken Duty
addappid(1739400)
addappid(1739401, 1, "9ac6a61f38db753fc7445389e79ede5b3dd9c0e7c260f9273c50184e7bb5f0b3")
