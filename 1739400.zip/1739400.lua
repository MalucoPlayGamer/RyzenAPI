-- Lua provided by RyzenAPI
-- Game: Chicken Duty

-- MAIN APPLICATION
addappid(1739400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1739401, 1, "9ac6a61f38db753fc7445389e79ede5b3dd9c0e7c260f9273c50184e7bb5f0b3")

