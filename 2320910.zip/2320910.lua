-- Lua provided by RyzenAPI
-- Game: AMID EVIL VR

-- MAIN APPLICATION
addappid(2320910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2320911, 1, "31647c4898bf26efffea3717f393d4b576015ecd72a3c37caae868f4dffee36f")

