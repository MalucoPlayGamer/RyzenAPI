-- Lua provided by RyzenAPI
-- Game: Priest Simulator: Heavy Duty

-- MAIN APPLICATION
addappid(1675670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1675671, 1, "cf03b2cad23347c6916b8dbcc1890b0e35806263e37bd6b13a1b6b310a55a734")

