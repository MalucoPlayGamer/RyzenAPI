-- Lua provided by RyzenAPI
-- Game: 1675670

-- MAIN APPLICATION
addappid(1675670)
-- Game: addappid(1675670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1675671, 1, "cf03b2cad23347c6916b8dbcc1890b0e35806263e37bd6b13a1b6b310a55a734")
