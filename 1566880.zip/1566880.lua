-- Lua provided by RyzenAPI
-- Game: SWORD ART ONLINE Last Recollection

-- MAIN APPLICATION
addappid(1566880)
addappid(2296840)
addappid(2296841)
addappid(2296842)
addappid(2296843)
addappid(2296846)
addappid(2603920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1566881, 1, "425a65e84dd99521033eb9d137b3e41b95b6d26f823d1f8227dbb3a6d4bc0572")
addappid(2296844, 0, "6e12c7a8446ad8cd625cf9d6a52b8cb326182af8a6f1e868e4e14f68652c001b")
addappid(2389110, 0, "87e61effb3dbf81dedeff59048a1ae93023bf8fe1d6e0f7cce88eb56c1242c84")

