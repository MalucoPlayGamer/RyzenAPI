-- Lua provided by RyzenAPI 
-- Game: SWORD ART ONLINE Last Recollection
addappid(1566880)
addappid(1566881, 1, "425a65e84dd99521033eb9d137b3e41b95b6d26f823d1f8227dbb3a6d4bc0572")
addappid(2296840)
addappid(2296841)
addappid(2296842)
addappid(2296844, 0, "6e12c7a8446ad8cd625cf9d6a52b8cb326182af8a6f1e868e4e14f68652c001b")
addappid(2296846)
addappid(2389110, 0, "87e61effb3dbf81dedeff59048a1ae93023bf8fe1d6e0f7cce88eb56c1242c84")
addappid(2603920)
