-- Lua provided by RyzenAPI
-- Game: Sex Adventures - Futanari Doctor

-- MAIN APPLICATION
addappid(1931680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931681, 1, "6c987d940461a279e3f4d42bbe560a02d2b5f09453e16cee399dd9baaf6e77e9")
