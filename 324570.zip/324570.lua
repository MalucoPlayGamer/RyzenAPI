-- Lua provided by RyzenAPI
-- Game: Halo: Spartan Strike

-- MAIN APPLICATION
addappid(324570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(324571, 1, "ea796de56c067bb73f342af86a9cd6a77438f7a85579f89a0a040d97e2874c2b")

