-- Lua provided by RyzenAPI
-- Game: Halo: Spartan Strike

-- MAIN APPLICATION
addappid(324570)

-- MAIN APP DEPOTS / PACKAGES
addappid(324571, 1, "ea796de56c067bb73f342af86a9cd6a77438f7a85579f89a0a040d97e2874c2b")

