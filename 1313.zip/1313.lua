-- Lua provided by RyzenAPI
-- Game: SiN Gold

-- MAIN APPLICATION
addappid(1313)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311,0,"2c6305c96d02b24ddb26c7de12ea9a4ec2948a567dcedc55fb533f99c8dbe616")
addappid(1312,0,"3d5468dc18c2c45eb429d7a380dc2872f644e77418334c5ebaaf587f42204ac2")
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

