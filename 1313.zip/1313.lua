-- Lua provided by RyzenAPI
-- Game: 1313

-- MAIN APPLICATION
addappid(1313)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311,0,"2c6305c96d02b24ddb26c7de12ea9a4ec2948a567dcedc55fb533f99c8dbe616")
addappid(1312,0,"3d5468dc18c2c45eb429d7a380dc2872f644e77418334c5ebaaf587f42204ac2")
