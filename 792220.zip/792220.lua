-- Lua provided by RyzenAPI
-- Game: AppID 792220

-- MAIN APPLICATION
addappid(792220)

-- MAIN APP DEPOTS / PACKAGES
addappid(792221, 1, "c8127dbb93449cd2ea6b927f77988e187b7d5d46f6c54e9aea4ea49bd1265729")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1185910)
