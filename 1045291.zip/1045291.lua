-- Lua provided by RyzenAPI
-- Game: Diesel Brothers: Truck Building Simulator - Garage Tunes (Soundtrack)

-- MAIN APPLICATION
addappid(1045291)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045291,0,"f14145fa899c5d9d138083b70b4519a0925e9385d85628a4a1f384651b80c94e")

