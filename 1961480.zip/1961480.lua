-- Lua provided by RyzenAPI
-- Game: 1961480

-- MAIN APPLICATION
addappid(1961480)
-- Game: addappid(1961480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961481, 1, "5d7d3820dee99c9fe181ff054941f8cfc79f11e184d2451eb7d403704c120056")
