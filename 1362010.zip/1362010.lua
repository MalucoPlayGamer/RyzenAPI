-- Lua provided by RyzenAPI
-- Game: SEX, Drugs and CYBERPUNK

-- MAIN APPLICATION
addappid(1362010)
-- Game: addappid(1362010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1362011, 1, "e00549b0f005f864bcc508cbd627167c8663d19524ff07cba94759f5fee8ab84")
