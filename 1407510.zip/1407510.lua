-- Lua provided by RyzenAPI
-- Game: 大江湖之苍龙与白鸟 Demo

-- MAIN APPLICATION
addappid(1407510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1407511, 1, "52143e4f4e7fe9a9d60f6a9f1dfa7ab90d7fee9b0145a0ead516462ea67f05d0")
