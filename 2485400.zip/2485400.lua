-- Lua provided by RyzenAPI
-- Game: 2485400

-- MAIN APPLICATION
addappid(2485400)
-- Game: addappid(2485400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2485400,0,"1c2044c2a9a0d4c545c013e0cfce89c6c2b91c5918ce8cebe31523193f727399")
