-- Lua provided by RyzenAPI
-- Game: Street Outlaws 2: Winner Takes All

-- MAIN APPLICATION
addappid(1451950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1451951, 1, "fd5375d7f84a16bbf89f440c28a457c7885189bbba39dc0ab432a7e7f55513ce")
addappid(1812470, 0, "285963cbd26f8f106c6ed47a6c055d5ccc2ffd38ddfb07d1eee7db1cc5668958")
addappid(1812480, 0, "512f23aa46f757122cabd39f2f971288d657fbcf4936c8c042867b32546ff7aa")
addappid(1812481, 0, "8f774293b6077b7c8ee3d1dcd792f41a8137bdf88b2de56f3db28cef47cd1922")
addappid(1812482, 0, "2977df08fb2f4f5c8a9c3d433db3b0b66a5a8f6476786d4dc2ec1d96bed863c0")
addappid(1812483, 0, "0b8e31e20ccf4bd8fc4554b9a3e3a053de8a84c2b1218f1dab2c81d670bf7eaf")
addappid(1812484, 0, "f71aff5cf44c3558ef2c8824db19fcdc7a59ccf95107d4a2e12ace5a2ce1587e")
addappid(1812485, 0, "205b2439b31a0794fc3bc7f2386a318845cb3fdbe68d08ece7cc14ca06dd6ca0")
addappid(1812486, 0, "340b40e064edcea4215635b6c9c8cef04ed0648921035e78c7bc1be08748f1a9")
addappid(1812487, 0, "cdc0333fa04a6559c107dde1c084e1643dcde4a0a6d498f2105000bdbfa17e1a")
