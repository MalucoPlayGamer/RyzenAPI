-- Lua provided by RyzenAPI
-- Game: Game: The Guardian Stone

-- MAIN APPLICATION
addappid(1663860)
-- Game: addappid(1663860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1663861, 1, "163c6d28179e009a616df40f850734a09876457c0145feef9816e9c8e95ee6d5")
