-- Lua provided by SkyAPI 
-- Game: AppID 977560
addappid(977560)
addappid(977561, 1, "f76711fe7c9828209e449b872d264069e5b5c66bcb238c1a812c2dd506b5ebe6")
addappid(977564, 1, "f9a0faf112d10d4b01f09f8604f1a46eabcef802e6de263fd38ac637adbb9757")
