-- Lua provided by RyzenAPI
-- Game: Fareast Four Season Story: Hello World Demo

-- MAIN APPLICATION
addappid(2579210)
-- Game: addappid(2579210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2579211, 1, "f462dce006e3021555857b4b9777ed5d61731594c473f3424f1a18f1ae761702")
