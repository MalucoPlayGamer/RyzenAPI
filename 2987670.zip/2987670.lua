-- Lua provided by SkyAPI 
-- Game: FURRY ORGY
addappid(2987670)
addappid(2987671, 1, "7dc818d6bb3e2fff7cbe4e74d9bffa75f1e2e48377423b8dc0392b52a5750189")
