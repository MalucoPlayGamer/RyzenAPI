-- Lua provided by RyzenAPI
-- Game: Game: FURRY ORGY

-- MAIN APPLICATION
addappid(2987670)
-- Game: addappid(2987670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2987671, 1, "7dc818d6bb3e2fff7cbe4e74d9bffa75f1e2e48377423b8dc0392b52a5750189")
