-- Lua provided by RyzenAPI
-- Game: Fancy Trangram VR

-- MAIN APPLICATION
addappid(552240)

-- MAIN APP DEPOTS / PACKAGES
addappid(552241, 1, "2b2bbcfa0cc649f1bd858e2a19fee1b0fbaea325a88f87df488d990a5e818ea3")

