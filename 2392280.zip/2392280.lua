-- Lua provided by RyzenAPI
-- Game: 2392280

-- MAIN APPLICATION
addappid(2392280)
-- Game: addappid(2392280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2392281, 1, "0be342cb8e6a01ba5429bbc63786465de3a8e96c6ad86213028d279c74bdd27a")
