-- Lua provided by RyzenAPI
-- Game: 760620

-- MAIN APPLICATION
addappid(760620)
-- Game: addappid(760620)

-- MAIN APP DEPOTS / PACKAGES
addappid(760621, 1, "f4ef19be07d7773d2a73f9577b9d5f13b47917162fb33e2f3ec1837c4e0ff09f")
addappid(760622, 1, "e9675e5acb51b6ac501852157c70570c5eafa1be5693ba2ccaaf3828ebbe9e04")
