-- Lua provided by RyzenAPI 
-- Game: AppID 509130
addappid(509130)
addappid(509131, 1, "aa32e5c3c201a74e204c81a85eb1d90a805a7ae14508ff60cd62ede9a96796d9")
