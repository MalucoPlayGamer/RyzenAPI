-- Lua provided by RyzenAPI
-- Game: War Smith

-- MAIN APPLICATION
addappid(1269250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269251, 1, "5dd9e3cee2aa9f499f49ff9aa0911ac9f1a9422c2f6fc5fb82ff009131cdc27b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
