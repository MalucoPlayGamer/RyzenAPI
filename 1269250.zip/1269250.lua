-- Lua provided by RyzenAPI
-- Game: Game: War Smith

-- MAIN APPLICATION
addappid(1269250)
-- Game: addappid(1269250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269251, 1, "5dd9e3cee2aa9f499f49ff9aa0911ac9f1a9422c2f6fc5fb82ff009131cdc27b")
