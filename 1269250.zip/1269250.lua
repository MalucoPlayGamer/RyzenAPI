-- Lua provided by RyzenAPI 
-- Game: War Smith
addappid(1269250)
addappid(1269251, 1, "5dd9e3cee2aa9f499f49ff9aa0911ac9f1a9422c2f6fc5fb82ff009131cdc27b")
