-- Lua provided by RyzenAPI
-- Game: AppID 1101450

-- MAIN APPLICATION
addappid(1101450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101451, 1, "2c5e03d9013f9ac01f525774d818dc1b30d84076bb2c2409cfda45b271bdcba4")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1114100)
