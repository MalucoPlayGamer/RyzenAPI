-- Lua provided by RyzenAPI
-- Game: Miss Neko

-- MAIN APPLICATION
addappid(1101450)
addappid(1114100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101451, 1, "2c5e03d9013f9ac01f525774d818dc1b30d84076bb2c2409cfda45b271bdcba4")

