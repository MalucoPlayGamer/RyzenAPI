-- Lua provided by RyzenAPI
-- Game: Aces of the Luftwaffe - Squadron

-- MAIN APPLICATION
addappid(859350)
addappid(860630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(859351, 1, "278bea2f94ba7069f687b491a20e1818778569a5eff95eccf5639c22be9272e9")

