-- Lua provided by RyzenAPI
-- Game: MR 333 II: Planetbirth

-- MAIN APPLICATION
addappid(2780660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780661, 1, "3d47b506fb1aacdf4abaa8367bb0e4d24961602104a2e71d341a5b015d2e01cc")

