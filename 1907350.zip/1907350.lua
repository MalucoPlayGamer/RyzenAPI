-- Lua provided by RyzenAPI 
-- Game: AppID 1907350
addappid(1907350)
addappid(1907351, 1, "7d2391d7a709bc6e2928d86d145729ad8648e344a291ff6b1ba8fb293fcc09a6")
