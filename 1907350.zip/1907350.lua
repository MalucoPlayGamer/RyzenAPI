-- Lua provided by RyzenAPI
-- Game: Arena Renovation - First Job

-- MAIN APPLICATION
addappid(1907350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1907351, 1, "7d2391d7a709bc6e2928d86d145729ad8648e344a291ff6b1ba8fb293fcc09a6")

