-- Lua provided by RyzenAPI
-- Game: Clover Reset

-- MAIN APPLICATION
addappid(3239250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3239251, 1, "05d0bb6a3326ce8a6fd1decafdace1dfc4ae5ab8555020c3762a3d4d379b6d61")

