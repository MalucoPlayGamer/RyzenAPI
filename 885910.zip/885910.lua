-- Lua provided by RyzenAPI
-- Game: Ginga Force

-- MAIN APPLICATION
addappid(885910)

-- MAIN APP DEPOTS / PACKAGES
addappid(885911, 1, "20c442c036ecc66949c8cf400fc69365b68054f48c53870636e494e90cc2ce0c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
