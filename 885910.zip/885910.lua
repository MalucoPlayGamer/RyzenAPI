-- Lua provided by RyzenAPI
-- Game: Ginga Force

-- MAIN APPLICATION
addappid(885910)
-- Game: addappid(885910)

-- MAIN APP DEPOTS / PACKAGES
addappid(885911, 1, "20c442c036ecc66949c8cf400fc69365b68054f48c53870636e494e90cc2ce0c")
