-- Lua provided by RyzenAPI
-- Game: 261020

-- MAIN APPLICATION
addappid(261020)
-- Game: addappid(261020)

-- MAIN APP DEPOTS / PACKAGES
addappid(261021, 1, "09cad8fd6916cdd18f10befd1b810903137c43b64dccc4fac986b5e492ea572e")
