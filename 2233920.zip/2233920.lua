-- Lua provided by RyzenAPI
-- Game: addappid(2233920)

-- MAIN APPLICATION
addappid(2233920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233921, 1, "2c3dcb4d36e4ecc3faa908ca4950511d3f4c54bdde4dfc8a727f0ebed253dd6f")
