-- Lua provided by RyzenAPI
-- Game: Game: AppID 613010

-- MAIN APPLICATION
addappid(613010)
-- Game: addappid(613010)

-- MAIN APP DEPOTS / PACKAGES
addappid(613011, 1, "4c06abf2984fa2c9201d7f9900468d7597eff28d833a7e3f6d39a855419e488b")
addappid(613012, 1, "d98e6af04a045362b8901053fc7d8c2a6abb3effc4840544aee2e172b5b8b410")
