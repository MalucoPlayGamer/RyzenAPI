-- Lua provided by RyzenAPI
-- Game: 380560

-- MAIN APPLICATION
addappid(380560)
-- Game: addappid(380560)

-- MAIN APP DEPOTS / PACKAGES
addappid(380561, 1, "d3275994ddbaa3c7104829de5ea53ae14e5b81e3de3f746ad536de88878266a8")
