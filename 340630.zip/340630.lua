-- Lua provided by RyzenAPI
-- Game: Game: Ninja Guy

-- MAIN APPLICATION
addappid(340630)
-- Game: addappid(340630)

-- MAIN APP DEPOTS / PACKAGES
addappid(340631, 1, "a9a95fab140e32f0d5471fc796b87a36400269e38b9ad2b729401860ba26debd")
addappid(340632, 1, "2e563b7fb06c73707ff63dc8319b544eb7ead6b7d46163cc6b3f242d9788d73c")
addappid(340633, 1, "0f2bc0521ac6cf1890404d0174eaf5e910c366976b7793c31fc8f38c47b2ba79")
addappid(340634, 1, "b46e76630f62bf97caefc6576c8eb6a25c3bae9566bfffcf85dc3e3876a7b5a0")
addappid(340635, 1, "08b7b5d81717ad4bda79b932b75ac015b954b7f294a736b12a8d6424ef30788b")
