-- Lua provided by RyzenAPI
-- Game: Squarism

-- MAIN APPLICATION
addappid(745030)
addappid(750640)

-- MAIN APP DEPOTS / PACKAGES
addappid(745031, 1, "a896230d690a9be3570741c13fd8a1e9bb39ac4b30220db0bb2d906cd6e67406")
