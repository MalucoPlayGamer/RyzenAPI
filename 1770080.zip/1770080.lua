-- Lua provided by SkyAPI 
-- Game: Superfuse
addappid(1770080)
addappid(1770081, 1, "5c4583aa8af1fd60a5b58b32b61b62f0bd78719f01c44911db342facc512fb6e")
