-- Lua provided by RyzenAPI
-- Game: Superfuse

-- MAIN APPLICATION
addappid(1770080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770081, 1, "5c4583aa8af1fd60a5b58b32b61b62f0bd78719f01c44911db342facc512fb6e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2282090)
