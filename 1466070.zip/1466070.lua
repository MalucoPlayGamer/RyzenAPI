-- Lua provided by SkyAPI 
-- Game: Fool's Paradise
addappid(1466070)
addappid(1466071, 1, "ca2570d9b3cc86ee7e85d29dcaa685d599521579148b0543b45b2c068fbc045e")
