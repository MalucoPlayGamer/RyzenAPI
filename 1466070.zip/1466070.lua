-- Lua provided by RyzenAPI
-- Game: Game: Fool's Paradise

-- MAIN APPLICATION
addappid(1466070)
-- Game: addappid(1466070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1466071, 1, "ca2570d9b3cc86ee7e85d29dcaa685d599521579148b0543b45b2c068fbc045e")
