-- Lua provided by RyzenAPI 
-- Game: AppID 964800
addappid(964800)
addappid(964801, 1, "1e07e2d26b198dcfda1c99a757ae5abc5699139537cccfa00ac61fe76033a2ab")
addappid(964803, 1, "0b54325c4c2ce079f4676f6492d7a640e9831574ed75b02352316a0cba970971")
