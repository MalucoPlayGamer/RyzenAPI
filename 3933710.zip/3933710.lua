-- Lua provided by RyzenAPI
-- Game: My Car My Life

-- MAIN APPLICATION
addappid(3933710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3933711,0,"30d62cfaf063a27b6d92d43278f89a288587df1c94bcac77fcafcbb85b47e2fe")

