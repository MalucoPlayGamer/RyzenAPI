-- Lua provided by RyzenAPI
-- Game: Beat Saber - Metallica - "Lux Æterna"

-- MAIN APPLICATION
addappid(3354590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354590,0,"705bb5987644ae5d173a84bfa143e26673f7808dc2911be17fe09a58565d4671")
