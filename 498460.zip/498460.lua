-- Lua provided by RyzenAPI
-- Game: addappid(498460)

-- MAIN APPLICATION
addappid(498460)

-- MAIN APP DEPOTS / PACKAGES
addappid(498461, 1, "c0eec2e58666b7a869896f1390ffeb1d5c0b7fc95aa488c8e1d0c43e9086679e")
