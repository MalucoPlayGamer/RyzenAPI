-- Lua provided by RyzenAPI
-- Game: AppID 959030

-- MAIN APPLICATION
addappid(959030)

-- MAIN APP DEPOTS / PACKAGES
addappid(959031, 1, "36b843ef8fa330d25d52283c1f8d369b3eada7ea8a53dd3d94f7f5266d21e43f")
