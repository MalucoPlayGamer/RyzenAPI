-- Lua provided by RyzenAPI
-- Game: Game: Hand of Doom

-- MAIN APPLICATION
addappid(1924400)
-- Game: addappid(1924400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1924401, 1, "b9942e4979f405a2ef2e5e38a45829c28d4baf6173c42607c2d48b0ea50c431e")
