-- Lua provided by RyzenAPI
-- Game: Wavetale

-- MAIN APPLICATION
addappid(1823930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823931, 1, "087783432f78e0fc4dc11f141dc90c15a2c252fe630c8a2672ca32b0ddae5897")

