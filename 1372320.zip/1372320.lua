-- Lua provided by SkyAPI 
-- Game: Cloud Gardens
addappid(1372320)
addappid(1372321, 1, "c6048f5203ffadde7e04256cee879b17a7f1b97f01cc849404e940ee0715f264")
addappid(1372322, 1, "b013288636d1c029efe42290a797e7ad5133cd28a83804250ddd5f5986a48d9a")
