-- Lua provided by RyzenAPI
-- Game: Shattered Star

-- MAIN APPLICATION
addappid(2096480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096481, 1, "5f8772d520fdd63c50e685262a42a56c9ce7978c4ffba4f6350e295419050807")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
