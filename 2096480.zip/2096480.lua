-- Lua provided by RyzenAPI
-- Game: Game: Shattered Star

-- MAIN APPLICATION
addappid(2096480)
-- Game: addappid(2096480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096481, 1, "5f8772d520fdd63c50e685262a42a56c9ce7978c4ffba4f6350e295419050807")
