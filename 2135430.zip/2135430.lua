-- Lua provided by RyzenAPI
-- Game: 2135430

-- MAIN APPLICATION
addappid(2135430)
-- Game: addappid(2135430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2135430,0,"8b0ad6d40d951cbe21f1d2b6813f60e5d86533f334ec692f53dde14964bd625d")
