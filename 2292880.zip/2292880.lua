-- Lua provided by RyzenAPI 
-- Game: The City: Superhero Flying Experience
addappid(2292880)
addappid(2292881, 1, "34651a8597af3e87f2ad00a487b9596c9cb3be930781367f0b093162c82bf417")
