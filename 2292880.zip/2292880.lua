-- Lua provided by RyzenAPI
-- Game: The City: Superhero Flying Experience

-- MAIN APPLICATION
addappid(2292880)
-- Game: addappid(2292880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2292881, 1, "34651a8597af3e87f2ad00a487b9596c9cb3be930781367f0b093162c82bf417")
