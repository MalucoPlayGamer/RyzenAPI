-- Lua provided by RyzenAPI 
-- Game: Danko and the mystery of the jungle
addappid(1215340)
addappid(1215341, 1, "6abde96aae2d0be6e5d0ddc97592d1563c1ce41ae3ade0d046c9fd6edafaf1ae")
