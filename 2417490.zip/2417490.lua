-- Lua provided by RyzenAPI
-- Game: Game: HOLEHOLE

-- MAIN APPLICATION
addappid(2417490)
-- Game: addappid(2417490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2417491, 1, "9b6dc4a32c2833f078676f4d977a9cede046cdf0da865397a55bfc7c46ce5136")
addappid(2417492, 1, "738f3c1eb368142f7a6bd2caf3463e2faa33191ba9980c346b794054fe3b086f")
