-- Lua provided by RyzenAPI
-- Game: Another Farm Roguelike

-- MAIN APPLICATION
addappid(2116850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2116851, 1, "12bcd296c9979cdbe33581add5e36b3c3a29d1faeba1ca809bcd1fa4eb4729e8")
