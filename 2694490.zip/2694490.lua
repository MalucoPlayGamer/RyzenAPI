-- Lua provided by RyzenAPI
-- Game: Path of Exile 2

-- MAIN APPLICATION
addappid(2694490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2694491, 1, "e30d071e5cd89c91b6675ce95a63377021dd70852367d073a9fc76ec88fff843")
addappid(2694492, 1, "605258f87a1f07cfe2baaf34fedebb1b064859274a3191cdb43fcd5876336221")

