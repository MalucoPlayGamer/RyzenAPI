-- Lua provided by RyzenAPI
-- Game: Path of Exile 2

-- MAIN APPLICATION
addappid(2694490)
addappid(3349410)
addappid(3349420)
addappid(3349430)
addappid(3906470)
addappid(3906480)
addappid(3906490)
addappid(3906500)
addappid(3906510)
addappid(3906520)
addappid(4200610)
addappid(4200620)
addappid(4200630)
addappid(4200640)
addappid(4200650)
addappid(4200660)
addappid(4555110)
addappid(4619840)
addappid(4619850)
addappid(4619860)
addappid(4619870)
addappid(4619880)
addappid(4619890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2694491,0,"e30d071e5cd89c91b6675ce95a63377021dd70852367d073a9fc76ec88fff843")
addappid(2694492,0,"605258f87a1f07cfe2baaf34fedebb1b064859274a3191cdb43fcd5876336221")
addappid(2694493,0,"75fd52272326822de2282884751247dae91c9eb7937338a58e25d214a307a756")

