-- Lua provided by RyzenAPI
-- Game: MycoRelic Demo

-- MAIN APPLICATION
addappid(2747040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747041, 1, "10a9a5a830466b1332eceb0b036a719e3fce8fe98bf44a7e4145d5d652bbd355")

