-- Lua provided by RyzenAPI
-- Game: 873190

-- MAIN APPLICATION
addappid(873190)
-- Game: addappid(873190)

-- MAIN APP DEPOTS / PACKAGES
addappid(873191, 1, "d53c9452d9d5fdfe19780021d095ec7bda0db8bd07665b915cd907668be225ca")
