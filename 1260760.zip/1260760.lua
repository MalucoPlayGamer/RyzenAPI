-- Lua provided by RyzenAPI 
-- Game: AppID 1260760
addappid(1260760)
addappid(1260761, 1, "420f4b220265a705510d8c5b263de0f674d8503f454dcecbe606d82ddfa5394c")
