-- Lua provided by RyzenAPI 
-- Game: Bring Dad Home
addappid(1332380)
addappid(1332381, 1, "0169f6f0e4fe72d918869351dc7485d7e1964b0a6d1a8101798c5ca236b50a41")
addappid(1332383, 1, "b4af490e3957de1a4282018ba05cb204d5cce2e6de2ccf56036f217e2960a942")
