-- Lua provided by RyzenAPI
-- Game: AppID 1235510

-- MAIN APPLICATION
addappid(1235510)
-- Game: addappid(1235510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1235511, 1, "fd3b39f336126a6620d32153ca1da7cdaccbd228aa67c17eca12af0cfe282fb7")
