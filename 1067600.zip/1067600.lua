-- Lua provided by SkyAPI 
-- Game: The Defender: Farm and Castle
addappid(1067600)
addappid(1067601, 1, "a7719803af162232b4949659503b06a184bc5b4049aab8172be8c0fe7ec02886")
