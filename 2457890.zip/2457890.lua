-- Lua provided by RyzenAPI
-- Game: Game: DRACOMATON

-- MAIN APPLICATION
addappid(2457890)
-- Game: addappid(2457890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2457891, 1, "d21b2800b2e35782baf57d1646111aa97b7d1422ea8e170f414367b31ff0166f")
