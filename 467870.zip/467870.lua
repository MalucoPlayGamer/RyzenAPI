-- Lua provided by RyzenAPI
-- Game: MINUS ZERO - Original Sound Track

-- MAIN APPLICATION
addappid(467870)

-- MAIN APP DEPOTS / PACKAGES
addappid(467871, 1, "d5d085cd97912a9ee657c870703d876737f6559dcdedbbe0f6726b3ebe802461")
