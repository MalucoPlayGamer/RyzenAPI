-- Lua provided by RyzenAPI
-- Game: AppID 1172470

-- MAIN APPLICATION
addappid(1172470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1172471, 1, "07aa3be059db58b5721e17cb3e8c90e03a1905aff70010a5f797a2f993516984")
addappid(1172472, 1, "2d8c2248b6a32f060a98833b794bfe1389f8013990e15270fd37d5f6afb919ec")
addappid(1172473, 1, "6a56a233dd8485b7ff6e653cbad3936a1bc6b401e23c3cfa2344f1af820bed37")
addappid(1172474, 1, "62fd173e23d67c4f6ca3f00eb389a16caf7d02997a61bc022876410e1396cfab")
addappid(1172475, 1, "1cc5c1dfd724bccf46f21245f637b41ce56dc94e6d87f13cadfa0bb1b4642eb2")
addappid(1172476, 1, "2c7bc15467491f509af58c3865003c3e841699d902300953fb76310f0c582460")
addappid(1172477, 1, "850186824241bbe7e4fcb22cf90f3225591834496905d2946d45d1d8e4210dbc")
addappid(1172478, 1, "a08e1070c2beb20e95f9339404827e903df22cdbf0b91b17ce3990c110e8313c")
addappid(1172479, 1, "35edf936f063125939e06eaaa66ab4b6be58dc79af9c8aab5bde08c942a303cb")
addappid(1311105, 0, "70fc46e692a1da85e402ead6bfce0fc11831de7b9597a24ec40cff53b0c698d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1311090)
addappid(1311091)
addappid(1311092)
addappid(1311094)
addappid(1311098)
addappid(1311100)
addappid(1311101)
addappid(1311102)
addappid(1440320)
addappid(1445900)
addappid(1445930)
addappid(1445950)
addappid(1445990)
addappid(1465730)
addappid(1465731)
addappid(1465732)
addappid(1465733)
addappid(1465734)
addappid(1467350)
addappid(1479451)
addappid(1479453)
addappid(1479454)
addappid(1576330)
addappid(1622670)
addappid(1623570)
addappid(1623571)
addappid(1831300)
addappid(1948850)
addappid(3403260)
