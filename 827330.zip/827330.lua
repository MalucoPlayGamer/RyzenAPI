-- Lua provided by RyzenAPI
-- Game: Skydrift Infinity

-- MAIN APPLICATION
addappid(827330)

-- MAIN APP DEPOTS / PACKAGES
addappid(827331, 1, "645aa864ace73467aa443133da03796e38a27c65352c65667793f2b64255c953")

