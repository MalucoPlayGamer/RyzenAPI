-- Lua provided by RyzenAPI
-- Game: Skydrift Infinity

-- MAIN APPLICATION
addappid(827330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(827331, 1, "645aa864ace73467aa443133da03796e38a27c65352c65667793f2b64255c953")

