-- Lua provided by RyzenAPI
-- Game: Circle Rally Party

-- MAIN APPLICATION
addappid(992950)
-- Game: addappid(992950)

-- MAIN APP DEPOTS / PACKAGES
addappid(992951, 1, "e8fcf172b178e5b228fc760051ca7302920bfd3284e681fe12b8ae21306f56c6")
