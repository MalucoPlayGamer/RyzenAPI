-- Lua provided by RyzenAPI
-- Game: addappid(209830)

-- MAIN APPLICATION
addappid(209830)
addappid(433780)

-- MAIN APP DEPOTS / PACKAGES
addappid(209831, 1, "3281ce742ac0927afc658e10fa03047470e9768df05f33a842997dc23dd87d28")
addappid(209832, 1, "982b088b872c78620297cbdb18aee1a3c359a8c5fffbe0e49b49a52dd8705795")
