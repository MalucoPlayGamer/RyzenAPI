-- Lua provided by RyzenAPI
-- Game: Farstorm

-- MAIN APPLICATION
addappid(923420)
addappid(1145990)
addappid(1148640)

-- MAIN APP DEPOTS / PACKAGES
addappid(923422,0,"dfe246db28901e8ed3c05d7377d2a54cd62b181a90398b29759ac37568573ce1")

