-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(923420)
addappid(228986)
-- setManifestid(228986,"8782296191957114623")
addappid(228987)
-- setManifestid(228987,"4302102680580581867")
addappid(228990)
-- setManifestid(228990,"1829726630299308803")
addappid(229005)
-- setManifestid(229005,"7992454656023763365")
addappid(923422,0,"dfe246db28901e8ed3c05d7377d2a54cd62b181a90398b29759ac37568573ce1")
-- setManifestid(923422,"6734856532938298134")