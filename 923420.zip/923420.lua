-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228986)
addappid(228987)
addappid(228990)
addappid(229005)
addappid(923420)

-- MAIN APP DEPOTS / PACKAGES
addappid(923422,0,"dfe246db28901e8ed3c05d7377d2a54cd62b181a90398b29759ac37568573ce1")

