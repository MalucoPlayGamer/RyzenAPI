-- Lua provided by RyzenAPI
-- Game: Farstorm

-- MAIN APPLICATION
addappid(923420)
addappid(1145990)
addappid(1148640)

-- MAIN APP DEPOTS / PACKAGES
addappid(923422,0,"dfe246db28901e8ed3c05d7377d2a54cd62b181a90398b29759ac37568573ce1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
