-- Lua provided by SkyAPI 
-- Game: PHANTASIA
addappid(1821820)
addappid(1821821, 1, "d6ffdb922f1f3e5cfc9cd6fe43897563815558f0d34103f1cca670179dfbd16a")
