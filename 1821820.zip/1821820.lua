-- Lua provided by RyzenAPI
-- Game: PHANTASIA

-- MAIN APPLICATION
addappid(1821820)
-- Game: addappid(1821820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1821821, 1, "d6ffdb922f1f3e5cfc9cd6fe43897563815558f0d34103f1cca670179dfbd16a")
