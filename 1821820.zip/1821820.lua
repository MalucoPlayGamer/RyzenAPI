-- Lua provided by RyzenAPI
-- Game: PHANTASIA

-- MAIN APPLICATION
addappid(1821820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1821821, 1, "d6ffdb922f1f3e5cfc9cd6fe43897563815558f0d34103f1cca670179dfbd16a")

