-- Lua provided by RyzenAPI 
-- Game: Slimekeep Soundtrack
addappid(3750380)
addappid(3750381, 1, "0f4c994dcb35e67fbe71038b9d601887527ed52ac866713f9c3100498b4ca58c")
addappid(3750382, 1, "5a409678d03034a1415066765fa459a456d948ddfa3ca62e1b42c4b025dbbd18")
