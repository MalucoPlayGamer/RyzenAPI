-- Lua provided by RyzenAPI
-- Game: addappid(2902100)

-- MAIN APPLICATION
addappid(2902100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2902101, 1, "1e9ecc782db863715ff6afa84de44f2ad8fc1a87ed4e3793a37d559e0a7eb9b5")
