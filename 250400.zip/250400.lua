-- Lua provided by RyzenAPI
-- Game: Game: How to Survive

-- MAIN APPLICATION
addappid(250400)
addappid(289732)
addappid(289733)
addappid(289734)
-- Game: addappid(250400)

-- MAIN APP DEPOTS / PACKAGES
addappid(250401, 1, "6372189d2d1cf4cab7b0b59f10620327fccd3e084ad79e276f9722509bed6bfe")
addappid(250402, 1, "2d3fbc304c9eece62cf9778843ac9430321112f51cbe5d99d86bdb86bf9d8ae8")
addappid(250403, 1, "9db35200a8ef2763b3a2711a66f26a2fd63f2d036a4ee7e03a4d67db5a4644d8")
addappid(250404, 1, "f505e8703cdd9372a569c4facad6a9d4f92ab960558ec4c4c28874c73ab2aff7")
addappid(250405, 1, "77820344ba17338445c6de064e3293a669fc7f8cd50847bc65f3bbc3cfabec1a")
addappid(250406, 1, "bdb3ca0e1a988331a7e014ebeaa23dffcecefeca46105b0834f41fa4f872c036")
addappid(250407, 1, "43f5170a41f5e11d9a60e4ae18a70dd42570ac709320c9fcabbfa59f15d87694")
addappid(250408, 1, "19164de4f3ffdcd30d6ef29fb3693425c0c83471f9b89f22566e1c012c737cc5")
addappid(289730, 0, "5784f0e1b805ef8a3928a8c84ab6ec916837907ae8b26c13c4f7ade47672aec9")
