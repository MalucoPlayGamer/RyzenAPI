-- Lua provided by RyzenAPI
-- Game: DRAGON QUEST MONSTERS: The Dark Prince

-- MAIN APPLICATION
addappid(2175540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2175541, 1, "bb34a035fea6b37fef9b6e478eca854e431df2efbe4dfdbb05f78cea963fc4a1")
