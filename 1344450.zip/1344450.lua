-- Lua provided by RyzenAPI 
-- Game: Black Smith2
addappid(1344450)
addappid(1344451, 1, "b83e42d192b96a20250d34f7cb7497f7c09cacd6b1ab56885717e07011f56cee")
