-- Lua provided by RyzenAPI
-- Game: addappid(1344450)

-- MAIN APPLICATION
addappid(1344450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1344451, 1, "b83e42d192b96a20250d34f7cb7497f7c09cacd6b1ab56885717e07011f56cee")
