-- Lua provided by RyzenAPI
-- Game: AppID 893730

-- MAIN APPLICATION
addappid(893730)
-- Game: addappid(893730)

-- MAIN APP DEPOTS / PACKAGES
addappid(893731, 1, "d4a8e3a699c9137f1f4d0d0255960ff8f53f5fcc2dd6aa05b5ef4e8c5418ffa9")
