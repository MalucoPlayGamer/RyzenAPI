-- Lua provided by RyzenAPI
-- Game: 773810

-- MAIN APPLICATION
addappid(773810)
-- Game: addappid(773810)

-- MAIN APP DEPOTS / PACKAGES
addappid(773811, 1, "034598527e0fc81ab1fdd88903624041eecb14fac76c06498ab55890a44a8937")
