-- Lua provided by RyzenAPI
-- Game: addappid(346210)

-- MAIN APPLICATION
addappid(346210)

-- MAIN APP DEPOTS / PACKAGES
addappid(346211, 1, "330b281e9b32bd427668bf755428f32bd03297d4c9b853a62ea6034b47d6a0a7")
