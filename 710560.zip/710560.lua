-- Lua provided by RyzenAPI
-- Game: Ylands Dedicated Server

-- MAIN APPLICATION
addappid(710560)

-- MAIN APP DEPOTS / PACKAGES
addappid(710561, 1, "98936f54463724132885c08f78dbe1c3117522ad36edf4072396f5a3f157b141")

