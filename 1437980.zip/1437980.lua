-- Lua provided by SkyAPI 
-- Game: Cyberforge: First Light
addappid(1437980)
addappid(1437981, 1, "c176aff472970dfe1287e8990123c17d863cee50cc077b071067522f5f1b4796")
addappid(1437982, 1, "5db64579ec4c506d28581885365b2b4f0690abb5d7aa5cfcca5e3cea227c1366")
