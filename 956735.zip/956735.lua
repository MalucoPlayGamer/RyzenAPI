-- Lua provided by RyzenAPI
-- Game: Huang Gai - Officer Ticket / 黄蓋使用券

-- MAIN APPLICATION
addappid(956735)
-- Game: addappid(956735)

-- MAIN APP DEPOTS / PACKAGES
addappid(956735,0,"852d5b1f0a498b712c1b171aff4b70fde0000935f65220817ab384ee1e12c487")
