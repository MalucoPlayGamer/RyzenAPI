-- Lua provided by RyzenAPI
-- Game: Playable Mockup

-- MAIN APPLICATION
addappid(1955390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1955391, 1, "f78d3c6a9948135e143a84f748a62f01e6d15f2365a6eef981ae37c6578d9ec3")
