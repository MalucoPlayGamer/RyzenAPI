-- Lua provided by RyzenAPI
-- Game: Behold Battle

-- MAIN APPLICATION
addappid(2338910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2338911, 1, "5b57ee5da53b6fd3ff554ca326439c065dec8297e1f6c2b9da3c100c104b0679")

