-- Lua provided by RyzenAPI
-- Game: SubwaySim Hamburg

-- MAIN APPLICATION
addappid(1925090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925091, 1, "c6319d7c0b9ce3350afa1110376f4e174c19daceae8ec57a820b4e67d0a85d0d")
addappid(1925093, 1, "7f81b8bd0dd128c1f7357500ec321bc75632ae78b013d23393b33546681db2df")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
