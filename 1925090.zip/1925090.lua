-- Lua provided by RyzenAPI
-- Game: SubwaySim Hamburg

-- MAIN APPLICATION
addappid(1925090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925091, 1, "c6319d7c0b9ce3350afa1110376f4e174c19daceae8ec57a820b4e67d0a85d0d")
addappid(1925093, 1, "7f81b8bd0dd128c1f7357500ec321bc75632ae78b013d23393b33546681db2df")

