-- Lua provided by RyzenAPI
-- Game: addappid(2806640)

-- MAIN APPLICATION
addappid(2806640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2806641, 1, "7608c9835511431b6d95c5aa29bcb269f2cc727e99109c084e19dadb256a25a5")
