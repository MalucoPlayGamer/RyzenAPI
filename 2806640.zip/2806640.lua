-- Lua provided by RyzenAPI
-- Game: The Talos Principle: Reawakened

-- MAIN APPLICATION
addappid(2806640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2806641, 1, "7608c9835511431b6d95c5aa29bcb269f2cc727e99109c084e19dadb256a25a5")

