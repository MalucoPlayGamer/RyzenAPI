-- Lua provided by RyzenAPI
-- Game: Sad Virus Space

-- MAIN APPLICATION
addappid(3773950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3773951, 1, "dfb69209759dbefae73fe0f3943973179538ca7934b068ddf136c3234073c252")
