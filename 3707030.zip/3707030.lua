-- Lua provided by RyzenAPI
-- Game: Game: World of Witchcraft

-- MAIN APPLICATION
addappid(3707030)
-- Game: addappid(3707030)

-- MAIN APP DEPOTS / PACKAGES
addappid(3707031, 1, "f14b3e654456c01c4e4538128dff3c04cb7c896dcd72e62f28eb6eb88e00e06b")
