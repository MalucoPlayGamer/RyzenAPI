-- Lua provided by RyzenAPI
-- Game: Neon Blood

-- MAIN APPLICATION
addappid(2067310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2067311, 1, "250ca541652dc67026fe0060efa93ad7cafce6a026c62aca851a85902771c927")
