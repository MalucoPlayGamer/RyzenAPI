-- Lua provided by RyzenAPI
-- Game: HappyFunLand

-- MAIN APPLICATION
addappid(642910)

-- MAIN APP DEPOTS / PACKAGES
addappid(642911,0,"7a150fa6d7a8893f28da2a000c7c57861e0de7d4bcfba9757bd34f15b2fcd27a")

