-- Lua provided by RyzenAPI
-- Game: HappyFunLand

-- MAIN APPLICATION
addappid(642910)

-- MAIN APP DEPOTS / PACKAGES
addappid(642911,0,"7a150fa6d7a8893f28da2a000c7c57861e0de7d4bcfba9757bd34f15b2fcd27a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
