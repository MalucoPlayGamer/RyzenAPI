-- Lua provided by RyzenAPI
-- Game: Futanari di Funghi

-- MAIN APPLICATION
addappid(2496640)
-- Game: addappid(2496640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2496641, 1, "08d1827584c6748e4bd8e688515e37fceaca278508ab2f3065d6ef25e5e7a74a")
