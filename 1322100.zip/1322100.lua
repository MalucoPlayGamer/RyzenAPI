-- Lua provided by RyzenAPI
-- Game: Battle Bands: Rock & Roll Deckbuilder

-- MAIN APPLICATION
addappid(1322100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1322101, 1, "569c1fae8063122873a54e23cfb988eef3fd490a1507b0cb3f2090bf95d02be7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
