-- Lua provided by RyzenAPI
-- Game: Game: Battle Bands: Rock & Roll Deckbuilder

-- MAIN APPLICATION
addappid(1322100)
-- Game: addappid(1322100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1322101, 1, "569c1fae8063122873a54e23cfb988eef3fd490a1507b0cb3f2090bf95d02be7")
