-- Lua provided by RyzenAPI 
-- Game: DEMON GAZE EXTRA DIGITAL MEMORIAL SOUNDTRACK
addappid(1943270)
addappid(1943271, 1, "ede72808b0fada75799a164def6a3e59879e7d2ace723d9f114eef4760589ead")
