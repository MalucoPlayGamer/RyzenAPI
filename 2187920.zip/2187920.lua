-- Lua provided by RyzenAPI
-- Game: Game: Iron Marines Invasion

-- MAIN APPLICATION
addappid(2187920)
-- Game: addappid(2187920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2187921, 1, "faf1b58bb71b06471b720d7e4f52ae25a860085569fa7dfa4afff29f04e8b4ee")
