-- Lua provided by RyzenAPI
-- Game: LOST INSIDE Act 1

-- MAIN APPLICATION
addappid(1727490)
-- Game: addappid(1727490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727491, 1, "159c2b0eea7aedc2455b696c4bc7ebb8616baec42a29bb5dcb4bddae648de9d2")
