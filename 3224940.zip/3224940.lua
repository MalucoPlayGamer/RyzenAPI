-- Lua provided by RyzenAPI
-- Game: 3224940

-- MAIN APPLICATION
addappid(3224940)
-- Game: addappid(3224940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3224943,0,"406eef4e65111939ba7f0d58bb6bc6c1012eeb0064c952816cda1c3ff93c1e5a")
