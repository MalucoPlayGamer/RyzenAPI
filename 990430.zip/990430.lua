-- Lua provided by RyzenAPI
-- Game: Game: RimWorld Soundtrack

-- MAIN APPLICATION
addappid(990430)
-- Game: addappid(990430)

-- MAIN APP DEPOTS / PACKAGES
addappid(990431, 1, "2174f1eb5c39b7d5a0f00b991fdb1bd690f7ea733d1e8cfdc72a42b5361cae8f")
