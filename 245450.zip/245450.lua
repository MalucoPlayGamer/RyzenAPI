-- Lua provided by RyzenAPI
-- Game: Wizardry 8

-- MAIN APPLICATION
addappid(245450)

-- MAIN APP DEPOTS / PACKAGES
addappid(245451, 1, "a63de9912114334f57ca6393e34220c2d06f246413d4d69b3ec20853a3a65480")
addappid(245452, 1, "cd99a3d294352cfa54190ee3c738abd7a364be7d00a35ba7fe0345d75d088976")
addappid(245453, 1, "524834046aa2ee5c70879faf10e3c19a6697bcf58a7eb9142431879d15c20d22")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
