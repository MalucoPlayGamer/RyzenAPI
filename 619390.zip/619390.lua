-- Lua provided by RyzenAPI
-- Game: Oddworld: Soulstorm Enhanced Edition

-- MAIN APPLICATION
addappid(619390)

-- MAIN APP DEPOTS / PACKAGES
addappid(619391, 1, "76ec6b54bcd304f79e362dd0e6cda4cadc962f1e0ed1a3fec67edd6344d03657")

