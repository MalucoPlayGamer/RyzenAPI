-- Lua provided by RyzenAPI 
-- Game: Kingdom of Wreck Business
addappid(1367040)
addappid(1367041, 1, "0d93e562f074ffb8c16b1548785ff05459d14d986d3cc75967444ce8aec58cf9")
