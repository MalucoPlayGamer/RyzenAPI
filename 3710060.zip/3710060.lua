-- Lua provided by RyzenAPI
-- Game: Game: Escape From Tung Tung Sahur

-- MAIN APPLICATION
addappid(3710060)
-- Game: addappid(3710060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3710061, 1, "cd8480e648b15a40d9f2ad6d492a247daa2261759d09981ffb112a07c9ee9936")
