-- Lua provided by RyzenAPI
-- Game: 650110

-- MAIN APPLICATION
addappid(650110)
addappid(650111)
addappid(650114)
-- Game: addappid(650110)

-- MAIN APP DEPOTS / PACKAGES
addappid(650113,0,"7223b91aef02999a71bb0f2c7e88a4e26ef41a0b758825324d755fc61fc0f491")
addappid(650115,0,"b2eef554181c1528cc1194f1572c45946795afc8025f3926fdc8b6be921e6fa7")
addappid(650116,0,"a36aeecc60a29f14babc8dacd59036bb48476164bb7ea471b556eba92459e269")
