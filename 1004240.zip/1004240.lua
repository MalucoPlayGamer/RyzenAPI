-- Lua provided by RyzenAPI
-- Game: addappid(1004240)

-- MAIN APPLICATION
addappid(1004240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004241, 1, "d25ff0f94c221488f420bb8a7499d500da3ef23b8309b15140b2481f95aae995")
addappid(1004242, 1, "7cc33e8893ed976f88a15f3dbdbde8b1ec10879c105a3fafecdff372f6894007")
