-- Lua provided by RyzenAPI
-- Game: Game: AppID 737330

-- MAIN APPLICATION
addappid(737330)
-- Game: addappid(737330)

-- MAIN APP DEPOTS / PACKAGES
addappid(737331, 1, "247f460e861020cfdf12cf05199a26666f4b1b003eaadb9dc65630e647b436e4")
