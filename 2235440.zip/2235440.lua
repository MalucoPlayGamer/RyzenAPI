-- Lua provided by SkyAPI 
-- Game: My Little Pony: A Zephyr Heights Mystery
addappid(2235440)
addappid(2235441, 1, "06e3207eb84a4af209b1f736777136aa02192a3fb7b75eef3f72ea31ed04d6ee")
