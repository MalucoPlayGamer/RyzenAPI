-- Lua provided by RyzenAPI
-- Game: 2235440

-- MAIN APPLICATION
addappid(2235440)
-- Game: addappid(2235440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2235441, 1, "06e3207eb84a4af209b1f736777136aa02192a3fb7b75eef3f72ea31ed04d6ee")
