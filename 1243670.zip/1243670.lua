-- Lua provided by RyzenAPI
-- Game: AppID 1243670

-- MAIN APPLICATION
addappid(1243670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243671, 1, "395a089690816042035e4b206c627b493398905bd2cad25f1d6021e435d52834")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
