-- Lua provided by RyzenAPI 
-- Game: AppID 1243670
addappid(1243670)
addappid(1243671, 1, "395a089690816042035e4b206c627b493398905bd2cad25f1d6021e435d52834")
