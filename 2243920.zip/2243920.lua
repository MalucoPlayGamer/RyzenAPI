-- Lua provided by RyzenAPI
-- Game: The 2nd page of the medical examination diary: Another story of exciting days of me and my senpai

-- MAIN APPLICATION
addappid(2243920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2243921, 1, "07c82b79fdfa024eda4b10cbe7f6963c4fd1a0630617b399987a29709887997b")

