-- Lua provided by RyzenAPI
-- Game: addappid(2243920)

-- MAIN APPLICATION
addappid(2243920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2243921, 1, "07c82b79fdfa024eda4b10cbe7f6963c4fd1a0630617b399987a29709887997b")
