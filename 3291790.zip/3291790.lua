-- Lua provided by RyzenAPI
-- Game: Durak Online

-- MAIN APPLICATION
addappid(3291790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3291791, 1, "78d9f5efaf38597d375e964c30b2b97ff4e9dfc0aad6791908b6c889ea8430ff")
