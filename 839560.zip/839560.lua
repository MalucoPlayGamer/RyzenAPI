-- Lua provided by RyzenAPI
-- Game: addappid(839560)

-- MAIN APPLICATION
addappid(839560)

-- MAIN APP DEPOTS / PACKAGES
addappid(839561, 1, "34980d51ba14c102e4ccc29559743976557c244fb34c0fa1a994a447ff9739cf")
