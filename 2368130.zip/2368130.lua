-- Lua provided by RyzenAPI
-- Game: Bearskull

-- MAIN APPLICATION
addappid(2368130)
addappid(2410830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2368131, 1, "4a74d94a33cd49ad5d00b59e0adb3e9e28f8d7bc8f8bb33d5c6747bcab2c39fb")

