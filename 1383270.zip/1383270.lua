-- Lua provided by RyzenAPI
-- Game: Pre-Shave

-- MAIN APPLICATION
addappid(1383270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383272,0,"6c65614a698df1db7c8e1bd1e45b6be4dd9ad1fa33e87acb39f0af1a3418998b")

