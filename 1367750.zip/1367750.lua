-- Lua provided by RyzenAPI
-- Game: Target Runner

-- MAIN APPLICATION
addappid(1367750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367751, 1, "13836f923573740ebf7ef0b7ee0b509c56e2bc165af14748b22564307a56fd78")
