-- Lua provided by RyzenAPI
-- Game: Ink Shadow: Zero

-- MAIN APPLICATION
addappid(4282510)
