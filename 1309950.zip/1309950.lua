-- Lua provided by RyzenAPI 
-- Game: Children of the Sun
addappid(1309950)
addappid(1309951, 1, "cf5060130859fe0aa840516e68990b99d214ca28dc248e5edbccee1230ba6db0")
