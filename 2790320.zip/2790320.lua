-- Lua provided by RyzenAPI
-- Game: Măgurele Mystery 2

-- MAIN APPLICATION
addappid(2790320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2790321, 1, "8bb2405ec5891d2b6b569dd80fea11421b32723955e5d45b784d3dcf4004cb3b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
