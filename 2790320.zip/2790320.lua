-- Lua provided by SkyAPI 
-- Game: Măgurele Mystery 2
addappid(2790320)
addappid(2790321, 1, "8bb2405ec5891d2b6b569dd80fea11421b32723955e5d45b784d3dcf4004cb3b")
