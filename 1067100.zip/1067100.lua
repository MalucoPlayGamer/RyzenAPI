-- Lua provided by RyzenAPI
-- Game: Smart Gecko

-- MAIN APPLICATION
addappid(1067100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1067101, 1, "a55c22941f7fdba46b6caa3dfcb2542afb999458138696f8c0201ebdd66508f1")
