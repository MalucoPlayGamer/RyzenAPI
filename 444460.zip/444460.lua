-- Lua provided by RyzenAPI
-- Game: Love is Blind: Mutants

-- MAIN APPLICATION
addappid(444460)

-- MAIN APP DEPOTS / PACKAGES
addappid(444461, 1, "3a1366b0c6f859a40d25043a7ab9f5b958eb4ad24c085eba52451e7a51190e1a")
addappid(444462, 1, "67364f615e019c20d452c87b565ad853a4300f09abb603804586edc366a2ba3f")
