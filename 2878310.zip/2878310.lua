-- Lua provided by RyzenAPI
-- Game: Hidden Pirates Top-Down 3D

-- MAIN APPLICATION
addappid(2878310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878311, 1, "87ea543f021f8966ececcc132620793d3f5fd3a42a092b71058dde38070ca727")

