-- Lua provided by RyzenAPI
-- Game: Deranged

-- MAIN APPLICATION
addappid(1813560)
-- Game: addappid(1813560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813561, 1, "260e750f5a0bceb3c0dc721f5a7af99652913e6d9cddf061c6d40cc454ff200f")
