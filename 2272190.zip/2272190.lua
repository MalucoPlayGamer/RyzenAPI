-- Lua provided by RyzenAPI
-- Game: Kristal Mağara

-- MAIN APPLICATION
addappid(2272190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2272191, 1, "a0f4fc6be9e4d8d43835b6c5575dd4d0302e35032cd58a755afecbff6082adab")

