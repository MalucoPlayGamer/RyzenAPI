-- Lua provided by RyzenAPI
-- Game: addappid(2272190)

-- MAIN APPLICATION
addappid(2272190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2272191, 1, "a0f4fc6be9e4d8d43835b6c5575dd4d0302e35032cd58a755afecbff6082adab")
