-- Lua provided by SkyAPI 
-- Game: Kristal Mağara
addappid(2272190)
addappid(2272191, 1, "a0f4fc6be9e4d8d43835b6c5575dd4d0302e35032cd58a755afecbff6082adab")
