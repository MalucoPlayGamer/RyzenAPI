-- Lua provided by RyzenAPI
-- Game: Resident Evil Re:Verse - Claire Skin: Leather Jacket (Resident Evil Revelations 2)

-- MAIN APPLICATION
addappid(1607019)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607019,0,"f92749ce89026e45400ce9f76694564f90c49db3cfbe6d81bbd322a36a389369")
