-- Lua provided by RyzenAPI
-- Game: Curse of Pirates

-- MAIN APPLICATION
addappid(3484940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3484941,0,"6a46e22525d6b088fabba15f3d258c7c1c9c62907440224e50ab6cdd16e64f6a")

