-- Lua provided by RyzenAPI
-- Game: Atan

-- MAIN APPLICATION
addappid(2707360)
-- Game: addappid(2707360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707361, 1, "4f39c00e6cb1c266d99d2082e5fd2724961da5bffd5bf245bb41c4f1cf1c1d15")
