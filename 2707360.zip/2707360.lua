-- Lua provided by SkyAPI 
-- Game: Atan
addappid(2707360)
addappid(2707361, 1, "4f39c00e6cb1c266d99d2082e5fd2724961da5bffd5bf245bb41c4f1cf1c1d15")
