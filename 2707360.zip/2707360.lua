-- Lua provided by RyzenAPI
-- Game: Atan

-- MAIN APPLICATION
addappid(2707360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2707361, 1, "4f39c00e6cb1c266d99d2082e5fd2724961da5bffd5bf245bb41c4f1cf1c1d15")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
