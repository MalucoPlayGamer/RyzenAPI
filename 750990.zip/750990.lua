-- Lua provided by RyzenAPI
-- Game: Game: AppID 750990

-- MAIN APPLICATION
addappid(750990)
-- Game: addappid(750990)

-- MAIN APP DEPOTS / PACKAGES
addappid(750991, 1, "90be36bd34ef25057681f8caf89d75cbf4f5ccfc6c904dff69abb0372a63d6cc")
addappid(947720, 0, "2b50b8116dd3d0683322f1b994b8b29bacacff19d6096bb6e344df537c9b2552")
