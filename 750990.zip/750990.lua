-- Lua provided by RyzenAPI
-- Game: AppID 750990

-- MAIN APPLICATION
addappid(750990)

-- MAIN APP DEPOTS / PACKAGES
addappid(750991, 1, "90be36bd34ef25057681f8caf89d75cbf4f5ccfc6c904dff69abb0372a63d6cc")
addappid(947720, 0, "2b50b8116dd3d0683322f1b994b8b29bacacff19d6096bb6e344df537c9b2552")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
