-- Lua provided by RyzenAPI
-- Game: Game: Inversion™

-- MAIN APPLICATION
addappid(212410)
-- Game: addappid(212410)

-- MAIN APP DEPOTS / PACKAGES
addappid(212411, 1, "0599c802622097a28f5524cd2b4140ca52adb8b991d98d83c2e4b76a066ede3f")
addappid(212412, 1, "e94f44d625bc74a50a2f75cb4feb6a8876cc39630ea3d088b02523770e7efcca")
addappid(212413, 1, "95f93e00678ebb8751216aee198b2aa59f7af63a1c57339ca4b5162e33b2a1a5")
addappid(212414, 1, "b7d1870859469d8d219d4fdfc6c42a21fef23aefe49eda0ef866c9b6f3de29e5")
addappid(212415, 1, "298d2cb3719fb40d227c776a62e1c328702e831e9e5cb07d08a8bdc1a35f4ba8")
addappid(212416, 1, "c87a1960c35476ec09c56adf556cddf86a5e3c330444a8e9f1970e708c5904d6")
