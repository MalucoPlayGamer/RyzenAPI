-- Lua provided by RyzenAPI
-- Game: Runa Illustra

-- MAIN APPLICATION
addappid(2854360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2854361, 1, "fd4f87779e04e8fe198f42557aa78e7e1029233155933c2be9a9fa49d0305009")

