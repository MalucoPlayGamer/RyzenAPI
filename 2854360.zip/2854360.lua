-- Lua provided by RyzenAPI
-- Game: Runa Illustra

-- MAIN APPLICATION
addappid(2854360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2854361, 1, "fd4f87779e04e8fe198f42557aa78e7e1029233155933c2be9a9fa49d0305009")

