-- Lua provided by RyzenAPI
-- Game: Game: Silver Screen Story

-- MAIN APPLICATION
addappid(2101290)
-- Game: addappid(2101290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2101291, 1, "d19970a28b1724c943c5c15bdfb8030f94d2219cdc4db51152f16f3250e16155")
