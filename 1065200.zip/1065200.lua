-- Lua provided by RyzenAPI
-- Game: Game: Visitor2 / 来访者2

-- MAIN APPLICATION
addappid(1065200)
-- Game: addappid(1065200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1065201, 1, "421d88158392f57bd1671069eea49e2028cde5eaf0188624163932ae85546342")
