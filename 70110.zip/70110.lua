-- Lua provided by SkyAPI 
-- Game: Hacker Evolution: Untold
addappid(70110)
addappid(70111, 1, "347e7a5a5aeec0e143fcd37e8fcd6f8df1cf214908279a26a923985ecd15d225")
addappid(70112, 1, "97e157504a311e48811b2a6b1f1286218e6f8689f7a93a131e374d13ff7edc96")
addappid(70113, 1, "9ab1cfff3e3791f1bac91a697a5201f4b6e84f862670d9f591fd302999e59537")
addappid(250230)
addappid(259240)
addappid(279830)
