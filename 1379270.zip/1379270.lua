-- Lua provided by RyzenAPI
-- Game: addappid(1379270)

-- MAIN APPLICATION
addappid(1379270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379272,0,"6c4088899a399b7deefad1194e93a4199b3fd0e2eb39dff1d0dbfebaad53793a")
