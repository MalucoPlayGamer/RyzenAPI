-- Lua provided by RyzenAPI
-- Game: Stop Dead Demo

-- MAIN APPLICATION
addappid(2386830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386831, 1, "504d6e142885f5b0c346005e401ee200cb94b2e17bcfc152c52c255e553e85b1")

