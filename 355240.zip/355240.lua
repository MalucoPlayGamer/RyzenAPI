-- Lua provided by RyzenAPI
-- Game: NEO AQUARIUM - The King of Crustaceans -

-- MAIN APPLICATION
addappid(355240)
-- Game: addappid(355240)

-- MAIN APP DEPOTS / PACKAGES
addappid(355241, 1, "5fa535f272628bb405bcf5fdb1309557b87cc84d99906a374daa7a64e7fb1019")
addappid(355242, 1, "8dbe98779d4fa903846d7ec8e76753f246840cb95fb0dec165f2a472ba87893a")
