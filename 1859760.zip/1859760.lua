-- Lua provided by RyzenAPI 
-- Game: Elf Wives Cheat to Ride my Meat
addappid(1859760)
addappid(1859761, 1, "d5d239ed3d183b583372048f65cceecf0d31a6977549e3fac1bfd7a1040b678d")
