-- Lua provided by RyzenAPI
-- Game: Elf Wives Cheat to Ride my Meat

-- MAIN APPLICATION
addappid(1859760)
-- Game: addappid(1859760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859761, 1, "d5d239ed3d183b583372048f65cceecf0d31a6977549e3fac1bfd7a1040b678d")
