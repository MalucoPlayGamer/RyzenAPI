-- Lua provided by RyzenAPI
-- Game: Catto Boi Collection

-- MAIN APPLICATION
addappid(3955550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3955551,0,"a977c6c6740aa627bb4d55a61c926bd7973bb2613ff3e027c669d8e51847e4bc")

