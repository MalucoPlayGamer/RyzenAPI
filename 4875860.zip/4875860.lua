-- Lua provided by RyzenAPI
-- Game: ECHOES

-- MAIN APPLICATION
addappid(4875860)
