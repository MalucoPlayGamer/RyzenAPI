-- Lua provided by RyzenAPI
-- Game: Blues and Bullets - Digital Comic

-- MAIN APPLICATION
addappid(389970)

-- MAIN APP DEPOTS / PACKAGES
addappid(389971, 1, "d5be3720eddb92ce601bbcbc4020aeb4974b28312729c11072af5ad4214a67d3")

