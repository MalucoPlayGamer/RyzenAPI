-- Lua provided by RyzenAPI
-- Game: AppID 431850

-- MAIN APPLICATION
addappid(431850)

-- MAIN APP DEPOTS / PACKAGES
addappid(431851, 1, "142023f241a7efbac111ee635cabd94f73064e764cd7f77647b2f5b30a68a9e1")

