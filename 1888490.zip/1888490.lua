-- Lua provided by RyzenAPI
-- Game: Tremblay Island

-- MAIN APPLICATION
addappid(1888490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888491, 1, "ff33d3b11ca117412feef033aa09a0ea5177cf8054cc97ed25061530c2849078")

