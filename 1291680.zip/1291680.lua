-- Lua provided by RyzenAPI
-- Game: Apocalypse: 2.0 Edition

-- MAIN APPLICATION
addappid(1291680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291681, 1, "a622ebb9241cfaade1842a34c56ae2a16db79835662dfb8be1f90f52bc36ef39")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
