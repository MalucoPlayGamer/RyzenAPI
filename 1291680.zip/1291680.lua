-- Lua provided by RyzenAPI
-- Game: Apocalypse: 2.0 Edition

-- MAIN APPLICATION
addappid(1291680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291681, 1, "a622ebb9241cfaade1842a34c56ae2a16db79835662dfb8be1f90f52bc36ef39")
