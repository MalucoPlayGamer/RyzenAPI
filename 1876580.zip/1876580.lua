-- Lua provided by RyzenAPI
-- Game: Risen Soundtrack

-- MAIN APPLICATION
addappid(1876580)
-- Game: addappid(1876580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876581, 1, "c565f9c257cfe9d2a698b6743496b12df70abde11c870f7c1fc0fa2a2e0a910b")
addappid(1876582, 1, "90b4f85a4588dabc9eb21a378b563aaf41471b85bd1735605b1e01c5b639a053")
