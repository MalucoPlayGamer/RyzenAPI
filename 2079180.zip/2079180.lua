-- Lua provided by RyzenAPI
-- Game: VIDEOVERSE

-- MAIN APPLICATION
addappid(2079180)
-- Game: addappid(2079180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2079181, 1, "b913a04495ecd4ae0688b8e1a38adf6f2700c20b5933708d016f42ae7b1ce065")
