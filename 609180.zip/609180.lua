-- Lua provided by RyzenAPI
-- Game: Hotel 19-95

-- MAIN APPLICATION
addappid(609180)

-- MAIN APP DEPOTS / PACKAGES
addappid(609181, 1, "0c5a2bfa5310b28c3e98beeef6bee5c94af821771e205c5dce987e62311a444f")
