-- Lua provided by RyzenAPI
-- Game: Sniper Ghost Warrior 3 Original Soundtrack

-- MAIN APPLICATION
addappid(659971)
-- Game: addappid(659971)

-- MAIN APP DEPOTS / PACKAGES
addappid(1229620,0,"0c73fb7a4d10e51372cf394d917748b7397a9d904a1d482b9e0472918be1a1fa")
addappid(1229621,0,"ac6a312c7404f80d8912fd3e9cf7f7ca4c8090635c23a70a88d97f2cd457b311")
