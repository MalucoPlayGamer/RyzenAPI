-- Lua provided by RyzenAPI
-- Game: addappid(1712650)

-- MAIN APPLICATION
addappid(1712650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1712651, 1, "d229ecda10c60cdd6e9205439508c8a90535fecf5fd5c4a242260c6bc025b2fb")
