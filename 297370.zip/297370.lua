-- Lua provided by RyzenAPI
-- Game: Hero of Many

-- MAIN APPLICATION
addappid(297370)
-- Game: addappid(297370)

-- MAIN APP DEPOTS / PACKAGES
addappid(297371, 1, "7ad10de93762c115d657eec76093b4873172b871709cf3a7b8b9f92372fa8472")
addappid(297373, 1, "8bc1686897f774bf4bbb5ccd091a601738525c8eeeff04eda48a5ac372d5ecf8")
addappid(318640, 0, "f58a3978cb43d56cbcb9f41e399eb2219d3185dd5164f517dd614c791ba592cc")
