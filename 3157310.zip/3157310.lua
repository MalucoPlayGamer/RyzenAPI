-- Lua provided by RyzenAPI
-- Game: Tales of the Forgotten

-- MAIN APPLICATION
addappid(3157310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3157311, 1, "ee51f95840fc3d144478d505d8c9d6a346bdb9cbf9d32a54acae7b42b567d6dc")

