-- Lua provided by RyzenAPI
-- Game: addappid(1824580)

-- MAIN APPLICATION
addappid(1824580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824581, 1, "b82852173fa8a9a1f47faa23ff0e0abb2ec174b72447142e96c5f9c396a9a5dd")
addappid(1824583, 1, "f72539d748d7c236418a1e8bc140c5420575d0ab2dfeb75fb2de7d7ba27cab91")
