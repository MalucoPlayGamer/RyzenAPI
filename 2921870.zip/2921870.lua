-- Lua provided by RyzenAPI
-- Game: PacaPomo

-- MAIN APPLICATION
addappid(2921870)
