-- Lua provided by RyzenAPI
-- Game: Pigeon Fight

-- MAIN APPLICATION
addappid(520370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(520371, 1, "6e011f85c901ee783fb9c554bed1cb682af00c01d7f7c11d6cf73e7c9756e7d5")

