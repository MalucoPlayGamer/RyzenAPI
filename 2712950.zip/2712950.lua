-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2712950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2712950,0,"e87c2fd0103b135d75ea1e7ab9961328a7d9bdd04bc07c98c60539ac490017fb")
