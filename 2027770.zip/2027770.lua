-- Lua provided by RyzenAPI
-- Game: Game: Spikair Volleyball Demo

-- MAIN APPLICATION
addappid(2027770)
-- Game: addappid(2027770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027771, 1, "1bd24e97d191367b728b9b6f818fd21ec333f3604c0289a8d0351d0c9e9c0a01")
