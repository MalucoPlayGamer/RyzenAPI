-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Global Scenery: Asia

-- MAIN APPLICATION
addappid(2126104)

-- MAIN APP DEPOTS / PACKAGES
addappid(2126104,0,"b3a749cde58bf9259f02cb4bd01e1f99340d3f6fb518e84d8df124ff93d648d9")
