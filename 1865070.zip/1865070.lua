-- Lua provided by RyzenAPI
-- Game: Game: THE GREAT CIRCLE Demo

-- MAIN APPLICATION
addappid(1865070)
-- Game: addappid(1865070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1865071, 1, "a09a808bfac698263a7a1db107933e8eab446b713e834d8e4510e313fdc2c8ee")
