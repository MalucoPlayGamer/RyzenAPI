-- Lua provided by RyzenAPI
-- Game: Secret Love Temple

-- MAIN APPLICATION
addappid(3563430)
-- Game: addappid(3563430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3563431, 1, "92a99142e1d266b99dd07149e5538d9c3f933dd393575229aa713810c63dd06f")
