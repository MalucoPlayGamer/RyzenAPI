-- Lua provided by RyzenAPI 
-- Game: Game of Thrones: Kingsroad
addappid(3183280)
addappid(3183281, 1, "68dce48db7977a0ea03b654ede2a578765ee4320c93955e29aeae0ef9bb43c9e")
addappid(3183282, 1, "7fda33f42919c3fececa548528f54b0514a220b324f6a87377d20f63a8d7982f")
addappid(3477690, 0, "09ad1044265abc607d130258e11d192531c0471b4755edbe711911048d6bd94f")
