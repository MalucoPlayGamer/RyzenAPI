-- Lua provided by RyzenAPI
-- Game: Divinity: Original Sin Enhanced Edition - Official Soundtrack

-- MAIN APPLICATION
addappid(409552)

-- MAIN APP DEPOTS / PACKAGES
addappid(409552,0,"789ee47c2c4cc60597d07013f258f5daef67124617b009dbd45e44977bf3f505")
