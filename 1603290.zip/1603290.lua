-- Lua provided by RyzenAPI
-- Game: Project Hacker

-- MAIN APPLICATION
addappid(1603290)
-- Game: addappid(1603290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1603291, 1, "e0ae8612b9693c2682c8be182495188970de4e7bae4293e92c74f45f04844892")
