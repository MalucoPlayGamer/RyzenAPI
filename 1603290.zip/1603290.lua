-- Lua provided by RyzenAPI
-- Game: Project Hacker

-- MAIN APPLICATION
addappid(1603290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1603291, 1, "e0ae8612b9693c2682c8be182495188970de4e7bae4293e92c74f45f04844892")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
