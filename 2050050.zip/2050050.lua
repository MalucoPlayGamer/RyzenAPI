-- Lua provided by RyzenAPI
-- Game: Rift Loopers

-- MAIN APPLICATION
addappid(2050050)
-- Game: addappid(2050050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050051, 1, "090139d70d82ef15136f66a2088654ccb9bfe23a404799329f1585558ab96c6a")
