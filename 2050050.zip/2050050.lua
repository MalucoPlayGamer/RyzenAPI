-- Lua provided by RyzenAPI
-- Game: Rift Loopers

-- MAIN APPLICATION
addappid(2050050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2050051, 1, "090139d70d82ef15136f66a2088654ccb9bfe23a404799329f1585558ab96c6a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2376900)
addappid(2435420)
