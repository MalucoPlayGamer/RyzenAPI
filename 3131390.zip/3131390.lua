-- Lua provided by RyzenAPI
-- Game: Arco - Original Soundtrack

-- MAIN APPLICATION
addappid(3131390)
-- Game: addappid(3131390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3131391, 1, "9f6a639826ba6bdef89b9a8b14a21def30ed5e7223c3d224c74770ec1142b797")
addappid(3131392, 1, "c3174cd81f81bf41f6916b3c11996637ea828a749d30ee5dae4146e912f2445e")
