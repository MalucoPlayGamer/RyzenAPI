-- Lua provided by RyzenAPI
-- Game: Paint the Town Red Demo

-- MAIN APPLICATION
addappid(1676650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1676651, 1, "0b2c6e58bf9892b484caf8dbd4009a1cb2e989e9a306307fc03100e375838a9c")

