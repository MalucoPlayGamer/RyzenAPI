-- Lua provided by RyzenAPI
-- Game: Undying - Original Soundtrack

-- MAIN APPLICATION
addappid(2260070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2260071, 1, "8813dc9c880f6b96c80f71754aeba9d0af1dc45d18ed1c3ed585ecb46426f626")
addappid(2260072, 1, "db2b85a6d7e6114a7821e490dc653df413c8441c7b02c34bbc3dd16cc18d3a7c")

