-- Lua provided by RyzenAPI
-- Game: addappid(2884070)

-- MAIN APPLICATION
addappid(2884070)
addappid(4019100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2884071, 1, "9b9205fd9150b7870a22cdb5b5a64399158f49e445683a845acd3b1034b2d8fd")
