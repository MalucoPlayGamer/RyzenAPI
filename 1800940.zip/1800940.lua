-- Lua provided by RyzenAPI
-- Game: The Enjenir: The Engineering Physics Building Simulator

-- MAIN APPLICATION
addappid(1800940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1800941, 1, "b4c278ce077bc280eb7a8aa35aeda21f50ba0bb7529e41e7d72d5e0f749002f9")

