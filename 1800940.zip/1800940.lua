-- Lua provided by RyzenAPI
-- Game: 1800940

-- MAIN APPLICATION
addappid(1800940)
-- Game: addappid(1800940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1800941, 1, "b4c278ce077bc280eb7a8aa35aeda21f50ba0bb7529e41e7d72d5e0f749002f9")
