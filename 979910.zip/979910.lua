-- Lua provided by RyzenAPI
-- Game: AppID 979910

-- MAIN APPLICATION
addappid(979910)

-- MAIN APP DEPOTS / PACKAGES
addappid(979911, 1, "417b325cade534cc3a5186354fecc60027c9cd4fe39d6c1f05db8b5f91fa7a94")

