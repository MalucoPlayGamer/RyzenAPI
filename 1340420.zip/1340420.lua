-- Lua provided by RyzenAPI 
-- Game: Slime Up
addappid(1340420)
addappid(1340421, 1, "993790b4a68397dee8d233ee4e5ce656ce2b5a99d34018801e50f3b90e89ebd7")
