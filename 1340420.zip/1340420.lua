-- Lua provided by RyzenAPI
-- Game: 1340420

-- MAIN APPLICATION
addappid(1340420)
-- Game: addappid(1340420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340421, 1, "993790b4a68397dee8d233ee4e5ce656ce2b5a99d34018801e50f3b90e89ebd7")
