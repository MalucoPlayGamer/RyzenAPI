-- Lua provided by RyzenAPI
-- Game: Frostpunk 2

-- MAIN APPLICATION
addappid(1601580)
addappid(2791510)
addappid(4065430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1601581, 1, "7372485e88b89813dc5250dca3be72fcfa499604514bea173703fbb7bac1f78f")
addappid(1601582, 1, "430c4ff745d427259e5934cada320f38cfadad961bdb56a35f4403f2ffeaea6b")
addappid(1601583, 1, "be06bc27eb3b8e788a06bae787211c5e406cf846a3aeceffbac54475a447d036")
addappid(2791490, 0, "3f4b6f54645a56bc7991b93bed90155b81354f90e7fb4113e92ed9378980e36c")
addappid(2791500, 0, "647f22682ffa05f21b1ea12779b04414782ddf4f2456565761b6ee0f863204ee")

