-- Lua provided by RyzenAPI
-- Game: Shield Operator

-- MAIN APPLICATION
addappid(4929650) -- Shield Operator

-- MAIN APP DEPOTS / PACKAGES
addappid(4929651, 1, "22725b6a817b7dc7443f209bfa38588b9dfe342e04b78756f4dd8cf6bfb03c1c") -- Depot 4929651

