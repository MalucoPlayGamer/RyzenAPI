-- Lua provided by SkyAPI 
-- Game: Million Arthur: Arcana Blood
addappid(989550)
addappid(989551, 1, "5c95bb31ef1374483f436a7728adf86dac9dc80f609c77df6cdc765f43be2a5b")
