-- Lua provided by RyzenAPI
-- Game: Million Arthur: Arcana Blood

-- MAIN APPLICATION
addappid(989550)
addappid(1104130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(989551, 1, "5c95bb31ef1374483f436a7728adf86dac9dc80f609c77df6cdc765f43be2a5b")

