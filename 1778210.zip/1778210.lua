-- Lua provided by RyzenAPI
-- Game: Game: King Boo

-- MAIN APPLICATION
addappid(1778210)
-- Game: addappid(1778210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1778211, 1, "c36d0369d34abbfd5523e157abee45551c68034c13f000101d69b033a33edc24")
