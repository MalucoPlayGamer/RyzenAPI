-- Lua provided by RyzenAPI
-- Game: TechnoTsunami

-- MAIN APPLICATION
addappid(1240460)
-- Game: addappid(1240460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240461, 1, "1a04dd78fa82699d65cba1933404bb688206b6adaceb029d16eef850d4b709b6")
