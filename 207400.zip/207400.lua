-- Lua provided by RyzenAPI
-- Game: addappid(207400)

-- MAIN APPLICATION
addappid(207400)

-- MAIN APP DEPOTS / PACKAGES
addappid(207401, 1, "234d8fb7055dbf1a0ba9fd7ee3205830090297659236fc22feee6a256b227810")
addappid(334530, 0, "5436ca53938d624a0d5eafa7c7bb7edcf17ced65abd5280dc876a456e9b81ef6")
