-- Lua provided by SkyAPI 
-- Game: eXceed 3rd - Jade Penetrate Black Package
addappid(207400)
addappid(207401, 1, "234d8fb7055dbf1a0ba9fd7ee3205830090297659236fc22feee6a256b227810")
addappid(334530, 0, "5436ca53938d624a0d5eafa7c7bb7edcf17ced65abd5280dc876a456e9b81ef6")
