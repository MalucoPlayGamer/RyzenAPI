-- Lua provided by RyzenAPI
-- Game: Cross Blitz - Original Soundtrack

-- MAIN APPLICATION
addappid(2677440)
-- Game: addappid(2677440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2677441, 1, "d45ea88779b20a6309c4a69514853da62e9865297eb4ead7ca258d4f6b1df771")
addappid(2677442, 1, "f42068ed6b4c832855a6b1e4c7184058f6b4c332f221fc7c9960a6b01444b11b")
