-- Lua provided by RyzenAPI
-- Game: Sceelix - Procedural Power

-- MAIN APPLICATION
addappid(509020)

-- MAIN APP DEPOTS / PACKAGES
addappid(509021, 1, "48a289ff6884d4c49411c659c6d7c6d1519ae669af46cec88613adda0e05d486")
addappid(509022, 1, "ea546f2cb6e793caedad840cec1fcdbb5b24c1cdb7a5de1ab6d43bbc917153cb")
addappid(509023, 1, "3b952e4895368b1b1d693313d80bdbc46a7111368fa8539e5b3bf62e7d3dacbc")
addappid(509024, 1, "a4796720d341565cda3f94e31dbadb1e8116b9de9e27a033f723ea0040bdd031")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
