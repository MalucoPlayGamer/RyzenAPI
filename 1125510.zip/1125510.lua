-- Lua provided by RyzenAPI 
-- Game: Snacko
addappid(1125510)
addappid(1125511, 1, "721d6be4d8d35b2d2a878f4c0c9fd8514bf8db80e1666a1c27484fccb4767d2b")
