-- Lua provided by SkyAPI 
-- Game: Westwood Shadows: Prologue
addappid(1717810)
addappid(1717811, 1, "92abab40d4ae076d58a025bf125acb1dd4beb62d70431a62f8237dd6706d697d")
