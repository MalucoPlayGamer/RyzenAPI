-- Lua provided by RyzenAPI
-- Game: Game: Westwood Shadows: Prologue

-- MAIN APPLICATION
addappid(1717810)
-- Game: addappid(1717810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717811, 1, "92abab40d4ae076d58a025bf125acb1dd4beb62d70431a62f8237dd6706d697d")
