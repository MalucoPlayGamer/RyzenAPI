-- Lua provided by SkyAPI 
-- Game: Trainz Railroad Simulator 2022
addappid(1784570)
addappid(1784571, 1, "134fdb5ee9afedbedea81a6af4a0dc4afe43e2ca1f83e04205b338b5c0d4dc44")
addappid(1784572, 1, "4bbf4e4bfac1fe6314ef4c41571ed922d6546dc548c96a7e61bfca6711050512")
