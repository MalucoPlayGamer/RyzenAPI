-- Lua provided by RyzenAPI
-- Game: Titan Quest Anniversary Edition

-- MAIN APPLICATION
addappid(475150)

-- MAIN APP DEPOTS / PACKAGES
addappid(475151, 1, "c1c3edb704d43929929fa371f6e02864b265e7d85a33430f789a2e6a4d6869f8")
addappid(475152, 1, "aa44d00ff5b62b6c416f4ce7b9fc8fb3247c35edc0c67f4284effe5cebc9fbb7")
addappid(741350, 0, "58951f90a73c082db0d47f5b217fd4026c5b6bb5a21a0e537bd069e5d7078d26")
addappid(760270, 0, "cc33840e6436454777bf485a4bc8807cd79883b8ec34d72d814704e68ba07c5e")
addappid(1071200, 0, "05f1bf6799fc248979458614b61b543dedb3bb085232409f294c70210e5c61e1")
addappid(1804460, 0, "0088e414403d323b326c3335d3467cc5d112baa680f869d978a08853f0b0d7d7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
