-- Lua provided by RyzenAPI
-- Game: Orcs Must Die! Deathtrap

-- MAIN APPLICATION
addappid(2273980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2273981, 1, "179ec5c394c5940b45918894a57184084765edbab18b181584b305b0e9d917a7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3291710)
