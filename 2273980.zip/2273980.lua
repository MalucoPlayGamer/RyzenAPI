-- Lua provided by SkyAPI 
-- Game: Orcs Must Die! Deathtrap
addappid(2273980)
addappid(2273981, 1, "179ec5c394c5940b45918894a57184084765edbab18b181584b305b0e9d917a7")
