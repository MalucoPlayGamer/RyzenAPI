-- Lua provided by RyzenAPI 
-- Game: Space Squadron
addappid(1450200)
addappid(1450201, 1, "18448981ea1834b2590e223c82c8faeea22ca9fb1f1e99c753d53e6cc47d758e")
