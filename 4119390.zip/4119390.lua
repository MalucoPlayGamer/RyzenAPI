-- Lua provided by RyzenAPI
-- Game: Futanari have a heart too

-- MAIN APPLICATION
addappid(4119390)

-- MAIN APP DEPOTS / PACKAGES
addappid(4119391,0,"407fb7ffe6953b85d9bd11369d8d19bd9c962de2c8e787bae63aa4f58383069f")

