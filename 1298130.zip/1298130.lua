-- Lua provided by RyzenAPI
-- Game: AppID 1298130

-- MAIN APPLICATION
addappid(1298130)
-- Game: addappid(1298130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1298131, 1, "5f4c69daac0547a7bfc6017f89bb5861cab43d9a3563efe0702d617f9573dd24")
