-- Lua provided by SkyAPI 
-- Game: AppID 1298130
addappid(1298130)
addappid(1298131, 1, "5f4c69daac0547a7bfc6017f89bb5861cab43d9a3563efe0702d617f9573dd24")
