-- Lua provided by RyzenAPI
-- Game: AppID 1298130

-- MAIN APPLICATION
addappid(1298130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1298131, 1, "5f4c69daac0547a7bfc6017f89bb5861cab43d9a3563efe0702d617f9573dd24")

