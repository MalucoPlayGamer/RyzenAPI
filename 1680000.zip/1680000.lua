-- Lua provided by RyzenAPI 
-- Game: Rewrite+
addappid(1680000)
addappid(1680001, 1, "e009ba86a684927aee3716d3437309765040f05514e72f7329f91592c1ae015d")
addappid(1680002, 1, "f4525e02fbf324a3fac3c71d5f2e7d61afabcd923d65314bfe5a3cc8ced81a33")
