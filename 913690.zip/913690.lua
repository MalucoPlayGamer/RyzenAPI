-- Lua provided by RyzenAPI
-- Game: AppID 913690

-- MAIN APPLICATION
addappid(913690)

-- MAIN APP DEPOTS / PACKAGES
addappid(913691, 1, "a13496b274b240a6cdb7e6d950a9f2652e3e9bba33f6e26892d55b97eeb817b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
