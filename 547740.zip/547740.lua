-- Lua provided by RyzenAPI
-- Game: Across

-- MAIN APPLICATION
addappid(547740)

-- MAIN APP DEPOTS / PACKAGES
addappid(547741,0,"1f3d1e757422f35ee263f9bf9a81ebc5feaaa4ec5c26dae1e1bb5fe4d900589f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
