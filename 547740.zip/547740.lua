-- Lua provided by RyzenAPI
-- Game: Across

-- MAIN APPLICATION
addappid(547740)

-- MAIN APP DEPOTS / PACKAGES
addappid(547741,0,"1f3d1e757422f35ee263f9bf9a81ebc5feaaa4ec5c26dae1e1bb5fe4d900589f")

