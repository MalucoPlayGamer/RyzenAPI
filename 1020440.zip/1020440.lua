-- Lua provided by RyzenAPI
-- Game: Doodle Creatures

-- MAIN APPLICATION
addappid(1020440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1020441, 1, "45604e0e895548cb8c0f731ea577d20513837ee86d58ab5bd6700e0080f26195")
addappid(1020442, 1, "13579f13d517f0728c504277015aaca96eb27a559e6951b4ca3d8215fc7f55a9")

