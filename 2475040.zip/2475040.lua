-- Lua provided by RyzenAPI
-- Game: addappid(2475040)

-- MAIN APPLICATION
addappid(2475040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475041, 1, "7c995ab124aade52717a87ffc7682731449c5546d4922ebcba6232b6d0d92a99")
