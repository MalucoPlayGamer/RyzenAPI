-- Lua provided by RyzenAPI
-- Game: Jelly in the sky

-- MAIN APPLICATION
addappid(593530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(593531, 1, "41b2d149e8b0af8c8fa1e0ac351078bd4f5ffece221caa10658558f190cb3fa2")
addappid(593532, 1, "6725ee3a3dde6cdef8ffd49ee5ef0adedc728fe8d107eb5d8f24354e6fd567c0")

