-- Lua provided by RyzenAPI
-- Game: Game: Jelly in the sky

-- MAIN APPLICATION
addappid(593530)
-- Game: addappid(593530)

-- MAIN APP DEPOTS / PACKAGES
addappid(593531, 1, "41b2d149e8b0af8c8fa1e0ac351078bd4f5ffece221caa10658558f190cb3fa2")
addappid(593532, 1, "6725ee3a3dde6cdef8ffd49ee5ef0adedc728fe8d107eb5d8f24354e6fd567c0")
