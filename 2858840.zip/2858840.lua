-- Lua provided by RyzenAPI
-- Game: addappid(2858840)

-- MAIN APPLICATION
addappid(2858840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2858842,0,"1244d31eb74d65917d75ee9bb895ebb077c17c7edee75ee99ee1dd187804688b")
addappid(2858843,0,"ec86b8bf55c01a3b24960108bf885ee054dc67905fc37dc45da59f78d7adda79")
