-- Lua provided by RyzenAPI
-- Game: The Art of Trailmakers

-- MAIN APPLICATION
addappid(3275860)
-- Game: addappid(3275860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3275860,0,"92541d123b724326f3491f00d06a06ad9cc4c16d90bb42156c8140c43b238d6c")
