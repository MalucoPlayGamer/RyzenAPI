-- Lua provided by RyzenAPI
-- Game: The Travels of Marco Polo

-- MAIN APPLICATION
addappid(366670)

-- MAIN APP DEPOTS / PACKAGES
addappid(366671, 1, "2342df513e528f02cca9c95b98098c0decd7f7005d8d0ea45872202ed7a6a3bd")
addappid(366672, 1, "75bbbf9f0316ef3293b9b76dc4c3b0988ffa2f74206db0ceca9b2ad52978c3c2")
addappid(366673, 1, "e8b0a5b5abbf8336350a7461396573f8e773d20773058c1086c033aed55d3cdb")
addappid(366674, 1, "311a92fce1d2d32a71cc22c6b549d695aa0c8fe4ac2f94236fb6ef96ca4cdfb8")
addappid(366675, 1, "231972599739759a8c751d52c20a99d80621d4cc764b0a1169c33fb3aaa72b91")

