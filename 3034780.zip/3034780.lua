-- Lua provided by RyzenAPI
-- Game: addappid(3034780)

-- MAIN APPLICATION
addappid(3034780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3034781, 1, "23c296885019bd4b62bf533effdc149c6043b1f14bdd887845f6d596ea0b2e20")
