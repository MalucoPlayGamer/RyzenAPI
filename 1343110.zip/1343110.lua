-- Lua provided by RyzenAPI
-- Game: 1343110

-- MAIN APPLICATION
addappid(1343110)
-- Game: addappid(1343110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1343111, 1, "71a1456283258b459504e95b1daa4652a62ddf53a89f9e9e18a0568b8d176dce")
