-- Lua provided by RyzenAPI
-- Game: 3228180

-- MAIN APPLICATION
addappid(3228180)
-- Game: addappid(3228180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3228181, 1, "bfdbd64a77edbb619c3b3122f2c9002d6f542b240425b3563aa93e2d0e74235e")
