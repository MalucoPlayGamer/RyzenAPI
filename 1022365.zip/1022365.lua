-- Lua provided by RyzenAPI
-- Game: DFF NT: Cardinal, Rinoa Heartilly's 4th Weapon

-- MAIN APPLICATION
addappid(1022365)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022365,0,"9f4ccd0026127ecd824743629b28c8d41059ccb22584c4375f0b363c9d9e12ad")
