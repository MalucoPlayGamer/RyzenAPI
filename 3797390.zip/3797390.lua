-- Lua provided by RyzenAPI
-- Game: addappid(3797390)

-- MAIN APPLICATION
addappid(3797390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3797391, 1, "bbac2053187a142ec3e3c74a08cba8c504ab0d77c31fc1c136833ee6e72e7776")
