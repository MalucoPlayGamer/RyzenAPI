-- Lua provided by RyzenAPI
-- Game: Xenowars

-- MAIN APPLICATION
addappid(2920380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2920381, 1, "a64bc3d0ea406b175c0f083c39a808f35b84a3f5650d1817491a7ff168f1c031")
