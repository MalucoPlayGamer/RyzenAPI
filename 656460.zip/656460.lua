-- Lua provided by SkyAPI 
-- Game: Vostok Inc.
addappid(656460)
addappid(656461, 1, "2025f881a314cb49a111754e494dece5179a163f8bc53e23f049aa3acab142bd")
addappid(656464, 1, "4c43c16ce1dcc08c026fa26ec5fada72f1c2265d28a63feec7041d609799b656")
