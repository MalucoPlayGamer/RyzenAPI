-- Lua provided by RyzenAPI
-- Game: Nomads of Driftland

-- MAIN APPLICATION
addappid(1400520)
addappid(1436970)
-- Game: addappid(1400520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1400521, 1, "f5c0bf0129b98e3c93229c9c3746cc502e60b1b84b3aff7b7d63e3918468f10a")
