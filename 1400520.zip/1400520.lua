-- Lua provided by RyzenAPI
-- Game: Nomads of Driftland

-- MAIN APPLICATION
addappid(1400520)
addappid(1436970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1400521, 1, "f5c0bf0129b98e3c93229c9c3746cc502e60b1b84b3aff7b7d63e3918468f10a")

