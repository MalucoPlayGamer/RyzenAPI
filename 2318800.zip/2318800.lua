-- Lua provided by RyzenAPI
-- Game: addappid(2318800)

-- MAIN APPLICATION
addappid(2318800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318801, 1, "3609758854aae9b17908bcaa3a4d0f15f4f1a87325039c5e2f9736cf9e8ab85c")
