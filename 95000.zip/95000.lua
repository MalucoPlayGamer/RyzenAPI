-- Lua provided by RyzenAPI
-- Game: Game: Super Splatters

-- MAIN APPLICATION
addappid(95000)
-- Game: addappid(95000)

-- MAIN APP DEPOTS / PACKAGES
addappid(95001, 1, "21f51eadfca4cbd76526e37e7321f0d9598aeb80f339de71b87b1d7266be3572")
addappid(95002, 1, "67fcaad425150dc24360bcbdb0135efdd34a5c96e5896ccaba19b5d67b7e6bb1")
addappid(95003, 1, "85d5b3b39249386fdf8d0fc9870bdbd4b0e23de53f8106bf865b06c8dc2b9b75")
