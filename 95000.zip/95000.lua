-- Lua provided by RyzenAPI
-- Game: Super Splatters

-- MAIN APPLICATION
addappid(95000)

-- MAIN APP DEPOTS / PACKAGES
addappid(95001, 1, "21f51eadfca4cbd76526e37e7321f0d9598aeb80f339de71b87b1d7266be3572")
addappid(95002, 1, "67fcaad425150dc24360bcbdb0135efdd34a5c96e5896ccaba19b5d67b7e6bb1")
addappid(95003, 1, "85d5b3b39249386fdf8d0fc9870bdbd4b0e23de53f8106bf865b06c8dc2b9b75")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
