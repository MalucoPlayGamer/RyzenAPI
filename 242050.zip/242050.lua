-- Lua provided by RyzenAPI
-- Game: Assassin’s Creed® IV Black Flag™

-- MAIN APPLICATION
addappid(242050)
addappid(260470)
addappid(260471)
addappid(260472)
addappid(260473)
addappid(260474)
addappid(260477)
addappid(260478)
addappid(260950)
addappid(264750)
addappid(264800)
addappid(264801)
addappid(264802)
addappid(264804)
addappid(264805)
addappid(264810)
addappid(264811)
addappid(264812)
addappid(264813)
addappid(265320)
addappid(1650420)

-- MAIN APP DEPOTS / PACKAGES
addappid(242051, 1, "6b4004c38a5c8c1a869d90c381726c7d5651f578753c316c2dcd372fa13ef609")
addappid(260476, 0, "c6245eb9d4c77c2f2204ab40754a0d50402bb78f9de10b495e2f9df94d0c051d")
addappid(264803, 0, "28fe23f7e6ef14d6190c4b1646a87d9d7aa6d22d7a0f89936abfe3ebd293fd80")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
