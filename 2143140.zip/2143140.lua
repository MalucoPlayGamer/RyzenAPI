-- Lua provided by RyzenAPI
-- Game: 2143140

-- MAIN APPLICATION
addappid(2143140)
-- Game: addappid(2143140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2143141, 1, "67925dd41417ff7ee4b830236e4be9ae38b4175fb8baa9cfdea9e326aaa7f14a")
