-- 4336570's Lua and Manifest Created by Hubcap Manifest
-- Usurper Reborn
-- Created: August 06, 2026 at 11:24:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4336570) -- Usurper Reborn
-- MAIN APP DEPOTS
addappid(4336571, 1, "07c033bf0eb0c8f1c031ea6dc38537015e051bb4f2a9aa001901d3478aff387e") -- Depot 4336571
setManifestid(4336571, "741878996367967943", 321408502)
addappid(4336572, 1, "38fed8105269e7427e4c9037ef9c5ab842523ef1241c7636dad0da78b9b32f98") -- Depot 4336572
setManifestid(4336572, "86586338135569868", 180869269)
addappid(4336573, 1, "5b7467d444aa35b5531c96071cfba16fa172d8044d91cf12f44ad3ebe0e881a7") -- Depot 4336573
setManifestid(4336573, "8179043345189843884", 487706796)