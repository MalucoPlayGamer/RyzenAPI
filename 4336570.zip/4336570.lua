-- Lua provided by RyzenAPI
-- Game: Usurper Reborn

-- MAIN APPLICATION
addappid(4336570) -- Usurper Reborn

-- MAIN APP DEPOTS / PACKAGES
addappid(4336571, 1, "07c033bf0eb0c8f1c031ea6dc38537015e051bb4f2a9aa001901d3478aff387e") -- Depot 4336571
addappid(4336572, 1, "38fed8105269e7427e4c9037ef9c5ab842523ef1241c7636dad0da78b9b32f98") -- Depot 4336572
addappid(4336573, 1, "5b7467d444aa35b5531c96071cfba16fa172d8044d91cf12f44ad3ebe0e881a7") -- Depot 4336573

