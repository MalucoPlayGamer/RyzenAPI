-- Lua provided by RyzenAPI 
-- Game: Milanoir
addappid(642830)
addappid(642831, 1, "e17794e708296164ee55e0863536aed19e59713c1d86dcb4ec7318a776f8f9c0")
addappid(798440, 0, "0359d76da0a66aa88a577b48459232257188b088792d30f3ee02cbd5351c31a2")
