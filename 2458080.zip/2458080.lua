-- Lua provided by RyzenAPI
-- Game: 2458080

-- MAIN APPLICATION
addappid(2458080)
-- Game: addappid(2458080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2458081, 1, "9d0550cbfd983c50bd056ad7a0db291e1421ff9cc5d1e81cbf9eee8c43e0fdcd")
