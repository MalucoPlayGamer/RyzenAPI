-- Lua provided by RyzenAPI
-- Game: The Feast

-- MAIN APPLICATION
addappid(2221940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2221941, 1, "834026ddc2a025c752a2eb0e86d2f177fcff166a6191ab1c703e3226965d4e1f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2244340)
addappid(2244341)
