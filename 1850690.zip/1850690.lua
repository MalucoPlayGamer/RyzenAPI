-- Lua provided by RyzenAPI
-- Game: AppID 1850690

-- MAIN APPLICATION
addappid(1850690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1850691, 1, "e99c7c78f4003ab7f15b2c26f6db1da8bd6cabdc23d15849e61cfbf2793e8af1")
