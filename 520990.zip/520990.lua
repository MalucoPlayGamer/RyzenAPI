-- Lua provided by RyzenAPI
-- Game: Barrow Hill: The Dark Path

-- MAIN APPLICATION
addappid(520990)

-- MAIN APP DEPOTS / PACKAGES
addappid(520991, 1, "f487efe30ff8ff4a7c2a317fdd64f0109783aea8ce43d388b287635022afa081")
addappid(520992, 1, "6296d010c3ef2ab8e63082fa2c7019df8faaa92b8ff9e972939aa70acabf12d4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
