-- Lua provided by RyzenAPI
-- Game: Kaku Ancient Seal Demo

-- MAIN APPLICATION
addappid(1179590)
-- Game: addappid(1179590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179591, 1, "e00cb15e78e568d2904680ee9a2a2e726048fe8a00250c9290ce8de41ffbc1bb")
