-- Lua provided by RyzenAPI 
-- Game: Project Hospital - Hospital Services
addappid(1282550)
addappid(1282551, 1, "1194d8920c53c77a582f8eded1efddd58dff69f1feeef03abc3b70a40cb8f450")
addappid(1282552, 1, "7c8b8f513073691ae4ce239a42e79fc3b923c5f48908d8d31761c1396b51be96")
addappid(1282553, 1, "0e14341c052c873c0b6a29f72f90af6260806d52c3289664f71a25fea30190ba")
