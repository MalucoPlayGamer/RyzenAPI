-- Lua provided by RyzenAPI
-- Game: Wobbly Jungle

-- MAIN APPLICATION
addappid(437090)

-- MAIN APP DEPOTS / PACKAGES
addappid(437091, 1, "22cc7fa2c86a11e9e53cb53d484e95d7b8b5b5bb5d2cdbebd252d3ad37dcb8a7")
addappid(437092, 1, "47949ab9cba5cee212d65479da88d25f4e89ced781e32f60b7252078b20f3834")
addappid(437093, 1, "f667fd14e386839fbd7c5dbb9831fac9e3c69febf64e8f4ab4d9b085d0fe01cb")
addappid(437094, 1, "1f8d0416bb3f139f9aa23162bba964da34b63f6d1d32abffa22574b1d227334e")
addappid(437095, 1, "2fa77ecdd8658f97ba014fba311d57c56c27b6986b1acf97cae9c6f6b72cadaf")
addappid(437096, 1, "55cfafcf18ff3710801eeb8f6dbca7b0a1b1a86199a46e85ed67d9b7458c4b60")
addappid(437097, 1, "30ee1b86ed098d1ca761167756805fbebebacc33d0ed729b7966dcfc08418643")
addappid(437098, 1, "5717d70674c9bdd1185766ad02677b286328eb459752dabbb29785812be0c9bd")
addappid(437099, 1, "5806f8c20e994bc34a140b934c61ce7fd55568880f7fe2f8fa1b9a26f23950a0")

