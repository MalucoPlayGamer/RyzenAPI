-- Lua provided by RyzenAPI
-- Game: Harder

-- MAIN APPLICATION
addappid(3133740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3133741, 1, "3918e32c15496d0f78c6489136eb83cf3645e4e0840bfc1d593184970c662e14")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
