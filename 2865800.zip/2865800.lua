-- Lua provided by RyzenAPI
-- Game: Cubethon

-- MAIN APPLICATION
addappid(2865800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2865801, 1, "72e0deefc32657db8c5b6715e83bbf3b7ece0896037e401389a9f51ac2af32b6")

