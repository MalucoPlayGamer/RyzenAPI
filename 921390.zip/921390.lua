-- Lua provided by RyzenAPI
-- Game: 武林志（Wushu Chronicles）

-- MAIN APPLICATION
addappid(921390)
-- Game: addappid(921390)

-- MAIN APP DEPOTS / PACKAGES
addappid(921391, 1, "a1de2fd75f0c5680d0ba97364fd66e9044abc45fafd48ae6d9ed75452e533f65")
