-- Lua provided by RyzenAPI
-- Game: addappid(547710)

-- MAIN APPLICATION
addappid(547710)

-- MAIN APP DEPOTS / PACKAGES
addappid(547711, 1, "85bd20a122f0d0fd6d3015c83e4dcfe6ffda450e607af6177c783eaffe92d7c0")
