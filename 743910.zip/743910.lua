-- Lua provided by RyzenAPI
-- Game: Omoide Ni Kawaru Kimi Memories Off

-- MAIN APPLICATION
addappid(743910)

-- MAIN APP DEPOTS / PACKAGES
addappid(743911, 1, "5fa8867be2b4d47bcb651d617d9676eb837d86a9645d788278a8ee9cbf86062c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
