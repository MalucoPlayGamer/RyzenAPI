-- Lua provided by SkyAPI 
-- Game: Omoide Ni Kawaru Kimi Memories Off
addappid(743910)
addappid(743911, 1, "5fa8867be2b4d47bcb651d617d9676eb837d86a9645d788278a8ee9cbf86062c")
