-- Lua provided by RyzenAPI
-- Game: Transformice

-- MAIN APPLICATION
addappid(335240)

-- MAIN APP DEPOTS / PACKAGES
addappid(335241, 1, "ad178ca235b3baca062d2cc47ced165cb1bb054b6c7d4c6ea3841cca9d68a1f6")
addappid(335242, 1, "567c202895347f109b278ace070dc0956e84c738c443000696b32eb506b734a2")
addappid(335243, 1, "f680d57f91342c9a5454739ebe066f485b24ba7f56e5e72598aba48ef4e2f8a0")

