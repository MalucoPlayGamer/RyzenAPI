-- Lua provided by RyzenAPI
-- Game: Game: Mars First Logistics

-- MAIN APPLICATION
addappid(1532200)
-- Game: addappid(1532200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532201, 1, "817366fa3557fd7360844c98856d1448a3c23773756a71b1a0bc76989bf65cd4")
