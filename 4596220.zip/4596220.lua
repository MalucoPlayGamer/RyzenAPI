-- Lua provided by RyzenAPI
-- Game: Monke Survivor

-- MAIN APP DEPOTS / PACKAGES
addappid(4596220, 1, "d9dd6fe2b79b3c3560cc815ddedfbd552155c8f8c7e57b4d638f0762c153f8f6") -- Monke Survivor
addappid(4596221, 1, "a7b14386197c52d1d29e92eb12fc599c641be5ace706a2e00d046fbc473e34f3") -- Depot 4596221

