-- Lua provided by RyzenAPI
-- Game: AppID 1901510

-- MAIN APPLICATION
addappid(1901510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901511, 1, "9bb49d21a09b43cbdc96b1244130f8276a095df116e8beec636eda1b8e4e11ed")
