-- Lua provided by RyzenAPI
-- Game: SVFI - Transparent Footage Support

-- MAIN APPLICATION
addappid(1813870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813871, 1, "9bfe223f56c7448235525d0156f51ffbec4b91dbbc58a4aae612ecc5db67aa53")
