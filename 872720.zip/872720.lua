-- Lua provided by RyzenAPI
-- Game: SuperMash

-- MAIN APPLICATION
addappid(872720)

-- MAIN APP DEPOTS / PACKAGES
addappid(872721,0,"683086e67bea9aa0f0a1250b6e968f7a714901176a5aa8b9b40dbe26c4b74a82")
addappid(872722,0,"5e9cfd2841a3cebcdce934827b80155b1e07b042ea798ae4cbd0cec9f6d25958")

