-- Lua provided by RyzenAPI
-- Game: Game: Criminal Expert

-- MAIN APPLICATION
addappid(2194660)
-- Game: addappid(2194660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194661, 1, "05a3f76c834498cca570293fe76af3df0544f2f4a354433e40933f1e2c2490ea")
