-- Lua provided by RyzenAPI
-- Game: 634120

-- MAIN APPLICATION
addappid(634120)
-- Game: addappid(634120)

-- MAIN APP DEPOTS / PACKAGES
addappid(634121, 1, "469130560b3f47135fbd8991c4da11ac0128647e5149f9612050e66ebebcb0a5")
