-- Lua provided by SkyAPI 
-- Game: AppID 634120
addappid(634120)
addappid(634121, 1, "469130560b3f47135fbd8991c4da11ac0128647e5149f9612050e66ebebcb0a5")
