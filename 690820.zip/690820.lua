-- Lua provided by RyzenAPI
-- Game: The Sunset 2096

-- MAIN APPLICATION
addappid(690820)
-- Game: addappid(690820)

-- MAIN APP DEPOTS / PACKAGES
addappid(690821, 1, "9b7a6fb6b06a58d6e5958122c6b4134bae116368b9b89c50f61a4f07cb06715b")
