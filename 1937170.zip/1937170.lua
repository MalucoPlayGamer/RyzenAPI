-- Lua provided by RyzenAPI
-- Game: 1937170

-- MAIN APPLICATION
addappid(1937170)
addappid(1937171)
addappid(1937172)
addappid(1937173)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937174,0,"e36d4fd02debddacadea10fdbe4b2b0a6b11f29d30fd4deeac6652509fe21286")

