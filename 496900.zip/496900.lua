-- Lua provided by RyzenAPI
-- Game: 496900

-- MAIN APPLICATION
addappid(496900)
-- Game: addappid(496900)

-- MAIN APP DEPOTS / PACKAGES
addappid(496900,0,"b88b0a9892f248267bf7209435b58ca60213aef50d6bc31277f09ae71fa5b79c")
