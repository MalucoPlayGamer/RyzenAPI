-- Lua provided by RyzenAPI 
-- Game: Faint Call
addappid(2958780)
addappid(2958781, 1, "832b56db1f44f8cce816ab2cfd2f9d0ad3fffdb68a73de04a095e6345b7849aa")
