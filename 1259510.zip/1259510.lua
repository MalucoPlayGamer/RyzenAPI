-- Lua provided by RyzenAPI
-- Game: Venge

-- MAIN APPLICATION
addappid(1259510)
-- Game: addappid(1259510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259511, 1, "8ffb4f49c1165d513598114dc7b7129b7c27b980a67270ca715d1703ed87e0a9")
