-- Lua provided by RyzenAPI
-- Game: 鬼魂街

-- MAIN APPLICATION
addappid(2027470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2027471, 1, "eaa21b31c24d3174555b95c897e26d6c998a4f8d4ab80bf38a127312738bfe86")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
