-- Lua provided by RyzenAPI
-- Game: Game: The Witch & The 66 Mushrooms

-- MAIN APPLICATION
addappid(891170)
-- Game: addappid(891170)

-- MAIN APP DEPOTS / PACKAGES
addappid(891171, 1, "097468fb3a20531ebf77c3fecff71d618120a5479c4c5097b1dc2fae16a0766b")
