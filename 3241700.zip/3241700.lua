-- Lua provided by RyzenAPI
-- Game: Hentai Ami

-- MAIN APPLICATION
addappid(3241700)
-- Game: addappid(3241700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3241701, 1, "f5480175bb4c41041110c49fcf844f988cbf05559d0fa5f59f3c35e08583b0f5")
