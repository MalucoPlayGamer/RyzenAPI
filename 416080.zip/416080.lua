-- Lua provided by RyzenAPI
-- Game: The Odyssey: Winds of Athena

-- MAIN APPLICATION
addappid(416080)

-- MAIN APP DEPOTS / PACKAGES
addappid(416081, 1, "84bc0a68b19eb469eedc2cc7775491d1371e6c52b1097972ee460eb815c75cee")
