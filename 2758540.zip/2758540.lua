-- Lua provided by RyzenAPI
-- Game: Game: 我的小鲨鱼

-- MAIN APPLICATION
addappid(2758540)
-- Game: addappid(2758540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2758541, 1, "111d8098073e50772511786a0db0e72415eca5147b4abaf9c7a1fc5d0e859aa0")
