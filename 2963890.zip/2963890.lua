-- Lua provided by RyzenAPI
-- Game: Expelled!

-- MAIN APPLICATION
addappid(2963890)
-- Game: addappid(2963890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963891, 1, "7426f560be42449d13454823aa763f5a517d0417ed3d1ad364b14f6213cb2d36")
