-- Lua provided by RyzenAPI
-- Game: AppID 1289890

-- MAIN APPLICATION
addappid(1289890)
-- Game: addappid(1289890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289891, 1, "14266a98302bedf7dc988ccd5e2197a011ce9348db5abb767594402d986377a5")
