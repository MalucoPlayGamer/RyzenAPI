-- Lua provided by RyzenAPI
-- Game: Happy New Hentai

-- MAIN APPLICATION
addappid(1474580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1474581, 1, "c9c51e9ad427d407dd0e0f5dd65837fb782183eb0413f1bf141db4672f16de59")

