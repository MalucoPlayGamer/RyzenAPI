-- Lua provided by RyzenAPI
-- Game: 2833960

-- MAIN APPLICATION
addappid(2833960)
addappid(2873730)
-- Game: addappid(2833960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2833961, 1, "4f2bfbfc476005e67571dea768a0d2b861aa1c823698caaa08f06c7035f77c40")
