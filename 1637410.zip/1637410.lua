-- Lua provided by SkyAPI 
-- Game: Dream Catcher: Prologue
addappid(1637410)
addappid(1637411, 1, "ed5297be5fef4c9201cf3c2411ee855e57a7be2f1d4c2852e2c596a49f5df233")
