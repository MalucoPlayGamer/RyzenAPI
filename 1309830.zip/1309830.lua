-- Lua provided by RyzenAPI
-- Game: 1309830

-- MAIN APPLICATION
addappid(1309830)
-- Game: addappid(1309830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309831, 1, "0e4f931d14a6efa48d0b5665fa54aa9ecd770359670cbe75a9dd2aa99b74045f")
