-- Lua provided by RyzenAPI
-- Game: addappid(3256020)

-- MAIN APPLICATION
addappid(3256020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3256021, 1, "ce6fd8f56262e17a4fc4a2441e49de4599c45a29d5f1022d0fe764686dba3184")
