-- Lua provided by SkyAPI 
-- Game: eXecutor
addappid(2110550)
addappid(2110551, 1, "052e4c992a75540fda605b7e02772267da11f96245e082a020093147452a361f")
