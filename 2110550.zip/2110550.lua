-- Lua provided by RyzenAPI
-- Game: Game: eXecutor

-- MAIN APPLICATION
addappid(2110550)
-- Game: addappid(2110550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2110551, 1, "052e4c992a75540fda605b7e02772267da11f96245e082a020093147452a361f")
