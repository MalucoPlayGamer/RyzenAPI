-- Lua provided by RyzenAPI
-- Game: addappid(2699880)

-- MAIN APPLICATION
addappid(2699880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2699881, 1, "4c1bf9cf10c5a7df240105fda92264d42f8768e3a9d99773b4fa9bcb91627271")
