-- Lua provided by SkyAPI 
-- Game: Fairies Love
addappid(2699880)
addappid(2699881, 1, "4c1bf9cf10c5a7df240105fda92264d42f8768e3a9d99773b4fa9bcb91627271")
