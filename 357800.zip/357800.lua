-- Lua provided by RyzenAPI
-- Game: 357800

-- MAIN APPLICATION
addappid(357800)
-- Game: addappid(357800)

-- MAIN APP DEPOTS / PACKAGES
addappid(357801, 1, "a6fb6aeeed3dfda435d5e36ddb6991e985320549035b17cac0690d88583b6dc9")
