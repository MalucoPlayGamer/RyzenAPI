-- Lua provided by SkyAPI 
-- Game: AppID 2417870
addappid(2417870)
addappid(2417871, 1, "1054cf46775a63d69068c1904398ee735f27a076fd54a6716313798a34c4d8b6")
