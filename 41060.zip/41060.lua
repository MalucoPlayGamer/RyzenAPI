-- Lua provided by RyzenAPI 
-- Game: AppID 41060
addappid(41060)
addappid(41061, 1, "f0f57c2acd45a567b57dc6ff1cd9943704c5c96c24eb4484d8d5772c25937bfe")
