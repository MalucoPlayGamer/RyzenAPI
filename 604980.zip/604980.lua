-- Lua provided by RyzenAPI
-- Game: Travel Riddles: Trip To India

-- MAIN APPLICATION
addappid(604980)

-- MAIN APP DEPOTS / PACKAGES
addappid(604981,0,"bcc84234f1ffa72137ce816160892313db4ae338e3d21cd70b68ba5c8342a46e")

