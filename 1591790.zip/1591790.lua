-- Lua provided by RyzenAPI
-- Game: Countdown Final Zone Demo

-- MAIN APPLICATION
addappid(1591790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1591791, 1, "18ab468216cc9e7bdfb83988c04a95999ba85025fb19445b72caf96d1c62aa30")
