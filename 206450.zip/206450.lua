-- Lua provided by RyzenAPI
-- Game: 206450

-- MAIN APPLICATION
addappid(206450)
-- Game: addappid(206450)

-- MAIN APP DEPOTS / PACKAGES
addappid(206451, 1, "d920067d860e8f1239c5e6206ef48c1a7ce38c31c107b240f837343be7e90a9d")
