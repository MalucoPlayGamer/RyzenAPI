-- Lua provided by RyzenAPI
-- Game: Ever Forward

-- MAIN APPLICATION
addappid(1220370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220371, 1, "c1438d52d46f8e4077f4693fbedd0c30553d003c9a0125e557b165ca0c6e0fce")

