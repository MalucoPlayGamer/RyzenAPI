-- Lua provided by RyzenAPI
-- Game: Tales of the Magic Ball: The Lost Sorcerer

-- MAIN APPLICATION
addappid(2318100)
-- Game: addappid(2318100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318101, 1, "a73a405a446c792d3f43d000aa232b4001075cba89292ec0d06d07176c86ffd6")
