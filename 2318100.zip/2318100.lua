-- Lua provided by RyzenAPI
-- Game: Tales of the Magic Ball: The Lost Sorcerer

-- MAIN APPLICATION
addappid(2318100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2318101, 1, "a73a405a446c792d3f43d000aa232b4001075cba89292ec0d06d07176c86ffd6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
