-- 2306840's Lua and Manifest Created by Hubcap Manifest
-- Fantasy Shop Tycoon
-- Created: August 17, 2026 at 09:18:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2306840) -- Fantasy Shop Tycoon
-- MAIN APP DEPOTS
addappid(2306841, 1, "f393e5e90411bdfa412409236566acb8ceca4e5f83061914a50c9349a4ea1aaf") -- Depot 2306841
setManifestid(2306841, "6983035628324986240", 1039247308)