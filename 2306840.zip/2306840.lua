-- Lua provided by RyzenAPI
-- Game: Fantasy Shop Tycoon

-- MAIN APPLICATION
addappid(2306840) -- Fantasy Shop Tycoon

-- MAIN APP DEPOTS / PACKAGES
addappid(2306841, 1, "f393e5e90411bdfa412409236566acb8ceca4e5f83061914a50c9349a4ea1aaf") -- Depot 2306841

