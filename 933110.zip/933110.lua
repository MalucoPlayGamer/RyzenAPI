-- Lua provided by RyzenAPI
-- Game: Age of Empires III: Definitive Edition

-- MAIN APPLICATION
addappid(933110)

-- MAIN APP DEPOTS / PACKAGES
addappid(933111, 1, "db66cbd6d22bd891a526cad65c5688f4f4b787857167cedf9f5b80235279aaba")
addappid(933112, 1, "542beeb65a43d03a4f47315afc9b7736a2760f4895f2b9e646d77055174f9aed")
addappid(933113, 1, "dd5ff8738c67b40554f40b0403599e72b7f27809d2652eb454bbd211250a7f38")
addappid(933114, 1, "8745ff68b7c8aef2ffb3a9fd0146544e2510597561e1dc883437511360d00dc5")
addappid(933115, 1, "28c9a4be20849089236b08058848b0078a3bc7bd6585cde6e8aff724500d59be")
addappid(933116, 1, "fc8c4607987f3f1de5510b31695f99c786d31f6092e5374fee28c881f846ddd9")
addappid(933117, 1, "d7004cbd474e05e0f3a4271b2a41c69e3971f091ab89da0b8d5c14d392817628")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1581450)
addappid(1581451)
addappid(1817361)
addappid(1817370)
addappid(2154360)
addappid(2154361)
addappid(2154362)
addappid(2477660)
addappid(4308600)
