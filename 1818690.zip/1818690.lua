-- Lua provided by RyzenAPI
-- Game: addappid(1818690)

-- MAIN APPLICATION
addappid(1818690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818691, 1, "0d6facef61f324f28048b61a828730bab238ea31e330bc37610236b49b05932d")
