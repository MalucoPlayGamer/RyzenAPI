-- Lua provided by RyzenAPI
-- Game: Tyrant Quest - Gold Edition 🔞

-- MAIN APPLICATION
addappid(1888470)
-- Game: addappid(1888470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888471, 1, "f35dc9cb49bb17190faca9c55de1fbda2c7b7ff5bd5bcab28e6b082ea94ac492")
