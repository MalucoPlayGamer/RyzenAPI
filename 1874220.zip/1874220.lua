-- Lua provided by RyzenAPI
-- Game: 1874220

-- MAIN APPLICATION
addappid(1874220)
-- Game: addappid(1874220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1874221, 1, "9f4d7921ab4c87c037324d2454078d2633b0ad53c50b12b485a7cf1dc671d1f3")
