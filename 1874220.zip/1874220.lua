-- Lua provided by SkyAPI 
-- Game: AppID 1874220
addappid(1874220)
addappid(1874221, 1, "9f4d7921ab4c87c037324d2454078d2633b0ad53c50b12b485a7cf1dc671d1f3")
