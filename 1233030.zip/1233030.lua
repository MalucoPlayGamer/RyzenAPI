-- Lua provided by RyzenAPI
-- Game: Armorik the Viking: The Eight Conquests

-- MAIN APPLICATION
addappid(1233030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1233031, 1, "d816e643e8699361a68c21050b24641a6174471a294e67279eb33581a7f29674")

