-- Lua provided by RyzenAPI 
-- Game: Athos
addappid(2526410)
addappid(2526411, 1, "8e3135cdb52c85f39fa64374d5d29679162eb84e636668c1c6ab13d0e030613a")
