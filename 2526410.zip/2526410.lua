-- Lua provided by RyzenAPI
-- Game: Athos

-- MAIN APPLICATION
addappid(2526410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2526411, 1, "8e3135cdb52c85f39fa64374d5d29679162eb84e636668c1c6ab13d0e030613a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
