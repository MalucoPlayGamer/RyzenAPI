-- Lua provided by RyzenAPI
-- Game: Level Zero: Extraction Digital Artbook

-- MAIN APPLICATION
addappid(3126940)
-- Game: addappid(3126940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3126940,0,"af0c7bfcbba9e7a7fb6f90a5a5a5aefaad100d711323fc563276747415d88b39")
