-- Lua provided by RyzenAPI
-- Game: Ducks Can Drive

-- MAIN APPLICATION
addappid(2472840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2472841, 1, "d4d83c76440d0abb0d03fe35917a6dc816e18fafdf5cae32da4dda8af7e186e1")
addappid(2472842, 1, "2ac941aa9ded058070795aa0d5f78e4b8560ba12951c8a5f3ec36fe038d70fb1")
addappid(2472843, 1, "3aa7c1c5d0820da1542657ee3fff57a87822d1647a959d4c31c844e78cd7156b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2546870)
addappid(2582580)
