-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2062180)
-- Game: addappid(2062180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2062180,0,"98b327e7cdf46bf254b9bd62b1597f3818f4ab5206eea67e4ff4ae3df7b8259d")
