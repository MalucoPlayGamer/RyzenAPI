-- Lua provided by RyzenAPI
-- Game: Intown Nightmares

-- MAIN APPLICATION
addappid(2779400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779401,0,"fb78baadf119f44211df5b626a9daa8a94816c0610456cfcb46a93c1702dc6ee")

