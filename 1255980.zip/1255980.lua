-- Lua provided by RyzenAPI
-- Game: Game: AppID 1255980

-- MAIN APPLICATION
addappid(1255980)
-- Game: addappid(1255980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1255981, 1, "dc98a3763d3f305b4ec2f52bdab9d93fcd7edc25ff86941b4a645808928a765b")
addappid(1255982, 1, "c45de80198a85a5d2f5128905433e651884ebabdd0a640cfbd5a7ddf8dce4b09")
addappid(1255983, 1, "6e5218c30d056e7bdc1ebd853b355432e6c17bec69bea34f09faafc96e9d23e5")
addappid(1255984, 1, "e7182b8d7f301de4150fa8bc6058a8ee245ed6643e44171a28935112d68ffe07")
