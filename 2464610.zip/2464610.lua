-- Lua provided by RyzenAPI
-- Game: Saloon Simulator Demo

-- MAIN APPLICATION
addappid(2464610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464611, 1, "e15c579fedbf9728fbb1dbd437dc9e06f1cc41719dda7a6b4ab27cf95aaba783")
