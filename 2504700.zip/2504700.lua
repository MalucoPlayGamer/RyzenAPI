-- Lua provided by RyzenAPI
-- Game: addappid(2504700)

-- MAIN APPLICATION
addappid(2504700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2504701, 1, "2d00863f4eeb86e7e600cf5c1ab6f55b8a985a2871668776ff89799d8dff2f4c")
addappid(2504702, 1, "a7b1600ceb42bead1df5b8531f5344f2a515083a0d8b3ad680c7cfc112d07779")
