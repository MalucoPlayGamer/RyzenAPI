-- Lua provided by RyzenAPI
-- Game: addappid(747470)

-- MAIN APPLICATION
addappid(747470)

-- MAIN APP DEPOTS / PACKAGES
addappid(747471, 1, "f9634c11e170a9ce97b83f7bdc7cc14a338ce30caf2f9b7551bc91d7b5c86899")
addappid(747472, 1, "60df54687cf6b7df70bff5a88999f0f755a6167d4d3f2b5c8b3fc24a3088f27b")
