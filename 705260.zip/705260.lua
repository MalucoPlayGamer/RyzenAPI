-- Lua provided by SkyAPI 
-- Game: AppID 705260
addappid(705260)
addappid(705261, 1, "473f1d4ec680f24de79e5cd1493ea8c5c7dcfcf7ef15a7118d2741e76873f3b2")
