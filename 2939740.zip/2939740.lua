-- Lua provided by RyzenAPI 
-- Game: AppID 2939740
addappid(2939740)
addappid(2939741, 1, "7813cfacdc7e9e6e010bc301a2bc32654b2239cc6f1e40952756ce3728304eb2")
