-- Lua provided by RyzenAPI
-- Game: 2939740

-- MAIN APPLICATION
addappid(2939740)
-- Game: addappid(2939740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2939741, 1, "7813cfacdc7e9e6e010bc301a2bc32654b2239cc6f1e40952756ce3728304eb2")
