-- Lua provided by RyzenAPI
-- Game: 绝命游歌 Demo

-- MAIN APPLICATION
addappid(2939740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2939741, 1, "7813cfacdc7e9e6e010bc301a2bc32654b2239cc6f1e40952756ce3728304eb2")
