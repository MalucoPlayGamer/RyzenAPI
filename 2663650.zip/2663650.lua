-- Lua provided by RyzenAPI 
-- Game: AppID 2663650
addappid(2663650)
addappid(2663651, 1, "b4bc633e06c4c228e581b386b021f6d5caf217f15d58e68e84cfb08cea91eb11")
