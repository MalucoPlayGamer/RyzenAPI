-- Lua provided by RyzenAPI
-- Game: Everything is Mayo

-- MAIN APPLICATION
addappid(1097900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097901, 1, "5c7a6644b5527dc43bb5a9d1d082cb68f218bc83ccee0558f1fe62546befe555")
