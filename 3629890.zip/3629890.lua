-- Lua provided by RyzenAPI
-- Game: Bushside Rangers - Original Soundtrack

-- MAIN APPLICATION
addappid(3629890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3641871,0,"7aced8f4f4de82c7f569c5aabebdf24108d7070ecbfbeb2b8b1eca6a217e7595")
