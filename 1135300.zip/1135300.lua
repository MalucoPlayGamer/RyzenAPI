-- Lua provided by RyzenAPI
-- Game: King's Bounty II

-- MAIN APPLICATION
addappid(1135300)
addappid(1898190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1135301, 1, "77aa1a71dc4364571a589730aab4343c6d3b2a434f870060a3f70c8ec2904004")
addappid(1135302, 1, "7db1a11fc877fc788994436903f5fc14ef66ffcdb6c41194d091db270e36a3d6")
addappid(1640381, 0, "79a1a9a4d636c93b68046aad9c43d412400be40783edf414bc9181e6ea262b59")
addappid(1640382, 0, "5e5b9cd39d1ce6304ca64c0c2de1bb1361751bdd8540e8ed261c78632fd48772")
addappid(1640383, 0, "450da9b77a12e409f90ae348305117d3dad0611eaa6ec96ebf818beb0657bf21")
addappid(1640390, 0, "f2f3bd30ab5020de664be552336cfadcc15e00b73e8ca94dd3201a6a7c13e168")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
