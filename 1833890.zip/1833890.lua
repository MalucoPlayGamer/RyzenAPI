-- Lua provided by RyzenAPI
-- Game: 1833890

-- MAIN APPLICATION
addappid(1833890)
-- Game: addappid(1833890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833891, 1, "92d946efe3dc09b3371ef079961d8684a48ffe4024b1263aec723da5f990716c")
