-- Lua provided by RyzenAPI
-- Game: Game: AppID 1133120

-- MAIN APPLICATION
addappid(1133120)
-- Game: addappid(1133120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133121, 1, "224caafcfaff8f534095420d9554d74754f82c7d8e3240317181445e0f7d8544")
