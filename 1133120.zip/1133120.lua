-- Lua provided by RyzenAPI
-- Game: Ecosystem

-- MAIN APPLICATION
addappid(1133120)
addappid(3816870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133121, 1, "224caafcfaff8f534095420d9554d74754f82c7d8e3240317181445e0f7d8544")
