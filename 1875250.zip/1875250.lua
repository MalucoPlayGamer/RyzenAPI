-- Lua provided by RyzenAPI 
-- Game: AppID 1875250
addappid(1875250)
addappid(1875251, 1, "4740d6bc90e08f94fe17e8fa5d10261b03b90de3498a8786b8b92e8a97f0798c")
