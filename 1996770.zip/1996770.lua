-- Lua provided by RyzenAPI
-- Game: Turok 3: Shadow of Oblivion Remastered

-- MAIN APPLICATION
addappid(1996770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1996771, 1, "7ed721a70c972dbb1440b82b2e076a5d3f6532b9a7fe901e60594c8dac4d4171")
addappid(1996772, 1, "75cb474f5167ea5fb98fc750c86723197a33cba27927d4b57906013e29165841")
