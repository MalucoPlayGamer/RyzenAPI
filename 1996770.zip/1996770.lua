-- Lua provided by RyzenAPI
-- Game: Turok 3: Shadow of Oblivion Remastered

-- MAIN APPLICATION
addappid(1996770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1996771, 1, "7ed721a70c972dbb1440b82b2e076a5d3f6532b9a7fe901e60594c8dac4d4171")
addappid(1996772, 1, "75cb474f5167ea5fb98fc750c86723197a33cba27927d4b57906013e29165841")

