-- Lua provided by RyzenAPI
-- Game: Game: Ultimagus

-- MAIN APPLICATION
addappid(575360)
-- Game: addappid(575360)

-- MAIN APP DEPOTS / PACKAGES
addappid(575361, 1, "11388f54e587073401d77ced74e2626386052ecae8371cb8cb75f9dbbf93b1d2")
