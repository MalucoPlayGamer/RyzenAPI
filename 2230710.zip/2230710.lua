-- Lua provided by RyzenAPI
-- Game: AppID 2230710

-- MAIN APPLICATION
addappid(2230710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2230711, 1, "0d3d6f4fb7f7033153429c90eca6c520a7f0f182041fa0fc2aa49f0b60faa3ee")
addappid(2230712, 1, "81531c117bf150c4fe0ea01ec4f94aff0cb59e0831cc978ee4a03d5f8f2dab2e")

