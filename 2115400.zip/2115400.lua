-- Lua provided by RyzenAPI
-- Game: 2115400

-- MAIN APPLICATION
addappid(2115400)
-- Game: addappid(2115400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2115401, 1, "fe8431dba5ecd519312aad63b5ab2942da67f4c04d8732cfdcb41499812bf770")
