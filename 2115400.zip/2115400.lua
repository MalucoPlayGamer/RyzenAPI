-- Lua provided by RyzenAPI 
-- Game: Muse&Barbarian
addappid(2115400)
addappid(2115401, 1, "fe8431dba5ecd519312aad63b5ab2942da67f4c04d8732cfdcb41499812bf770")
