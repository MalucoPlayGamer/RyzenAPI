-- Lua provided by RyzenAPI
-- Game: AppID 699100

-- MAIN APPLICATION
addappid(699100)
-- Game: addappid(699100)

-- MAIN APP DEPOTS / PACKAGES
addappid(699101, 1, "1daf8a8ff3bf431087ee70840ce3e1ffc63aadfb7f45ea8cf78a7652450c9c0c")
