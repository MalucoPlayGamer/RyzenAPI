-- Lua provided by RyzenAPI
-- Game: The God's Chain

-- MAIN APPLICATION
addappid(504490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(504491, 1, "b68ab601a266d1a4d1e02970231608e5df1699a08dc1518ef3ea82732604b73b")
addappid(504492, 1, "638bb07d19a4400427f8cb37efc58a315f58fea002f206af9cdd43161f4cec38")
addappid(504493, 1, "2c5556b95765b7f808f6c78d93d9319c9b341756317675fc873979b43705eb43")

