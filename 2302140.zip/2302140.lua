-- Lua provided by RyzenAPI
-- Game: q.u.q.

-- MAIN APPLICATION
addappid(2302140)
-- Game: addappid(2302140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302141, 1, "ee4d60a290843cc3349861d1b57aa37a39f1585f84d01738299403b96e194d3e")
