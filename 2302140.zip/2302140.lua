-- Lua provided by SkyAPI 
-- Game: q.u.q.
addappid(2302140)
addappid(2302141, 1, "ee4d60a290843cc3349861d1b57aa37a39f1585f84d01738299403b96e194d3e")
