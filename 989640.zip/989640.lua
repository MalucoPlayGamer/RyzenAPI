-- Lua provided by RyzenAPI
-- Game: addappid(989640)

-- MAIN APPLICATION
addappid(989640)

-- MAIN APP DEPOTS / PACKAGES
addappid(989646,0,"44606b0f020ebdb481c968da652e3ae9930db5fd971e44a1932f755e3a491f0c")
addappid(989647,0,"0933dff18ffba0163ddc61b6e04d9b1ec61039a2f8fe1ce005e41c55c67c5276")
