-- Lua provided by RyzenAPI
-- Game: Dungeon No Dungeon: Tyrant's Endgame

-- MAIN APPLICATION
addappid(2449080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2449081, 1, "ecaa1670b4b7a7c0a5559452bdb5752070d50d3561845308ef57a2ceebf92915")

