-- Lua provided by RyzenAPI
-- Game: Rogue Hex

-- MAIN APPLICATION
addappid(2275940)
addappid(3405240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2275941, 1, "493a9b9bd149fbff512d290f8730b75c9821ea5e71fdb8022926b4a6456ac8ad")

