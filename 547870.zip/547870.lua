-- Lua provided by RyzenAPI
-- Game: Clown2Beat

-- MAIN APPLICATION
addappid(547870)
addappid(632650)

-- MAIN APP DEPOTS / PACKAGES
addappid(547871, 1, "fd3ec9d4403d54df876c89fc383d5de0d5242f09cf010a63acdaee1c1d9e7ede")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
