-- Lua provided by SkyAPI 
-- Game: Clown2Beat
addappid(547870)
addappid(547871, 1, "fd3ec9d4403d54df876c89fc383d5de0d5242f09cf010a63acdaee1c1d9e7ede")
addappid(632650)
