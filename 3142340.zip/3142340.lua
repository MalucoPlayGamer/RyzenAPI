-- Lua provided by RyzenAPI
-- Game: Chill Corner - Mood & Vibes (Vol 3) - Chill Town Collection

-- MAIN APPLICATION
addappid(3142340)
-- Game: addappid(3142340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3142340,0,"9395ce3c647796b0392c2f3cccf41a0bb89a656444ddb78ead8543d5ba954565")
