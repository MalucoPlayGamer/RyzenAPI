-- Lua provided by RyzenAPI
-- Game: addappid(3142340)

-- MAIN APPLICATION
addappid(3142340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3142340,0,"9395ce3c647796b0392c2f3cccf41a0bb89a656444ddb78ead8543d5ba954565")
