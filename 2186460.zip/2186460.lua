-- Lua provided by RyzenAPI
-- Game: Cybercontrol

-- MAIN APPLICATION
addappid(2186460)
-- Game: addappid(2186460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2186461, 1, "6f2dd7a03bcc05e2e34a3fd12c3fa69ce8c32c064f4f2134ac401893a995a343")
