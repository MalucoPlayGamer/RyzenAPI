-- Lua provided by RyzenAPI
-- Game: Grow Home

-- MAIN APPLICATION
addappid(323320)
addappid(353590)

-- MAIN APP DEPOTS / PACKAGES
addappid(323321, 1, "374f4eca62268df297c6d1cc7d1edb52d74f49c967a8ec42e6818dcb37067011")
addappid(323322, 1, "936184f821dd6617a3bffcf7c29b0a7798c284f7a65980463451e58756d6b9ff")
