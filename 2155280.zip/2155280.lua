-- Lua provided by RyzenAPI 
-- Game: Defend Earth: Xenos Survivors
addappid(2155280)
addappid(2155281, 1, "0a50ec0ef9d1c889b6d21406f0ec91c1653bb437a1bf7b1356055b95777cee6b")
