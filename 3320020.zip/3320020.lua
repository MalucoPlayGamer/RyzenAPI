-- 3320020's Lua and Manifest Created by Hubcap Manifest
-- Cats With Standards
-- Created: August 05, 2026 at 22:43:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3320020) -- Cats With Standards
-- MAIN APP DEPOTS
addappid(3320021, 1, "a0209593f29149a3379e29088cdfdc7f395aab1b6bee53879f782d796263cbb8") -- Depot 3320021
setManifestid(3320021, "7227619342521239174", 169523646)
addappid(3320022, 1, "7e48bd85283fcd8bd198b5e431b9dcd1ede56f4bb91ea5cf7c0d13f7bee58573") -- Depot 3320022
setManifestid(3320022, "6178437440333354245", 416019539)
addappid(3320023, 1, "fd1aa846845da6e285eb6dcf0ade4116f68cf7d5aa0c0ff394c08ee9aa76bdd9") -- Depot 3320023
setManifestid(3320023, "1463612283255066361", 137480535)