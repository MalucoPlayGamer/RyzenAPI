-- Lua provided by RyzenAPI
-- Game: Cats With Standards

-- MAIN APPLICATION
addappid(3320020) -- Cats With Standards

-- MAIN APP DEPOTS / PACKAGES
addappid(3320021, 1, "a0209593f29149a3379e29088cdfdc7f395aab1b6bee53879f782d796263cbb8") -- Depot 3320021
addappid(3320022, 1, "7e48bd85283fcd8bd198b5e431b9dcd1ede56f4bb91ea5cf7c0d13f7bee58573") -- Depot 3320022
addappid(3320023, 1, "fd1aa846845da6e285eb6dcf0ade4116f68cf7d5aa0c0ff394c08ee9aa76bdd9") -- Depot 3320023

