-- Lua provided by RyzenAPI
-- Game: Game: AppID 1449210

-- MAIN APPLICATION
addappid(1449210)
-- Game: addappid(1449210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449211, 1, "d719cd83c16f0beedd69b59a3c1d665e2b8127ad8a84ece7d4e15c9f1e96a9db")
