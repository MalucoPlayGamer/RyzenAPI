-- Lua provided by RyzenAPI
-- Game: 451310

-- MAIN APPLICATION
addappid(451310)
-- Game: addappid(451310)

-- MAIN APP DEPOTS / PACKAGES
addappid(451311, 1, "cc128421e04cffb1acd3eca2edc4dfe530c11f50664e5d712bda5aac006a0a0d")
