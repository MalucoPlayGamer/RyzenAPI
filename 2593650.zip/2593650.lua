-- Lua provided by RyzenAPI
-- Game: Game: Deep Space Solitude

-- MAIN APPLICATION
addappid(2593650)
-- Game: addappid(2593650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593651, 1, "d70fe6bb8059a849624948beeadfb5d6c7a55ed12a0fd5b0cdfaffd80eb7338d")
