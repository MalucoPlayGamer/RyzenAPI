-- Lua provided by RyzenAPI
-- Game: BIGFOOT

-- MAIN APPLICATION
addappid(509980)
addappid(1802310)
addappid(1805430)
addappid(1805440)
addappid(1871270)
addappid(1871271)
addappid(1871300)
addappid(1871301)
addappid(1871302)

-- MAIN APP DEPOTS / PACKAGES
addappid(509981, 1, "3c460f6210e45fbbeb0e3462679cc44b11c549eebd629cab653f3fd3d2240a85")
addappid(509982, 1, "1828ef052d7981097d4990a026f524049414f37295970acda2e08b26eb95f2db")

