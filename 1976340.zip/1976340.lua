-- Lua provided by RyzenAPI
-- Game: 1976340

-- MAIN APPLICATION
addappid(1976340)
-- Game: addappid(1976340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976341, 1, "e935edecb98b252f311d18f5727aafe4c9bdff7911b790235bce1659b2570643")
