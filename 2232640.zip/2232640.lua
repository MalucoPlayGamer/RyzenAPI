-- Lua provided by RyzenAPI
-- Game: Isekai Janken Hero-Digital ArtBook

-- MAIN APPLICATION
addappid(2232640)
-- Game: addappid(2232640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232640,0,"41551a0db163cbf1c3cb672db7458c61f55217c43119f32f126bdcdce85a54fb")
