-- Lua provided by RyzenAPI
-- Game: addappid(2024890)

-- MAIN APPLICATION
addappid(2024890)
addappid(2384770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2024891, 1, "a18f033e9f76188847b624f4881145152da5705ae68707f7b96ef4c6f2dc58d6")
