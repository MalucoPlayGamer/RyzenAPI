-- Lua provided by RyzenAPI
-- Game: TAL: Arctic 3

-- MAIN APPLICATION
addappid(932120)

-- MAIN APP DEPOTS / PACKAGES
addappid(932121, 1, "a437bcf3832d499d699e0a3fa54bc66b22406fbe1913b312f5a330a3b8cb1f83")
