-- Lua provided by RyzenAPI
-- Game: Zombie City

-- MAIN APPLICATION
addappid(1895080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895081, 1, "78ab85d8c4d91f22e5ec3463ce968dd24e5bc91c59fe11fdcd1f7fc10e6fdea6")
