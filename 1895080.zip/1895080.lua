-- Lua provided by RyzenAPI
-- Game: Zombie City

-- MAIN APPLICATION
addappid(1895080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1895081, 1, "78ab85d8c4d91f22e5ec3463ce968dd24e5bc91c59fe11fdcd1f7fc10e6fdea6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
