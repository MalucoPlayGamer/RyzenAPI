-- Lua provided by RyzenAPI
-- Game: Locked In Mind

-- MAIN APPLICATION
addappid(2252820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2252821, 1, "ddbb4db9dae891de1bb9d381a27d3828171a9aff08fa298ea4d5227f9f2e7ced")

