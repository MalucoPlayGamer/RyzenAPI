-- Lua provided by RyzenAPI
-- Game: Game: Match Point

-- MAIN APPLICATION
addappid(764890)
-- Game: addappid(764890)

-- MAIN APP DEPOTS / PACKAGES
addappid(764891, 1, "4bb6974e7c5556446c7f130565e28bf540cee812e467371093c30295807e4ca0")
