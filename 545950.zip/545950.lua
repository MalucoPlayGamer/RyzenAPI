-- Lua provided by RyzenAPI
-- Game: AppID 545950

-- MAIN APPLICATION
addappid(545950)
-- Game: addappid(545950)

-- MAIN APP DEPOTS / PACKAGES
addappid(545951, 1, "8736c9b33f5125c107f1070e01a44cb7c485ac3f358d97b2f60fd64d9b739dce")
