-- Lua provided by RyzenAPI
-- Game: Game: Sex Adventures - Swingers Gym

-- MAIN APPLICATION
addappid(2111520)
-- Game: addappid(2111520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2111521, 1, "5fd14bbab06647a29d1d24dec02384dbbf00fffddbc8bb61f35094112aff52b7")
