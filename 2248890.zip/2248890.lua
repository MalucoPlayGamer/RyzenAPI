-- Lua provided by RyzenAPI
-- Game: addappid(2248890)

-- MAIN APPLICATION
addappid(2248890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2248892,0,"b82451be94289feb6554a498fd53dbefdc9345db21390ea805045fb901921ffd")
