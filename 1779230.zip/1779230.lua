-- Lua provided by RyzenAPI
-- Game: AppID 1779230

-- MAIN APPLICATION
addappid(1779230)
-- Game: addappid(1779230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1779231, 1, "ed6da2adec0128bc590b57e7e9059ed565d7fd82b06c2c816bab89117086883f")
