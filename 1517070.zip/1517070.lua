-- Lua provided by RyzenAPI
-- Game: Get Packed Demo

-- MAIN APPLICATION
addappid(1517070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517071, 1, "85965ff04bd90ea5658742e1d0ae685a1f348d733d4f8f3b7a19ef1cadf33f94")
