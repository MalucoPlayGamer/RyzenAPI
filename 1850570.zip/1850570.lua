-- Lua provided by RyzenAPI
-- Game: DEATH STRANDING DIRECTOR'S CUT

-- MAIN APPLICATION
addappid(1850570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1850571, 1, "f0c67b235585f625ae33882c4547f9ef4404e96c5ad0a1fb4dbf43da61e04e24")
addappid(1946740, 0, "e01735660cdb310784cc00ba796a0b48c48605b9b94cf3e4d473b3a5ae97af32")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
