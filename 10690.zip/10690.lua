-- Lua provided by RyzenAPI
-- Game: 10690

-- MAIN APPLICATION
addappid(10690)
addappid(10691)

-- MAIN APP DEPOTS / PACKAGES
addappid(10695,0,"1256afb7b46e18e39a1045641f5e1ccd468d5be8d0bc43930ac80e654d3a40d4")
