-- Lua provided by SkyAPI 
-- Game: Mecha Simultactics Alpha
addappid(2898880)
addappid(2898881, 1, "734b42801bbbb26b4876840d6ecc53d45f4313ab58abc779a1d0f00b34bbd265")
