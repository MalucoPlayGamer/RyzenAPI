-- Lua provided by RyzenAPI
-- Game: City of Beats

-- MAIN APPLICATION
addappid(1470390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1470391, 1, "0355f2c893d13de8b3d795e996bc6d86b593d8ecbd889b2f20a7fc417c4b2c50")

