-- Lua provided by RyzenAPI
-- Game: City of Beats

-- MAIN APPLICATION
addappid(1470390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1470391, 1, "0355f2c893d13de8b3d795e996bc6d86b593d8ecbd889b2f20a7fc417c4b2c50")

