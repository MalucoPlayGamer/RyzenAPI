-- Lua provided by RyzenAPI
-- Game: Yayos

-- MAIN APPLICATION
addappid(4207330)

-- MAIN APP DEPOTS / PACKAGES
addappid(4207331,0,"79308ac09b83c3bfc79d0d6fd769967885b891f42ae680c8472fd856d25d66be")

