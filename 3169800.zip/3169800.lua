-- Lua provided by RyzenAPI
-- Game: Game: AppID 3169800

-- MAIN APPLICATION
addappid(3169800)
-- Game: addappid(3169800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169801, 1, "26b9e710edecdb1e5da74962e370f95bb3aaab35b08d0619d61131e5ac71c6d7")
