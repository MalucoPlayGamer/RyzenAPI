-- Lua provided by RyzenAPI
-- Game: addappid(669390)

-- MAIN APPLICATION
addappid(669390)

-- MAIN APP DEPOTS / PACKAGES
addappid(669391, 1, "fbf92f8b7bb44cfdc360fb7cb215b7693ab0b80b9d0ff7f4b903907cf0b97c29")
