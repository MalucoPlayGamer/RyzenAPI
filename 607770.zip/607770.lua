-- Lua provided by RyzenAPI
-- Game: addappid(607770)

-- MAIN APPLICATION
addappid(607770)

-- MAIN APP DEPOTS / PACKAGES
addappid(607771, 1, "d35b6b1cd26cb87bb96a11da744c48ca7ddf772ed5981252f2b5d44731ecf5e7")
