-- Lua provided by RyzenAPI
-- Game: addappid(823130)

-- MAIN APPLICATION
addappid(823130)

-- MAIN APP DEPOTS / PACKAGES
addappid(823131, 1, "7e190008c73c1ad83bd9b89becea2318a43d57e0a849b355377323220e91e791")
