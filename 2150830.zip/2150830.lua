-- Lua provided by RyzenAPI
-- Game: 黄泉：孤岛惊魂

-- MAIN APPLICATION
addappid(2150830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2150832,0,"78aab0cf76109ee14f93dd17c03275bc6107e7eeb0398c20be760ac773a5e129")
addappid(2150833,0,"ed8742f5973beaa65d447bcfdef47dbb6a90162a839f108fc4ba54626d191879")
addtoken(2150830,"9569488870928695832")

