-- Lua provided by RyzenAPI
-- Game: The Backrooms: Mass Extinction Demo

-- MAIN APPLICATION
addappid(2061570)
-- Game: addappid(2061570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2061571, 1, "72ccd35ff81d3b33beb326ef9345eccbd708126a695063b38bb28a2196888306")
