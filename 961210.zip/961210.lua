-- Lua provided by RyzenAPI
-- Game: 7-minute HOP

-- MAIN APPLICATION
addappid(961210)

-- MAIN APP DEPOTS / PACKAGES
addappid(961211, 1, "912400d088cf898b0f23db554cf37c8243d489ff6d1214836dcc5f4282d64dab")

