-- Lua provided by RyzenAPI
-- Game: Stellar Watch Demo

-- MAIN APPLICATION
addappid(2249410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249411, 1, "018c0a448767aabc57abe648f7b61204327458dae20a9c1e5211e0e587665927")
