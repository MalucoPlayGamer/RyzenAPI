-- Lua provided by RyzenAPI
-- Game: Game: AppID 1549680

-- MAIN APPLICATION
addappid(1549680)
-- Game: addappid(1549680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549681, 1, "82d4db9210baa75f14d0903b0d3cd0bc55d52373476927d44b55505f87227b7a")
