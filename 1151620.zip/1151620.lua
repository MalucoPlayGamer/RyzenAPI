-- Lua provided by RyzenAPI
-- Game: Game: AppID 1151620

-- MAIN APPLICATION
addappid(1151620)
-- Game: addappid(1151620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1151621, 1, "71e5cd4fc68261dd53909e0ef2da567238a6565eefabba34ef97104a522bbd79")
