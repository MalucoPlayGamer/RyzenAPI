-- Lua provided by SkyAPI 
-- Game: Nova Wing
addappid(787200)
addappid(787201, 1, "edae56ceb5d5b6c4af41c58d86db317329e838823dcf17aa417cd82deacd764e")
