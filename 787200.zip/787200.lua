-- Lua provided by RyzenAPI
-- Game: Nova Wing

-- MAIN APPLICATION
addappid(787200)

-- MAIN APP DEPOTS / PACKAGES
addappid(787201, 1, "edae56ceb5d5b6c4af41c58d86db317329e838823dcf17aa417cd82deacd764e")
