-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2594050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2594050,0,"8cf479dc857abd63a749048d2c481a2d30cccb4c3fa0402abf6ec58e0c2d54cc")

