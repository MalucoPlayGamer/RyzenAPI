-- Lua provided by RyzenAPI
-- Game: UFO Simulator Control Master

-- MAIN APPLICATION
addappid(848070)

-- MAIN APP DEPOTS / PACKAGES
addappid(848071,0,"81a5185387859089777d7553c32811193f7c7495b9bccee8fffbffd4d4e6cba8")

