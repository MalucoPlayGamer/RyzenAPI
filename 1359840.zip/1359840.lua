-- Lua provided by RyzenAPI
-- Game: Game: Lockdown Hero

-- MAIN APPLICATION
addappid(1359840)
-- Game: addappid(1359840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359841, 1, "1cd9f7e3536f7b9d136da271a13995e62893dc6ab76dd4d7a395391dee3edd73")
