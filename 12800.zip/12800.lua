-- Lua provided by RyzenAPI
-- Game: 12800

-- MAIN APPLICATION
addappid(12800)
-- Game: addappid(12800)

-- MAIN APP DEPOTS / PACKAGES
addappid(12801, 1, "15e9fc6b41a6aaa487d6f40aab10935309539ffab42feef113b81f933363d8eb")
