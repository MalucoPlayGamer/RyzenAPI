-- Lua provided by RyzenAPI
-- Game: 1558490

-- MAIN APPLICATION
addappid(1558490)
-- Game: addappid(1558490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558491, 1, "4e2da9fdf087d32bc55ece6476bef9e7f1b0ea2f9346bcee29ac5b9381a84bae")
