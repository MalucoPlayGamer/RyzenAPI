-- Lua provided by RyzenAPI
-- Game: Firelight Fantasy: Resistance

-- MAIN APPLICATION
addappid(1558490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558491, 1, "4e2da9fdf087d32bc55ece6476bef9e7f1b0ea2f9346bcee29ac5b9381a84bae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
