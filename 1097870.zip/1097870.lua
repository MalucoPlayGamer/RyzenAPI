-- Lua provided by RyzenAPI
-- Game: 1097870

-- MAIN APPLICATION
addappid(1097870)
-- Game: addappid(1097870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097871, 1, "12f03c7082b41b0e9511fce190d9b032e17a71fc98992e89dcd607c0ef480f23")
