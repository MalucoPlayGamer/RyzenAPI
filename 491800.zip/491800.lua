-- Lua provided by RyzenAPI
-- Game: Across The Line

-- MAIN APPLICATION
addappid(491800)

-- MAIN APP DEPOTS / PACKAGES
addappid(491801, 1, "2463b5b8ad4f4b860e5f5257e7a6b1ef5f221d88be9ff557851dd409f8158df6")

