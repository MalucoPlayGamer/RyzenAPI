-- Lua provided by RyzenAPI
-- Game: The Quiet Things Demo

-- MAIN APPLICATION
addappid(2828480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2828481, 1, "3cdc6d09ed24de1a977716a3ca185c18bd0808c89e16a79a111685194e0f2aa7")

