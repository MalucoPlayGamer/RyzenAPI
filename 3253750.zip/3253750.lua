-- Lua provided by RyzenAPI
-- Game: Strange Stories of the Universe Demo

-- MAIN APPLICATION
addappid(3253750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3253751, 1, "224515a7173a15fb0edb80609daa04971c4d908a03e7c48306897866a630f732")
