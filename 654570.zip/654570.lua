-- Lua provided by RyzenAPI
-- Game: History2048 - 3D puzzle number game

-- MAIN APPLICATION
addappid(654570)

-- MAIN APP DEPOTS / PACKAGES
addappid(654571, 1, "bd9d035454f155715bcefbc6d2982bc1bf65a72c5fe16d22763771f187602212")
