-- Lua provided by RyzenAPI
-- Game: Monument

-- MAIN APPLICATION
addappid(376730)

-- MAIN APP DEPOTS / PACKAGES
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(376731, 1, "3fccd380201ce59666c0e59c12c25a9c57aa6a467e37feede32299832b62995f")
addappid(376732, 1, "74680eebb7864bc3b81d83c41c38815699a5d77272c73a5b502ad4c8dd3784f3")
addappid(376733, 1, "90ca89c7437fbb52a97084994970ecdcdd898de6f3d7681f31f595fa91c57e8a")

