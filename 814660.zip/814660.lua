-- Lua provided by SkyAPI 
-- Game: AppID 814660
addappid(814660)
addappid(814661, 1, "61c8f41f0da54dca55e8fde536eec7a00e419fb275468fd13dda70a3d0a3cc29")
addappid(1040300, 0, "1ada5418967a642650638ddea236098cf3e52dc912f214118724107ca7c20c87")
