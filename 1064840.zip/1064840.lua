-- Lua provided by RyzenAPI
-- Game: Tamarin

-- MAIN APPLICATION
addappid(1064840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064841, 1, "bcd420aba697793ee5797e26f7bf891c94362303154e2dc83da534302c31519d")

