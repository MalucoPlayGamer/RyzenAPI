-- Lua provided by SkyAPI 
-- Game: Streamer Life Simulator 2
addappid(2890830)
addappid(2890831, 1, "f266168cbca0fdbad69d36ca8ed9187480ed8adf90c68090ebea91b92757a77e")
