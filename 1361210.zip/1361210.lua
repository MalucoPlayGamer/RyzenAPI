-- Lua provided by SkyAPI 
-- Game: Warhammer 40,000: Darktide
addappid(1361210)
addappid(1361211, 1, "91a13a5dcfb61da0b70e706684905b0c2aa90d8287d89e17507c0b94bc0f6e62")
addappid(1361212, 1, "4d49f54fcf910bba344e8488b85616043a21cf7d6d486b8ad37085ffc6bf9401")
addappid(1361213, 1, "5b665c11f3ab71ed186993ab184691c52af53a8d86ffd0c2fd8fbc8ec33b757d")
