-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Darktide

-- MAIN APPLICATION
addappid(1361210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361211, 1, "91a13a5dcfb61da0b70e706684905b0c2aa90d8287d89e17507c0b94bc0f6e62")
addappid(1361212, 1, "4d49f54fcf910bba344e8488b85616043a21cf7d6d486b8ad37085ffc6bf9401")
addappid(1361213, 1, "5b665c11f3ab71ed186993ab184691c52af53a8d86ffd0c2fd8fbc8ec33b757d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1981790)
addappid(2215000)
addappid(3710910)
addappid(3710950)
addappid(3710980)
addappid(4013290)
addappid(4013300)
addappid(4013310)
addappid(4355570)
addappid(4355580)
addappid(4355590)
