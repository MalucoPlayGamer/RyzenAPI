-- Lua provided by RyzenAPI
-- Game: Game: Alicemare

-- MAIN APPLICATION
addappid(524850)
-- Game: addappid(524850)

-- MAIN APP DEPOTS / PACKAGES
addappid(524851, 1, "ec19e3f6238628025d3b91f7a87c0fdb4a7a5f5b604cdc98c88c6dd75cf5c394")
addappid(524852, 1, "cc3c64c3d663717cb5f1e017abe2e5a77805a7406047113729266d353def960f")
addappid(524853, 1, "30cc457fb409403fc86e2678d6af3f487d03f9f61d87e5a028169413e80e0f8b")
addappid(524854, 1, "b47ea28abf0d1949a8560a57b563da4a59aa53141f917b2733c1e1d3cdcebbc8")
