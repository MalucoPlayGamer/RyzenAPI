-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Fantasy Heroine Character Pack 7

-- MAIN APPLICATION
addappid(1405600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1405600,0,"dc6a3181747aed5ad0d61743a72779e35013d50189a597d313f53be485e46018")

