-- Lua provided by SkyAPI 
-- Game: Shades of Sakura
addappid(1678140)
addappid(1678141, 1, "7768cb51f72f6fa4bee7fa9e4208d02b25c10f24d078cab93dad95be7a855f6c")
addappid(1697260, 0, "1eafdaaa41d4d3bd9c7b34430254803660e2b5782a9b242ab8b15a28d8116c51")
addappid(1700360, 0, "1566c0cee5caf136b73096a572407542941d2ce5293e8c5a672800ecb764ec07")
