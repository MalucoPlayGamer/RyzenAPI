-- Lua provided by SkyAPI 
-- Game: Junkyard Simulator
addappid(671970)
addappid(671971, 1, "ad7914c55b562ea713dcecf9f83ce5a6d28d98ce161066b5b7011f2f7c8a81e9")
