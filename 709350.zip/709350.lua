-- Lua provided by RyzenAPI
-- Game: addappid(709350)

-- MAIN APPLICATION
addappid(709350)

-- MAIN APP DEPOTS / PACKAGES
addappid(709351, 1, "a3638d9b0440dfbb230d4ae1d04e738442480fca639ffb29fc978227f0b0bd46")
