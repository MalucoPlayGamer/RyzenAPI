-- Lua provided by RyzenAPI
-- Game: Elderine: Dreams to Destiny

-- MAIN APPLICATION
addappid(535350)
addappid(579140)

-- MAIN APP DEPOTS / PACKAGES
addappid(535351,0,"e86a6c1b4681c2f1111d09e5cea52a10d4ecb6f984183fe4874f445caeb2135b")

