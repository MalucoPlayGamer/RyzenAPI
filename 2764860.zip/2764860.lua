-- Lua provided by RyzenAPI
-- Game: 2764860

-- MAIN APPLICATION
addappid(2764860)
-- Game: addappid(2764860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2764861, 1, "d651c79a6d588cf0bfbd6f11bbeed58215e244ff411192880552551d6ac8fcbb")
