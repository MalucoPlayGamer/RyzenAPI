-- Lua provided by RyzenAPI
-- Game: Game: A Dump in the Dark

-- MAIN APPLICATION
addappid(577080)
-- Game: addappid(577080)

-- MAIN APP DEPOTS / PACKAGES
addappid(577081, 1, "86b05119c80af4a700431500394be69f1ca5b3cec90bd744a3e39ccecb7c660c")
