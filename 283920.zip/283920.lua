-- Lua provided by RyzenAPI
-- Game: Putt-Putt Joins the Parade

-- MAIN APPLICATION
addappid(283920)

-- MAIN APP DEPOTS / PACKAGES
addappid(283921, 1, "ea1ea5d5d930e8a3f4474d39607169327a04175e1caeccfd72fe2e10004311c9")
addappid(283924, 1, "58e60d7e0b0b2ef01e33c904332297dc297b36b61e2344ff51c2de4c030ea883")
addappid(283925, 1, "690c4fbf56612b7663dbb5350711df0a7b6c5886ef2a311c80f7ffed49a4c5d4")
