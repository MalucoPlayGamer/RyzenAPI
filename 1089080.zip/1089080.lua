-- Lua provided by SkyAPI 
-- Game: Superstar Hero
addappid(1089080)
addappid(1089081, 1, "960c2a56487333753d4a930d9e6ec8650245cb2c001fbd350f3ac57c44eb18bb")
