-- Lua provided by RyzenAPI
-- Game: 1089080

-- MAIN APPLICATION
addappid(1089080)
-- Game: addappid(1089080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089081, 1, "960c2a56487333753d4a930d9e6ec8650245cb2c001fbd350f3ac57c44eb18bb")
