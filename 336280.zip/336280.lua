-- Lua provided by RyzenAPI
-- Game: 336280

-- MAIN APPLICATION
addappid(336280)
-- Game: addappid(336280)

-- MAIN APP DEPOTS / PACKAGES
addappid(336281, 1, "b951ad8825806a8d572de1ba3db3d367ef9a7bf846a44eda7648ae59581d58d5")
