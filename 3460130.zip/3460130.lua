-- Lua provided by RyzenAPI
-- Game: LockYourDoor Demo

-- MAIN APPLICATION
addappid(3460130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3460131, 1, "7c1a606ac8019410432d66301516fc9b51879c5f3eb70e9471cfaacf7194ac9b")

