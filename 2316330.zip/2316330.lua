-- Lua provided by RyzenAPI
-- Game: Shogun Showdown: Prologue

-- MAIN APPLICATION
addappid(2316330)

