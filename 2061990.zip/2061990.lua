-- Lua provided by RyzenAPI
-- Game: The Pedestrian Digital Artbook

-- MAIN APPLICATION
addappid(2061990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2061990,0,"af7f456baac74501925d7a3d7e320450bcfe36856fabd12ccb38098d17737ebf")

