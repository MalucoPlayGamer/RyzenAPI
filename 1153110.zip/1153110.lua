-- Lua provided by RyzenAPI
-- Game: Rally Drift Cars

-- MAIN APPLICATION
addappid(1153110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153111, 1, "b547ffd6c404941024a5ee764667dd4d241a0a9415e6fdab86381b237b551973")
