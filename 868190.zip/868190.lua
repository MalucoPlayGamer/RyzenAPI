-- Lua provided by RyzenAPI
-- Game: Sapper boom!

-- MAIN APPLICATION
addappid(868190)

-- MAIN APP DEPOTS / PACKAGES
addappid(868191,0,"d9e1c687a6e221de2bf675004d7d2b6ebadae09959f42a6d25238dc2ac738288")

