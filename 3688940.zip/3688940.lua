-- Lua provided by RyzenAPI
-- Game: Zefyr: A Thief's Melody - Supporter DLC

-- MAIN APPLICATION
addappid(3688940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3688940,0,"aa42e4836a17b1882be02035534c50614d63f7a7b0bb8800e44be4832c638e33")

