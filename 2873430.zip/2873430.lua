-- Lua provided by RyzenAPI
-- Game: Game: AppID 2873430

-- MAIN APPLICATION
addappid(2873430)
-- Game: addappid(2873430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2873431, 1, "c7dfe345920ae3a91f6cd64a0b60f3b0f2c175d71600d2f05ec72cf0ff5b760a")
