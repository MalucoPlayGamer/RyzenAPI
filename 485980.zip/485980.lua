-- Lua provided by RyzenAPI
-- Game: Syrian Warfare

-- MAIN APPLICATION
addappid(485980)
addappid(938490)

-- MAIN APP DEPOTS / PACKAGES
addappid(485981, 1, "63f6fb6dc81b9a19d9e9d8a250dae031e7dc2b4664231150df12e746d646487d")
addappid(485982, 1, "81fc5a8b50ecd9d04ab187882af770ce9b4a23a03e98557c8ba21bfe1f7ca400")
addappid(485983, 1, "e1a8017bfbc0c00d85b83a47dc9d5826f9f21b990fcdfad2ca1e7a26e51c0b6e")
addappid(485984, 1, "ef8b80c66f2ebbd4c7ae3d9364ba9c7731ebcbfce28a1e4ce7d443e3a8171566")
addappid(485985, 1, "a7a4228106ce5217c4cd271260779c7aefdbc80198852ed1147de177d68fb83c")
addappid(485986, 1, "d150e3160b0cc0ef230caa7a81d55183fdd575401f53ae95182f183dd1fdf2a3")
addappid(485987, 1, "1859e5b64f9bfb6866287476d141b062900a52d9865c70eb2b8f87ad2ae8150a")
addappid(485988, 1, "ea0864f7196d767a4cf825e8a90b745b94906beb022a19fbe78ff7e4021e8cb4")
addappid(485989, 1, "852f7c9f0bf3e6d7acc958b8253370f6b367fb91161278b4790c4b9576138835")
addappid(599050, 0, "8a033587fe23c4c51768cdf967152908dc9b44119e75ff0ab5cab0bac42e079b")
addappid(635030, 0, "f668b8feed4af17fbaf6e7b83e39ed19ea76358bdab0741d20e93205324e58bf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
