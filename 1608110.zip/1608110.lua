-- Lua provided by RyzenAPI
-- Game: addappid(1608110)

-- MAIN APPLICATION
addappid(1608110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608111, 1, "ef80353dfe5113595d089dbe86b6d5f3da4386c770b7ab663843d901bd64c651")
