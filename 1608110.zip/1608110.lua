-- Lua provided by RyzenAPI
-- Game: Splash Girls

-- MAIN APPLICATION
addappid(1608110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1608111, 1, "ef80353dfe5113595d089dbe86b6d5f3da4386c770b7ab663843d901bd64c651")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
