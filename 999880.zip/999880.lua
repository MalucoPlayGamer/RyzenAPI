-- Lua provided by RyzenAPI 
-- Game: NASA's Exoplanet Excursions
addappid(999880)
addappid(999881, 1, "199df8d046bd5003510efcbff88299c42faec7adf052832d1c2119b06649afca")
