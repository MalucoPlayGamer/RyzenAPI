-- Lua provided by RyzenAPI
-- Game: NASA's Exoplanet Excursions

-- MAIN APPLICATION
addappid(999880)
-- Game: addappid(999880)

-- MAIN APP DEPOTS / PACKAGES
addappid(999881, 1, "199df8d046bd5003510efcbff88299c42faec7adf052832d1c2119b06649afca")
