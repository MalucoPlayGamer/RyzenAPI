-- Lua provided by RyzenAPI 
-- Game: Valefor
addappid(2886470)
addappid(2886471, 1, "b320e93b04842c73cca58764432099206645918746ac10d2bad04a5677f8f1cb")
