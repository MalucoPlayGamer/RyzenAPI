-- Lua provided by RyzenAPI
-- Game: 1134200

-- MAIN APPLICATION
addappid(1134200)
-- Game: addappid(1134200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134201, 1, "70ba7ca3cc09a0dd54fe27e26bfd12e2501cd9c455fb858394e25b77359644db")
