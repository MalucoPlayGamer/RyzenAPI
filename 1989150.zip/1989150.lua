-- Lua provided by RyzenAPI
-- Game: Thread

-- MAIN APPLICATION
addappid(1989150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989152,0,"de9d7857145ecca8768d11dfa05c791f281d6b89a34cd79d7602cf04b9a14456")

