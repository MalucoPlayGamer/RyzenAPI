-- Lua provided by SkyAPI 
-- Game: AppID 17730
addappid(17730)
addappid(17731, 1, "de5e26dfe655dba3671055153e8f189122103449bc2661dcdeadc334c4d3112a")
