-- Lua provided by RyzenAPI
-- Game: Geckorientalism_Demo

-- MAIN APPLICATION
addappid(3037760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3037769,0,"10112a81a2e77f6931b4e449cd4f8022a03dff1c9bc10479474209f2badac845")
