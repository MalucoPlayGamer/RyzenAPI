-- Lua provided by RyzenAPI
-- Game: PRO EVOLUTION SOCCER 2018 LITE

-- MAIN APPLICATION
addappid(592600)
addappid(625540)
addappid(625541)
addappid(625542)
addappid(625543)
addappid(625545)
addappid(625546)
addappid(625547)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(592601, 1, "81c84dd28a7eab51f8ced2707d680da4eb6ccdff6768e375fd860a3163717aed")
addappid(592602, 1, "cf2847779fbff65f52f65e5f61238b802c4e2291d7102e9b5362da27283ca5bc")
addappid(625544, 0, "f0173574792195aa46d9394bb44f5becb8704f6cfd2ebac53271ce8841eaf873")

