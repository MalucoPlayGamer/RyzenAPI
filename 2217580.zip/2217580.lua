-- Lua provided by RyzenAPI
-- Game: New Star™ GP

-- MAIN APPLICATION
addappid(2217580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2217581, 1, "94ee113568e147cb7d7aab0385228c0803ecee39e034bd932f7107fb9a97e33b")
