-- Lua provided by RyzenAPI
-- Game: City Eye

-- MAIN APPLICATION
addappid(759080)

-- MAIN APP DEPOTS / PACKAGES
addappid(759081,0,"0656f3430109573655cab20aaee2881cfb29b0b0fedc2551295c9478f047d231")

