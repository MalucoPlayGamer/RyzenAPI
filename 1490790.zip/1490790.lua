-- Lua provided by RyzenAPI
-- Game: Christmas Adventures: A Winter Night's Dream

-- MAIN APPLICATION
addappid(1490790)
-- Game: addappid(1490790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1490791, 1, "683b1e6823daf87ca361d2bf6f88e6c8bb30eb8f872b0eedc0f64713cfcc6a34")
