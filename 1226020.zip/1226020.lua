-- Lua provided by RyzenAPI
-- Game: 机忆

-- MAIN APPLICATION
addappid(1226020)
-- Game: addappid(1226020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226021, 1, "d8f2f7a5fb9ca2ecdc257ff86b0a8eabfacff5119d12a19992bc2f71a14e653f")
