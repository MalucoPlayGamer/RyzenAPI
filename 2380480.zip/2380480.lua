-- Lua provided by RyzenAPI
-- Game: Game: ALMOST Playtest

-- MAIN APPLICATION
addappid(2380480)
-- Game: addappid(2380480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2380481, 1, "c6e78360b821dbe3da1b55ee61533526e1d9eb2241632c05e305df2c3d0c4efb")
