-- Lua provided by RyzenAPI 
-- Game: Cry Babies Magic Tears: The Big Game
addappid(2458250)
addappid(2458251, 1, "2c12f5f2dd56e4110247b98de503ae5b887d7a0885eb089fc8bfb2a5e21606e1")
