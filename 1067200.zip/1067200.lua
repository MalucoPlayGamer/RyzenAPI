-- Lua provided by RyzenAPI
-- Game: AppID 1067200

-- MAIN APPLICATION
addappid(1067200)
addappid(1131850)
addappid(1332980)
-- Game: addappid(1067200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1067201, 1, "aadb38ba5bcc7a7bf24fe4c2c2e996a0825c5e0f33378e2a3854e887e8a220ab")
