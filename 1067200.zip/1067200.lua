-- Lua provided by RyzenAPI
-- Game: Plagueworld

-- MAIN APPLICATION
addappid(1067200)
addappid(1131850)
addappid(1332980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1067201, 1, "aadb38ba5bcc7a7bf24fe4c2c2e996a0825c5e0f33378e2a3854e887e8a220ab")

