-- Lua provided by RyzenAPI
-- Game: Trials Fusion™

-- MAIN APPLICATION
addappid(245490)
addappid(287330)
addappid(287410)
addappid(287411)
addappid(297600)
addappid(297601)
addappid(311550)
addappid(311551)
addappid(326170)
addappid(337740)
addappid(337750)
addappid(355770)
addappid(381840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(245491, 1, "e44218247bc22153f73511eb618b0364fb6007571dbba9879087eaef3b6b8cfe")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")

