-- Lua provided by RyzenAPI
-- Game: Game: Trials Fusion™

-- MAIN APPLICATION
addappid(245490)
-- Game: addappid(245490)

-- MAIN APP DEPOTS / PACKAGES
addappid(245491, 1, "e44218247bc22153f73511eb618b0364fb6007571dbba9879087eaef3b6b8cfe")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
