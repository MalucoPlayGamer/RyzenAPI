-- Lua provided by RyzenAPI
-- Game: 1990590

-- MAIN APPLICATION
addappid(1990590)
-- Game: addappid(1990590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990591, 1, "56cb7ffa461c2ab41048b35f0ab4331bea6c849e29007d9e025264016d489ab8")
