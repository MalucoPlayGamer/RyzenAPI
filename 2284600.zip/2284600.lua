-- Lua provided by RyzenAPI
-- Game: Codex Lost

-- MAIN APPLICATION
addappid(2284600)
-- Game: addappid(2284600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2284601, 1, "85dff7b13ebc63b03b4e17d8db02b07fd42e4253e46a96e72808dfad9a22a0e6")
