-- Lua provided by RyzenAPI
-- Game: Letsss Play

-- MAIN APPLICATION
addappid(4050230)

-- MAIN APP DEPOTS / PACKAGES
addappid(4050231,0,"76d36ef3aaf2552d568df2fd3fd02619fa73d51e1ef66fd31966cf71ec4d9810")

