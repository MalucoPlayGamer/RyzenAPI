-- Lua provided by RyzenAPI
-- Game: Letsss Play

-- MAIN APPLICATION
addappid(4050230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4050231,0,"76d36ef3aaf2552d568df2fd3fd02619fa73d51e1ef66fd31966cf71ec4d9810")

