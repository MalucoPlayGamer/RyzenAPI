-- Lua provided by RyzenAPI
-- Game: Merge & Blade Demo

-- MAIN APPLICATION
addappid(1488880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1488881, 1, "0fc7e042000f50831993bd5ff0e9eebfd09454fefb0b6742abed763d86a89346")

