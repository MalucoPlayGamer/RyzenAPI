-- Lua provided by RyzenAPI
-- Game: Cross Maid

-- MAIN APPLICATION
addappid(1424870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424871, 1, "3c81376aac15dbb11700f7d6b774fa6b4b0a3c6ba2de67f09ff57214bffd4bec")

