-- Lua provided by RyzenAPI
-- Game: Game: Inexplicable Deaths In Damipolis: Inner Thoughts

-- MAIN APPLICATION
addappid(1341430)
-- Game: addappid(1341430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341431, 1, "418cebad944528f8cb84395757ed9e14f89fc67cfdd7960273aefadc2c42f3cc")
