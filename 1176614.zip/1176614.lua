-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4 Ultimate - Special Costume for Hades

-- MAIN APPLICATION
addappid(1176614)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176614,0,"7e91477853a75217aceb7945f0e2de64915c36e6a6057a933ed9955fd4f19593")

