-- Lua provided by RyzenAPI
-- Game: 1080510

-- MAIN APPLICATION
addappid(1080510)
-- Game: addappid(1080510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1080510,0,"7b046f17d4f778d42383794a6b9d88cc7fb0e3dd2af420d70e97696a46f0eb91")
