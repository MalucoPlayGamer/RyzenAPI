-- Lua provided by RyzenAPI
-- Game: Mondly: Learn Languages in VR

-- MAIN APPLICATION
addappid(1141930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141931, 1, "b32be087e55079e316d986addd64e39e722e53302461f7c8d18f0a81bc94bf1f")
