-- Lua provided by RyzenAPI
-- Game: Fast Food Never More

-- MAIN APPLICATION
addappid(1201620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201621, 1, "5377e7e21b891b2aa2ac20a3f652fb5ed7e42efd0c10e936ef69e51da026c457")

