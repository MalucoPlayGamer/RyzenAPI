-- Lua provided by RyzenAPI
-- Game: Sweet Toys Simulator

-- MAIN APPLICATION
addappid(3770980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3770981, 1, "1280d3526eeb53163af6a043db15a2df858888ecea2c256a98eff362efe5ad05")
