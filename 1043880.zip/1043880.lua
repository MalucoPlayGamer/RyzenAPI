-- Lua provided by RyzenAPI
-- Game: Hentai Clouds

-- MAIN APPLICATION
addappid(1043880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043881, 1, "ef2f0e2bf83faa3fcb796db805831404036f47513c530cb6fc161e90d7c1b612")

