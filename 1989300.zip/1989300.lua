-- Lua provided by RyzenAPI
-- Game: AppID 1989300

-- MAIN APPLICATION
addappid(1989300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989301, 1, "6406d8ab27e1e8e3ad8c7ea163609c4dad6dd012a1ddd5b6b2c7825c34061f44")

