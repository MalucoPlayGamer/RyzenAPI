-- Lua provided by RyzenAPI
-- Game: 接触: 第一章(The Encounter: Chapter One)

-- MAIN APPLICATION
addappid(2498580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2498581, 1, "3d0a55b3e1b44665233243f25753692263352f3e639ca472b6c998b92e6b00a2")

