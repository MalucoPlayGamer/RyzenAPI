-- Lua provided by RyzenAPI
-- Game: Game: Lust Theory - Season 1

-- MAIN APPLICATION
addappid(1607130)
-- Game: addappid(1607130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607131, 1, "34a2e19836c47d58fea934474d66310da4b8c9cbaddee722d66827c7e1997e58")
addappid(2177670, 0, "26933dd3e70666a27b8ed940ac1e940807d9189b896990bceaa4c0a2a18edb82")
