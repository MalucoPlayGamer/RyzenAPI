-- Lua provided by RyzenAPI
-- Game: lizards vs Slavs : Arena

-- MAIN APPLICATION
addappid(2858340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2858341, 1, "a851bcd9238d85990d36db5e36b61f081c01606108aa7e4715effbcc15a77347")

