-- Lua provided by SkyAPI 
-- Game: lizards vs Slavs : Arena
addappid(2858340)
addappid(2858341, 1, "a851bcd9238d85990d36db5e36b61f081c01606108aa7e4715effbcc15a77347")
