-- Lua provided by RyzenAPI
-- Game: AppID 1166290

-- MAIN APPLICATION
addappid(1166290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166291, 1, "1e8d0c9ff18e0d0561e51dd04f7ba2c50d91f2ed2c1bb928e5ac06af53beccf6")
addappid(1166292, 1, "326a9000d9ccbd69faf3311eeb3d01f08483dd7f95401f0de9d0f76477ef8d87")
addappid(1166293, 1, "ea63c61235a8f3d41bfc24530bd89a87d3b3c90daf411e9feecbaf3403d0e5e0")
