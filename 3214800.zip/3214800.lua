-- Lua provided by RyzenAPI
-- Game: addappid(3214800)

-- MAIN APPLICATION
addappid(3214800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3214801, 1, "703ee7a3368fa33ed1245d8dfe5479fb9f31736de181d549c28c8d492ca79a3f")
