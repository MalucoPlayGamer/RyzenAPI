-- Lua provided by SkyAPI 
-- Game: AppID 2649480
addappid(2649480)
addappid(2649481, 1, "c8eb781eae8b24fa10fbf59a6cd2c74a0068c19afa643ade78e34aae7fc20b88")
