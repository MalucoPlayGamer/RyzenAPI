-- Lua provided by RyzenAPI
-- Game: Sycamore Free

-- MAIN APPLICATION
addappid(2199240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199241, 1, "07d9df2ffb5e27866c745c48b8087e8ee7b7d568d9aaa17da8ec80f907ee47c0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
