-- Lua provided by RyzenAPI
-- Game: Sycamore Free

-- MAIN APPLICATION
addappid(2199240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199241, 1, "07d9df2ffb5e27866c745c48b8087e8ee7b7d568d9aaa17da8ec80f907ee47c0")

