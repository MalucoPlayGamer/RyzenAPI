-- Lua provided by RyzenAPI
-- Game: Halls of Torment

-- MAIN APPLICATION
addappid(2218750)
-- Game: addappid(2218750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218751, 1, "77e405a755a01168f3c593afff3cf026d1e1a98ae9305e5e34f66d3d3646105b")
addappid(2218752, 1, "a7f53da3b69f8caad57110d9a5793e8d27d836945013f56ae01b011d9440b74f")
addappid(3386980, 0, "959c2315ffca5cd7b82d1878582e16e23a8bb1befbcf9f265fd6c2d0c1cf8c52")
