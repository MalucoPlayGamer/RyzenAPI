-- Lua provided by RyzenAPI 
-- Game: TraumaCore Violence
addappid(2284460)
addappid(2284461, 1, "be336d9c4cdc80c880ad427286896c4501dbd03a490dc247b2d7917b4266cf90")
