-- Lua provided by RyzenAPI
-- Game: addappid(1729650)

-- MAIN APPLICATION
addappid(1729650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729651, 1, "790428ed13cd906f6dfe55b0ee3b998a13b47944c5ff23e451ce294814b36ce0")
