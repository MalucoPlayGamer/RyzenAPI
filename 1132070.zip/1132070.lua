-- Lua provided by RyzenAPI
-- Game: addappid(1132070)

-- MAIN APPLICATION
addappid(1132070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1132071, 1, "6c96ed1aac78fadc32a5a4070e6e7d711901077a32a57f090a35cf82fc37fcbc")
