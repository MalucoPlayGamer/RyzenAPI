-- Lua provided by SkyAPI 
-- Game: AppID 268770
addappid(268770)
addappid(268771, 1, "b99bbcb062068388d0c1f6050542e45522500c2a169618cc8c76ffe247d48bfa")
addappid(268772, 1, "d6091cf4d4570926bb0a711d56629e54aed24f772ee043c314f334053a3d191c")
addappid(268773, 1, "29fde36bfa96f9c0c2e84aad25c5adfc71b6fa23c1d2b8c7f1cafc575ca65060")
addappid(785080)
