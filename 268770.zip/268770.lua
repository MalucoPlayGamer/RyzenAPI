-- Lua provided by RyzenAPI
-- Game: Treasure Adventure World

-- MAIN APPLICATION
addappid(268770)
addappid(785080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(268771, 1, "b99bbcb062068388d0c1f6050542e45522500c2a169618cc8c76ffe247d48bfa")
addappid(268772, 1, "d6091cf4d4570926bb0a711d56629e54aed24f772ee043c314f334053a3d191c")
addappid(268773, 1, "29fde36bfa96f9c0c2e84aad25c5adfc71b6fa23c1d2b8c7f1cafc575ca65060")

