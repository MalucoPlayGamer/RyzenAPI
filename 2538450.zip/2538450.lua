-- Lua provided by RyzenAPI 
-- Game: Hitmen Party Demo
addappid(2538450)
addappid(2538451, 1, "d1692bc8704ec6a86aa324cc84d30bb85bed7eeb78e55d9d1e4b452c2c79183f")
