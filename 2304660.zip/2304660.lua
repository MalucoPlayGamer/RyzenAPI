-- Lua provided by RyzenAPI
-- Game: 2304660

-- MAIN APPLICATION
addappid(2304660)
-- Game: addappid(2304660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304661, 1, "ab915c4089c6508ae830d6e4d9fa6410b6879c4484a8edf2714714be3f5df8a2")
