-- Lua provided by RyzenAPI
-- Game: A Twisted Path to Renown

-- MAIN APPLICATION
addappid(2304660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304661, 1, "ab915c4089c6508ae830d6e4d9fa6410b6879c4484a8edf2714714be3f5df8a2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2895460)
addappid(2895470)
