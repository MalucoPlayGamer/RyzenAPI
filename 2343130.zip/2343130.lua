-- Lua provided by SkyAPI 
-- Game: Hollow Mission
addappid(2343130)
addappid(2343131, 1, "65dda9cc8afb7487dd34c86c1f0f0ddc2e4913bccd69d0ac70ba1fec58f068b2")
