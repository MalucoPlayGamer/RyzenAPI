-- Lua provided by RyzenAPI
-- Game: Hollow Mission

-- MAIN APPLICATION
addappid(2343130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2343131, 1, "65dda9cc8afb7487dd34c86c1f0f0ddc2e4913bccd69d0ac70ba1fec58f068b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
