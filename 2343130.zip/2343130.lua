-- Lua provided by RyzenAPI
-- Game: Game: Hollow Mission

-- MAIN APPLICATION
addappid(2343130)
-- Game: addappid(2343130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2343131, 1, "65dda9cc8afb7487dd34c86c1f0f0ddc2e4913bccd69d0ac70ba1fec58f068b2")
