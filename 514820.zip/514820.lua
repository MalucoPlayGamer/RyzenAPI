-- Lua provided by RyzenAPI
-- Game: Wasps!

-- MAIN APPLICATION
addappid(514820)
-- Game: addappid(514820)

-- MAIN APP DEPOTS / PACKAGES
addappid(514821, 1, "83e9ae798ccf28e378ebb7179aecfb686b3d0a807780ed705a7644c1774c1bf8")
