-- Lua provided by RyzenAPI
-- Game: 44100

-- MAIN APPLICATION
addappid(44100)
-- Game: addappid(44100)

-- MAIN APP DEPOTS / PACKAGES
addappid(44101, 1, "a182951c0e6391c50a4d6e1c09c5d407c7378c4d080025332a1249df26912e97")
