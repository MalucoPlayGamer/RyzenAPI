-- Lua provided by SkyAPI 
-- Game: AppID 44100
addappid(44100)
addappid(44101, 1, "a182951c0e6391c50a4d6e1c09c5d407c7378c4d080025332a1249df26912e97")
