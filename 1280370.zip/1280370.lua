-- Lua provided by RyzenAPI
-- Game: AppID 1280370

-- MAIN APPLICATION
addappid(1280370)
-- Game: addappid(1280370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280371, 1, "b39ea9feb008622e2c44ae158615e669f8c638800bb732c96e699f4b8dccca88")
