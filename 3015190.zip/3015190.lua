-- Lua provided by RyzenAPI
-- Game: Rap Pop Jump Core

-- MAIN APPLICATION
addappid(3015190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015191, 1, "a83a9390a7015089f1653451c240d5c10cbe9b7018acb4a1094d0c3843e51376")

