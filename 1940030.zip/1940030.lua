-- Lua provided by RyzenAPI
-- Game: Gas Station Simulator - Can Touch This DLC

-- MAIN APPLICATION
addappid(1940030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1940030,0,"0a6183b31d33d942748a804b209c92164d3c822726e740991f2873e8f2b7fefd")

