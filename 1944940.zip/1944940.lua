-- Lua provided by RyzenAPI
-- Game: Easter Eggstravaganza

-- MAIN APPLICATION
addappid(1944940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1944941, 1, "93c9968dc30c4bbbf9cf7284781923d419d8dd6fe9586c73431ec29d28b96490")

