-- Lua provided by RyzenAPI
-- Game: 1944940

-- MAIN APPLICATION
addappid(1944940)
-- Game: addappid(1944940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1944941, 1, "93c9968dc30c4bbbf9cf7284781923d419d8dd6fe9586c73431ec29d28b96490")
