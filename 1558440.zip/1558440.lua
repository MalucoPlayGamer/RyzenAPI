-- Lua provided by SkyAPI 
-- Game: SPY ESCAPE
addappid(1558440)
addappid(1558441, 1, "d2ae9561a9433cc1827eb3c0d763e01efa7ea840257bebbaa28cc2c6e3d212a6")
