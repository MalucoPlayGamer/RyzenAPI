-- Lua provided by RyzenAPI
-- Game: Christmas Horror

-- MAIN APPLICATION
addappid(1813140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813141, 1, "d09841a2f2aa0b678d31bbd0b73fed487e5593877bc8619d9326561136dbf233")
