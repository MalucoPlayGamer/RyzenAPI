-- Lua provided by RyzenAPI
-- Game: Game: AppID 874760

-- MAIN APPLICATION
addappid(874760)
-- Game: addappid(874760)

-- MAIN APP DEPOTS / PACKAGES
addappid(874761, 1, "d5aca8b1098e6094517c7644433734de5796855f3a846982266ad39b9ebdfe74")
