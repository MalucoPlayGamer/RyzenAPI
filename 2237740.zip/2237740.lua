-- Lua provided by RyzenAPI
-- Game: SOUL COVENANT

-- MAIN APPLICATION
addappid(2237740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2237741, 1, "cd60e4d7beaa6169c6f9f5618dc074fd96ef51be6ca170af7368c92c8b3b0b93")

