-- Lua provided by RyzenAPI
-- Game: FUSER™ - Marlon Kane - "This Is How You Left Me"

-- MAIN APPLICATION
addappid(1644614)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644614,0,"88744d5b366edba564b8d5c9f184576f63fde66d438b11f4ce7cc9d8bc78161c")

