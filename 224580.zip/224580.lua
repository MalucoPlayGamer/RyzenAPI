-- Lua provided by RyzenAPI
-- Game: Arma II: DayZ Mod

-- MAIN APPLICATION
addappid(224580)

-- MAIN APP DEPOTS / PACKAGES
addappid(224581, 1, "b5e25281950d5209da561a41171dbd41832df8742d9306f4eba9828eff8c7b46")

