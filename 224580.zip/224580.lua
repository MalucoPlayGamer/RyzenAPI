-- Lua provided by SkyAPI 
-- Game: Arma II: DayZ Mod
addappid(224580)
addappid(224581, 1, "b5e25281950d5209da561a41171dbd41832df8742d9306f4eba9828eff8c7b46")
