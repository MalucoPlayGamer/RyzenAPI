-- Lua provided by SkyAPI 
-- Game: Orwell's Animal Farm
addappid(1398100)
addappid(1398101, 1, "a120fcd6d807e938911646e478272232281dcd48555532f6d980603c56e68494")
addappid(1398102, 1, "0c443c472bae6d609dc399ce40f4a2ba62104c5ab16c902f2f160549cdd905fd")
