-- Lua provided by RyzenAPI
-- Game: Haven Park Demo

-- MAIN APPLICATION
addappid(1653280)
-- Game: addappid(1653280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653281, 1, "df6ca960c9efdcc1e8375f20623cd7349b5f232958e0724da579a4f347e49493")
