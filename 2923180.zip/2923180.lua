-- Lua provided by RyzenAPI
-- Game: Defense of the Dauntless

-- MAIN APPLICATION
addappid(2923180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2923181, 1, "90a10fd9ff1acfa47dd71576950f4813f007c1b01a49fea4fffb5b311f3c6d06")
