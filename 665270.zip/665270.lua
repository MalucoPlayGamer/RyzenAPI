-- Lua provided by RyzenAPI
-- Game: 弹幕音乐绘 ～风雷幻奏曲～ / Barrage Musical  ~A Fantasy of Tempest~

-- MAIN APPLICATION
addappid(665270)

-- MAIN APP DEPOTS / PACKAGES
addappid(665271, 1, "e86af823b6dd5b24c355b943120b03c2e6ea47c9fc93bb147b1b03bf1a1ef521")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
