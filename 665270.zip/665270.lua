-- Lua provided by RyzenAPI
-- Game: 弹幕音乐绘 ～风雷幻奏曲～ / Barrage Musical  ~A Fantasy of Tempest~

-- MAIN APPLICATION
addappid(665270)

-- MAIN APP DEPOTS / PACKAGES
addappid(665271, 1, "e86af823b6dd5b24c355b943120b03c2e6ea47c9fc93bb147b1b03bf1a1ef521")

