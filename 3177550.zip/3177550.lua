-- Lua provided by RyzenAPI
-- Game: Black Light Kills

-- MAIN APPLICATION
addappid(3177550)
-- Game: addappid(3177550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3177551, 1, "7b314b2ecfa1185206599379aa6a7ee3a751574d717a67ef2e44ce3e0b2bf65a")
