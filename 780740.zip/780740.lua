-- Lua provided by RyzenAPI
-- Game: Silent Footsteps

-- MAIN APPLICATION
addappid(780740)

-- MAIN APP DEPOTS / PACKAGES
addappid(780741,0,"b93d493bea5b2952e774e3d03b6b350d025c7457de9e62215f682f4b459c22bd")

