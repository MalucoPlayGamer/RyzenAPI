-- Lua provided by RyzenAPI
-- Game: addappid(1761530)

-- MAIN APPLICATION
addappid(1761530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761531, 1, "71044c4b82603f9b6c280c98b9bfd7eb29da9bbfc1ee0a2ccb2f65c8f8e071e6")
