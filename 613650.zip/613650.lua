-- Lua provided by RyzenAPI
-- Game: Sudden Strike 3: Last Stand

-- MAIN APPLICATION
addappid(613650)

-- MAIN APP DEPOTS / PACKAGES
addappid(613651, 1, "db504bf31a8e9e744cf0d17a625745d36bcb0f8b9c26abdcd2f1605e45887674")
addappid(613652, 1, "e1aa9d0016422e6801acf0dbc774ab3a15f969082a6594b0f7860c57209e7226")
addappid(613653, 1, "f1bc13c1cb59d80b7fef6877b8e6fd5f4398e22ec02e1c4020f0b7e9b3ace3bb")

