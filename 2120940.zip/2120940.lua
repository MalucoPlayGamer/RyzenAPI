-- Lua provided by RyzenAPI
-- Game: Game: AppID 2120940

-- MAIN APPLICATION
addappid(2120940)
-- Game: addappid(2120940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2120941, 1, "d64464f8d3915127044b3fe60e7968b41e5dc6f9e142e0909d6867953d1ddcd6")
