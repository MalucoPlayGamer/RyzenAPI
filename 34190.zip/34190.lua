-- Lua provided by RyzenAPI
-- Game: Sonic and SEGA All Stars Racing

-- MAIN APPLICATION
addappid(34190)

-- MAIN APP DEPOTS / PACKAGES
addappid(34191, 1, "3efd05bf64157943c2a3e64fb4b6b4e02c43daa0d4c3251c8745d21120bd2b1a")
