-- Lua provided by RyzenAPI
-- Game: Sakura Succubus 4

-- MAIN APPLICATION
addappid(1466690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1466691, 1, "48210f1731a5bcf4701bd2916df194f6ed68c021b8ccceb3ad87c89c99820ba4")
