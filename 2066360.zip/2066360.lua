-- Lua provided by RyzenAPI
-- Game: Yumahorome ~Toki o Tometa Yakata de Asu o Sagasu Maigo-tachi~

-- MAIN APPLICATION
addappid(2066360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2066361, 1, "80cc1ee83a748893f9e600525fab7bd2ad3a8071aacd5074b1b6fee2a357e9b5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
