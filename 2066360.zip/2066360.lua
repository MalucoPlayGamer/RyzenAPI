-- Lua provided by RyzenAPI 
-- Game: Yumahorome ~Toki o Tometa Yakata de Asu o Sagasu Maigo-tachi~
addappid(2066360)
addappid(2066361, 1, "80cc1ee83a748893f9e600525fab7bd2ad3a8071aacd5074b1b6fee2a357e9b5")
