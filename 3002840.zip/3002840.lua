-- Lua provided by RyzenAPI
-- Game: Game: 荒古战纪

-- MAIN APPLICATION
addappid(3002840)
addappid(3376090)
-- Game: addappid(3002840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3002841, 1, "57fd236558f445c8fe3d0673a0d476bc2633a0e29ed3b80bf6a5a11243b0c535")
addappid(3002842, 1, "5df9dfa525fea7370c26350d27b023fc61b9a22f79f828fa727c7c2feaefc6c9")
addappid(3002843, 1, "10d14b7c5fd13083e01c8772113e2a211485f70a07accf69d86d053576e6c802")
addappid(3002844, 1, "00522ae04e42a428399b6dac84dd753311ce72d213ccbb54e3dd6aeb30bd130c")
