-- Lua provided by RyzenAPI
-- Game: 966760

-- MAIN APPLICATION
addappid(966760)
-- Game: addappid(966760)

-- MAIN APP DEPOTS / PACKAGES
addappid(966761, 1, "e6afaef929983a9ad56cb841f8cc3552425651afb88664b7015a149cbfbc24c3")
addappid(966762, 1, "2fe62e51e5c325c9a2e142d4e6c1fd5789385017929957d3c7ab60aabdd1c546")
