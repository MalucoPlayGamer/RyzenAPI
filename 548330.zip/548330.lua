-- Lua provided by RyzenAPI
-- Game: Wheely

-- MAIN APPLICATION
addappid(548330)
-- Game: addappid(548330)

-- MAIN APP DEPOTS / PACKAGES
addappid(548331, 1, "de6cecca9a4d203d9abdd4a4f93935507c202bb0e3d2b234d0284f62fc24c76d")
