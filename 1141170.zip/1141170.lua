-- Lua provided by RyzenAPI
-- Game: 1141170

-- MAIN APPLICATION
addappid(1141170)
-- Game: addappid(1141170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141171, 1, "d4506a06fd18399b6e94d684b83fd781f652dc13b520fadd61e190fea610924e")
