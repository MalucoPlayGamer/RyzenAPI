-- Lua provided by RyzenAPI
-- Game: hopeless.

-- MAIN APPLICATION
addappid(1995280)
addappid(2339770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995281, 1, "87891a75eaca11afccb6801b16cea2af9929800dcad1789d95ecc3769102877e")
