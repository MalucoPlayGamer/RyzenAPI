-- Lua provided by SkyAPI 
-- Game: AppID 3015390
addappid(3015390)
addappid(3015391, 1, "1815e890310136ef687850ad23802eca1e385b13a5716e5cfdae60628346432e")
