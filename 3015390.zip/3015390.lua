-- Lua provided by RyzenAPI
-- Game: Intravenous 2 Demo

-- MAIN APPLICATION
addappid(3015390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015391, 1, "1815e890310136ef687850ad23802eca1e385b13a5716e5cfdae60628346432e")

