-- Lua provided by RyzenAPI
-- Game: Pirate Jump 2

-- MAIN APPLICATION
addappid(690860)

-- MAIN APP DEPOTS / PACKAGES
addappid(690861, 1, "208deb415d74938790d0a7ca08a09ca96224b2e52abab31e0a17227ab60c3b05")

