-- Lua provided by RyzenAPI
-- Game: AppID 3807780

-- MAIN APPLICATION
addappid(3807780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3807781, 1, "b72ec4656f44f66d3e61b07f07ae8d0f8e7b4d255de8183fba1d3f48b40c7d59")
