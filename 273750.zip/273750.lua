-- Lua provided by RyzenAPI
-- Game: Formula Truck 2013

-- MAIN APPLICATION
addappid(273750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(273751, 1, "6ccbf5504843adc5ac3b2fe43ac8fe5043700e377b848f14cb9bfc96a2a69c12")

