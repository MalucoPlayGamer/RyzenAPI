-- Lua provided by RyzenAPI
-- Game: Game: Formula Truck 2013

-- MAIN APPLICATION
addappid(273750)
-- Game: addappid(273750)

-- MAIN APP DEPOTS / PACKAGES
addappid(273751, 1, "6ccbf5504843adc5ac3b2fe43ac8fe5043700e377b848f14cb9bfc96a2a69c12")
