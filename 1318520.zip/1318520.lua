-- Lua provided by SkyAPI 
-- Game: AppID 1318520
addappid(1318520)
addappid(1318521, 1, "b203e8c16d440e51229b35bdca8ce26ebb329e3f65bd76a0f11b36da5cffa7e8")
