-- Lua provided by RyzenAPI
-- Game: Brukel

-- MAIN APPLICATION
addappid(1073900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1073901, 1, "c0a076bfdba3ee01e2f5c7e9e376a91901452e0844ddd9e1842322779255d5ed")

