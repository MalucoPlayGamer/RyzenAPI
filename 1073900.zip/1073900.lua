-- Lua provided by RyzenAPI
-- Game: Brukel

-- MAIN APPLICATION
addappid(1073900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1073901, 1, "c0a076bfdba3ee01e2f5c7e9e376a91901452e0844ddd9e1842322779255d5ed")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
