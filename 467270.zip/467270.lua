-- Lua provided by RyzenAPI
-- Game: Weaves of Fate

-- MAIN APPLICATION
addappid(467270)

-- MAIN APP DEPOTS / PACKAGES
addappid(467271, 1, "30a36fa3b11375c857b2eb57499e2245a58330e7e501e4299ccd0ccd4b7dee9f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
