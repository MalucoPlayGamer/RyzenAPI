-- Lua provided by RyzenAPI
-- Game: Weaves of Fate

-- MAIN APPLICATION
addappid(467270)

-- MAIN APP DEPOTS / PACKAGES
addappid(467271, 1, "30a36fa3b11375c857b2eb57499e2245a58330e7e501e4299ccd0ccd4b7dee9f")
