-- Lua provided by RyzenAPI 
-- Game: Gun Range VR
addappid(491710)
addappid(491711, 1, "3d1f4531aed868d8565ec3d13fbdc2bada121096a84de6106d0776085ce87427")
