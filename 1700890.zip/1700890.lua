-- Lua provided by RyzenAPI
-- Game: 1700890

-- MAIN APPLICATION
addappid(1700890)
-- Game: addappid(1700890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1700891, 1, "b091a19595b3b4b724ea5b8dc94d94eed0773e9ca275a12da130c790d398f6cb")
