-- Lua provided by SkyAPI 
-- Game: AppID 943230
addappid(943230)
addappid(943231, 1, "cfe43217de617e7810c70740eb980ef76dc4d30805bed7a09950847bcd55ae06")
