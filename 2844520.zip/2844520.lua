-- Lua provided by RyzenAPI
-- Game: Shadows Unveiled: Agnes

-- MAIN APPLICATION
addappid(2844520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2844521, 1, "a9e76de6bf0271b4097d54057c306bb92b5eb842bc82319286f5a9f9b02485b9")

