-- Lua provided by SkyAPI 
-- Game: Shadows Unveiled: Agnes
addappid(2844520)
addappid(2844521, 1, "a9e76de6bf0271b4097d54057c306bb92b5eb842bc82319286f5a9f9b02485b9")
