-- Lua provided by RyzenAPI
-- Game: Trinity

-- MAIN APPLICATION
addappid(778580)

-- MAIN APP DEPOTS / PACKAGES
addappid(778581, 1, "cb892e9884e66d1277462c0325c900897e039063f39a7c2f10e837ec80a32611")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
