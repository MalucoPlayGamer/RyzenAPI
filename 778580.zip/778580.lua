-- Lua provided by RyzenAPI
-- Game: Trinity

-- MAIN APPLICATION
addappid(778580)
-- Game: addappid(778580)

-- MAIN APP DEPOTS / PACKAGES
addappid(778581, 1, "cb892e9884e66d1277462c0325c900897e039063f39a7c2f10e837ec80a32611")
