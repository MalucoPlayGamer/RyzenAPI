-- Lua provided by RyzenAPI
-- Game: Guo Jia - Officer Ticket / 郭嘉使用券

-- MAIN APPLICATION
addappid(956897)

-- MAIN APP DEPOTS / PACKAGES
addappid(956897,0,"8cc210beb59192128f63f6313a4c7c6b3e6b1872087b9169b518ee956e5e3782")

