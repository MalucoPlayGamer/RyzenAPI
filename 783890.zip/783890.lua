-- Lua provided by RyzenAPI
-- Game: BRIGHTEST

-- MAIN APPLICATION
addappid(783890)

-- MAIN APP DEPOTS / PACKAGES
addappid(783891, 1, "47d8ae9eefb074fbe5b402278bb9b81a9d1d579cd4f4cf2576675ab64bc3cd80")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
