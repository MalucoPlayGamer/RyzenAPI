-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Cinematic Soundtrack

-- MAIN APPLICATION
addappid(1661520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661520,0,"3ac1364bfca0ce6168a0b72451779725547b8b13b6793faae58e4bfff681fa31")

