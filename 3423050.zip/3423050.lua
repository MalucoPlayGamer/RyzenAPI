-- Lua provided by RyzenAPI
-- Game: An alien girl fell on my head, and now I must save our world by demonstrating great and beautiful love

-- MAIN APPLICATION
addappid(3423050)
-- Game: addappid(3423050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3423051, 1, "91b6d1aac63b21b849d1dad52e3cc2766fbfa0cf62594572cb94a8fa3b047fae")
