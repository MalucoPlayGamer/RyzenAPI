-- Lua provided by RyzenAPI
-- Game: 3423050

-- MAIN APPLICATION
addappid(3423050)
-- Game: addappid(3423050)

-- MAIN APP DEPOTS / PACKAGES
addappid(3423051, 1, "91b6d1aac63b21b849d1dad52e3cc2766fbfa0cf62594572cb94a8fa3b047fae")
