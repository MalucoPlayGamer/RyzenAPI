-- Lua provided by RyzenAPI
-- Game: addappid(1122577)

-- MAIN APPLICATION
addappid(1122577)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122577,0,"ec4b5c40d95c2581c4d4863de50a06f9c493155257141efa6f69e49c0df1ea4f")
