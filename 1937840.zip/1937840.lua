-- Lua provided by RyzenAPI
-- Game: Stargazing: Genesis

-- MAIN APPLICATION
addappid(1937840)
-- Game: addappid(1937840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937841, 1, "5a076f55d885c4e767dc4828c9eba6784d7efb22db3a940994977bd68f4245b7")
