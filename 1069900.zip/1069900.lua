-- Lua provided by RyzenAPI
-- Game: Private Dance VR

-- MAIN APPLICATION
addappid(1069900)
-- Game: addappid(1069900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069901, 1, "8101836fe72e96d9d8ba5d1440d31c12a95f8e657b7c2d6c09a5af63c0acc7f0")
