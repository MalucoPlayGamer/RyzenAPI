-- Lua provided by RyzenAPI
-- Game: AppID 568300

-- MAIN APPLICATION
addappid(568300)

-- MAIN APP DEPOTS / PACKAGES
addappid(568301, 1, "a08d01feffdbb7b02be0481300c6cfdc9c401b57ab635ec8035af803b417fc8a")
