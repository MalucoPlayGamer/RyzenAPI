-- Lua provided by RyzenAPI
-- Game: AppID 819970

-- MAIN APPLICATION
addappid(819970)

-- MAIN APP DEPOTS / PACKAGES
addappid(819971, 1, "be6100698bb12628bc6237a7302c66631a2930f31572d6696fa4b70ebc2cbb41")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(830830)
