-- Lua provided by RyzenAPI
-- Game: AppID 819970

-- MAIN APPLICATION
addappid(819970)
-- Game: addappid(819970)

-- MAIN APP DEPOTS / PACKAGES
addappid(819971, 1, "be6100698bb12628bc6237a7302c66631a2930f31572d6696fa4b70ebc2cbb41")
