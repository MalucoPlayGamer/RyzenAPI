-- Lua provided by RyzenAPI
-- Game: Game: Sven - Completely Screwed

-- MAIN APPLICATION
addappid(2213500)
-- Game: addappid(2213500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2213501, 1, "9d3f6855cf4315a0dfdc66d69610d6b873e0965039fd86d6339b054f4d0f8784")
