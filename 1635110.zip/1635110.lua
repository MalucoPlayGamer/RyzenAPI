-- Lua provided by RyzenAPI
-- Game: Spirit Of The Island Demo

-- MAIN APPLICATION
addappid(1635110)
-- Game: addappid(1635110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635111, 1, "fd4bee915f458fd1683cef4437c468306d3e1d6e35aeeab757d91554d467dc10")
