-- Lua provided by RyzenAPI
-- Game: 1245300

-- MAIN APPLICATION
addappid(1245300)
-- Game: addappid(1245300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245301, 1, "3a1d23fc38531dfb35dd49ef3a9b8630451328f54cde98b32d4a735dc7d1b1fd")
