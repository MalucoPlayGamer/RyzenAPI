-- Lua provided by RyzenAPI
-- Game: Signal to Noise (2015)

-- MAIN APPLICATION
addappid(380210)
-- Game: addappid(380210)

-- MAIN APP DEPOTS / PACKAGES
addappid(380211, 1, "9cfb50ff81054db83ba731725cc38ddd7452e4f6dde52559e5a96a2f81c5d4a5")
