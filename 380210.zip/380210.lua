-- Lua provided by SkyAPI 
-- Game: Signal to Noise (2015)
addappid(380210)
addappid(380211, 1, "9cfb50ff81054db83ba731725cc38ddd7452e4f6dde52559e5a96a2f81c5d4a5")
