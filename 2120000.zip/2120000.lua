-- Lua provided by RyzenAPI
-- Game: For me Demo

-- MAIN APPLICATION
addappid(2120000)
-- Game: addappid(2120000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2120001, 1, "06aeebf1a725ce0c55d64865d36eafc2647c519197324c3c8338801697a9d3bd")
