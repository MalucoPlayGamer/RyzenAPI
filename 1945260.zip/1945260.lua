-- Lua provided by RyzenAPI
-- Game: 1945260

-- MAIN APPLICATION
addappid(1945260)
-- Game: addappid(1945260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945261, 1, "b6552cb0a84bbac358e39d480a292a0d1fba3004798659efd7582b381826b930")
