-- Lua provided by RyzenAPI
-- Game: 61510

-- MAIN APPLICATION
addappid(61510)
-- Game: addappid(61510)

-- MAIN APP DEPOTS / PACKAGES
addappid(61511, 1, "3907be125424208b6e3e3ddcc158384a8116bf7a8305617e160c0a34052be58e")
