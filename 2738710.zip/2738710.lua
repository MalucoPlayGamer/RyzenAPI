-- Lua provided by RyzenAPI 
-- Game: Planet Mort
addappid(2738710)
addappid(2738711, 1, "71977d10d3cc5240112ae091f468955b54bdf8d942f34c5333b8d67fca9fa8e7")
