-- Lua provided by RyzenAPI
-- Game: Planet Mort

-- MAIN APPLICATION
addappid(2738710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2738711, 1, "71977d10d3cc5240112ae091f468955b54bdf8d942f34c5333b8d67fca9fa8e7")

