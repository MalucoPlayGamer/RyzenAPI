-- Lua provided by RyzenAPI
-- Game: 2738710

-- MAIN APPLICATION
addappid(2738710)
-- Game: addappid(2738710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738711, 1, "71977d10d3cc5240112ae091f468955b54bdf8d942f34c5333b8d67fca9fa8e7")
