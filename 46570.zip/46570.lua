-- Lua provided by RyzenAPI 
-- Game: Grotesque Tactics 2 – Dungeons and Donuts
addappid(46570)
addappid(46571, 1, "06ab1b2248a4b23a5c7f3c97db4a0fd0e06095e1bbb2b328fdbd9095fa33c1ca")
