-- Lua provided by RyzenAPI
-- Game: 871120

-- MAIN APPLICATION
addappid(871120)
-- Game: addappid(871120)

-- MAIN APP DEPOTS / PACKAGES
addappid(871121, 1, "804aa853132d0e307bb9950ee2e055df8fb0969618c5190ad59dd5950d06570b")
