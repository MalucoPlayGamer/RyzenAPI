-- Lua provided by RyzenAPI
-- Game: Summer For You

-- MAIN APPLICATION
addappid(2066980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2066981, 1, "6b86aaa3c0186b88938b716851a58479cf34d43be6b5c769da79de2d446d686a")

