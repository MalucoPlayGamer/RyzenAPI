-- Lua provided by RyzenAPI
-- Game: Moon Defence

-- MAIN APPLICATION
addappid(1495800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495801, 1, "98d8d4d1bc7462d5266e15101dc8f0a98f2262662a2a0c113f52c1f24344d58e")
