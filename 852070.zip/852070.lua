-- Lua provided by RyzenAPI
-- Game: AppID 852070

-- MAIN APPLICATION
addappid(852070)

-- MAIN APP DEPOTS / PACKAGES
addappid(852071, 1, "ef925db38ae3905873f59fc5823d399e785d364a9e73bfae80a20cf4cfab8dad")
