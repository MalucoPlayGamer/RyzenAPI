-- Lua provided by RyzenAPI
-- Game: Carp Fishing Simulator

-- MAIN APPLICATION
addappid(366290)

-- MAIN APP DEPOTS / PACKAGES
addappid(366291, 1, "78800c2075d6f66ac76cc9599dd39023a39982ba59bbcebd7702dd4f5cbd0cb0")

