-- Lua provided by RyzenAPI
-- Game: Game: SudoKats

-- MAIN APPLICATION
addappid(1706190)
-- Game: addappid(1706190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1706191, 1, "c1e7221aeb31f85957ab60835210f85e2ce24714b696f005a0cea8a3564fa7b0")
