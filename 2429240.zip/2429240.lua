-- Lua provided by RyzenAPI
-- Game: Soulslinger: Envoy of Death

-- MAIN APPLICATION
addappid(2429240)
-- Game: addappid(2429240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429241, 1, "53e4a954f1731f3f0a40aa1f67e503a468f4684263f1e00e4f9388cff872553c")
