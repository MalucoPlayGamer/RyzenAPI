-- Lua provided by RyzenAPI
-- Game: Soulslinger: Envoy of Death

-- MAIN APPLICATION
addappid(2429240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2429241, 1, "53e4a954f1731f3f0a40aa1f67e503a468f4684263f1e00e4f9388cff872553c")

