-- Lua provided by RyzenAPI 
-- Game: Soulslinger: Envoy of Death
addappid(2429240)
addappid(2429241, 1, "53e4a954f1731f3f0a40aa1f67e503a468f4684263f1e00e4f9388cff872553c")
