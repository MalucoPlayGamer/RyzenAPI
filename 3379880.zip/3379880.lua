-- Lua provided by RyzenAPI
-- Game: Countermeasure Pioneers: Modern Drone Battlefield

-- MAIN APPLICATION
addappid(3379880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3379881, 1, "8d4fc5cd6294ab74f555e64c761077078c4c4a220cb6c707a5b404222ba4ad63")

