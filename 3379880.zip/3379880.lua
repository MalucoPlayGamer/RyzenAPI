-- Lua provided by RyzenAPI
-- Game: Countermeasure Pioneers: Modern Drone Battlefield

-- MAIN APPLICATION
addappid(3379880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3379881, 1, "8d4fc5cd6294ab74f555e64c761077078c4c4a220cb6c707a5b404222ba4ad63")

