-- Lua provided by RyzenAPI
-- Game: Active Mummy

-- MAIN APPLICATION
addappid(1547900)
-- Game: addappid(1547900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1547901, 1, "79ddd0555de5a84664a0966262773947998b97ae1d1b66ca4704a055663ddba5")
