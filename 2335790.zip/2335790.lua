-- Lua provided by RyzenAPI
-- Game: Future Breach 64

-- MAIN APPLICATION
addappid(2335790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2335791, 1, "1d5e48e2b416c71f478a54acb0e97bc1ecfd9b53b5f90cdbb508a426d1dffd0d")
