-- Lua provided by RyzenAPI
-- Game: AppID 636010

-- MAIN APPLICATION
addappid(636010)

-- MAIN APP DEPOTS / PACKAGES
addappid(636011, 1, "f34b02bed6bd65a87d163b9004186a9b5994c5daebd849ac6f9c0f5086f424db")
addappid(636012, 1, "d25aca2c7197ff47a7bf084c2d4bdb6972b5b0145005f8b1c5729d2fa1dd5baa")
addappid(636013, 1, "ff0d411661144eb8c7114bf0dfc249f3247d0a89f490ee3fdc5092cddabf42dc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
