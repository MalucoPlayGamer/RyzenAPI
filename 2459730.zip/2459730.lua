-- Lua provided by RyzenAPI
-- Game: addappid(2459730)

-- MAIN APPLICATION
addappid(2459730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2459731, 1, "733b75bfa0e7814de9a6c465aac764ec07cad74075d2a3557869a7d476531c30")
addappid(2459732, 1, "ffa2aeba5614ae4dd988c1e07dacf8a7547578d09ab20ad2b230b97453feb16a")
