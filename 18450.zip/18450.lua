-- Lua provided by RyzenAPI
-- Game: Game: AppID 18450

-- MAIN APPLICATION
addappid(18450)
-- Game: addappid(18450)

-- MAIN APP DEPOTS / PACKAGES
addappid(18451, 1, "9116ced51c16b597aed9c24e1059826d04fb14f6c01ab1f7ac866ed726ff6662")
