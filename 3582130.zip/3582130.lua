-- Lua provided by SkyAPI 
-- Game: 破环者 LoopBreaker
addappid(3582130)
addappid(3582131, 1, "2741fd296337aee21c023ac7490261d3f6db9abdef1d1c82aeb272571deaae3e")
