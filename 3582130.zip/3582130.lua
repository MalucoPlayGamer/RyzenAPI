-- Lua provided by RyzenAPI
-- Game: 破环者 LoopBreaker

-- MAIN APPLICATION
addappid(3582130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3582131, 1, "2741fd296337aee21c023ac7490261d3f6db9abdef1d1c82aeb272571deaae3e")
