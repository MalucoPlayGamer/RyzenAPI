-- Lua provided by RyzenAPI
-- Game: 3267800

-- MAIN APPLICATION
addappid(3267800)
-- Game: addappid(3267800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3267800,0,"f770c6897762740855879c63cae6ae64d14e503284b18a0c794cf6df7bfb8cd9")
