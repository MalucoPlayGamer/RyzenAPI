-- Lua provided by RyzenAPI
-- Game: Game: Grave Chase

-- MAIN APPLICATION
addappid(611630)
-- Game: addappid(611630)

-- MAIN APP DEPOTS / PACKAGES
addappid(611631, 1, "43b82b7882a316134f939090851b21498e4d78b1a1ace9fbc8a3325e7c864934")
