-- Lua provided by RyzenAPI 
-- Game: Grave Chase
addappid(611630)
addappid(611631, 1, "43b82b7882a316134f939090851b21498e4d78b1a1ace9fbc8a3325e7c864934")
