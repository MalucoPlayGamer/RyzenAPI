-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9 Useful Gems & Materials Set　（役立つ宝玉・素材セット）（助益多寶玉・素材組合）

-- MAIN APPLICATION
addappid(835590)

-- MAIN APP DEPOTS / PACKAGES
addappid(835590,0,"713d67329656d6275eed859cd81329338400d24444ac721fa3812c11353dd55b")
