-- Lua provided by RyzenAPI
-- Game: My Strange Girlfriends - Artbook 18+

-- MAIN APPLICATION
addappid(1290970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1290970,0,"6e9bd0393b2718a3f10ca7561a277825309210f22910a18a70414facc587ec89")

