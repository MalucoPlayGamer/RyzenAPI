-- Lua provided by RyzenAPI
-- Game: Who wants to strip this babe? (Hentai Teacher)

-- MAIN APPLICATION
addappid(1017520)
-- Game: addappid(1017520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1017521, 1, "967d3e9ce6752714bf06a98971805dc1e0e3e298ae4992c0d918d4ba0d4a1a43")
