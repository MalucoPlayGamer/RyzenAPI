-- Lua provided by RyzenAPI
-- Game: Dream Cycle

-- MAIN APPLICATION
addappid(1105590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(1105591, 1, "d4a52ea4696ad4df5cf285f873b576fd94ee58da68021d08a8f1882c017298ea")

