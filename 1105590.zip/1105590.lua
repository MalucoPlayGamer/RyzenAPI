-- Lua provided by RyzenAPI
-- Game: Game: Dream Cycle

-- MAIN APPLICATION
addappid(1105590)
-- Game: addappid(1105590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1105591, 1, "d4a52ea4696ad4df5cf285f873b576fd94ee58da68021d08a8f1882c017298ea")
