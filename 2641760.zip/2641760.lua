-- Lua provided by RyzenAPI
-- Game: Game: AppID 2641760

-- MAIN APPLICATION
addappid(2641760)
-- Game: addappid(2641760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641761, 1, "fa1cc09d464a6158a93e45211b93d1ca665f0f040bd859aaa55ae41c5717ad6e")
