-- Lua provided by RyzenAPI
-- Game: Gobby McGobblenutz Presents - The Questionably Quirky Quiz Show

-- MAIN APPLICATION
addappid(1719180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719181, 1, "cac1288f0aab29742deb9c148d404f82b5f909fdff1dc1aeea0c2d9ccd1b5779")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
