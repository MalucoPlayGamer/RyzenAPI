-- Lua provided by RyzenAPI
-- Game: addappid(1719180)

-- MAIN APPLICATION
addappid(1719180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719181, 1, "cac1288f0aab29742deb9c148d404f82b5f909fdff1dc1aeea0c2d9ccd1b5779")
