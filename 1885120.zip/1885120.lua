-- Lua provided by SkyAPI 
-- Game: 13 Steps
addappid(1885120)
addappid(1885121, 1, "8ec0e46f788aa6f88112fa909e636e126e21943e1f53ab83ad50290658504c0d")
