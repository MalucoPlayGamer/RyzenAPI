-- Lua provided by RyzenAPI
-- Game: 13 Steps

-- MAIN APPLICATION
addappid(1885120)
-- Game: addappid(1885120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1885121, 1, "8ec0e46f788aa6f88112fa909e636e126e21943e1f53ab83ad50290658504c0d")
