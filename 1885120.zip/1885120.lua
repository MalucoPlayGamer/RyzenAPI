-- Lua provided by RyzenAPI
-- Game: 13 Steps

-- MAIN APPLICATION
addappid(1885120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1885121, 1, "8ec0e46f788aa6f88112fa909e636e126e21943e1f53ab83ad50290658504c0d")

