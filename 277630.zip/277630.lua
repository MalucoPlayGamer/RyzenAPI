-- Lua provided by RyzenAPI
-- Game: AppID 277630

-- MAIN APPLICATION
addappid(277630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(277631, 1, "4bc6b9c8d2600ae6357980d5e61aa7523fface8850ace88373466d559e0cc3c9")

