-- Lua provided by RyzenAPI
-- Game: addappid(277630)

-- MAIN APPLICATION
addappid(277630)

-- MAIN APP DEPOTS / PACKAGES
addappid(277631, 1, "4bc6b9c8d2600ae6357980d5e61aa7523fface8850ace88373466d559e0cc3c9")
