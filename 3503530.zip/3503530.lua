-- Lua provided by SkyAPI 
-- Game: All-Front Assault
addappid(3503530)
addappid(3503531, 1, "460deeec3d513da447699425c004c3d6132456bce3ec3192fbe708eaf1c580a9")
