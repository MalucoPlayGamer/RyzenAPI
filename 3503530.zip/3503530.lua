-- Lua provided by RyzenAPI
-- Game: Game: All-Front Assault

-- MAIN APPLICATION
addappid(3503530)
-- Game: addappid(3503530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3503531, 1, "460deeec3d513da447699425c004c3d6132456bce3ec3192fbe708eaf1c580a9")
