-- Lua provided by RyzenAPI
-- Game: Game: One More Dungeon

-- MAIN APPLICATION
addappid(415030)
-- Game: addappid(415030)

-- MAIN APP DEPOTS / PACKAGES
addappid(415031, 1, "cfba952530cffc41f9a5bd1e7164f254d55c08ecbfdf704806051572594f5015")
addappid(415032, 1, "762ce28a220d1f3b7e382d5361ffd6244a90d089c82a15995d363423a0f2d720")
addappid(415033, 1, "cd205a9ce4cd64db288b575d9861d01fa9f66f2d7a641515b77c596f280b2e53")
