-- Lua provided by RyzenAPI
-- Game: Game: Fantasy Match -Make a H match with cute young woman-

-- MAIN APPLICATION
addappid(2651500)
-- Game: addappid(2651500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651501, 1, "28b6ed09cacc74e129d915cb834e67a39030199af8448aa6efcbaf0e82fb841e")
