-- Lua provided by RyzenAPI
-- Game: Another Hole to Seduce a Married Woman

-- MAIN APPLICATION
addappid(3353490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3353491, 1, "448865df39ea678c0f6a3caa36c6afd3e91a671b1a06fcc468ded7e534cc26c6")

