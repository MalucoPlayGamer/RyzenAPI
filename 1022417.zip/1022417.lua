-- Lua provided by RyzenAPI
-- Game: DFF NT: Void Sword, Exdeath's 4th Weapon

-- MAIN APPLICATION
addappid(1022417)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022417,0,"eec2ed23ac6a9a2df7c844f1b1f23abb6a51a6752b7ee3f14c80e0726bb6b0c5")
