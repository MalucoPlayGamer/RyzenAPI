-- Lua provided by RyzenAPI
-- Game: F1® Manager 2023

-- MAIN APPLICATION
addappid(2287220)
addappid(2386730)
addappid(2428720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2287221, 1, "f3bbc703b528bc21ea60de0dfbd5eb17f2b5697a6dcebc73b2a287fc01853882")

