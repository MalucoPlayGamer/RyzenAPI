-- Lua provided by RyzenAPI
-- Game: addappid(2617100)

-- MAIN APPLICATION
addappid(2617100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617101, 1, "a6b3065d74f33809cffdd62620f5ac1a5d142afdef31487f126d90fec028250a")
