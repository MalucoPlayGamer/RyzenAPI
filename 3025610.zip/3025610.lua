-- Lua provided by RyzenAPI
-- Game: OCON

-- MAIN APPLICATION
addappid(3025610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3025611, 1, "2febc89f680af56e8ebdbea86b9812851b7a4ff68d53d4a48761ea5a3589d0fb")

