-- Lua provided by RyzenAPI 
-- Game: OCON
addappid(3025610)
addappid(3025611, 1, "2febc89f680af56e8ebdbea86b9812851b7a4ff68d53d4a48761ea5a3589d0fb")
