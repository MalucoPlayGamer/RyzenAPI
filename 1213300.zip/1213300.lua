-- Lua provided by RyzenAPI
-- Game: addappid(1213300)

-- MAIN APPLICATION
addappid(1213300)
addappid(3573840)
addappid(3573870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213302,0,"a237589c759350160f6eaa4255cfbb51b778235d41e60ca9b6b5ce7936dcca04")
