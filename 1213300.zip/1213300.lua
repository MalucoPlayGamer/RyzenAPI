-- Lua provided by RyzenAPI
-- Game: 叛逆神魂 GODSOUL🔥

-- MAIN APPLICATION
addappid(1213300)
addappid(3573830)
addappid(3573840)
addappid(3573870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213300,0,"877a197f18e3e4737a31eb713eb55d809723fb7a650efb5b3969f012a686bd19")
addappid(1213302,0,"a237589c759350160f6eaa4255cfbb51b778235d41e60ca9b6b5ce7936dcca04")
addappid(3573850,0,"e02ec17f12b7b2ee078f9a9d3ae34992510b1920887480f46be5d3d2e6873212")
addappid(3573860,0,"daa9c7677c0363903f504ee940a4451f70777b4b28ffb5ccd0175fbc7bff3a34")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
