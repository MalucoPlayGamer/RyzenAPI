-- Lua provided by RyzenAPI
-- Game: Game: The Memory Thieves

-- MAIN APPLICATION
addappid(2963720)
-- Game: addappid(2963720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963721, 1, "8d0b335aabc9893a42bc96061736d71a4fb113eec463a2e2a5ea3f904668e6d5")
