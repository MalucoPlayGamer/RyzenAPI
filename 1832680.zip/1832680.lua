-- Lua provided by RyzenAPI
-- Game: 1832680

-- MAIN APPLICATION
addappid(1832680)
-- Game: addappid(1832680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832681, 1, "9b0bfcb86b4e62d011af6a8ace664a6b97cd3c22db2f99991d7fd16543afcfc4")
