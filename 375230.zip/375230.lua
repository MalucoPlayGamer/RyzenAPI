-- Lua provided by RyzenAPI
-- Game: Game: Warhammer 40,000: Eternal Crusade

-- MAIN APPLICATION
addappid(375230)
addappid(377910)
addappid(377920)
addappid(377930)
-- Game: addappid(375230)

-- MAIN APP DEPOTS / PACKAGES
addappid(375231, 1, "6e47925cc8e4eef9313ac6f4b31f277676d99c70e470f851270bb837fcd1a3bc")
