-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Eternal Crusade

-- MAIN APPLICATION
addappid(375230)
addappid(377910)
addappid(377920)
addappid(377930)
addappid(489960)
addappid(566040)
addappid(591810)
addappid(591811)
addappid(591812)
addappid(591813)
addappid(592960)
addappid(596830)
addappid(597050)
addappid(612630)
addappid(612631)
addappid(621460)
addappid(621461)
addappid(622120)
addappid(625200)
addappid(630970)
addappid(637370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(375231, 1, "6e47925cc8e4eef9313ac6f4b31f277676d99c70e470f851270bb837fcd1a3bc")

