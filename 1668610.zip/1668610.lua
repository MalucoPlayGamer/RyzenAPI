-- Lua provided by RyzenAPI
-- Game: addappid(1668610)

-- MAIN APPLICATION
addappid(1668610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1668616,0,"ed0c428f180f4de5fe133f3efd3139ad6cc592a212ce4d014455591627986ebf")
