-- 4162260's Lua and Manifest Created by Hubcap Manifest
-- Pizza Man Simulator
-- Created: August 14, 2026 at 00:44:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4162260) -- Pizza Man Simulator
-- MAIN APP DEPOTS
addappid(4162261, 1, "b1bc69f89400a468e63653b5f29f5d71f3841d914b6dbc1460565c8c4a425bc9") -- Depot 4162261
setManifestid(4162261, "8388097151180240153", 5535444522)