-- Lua provided by RyzenAPI
-- Game: Pizza Man Simulator

-- MAIN APPLICATION
addappid(4162260) -- Pizza Man Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(4162261, 1, "b1bc69f89400a468e63653b5f29f5d71f3841d914b6dbc1460565c8c4a425bc9") -- Depot 4162261

