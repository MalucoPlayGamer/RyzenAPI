-- Lua provided by RyzenAPI
-- Game: AppID 1346120

-- MAIN APPLICATION
addappid(1346120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1346121, 1, "7e9f717637314a2b418b0e9eab645e2278c2a22bf4124c1a73a47421553a7d31")
addappid(1346124, 1, "59551e7fe91b923730f48228cc9d302ffbbd1d82f16fa4a90f1d6a3ae98857f2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
