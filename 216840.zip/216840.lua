-- Lua provided by RyzenAPI
-- Game: AppID 216840

-- MAIN APPLICATION
addappid(216840)

-- MAIN APP DEPOTS / PACKAGES
addappid(216841, 1, "67561476caa281dc81cbc21c39131bffa5435ab051ca4ca92174e53c9dac942c")

