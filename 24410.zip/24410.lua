-- Lua provided by RyzenAPI
-- Game: Game: Crusaders: Thy Kingdom Come

-- MAIN APPLICATION
addappid(24410)
-- Game: addappid(24410)

-- MAIN APP DEPOTS / PACKAGES
addappid(24411, 1, "87b5483cfc5b1fd70ce546e8c1c328fb15a7e033d05e73eb54a7e1e7d5749725")
addappid(24412, 1, "5f58f994ad46c4d0354c1b1ab503e99cd232bcd772a694f792c76fd26560f057")
addappid(24413, 1, "c0d66269c2e3e8263b1dc80a7825563e0d1052b3b8b53d215c686bf7153af170")
addappid(24414, 1, "c11083fa4b82ec5059b97f12071df5572dc3acfe88bee9e5eafe2881f51a1e5a")
addappid(24415, 1, "cc4d8aee2c43a2844157d6a14706c19fee79e2d534d01bb8e950e9a7fddaf177")
addappid(24416, 1, "27eb232b09f8bd31bfb86b5045d388331351f3c902a81c0d19d1fe4006c0db5d")
