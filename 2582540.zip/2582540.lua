-- Lua provided by RyzenAPI
-- Game: RoGlass

-- MAIN APPLICATION
addappid(2582540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2582541, 1, "ab47fac8b70c3548f20619615ff8296da2e001cfd8145d9004eff2845f414865")
