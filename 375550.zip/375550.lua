-- Lua provided by RyzenAPI
-- Game: DungeonRift

-- MAIN APPLICATION
addappid(375550)

-- MAIN APP DEPOTS / PACKAGES
addappid(375551, 1, "c1f084ee22cfc683e9e6c84447d74c6772861c42bd51abbccb78a31753e79001")
addappid(375552, 1, "8fe5345177a274197813c386a70f2b4c5ae30a406dae9bff24334a5fbb09ba48")
addappid(375553, 1, "ca21a73128d8f2c193cd8759536dc52a12c90b53c47742d46e58d3d51b1ab096")
addappid(375554, 1, "49c853e748c5abd9eac6aa5cd86c890d68a591683230c04896b08a3f56f0251e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
