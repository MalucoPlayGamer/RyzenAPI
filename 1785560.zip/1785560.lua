-- Lua provided by RyzenAPI
-- Game: addappid(1785560)

-- MAIN APPLICATION
addappid(1785560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1785561, 1, "650699ef9e0c191a7da9907c43bcbdcc3091d48fb50684ee9fe62e1095b23efe")
