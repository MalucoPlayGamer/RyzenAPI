-- Lua provided by RyzenAPI
-- Game: Game: High Sea Saga DX

-- MAIN APPLICATION
addappid(2431880)
-- Game: addappid(2431880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431881, 1, "5ae964a51726dfa3bf17c04c59f3f2bca50dc7a8132dc6b90d47501160dd5d1a")
