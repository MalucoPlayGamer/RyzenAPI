-- Lua provided by RyzenAPI
-- Game: Perfect Gold Demo

-- MAIN APPLICATION
addappid(1325750)
-- Game: addappid(1325750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325751, 1, "b36a042d38a25af4cb17c3d854c657bb7cd07db012a369e5057b6ca3143d705c")
