-- Lua provided by SkyAPI 
-- Game: The Burrito Quest
addappid(2106760)
addappid(2106761, 1, "3b277b87e2b4347f4f7b90ac9224172dba52aad2116e4d0cae955090ef831129")
addappid(2106762, 1, "adcea875e38fc3479b7ecd4fed58478a67fc11cf31fd8726def978246039ded7")
