-- Lua provided by RyzenAPI
-- Game: The Wind Road

-- MAIN APPLICATION
addappid(1264670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1264671, 1, "585a37c31110ec56d0240b20e1825369b488566f1f5046f7388d38b946c7294a")

