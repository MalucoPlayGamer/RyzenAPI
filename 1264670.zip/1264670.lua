-- Lua provided by RyzenAPI
-- Game: Game: The Wind Road

-- MAIN APPLICATION
addappid(1264670)
-- Game: addappid(1264670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264671, 1, "585a37c31110ec56d0240b20e1825369b488566f1f5046f7388d38b946c7294a")
