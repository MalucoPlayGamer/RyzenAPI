-- Lua provided by RyzenAPI
-- Game: Applewood

-- MAIN APPLICATION
addappid(1107470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1107471, 1, "d7163567cc68ab1e35e89fb8fa7fc1edb2c09ed73c714d4c1b5351143837b87b")
