-- Lua provided by RyzenAPI
-- Game: Applewood

-- MAIN APPLICATION
addappid(1107470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1107471, 1, "d7163567cc68ab1e35e89fb8fa7fc1edb2c09ed73c714d4c1b5351143837b87b")

