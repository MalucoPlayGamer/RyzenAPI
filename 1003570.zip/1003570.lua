-- Lua provided by RyzenAPI
-- Game: 103 - Soundtrack

-- MAIN APPLICATION
addappid(1003570)
-- Game: addappid(1003570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1003570,0,"d2a024f3a6691f5e63d231b48c3eb9f5d8b6b4913a62daf290f66e75600c321c")
