-- Lua provided by SkyAPI 
-- Game: SquareMan
addappid(1778520)
addappid(1778521, 1, "6549dfaad8343a9fb1cd27f2a6e80e5277ca4e411dee3c815d72bf99f24a68f1")
