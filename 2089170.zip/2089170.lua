-- Lua provided by RyzenAPI
-- Game: Game: AppID 2089170

-- MAIN APPLICATION
addappid(2089170)
-- Game: addappid(2089170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2089171, 1, "137118c78ce3882b6e5b46d77aa8c7edcbcc8748c026df402487bc58c0577c30")
