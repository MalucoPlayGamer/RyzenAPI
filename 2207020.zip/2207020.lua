-- Lua provided by RyzenAPI
-- Game: 原点计划：序章

-- MAIN APPLICATION
addappid(2207020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2207021, 1, "6771f39ebd3f2da4ade7ce1d5d6ecfd9b96980b0ccfd4e4c60f29fbf151ea6e7")
