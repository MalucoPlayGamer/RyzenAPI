-- Lua provided by RyzenAPI
-- Game: 新盗墓笔记（官方正版）

-- MAIN APPLICATION
addappid(4676570)
