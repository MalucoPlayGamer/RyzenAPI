-- Lua provided by RyzenAPI
-- Game: THE DARK DWELLERS

-- MAIN APPLICATION
addappid(1771620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1771622,0,"c1252d5cf0b510304e7e94048866eaf65b528fc3db45a90fe4257c98fd44ecff")

