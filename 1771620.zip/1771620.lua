-- Lua provided by RyzenAPI
-- Game: 1771620

-- MAIN APPLICATION
addappid(1771620)
-- Game: addappid(1771620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771622,0,"c1252d5cf0b510304e7e94048866eaf65b528fc3db45a90fe4257c98fd44ecff")
