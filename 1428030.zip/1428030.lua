-- Lua provided by RyzenAPI
-- Game: Prince Of Wallachia

-- MAIN APPLICATION
addappid(1428030)
-- Game: addappid(1428030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428031, 1, "c1faa49d7ec1c063859e5e8f1974f1b6596981c0fc5efda7222571263143ca6c")
