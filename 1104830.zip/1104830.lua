-- Lua provided by RyzenAPI
-- Game: Mystery Masterpiece: The Moonstone

-- MAIN APPLICATION
addappid(1104830)
-- Game: addappid(1104830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1104831, 1, "25c307b75f789ffddc0ce0817a15c47af4ccdf3310a9f40dee3bc2dac6899fd5")
addappid(1104832, 1, "a910e4a6a8d48eb49d5292feaf539ac77f4958aafa412422dabf345aee5682b7")
