-- Lua provided by RyzenAPI
-- Game: 淤積的祈禱（Silted Prayer）

-- MAIN APPLICATION
addappid(2429380)
-- Game: addappid(2429380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429381, 1, "e5e355584e5654ef579d828f2b0446c1794b31f2db5e9d7e1e0cef03f17cc6bb")
