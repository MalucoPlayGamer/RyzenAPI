-- Lua provided by RyzenAPI 
-- Game: Car Mechanic Shop Simulator
addappid(3401000)
addappid(3401001, 1, "e0805c6da423b023a4aaee83809cef9ebdc1eca5a36d64e0733c52862c667161")
