-- Lua provided by RyzenAPI
-- Game: Brawl To The West

-- MAIN APPLICATION
addappid(2870150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870151, 1, "daefc521adef76e7bf8e10ef8e7776684795f15b29a5aabe7781f20c31a87b7e")
