-- Lua provided by RyzenAPI
-- Game: Stayhome Simulator

-- MAIN APPLICATION
addappid(1285000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1285001, 1, "018efd266b1b97cc60fa72ecf5ddcb510d27f8704202951258363a709e8cd132")

