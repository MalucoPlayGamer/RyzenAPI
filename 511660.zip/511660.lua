-- Lua provided by RyzenAPI
-- Game: Beachhead 2002

-- MAIN APPLICATION
addappid(511660)

-- MAIN APP DEPOTS / PACKAGES
addappid(511661, 1, "f21698913ecc8e85026514c9a4971dd6f0c736925182966574812c5852969cba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
