-- Lua provided by RyzenAPI
-- Game: Beachhead 2002

-- MAIN APPLICATION
addappid(511660)
-- Game: addappid(511660)

-- MAIN APP DEPOTS / PACKAGES
addappid(511661, 1, "f21698913ecc8e85026514c9a4971dd6f0c736925182966574812c5852969cba")
