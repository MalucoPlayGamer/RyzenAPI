-- Lua provided by RyzenAPI
-- Game: Metal Soldiers 2

-- MAIN APPLICATION
addappid(753380)

-- MAIN APP DEPOTS / PACKAGES
addappid(753381, 1, "546d0ef18e3c2799ba40ccf4b8c52b13682f1211d41aa0b03895eecce40d9f33")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
