-- Lua provided by RyzenAPI
-- Game: Game: Sun Warriors

-- MAIN APPLICATION
addappid(1470860)
-- Game: addappid(1470860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1470861, 1, "92e9c4972e78ea37ba225431e575c0f6307eeead2a2c3c61a9056dff1b0f4628")
