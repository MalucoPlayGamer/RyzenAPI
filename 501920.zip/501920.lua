-- Lua provided by RyzenAPI
-- Game: Game: AppID 501920

-- MAIN APPLICATION
addappid(501920)
-- Game: addappid(501920)

-- MAIN APP DEPOTS / PACKAGES
addappid(501921, 1, "45e9969edc75dcd33e563ca368f57f4e1561c74281246d062a39a6cd3ef764c9")
addappid(501922, 1, "27d7ec076ab4ac784a3bb7524faae51299af5000735873d8afc0d0bc59bc29b0")
