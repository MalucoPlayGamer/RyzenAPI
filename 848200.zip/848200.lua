-- Lua provided by RyzenAPI
-- Game: addappid(848200)

-- MAIN APPLICATION
addappid(848200)

-- MAIN APP DEPOTS / PACKAGES
addappid(848201, 1, "50e225d17d69d3884b20fc0b33d3d9a419b6f7da5ff57e59ea33c8d1ffb69d6d")
