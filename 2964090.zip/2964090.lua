-- Lua provided by RyzenAPI
-- Game: World of Warships: Legends

-- MAIN APPLICATION
addappid(2964090)

