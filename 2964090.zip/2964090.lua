-- Lua provided by RyzenAPI
-- Game: World of Warships: Legends

-- MAIN APPLICATION
addappid(2964090)
addappid(4596240)
addappid(4604950)
addappid(4626910)
addappid(4636090)
addappid(4640340)
addappid(4652620)
addappid(4813730)
addappid(5001710)
addappid(5065460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

