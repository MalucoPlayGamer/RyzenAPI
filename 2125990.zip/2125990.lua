-- Lua provided by RyzenAPI
-- Game: AppID 2125990

-- MAIN APPLICATION
addappid(2125990)
-- Game: addappid(2125990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2125991, 1, "2e1403ac15327a5872d54eac45a1faa9cc0e26b108bcabc8760b2d88e1c337c3")
