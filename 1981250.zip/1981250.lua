-- Lua provided by RyzenAPI
-- Game: Date Ariane Remastered

-- MAIN APPLICATION
addappid(1981250)
-- Game: addappid(1981250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1981251, 1, "2c5f3a2869823ebe3f4d5b4ba905dc3a64f6de7d6ea22fe8f685ed7f0a881073")
