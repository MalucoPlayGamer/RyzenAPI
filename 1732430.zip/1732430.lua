-- Lua provided by RyzenAPI
-- Game: 1732430

-- MAIN APPLICATION
addappid(1732430)
-- Game: addappid(1732430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732431, 1, "b597fd2377aa27876247617581b9feee95642f0cc5dbf5a9bf510425106e099b")
