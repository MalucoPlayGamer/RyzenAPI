-- Lua provided by SkyAPI 
-- Game: Love, Ghostie
addappid(1789490)
addappid(1789491, 1, "48f43dd39088d216a726ed8f19bf9dc7a5d3f97b3468bbbd2cb46121e0342e82")
addappid(1789492, 1, "9cbfc8ca0feec14bf0dce887bcc51accd79fc8a2afce7f46d59d4d6ac8f9b92a")
