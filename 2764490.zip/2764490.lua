-- Lua provided by RyzenAPI
-- Game: Game: 带不动的七年一班 No Kids Left

-- MAIN APPLICATION
addappid(2764490)
-- Game: addappid(2764490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2764491, 1, "8c6360babb7f0c5d2efc239f73e22d0ec9a3e5e30c387d426a6fe486c2e8efcd")
