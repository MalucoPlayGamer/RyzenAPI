-- Lua provided by RyzenAPI
-- Game: Charming Hearts

-- MAIN APPLICATION
addappid(2817140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817141, 1, "e9be934c49c9d5653bdd97826c3dcd00b0a6ab755f9f3fc2f699be41b15c2f9b")
