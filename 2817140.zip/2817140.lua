-- Lua provided by RyzenAPI
-- Game: Charming Hearts

-- MAIN APPLICATION
addappid(2817140)
addappid(3048920)
addappid(3527410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817141,0,"e9be934c49c9d5653bdd97826c3dcd00b0a6ab755f9f3fc2f699be41b15c2f9b")
addappid(3048920,0,"7d27dbdf4a818aeb889f11852c88b6d499f74ff06f25b560ec4a0e3c03dac0bf")
addappid(3527410,0,"a6b757b89d8447056bb087290388bde63bf046cc0d4b2f1beae3d904f481ed24")

