-- Lua provided by RyzenAPI
-- Game: 1073390

-- MAIN APPLICATION
addappid(1073390)
-- Game: addappid(1073390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1073391, 1, "3bf31f757ac00c0aaa0dac1f9aa0710b7cb4e316d7c31ef16b511df1eb429a9f")
