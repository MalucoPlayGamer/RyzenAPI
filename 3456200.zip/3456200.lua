-- Lua provided by RyzenAPI
-- Game: The Night Museum

-- MAIN APPLICATION
addappid(3456200)
-- Game: addappid(3456200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3456201, 1, "c9e3dce37886f1280a2b933f9aa9516cada7119370f7dd3d2200c5639d1fae6d")
