-- Lua provided by RyzenAPI
-- Game: Train Crisis

-- MAIN APPLICATION
addappid(542100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(542101, 1, "0c02a3493636d39254ae9a6881b27db001da7012b3b12f4485db79e4c3975fd8")
addappid(542102, 1, "bb8d2369eac3ef509cc6544ef4d0002f48ef9bcbf13dd870c4c549d4c309a33d")

