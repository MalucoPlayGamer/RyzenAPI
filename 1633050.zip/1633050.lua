-- Lua provided by RyzenAPI
-- Game: Game: Devoul- Curse of the Soulless

-- MAIN APPLICATION
addappid(1633050)
-- Game: addappid(1633050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1633051, 1, "7e8be01494f00d6f92b463a41d1e70e68abddfabd3c7e80488d29fc4eee05fa1")
