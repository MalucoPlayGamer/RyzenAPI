-- Lua provided by SkyAPI 
-- Game: Root Of Win
addappid(2423050)
addappid(2423051, 1, "08f185c98f09486b0fee08196cbd345a3abaa0e71edc3e2103dda844fec42242")
