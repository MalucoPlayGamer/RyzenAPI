-- Lua provided by RyzenAPI
-- Game: Root Of Win

-- MAIN APPLICATION
addappid(2423050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2423051, 1, "08f185c98f09486b0fee08196cbd345a3abaa0e71edc3e2103dda844fec42242")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
