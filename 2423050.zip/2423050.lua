-- Lua provided by RyzenAPI
-- Game: Root Of Win

-- MAIN APPLICATION
addappid(2423050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2423051, 1, "08f185c98f09486b0fee08196cbd345a3abaa0e71edc3e2103dda844fec42242")

