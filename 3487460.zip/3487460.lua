-- Lua provided by RyzenAPI
-- Game: A Few Days With : Darlene

-- MAIN APPLICATION
addappid(3487460)
-- Game: addappid(3487460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3487461, 1, "3e5602e8f432d2ba813122f0d75ca895bcd0cf5a1e567e4fb4def2a7dc2240f5")
