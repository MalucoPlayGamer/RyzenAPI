-- Lua provided by RyzenAPI
-- Game: Game: AppID 464500

-- MAIN APPLICATION
addappid(464500)
-- Game: addappid(464500)

-- MAIN APP DEPOTS / PACKAGES
addappid(464501, 1, "7ce97ef67887df9cd3b52c66077fe4c847e1e88c362c9690f3c1311712b81052")
addappid(464503, 1, "23fcfffe60744fd5e6ca37c68535a991eff7c08628d048fcae1648c70054bc69")
