-- Lua provided by RyzenAPI
-- Game: Fever Cabin

-- MAIN APPLICATION
addappid(1226210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1226211, 1, "91d4acd6928a946c4fe16f4657dd5d6de3c8e3f30c2eafbd818b45ec64c9903f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
