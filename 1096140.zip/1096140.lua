-- Lua provided by RyzenAPI
-- Game: Timemelters

-- MAIN APPLICATION
addappid(1096140)
-- Game: addappid(1096140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096141, 1, "b0f8f5510981b56cbcdc321e3d4ba5dba80c71f5f3b1025da8ca8d7a32ded7da")
