-- Lua provided by RyzenAPI
-- Game: Musician

-- MAIN APPLICATION
addappid(710280)

-- MAIN APP DEPOTS / PACKAGES
addappid(710281,0,"4c2494a13a3b9cd1a8c1fccbc5c61e41f5c4fed39cf018937cdf3bc29dc34a27")

