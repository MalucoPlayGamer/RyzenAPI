-- Lua provided by RyzenAPI
-- Game: Gurei

-- MAIN APPLICATION
addappid(2191280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191281,0,"aec0989877300addf49cc6fb8b0798ddf777f9360c7dc9b78c134d3ace85d127")

