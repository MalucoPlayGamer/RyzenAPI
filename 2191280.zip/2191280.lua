-- 2191280's Lua and Manifest Created by Hubcap Manifest
-- Gurei
-- Created: July 22, 2026 at 14:13:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2191280, 1, "6ff03a929c98ad2496876b4215a7ee7f3adae3fd5818ca6eb190f07c18474d15") -- Gurei
-- MAIN APP DEPOTS
addappid(2191281, 1, "aec0989877300addf49cc6fb8b0798ddf777f9360c7dc9b78c134d3ace85d127") -- Depot 2191281
setManifestid(2191281, "6774439254083390027", 795615535)