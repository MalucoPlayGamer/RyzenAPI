-- Lua provided by RyzenAPI
-- Game: Aven Colony - Cerulean Vale

-- MAIN APPLICATION
addappid(645900)
-- Game: addappid(645900)

-- MAIN APP DEPOTS / PACKAGES
addappid(645900,0,"99ab0e953e4cc25019e36cc8362417f5a014a3a1f4442036070eb9ce6b837450")
addtoken(645900,"8904856571382413981")
