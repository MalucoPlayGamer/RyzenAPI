-- Lua provided by RyzenAPI
-- Game: Atelier Tia

-- MAIN APPLICATION
addappid(1446480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1446481, 1, "eae4aef1041aa3e51a166e463b876aeedbd2ae3db234ef5a2752c900a1ebacad")

