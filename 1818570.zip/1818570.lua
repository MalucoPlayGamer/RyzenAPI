-- Lua provided by RyzenAPI
-- Game: Threes!

-- MAIN APPLICATION
addappid(1818570)
-- Game: addappid(1818570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1818573,0,"3cfc1d7b04c72eefeb597f091ec58247bcfe3b5049e9baecd7be2fba65ec123a")
