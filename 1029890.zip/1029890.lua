-- Lua provided by RyzenAPI
-- Game: Layers of Fear 2 (2019)

-- MAIN APPLICATION
addappid(1029890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1029891, 1, "b0334f2ce6dcd1a66d99ffffc95cc1909945e7ae7331f6cb109533a13be00ea1")
addappid(1029892, 1, "74d48df13383d062c76dfe7500c9544d21bcddfc9e0b60eb180cfc35ea8d9632")
addappid(1089320, 0, "0bd90a402a05c7b63a41a02640972e83c11ff6fd4f5573f3a1304179252ce99a")

