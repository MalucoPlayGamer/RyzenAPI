-- Lua provided by RyzenAPI
-- Game: Project Real

-- MAIN APPLICATION
addappid(2627600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2627601, 1, "b417565d08c1fbd4292c4459c013ead844b85481c636f7cebf2106a99b98b714")
