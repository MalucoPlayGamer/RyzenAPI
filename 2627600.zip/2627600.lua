-- Lua provided by RyzenAPI
-- Game: Projeto Real

-- MAIN APPLICATION
addappid(2627600)
addappid(2759550)
addappid(2764030)
addappid(2765450)
addappid(2765510)
addappid(2766320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2627601,0,"b417565d08c1fbd4292c4459c013ead844b85481c636f7cebf2106a99b98b714")

