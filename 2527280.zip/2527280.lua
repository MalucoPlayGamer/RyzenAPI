-- Lua provided by RyzenAPI 
-- Game: Nobody Nowhere Demo
addappid(2527280)
addappid(2527281, 1, "03e24d79992f1cc563b8a292976b17526ee2bd1fcfb7248a065986448e48bc88")
addappid(2527282, 1, "02560772dc9b31b95d1bbbe26394007d283d56dc334a97a96f78083d561aef50")
