-- Lua provided by RyzenAPI
-- Game: American Railroads - Summit River & Pine Valley

-- MAIN APPLICATION
addappid(787930)

-- MAIN APP DEPOTS / PACKAGES
addappid(787931, 1, "33278f4873829a3501ab57a701367d13a870826b487e3a43ca779b0bb524b3b6")

