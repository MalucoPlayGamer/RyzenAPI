-- Lua provided by RyzenAPI
-- Game: 2350380

-- MAIN APPLICATION
addappid(2350380)
addappid(2369260)
-- Game: addappid(2350380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350381, 1, "452de2864e199190c358ab1e837f5648e1d521f64c434ad1cb295abaeb3ce531")
