-- Lua provided by RyzenAPI
-- Game: Asa-Chan Wants to Go Home!

-- MAIN APPLICATION
addappid(2646240)
-- Game: addappid(2646240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646241, 1, "02897262b9562f49f6f8f553e65438ff0496bd038da17a051d8f998764799ca6")
addappid(2646242, 1, "1553173eaf38a25ac6a476beadfaf45607b5c1dd3a4b9cfd1c217bb2ed42169b")
