-- Lua provided by RyzenAPI
-- Game: Tales of Terror

-- MAIN APPLICATION
addappid(1824150)
-- Game: addappid(1824150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824151, 1, "4d8c40ff5e82cba06030fdca18d8025895e31b00e86b81b6d2502d68e33450cf")
