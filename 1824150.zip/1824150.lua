-- Lua provided by SkyAPI 
-- Game: Tales of Terror
addappid(1824150)
addappid(1824151, 1, "4d8c40ff5e82cba06030fdca18d8025895e31b00e86b81b6d2502d68e33450cf")
