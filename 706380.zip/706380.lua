-- Lua provided by RyzenAPI
-- Game: LOGistICAL: Norway

-- MAIN APPLICATION
addappid(706380)

-- MAIN APP DEPOTS / PACKAGES
addappid(706381,0,"8e5a7289cbfdb314d8be36ce21226e6835593a868a26f89a3ab9a324ab517ed9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
