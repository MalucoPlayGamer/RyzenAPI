-- Lua provided by RyzenAPI
-- Game: LOGistICAL: Norway

-- MAIN APPLICATION
addappid(706380)

-- MAIN APP DEPOTS / PACKAGES
addappid(706381,0,"8e5a7289cbfdb314d8be36ce21226e6835593a868a26f89a3ab9a324ab517ed9")

