-- 3236900's Lua and Manifest Created by Hubcap Manifest
-- Rebirth Pub
-- Created: August 14, 2026 at 10:00:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3236900) -- Rebirth Pub
-- MAIN APP DEPOTS
addappid(3236901, 1, "72a760c7a60c21e98890498394a318403547b3ff2c25b5f7cb5382def3ac8199") -- Depot 3236901
setManifestid(3236901, "7994300222101113637", 11454069450)