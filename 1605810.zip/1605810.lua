-- Lua provided by RyzenAPI
-- Game: Game: Root Soundtrack

-- MAIN APPLICATION
addappid(1605810)
-- Game: addappid(1605810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1605811, 1, "079d81be213da32fd8d706b224124a0518084ea349a2b9ea22db1b4e5f854374")
addappid(1605812, 1, "d7a5b713456c14d46c6fe3489999804d45876e58dc1d3130832ecb29da9bbaf3")
