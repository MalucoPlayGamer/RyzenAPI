-- Lua provided by RyzenAPI
-- Game: Game: Milk Girl -Sweet memories of summer

-- MAIN APPLICATION
addappid(1890680)
-- Game: addappid(1890680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890681, 1, "f00c0507ffd60673c50c786759cc07d952f22bce91ff77ecd35f87a5570c890b")
addappid(2254040, 0, "ede03d8eb54aebfa2ab65cb607fd789e5b19517f50b6288324702ddf656a9d8d")
