-- Lua provided by RyzenAPI
-- Game: Street Fighter® IV

-- MAIN APPLICATION
addappid(21660)

-- MAIN APP DEPOTS / PACKAGES
addappid(21661, 1, "2c05f2bfcfaec0efbf4e67e3cf8670c49fb397c9d3967a1c665b5fe3f7926e61")
