-- Lua provided by RyzenAPI
-- Game: Primal Carnage Dedicated Server

-- MAIN APPLICATION
addappid(224620)

-- MAIN APP DEPOTS / PACKAGES
addappid(224621, 1, "7201b4488209dd743482f79b2df8f28a487f7d778e545874c24566741f3b84ce")

