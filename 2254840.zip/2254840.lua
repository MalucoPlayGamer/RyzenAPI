-- Lua provided by SkyAPI 
-- Game: CUSTOM ORDER MAID 3D2 It’s a Night Magic Lucky Bag Ver.Live!
addappid(2254840)
addappid(2254841, 1, "9abe5255640bdb298b158072e54a95dae3a729b079f3bf8ba682801a448ef313")
addappid(2254842, 1, "a9e4a0668cef13c1f3a74b931f46e792e7263ddfba39ce107868a74654d7267b")
addappid(2254843, 1, "819c69caa09447dfe7bc546ac54a99ad1bb6fd1d20c5394ca9e51ce555d65459")
addappid(2254844, 1, "3fd1ec1f13001e951c17703135f3e079c5fb57c87e637c4944b038c1143e0665")
