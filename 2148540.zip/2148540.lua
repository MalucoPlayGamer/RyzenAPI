-- Lua provided by RyzenAPI
-- Game: AppID 2148540

-- MAIN APPLICATION
addappid(2148540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2148541, 1, "3e75a9befacab254e5ce1576b45c645c7bfa2eddd59e38bf0dea0564e952d735")
