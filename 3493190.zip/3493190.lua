-- Lua provided by SkyAPI 
-- Game: AppID 3493190
addappid(3493190)
addappid(3493191, 1, "6f60765d6973388bdf481d9b080421ef9b0aeb10805d162718091e753b6154ba")
