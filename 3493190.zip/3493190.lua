-- Lua provided by RyzenAPI
-- Game: Deep Hell Demo

-- MAIN APPLICATION
addappid(3493190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3493191, 1, "6f60765d6973388bdf481d9b080421ef9b0aeb10805d162718091e753b6154ba")

