-- Lua provided by RyzenAPI
-- Game: Maniac: Hunt or Be Hunted

-- MAIN APPLICATION
addappid(3738570)
-- Game: addappid(3738570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3738571, 1, "0e33dedb470613f8594cb421a9696bb2f5061b4f16924c28c488c06b988e36cc")
