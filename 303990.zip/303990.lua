-- Lua provided by RyzenAPI
-- Game: 303990

-- MAIN APPLICATION
addappid(303990)
-- Game: addappid(303990)

-- MAIN APP DEPOTS / PACKAGES
addappid(303991, 1, "961a9e974e1dff7ff8b1e5e9aa0c0355fec1809133f2d290adf96d2410e6a61d")
