-- Lua provided by RyzenAPI
-- Game: Dark Descent: The Blue Rose

-- MAIN APPLICATION
addappid(676800)

-- MAIN APP DEPOTS / PACKAGES
addappid(676801, 1, "f3560e1eb37daa0f778c9b46e58dbd696510f18365bad7c51ded981e81613584")

