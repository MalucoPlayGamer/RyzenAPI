-- Lua provided by RyzenAPI
-- Game: The Final Earth 2

-- MAIN APPLICATION
addappid(1180130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1180131, 1, "c3a17188fc7b3ab4d4898c5f0fd514b2718b110b6771b2281598880cf4554f15")

