-- Lua provided by RyzenAPI
-- Game: Ghostly Matter

-- MAIN APPLICATION
addappid(800240)

-- MAIN APP DEPOTS / PACKAGES
addappid(800241, 1, "31d8f95166dfdd390d74e638dd73ca1179aaee7e1be662fbb68a4ee5403e2fd5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
