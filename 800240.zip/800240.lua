-- Lua provided by RyzenAPI
-- Game: 800240

-- MAIN APPLICATION
addappid(800240)
-- Game: addappid(800240)

-- MAIN APP DEPOTS / PACKAGES
addappid(800241, 1, "31d8f95166dfdd390d74e638dd73ca1179aaee7e1be662fbb68a4ee5403e2fd5")
