-- Lua provided by RyzenAPI
-- Game: Dances and Girls

-- MAIN APPLICATION
addappid(1437720)
-- Game: addappid(1437720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437721, 1, "b8ac59cc3f8534a59c1e5133447b42c904f415d6e197b8eedc68dfeecb2f94dd")
