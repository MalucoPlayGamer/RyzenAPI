-- Lua provided by RyzenAPI
-- Game: SuccuSeka: Resist Succubus Temptation

-- MAIN APPLICATION
addappid(2274460)
-- Game: addappid(2274460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2282850,0,"b083c9ca52b99d7a27dcaf2bbb32faa9e388c3a18e8ba34e6e970ae111245476")
