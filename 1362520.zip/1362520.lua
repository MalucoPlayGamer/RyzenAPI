-- Lua provided by RyzenAPI
-- Game: The Luminous Underground

-- MAIN APPLICATION
addappid(1362520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1362521, 1, "ec7625d95e00aeec856a416760d3d37f0ee9bab4afa811b16d3d3da7c8613db5")

