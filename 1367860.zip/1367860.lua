-- Lua provided by RyzenAPI
-- Game: addappid(1367860)

-- MAIN APPLICATION
addappid(1367860)
addappid(1472720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367861, 1, "708ed2760937c4b301baa376ce415f7aad9c4e0da01d8e64868f81a333d1333e")
