-- Lua provided by RyzenAPI
-- Game: Damned Hand

-- MAIN APPLICATION
addappid(1367860)
addappid(1472720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1367861, 1, "708ed2760937c4b301baa376ce415f7aad9c4e0da01d8e64868f81a333d1333e")

