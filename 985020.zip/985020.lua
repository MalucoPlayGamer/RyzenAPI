-- Lua provided by RyzenAPI
-- Game: Game: Three Kingdoms：Ancient battlefield | 三国古战略

-- MAIN APPLICATION
addappid(985020)
-- Game: addappid(985020)

-- MAIN APP DEPOTS / PACKAGES
addappid(985021, 1, "d7f29ceed1aabebed7bc4539df0066c8c6796bea0c1a0ea212d299ca58824cea")
