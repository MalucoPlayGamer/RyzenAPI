-- Lua provided by RyzenAPI
-- Game: 544180

-- MAIN APPLICATION
addappid(544180)
-- Game: addappid(544180)

-- MAIN APP DEPOTS / PACKAGES
addappid(544181, 1, "c1370fef7f2b0bca0a0c63efaea72e26e3bdb912891b3cda4d10a5502c431546")
