-- Lua provided by RyzenAPI
-- Game: Pizza Shop Simulator

-- MAIN APPLICATION
addappid(3720070)
-- Game: addappid(3720070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3720072,0,"34344cf9b54a3bab2ab6e0c2b0af5c9151d93c13a93894e1d26278702de9cce0")
