-- Lua provided by SkyAPI 
-- Game: AppID 585720
addappid(585720)
addappid(585721, 1, "fbe2d1d116797915c12ac4cf8da13bfba6159fd662ca7897af7a0f9df0cdf59b")
