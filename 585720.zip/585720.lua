-- Lua provided by RyzenAPI
-- Game: AppID 585720

-- MAIN APPLICATION
addappid(585720)
-- Game: addappid(585720)

-- MAIN APP DEPOTS / PACKAGES
addappid(585721, 1, "fbe2d1d116797915c12ac4cf8da13bfba6159fd662ca7897af7a0f9df0cdf59b")
