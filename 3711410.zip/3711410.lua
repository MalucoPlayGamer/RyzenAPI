-- Lua provided by RyzenAPI
-- Game: MPPP - Multidimensional Paper Plane Project

-- MAIN APPLICATION
addappid(3711410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3711411, 1, "8fcf564407c38f2e3b7260e45e5bd6d39c6dc42d427d851c82002ccfc5d0148e")

