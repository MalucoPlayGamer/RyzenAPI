-- Lua provided by RyzenAPI
-- Game: BeastLink

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2962780, 1, "b1fb2905fda5af39bd95905a51c7c628249cdf95858b760aef78de62581c69fc") -- BeastLink
addappid(2962781, 1, "e68d15ff207c09d4e8cb1845d3b3138307609415a66e4244b208a9a7ef138d6f") -- Depot 2962781

