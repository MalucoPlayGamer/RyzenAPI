-- Lua provided by RyzenAPI
-- Game: Taken Souls: Blood Ritual Collector's Edition

-- MAIN APPLICATION
addappid(586930)

-- MAIN APP DEPOTS / PACKAGES
addappid(586931, 1, "7085bddb0c2bcc5065a604636a944aea07448fe608c59cbf67a3a53ba7196250")

