-- Lua provided by SkyAPI 
-- Game: Anime puzzle
addappid(1657960)
addappid(1657961, 1, "f3c68f7a4f262c983d109025f520ae227e3f7cf156afb7df4324cac68b3ad917")
