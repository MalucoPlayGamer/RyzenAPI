-- Lua provided by RyzenAPI
-- Game: Game: AppID 952950

-- MAIN APPLICATION
addappid(952950)
-- Game: addappid(952950)

-- MAIN APP DEPOTS / PACKAGES
addappid(952951, 1, "2152e526c3242b143734f45ef7384909417a5dc3636bbddabc023f77196c1d40")
