-- Lua provided by RyzenAPI 
-- Game: AppID 952950
addappid(952950)
addappid(952951, 1, "2152e526c3242b143734f45ef7384909417a5dc3636bbddabc023f77196c1d40")
