-- Lua provided by RyzenAPI
-- Game: 03.04

-- MAIN APPLICATION
addappid(952950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(952951, 1, "2152e526c3242b143734f45ef7384909417a5dc3636bbddabc023f77196c1d40")