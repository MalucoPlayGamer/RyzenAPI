-- Lua provided by RyzenAPI
-- Game: Ironclads: Schleswig War 1864

-- MAIN APPLICATION
addappid(46760)
-- Game: addappid(46760)

-- MAIN APP DEPOTS / PACKAGES
addappid(46761, 1, "a52dbddf5b18fcbe42a1764b06fad64ff623d8f9b25d5c88a27742501f4cc008")
