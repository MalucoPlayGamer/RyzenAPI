-- Lua provided by RyzenAPI
-- Game: Game: AppID 1067800

-- MAIN APPLICATION
addappid(1067800)
-- Game: addappid(1067800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1067801, 1, "83e283b0485e758cb04467b8661adf9ac27402bb1b161ac18eacaf883162ea02")
