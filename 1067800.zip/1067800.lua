-- Lua provided by SkyAPI 
-- Game: AppID 1067800
addappid(1067800)
addappid(1067801, 1, "83e283b0485e758cb04467b8661adf9ac27402bb1b161ac18eacaf883162ea02")
