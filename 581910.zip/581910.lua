-- Lua provided by RyzenAPI
-- Game: Iron Armada

-- MAIN APPLICATION
addappid(581910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(581911, 1, "9bc9170f7e5ed8724f661e3e4564d92c501316d8e1a3e634db33ae8216576078")
addappid(770341, 0, "d9211c1b50c17e0e7e701912faf14130acaa44cfb93d2b35e74d47a3aa89ac82")
