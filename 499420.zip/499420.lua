-- Lua provided by RyzenAPI
-- Game: Star Fields

-- MAIN APPLICATION
addappid(499420)

-- MAIN APP DEPOTS / PACKAGES
addappid(499421, 1, "e8d55f6d46644af54d91c0df7291f2f8e9cb463b43ec93d30646bc36c0b4ff00")
