-- Lua provided by SkyAPI 
-- Game: Star Fields
addappid(499420)
addappid(499421, 1, "e8d55f6d46644af54d91c0df7291f2f8e9cb463b43ec93d30646bc36c0b4ff00")
