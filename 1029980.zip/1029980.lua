-- Lua provided by RyzenAPI
-- Game: UBERMOSH Vol.7

-- MAIN APPLICATION
addappid(1029980)
-- Game: addappid(1029980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029981, 1, "f106db34723fba170518f236eb3d5c15afd496e8651a098f9a995581581a23b5")
