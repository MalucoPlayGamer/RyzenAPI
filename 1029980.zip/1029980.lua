-- Lua provided by RyzenAPI
-- Game: UBERMOSH Vol.7

-- MAIN APPLICATION
addappid(1029980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1029981, 1, "f106db34723fba170518f236eb3d5c15afd496e8651a098f9a995581581a23b5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
