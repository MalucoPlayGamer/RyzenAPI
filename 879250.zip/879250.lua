-- Lua provided by RyzenAPI
-- Game: Dot to Dot Puzzles

-- MAIN APPLICATION
addappid(879250)
addappid(883180)
addappid(883181)
addappid(883182)

