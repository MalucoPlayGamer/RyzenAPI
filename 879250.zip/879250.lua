-- Lua provided by RyzenAPI
-- Game: Dot to Dot Puzzles

-- MAIN APPLICATION
addappid(879250)
