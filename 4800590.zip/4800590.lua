-- 4800590's Lua and Manifest Created by Hubcap Manifest
-- Supermarket Chaos
-- Created: June 30, 2026 at 07:42:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4800590, 1, "e9335e53c789d938158eedb8a5c66e174fb270ecd3139813b644779b17bb0f82") -- Supermarket Chaos
-- MAIN APP DEPOTS
addappid(4800591, 1, "96914473ba48921d6f31b7753bec7dbeaac2e5ba8f983227bd6b51b8ebbed306") -- Depot 4800591
setManifestid(4800591, "6062930160626941632", 1451619307)