-- Lua provided by RyzenAPI
-- Game: Coffee & Boobs

-- MAIN APPLICATION
addappid(3471590)
addappid(3596490)
addappid(3596500)
addappid(3816810) -- Coffee  Boobs  GRAND GALA
addappid(4033030) -- Coffee  Boobs - Raiders of the Witchs Elixir

-- MAIN APP DEPOTS / PACKAGES
addappid(3471591, 1, "1e645a28773a20dd3cdb79845dc0347330707bdc8f69b5295ff23b62f1b14f71")
addappid(3471591, 1, "1e645a28773a20dd3cdb79845dc0347330707bdc8f69b5295ff23b62f1b14f71") 
addappid(3596490, 1, "a462e16bd2cd531eb492662d2271359a027603846e00b1e529ca3cf14773de78") -- Coffee  Boobs - Digital Artbook - Depot 3596490
addappid(3596500, 1, "1b6f0256a913f3905de0ac2018bfcd862b70547dda9376018d83c2f575de081e") -- Coffee  Boobs - Wallpapers Pack - Depot 3596500

