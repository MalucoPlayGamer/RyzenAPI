-- Lua provided by RyzenAPI
-- Game: 3471590

-- MAIN APPLICATION
addappid(3471590)
-- Game: addappid(3471590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3471591, 1, "1e645a28773a20dd3cdb79845dc0347330707bdc8f69b5295ff23b62f1b14f71")
