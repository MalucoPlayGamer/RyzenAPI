-- Lua provided by RyzenAPI
-- Game: AppID 1182310

-- MAIN APPLICATION
addappid(1182310)
addappid(2143560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(1182311, 1, "f3ebe58cd5c5b00650ce8e7b8348b9c3b812530cfed1294d166111e2a360842b")
addappid(1182312, 1, "32f7e3f76cfbd125af9337b9bc0d9e011d269be7eddbbe821b7d1fd96407fbd7")
addappid(1182313, 1, "1805788f23de35fa9fa98d5c941f7bb48ed9f3bda6db92007db5761504f2825e")
addappid(1182314, 1, "b2759f8bd404317cfe3e6cca6f85e5e91a03e288a790ec9d6ee8c2bf5c7ad3fe")

