-- Lua provided by RyzenAPI
-- Game: BoxLoop Soundtrack

-- MAIN APPLICATION
addappid(2062280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2062281, 1, "11f68a4b6750c9b9a6d159d0fbc6df633b1d5c1ae743b62fbde5a3538c86df6c")
addappid(2062282, 1, "e1eb0d155bc7182a599a264a2bd24ebe5f7b75d2c8c379aa94384e334a53fa91")

