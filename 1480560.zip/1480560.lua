-- Lua provided by RyzenAPI
-- Game: addappid(1480560)

-- MAIN APPLICATION
addappid(1480560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1480561, 1, "7a33fca064b1a78ea31a41dec6376187f4ce0d86a87c8cab3ae38accc7df718e")
