-- Lua provided by RyzenAPI
-- Game: Craft The World

-- MAIN APPLICATION
addappid(248390)
-- Game: addappid(248390)

-- MAIN APP DEPOTS / PACKAGES
addappid(248391, 1, "274bd06c718fcd808c0da011f82ad6dd30d033820190fb44486a5d9620b13d4b")
addappid(248392, 1, "7be3e3d259ff5cd3081f3ff4835215fca8d605a5967ae88d08892a48ccc916a0")
