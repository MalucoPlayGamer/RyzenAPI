-- Lua provided by RyzenAPI
-- Game: Craft The World

-- MAIN APPLICATION
addappid(248390)

-- MAIN APP DEPOTS / PACKAGES
addappid(248391, 1, "274bd06c718fcd808c0da011f82ad6dd30d033820190fb44486a5d9620b13d4b")
addappid(248392, 1, "7be3e3d259ff5cd3081f3ff4835215fca8d605a5967ae88d08892a48ccc916a0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(492680)
addappid(609800)
addappid(1105370)
addappid(1105371)
addappid(1157170)
addappid(1157310)
addappid(1209150)
addappid(1338630)
addappid(1509120)
addappid(2739550)
addappid(3392970)
addappid(4010190)
