-- Lua provided by RyzenAPI
-- Game: Sprout Valley

-- MAIN APPLICATION
addappid(1964820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964821, 1, "ab8d136ee492812ab5eff9f625ac687e13f2b83190324b50f9b42c7758bfe887")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2866230)
addappid(3405870)
