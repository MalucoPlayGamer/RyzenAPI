-- Lua provided by RyzenAPI
-- Game: 1964820

-- MAIN APPLICATION
addappid(1964820)
-- Game: addappid(1964820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1964821, 1, "ab8d136ee492812ab5eff9f625ac687e13f2b83190324b50f9b42c7758bfe887")
