-- Lua provided by RyzenAPI
-- Game: Ticket to Ride®

-- MAIN APPLICATION
addappid(2477010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477011, 1, "3615b8a0e6ab3df569fe773332ea74f8ce43b1467cc2a0c1cb310980d24fb274")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2608220)
addappid(2608230)
addappid(2856300)
addappid(2938560)
addappid(2938570)
addappid(3102710)
addappid(3252260)
addappid(3366230)
addappid(3367790)
addappid(3517340)
addappid(3842170)
addappid(4119700)
addappid(4404400)
