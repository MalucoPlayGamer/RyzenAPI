-- Lua provided by RyzenAPI
-- Game: AppID 99410

-- MAIN APPLICATION
addappid(99410)

-- MAIN APP DEPOTS / PACKAGES
addappid(99411, 1, "3fb11f157846afbf33dc385d6ab67c94f4eee9211c9300503f337cd8cedd8789")

