-- Lua provided by RyzenAPI
-- Game: Lords and Tactics

-- MAIN APPLICATION
addappid(2366000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2366001, 1, "03e1453058e2d2b2ba54c50830d24aab23b19d67f4cfff5ff28b0c85cdc77daa")

