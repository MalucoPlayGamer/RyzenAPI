-- Lua provided by SkyAPI 
-- Game: Lords and Tactics
addappid(2366000)
addappid(2366001, 1, "03e1453058e2d2b2ba54c50830d24aab23b19d67f4cfff5ff28b0c85cdc77daa")
