-- Lua provided by RyzenAPI
-- Game: addappid(2662270)

-- MAIN APPLICATION
addappid(2662270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2662271, 1, "44f9e10adb876755abfe45ca876734c862185b29c74385cb6a7cf34a119bdb41")
