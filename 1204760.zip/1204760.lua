-- Lua provided by RyzenAPI
-- Game: 1204760

-- MAIN APPLICATION
addappid(1204760)
-- Game: addappid(1204760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1204761, 1, "6c770ab3a9b8f5b1507892126bcd72790236fe21ebe848f6aaede9cc05554021")
