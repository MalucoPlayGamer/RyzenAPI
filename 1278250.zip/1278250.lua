-- Lua provided by RyzenAPI
-- Game: Kingdoms of Amalur: Re-Reckoning Soundtrack

-- MAIN APPLICATION
addappid(1278250)
-- Game: addappid(1278250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278251, 1, "27fc6849935fce8848a6239c2e71b59c980519c6cbb3565f78ea12348b396e25")
