-- Lua provided by RyzenAPI
-- Game: Hardenville

-- MAIN APPLICATION
addappid(2010460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2010461, 1, "72ceed4f1a9038ddfe02fc53cff6b44b24937ca5ed4bb900bbe3b5e002aa7953")
