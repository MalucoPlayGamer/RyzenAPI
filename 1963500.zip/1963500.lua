-- Lua provided by RyzenAPI
-- Game: Game: AppID 1963500

-- MAIN APPLICATION
addappid(1963500)
-- Game: addappid(1963500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1963501, 1, "4084914658005ce3d2575ab69406440992db6b9dff553b14bc2fcacf7e0b71d9")
