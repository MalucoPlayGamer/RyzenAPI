-- Lua provided by RyzenAPI
-- Game: addappid(1207270)

-- MAIN APPLICATION
addappid(1207270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1207271, 1, "4c1fd42d5caa0381bef96c39964413d83cf0bd358f7d5dda760699038da55e5b")
