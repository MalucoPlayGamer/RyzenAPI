-- Lua provided by RyzenAPI
-- Game: Flipstown

-- MAIN APPLICATION
addappid(1890710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890711, 1, "23e3774afae09efb66bde41623ffd90b587467820644c9000a2101c42677bd44")

