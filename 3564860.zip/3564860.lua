-- Lua provided by RyzenAPI
-- Game: 3564860

-- MAIN APPLICATION
addappid(3564860)
-- Game: addappid(3564860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3564861, 1, "262176baa1fa0d44b7b0cad48968679d5c5a731eaceb4a7cd0eda5e2dae9818d")
