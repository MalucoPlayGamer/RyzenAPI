-- Lua provided by SkyAPI 
-- Game: DJ Mole
addappid(806880)
addappid(806881, 1, "2b24e8aa6695cb02d890b3e0ee701df2b19bec586c2da723170f68742de85f3c")
