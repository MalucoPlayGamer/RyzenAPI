-- Lua provided by RyzenAPI 
-- Game: Driver Fusion
addappid(234820)
addappid(234821, 1, "a89074202c42f17c5a74caa7683082d9b5649ce0cb16e194594a43ef599c6b84")
