-- Lua provided by RyzenAPI
-- Game: 234820

-- MAIN APPLICATION
addappid(234820)
-- Game: addappid(234820)

-- MAIN APP DEPOTS / PACKAGES
addappid(234821, 1, "a89074202c42f17c5a74caa7683082d9b5649ce0cb16e194594a43ef599c6b84")
