-- Lua provided by RyzenAPI
-- Game: Driver Fusion

-- MAIN APPLICATION
addappid(234820)
addappid(864660)
addappid(865340)
addappid(865350)
addappid(865351)
addappid(1095930)
addappid(1339390)
addappid(1339391)
addappid(1623030)
addappid(1623031)
addappid(2014860)
addappid(2014861)
addappid(2625230)
addappid(2625240)
addappid(2625260)
addappid(3481420)
addappid(3481430)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(234821, 1, "a89074202c42f17c5a74caa7683082d9b5649ce0cb16e194594a43ef599c6b84")

