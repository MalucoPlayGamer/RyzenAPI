-- Lua provided by RyzenAPI
-- Game: The Trap 2: Mindlock (beta)

-- MAIN APPLICATION
addappid(638800)
-- Game: addappid(638800)

-- MAIN APP DEPOTS / PACKAGES
addappid(638804,0,"cfdf270d35772f67d7b1ecf24ec44e0deca6b15e3460ce833882fad75be36cea")
