-- Lua provided by RyzenAPI
-- Game: Sunset's Ashes

-- MAIN APPLICATION
addappid(557890)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(558000)
