-- Lua provided by RyzenAPI
-- Game: Sunset's Ashes

-- MAIN APPLICATION
addappid(557890)

