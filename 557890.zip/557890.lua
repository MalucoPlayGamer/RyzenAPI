-- Lua provided by RyzenAPI
-- Game: Sunset's Ashes

-- MAIN APPLICATION
addappid(557890)
addappid(558000)

