-- Lua provided by RyzenAPI
-- Game: Night Sing

-- MAIN APPLICATION
addappid(1097310)
-- Game: addappid(1097310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1097311, 1, "1234135bcdb3b8429954089348bc445475d4fa9eaf3a83da34c781712b0231eb")
