-- Lua provided by RyzenAPI
-- Game: addappid(1089180)

-- MAIN APPLICATION
addappid(1089180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089180,0,"57ff46f34c6cdae9c5e813abb4865be96db0c2bebf99ad7206c9c467d47bf20a")
addtoken(1089180,"13291618739727557465")
