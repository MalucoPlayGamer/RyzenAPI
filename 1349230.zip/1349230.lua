-- Lua provided by RyzenAPI
-- Game: 5D Chess With Multiverse Time Travel

-- MAIN APPLICATION
addappid(1349230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1349231, 1, "9af1a46110145388fed5f1c59a4522a11827a0ae75a52513502241458a4f379e")
addappid(1349232, 1, "d3b212bbee6a3c8abeea29355ef11645bfc5c62d00dfee28276878f518d1bbb0")
addappid(1349233, 1, "26e59a051b7ea99212454bf5594b3ae211aee40400fcd97edff0bf0dcd744ff4")

