-- Lua provided by RyzenAPI
-- Game: Love n War: Warlord by Chance

-- MAIN APPLICATION
addappid(1508680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508681, 1, "49f5ff76cf50a3adbbf14e284efcf8faf6bb9b3af96c8e91ffa3a8650dd8d05d")
