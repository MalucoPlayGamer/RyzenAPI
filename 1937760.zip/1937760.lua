-- Lua provided by SkyAPI 
-- Game: Prime of Flames Demo
addappid(1937760)
addappid(1937761, 1, "da7d19e51506294720fa976ca838d13a151233d5221626d7341107c84f432971")
