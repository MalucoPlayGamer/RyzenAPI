-- Lua provided by RyzenAPI
-- Game: Prime of Flames Demo

-- MAIN APPLICATION
addappid(1937760)
-- Game: addappid(1937760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937761, 1, "da7d19e51506294720fa976ca838d13a151233d5221626d7341107c84f432971")
