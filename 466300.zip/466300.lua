-- Lua provided by RyzenAPI
-- Game: Planescape: Torment: Enhanced Edition

-- MAIN APPLICATION
addappid(466300)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(466301, 1, "f5dea5dc2a4dd02dc4c62171ebccd439b3832f5221cb4ed1d56ce6044c031bed")
addappid(466302, 1, "90215b43e3e7041c3a400e585e110826f4e3b29d74bff7e1b9743d4595f268ae")
addappid(466303, 1, "ea417d8bb1f1503643c8a862131dcc29b03926c2a429cc3ed2ae4664e4f4358c")
addappid(466304, 1, "dae8e1cbc57b62791ec74958f07808a281bc3d973079b8fec88b0878c8a346a1")

