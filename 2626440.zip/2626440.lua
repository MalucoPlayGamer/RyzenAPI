-- Lua provided by RyzenAPI
-- Game: Brothel of Darkness Demo

-- MAIN APPLICATION
addappid(2626440)
-- Game: addappid(2626440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626441, 1, "b4f87d0c04d9e391949a88a8c90c95311889f9b8211bd8b3e7fb405d45c4a668")
