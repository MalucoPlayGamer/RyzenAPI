-- Lua provided by RyzenAPI
-- Game: addappid(945880)

-- MAIN APPLICATION
addappid(945880)

-- MAIN APP DEPOTS / PACKAGES
addappid(945881, 1, "7a0e881177bded0da7d61ad82ad04ff24e856ba8abaaec084ffcbcfc7f91112e")
