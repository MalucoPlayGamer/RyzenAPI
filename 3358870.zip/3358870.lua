-- Lua provided by RyzenAPI 
-- Game: AppID 3358870
addappid(3358870)
addappid(3358871, 1, "b94c1026ceb151bbbb472ead481ac73e366e9c03ee61e9960803098849d28f24")
