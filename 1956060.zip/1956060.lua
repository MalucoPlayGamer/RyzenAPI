-- Lua provided by RyzenAPI
-- Game: 1956060

-- MAIN APPLICATION
addappid(1956060)
-- Game: addappid(1956060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1956061, 1, "08465e336c0d340bad2cf9b02d2ade13527442abfa98df30735117d8c89ffc32")
