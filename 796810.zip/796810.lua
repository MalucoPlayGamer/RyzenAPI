-- Lua provided by RyzenAPI
-- Game: AppID 796810

-- MAIN APPLICATION
addappid(796810)
-- Game: addappid(796810)

-- MAIN APP DEPOTS / PACKAGES
addappid(796811, 1, "feb831f6c1fe8a005e6a5a7d91d252fa433b337148146939b4506f3e4d21a668")
