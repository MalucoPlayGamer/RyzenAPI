-- Lua provided by RyzenAPI
-- Game: Game: Bewitching Sinners Demo

-- MAIN APPLICATION
addappid(2615760)
-- Game: addappid(2615760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2615761, 1, "dace48495a336acb6c4a8f5ae33e2c0e5e9f57cb04bb71b7fa7876f698a48782")
