-- Lua provided by RyzenAPI
-- Game: Spooky Milk Life

-- MAIN APPLICATION
addappid(1621540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1621541, 1, "da248b681f7058df83a67345a8b402b8cfd5bdcfa64a115ae25dfc53352973f7")

