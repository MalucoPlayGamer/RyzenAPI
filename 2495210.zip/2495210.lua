-- Lua provided by RyzenAPI
-- Game: Lost Crystals

-- MAIN APPLICATION
addappid(2495210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2495211, 1, "82f0c2350fab95cdb4a7401f27f8236a8142349676cb1315ba1e7d10377010cb")
