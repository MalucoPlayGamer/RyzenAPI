-- Lua provided by RyzenAPI
-- Game: Game: Rollin' Rascal Demo

-- MAIN APPLICATION
addappid(2809080)
-- Game: addappid(2809080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2809081, 1, "21615da354ee0c01b921544463333d83a8c0ecc7817eff1c4a6f27535291aa96")
