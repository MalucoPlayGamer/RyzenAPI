-- Lua provided by RyzenAPI
-- Game: Battlecruiser Generations

-- MAIN APPLICATION
addappid(1755420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755421, 1, "d5e7e97fb761baf3a699af865e688b46d032e85b5edcb96dd815fc9be9b1fe12")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
