-- Lua provided by RyzenAPI
-- Game: addappid(1755420)

-- MAIN APPLICATION
addappid(1755420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755421, 1, "d5e7e97fb761baf3a699af865e688b46d032e85b5edcb96dd815fc9be9b1fe12")
