-- Lua provided by RyzenAPI
-- Game: 2464470

-- MAIN APPLICATION
addappid(2464470)
-- Game: addappid(2464470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464471, 1, "9b1ce1cf695e9301e30270beb31c2d5f86af7bf04a8ea1347849586a9cd45823")
