-- Lua provided by RyzenAPI
-- Game: Farming Simulator 15

-- MAIN APPLICATION
addappid(313160)
addappid(327540)
addappid(327541)
addappid(327542)
addappid(327543)
addappid(327545)
addappid(327548)
addappid(327549)

-- MAIN APP DEPOTS / PACKAGES
addappid(313161, 1, "6d9326de17be17ef5be4e5adf2b1ca9d23921b0e4f3fa06d07c1d6a68e790d77")
addappid(313162, 1, "27d6461f13f1a77c2db66f2aaa53f2fffda90f9c584b58c1d52f8eb9c50bdb68")
addappid(327544, 0, "8208ef870d729ec3ba1e50102baccfa768b7ee84a9964f61aefef42664069138")
addappid(327546, 0, "8f2816e0a37f8fc3c3a7ac9b7b9e136d3222928d76012816fa98d9ba41c8641e")
addappid(327547, 0, "00445d6ef540bb21f208c9b02aa354e0e8cfa648d6f445a4905bd2f4a5f6945a")
addappid(327550, 0, "5e9f6ee13426cad940d607be2049e1996fd50e5241ae72e8f85bec2b0f7e53a1")
addappid(335290, 0, "8d88fcfe76a61dc548c557acb79f9a734c2532cd71f5b0b201cac36b480dff69")
addappid(345740, 0, "62c3664ffb5af47eadf8ce315f47116731575b9909881d202d96800d13142eb9")
addappid(345741, 0, "030dec284fc690653d89d272de419ca20bda15d1fc2e67b88918fcbd07b4d37d")
addappid(374850, 0, "4fc20ab1f4f6e67d92be953fc5b7deed7f11805b7c65b6c408a09398837dd79a")
addappid(374851, 0, "4455047e62a4d661d71f8cbbdcdabde1ea553536203a443af5f93ab61ad7e971")
addappid(381240, 0, "0c0c0ae392b81438b0915fb02253f452a4d334c56f13d84dc568876e8d2e2276")
addappid(411040, 0, "b503b8b9ddbc8fb9f60b9b3afaca90e1e8cdad532a9ef1e97ceeb26bee3915ee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
