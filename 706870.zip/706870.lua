-- Lua provided by RyzenAPI
-- Game: addappid(706870)

-- MAIN APPLICATION
addappid(706870)

-- MAIN APP DEPOTS / PACKAGES
addappid(706871, 1, "fc563f0b69dcab720c035730cf284bcf2336a9ef0932654ed2b1706fec4523db")
