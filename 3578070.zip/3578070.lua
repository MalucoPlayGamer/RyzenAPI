-- Lua provided by RyzenAPI
-- Game: Shake it Co!

-- MAIN APPLICATION
addappid(3578070) -- Shake it Co!

-- MAIN APP DEPOTS / PACKAGES
addappid(3578071, 1, "2520663868879334d88f35c478b491c1cd6ad3878c2cc1959fba78072e34e03d") -- Depot 3578071

