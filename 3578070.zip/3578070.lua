-- 3578070's Lua and Manifest Created by Hubcap Manifest
-- Shake it Co!
-- Created: August 19, 2026 at 13:49:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3578070) -- Shake it Co!
-- MAIN APP DEPOTS
addappid(3578071, 1, "2520663868879334d88f35c478b491c1cd6ad3878c2cc1959fba78072e34e03d") -- Depot 3578071
setManifestid(3578071, "7957695502450430252", 186833167)