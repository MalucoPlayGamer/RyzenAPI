-- Lua provided by RyzenAPI
-- Game: - Mischief Dungeon Life - 異世界転生した俺のイタズラダンジョンライフ Janice Edition

-- MAIN APPLICATION
addappid(2184420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2184421, 1, "d4650aa7d9f8a08dc97301cb503f6324fe0e6a9d171e720261f27652e90e4a23")

