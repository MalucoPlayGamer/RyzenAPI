-- Lua provided by RyzenAPI
-- Game: Pixel Starships

-- MAIN APPLICATION
addappid(378760)

-- MAIN APP DEPOTS / PACKAGES
addappid(378761, 1, "f7aa7945fe08f57631e1cecc6b3f092e3cedc62bbcd22a6666998adcf0b7d026")
addappid(378762, 1, "7ebb22ed5e4d93065084a0c2213da9ce2c670f5c766a740d95a7a027726b5a32")
addappid(378763, 1, "58fc74e167c2c3cfd065a3f0ad706461505ab2be6c3eac7f8f370bf08e2a99b9")

