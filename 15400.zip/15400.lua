-- Lua provided by RyzenAPI
-- Game: Harvest: Massive Encounter

-- MAIN APPLICATION
addappid(15400)

-- MAIN APP DEPOTS / PACKAGES
addappid(15401, 1, "a1839e5b86b090caa32040fd5460a13c7264ade8fa7699b16aa883d0b5329a03")
addappid(15402, 1, "7022436f45fd7841d80f2f43e5b6d9ae5765c56c66667ae6a9160335d070af38")
addappid(15403, 1, "aa13f3fa345f0b517220b2a9c3f37f8bcede8d7ada6c95d9aa0adb793b33e302")
