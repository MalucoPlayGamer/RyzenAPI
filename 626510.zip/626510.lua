-- Lua provided by RyzenAPI
-- Game: LoveKami -Useless Goddess-

-- MAIN APPLICATION
addappid(626510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(626511, 1, "b13fabb430b845494587877101c055c614ae5416f3d64040fd79558925ae7258")
addappid(626512, 1, "a08daca5572d870ffadee3020daa90bf6f6a7de812e0359f6e3024e6672257e3")
addappid(626514, 1, "f7a20207ff5fa76d2dc65b1f7fc2f4c02b6962c43cab9acf9e24fd37b008459f")
addappid(1007510, 0, "74f75d44cdc1ff74b2909dc7c527f9758ca0d2d5e6d011b50d7b20634654efa4")
