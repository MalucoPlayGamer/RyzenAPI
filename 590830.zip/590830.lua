-- Lua provided by RyzenAPI
-- Game: s&box

-- MAIN APPLICATION
addappid(590830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(590831, 1, "5368f87f9235f5cd8144e9eea13824133defa90e4a90c2d478fac61ca5cfcc8a")
