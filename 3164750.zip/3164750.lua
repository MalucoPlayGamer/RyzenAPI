-- Lua provided by RyzenAPI
-- Game: Sandbox:God Simulator Demo

-- MAIN APPLICATION
addappid(3164750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3164751, 1, "1979131136ff2b76c71f6b5918ed4095d9d7d421c176bc569b5c3c7d3589cc86")
