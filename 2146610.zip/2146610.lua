-- Lua provided by RyzenAPI
-- Game: Game: Reality Rash

-- MAIN APPLICATION
addappid(2146610)
-- Game: addappid(2146610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2146611, 1, "265665f00e094c47961e7d83e243858ca766fe34c6fc5bbe720a351f03817967")
