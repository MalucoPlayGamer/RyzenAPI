-- Lua provided by RyzenAPI
-- Game: 2083720

-- MAIN APPLICATION
addappid(2083720)
-- Game: addappid(2083720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2083721, 1, "2acbd340457ecaeee6c0d9eb5a3b82ceb5572d31d89d72751228d18a4c82a04a")
