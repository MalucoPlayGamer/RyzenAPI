-- 3561740's Lua and Manifest Created by Hubcap Manifest
-- Detective Sherlock: Shadow Stalker
-- Created: August 21, 2026 at 22:33:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3561740) -- Detective Sherlock: Shadow Stalker
addtoken(3561740, "25151509749104112")
-- MAIN APP DEPOTS
addappid(3561741, 1, "2cc00726d7929ca88066123619d9d4d535eaeb281a503a43fe010d2e4ff061a5") -- Depot 3561741
setManifestid(3561741, "4984802577957080281", 16711438435)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3561742) -- Depot 3561742 (empty depot)