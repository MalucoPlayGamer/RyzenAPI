-- Lua provided by RyzenAPI
-- Game: Detective Sherlock: Shadow Stalker

-- MAIN APPLICATION
addappid(3561740) -- Detective Sherlock: Shadow Stalker
-- addappid(3561742) -- Depot 3561742 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(3561741, 1, "2cc00726d7929ca88066123619d9d4d535eaeb281a503a43fe010d2e4ff061a5") -- Depot 3561741
addtoken(3561740, "25151509749104112")

