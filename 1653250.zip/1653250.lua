-- Lua provided by RyzenAPI
-- Game: Alien Flex

-- MAIN APPLICATION
addappid(1653250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1653251, 1, "e6e2a1687579c1934b0c2287d6b64441f9fb9c78a8e268be50f284d649be1f83")

