-- Lua provided by RyzenAPI
-- Game: Alien Flex

-- MAIN APPLICATION
addappid(1653250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653251, 1, "e6e2a1687579c1934b0c2287d6b64441f9fb9c78a8e268be50f284d649be1f83")

