-- Lua provided by RyzenAPI
-- Game: 2736220

-- MAIN APPLICATION
addappid(2736220)
-- Game: addappid(2736220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2736222,0,"956b2a5d452e0289ffe137df45b11b19ee23735dec3d82d5f1eeec4334c360d8")
