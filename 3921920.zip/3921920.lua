-- Lua provided by RyzenAPI
-- Game: Discarded

-- MAIN APPLICATION
addappid(3921920) -- Discarded

-- MAIN APP DEPOTS / PACKAGES
addappid(3921921, 1, "23cc91fb6cb49da6b69170e9e5c379eab58014af22a0ab9d89d6e3e789a61054") -- Depot 3921921

