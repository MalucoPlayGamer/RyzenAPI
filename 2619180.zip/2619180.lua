-- Lua provided by RyzenAPI
-- Game: 小夜怪奇物语

-- MAIN APPLICATION
addappid(2619180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2619181, 1, "3a27c4ac995d44c53917c0bcc808316e1a718356640dc6f612b5245b95431f5b")
addappid(2753280, 0, "7f3464bb57b11bea066802dd4ba2c9b1f846bf698e1f2a29442e48910349b8fc")
addappid(2858260, 0, "cec8236cf3f9a7590602623e0c2ddc484a08c387b6e70e9448ea24ab45bb4995")
addappid(2986560, 0, "bec3f472af85d262ad2acd5f7cb4ca780ed0e1dd2ee6e81b149ea71df0631265")
addappid(3125240, 0, "51c909c42978dd35808a6721202bc0b89854a6e8bd4c76b0425a8b0d21acff4b")
addappid(3283780, 0, "5813003e0f38ed7113be60cb2f43361fd2e866faee19efc9e8f7892ab36c99f2")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3451450)
addappid(3851060)
