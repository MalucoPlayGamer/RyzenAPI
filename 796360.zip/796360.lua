-- Lua provided by RyzenAPI
-- Game: 796360

-- MAIN APPLICATION
addappid(796360)
-- Game: addappid(796360)

-- MAIN APP DEPOTS / PACKAGES
addappid(796361, 1, "4f481171e42080f93bce997fc83e7870bd42f2f6119443db1b98ebe874635259")
