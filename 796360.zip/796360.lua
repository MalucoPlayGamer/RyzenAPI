-- Lua provided by RyzenAPI 
-- Game: JQ: countries
addappid(796360)
addappid(796361, 1, "4f481171e42080f93bce997fc83e7870bd42f2f6119443db1b98ebe874635259")
