-- Lua provided by RyzenAPI
-- Game: Train Your Minibot Soundtrack

-- MAIN APPLICATION
addappid(1802750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802751, 1, "d9ba46949bc50cbdf3b865b83f322c331cc0af39f54ae0d02ccb36ed80f6cb1b")
addappid(1802752, 1, "30088ae6c080af87aee74442d2a93e95d39314795ba559247b6cb7612a268b90")
