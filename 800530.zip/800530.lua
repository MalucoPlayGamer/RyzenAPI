-- Lua provided by RyzenAPI
-- Game: 800530

-- MAIN APPLICATION
addappid(800530)
-- Game: addappid(800530)

-- MAIN APP DEPOTS / PACKAGES
addappid(800531, 1, "f7f51a761a9746a97ee61244617d907770af460b9b3860eb2d60afc27ee16a9a")
