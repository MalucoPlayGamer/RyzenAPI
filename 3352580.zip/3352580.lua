-- Lua provided by RyzenAPI
-- Game: Aloft - Supporter Pack

-- MAIN APPLICATION
addappid(3352580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3352580,0,"dad71f0783613579b08d5787dc32c61d420acb327988eb00bb6049ff1df2b630")
