-- 2684630's Lua and Manifest Created by Hubcap Manifest
-- Endacopia
-- Created: July 27, 2026 at 11:34:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2684630) -- Endacopia
-- MAIN APP DEPOTS
addappid(2684631, 1, "1f7bf3167ca617389ebcd08272a36520465e1b68f1209370d34e4edfb6e4d78d") -- Depot 2684631
setManifestid(2684631, "4944600836437285723", 2985198715)