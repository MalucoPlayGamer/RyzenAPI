-- Lua provided by RyzenAPI
-- Game: Endacopia

-- MAIN APPLICATION
addappid(2684630)
addappid(2684630) -- Endacopia

-- MAIN APP DEPOTS / PACKAGES
addappid(2684631, 1, "1f7bf3167ca617389ebcd08272a36520465e1b68f1209370d34e4edfb6e4d78d")
addappid(2684631, 1, "1f7bf3167ca617389ebcd08272a36520465e1b68f1209370d34e4edfb6e4d78d") -- Depot 2684631

