-- Lua provided by RyzenAPI
-- Game: AppID 3262590

-- MAIN APPLICATION
addappid(3262590)
-- Game: addappid(3262590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3262591, 1, "c3a297c4b210e5700e698006a545b1de31e7b9b631e8d9b44a5d5eb81fa7b698")
