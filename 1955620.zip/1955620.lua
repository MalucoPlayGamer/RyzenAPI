-- Lua provided by SkyAPI 
-- Game: Adventure Academia: The Fractured Continent Transfer Edition
addappid(1955620)
addappid(1955621, 1, "94212f176d5bd0861762a9b3146bda9c5dfd6fb5635b0a421766ffa99060e6d3")
