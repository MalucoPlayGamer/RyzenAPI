-- Lua provided by RyzenAPI
-- Game: Game: Malys

-- MAIN APPLICATION
addappid(3449690)
-- Game: addappid(3449690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3449691, 1, "3962c8c91bc4a3a623b45fbb4a197f96573f4b23e86d1b3f66c3f102d25e9539")
