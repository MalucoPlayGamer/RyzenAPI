-- Lua provided by RyzenAPI
-- Game: How Many Dudes?

-- MAIN APPLICATION
addappid(3934270)
addappid(4815310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3934271,0,"36c4014d117bde08b3fe39c4f0974fe3fd9dab69393e815c7c7fd008c0680363")
addappid(4815311,0,"a71a82affca1675f08f3e9e13b4c1f6f912196c28f2cc0ea63582216221db25f")

