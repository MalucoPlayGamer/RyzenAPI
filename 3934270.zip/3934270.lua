-- 3934270's Lua and Manifest Created by Hubcap Manifest
-- How Many Dudes?
-- Created: July 30, 2026 at 14:12:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3934270) -- How Many Dudes?
-- MAIN APP DEPOTS
addappid(3934271, 1, "36c4014d117bde08b3fe39c4f0974fe3fd9dab69393e815c7c7fd008c0680363") -- Depot 3934271
setManifestid(3934271, "8298934312075159838", 196505402)
-- SHARED DEPOTS (from other apps)
addappid(4815311, 1, "a71a82affca1675f08f3e9e13b4c1f6f912196c28f2cc0ea63582216221db25f") -- Depot 4815311 (Shared from App 4815310)
setManifestid(4815311, "3677334875839138521", 77698472)