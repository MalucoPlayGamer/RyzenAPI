-- Lua provided by RyzenAPI
-- Game: Paper Trail Demo

-- MAIN APPLICATION
addappid(2001940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2001941, 1, "216c4c1f3bba1433cfd584b2af5fae7cf971f66f5281a94b5a32f20e010e8218")
