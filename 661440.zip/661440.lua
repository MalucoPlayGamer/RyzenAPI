-- Lua provided by RyzenAPI 
-- Game: AppID 661440
addappid(661440)
addappid(661441, 1, "89dcdb925c6982c5d97b4c39faf93867cadb2475528be3fe7d0ffb946532d624")
