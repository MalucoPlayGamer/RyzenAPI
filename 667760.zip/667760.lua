-- Lua provided by RyzenAPI
-- Game: Game: Super Lumi Live

-- MAIN APPLICATION
addappid(667760)
-- Game: addappid(667760)

-- MAIN APP DEPOTS / PACKAGES
addappid(667761, 1, "d62667fbd132469dd1c3db50212d4b4ee8b2fd925fb58984f9e17ec07597c114")
