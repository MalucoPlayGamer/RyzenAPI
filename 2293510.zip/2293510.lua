-- Lua provided by RyzenAPI
-- Game: Game: The Last Pawn

-- MAIN APPLICATION
addappid(2293510)
-- Game: addappid(2293510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293511, 1, "800ae9a6fbcf0fc01d65efee5556dc78d6751391ef6f2b669aeccb083e6b5187")
