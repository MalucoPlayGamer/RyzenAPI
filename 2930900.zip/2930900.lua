-- Lua provided by RyzenAPI
-- Game: 2930900

-- MAIN APPLICATION
addappid(2930900)
-- Game: addappid(2930900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2930901, 1, "25bd5858f7c9e6154a86b59c7bac0f9f0574c66eae97ae7d384b4117ccf3e957")
