-- Lua provided by RyzenAPI
-- Game: addappid(748370)

-- MAIN APPLICATION
addappid(748370)

-- MAIN APP DEPOTS / PACKAGES
addappid(748371, 1, "6bd0f58014630145a77fae96aa6fa613abd6419abbf5eac950f38a6182774435")
