-- Lua provided by RyzenAPI
-- Game: Don't Steal My Christmas!

-- MAIN APPLICATION
addappid(2244550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2244551, 1, "6ee2fd2324011164e95ac71f8763721fcb9bda47d730a1ac68f2a31a2463d054")

