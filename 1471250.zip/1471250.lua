-- Lua provided by RyzenAPI
-- Game: Orion: The Eternal Punishment

-- MAIN APPLICATION
addappid(1471250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1471251, 1, "ac699abcd9f5df040eaf71f353276fd34a85bcaccbc2ce9975bd4d95cec2693f")
addappid(1471252, 1, "6d58850195fec3e164dd5a194f3e42ee63cc8c0ff74ecc58fe41639bad54ccd7")
addappid(1471253, 1, "00955f5d150050bfac22dccb803e46256b3ca4cff566307d6ddadf7a3a236ecc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
