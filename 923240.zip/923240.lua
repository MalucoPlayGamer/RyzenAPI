-- Lua provided by RyzenAPI
-- Game: 923240

-- MAIN APPLICATION
addappid(923240)
-- Game: addappid(923240)

-- MAIN APP DEPOTS / PACKAGES
addappid(923241, 1, "295411f1dad3c3da9151dc74adadf38fb88c2e447c21c80c9346e3555473cc55")
