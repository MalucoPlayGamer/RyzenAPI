-- Lua provided by RyzenAPI
-- Game: Game: Chernobylite Soundtrack

-- MAIN APPLICATION
addappid(1847400)
-- Game: addappid(1847400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1847401, 1, "7b6ae2a3d3126a7c53d0c7fb506e27cb982e2ac8742857492c7b776f8dcc3bb4")
addappid(1847402, 1, "143d8c7cb0f9fe8b5033451924f8235ffe13c43cbcd891a6253966a51d3ac52f")
