-- Lua provided by RyzenAPI
-- Game: War Sniper

-- MAIN APPLICATION
addappid(2960870)

