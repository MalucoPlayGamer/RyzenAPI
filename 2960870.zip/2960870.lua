-- Lua provided by RyzenAPI
-- Game: War Sniper

-- MAIN APPLICATION
addappid(2960870)



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
