-- Lua provided by RyzenAPI
-- Game: addappid(3138360)

-- MAIN APPLICATION
addappid(3138360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3138361, 1, "8646b08180f73b5b8432e8cba6baf21be1b0c2b32d3f6b4e354a0d629aade708")
