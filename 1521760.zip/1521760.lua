-- Lua provided by RyzenAPI
-- Game: Game: Dodge Dancer

-- MAIN APPLICATION
addappid(1521760)
-- Game: addappid(1521760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1521761, 1, "34252d2790ab2d878e5682e9e96948081112b19d018f36cab4af7fe56a645565")
