-- Lua provided by RyzenAPI
-- Game: 3376990

-- MAIN APPLICATION
addappid(3376990)
-- Game: addappid(3376990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3376991, 1, "9c080119de190e58867a36189eee04c7dee1ade72b6654388f8795f8b3b4fa5f")
