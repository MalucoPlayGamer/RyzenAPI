-- Lua provided by SkyAPI 
-- Game: Missing Stars
addappid(2261640)
addappid(2261641, 1, "af5f9cf90a2af391e5ebb1f31bef606b5559b2407fe210abd7f66f2eb18b2f93")
