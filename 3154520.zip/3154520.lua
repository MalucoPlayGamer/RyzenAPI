-- Lua provided by RyzenAPI
-- Game: Blob

-- MAIN APPLICATION
addappid(3154520)
-- Game: addappid(3154520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3154521, 1, "89fbd1388ca2c3130a25983bfa9775e39af1f447c79fc766d4e3249745d14582")
