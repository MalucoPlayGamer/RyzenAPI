-- Lua provided by RyzenAPI 
-- Game: AppID 1154360
addappid(1154360)
addappid(1154361, 1, "baae7ec280ee03178c6f886e6302e97a40a652c7d5f43e26aa800f7ba4c182a3")
