-- Lua provided by RyzenAPI
-- Game: Game: MEMASIKI

-- MAIN APPLICATION
addappid(3629210)
-- Game: addappid(3629210)

-- MAIN APP DEPOTS / PACKAGES
addappid(3629211, 1, "d672c6a88c35d9f0869360dd507a85f64f792a7fcc1567429e2129be6d3b3306")
