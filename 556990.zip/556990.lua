-- Lua provided by RyzenAPI
-- Game: Game: Rage Against The Zombies

-- MAIN APPLICATION
addappid(556990)
-- Game: addappid(556990)

-- MAIN APP DEPOTS / PACKAGES
addappid(556991, 1, "19d36f23726fbea08400cf4a4863bc65900433c671b2231079b46310205172de")
addappid(556992, 1, "55eb6bfe5a7b2aa8d676b56b6b8791d261875449534c46c0b0b61de383b0c1fd")
