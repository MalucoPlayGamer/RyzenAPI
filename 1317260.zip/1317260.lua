-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: SAM AirportVehicles

-- MAIN APPLICATION
addappid(1317260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1317260,0,"53e0fec4820982dd308ad3930544554040b925eb85c615e2d06a4b1c3faefa82")

