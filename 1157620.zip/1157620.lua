-- Lua provided by RyzenAPI
-- Game: Game: Magical MILFs

-- MAIN APPLICATION
addappid(1157620)
-- Game: addappid(1157620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1157621, 1, "420ee3fc1ba43d4c24fe45776f303d0817b1086f9616527d424284471bf1027f")
