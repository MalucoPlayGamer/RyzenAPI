-- Lua provided by RyzenAPI
-- Game: Clamb Demo

-- MAIN APPLICATION
addappid(3015340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015341, 1, "e7180a0f1641eed21b7c42cb0f7b4dbb029d88a464e12c9b395c9debeac14ef9")
