-- Lua provided by RyzenAPI
-- Game: 550440

-- MAIN APPLICATION
addappid(550440)
-- Game: addappid(550440)

-- MAIN APP DEPOTS / PACKAGES
addappid(550441, 1, "a1fa544e31ee45f9d33907ba9ef84091c22096f22516d062b388e95dcd8eb9ba")
