-- Lua provided by RyzenAPI
-- Game: 2652000

-- MAIN APPLICATION
addappid(2652000)
-- Game: addappid(2652000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2652001, 1, "069ba0e8e16bf5418b151bc0240f072aeb58e0bb6e1982fa50539cf3efeb7ad8")
addappid(2652002, 1, "97ca61c0aed079afd1bfa4d068be272475d6c3eb2fd400074b6b5b3a1abfcc09")
addappid(2828508, 0, "86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")
