-- Lua provided by RyzenAPI
-- Game: Dusk City

-- MAIN APPLICATION
addappid(2973120)
addappid(4603110)
-- Game: addappid(2973120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2973121, 1, "22c01bbafdfb219a5fd9ba90848c076d2fc0a62366836087c2a8aed2d9c44339")
addappid(2973122, 1, "d7d1f397f1b5038d3a5cf8597157319b7ca6eeb5933015b27e4ed9b9f722ca6f")
addappid(2973123, 1, "dce7b2f5d76759d38587d0330b673efad0c28c0c47ac29e9ab7f6b450d42ab81")
addappid(2973124, 1, "8336ffde5b25ce0a901425e42a3b8114d9d11cf87d411c29f5579b390199957e")
