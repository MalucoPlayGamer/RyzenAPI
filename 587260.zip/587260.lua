-- Lua provided by RyzenAPI
-- Game: Tokyo Xanadu eX+

-- MAIN APPLICATION
addappid(587260)

-- MAIN APP DEPOTS / PACKAGES
addappid(587261, 1, "eddc2dc1d0ce0bfb1568a287bb37ec876697d9613a139f9b93e54d3c03fc6cbd")
