-- Lua provided by RyzenAPI
-- Game: Tokyo Xanadu eX+

-- MAIN APPLICATION
addappid(587260)

-- MAIN APP DEPOTS / PACKAGES
addappid(587261, 1, "eddc2dc1d0ce0bfb1568a287bb37ec876697d9613a139f9b93e54d3c03fc6cbd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(750910)
addappid(750911)
addappid(750912)
