-- Lua provided by RyzenAPI
-- Game: AppID 895170

-- MAIN APPLICATION
addappid(895170)
-- Game: addappid(895170)

-- MAIN APP DEPOTS / PACKAGES
addappid(895171, 1, "2311b120d774523c09e45d6f9e85f9671642a45ba63a25f7bd480b437c812df0")
