-- Lua provided by RyzenAPI
-- Game: Drop Up

-- MAIN APPLICATION
addappid(895170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(895171, 1, "2311b120d774523c09e45d6f9e85f9671642a45ba63a25f7bd480b437c812df0")

