-- Lua provided by RyzenAPI
-- Game: Zhong Hui - Officer Ticket / 鍾会使用券

-- MAIN APPLICATION
addappid(956863)
-- Game: addappid(956863)

-- MAIN APP DEPOTS / PACKAGES
addappid(956863,0,"b0ccd31266300c79465e1f27ebcdcd549c4ec0931db309874907c83a7fd3250a")
