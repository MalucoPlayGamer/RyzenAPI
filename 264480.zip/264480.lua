-- Lua provided by RyzenAPI
-- Game: 264480

-- MAIN APPLICATION
addappid(229002)
addappid(229003)
addappid(229004)
addappid(229020)
addappid(229032)
addappid(264480)

-- MAIN APP DEPOTS / PACKAGES
addappid(264482,0,"d532a6b2bbdf71f2379acd17ab59e247dbcbbae23343d6f40698b2758315898c")
addtoken(264480,16839124779470641561)

