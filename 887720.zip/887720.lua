-- Lua provided by RyzenAPI
-- Game: Game: AppID 887720

-- MAIN APPLICATION
addappid(887720)
-- Game: addappid(887720)

-- MAIN APP DEPOTS / PACKAGES
addappid(887721, 1, "27042f0b9353a83d5f5650d2ef58741aa50cde4a136b7686b14a130616959f60")
