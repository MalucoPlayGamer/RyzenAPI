-- Lua provided by RyzenAPI
-- Game: AppID 887720

-- MAIN APPLICATION
addappid(887720)

-- MAIN APP DEPOTS / PACKAGES
addappid(887721, 1, "27042f0b9353a83d5f5650d2ef58741aa50cde4a136b7686b14a130616959f60")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
