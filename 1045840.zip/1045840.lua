-- Lua provided by RyzenAPI
-- Game: Intruders: Hide and Seek

-- MAIN APPLICATION
addappid(1045840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045841, 1, "d831f043f921f6380253d192d7b50a09815e999819f0689938e2107c7ad92756")
