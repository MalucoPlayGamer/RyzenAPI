-- Lua provided by RyzenAPI
-- Game: Game: Moonflower

-- MAIN APPLICATION
addappid(2145530)
addappid(2442210)
-- Game: addappid(2145530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2145531, 1, "00f64837323457366f28c0680bdcc514a94d2165be61913fe7ee65a68a6d5cd5")
