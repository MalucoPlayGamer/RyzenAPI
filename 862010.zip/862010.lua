-- Lua provided by RyzenAPI
-- Game: Weird Dungeon Explorer: Defender

-- MAIN APPLICATION
addappid(862010)

-- MAIN APP DEPOTS / PACKAGES
addappid(862011, 1, "6190166bff95501e74f655757e48dfbae0d63c819d00d3c15f5e029188babc8b")

