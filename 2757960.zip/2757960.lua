-- Lua provided by RyzenAPI
-- Game: Project Cradle Demo

-- MAIN APPLICATION
addappid(2757960)
-- Game: addappid(2757960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757961, 1, "c4bebdf285d4ddb1d382700680c600cd769b7b68c7c1e3d80697e4f395eed47a")
