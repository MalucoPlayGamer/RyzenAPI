-- Lua provided by RyzenAPI
-- Game: addappid(1364760)

-- MAIN APPLICATION
addappid(1364760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364761, 1, "d6e0a91c184b5daccafdd35a61687c82e6b24242040af1634b39fd3f84b7a89f")
