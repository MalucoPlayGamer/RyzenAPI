-- Lua provided by RyzenAPI
-- Game: COTTOn Rock'n'Roll -SUPERLATIVE NIGHT DREAMS-

-- MAIN APPLICATION
addappid(1364760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1364761, 1, "d6e0a91c184b5daccafdd35a61687c82e6b24242040af1634b39fd3f84b7a89f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
