-- Lua provided by RyzenAPI
-- Game: 548810

-- MAIN APPLICATION
addappid(548810)
-- Game: addappid(548810)

-- MAIN APP DEPOTS / PACKAGES
addappid(548811, 1, "192c8090a3cd28c84884eba31cad1dd00306f6db222b8fe003593afdc644aad5")
addappid(548830, 1, "c0b63d072e7f83d194092ce06b967994a4bdc57bcb3f54ca4c60baf4b44ccc6c")
addappid(548831, 0, "3fd10f9a79bb8d35bd482b7cf94fa1c4ba51709e7a23e9d18713d670450786fc")
