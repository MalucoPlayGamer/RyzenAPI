-- Lua provided by RyzenAPI
-- Game: Operation Babel: New Tokyo Legacy

-- MAIN APPLICATION
addappid(548810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(548811, 1, "192c8090a3cd28c84884eba31cad1dd00306f6db222b8fe003593afdc644aad5")
addappid(548830, 1, "c0b63d072e7f83d194092ce06b967994a4bdc57bcb3f54ca4c60baf4b44ccc6c")
addappid(548831, 0, "3fd10f9a79bb8d35bd482b7cf94fa1c4ba51709e7a23e9d18713d670450786fc")

