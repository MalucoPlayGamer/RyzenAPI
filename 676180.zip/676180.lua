-- Lua provided by RyzenAPI
-- Game: Spaceguard 80

-- MAIN APPLICATION
addappid(676180)

-- MAIN APP DEPOTS / PACKAGES
addappid(676181, 1, "4b6817bbc4516aa8a5a3986772bccfca8c4031adb6802064ba4333111e019daa")

