-- Lua provided by RyzenAPI
-- Game: Supreme Commander 2

-- MAIN APPLICATION
addappid(40100)

-- MAIN APP DEPOTS / PACKAGES
addappid(40102,0,"9e4d9dd412dc1be64d8be651738ec15d4c0b606a301478c65189485cb8f740eb")
addappid(40103,0,"1a74c478ee09ed109ecb262bf9c79a0fa3283e54d7e6cd3d271d388009796a0e")
addappid(40104,0,"57754554261251697ad283d005bc1498efbbd9c5f8037adb975eee4997a2ae0d")
addappid(40105,0,"ef99ebe9827e5df969f6ccbc44b1f8c4cb6f98a131c3cb4eee24a097d0a54f13")
addappid(40106,0,"f856a974eed50f4194ae34b65eb832301c78bb950d42121a709a2f59cbe149cb")
addappid(40107,0,"61b6bdd5d45852ab0055b1ee893925a305fb31e86ad89ed217b1618801a1edeb")
addappid(40108,0,"352dfeb28cbd61280321fe32718384bf1bd3603230d3e3dc5d70968b9098045c")
addappid(40109,0,"538bb108cd783ed872cacee812f765b6967ae35f1f6267673cb8ccdc95fcc397")
addappid(40110,0,"4945396274a7e0d6155c92602336da6771c00a14742719aa2832093b1f3a1ebb")
addappid(40135,0,"1328898f93408d55f7c947b6cf319f50a5045d9bd79f71de6482210e6bb21369")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(40125)
addappid(40130)
addappid(40131)
addappid(40132)
addappid(40133)
addappid(40134)
addappid(40136)
addappid(40230)
