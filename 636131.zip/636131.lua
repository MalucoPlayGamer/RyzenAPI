-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - Airport Oslo

-- MAIN APPLICATION
addappid(636131)

-- MAIN APP DEPOTS / PACKAGES
addappid(638640,0,"9627b4491f5e287cf4388aa70f572110e75da6983a2d00ecdd674c254c8a7b7d")

