-- Lua provided by RyzenAPI 
-- Game: AppID 1274450
addappid(1274450)
addappid(1274451, 1, "7666a4eb0bab9d0db394e6746c1017b82fd00bf107bf36dc54e4382cf55617b0")
