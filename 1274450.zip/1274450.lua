-- Lua provided by RyzenAPI
-- Game: 1274450

-- MAIN APPLICATION
addappid(1274450)
-- Game: addappid(1274450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274451, 1, "7666a4eb0bab9d0db394e6746c1017b82fd00bf107bf36dc54e4382cf55617b0")
