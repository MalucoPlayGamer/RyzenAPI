-- Lua provided by RyzenAPI
-- Game: 2401970

-- MAIN APPLICATION
addappid(2401970)
addappid(2708760)
-- Game: addappid(2401970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2401971, 1, "6207c375742bbad4314f7dd29c0875182fdcb82428b948c4ae9205f86a920a3c")
