-- Lua provided by RyzenAPI
-- Game: Ben and Ed - Blood Party

-- MAIN APPLICATION
addappid(500260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(500261, 1, "79e78eb3295371e7da5cfdfa3281892b714e01796e43584c86eadf0d64fd9626")
addappid(640910, 0, "c389a981b78db9c34f29fe57d1b0793970b19107a4267e2fe58181e8940a0a10")
