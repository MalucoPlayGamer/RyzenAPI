-- Lua provided by RyzenAPI
-- Game: 2540240

-- MAIN APPLICATION
addappid(2540240)
-- Game: addappid(2540240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540241, 1, "4a8a2a9a18ba4d6a7fe6b2d4d4e5964d662167c1e7711055bc907ad68aaa3955")
