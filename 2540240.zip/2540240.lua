-- Lua provided by RyzenAPI
-- Game: HAELE 3D - Hand Poses Pro - Drawing References

-- MAIN APPLICATION
addappid(2540240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540241, 1, "4a8a2a9a18ba4d6a7fe6b2d4d4e5964d662167c1e7711055bc907ad68aaa3955")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
