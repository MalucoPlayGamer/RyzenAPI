-- Lua provided by RyzenAPI
-- Game: addappid(410790)

-- MAIN APPLICATION
addappid(410790)

-- MAIN APP DEPOTS / PACKAGES
addappid(410790,0,"a775ad9a4cc1bde128e630f35e4370cd2bdc659943da868a5b09c6d8cc35bd96")
