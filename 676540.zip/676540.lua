-- Lua provided by RyzenAPI
-- Game: Mercfighter

-- MAIN APPLICATION
addappid(676540)

-- MAIN APP DEPOTS / PACKAGES
addappid(676541,0,"bd852040c03ca0d77b6188ea967187f89700edd7d571be77a1f6c1247e791fcd")

