-- Lua provided by RyzenAPI
-- Game: 2799680

-- MAIN APPLICATION
addappid(2799680)
-- Game: addappid(2799680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2799683,0,"9dfe4a3ed46a1214e9e175faf3e98dd4aa8e3625d496df3bbed3e33faa5570d2")
