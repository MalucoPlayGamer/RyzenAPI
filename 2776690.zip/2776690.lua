-- Lua provided by RyzenAPI 
-- Game: AppID 2776690
addappid(2776690)
addappid(2776691, 1, "6399755e571a3d3d67834e80bc017b47e1dea79c32dda700f60020996541580f")
