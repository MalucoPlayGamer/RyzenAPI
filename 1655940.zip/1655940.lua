-- Lua provided by SkyAPI 
-- Game: Earth's Shadow
addappid(1655940)
addappid(1655941, 1, "d0836e56f4637d40a8fa041d436e285389fb78cd15f80e36b73ed4db4baaeabb")
