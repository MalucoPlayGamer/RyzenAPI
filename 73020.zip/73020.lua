-- Lua provided by RyzenAPI
-- Game: Majesty 2 Collection

-- MAIN APPLICATION
addappid(73020)

-- MAIN APP DEPOTS / PACKAGES
addappid(73021, 1, "aab293d2026fda31097626a6fe04a8da7b0dfec957c2fbd332c10b63112b9a35")
addappid(73022, 1, "c8ce5555253abe877feeb00a6d1a24fa534c7f7db2469677930cc31d2838fe73")
addappid(73023, 1, "487f9b0a3a3102e1103e0a86f24a6dbb73627c5620ad0c1c2a3f05472fbcb61c")
addappid(73024, 1, "077103122769fc90a37b8b0f6641b3af8425ddd77b9fad9087905f4d8855cc95")
addappid(73025, 1, "271229cf2110639c7fdbf9f3d9dc493e83e98ca4f560cfae75c80db54c81d375")

