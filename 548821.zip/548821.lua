-- Lua provided by RyzenAPI
-- Game: addappid(548821)

-- MAIN APPLICATION
addappid(548821)

-- MAIN APP DEPOTS / PACKAGES
addappid(548821,0,"2e136a1de606da42a8fd483e6af894111eb2a8fa845627dbcc9c991ae3796823")
