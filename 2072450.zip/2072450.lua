-- Lua provided by RyzenAPI
-- Game: AppID 2072450

-- MAIN APPLICATION
addappid(2072450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072451, 1, "77360feef0acf98c8a6727d3cca6f0bd7ede2c3a36fa467945ff217a7067e002")
