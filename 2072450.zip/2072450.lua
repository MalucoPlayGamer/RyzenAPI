-- Lua provided by RyzenAPI
-- Game: AppID 2072450

-- MAIN APPLICATION
addappid(2072450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2072451, 1, "77360feef0acf98c8a6727d3cca6f0bd7ede2c3a36fa467945ff217a7067e002")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2562820)
addappid(2562830)
addappid(2562840)
addappid(2562850)
addappid(2562860)
addappid(2584300)
addappid(2606390)
addappid(2606400)
addappid(2606410)
addappid(2606420)
addappid(2606430)
addappid(2606440)
addappid(2606450)
addappid(2606460)
addappid(2606470)
addappid(2606480)
addappid(2606490)
addappid(2606500)
addappid(2606510)
addappid(2669420)
