-- Lua provided by RyzenAPI
-- Game: 624550

-- MAIN APPLICATION
addappid(624550)
-- Game: addappid(624550)

-- MAIN APP DEPOTS / PACKAGES
addappid(624551, 1, "07ba621d9fd73081a17de8ef69bbad0edeafad7d4ae7c17d8ca143665e11fc85")
addappid(624552, 1, "f19395c203e7f39e6f1d4720df93204a7959445e285dbe2426c87c6a1fa11be2")
addappid(624553, 1, "42817b2bfe6c8c5e5c2e55a092bae25c93544bb959e6fdb95ad681330a031c28")
addappid(624554, 1, "ddc565acb9f20370959f3ab26c80cf52ab69d23a0fcc1d9db3feafe619914ecb")
addappid(624555, 1, "c7d2a7d94619ec8dc65ce262a268a4c0214edaed86f3bc5c3345962017cf6344")
