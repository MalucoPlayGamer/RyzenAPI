-- Lua provided by RyzenAPI
-- Game: The Factory Must Grow Demo

-- MAIN APPLICATION
addappid(3185990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3185991, 1, "d3eadbc2fe42cb961c81a1c3c0efdd2b337e749cc785bbde1d98e9e9db65abb7")

