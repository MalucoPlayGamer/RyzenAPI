-- Lua provided by RyzenAPI
-- Game: Demon Sword: Incubus

-- MAIN APPLICATION
addappid(1803960)
addappid(2061360)
-- Game: addappid(1803960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803961, 1, "ff7f413e42c437c1f4c3b9fd12d131be75186f481311b647681a184bdfbda3f5")
