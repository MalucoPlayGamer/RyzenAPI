-- Lua provided by RyzenAPI
-- Game: Save One More

-- MAIN APPLICATION
addappid(820240)

-- MAIN APP DEPOTS / PACKAGES
addappid(820241, 1, "49de698a56939f08b58bd14c915b66952209f8d0e01ed6f77c9fe6b4c4c96036")
