-- Lua provided by RyzenAPI
-- Game: Captain of Industry

-- MAIN APPLICATION
addappid(2004740)
addappid(4349830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594320, 1, "05671966acb0423953d9ccc1db5981a7d6f00bce411bddda621eb4959f9d2123") -- Captain of Industry
addappid(1594321, 1, "4ff3d26a9ec89b9d17aa43ee05ea46cb83cd638a31b36a385b43fc810ccc6703") -- Depot 1594321
addappid(2004740, 1, "99e976dbccd9e46b15b201695ea57868cd42725d13bb6fc4512e5f3a7d620687") -- Captain of Industry - Supporter pack - Depot 2004740
addappid(4349830, 1, "06605130aff9e40092bf43024ef429e6fd4c60c5da7f397898598e936d14e8a6") -- Captain of Industry - Trains expanded - Depot 4349830

