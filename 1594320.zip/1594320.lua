-- 1594320's Lua and Manifest Created by Hubcap Manifest
-- Captain of Industry
-- Created: August 11, 2026 at 17:27:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(1594320, 1, "05671966acb0423953d9ccc1db5981a7d6f00bce411bddda621eb4959f9d2123") -- Captain of Industry
-- MAIN APP DEPOTS
addappid(1594321, 1, "4ff3d26a9ec89b9d17aa43ee05ea46cb83cd638a31b36a385b43fc810ccc6703") -- Depot 1594321
setManifestid(1594321, "460392243543779354", 3740357854)
-- DLCS WITH DEDICATED DEPOTS
-- Captain of Industry - Supporter pack (AppID: 2004740)
addappid(2004740)
addappid(2004740, 1, "99e976dbccd9e46b15b201695ea57868cd42725d13bb6fc4512e5f3a7d620687") -- Captain of Industry - Supporter pack - Depot 2004740
setManifestid(2004740, "998360184296180806", 18169604)
-- Captain of Industry - Trains expanded (AppID: 4349830)
addappid(4349830)
addappid(4349830, 1, "06605130aff9e40092bf43024ef429e6fd4c60c5da7f397898598e936d14e8a6") -- Captain of Industry - Trains expanded - Depot 4349830
setManifestid(4349830, "2042502024757882087", 420646163)