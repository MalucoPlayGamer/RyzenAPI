-- Lua provided by RyzenAPI
-- Game: Captain of Industry

-- MAIN APPLICATION
addappid(1594320)
-- Game: addappid(1594320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594321, 1, "4ff3d26a9ec89b9d17aa43ee05ea46cb83cd638a31b36a385b43fc810ccc6703")
addappid(2004740, 0, "99e976dbccd9e46b15b201695ea57868cd42725d13bb6fc4512e5f3a7d620687")
