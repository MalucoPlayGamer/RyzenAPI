-- Lua provided by RyzenAPI
-- Game: AppID 529180

-- MAIN APPLICATION
addappid(529180)

-- MAIN APP DEPOTS / PACKAGES
addappid(529181, 1, "decc2a0b636b44fe0b92160c5a67c834a3a1f59feb51c76a7db36c9ffefde258")

