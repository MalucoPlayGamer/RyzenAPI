-- Lua provided by RyzenAPI
-- Game: Game: Paint Chips

-- MAIN APPLICATION
addappid(1554400)
addappid(2603700)
-- Game: addappid(1554400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554401, 1, "0f2c6adc5e8458d30f732e611b92b93e0de587fcf5a857190050960ba61ad526")
addappid(1554402, 1, "138ee852dd5c6f3fc228b6674ef9ada2f2375a78653e30b068c4d1385c62bfa4")
