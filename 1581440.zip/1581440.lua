-- Lua provided by RyzenAPI
-- Game: Game: QUADRICOLOR: Ultra Sentai Color Ranger

-- MAIN APPLICATION
addappid(1581440)
-- Game: addappid(1581440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581441, 1, "0b8fa7916636b67e1bc6d501a34339f86362a33189019ff0e88c39607dee5467")
