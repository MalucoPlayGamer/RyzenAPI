-- Lua provided by SkyAPI 
-- Game: Chinese Chess Party (Xiangqi)
addappid(2336550)
addappid(2336551, 1, "6557a518e4662af63aa183822a88bf28cfd679ffa9d2cb030779609293049b35")
