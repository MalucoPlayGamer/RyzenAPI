-- Lua provided by RyzenAPI
-- Game: Chinese Chess Party (Xiangqi)

-- MAIN APPLICATION
addappid(2336550)
-- Game: addappid(2336550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336551, 1, "6557a518e4662af63aa183822a88bf28cfd679ffa9d2cb030779609293049b35")
