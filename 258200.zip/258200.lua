-- Lua provided by RyzenAPI
-- Game: Game: Talisman: Prologue

-- MAIN APPLICATION
addappid(258200)
-- Game: addappid(258200)

-- MAIN APP DEPOTS / PACKAGES
addappid(258201, 1, "892a80b1056d141139102b3422c25e769bca10b4717eb6242cface611ace4ca8")
