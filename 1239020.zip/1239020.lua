-- Lua provided by RyzenAPI
-- Game: TOGETHER BnB

-- MAIN APPLICATION
addappid(1239020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1239021,0,"82aede50519233eae836f4cdf8091356f7f4d10f51555c31cabf58c3d2c235ce")
addappid(4030120,0,"e80485063b277a5f4c92e4489732b8e0b59597d1b0e5ad74961e89a60d011fe0")

