-- Lua provided by RyzenAPI
-- Game: addappid(2437330)

-- MAIN APPLICATION
addappid(2437330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437331, 1, "8a4e2bde9c0ea35fcbc1c9167624855ae1d0b27d26a5270720a67561996bf5b9")
