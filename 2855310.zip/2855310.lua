-- Lua provided by RyzenAPI
-- Game: Irritated Mind: Fear of Warehouse Demo

-- MAIN APPLICATION
addappid(2855310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2855311, 1, "fbe7c80761cb36ba6dda0b4f51c2047fd8f93e8f4dcbbacb206ccbdb3273fca6")

