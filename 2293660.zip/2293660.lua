-- Lua provided by RyzenAPI
-- Game: 2293660

-- MAIN APPLICATION
addappid(2293660)
-- Game: addappid(2293660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293662,0,"7be28a9c9d2150522c77ae7dcbf70d886fcfd154674317cf4aa6d2cdd24fca1d")
