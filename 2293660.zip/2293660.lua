-- Lua provided by RyzenAPI
-- Game: He Fucked The Girl Out of Me

-- MAIN APPLICATION
addappid(2293660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2293662,0,"7be28a9c9d2150522c77ae7dcbf70d886fcfd154674317cf4aa6d2cdd24fca1d")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2447770)
addappid(2459990)
addappid(2459991)
addappid(2459992)
addappid(2459993)
