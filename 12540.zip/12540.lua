-- Lua provided by RyzenAPI
-- Game: 12540

-- MAIN APPLICATION
addappid(12540)
-- Game: addappid(12540)

-- MAIN APP DEPOTS / PACKAGES
addappid(12541, 1, "371dedb5e7668703344bbefd831cbd88d9a6c7fadad690ccf69886a3140be3f3")
