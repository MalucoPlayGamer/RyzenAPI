-- Lua provided by RyzenAPI
-- Game: AppID 1018680

-- MAIN APPLICATION
addappid(1018680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018681, 1, "638d8dbde1428792f69f705ca41bf43cfbc18d6716d197517b7345c6c407c89a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
