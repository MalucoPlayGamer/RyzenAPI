-- Lua provided by SkyAPI 
-- Game: AppID 1018680
addappid(1018680)
addappid(1018681, 1, "638d8dbde1428792f69f705ca41bf43cfbc18d6716d197517b7345c6c407c89a")
