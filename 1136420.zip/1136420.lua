-- Lua provided by RyzenAPI
-- Game: Gates of Hell

-- MAIN APPLICATION
addappid(1136420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1136421, 1, "5d9be9756c767eb582f0911e2167cade6f389405e3c6563a294fc31f9c57427c")
