-- Lua provided by SkyAPI 
-- Game: Temperia: Soul of Majestic
addappid(852780)
addappid(852781, 1, "c9f7d0f7c3fcf45107bff57de4e2235c50eabf7ed4a47b14a984c655e33dd2d3")
