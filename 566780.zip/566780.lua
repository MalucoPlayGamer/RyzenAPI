-- Lua provided by RyzenAPI
-- Game: 566780

-- MAIN APPLICATION
addappid(566780)
addappid(566781)
addappid(566782)
addappid(566783)
addappid(566784)
addappid(566785)
addappid(566786)
addappid(566787)
addappid(566788)
addappid(566789)
addappid(582101)
-- Game: addappid(566780)

-- MAIN APP DEPOTS / PACKAGES
addappid(582102,0,"7b5fbb86e9d1d71a2335b3f06c76d809a2b5ff1793581b4ce6078343bbf4ac53")
