-- Lua provided by RyzenAPI
-- Game: Game: cat and rat

-- MAIN APPLICATION
addappid(2214950)
-- Game: addappid(2214950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214951, 1, "34356574f9517715c0c8848a3b4fd49cb6c8169002554f8fedff1b11761b1460")
