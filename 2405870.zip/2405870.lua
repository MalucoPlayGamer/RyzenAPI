-- Lua provided by RyzenAPI
-- Game: 2405870

-- MAIN APPLICATION
addappid(2405870)
-- Game: addappid(2405870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2405871, 1, "eefd38ec3ac3c598ac87ee0994da1164bb6363954ccbf074aaaa98502be9af99")
