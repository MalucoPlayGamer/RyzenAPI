-- Lua provided by RyzenAPI
-- Game: 1333610

-- MAIN APPLICATION
addappid(1333610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333610,0,"ea9bae422048e5924bc8b8e57d5ecc9b6cc5f7a1d013907d4d50bf850cc62ac5")

