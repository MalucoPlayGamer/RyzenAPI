-- Lua provided by RyzenAPI
-- Game: 2741100

-- MAIN APPLICATION
addappid(2741100)
-- Game: addappid(2741100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2741100,0,"a0853e12eb3ee3ad7933e2f1151a99e5ace454f0e41730be9e0e47993ec350c0")
