-- Lua provided by RyzenAPI
-- Game: Taxi Life: A City Driving Simulator

-- MAIN APPLICATION
addappid(1351240)
addappid(2633670)
addappid(2633680)
addappid(3197460)
addappid(3260720)
addappid(3335520)
addappid(3384710)
-- Game: addappid(1351240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351241, 1, "9e79fc452f59614517425d51bae47b42451e0a8aaba07aa8b48b756424d68539")
