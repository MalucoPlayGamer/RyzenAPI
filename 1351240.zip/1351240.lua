-- Lua provided by RyzenAPI
-- Game: Taxi Life: A City Driving Simulator

-- MAIN APPLICATION
addappid(1351240)
addappid(2633670)
addappid(2633680)
addappid(3197460)
addappid(3260720)
addappid(3335520)
addappid(3384710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351241, 1, "9e79fc452f59614517425d51bae47b42451e0a8aaba07aa8b48b756424d68539")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3576810)
addappid(3854360)
