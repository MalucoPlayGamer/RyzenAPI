-- Lua provided by SkyAPI 
-- Game: Port Shipping Tycoon
addappid(3572770)
addappid(3572771, 1, "5a7881fc88cc23a9dc5e0e6aaa05653d9d1850e77b43be1cd4186064a4a84c58")
