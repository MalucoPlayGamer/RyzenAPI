-- Lua provided by RyzenAPI
-- Game: Port Shipping Tycoon

-- MAIN APPLICATION
addappid(3572770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3572771, 1, "5a7881fc88cc23a9dc5e0e6aaa05653d9d1850e77b43be1cd4186064a4a84c58")

