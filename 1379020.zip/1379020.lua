-- Lua provided by RyzenAPI
-- Game: The Horrorscope: Fatal Awakening

-- MAIN APPLICATION
addappid(1379020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379021, 1, "0d0bcd038445895db7aeff811f2da1aef71d85793e43114ecac3d5d898fb1ec4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
