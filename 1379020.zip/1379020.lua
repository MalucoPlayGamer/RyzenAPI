-- Lua provided by RyzenAPI
-- Game: addappid(1379020)

-- MAIN APPLICATION
addappid(1379020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379021, 1, "0d0bcd038445895db7aeff811f2da1aef71d85793e43114ecac3d5d898fb1ec4")
