-- Lua provided by RyzenAPI
-- Game: Scythe: Digital Edition - Soundtrack

-- MAIN APPLICATION
addappid(893130)

-- MAIN APP DEPOTS / PACKAGES
addappid(893130,0,"fd5091307f88638ec6287e05aecc1d5db1b02ea34b7ea28f6101e6b93939d62f")
