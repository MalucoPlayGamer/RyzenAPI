-- Lua provided by RyzenAPI
-- Game: AppID 376030

-- MAIN APPLICATION
addappid(376030)
-- Game: addappid(376030)

-- MAIN APP DEPOTS / PACKAGES
addappid(376031, 1, "3ef38f0ea900ecf8b4d13ec70d922622938f14ae6a2c985a5e051132494ceff2")
