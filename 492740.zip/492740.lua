-- Lua provided by RyzenAPI
-- Game: Game: AppID 492740

-- MAIN APPLICATION
addappid(492740)
-- Game: addappid(492740)

-- MAIN APP DEPOTS / PACKAGES
addappid(492741, 1, "053977e6d7ad075dbabd274d06d477d8a6154716187e49503511dc39919a002c")
