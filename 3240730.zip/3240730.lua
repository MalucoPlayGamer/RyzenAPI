-- Lua provided by RyzenAPI
-- Game: MEAT-GRINDER Demo

-- MAIN APPLICATION
addappid(3240730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3240731, 1, "837cc2046be0e13630cb23b3fbfe1231fe234fdcf47e03af12b7abbe8b50b46a")
