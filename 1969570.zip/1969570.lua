-- Lua provided by RyzenAPI
-- Game: Shenanigans

-- MAIN APPLICATION
addappid(1969570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1969571, 1, "8267c5be6fff599cb1244b635245376ac723a96471ef033db15a7cf263d7bb6a")

