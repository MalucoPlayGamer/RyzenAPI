-- Lua provided by RyzenAPI
-- Game: Panzer Arena: Prologue

-- MAIN APPLICATION
addappid(1974610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1974611, 1, "fe9c25dd0604ab687e3c2a212bd4d6cd0b700b25a807c2a15977eb1ffc45e3d8")

