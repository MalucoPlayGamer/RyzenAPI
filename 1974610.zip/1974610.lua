-- Lua provided by RyzenAPI
-- Game: addappid(1974610)

-- MAIN APPLICATION
addappid(1974610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1974611, 1, "fe9c25dd0604ab687e3c2a212bd4d6cd0b700b25a807c2a15977eb1ffc45e3d8")
