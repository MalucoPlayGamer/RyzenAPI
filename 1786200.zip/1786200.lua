-- Lua provided by SkyAPI 
-- Game: Wars and Roses
addappid(1786200)
addappid(1786201, 1, "f271fc928f28eced8a1e9a2a3154832c002df44ae19246acd7f4c155ff1fe05f")
addappid(1843260, 0, "63b69477b10ccda6c11b1126200f4b75f989c9361ba550b9a2a6f751069b3a40")
