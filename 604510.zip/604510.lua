-- Lua provided by RyzenAPI
-- Game: addappid(604510)

-- MAIN APPLICATION
addappid(604510)

-- MAIN APP DEPOTS / PACKAGES
addappid(604511, 1, "638a73c4b7340ebb8705af15a06703210c69f5447ffab8475ffbdcec642ada34")
