-- Lua provided by RyzenAPI
-- Game: Game: Top Racer Collection

-- MAIN APPLICATION
addappid(2214000)
addappid(3800320)
-- Game: addappid(2214000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214001, 1, "70070ece4f1e0d702c001aa27bd3a90fd923bb62d3e5ecb673649443a1733106")
