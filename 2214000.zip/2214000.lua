-- Lua provided by RyzenAPI
-- Game: Top Racer Collection

-- MAIN APPLICATION
addappid(2214000)
addappid(3800320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214001, 1, "70070ece4f1e0d702c001aa27bd3a90fd923bb62d3e5ecb673649443a1733106")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
