-- Lua provided by RyzenAPI
-- Game: addappid(2930160)

-- MAIN APPLICATION
addappid(2930160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2930161, 1, "cd1d4064c69736c29a4dab440c24942c5a8c9dc7c765f0c5739d400a45ea06e2")
