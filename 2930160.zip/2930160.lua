-- Lua provided by RyzenAPI
-- Game: Nightmare Kart

-- MAIN APPLICATION
addappid(2930160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2930161, 1, "cd1d4064c69736c29a4dab440c24942c5a8c9dc7c765f0c5739d400a45ea06e2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
