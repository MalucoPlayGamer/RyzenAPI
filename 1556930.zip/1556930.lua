-- Lua provided by RyzenAPI
-- Game: 1556930

-- MAIN APPLICATION
addappid(1556930)
-- Game: addappid(1556930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1556931, 1, "1df29e1ed614731d23ec33b0eba06ecc41b322ac02bc5a14db5f11ea6e809116")
