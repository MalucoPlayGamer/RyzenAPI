-- Lua provided by RyzenAPI
-- Game: Game: Furry Angel Take In

-- MAIN APPLICATION
addappid(2910460)
-- Game: addappid(2910460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2910461, 1, "d575933875e98e3945a291a7d782f39e3374f3c6b0c907c9b2f3d91844708390")
