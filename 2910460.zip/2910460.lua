-- Lua provided by SkyAPI 
-- Game: Furry Angel Take In
addappid(2910460)
addappid(2910461, 1, "d575933875e98e3945a291a7d782f39e3374f3c6b0c907c9b2f3d91844708390")
