-- Lua provided by RyzenAPI
-- Game: Google Spotlight Stories: Pearl

-- MAIN APPLICATION
addappid(476540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(476541, 1, "37b0d5e676ecc86f427cd055089fec2e24d67236f727ae0708bbd9172e05dc57")
addappid(476542, 1, "c371166077f4d1164f04c86f239ace499f036003639e689549750c5845280351")

