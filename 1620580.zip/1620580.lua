-- Lua provided by RyzenAPI
-- Game: Game: Hentai VR 3

-- MAIN APPLICATION
addappid(1620580)
-- Game: addappid(1620580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620581, 1, "d64aeebcd5567afaaa400ea07b63a4d333ded56007ece0b26df1d44f6eee847c")
