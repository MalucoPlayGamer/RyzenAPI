-- Lua provided by RyzenAPI
-- Game: Dark Room VR

-- MAIN APPLICATION
addappid(1394640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394641, 1, "f2ade700d01307666d01c454dd17e96b835dbb0bfdd40f5330db17b1966ae9bf")
