-- Lua provided by RyzenAPI
-- Game: Game: Mokoko X - Adult Patch

-- MAIN APPLICATION
addappid(1791250)
-- Game: addappid(1791250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791251, 1, "19a9761bd7001133b25543c441c46ad3348a94327860dea734c62b836e452ea0")
