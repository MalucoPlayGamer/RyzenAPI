-- Lua provided by RyzenAPI
-- Game: Shine's Adventures 2 (Zombie Attack)

-- MAIN APPLICATION
addappid(1105410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1105411, 1, "fe9cf432ec7a599e52270e664bec95ff006fd08b760f2ab99c2d4289df0a860b")
