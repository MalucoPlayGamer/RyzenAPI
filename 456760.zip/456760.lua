-- Lua provided by SkyAPI 
-- Game: A dragon girl looks up at the endless sky
addappid(456760)
addappid(456761, 1, "3cdfe477a4745350cdc1598f64e4ce3e1092c3820a86612600c35bc788ab63df")
