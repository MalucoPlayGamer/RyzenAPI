-- Lua provided by RyzenAPI
-- Game: Game: A dragon girl looks up at the endless sky

-- MAIN APPLICATION
addappid(456760)
-- Game: addappid(456760)

-- MAIN APP DEPOTS / PACKAGES
addappid(456761, 1, "3cdfe477a4745350cdc1598f64e4ce3e1092c3820a86612600c35bc788ab63df")
