-- Lua provided by RyzenAPI
-- Game: A dragon girl looks up at the endless sky

-- MAIN APPLICATION
addappid(456760)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(456761, 1, "3cdfe477a4745350cdc1598f64e4ce3e1092c3820a86612600c35bc788ab63df")

