-- Lua provided by RyzenAPI
-- Game: AppID 1379570

-- MAIN APPLICATION
addappid(1379570)
-- Game: addappid(1379570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379571, 1, "1f1a69cf687eb12ddfaf305d6f2903b2ba5107857552e7715fa833b7f270df46")
