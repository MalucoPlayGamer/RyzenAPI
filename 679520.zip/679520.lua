-- Lua provided by SkyAPI 
-- Game: Memories Off 2nd
addappid(679520)
addappid(679521, 1, "3088548a5ebe8cddf2ebdf296013b2a2fd1561203d9c4d494acc1ea010456be6")
