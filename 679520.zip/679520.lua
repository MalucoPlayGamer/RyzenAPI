-- Lua provided by RyzenAPI
-- Game: Memories Off 2nd

-- MAIN APPLICATION
addappid(679520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(679521, 1, "3088548a5ebe8cddf2ebdf296013b2a2fd1561203d9c4d494acc1ea010456be6")

