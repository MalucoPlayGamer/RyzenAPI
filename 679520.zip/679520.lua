-- Lua provided by RyzenAPI
-- Game: Memories Off 2nd

-- MAIN APPLICATION
addappid(679520)

-- MAIN APP DEPOTS / PACKAGES
addappid(679521, 1, "3088548a5ebe8cddf2ebdf296013b2a2fd1561203d9c4d494acc1ea010456be6")
