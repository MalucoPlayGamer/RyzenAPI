-- Lua provided by RyzenAPI
-- Game: Wild West Steam Loco

-- MAIN APPLICATION
addappid(1256360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1256361, 1, "47248bdb75e5f1a405f88baeabb245dd4ea3e982206ca4b6633d911921e8171c")

