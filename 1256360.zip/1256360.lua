-- Lua provided by RyzenAPI
-- Game: addappid(1256360)

-- MAIN APPLICATION
addappid(1256360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1256361, 1, "47248bdb75e5f1a405f88baeabb245dd4ea3e982206ca4b6633d911921e8171c")
