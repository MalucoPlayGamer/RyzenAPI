-- Lua provided by RyzenAPI
-- Game: 1474990

-- MAIN APPLICATION
addappid(1474990)
-- Game: addappid(1474990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1474991, 1, "9994cf1c7e6fd3a2fb1da14463d0f2a5f9356f1b2d8c03b16485323f8086b455")
