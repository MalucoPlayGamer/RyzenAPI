-- Lua provided by RyzenAPI
-- Game: Pocket Mirror ~ GoldenerTraum - Demo

-- MAIN APPLICATION
addappid(2299800)
-- Game: addappid(2299800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2299801, 1, "4c6e90259e8f2cb32a7537be31a3fa2152e443aaa905fb6f2555a4ff0d50fa28")
