-- Lua provided by RyzenAPI
-- Game: Gunlock

-- MAIN APPLICATION
addappid(750450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(750451, 1, "1741139ff6378686934bf6a97e7f1ca97e1a3cc0364f319a06ff9f50912aad7b")

