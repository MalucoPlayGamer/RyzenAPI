-- Lua provided by RyzenAPI
-- Game: addappid(750450)

-- MAIN APPLICATION
addappid(750450)

-- MAIN APP DEPOTS / PACKAGES
addappid(750451, 1, "1741139ff6378686934bf6a97e7f1ca97e1a3cc0364f319a06ff9f50912aad7b")
