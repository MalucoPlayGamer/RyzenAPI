-- Lua provided by RyzenAPI
-- Game: 1057600

-- MAIN APPLICATION
addappid(1057600)
-- Game: addappid(1057600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057603,0,"9e89203161c9ae410db15abb1e6373668f2d966c4fbf0a1bc567c0ff78744d24")
