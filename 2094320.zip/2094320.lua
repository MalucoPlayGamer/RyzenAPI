-- Lua provided by RyzenAPI
-- Game: Escape First Alchemist ⚗️

-- MAIN APPLICATION
addappid(2094320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094321, 1, "a63622e56018d921236c2277ddf2ed8c9f5f81d3fed97e881945abd76ebc98d3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
