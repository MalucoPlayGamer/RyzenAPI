-- Lua provided by RyzenAPI
-- Game: Game: Escape First Alchemist ⚗️

-- MAIN APPLICATION
addappid(2094320)
-- Game: addappid(2094320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094321, 1, "a63622e56018d921236c2277ddf2ed8c9f5f81d3fed97e881945abd76ebc98d3")
