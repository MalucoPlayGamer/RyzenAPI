-- Lua provided by RyzenAPI
-- Game: Game: Golf On Mars

-- MAIN APPLICATION
addappid(1340570)
-- Game: addappid(1340570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340571, 1, "dcfb4eb0d9a9e70ed47ffc9387521f9fca6c5b5b4fa91f5a99e89fbffc21caa0")
