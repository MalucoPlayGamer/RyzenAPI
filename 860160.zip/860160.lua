-- Lua provided by RyzenAPI
-- Game: Save The Villy

-- MAIN APPLICATION
addappid(860160)

-- MAIN APP DEPOTS / PACKAGES
addappid(860161, 1, "121996d4c6ff8408c27187b692e6acee236bba0be1518b78298830f0ae1f269c")
