-- Lua provided by RyzenAPI
-- Game: 502480

-- MAIN APPLICATION
addappid(228990)
addappid(502480)
-- Game: addappid(502480)

-- MAIN APP DEPOTS / PACKAGES
addappid(502482,0,"fb4267efb3a106d6eddc7f46c550e6014727f04ad4d1ace7aa0e2cccf2697c0e")
