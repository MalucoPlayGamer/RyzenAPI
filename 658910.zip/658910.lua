-- Lua provided by RyzenAPI
-- Game: ClickRaid - Supporter Pack

-- MAIN APPLICATION
addappid(658910)
-- Game: addappid(658910)

-- MAIN APP DEPOTS / PACKAGES
addappid(658910,0,"33ce5011a4ca88e99b84c8415b44da9d437cf6d1fd4547c5920d86c02a14ed03")
