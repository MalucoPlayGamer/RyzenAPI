-- Lua provided by RyzenAPI
-- Game: Time Guard - The Red Menace

-- MAIN APPLICATION
addappid(3536610)

-- MAIN APP DEPOTS / PACKAGES
addappid(3536611, 1, "d7404107f48f6861cee4a21c7f4331f34114dddeed3e9da169c9cdd7c79e9acc")

