-- Lua provided by RyzenAPI
-- Game: 3262320

-- MAIN APPLICATION
addappid(3262320)
-- Game: addappid(3262320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3262321, 1, "f7e001ed53f7bd875d4829c18c215c9112ae8a429efcf86acda4eed829a6fa77")
