-- Lua provided by RyzenAPI
-- Game: Bunny-girl with Golden tummy

-- MAIN APPLICATION
addappid(2780880)
addappid(2814390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780881, 1, "43f0c4d288126ab2a5e9aef064cfe0496c2ff7b162cc8d59b4498486f647d038")
