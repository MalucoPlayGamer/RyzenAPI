-- Lua provided by RyzenAPI
-- Game: Lost & Found Collection

-- MAIN APPLICATION
addappid(3325690)
addappid(3325990)
-- Game: addappid(3325690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3325691, 1, "e10b417aa292316164706cc21bfc56f4861b992a89a7df9c78d896862e619459")
