-- Lua provided by RyzenAPI
-- Game: Return to Zork

-- MAIN APPLICATION
addappid(585240)
-- Game: addappid(585240)

-- MAIN APP DEPOTS / PACKAGES
addappid(585241, 1, "96d2fc95b7b266cd2b7ecff03b8211eb68676e59cf65edcf2f93526b95d68d7b")
