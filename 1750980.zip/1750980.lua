-- Lua provided by RyzenAPI
-- Game: Horror Maze

-- MAIN APPLICATION
addappid(1750980)
-- Game: addappid(1750980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750981, 1, "0180ba6a948a03f493c895395aaf78a39b10be6512a377c2918c4448e79a8c9d")
