-- Lua provided by RyzenAPI
-- Game: Horror Maze

-- MAIN APPLICATION
addappid(1750980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1750981, 1, "0180ba6a948a03f493c895395aaf78a39b10be6512a377c2918c4448e79a8c9d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
