-- Lua provided by RyzenAPI
-- Game: 222420

-- MAIN APPLICATION
addappid(222420)
addappid(228982)
addappid(228990)
-- Game: addappid(222420)

-- MAIN APP DEPOTS / PACKAGES
addappid(222421, 1, "05b790cfcf6ad87f7dd75e8efe61e3536174d02102780457187cc0c86ebf349a")
