-- Lua provided by RyzenAPI
-- Game: Game: FINAL FANTASY I PIXEL REMASTER Original Soundtrack

-- MAIN APPLICATION
addappid(3365570)
-- Game: addappid(3365570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3365571, 1, "4bcfe9c8da487e83c61231f4b6c25cd018caa5941e527aea204f778eb6678d8c")
