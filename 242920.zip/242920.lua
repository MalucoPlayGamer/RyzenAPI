-- Lua provided by RyzenAPI 
-- Game: Banished
addappid(242920)
addappid(242921, 1, "5af9db507a72f90aaddccef9f67da11317da1c5267370db1149d6d83eca4622f")
