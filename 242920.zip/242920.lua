-- Lua provided by RyzenAPI
-- Game: Banished

-- MAIN APPLICATION
addappid(242920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(242921, 1, "5af9db507a72f90aaddccef9f67da11317da1c5267370db1149d6d83eca4622f")

