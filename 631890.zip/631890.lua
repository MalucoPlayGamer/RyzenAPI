-- Lua provided by RyzenAPI
-- Game: Heartbound Demo

-- MAIN APPLICATION
addappid(228990)
addappid(631890)
addappid(631893)
addappid(631894)
-- Game: addappid(631890)

-- MAIN APP DEPOTS / PACKAGES
addappid(631892,0,"2b2c3e4d5284d13dbad4425acce3a7c43124cad84bb88cd114780e51401f01d4")
