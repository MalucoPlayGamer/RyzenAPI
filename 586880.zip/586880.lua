-- Lua provided by RyzenAPI
-- Game: Game: Mini Ghost

-- MAIN APPLICATION
addappid(586880)
-- Game: addappid(586880)

-- MAIN APP DEPOTS / PACKAGES
addappid(586881, 1, "a36b2577da4b50ed69b7bd9c61bbcfacb4ee6b3e0ce54fc984bedc265633d5f1")
