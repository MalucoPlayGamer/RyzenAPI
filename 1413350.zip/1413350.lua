-- Lua provided by RyzenAPI
-- Game: Flipper Volcano

-- MAIN APPLICATION
addappid(1413350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1413351, 1, "44cffaa1e3e79fa1cb54dc7d8f2829d4f4ba5b7dab8531ea5cb9f29525ecebc8")
