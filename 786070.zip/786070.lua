-- Lua provided by RyzenAPI
-- Game: Myths of the World: Spirit Wolf Collector's Edition

-- MAIN APPLICATION
addappid(786070)

-- MAIN APP DEPOTS / PACKAGES
addappid(786071,0,"1e223b97705733456c8bd4baf63cffec313710877d785e2b1fd11fff721b2e85")

