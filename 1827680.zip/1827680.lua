-- Lua provided by RyzenAPI
-- Game: 枝江畔之梦

-- MAIN APPLICATION
addappid(1827680)

