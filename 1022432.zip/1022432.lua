-- Lua provided by RyzenAPI
-- Game: DFF NT: Excalibur, Ramza Beoulve's 4th Weapon

-- MAIN APPLICATION
addappid(1022432)
-- Game: addappid(1022432)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022432,0,"49e9aed7bb3d3e59e2e881fd90a15d5ba3b6773c99167cfe922914ee8fa10487")
