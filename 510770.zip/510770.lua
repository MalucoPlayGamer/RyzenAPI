-- Lua provided by RyzenAPI
-- Game: Echoes of MK-ULTRA

-- MAIN APPLICATION
addappid(510770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(510771, 1, "f41a01602953ee4b1c4fbd7d2c7b6b705b9855d44ec6e94eb164da7618fbee34")

