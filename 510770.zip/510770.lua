-- Lua provided by RyzenAPI
-- Game: AppID 510770

-- MAIN APPLICATION
addappid(510770)

-- MAIN APP DEPOTS / PACKAGES
addappid(510771, 1, "f41a01602953ee4b1c4fbd7d2c7b6b705b9855d44ec6e94eb164da7618fbee34")

