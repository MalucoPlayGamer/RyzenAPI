-- Lua provided by RyzenAPI
-- Game: Hide From Papaku

-- MAIN APPLICATION
addappid(3517170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3517171, 1, "3726ccc598f25215bb43011e661a3940e8ad3e1c92453f40ecf02dd872ba3f4d")
