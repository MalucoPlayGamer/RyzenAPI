-- Lua provided by RyzenAPI 
-- Game: Harvest Hero Origins
addappid(1651500)
addappid(1651501, 1, "bdad4d21bc78799e619757f3c8117ae9d18653ef13c59a59893de76763cc4fdb")
