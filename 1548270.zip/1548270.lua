-- Lua provided by RyzenAPI
-- Game: Darkilson

-- MAIN APPLICATION
addappid(1548270)
-- Game: addappid(1548270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548271, 1, "d563832b59f4e0689830f253290612971327f30f9758edff2b017b180934f8d2")
