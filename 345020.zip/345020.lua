-- Lua provided by RyzenAPI
-- Game: Feeble Origins: Path of a Hero

-- MAIN APPLICATION
addappid(345020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(345021, 1, "405d204aaed5213db96509ae6359231d471f7305333ec130b0e51495fc9802e7")

