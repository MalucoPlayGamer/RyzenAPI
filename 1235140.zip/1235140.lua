-- Lua provided by RyzenAPI
-- Game: Yakuza: Like a Dragon

-- MAIN APPLICATION
addappid(1235140)
addappid(1253350)
addappid(1259670)
addappid(1289190)
addappid(1289191)
addappid(1289192)
addappid(1289211)
addappid(1289234)
-- Game: addappid(1235140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1235141, 1, "a6c3090851b8f41f9b628ed2b51335e1a9a6944cfb4041001860f1d10465adaa")
addappid(1235142, 1, "ba44937f15fa93fd09f7e671c4927d11fc61e1d46a6c8140eea67eef77efbf0c")
addappid(1235143, 1, "20bdc3f794349917d767fde04a451276f81c1ecbf0a5b9ee3757f34654cf8ff9")
addappid(1235144, 1, "59e0edbfd783e05543bdd078b6c008f13cbeac80f621afbaed948cf86f554eb0")
addappid(1261270, 0, "35065fd4cc1828f50c79b892de5c9a8ce97333c1ff4bfa2f8b7757ee63cc05ae")
