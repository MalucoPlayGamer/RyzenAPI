-- Lua provided by RyzenAPI
-- Game: addappid(974540)

-- MAIN APPLICATION
addappid(974540)

-- MAIN APP DEPOTS / PACKAGES
addappid(974540,0,"e41b6580c3becd00b5f9ae6a44d5a9cb6190ed4467d7900b7869d0b7a247c812")
