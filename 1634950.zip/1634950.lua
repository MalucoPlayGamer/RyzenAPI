-- Lua provided by RyzenAPI
-- Game: 1634950

-- MAIN APPLICATION
addappid(1634950)
-- Game: addappid(1634950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634951, 1, "c4b4eccb4dd922298e9760a6a58d69061acdcf3c3a02d46b40e84cdc95082190")
