-- Lua provided by RyzenAPI
-- Game: Heroes of a Broken Land

-- MAIN APPLICATION
addappid(314470)
-- Game: addappid(314470)

-- MAIN APP DEPOTS / PACKAGES
addappid(314471, 1, "d6116820c29eb4c932cb5b7e28682bf11545ef2807589f9cb699c34437402bba")
addappid(314472, 1, "c4cc921a56ced9e342d01997792222c940d020ee01760b28daf89f52cd19dc48")
addappid(314473, 1, "249c9c3f592c5f0c4cd94dd8bf664c035e3d4798e6ea2649835d7b33eea06383")
addappid(314474, 1, "855e48d427a187b7ae8ad1fc0f43cfba904f7e318f01d6d7a70c8e77d83655f3")
