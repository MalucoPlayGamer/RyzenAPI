-- Lua provided by RyzenAPI
-- Game: Game: enJoyTyping

-- MAIN APPLICATION
addappid(1956410)
-- Game: addappid(1956410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1956411, 1, "c679164d90f47c5aba72e7357b95a1b07fb4bdc2e0149242499ad67eb0593e90")
