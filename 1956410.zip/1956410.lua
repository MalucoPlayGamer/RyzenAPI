-- Lua provided by SkyAPI 
-- Game: enJoyTyping
addappid(1956410)
addappid(1956411, 1, "c679164d90f47c5aba72e7357b95a1b07fb4bdc2e0149242499ad67eb0593e90")
