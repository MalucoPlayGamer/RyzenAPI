-- Lua provided by RyzenAPI
-- Game: Doodle God: 8-bit Mania - Collector's Item

-- MAIN APPLICATION
addappid(538060)
addappid(931720)
-- Game: addappid(538060)

-- MAIN APP DEPOTS / PACKAGES
addappid(538061, 1, "9360816a456c52b41e9a1f7ca08472d4e4fd6198ec1ffba4fe5ad951628984b8")
addappid(538062, 1, "6e850cdb74e9a32e9e9dc6497e30ae4e345d5c663dfc67d59ce33ea534640f7b")
addappid(538063, 1, "b9db53c6e8e92abb95004a34e09a09e239f1e1612da2cd1a748d170584174a82")
addappid(538064, 1, "5ff557e041932c6717b4c27e820b482bb82f18d9988b8f4a6c82058d7a63d642")
addappid(538065, 1, "24612e347ea6a69e611d18c28e39e0773fdb0d72f96f8748154f0bc17ac9728a")
addappid(538066, 1, "77265ec1f72b865df4af945e7525ebc55b5b13faf3c942e7e6ce0636f3949885")
