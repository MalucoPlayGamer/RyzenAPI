-- Lua provided by RyzenAPI
-- Game: Dino Dawn

-- MAIN APPLICATION
addappid(854160)
-- Game: addappid(854160)

-- MAIN APP DEPOTS / PACKAGES
addappid(854161, 1, "592646c62ccf243c5d21ad5540d4ab6ef32744c165a006152b63869116b2576d")
