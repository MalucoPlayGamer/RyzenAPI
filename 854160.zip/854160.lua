-- Lua provided by RyzenAPI 
-- Game: Dino Dawn
addappid(854160)
addappid(854161, 1, "592646c62ccf243c5d21ad5540d4ab6ef32744c165a006152b63869116b2576d")
