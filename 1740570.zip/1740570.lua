-- Lua provided by RyzenAPI 
-- Game: CURSED NIGHT - The House
addappid(1740570)
addappid(1740571, 1, "41f3abd9c1a9f194b05296e65992a0aea9de720fa3710a4267bc8df7ab866036")
