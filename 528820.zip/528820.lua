-- Lua provided by RyzenAPI
-- Game: Eisenwald: Blood of November

-- MAIN APPLICATION
addappid(528820)

-- MAIN APP DEPOTS / PACKAGES
addappid(528821,0,"6eea47baae6731567c6928dbe663fe3b15b6a77cb0e880f2d4eebdd715504a74")

