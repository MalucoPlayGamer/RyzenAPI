-- Lua provided by RyzenAPI
-- Game: 969540

-- MAIN APPLICATION
addappid(969540)
-- Game: addappid(969540)

-- MAIN APP DEPOTS / PACKAGES
addappid(969541, 1, "7387258346d44ffc1777e79c065ef48faa21def3d9a3f897acedced5e08da292")
