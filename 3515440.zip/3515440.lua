-- Lua provided by RyzenAPI
-- Game: 3515440

-- MAIN APPLICATION
addappid(3515440)
-- Game: addappid(3515440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3515441, 1, "0f29d9d61a3f7855779dc9ddf981553a3b1ecffa6c5aef30a92e6ec6fa170041")
