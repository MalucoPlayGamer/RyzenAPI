-- Lua provided by SkyAPI 
-- Game: Death Delivery
addappid(3515440)
addappid(3515441, 1, "0f29d9d61a3f7855779dc9ddf981553a3b1ecffa6c5aef30a92e6ec6fa170041")
