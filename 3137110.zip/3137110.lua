-- Lua provided by RyzenAPI
-- Game: addappid(3137110)

-- MAIN APPLICATION
addappid(3137110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3137111, 1, "723a75ef69f26239bf22e21aa6297c4460e3527f88d140101ae4527c885dbbab")
