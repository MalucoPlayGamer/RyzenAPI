-- Lua provided by RyzenAPI
-- Game: Blue Toad Murder Files™: The Mysteries of Little Riddle

-- MAIN APPLICATION
addappid(90400)
-- Game: addappid(90400)

-- MAIN APP DEPOTS / PACKAGES
addappid(90401, 1, "3e398af776efa6a9c411e306bbd4e46c4d5cd0b1ec97adc2a925aad4ab04bb1f")
