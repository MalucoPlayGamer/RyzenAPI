-- Lua provided by SkyAPI 
-- Game: AppID 422420
addappid(422420)
addappid(422421, 1, "ac408aa88275d7d49765d9aaf6cf7eb714a7e856232e00a64488566e90d03f84")
addappid(422422, 1, "f3a195ed0d88801bdbc4c2f632ee6fdde6ecb5f7c73678c4e96eaa33c2e9962f")
