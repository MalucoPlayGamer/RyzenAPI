-- Lua provided by RyzenAPI 
-- Game: AppID 607860
addappid(607860)
addappid(607861, 1, "70df250adcb77708891923267a650837fe3dfab0c270750ba780274a1019b346")
