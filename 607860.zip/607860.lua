-- Lua provided by RyzenAPI
-- Game: AppID 607860

-- MAIN APPLICATION
addappid(607860)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(607861, 1, "70df250adcb77708891923267a650837fe3dfab0c270750ba780274a1019b346")

