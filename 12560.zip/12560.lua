-- Lua provided by RyzenAPI
-- Game: Ride! Carnival Tycoon

-- MAIN APPLICATION
addappid(12560)

-- MAIN APP DEPOTS / PACKAGES
addappid(12561, 1, "7b3393d96aaaa77c67e9fdddd232cfdba71ff86b53188404c13cda21e5b1a7aa")

