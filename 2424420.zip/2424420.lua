-- Lua provided by RyzenAPI
-- Game: Avatar Legends: The Fighting Game 

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(2424420, 1, "8020155cba97dd0a06f8df328ec539fe855c1fe77a38b1dd0b5dbf5e2ed8ed60") -- Avatar Legends: The Fighting Game 
addappid(2424421, 1, "aecbafdba75c145b913095a622b5665b86c3589fe2a77351c9ddbe48b185c4bd") -- Depot 2424421

