-- Lua provided by RyzenAPI
-- Game: 美少女ストリーマーの秘密恋愛 - Secret romance with streamer girls -

-- MAIN APPLICATION
addappid(2371470)
-- Game: addappid(2371470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2371471, 1, "0d0f9be13a9bf8e2c5249aa236b1874e311e53ad2ce508abdc57d913dea62e06")
