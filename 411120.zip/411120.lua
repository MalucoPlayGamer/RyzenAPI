-- Lua provided by RyzenAPI 
-- Game: Galaxy Admirals
addappid(411120)
addappid(411121, 1, "68b2be67ad5c4bb5a41812a1db10b2150ca506c7e71b885beba42ca5191b85aa")
addappid(411122, 1, "b73e76f636be35f181424a30e6b03a36ce0c5c5ad45d045858d7de1b8e88ac88")
addappid(411123, 1, "19513e705485792015bdc869e1d2cdf005a9c6717871dadefe5e8f6f393f671f")
