-- Lua provided by RyzenAPI
-- Game: BeeFense

-- MAIN APPLICATION
addappid(609990)
-- Game: addappid(609990)

-- MAIN APP DEPOTS / PACKAGES
addappid(609991, 1, "9c9144bc356359cd964b85df7f0f843d40581dd2683faf9dd1804f807acc80eb")
