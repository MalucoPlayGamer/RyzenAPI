-- Lua provided by RyzenAPI
-- Game: The Horror Story: Rebirth

-- MAIN APPLICATION
addappid(1943360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1943361, 1, "d3579722cdf83f2a946e6bc841f3b1f14118f9cb6579e927ce13ab18013cb1b3")
