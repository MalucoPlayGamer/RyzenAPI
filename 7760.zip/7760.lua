-- Lua provided by RyzenAPI
-- Game: 7760

-- MAIN APPLICATION
addappid(7760)
-- Game: addappid(7760)

-- MAIN APP DEPOTS / PACKAGES
addappid(7761, 1, "0cf39a3fa8866e9ed2698675b33c90030e66c60eb5b8eab170442ff15e9eb84c")
