-- Lua provided by SkyAPI 
-- Game: Knight Adventure
addappid(409420)
addappid(409421, 1, "5e85524d143b696eef69c4209c91cac3fd88ee1082251837b345f23d77762875")
