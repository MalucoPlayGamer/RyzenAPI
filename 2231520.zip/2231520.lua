-- Lua provided by RyzenAPI
-- Game: 2231520

-- MAIN APPLICATION
addappid(2231520)
-- Game: addappid(2231520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2231521, 1, "0dcbece8905381f8579e76e6c860eced6215b9a11041cea9e4572fdecd2471a1")
