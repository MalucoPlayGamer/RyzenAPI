-- Lua provided by RyzenAPI
-- Game: The Hidden Dragon

-- MAIN APPLICATION
addappid(498040)

-- MAIN APP DEPOTS / PACKAGES
addappid(498041, 1, "853b56bb9a18d1fe0ea81636e4fefc396a63f2a46c180cf40fbcd3379916b52f")

