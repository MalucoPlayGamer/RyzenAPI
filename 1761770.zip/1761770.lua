-- Lua provided by RyzenAPI
-- Game: Universe 51: Tannhäuser Wars

-- MAIN APPLICATION
addappid(1761770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761771, 1, "8976e6ed65fe3fb327383a0fccf8b575c892c144c396b3abb25ef7cb894fc2c2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
