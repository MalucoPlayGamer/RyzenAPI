-- Lua provided by RyzenAPI
-- Game: Universe 51: Tannhäuser Wars

-- MAIN APPLICATION
addappid(1761770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761771, 1, "8976e6ed65fe3fb327383a0fccf8b575c892c144c396b3abb25ef7cb894fc2c2")
