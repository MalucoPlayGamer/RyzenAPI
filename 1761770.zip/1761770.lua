-- Lua provided by SkyAPI 
-- Game: Universe 51: Tannhäuser Wars
addappid(1761770)
addappid(1761771, 1, "8976e6ed65fe3fb327383a0fccf8b575c892c144c396b3abb25ef7cb894fc2c2")
