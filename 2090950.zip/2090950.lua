-- Lua provided by SkyAPI 
-- Game: Magic Tower & Maidens
addappid(2090950)
addappid(2090951, 1, "f5557f7522ea66e99accef81e11706a04791d7744e12859c6ea7eeb3d71c6061")
addappid(2307270, 0, "0d2ac020edfe02dadc2819647c32b28fc4b2e4289fa19f8fb5003bf1e0e51777")
