-- Lua provided by RyzenAPI
-- Game: Disturbed: Beyond Aramor

-- MAIN APPLICATION
addappid(617620)

-- MAIN APP DEPOTS / PACKAGES
addappid(617621, 1, "c1e96849ef290ff7830604fd025fb33a32acfd69d859248e9436cfb864952d9f")
