-- Lua provided by RyzenAPI
-- Game: Lamplight Station

-- MAIN APPLICATION
addappid(753490)

-- MAIN APP DEPOTS / PACKAGES
addappid(753491,0,"2d5dbe0abaec5e54adf2f57612087ee82f2f808e9579ad36ba24370f3be8edc1")

