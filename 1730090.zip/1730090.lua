-- Lua provided by RyzenAPI
-- Game: Evil Soul

-- MAIN APPLICATION
addappid(1730090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730091, 1, "96a2998a6d36ebec5b0995f02aeabc5353214396f24d01a76d8344fc51e1f494")

