-- Lua provided by RyzenAPI
-- Game: Evil Soul

-- MAIN APPLICATION
addappid(1730090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730091, 1, "96a2998a6d36ebec5b0995f02aeabc5353214396f24d01a76d8344fc51e1f494")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
