-- Lua provided by RyzenAPI
-- Game: Cultures - Northland

-- MAIN APPLICATION
addappid(351860)
-- Game: addappid(351860)

-- MAIN APP DEPOTS / PACKAGES
addappid(351861, 1, "04456617ce4ab2250112c40b540d1c96f06fd22d6f60a6de83b9b0a8ff6f544a")
addappid(351862, 1, "145bb35f4903879a8e65c9edf5dc35636a97754c7e2ac4e03ba9a7f700c5725a")
