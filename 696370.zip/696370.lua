-- Lua provided by RyzenAPI
-- Game: 696370

-- MAIN APPLICATION
addappid(696370)
-- Game: addappid(696370)

-- MAIN APP DEPOTS / PACKAGES
addappid(696371, 1, "4999c8099997ea25196e76fdd7cb61573f53611ea21a3c45df3c4abfdf14f60f")
