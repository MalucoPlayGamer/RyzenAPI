-- Lua provided by SkyAPI 
-- Game: BROKE PROTOCOL
addappid(696370)
addappid(696371, 1, "4999c8099997ea25196e76fdd7cb61573f53611ea21a3c45df3c4abfdf14f60f")
