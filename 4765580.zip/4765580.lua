-- 4765580's Lua and Manifest Created by Hubcap Manifest
-- Brainrot Autobattler
-- Created: August 17, 2026 at 08:57:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4765580, 1, "c99a99311e562650438083e6a48d447b1ec878d2376d77e07c2961ef7d181e14") -- Brainrot Autobattler
-- MAIN APP DEPOTS
addappid(4765581, 1, "9c8d758f948105dc29a3212e8256467481445a0d12318a7cbc2f12b0beb11acc") -- Depot 4765581
setManifestid(4765581, "6135006763424272939", 1005668165)