-- Lua provided by RyzenAPI
-- Game: Brainrot Autobattler

-- MAIN APP DEPOTS / PACKAGES
addappid(4765580, 1, "c99a99311e562650438083e6a48d447b1ec878d2376d77e07c2961ef7d181e14") -- Brainrot Autobattler
addappid(4765581, 1, "9c8d758f948105dc29a3212e8256467481445a0d12318a7cbc2f12b0beb11acc") -- Depot 4765581

