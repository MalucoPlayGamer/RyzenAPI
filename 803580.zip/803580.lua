-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(803580)

-- MAIN APP DEPOTS / PACKAGES
addappid(803580,0,"cbc7c1fc41b5109b4a33824237c7ed6d53e78d6c2541ecba6db9993e9980b26d")
