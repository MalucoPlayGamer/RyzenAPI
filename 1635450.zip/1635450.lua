-- Lua provided by RyzenAPI
-- Game: Longvinter

-- MAIN APPLICATION
addappid(1635450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1635451, 1, "c2ee929e91b9cd2a8c5fbeacc241aa350dd3d69ef9b816e088ca7f13d8a1bb7c")
addappid(1635452, 1, "e8ba636ef56364d7b8ac0a117aaf34b9218b34c51597690c910afeb6f34f3f47")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
