-- Lua provided by RyzenAPI
-- Game: Stop and Smell the Flowers

-- MAIN APP DEPOTS / PACKAGES
addappid(2578290, 1, "fc864f2a9e06adab8445aaee6159bd18d0f2d419f0163ac3ae78c7f67ab01c13") -- Stop and Smell the Flowers
addappid(2578291, 1, "d378fae9ec40560a0fdf00a3a1130fdaa65ca4968a13c02d1adf3d33ed29ffea") -- Depot 2578291
addappid(2578292, 1, "99907f0dbab9723bbd8154cd458e45950e0a03180f9471936012a223413ce170") -- Depot 2578292

