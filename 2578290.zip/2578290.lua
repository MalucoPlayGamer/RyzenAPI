-- 2578290's Lua and Manifest Created by Hubcap Manifest
-- Stop and Smell the Flowers
-- Created: August 01, 2026 at 08:38:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2578290, 1, "fc864f2a9e06adab8445aaee6159bd18d0f2d419f0163ac3ae78c7f67ab01c13") -- Stop and Smell the Flowers
-- MAIN APP DEPOTS
addappid(2578291, 1, "d378fae9ec40560a0fdf00a3a1130fdaa65ca4968a13c02d1adf3d33ed29ffea") -- Depot 2578291
setManifestid(2578291, "6238789914288593631", 324124667)
addappid(2578292, 1, "99907f0dbab9723bbd8154cd458e45950e0a03180f9471936012a223413ce170") -- Depot 2578292
setManifestid(2578292, "1940822833848126076", 265890707)