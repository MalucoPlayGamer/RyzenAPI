-- Lua provided by RyzenAPI
-- Game: Kill Me If You Can: Multiplayer Edition

-- MAIN APPLICATION
addappid(3346310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3346311, 1, "8ba92ff4cab6d75549bc9cb657ce1d35f1bc4a4842d3c9eed23f63ce7260cf81")
