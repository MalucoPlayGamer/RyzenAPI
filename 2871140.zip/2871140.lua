-- Lua provided by RyzenAPI
-- Game: The Real Face of a VTuber

-- MAIN APPLICATION
addappid(2871140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2871141,0,"7a00b7fad72e0785e0ba6bb0b76a7901bda736ed3dac8dd9f9bbf45d703fcfe6")

