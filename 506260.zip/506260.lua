-- Lua provided by RyzenAPI
-- Game: Cladun Returns: This Is Sengoku!

-- MAIN APPLICATION
addappid(506260)
addappid(578290)

-- MAIN APP DEPOTS / PACKAGES
addappid(506261, 1, "01696906973a669990f1f45bf680fe49350ac68828c7e2c1c3963f1418e5ba77")

