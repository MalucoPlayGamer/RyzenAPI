-- Lua provided by RyzenAPI
-- Game: Game: WhiteClothes

-- MAIN APPLICATION
addappid(1495940)
addappid(2398510)
-- Game: addappid(1495940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495941, 1, "1bddbd595a18c47e4e62490c0ecfc09092d2bc7547b25b55ec3f154516e4c0a4")
addappid(1495943, 1, "142b00b3e303ff8c5b6b3793ddc8c0cab8886ce96189b9b920504b971721c0db")
