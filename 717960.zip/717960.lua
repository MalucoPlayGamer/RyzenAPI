-- Lua provided by RyzenAPI
-- Game: AppID 717960

-- MAIN APPLICATION
addappid(717960)

-- MAIN APP DEPOTS / PACKAGES
addappid(717961, 1, "e85990703225120a54f5187a09f71ac24e28d5940714942e775f67247b6105b2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
