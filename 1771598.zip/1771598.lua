-- Lua provided by RyzenAPI
-- Game: 1771598

-- MAIN APPLICATION
addappid(1771598)
-- Game: addappid(1771598)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771598,0,"2d7b60fcbe5dfe82f06656b1a86911b8bc776d5a5e7a08814c9de4178284535b")
