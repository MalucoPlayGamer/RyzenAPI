-- Lua provided by RyzenAPI 
-- Game: Magic Quest
addappid(454870)
addappid(454871, 1, "89cd4916138abfe818c92994fba46baae7f655733059a0654a75e2dcdca00722")
