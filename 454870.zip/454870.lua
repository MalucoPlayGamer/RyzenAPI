-- Lua provided by RyzenAPI
-- Game: Magic Quest

-- MAIN APPLICATION
addappid(454870)
-- Game: addappid(454870)

-- MAIN APP DEPOTS / PACKAGES
addappid(454871, 1, "89cd4916138abfe818c92994fba46baae7f655733059a0654a75e2dcdca00722")
