-- Lua provided by RyzenAPI
-- Game: Looking_for_food

-- MAIN APPLICATION
addappid(943880)

-- MAIN APP DEPOTS / PACKAGES
addappid(943881, 1, "880f5a4af1535493ae5d2b0d237bd391766d44917f20a50a276aef9d362cce03")
