-- Lua provided by RyzenAPI
-- Game: The Lord of the Rings: Adventure Card Game - Definitive Edition

-- MAIN APPLICATION
addappid(509580)
addappid(862380)
-- Game: addappid(509580)

-- MAIN APP DEPOTS / PACKAGES
addappid(509581, 1, "52c1a0087cbfb151a2209e4d93d765e9878d82528d0076b0c86ae46d6af8ecae")
addappid(509582, 1, "b6b0c192e229b3cb26585659eb421d8f57b3f2a16c17346690f21812f7c52b32")
addappid(509584, 1, "6f4ef29c5403c908f51d9898f44f7eba226e146ec440fac3ef4f979367e1f830")
addappid(509585, 1, "35378303b9f0a164e4940a248919e2105cd2082824b1a555a608a2dee92cd67a")
