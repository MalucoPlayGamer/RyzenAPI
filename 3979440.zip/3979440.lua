-- Lua provided by RyzenAPI
-- Game: Puzzle Gallery: Jigsaw Art Collection

-- MAIN APPLICATION
addappid(3979440)
