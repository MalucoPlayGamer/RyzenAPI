-- Lua provided by RyzenAPI
-- Game: Puzzle Gallery: Jigsaw Art Collection

-- MAIN APPLICATION
addappid(3979440)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4023090)
addappid(4036940)
addappid(4036950)
addappid(4036960)
