-- Lua provided by RyzenAPI
-- Game: Chasemaster

-- MAIN APPLICATION
addappid(2495720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2495723,0,"7489b6bb59dd9062273608006dc165c412eb924ae6ffbfb3d5e17be5514c14ea")
addappid(2495724,0,"560e48dbf1f3746213f2c3ad164d38b9f056e32c83ef1f8d0b222839e022edd5")

