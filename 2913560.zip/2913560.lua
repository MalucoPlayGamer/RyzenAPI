-- Lua provided by RyzenAPI
-- Game: addappid(2913560)

-- MAIN APPLICATION
addappid(2913560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2913561, 1, "f59f5c659d77716e5d5e64181938fa89ed2f583ef5d98f1e6c03792cb8f60698")
