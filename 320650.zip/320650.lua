-- Lua provided by RyzenAPI
-- Game: Season Match 2

-- MAIN APPLICATION
addappid(320650)

-- MAIN APP DEPOTS / PACKAGES
addappid(320651, 1, "6e6745746ab2008182aa5e6d900c7d4bf95f57134b5c363e5fa1768815589b88")
addappid(320656, 1, "c9ef45e928bec7a787a6e028fcebf664d8230cd81fd079bc5fd44f744aae40b3")
