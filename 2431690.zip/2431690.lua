-- Lua provided by RyzenAPI
-- Game: We Are Lost

-- MAIN APPLICATION
addappid(2431690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431691, 1, "07ca1073b08dbbda5b7a58e3cb9965e7fc158f332b3c5984b3fc69eb214ca01e")
