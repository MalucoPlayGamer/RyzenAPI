-- Lua provided by RyzenAPI
-- Game: 401800

-- MAIN APPLICATION
addappid(401800)
-- Game: addappid(401800)

-- MAIN APP DEPOTS / PACKAGES
addappid(401801, 1, "84b8d2a024afdd60da2e2d9ca9779328c4995d783d38194f85c19e8ce61c97f1")
addappid(401802, 1, "6cf8d7da33d2f620b58d131e43b22e3e4aede37159d2e23c2f494213a1cae599")
