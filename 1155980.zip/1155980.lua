-- Lua provided by RyzenAPI
-- Game: addappid(1155980)

-- MAIN APPLICATION
addappid(1155980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1155981, 1, "fe4e9671f58e894e7a6986d5c42792c9a6ea7c5b5e1fbf657d29367c1fcd5fc8")
