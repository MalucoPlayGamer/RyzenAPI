-- Lua provided by RyzenAPI 
-- Game: ALIA’s CARNIVAL！
addappid(1094530)
addappid(1094531, 1, "37cb045dd9f27bc97882d213c0b435344b427ea418682dd0a4592ca6d8a89a53")
addappid(1193690, 0, "18762011bf5995bc128ddc7367f2cc5e69edfeaa03f9373751b99bca98677855")
