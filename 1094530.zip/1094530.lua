-- Lua provided by RyzenAPI
-- Game: ALIA’s CARNIVAL！

-- MAIN APPLICATION
addappid(1094530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094531, 1, "37cb045dd9f27bc97882d213c0b435344b427ea418682dd0a4592ca6d8a89a53")
addappid(1193690, 0, "18762011bf5995bc128ddc7367f2cc5e69edfeaa03f9373751b99bca98677855")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
