-- Lua provided by RyzenAPI
-- Game: Game: Our Love Will Grow

-- MAIN APPLICATION
addappid(423770)
-- Game: addappid(423770)

-- MAIN APP DEPOTS / PACKAGES
addappid(423771, 1, "992526ac51aaf5bd3917e7b7bf65b725ef06ddb0e95d27eff28a2b9b75a36856")
addappid(425130, 0, "4c98c2a5a2177586355e41a7d81e6dd0486dc4283aff8f67e72032b6ec2b74d9")
