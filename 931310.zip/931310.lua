-- Lua provided by RyzenAPI
-- Game: Airplane Mode

-- MAIN APPLICATION
addappid(931310)

-- MAIN APP DEPOTS / PACKAGES
addappid(931311, 1, "4af89061cdbb47e91d803a00510ffe0a4422ab32c8868c12f09be4c0170a7625")
