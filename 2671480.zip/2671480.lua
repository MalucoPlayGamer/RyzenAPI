-- Lua provided by RyzenAPI
-- Game: 2671480

-- MAIN APPLICATION
addappid(2671480)
-- Game: addappid(2671480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2671481, 1, "35311d0ecebc5ec86e7ca50fc7419c21bbf860624ae94a780ce4d29b15e83873")
