-- Lua provided by RyzenAPI 
-- Game: AppID 576390
addappid(576390)
addappid(576391, 1, "dff51c7cf3e6ded42c5292a287ddead87acec4d2dab26fe8a4ad90d401a08cf1")
addappid(576392, 1, "a08ec93eb8f8d992f60a773f31a552525ee2b86ef583d71338f972241f718098")
addappid(576393, 1, "0c7217154a37f6425b43f296827a9baa5ebef67999f33d95f032231b6a6ea8b7")
