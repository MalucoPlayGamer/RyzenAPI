-- Lua provided by SkyAPI 
-- Game: Restaurant Empire II
addappid(32900)
addappid(32901, 1, "f877f700161f65e3f7ae473890f4b4ebc9b0c78cb45dc17b94ed000b6abed24a")
addappid(32902, 1, "c2eccbf22ba5c0fabd192c7d43a7ee3a63718549c8f7a447b481095f8296bf0c")
addappid(32903, 1, "492c9012878e023ad6f8a2b348b39339b69176fd1b875a9d4bd5c2fbace79c9b")
