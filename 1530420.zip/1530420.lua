-- Lua provided by RyzenAPI
-- Game: Fallen Tear: The Ascension Demo

-- MAIN APPLICATION
addappid(1530420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1530421, 1, "23e3ffcae59d9e014c78dcd7a3bbd2862cc4614f5426771af4b236d811966dfb")

