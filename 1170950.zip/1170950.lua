-- Lua provided by SkyAPI 
-- Game: AppID 1170950
addappid(1170950)
addappid(1170951, 1, "94af5252c477a832d7d00b05f92b88eac984fbf4deae87b88b1852fa91f9719f")
