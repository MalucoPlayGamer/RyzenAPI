-- Lua provided by RyzenAPI
-- Game: AppID 1170950

-- MAIN APPLICATION
addappid(1170950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1170951, 1, "94af5252c477a832d7d00b05f92b88eac984fbf4deae87b88b1852fa91f9719f")

