-- Lua provided by RyzenAPI
-- Game: addappid(1170950)

-- MAIN APPLICATION
addappid(1170950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1170951, 1, "94af5252c477a832d7d00b05f92b88eac984fbf4deae87b88b1852fa91f9719f")
