-- Lua provided by RyzenAPI
-- Game: 1088720

-- MAIN APPLICATION
addappid(1088720)
-- Game: addappid(1088720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088721, 1, "6dc4641baacdc3a1e5f8c16ddbf5c58ebfa97a00a78acf922e7488dd4c3fdfb8")
