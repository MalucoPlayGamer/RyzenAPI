-- Lua provided by RyzenAPI
-- Game: 枝江小镇 Demo

-- MAIN APPLICATION
addappid(1919660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919661, 1, "981e3491f436ee40618e0983ffc61ecdc8a760a4fc02d90c3199c84872598d91")
