-- Lua provided by RyzenAPI
-- Game: addappid(2056220)

-- MAIN APPLICATION
addappid(2056220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2056221, 1, "bc4e7a201782f1f30d4ff59d0ce296c2641d8f550b07a201ab8bc9136bf1c54b")
