-- Lua provided by RyzenAPI
-- Game: Game: AppID 836850

-- MAIN APPLICATION
addappid(836850)
-- Game: addappid(836850)

-- MAIN APP DEPOTS / PACKAGES
addappid(836851, 1, "ddf0dc8fa6f731855b5c074835598f57899badebb7d5129eea4fea3abbd4d8cc")
