-- Lua provided by RyzenAPI
-- Game: Populous™: The Beginning

-- MAIN APPLICATION
addappid(2616430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2616431, 1, "336fe51948d79441aaf0e12dda394f5d091d0047e7997329ea13635c09b3f7a0")
