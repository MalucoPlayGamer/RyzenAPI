-- Lua provided by RyzenAPI
-- Game: Top Burger Shop Simulator

-- MAIN APPLICATION
addappid(3310020) -- Top Burger Shop Simulator

-- MAIN APP DEPOTS / PACKAGES
addappid(3310021, 1, "73e76098b88be488a2fe0e70318abd72f57743a311011dc373e2f528026907d5") -- Depot 3310021

