-- 3310020's Lua and Manifest Created by Hubcap Manifest
-- Top Burger Shop Simulator
-- Created: August 01, 2026 at 00:34:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3310020) -- Top Burger Shop Simulator
-- MAIN APP DEPOTS
addappid(3310021, 1, "73e76098b88be488a2fe0e70318abd72f57743a311011dc373e2f528026907d5") -- Depot 3310021
setManifestid(3310021, "1808519278938398424", 217952904)