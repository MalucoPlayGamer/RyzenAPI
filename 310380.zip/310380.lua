-- Lua provided by RyzenAPI
-- Game: addappid(310380)

-- MAIN APPLICATION
addappid(310380)

-- MAIN APP DEPOTS / PACKAGES
addappid(310381, 1, "556263de88eeb49f504e8dcef068835249203f67bbd821bc1ec106629b46a71e")
