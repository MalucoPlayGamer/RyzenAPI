-- Lua provided by RyzenAPI
-- Game: AppID 310380

-- MAIN APPLICATION
addappid(310380)
addappid(333560)
addappid(338580)
addappid(357850)
addappid(465220)
addappid(492670)
addappid(492700)
addappid(520980)
addappid(521030)
addappid(524920)
addappid(543620)
addappid(711020)
addappid(711021)
addappid(711022)
addappid(711023)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(310381, 1, "556263de88eeb49f504e8dcef068835249203f67bbd821bc1ec106629b46a71e")

