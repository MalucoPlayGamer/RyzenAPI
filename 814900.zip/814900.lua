-- Lua provided by SkyAPI 
-- Game: AppID 814900
addappid(814900)
addappid(814901, 1, "d93132006e491b1f64d6befc0561b5ec8cb39b14f912341bbc46e0f20e7be5aa")
