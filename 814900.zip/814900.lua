-- Lua provided by RyzenAPI
-- Game: AppID 814900

-- MAIN APPLICATION
addappid(814900)
-- Game: addappid(814900)

-- MAIN APP DEPOTS / PACKAGES
addappid(814901, 1, "d93132006e491b1f64d6befc0561b5ec8cb39b14f912341bbc46e0f20e7be5aa")
