-- Lua provided by RyzenAPI 
-- Game: AppID 3235630
addappid(3235630)
addappid(3235631, 1, "3c02e1589c82dfda1ee49d2c6126d2dd74ab3b90a6abecc8c2e6a29491c3c3b2")
