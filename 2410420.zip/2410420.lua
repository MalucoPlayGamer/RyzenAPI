-- Lua provided by RyzenAPI
-- Game: KIDNEY STONE Clicker

-- MAIN APPLICATION
addappid(2410420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2410421, 1, "7efa70ee6999ce7a96625d1aa5be9c32db94b703cc9c305739a0f73a33a9e51d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
