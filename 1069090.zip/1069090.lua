-- Lua provided by RyzenAPI
-- Game: Game: AppID 1069090

-- MAIN APPLICATION
addappid(1069090)
-- Game: addappid(1069090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069091, 1, "2746689ebd45f6b851f265726009b1d33d203d94bc47cbd3af5708de34874df5")
