-- Lua provided by RyzenAPI
-- Game: AppID 1069090

-- MAIN APPLICATION
addappid(1069090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1069091, 1, "2746689ebd45f6b851f265726009b1d33d203d94bc47cbd3af5708de34874df5")

