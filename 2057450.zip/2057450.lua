-- Lua provided by RyzenAPI 
-- Game: The Lilliput Workshop Demo
addappid(2057450)
addappid(2057451, 1, "ee9c473a4dcb602578b9da8b980366bb1c45c45384a3db91dc1a4dd94dd249f8")
