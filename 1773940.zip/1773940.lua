-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1773940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1773940,0,"674e75e2675fb3c9e1cacc7ec4eecdbd74742313e7f18bf8ab75925567cbeb23")
