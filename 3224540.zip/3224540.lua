-- 3224540's Lua and Manifest Created by Hubcap Manifest
-- VOIDFACE
-- Created: August 19, 2026 at 12:03:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3224540, 1, "bba1a37b69cf0a1c96989557ee77091435edd25390ee82dddf8d1e8790afe988") -- VOIDFACE
-- MAIN APP DEPOTS
addappid(3224541, 1, "e41fb6bb5d851151ba651288e5d366b372501a674c8cf61347507f87d1a6081f") -- Depot 3224541
setManifestid(3224541, "3506226309622414997", 418277543)