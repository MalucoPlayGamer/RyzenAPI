-- Lua provided by RyzenAPI
-- Game: Aim Down Screen

-- MAIN APPLICATION
addappid(2755450)
-- Game: addappid(2755450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2755451, 1, "d73afa28be0a1b4fc40eb7df8fa31c4aedc4f766f2de1aa97f21e0be3b3c5eab")
