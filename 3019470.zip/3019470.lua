-- Lua provided by RyzenAPI
-- Game: addappid(3019470)

-- MAIN APPLICATION
addappid(3019470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3019471, 1, "f311e3b20ba030f19e5f40767d4bb4192a241cab8a6edce7fa05414975758a41")
