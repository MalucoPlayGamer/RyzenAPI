-- Lua provided by RyzenAPI
-- Game: The Childs Sight

-- MAIN APPLICATION
addappid(1002310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002311, 1, "4fcc30dcf51592edfdff47995dd0591564d8a1bdf4aadc1c1bed999295bbf912")
