-- Lua provided by RyzenAPI
-- Game: Sniper Elite VR

-- MAIN APPLICATION
addappid(752480)

-- MAIN APP DEPOTS / PACKAGES
addappid(752482,0,"fd6d41b828471e30b0a9d5393149283f6de2656c1360ec20c67218d3e679b066")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
