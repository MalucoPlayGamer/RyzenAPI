-- Lua provided by RyzenAPI
-- Game: Sniper Elite VR

-- MAIN APPLICATION
addappid(752480)
-- Game: addappid(752480)

-- MAIN APP DEPOTS / PACKAGES
addappid(752482,0,"fd6d41b828471e30b0a9d5393149283f6de2656c1360ec20c67218d3e679b066")
