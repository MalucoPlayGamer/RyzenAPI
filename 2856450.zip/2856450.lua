-- Lua provided by RyzenAPI
-- Game: Dimensionals

-- MAIN APPLICATION
addappid(2856450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2856454,0,"c8009814b6f1e6856f0fd4fc4221cc6c72a3a13994ef13a6214ead539257873b")
