-- Lua provided by RyzenAPI
-- Game: 2459670

-- MAIN APPLICATION
addappid(2459670)
-- Game: addappid(2459670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2459671, 1, "f0d772a5ede4d83669ad233d3be482f4f2978289062d9cf652c956b20e56db7b")
