-- Lua provided by SkyAPI 
-- Game: AppID 2459670
addappid(2459670)
addappid(2459671, 1, "f0d772a5ede4d83669ad233d3be482f4f2978289062d9cf652c956b20e56db7b")
