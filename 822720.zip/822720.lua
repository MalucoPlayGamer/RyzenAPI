-- Lua provided by RyzenAPI
-- Game: Game: The Amazing Bernard

-- MAIN APPLICATION
addappid(822720)
-- Game: addappid(822720)

-- MAIN APP DEPOTS / PACKAGES
addappid(822721, 1, "5ed8eea9ff85ad56d971c283cfb5563375727cc93257405404e33f4ea18b56c1")
addappid(831550, 0, "273225a2bd8336001eb1fc6f4ec04aa7513398a1518f133d42734c089237f3b6")
