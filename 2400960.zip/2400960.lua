-- Lua provided by RyzenAPI
-- Game: SolForge Fusion

-- MAIN APPLICATION
addappid(2400960)



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
