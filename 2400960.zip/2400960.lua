-- Lua provided by RyzenAPI
-- Game: SolForge Fusion

-- MAIN APPLICATION
addappid(2400960)
