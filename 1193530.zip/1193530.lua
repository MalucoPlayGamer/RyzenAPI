-- Lua provided by RyzenAPI
-- Game: Black Smith

-- MAIN APPLICATION
addappid(1193530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193531, 1, "fa786449288a221a0832dd2210518ede4b3aa47a22f7e3b13a9ad8f37a8e1643")

