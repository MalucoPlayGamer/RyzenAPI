-- Lua provided by RyzenAPI
-- Game: Game: OUTSP4CE

-- MAIN APPLICATION
addappid(1489900)
-- Game: addappid(1489900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1489901, 1, "6ca7d3275675c11874a791046bd9247c69ec66e4be6501225fc3cb902f4d844c")
