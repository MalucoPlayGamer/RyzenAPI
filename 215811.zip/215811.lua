-- Lua provided by RyzenAPI
-- Game: Darksiders II - Crucible Pass

-- MAIN APPLICATION
addappid(215811)

-- MAIN APP DEPOTS / PACKAGES
addappid(215811,0,"f06480e856b89c9aa11867d00ca12ec6a79a3b2ee96990fba0d821467e6c28dc")

