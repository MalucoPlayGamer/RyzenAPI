-- Lua provided by RyzenAPI
-- Game: Succubus: SEX Story

-- MAIN APPLICATION
addappid(2560670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2560671, 1, "7985d57fc202a3825ab83279dad777f9267a01997d766261070e4c271a1b5f6f")
