-- Lua provided by RyzenAPI 
-- Game: Lost Girl In Mirror
addappid(2535730)
addappid(2535731, 1, "afc0c7b8a935fe62a874aede1e3a3e0cee00551d510eaa773b1b27e30d5d5e90")
