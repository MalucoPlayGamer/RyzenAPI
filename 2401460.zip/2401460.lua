-- Lua provided by RyzenAPI
-- Game: addappid(2401460)

-- MAIN APPLICATION
addappid(2401460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2401467,0,"1070e450f68f8f855dcd9b730e78cd6b1e897b825d6424c4c0e6de64d9e71d73")
