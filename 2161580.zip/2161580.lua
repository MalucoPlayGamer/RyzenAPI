-- Lua provided by RyzenAPI
-- Game: addappid(2161580)

-- MAIN APPLICATION
addappid(2161580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2161581, 1, "aba94665387bfd097d5ccde4c338f2e9f2ae6329365287ee204db3b023e0b194")
