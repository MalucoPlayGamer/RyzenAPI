-- Lua provided by RyzenAPI
-- Game: Game: Maku

-- MAIN APPLICATION
addappid(2000980)
addappid(2612280)
-- Game: addappid(2000980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2000981, 1, "94e5b42050342ff73dce196024794355ddc2304949283e0d358d9b0729dc5838")
addappid(2000982, 1, "eb7c77e90748cee8ee9b70905affc35a4e55081acbce33421d63cc40d1b8c36b")
