-- Lua provided by RyzenAPI
-- Game: Jagged Alliance Gold

-- MAIN APPLICATION
addappid(283270)

-- MAIN APP DEPOTS / PACKAGES
addappid(283271, 1, "fbd7e63812e4543d7ad496610f5e153e972c3661348b71b6f235fd31ad64bd67")
addappid(283272, 1, "d72665f3f0a9d68c8a1e423bb7b78ebe37d08f2f9c379304397f7cc4dcab039d")
addappid(283273, 1, "ee31d3d38657b6a474375ca61bbe003f5efc70b8f1a800122c77229170abb48c")

