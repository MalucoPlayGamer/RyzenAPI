-- Lua provided by SkyAPI 
-- Game: Summer Memories+ - Expansion DLC
addappid(1390150)
addappid(1390151, 1, "609fc609a8f7331a13bd828804e541b1d1828a0bb17be063ce45b4e609a4d07c")
addappid(1390152, 1, "21326afe0d63411f4d163d64e57458dc1f85ee06da2043a310985ad856d049e6")
addappid(1390153, 1, "0afc28edbdc9fc9e6d5af5c2b52ad5b45e202ac8845aecf4a7e54c99b455bed4")
