-- Lua provided by RyzenAPI
-- Game: addappid(990630)

-- MAIN APPLICATION
addappid(990630)

-- MAIN APP DEPOTS / PACKAGES
addappid(990631, 1, "54fecd8d4479ec9b8dee9826e85bd791be330cac81710761bf5743522f82dc4d")
