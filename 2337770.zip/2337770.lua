-- Lua provided by RyzenAPI
-- Game: addappid(2337770)

-- MAIN APPLICATION
addappid(2337770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2337772,0,"417a7084ba03cf132298ab6ebd97599cf6370eab7d9192507e50c5338b5e41fc")
