-- Lua provided by SkyAPI 
-- Game: Ampu-Tea
addappid(289090)
addappid(289091, 1, "fd9e99422d88e451760196498692d139a49b0ba66df670caaf78409e2fe6fae4")
