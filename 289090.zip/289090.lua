-- Lua provided by RyzenAPI
-- Game: 289090

-- MAIN APPLICATION
addappid(289090)
-- Game: addappid(289090)

-- MAIN APP DEPOTS / PACKAGES
addappid(289091, 1, "fd9e99422d88e451760196498692d139a49b0ba66df670caaf78409e2fe6fae4")
