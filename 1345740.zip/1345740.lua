-- Lua provided by SkyAPI 
-- Game: 恋爱绮谭~不存在的夏天~
addappid(1345740)
addappid(1345741, 1, "1a776cf40337a4f50d2d0f8ddfad19a34991b1dce0f0e69cf3d74d3c82161061")
addappid(1457450, 0, "4a56d16c6d531aa2599dc673b78bdb898d6a4ed9572d79d7fb01f2a5fc85c876")
