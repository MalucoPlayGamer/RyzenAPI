-- Lua provided by RyzenAPI
-- Game: Strategic Mind: Spectre of Communism

-- MAIN APPLICATION
addappid(1341170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341171, 1, "e976a70c3ae0b0100b4b43c0e4ffd93be51b0984ab9e4348ccc33643711c4a71")
