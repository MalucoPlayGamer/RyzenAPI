-- Lua provided by RyzenAPI
-- Game: Strategic Mind: Spectre of Communism

-- MAIN APPLICATION
addappid(1341170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1341171, 1, "e976a70c3ae0b0100b4b43c0e4ffd93be51b0984ab9e4348ccc33643711c4a71")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
