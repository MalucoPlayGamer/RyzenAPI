-- Lua provided by RyzenAPI
-- Game: Haunted Elevator - 闹鬼电梯

-- MAIN APPLICATION
addappid(3113530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3113531, 1, "1403eb51ea7be9e17e9745d6ec5e163f1c5f9cbbe7a457c6497567dbccc0de2a")

