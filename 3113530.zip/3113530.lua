-- Lua provided by RyzenAPI
-- Game: Haunted Elevator - 闹鬼电梯

-- MAIN APPLICATION
addappid(3113530)
-- Game: addappid(3113530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3113531, 1, "1403eb51ea7be9e17e9745d6ec5e163f1c5f9cbbe7a457c6497567dbccc0de2a")
