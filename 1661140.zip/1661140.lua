-- Lua provided by RyzenAPI
-- Game: 1661140

-- MAIN APPLICATION
addappid(1661140)
-- Game: addappid(1661140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1661141, 1, "23875210d6e31a1ed0ee76765bdc74d29120d532abc0602b8e53d46cf6febe89")
