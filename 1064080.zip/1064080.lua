-- Lua provided by RyzenAPI
-- Game: addappid(1064080)

-- MAIN APPLICATION
addappid(1064080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064081, 1, "7f20ce434d8d7f2a2f65100d0c3ee7b548558db9b3a468f95f1df3b917bf29eb")
