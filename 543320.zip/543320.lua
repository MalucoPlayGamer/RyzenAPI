-- Lua provided by RyzenAPI
-- Game: Alchemist

-- MAIN APPLICATION
addappid(543320)

-- MAIN APP DEPOTS / PACKAGES
addappid(543321, 1, "ceae99e0d45eba837aad8bad41d1b7647d7f61b15298858e97066964a6976acf")
