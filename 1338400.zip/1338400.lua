-- Lua provided by RyzenAPI
-- Game: Fishing: North Atlantic Soundtrack

-- MAIN APPLICATION
addappid(1338400)
-- Game: addappid(1338400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1338401, 1, "eb0585c8874f17caab7aa897c500c8e57c5c358e0727f2eed7be69ee15721b17")
addappid(1338402, 1, "b29802be6c718d8ca0b47478b588d72c906c3a2f8b609fc446fbfac102478756")
