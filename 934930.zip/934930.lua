-- Lua provided by RyzenAPI
-- Game: Game: RDS - The Official Drift Videogame

-- MAIN APPLICATION
addappid(934930)
-- Game: addappid(934930)

-- MAIN APP DEPOTS / PACKAGES
addappid(934931, 1, "f54bafe2333dceab35812d3990e57d83d9c16ba31490a765ad6b43ba9090f325")
