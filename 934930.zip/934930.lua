-- Lua provided by RyzenAPI
-- Game: RDS - The Official Drift Videogame

-- MAIN APPLICATION
addappid(934930)
addappid(999300)
addappid(999301)
addappid(999302)
addappid(1191850)
addappid(1210000)

-- MAIN APP DEPOTS / PACKAGES
addappid(934931,0,"f54bafe2333dceab35812d3990e57d83d9c16ba31490a765ad6b43ba9090f325")

