-- Lua provided by RyzenAPI
-- Game: RDS - The Official Drift Videogame

-- MAIN APPLICATION
addappid(934930)
addappid(999300)
addappid(999301)
addappid(999302)
addappid(1191850)
addappid(1210000)

-- MAIN APP DEPOTS / PACKAGES
addappid(934931,0,"f54bafe2333dceab35812d3990e57d83d9c16ba31490a765ad6b43ba9090f325")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
