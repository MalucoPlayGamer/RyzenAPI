-- Lua provided by RyzenAPI 
-- Game: MX vs. ATV Reflex
addappid(55140)
addappid(55141, 1, "a2a06bd5998dbf680aebea06fa490d47338a29ed45e43a2cbc5e8aedd9cfc99a")
addappid(55142, 1, "6103f390de2683057ee3efef64387bd959933ca8fb1036790899b49d57dbee20")
addappid(55143, 1, "b4aaef8f4c301ac08fb7d84bef78ef5beae65a7bba7a50fe4f9e854909367542")
addappid(55144, 1, "7da930c09f881fd2267adc7705aa43d00cd94d60992bdcb2992cd641448a28d3")
addappid(55145, 1, "71095427a08b7a792716c2f3c6295656e92ca0d15730ddbba6ca00d6e0df5edc")
addappid(55146, 1, "5f490e7472e7a6ef9bc54bc75e5764533ce927ee7b1b63c347b6924cee6bdb1c")
