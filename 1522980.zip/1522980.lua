-- Lua provided by RyzenAPI
-- Game: addappid(1522980)

-- MAIN APPLICATION
addappid(1522980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1522981, 1, "585e10aacc4137ba62eb8c4015eb3dc442c7fbaf52c6aac9ead25d4d4f843d59")
