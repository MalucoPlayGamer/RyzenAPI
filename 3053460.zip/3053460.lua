-- Lua provided by RyzenAPI
-- Game: Game: Evil Corporation Demo

-- MAIN APPLICATION
addappid(3053460)
-- Game: addappid(3053460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3053461, 1, "2c713255c25425efc67aac9d58e781081de9bb9799a0252388ffa900152b2a94")
