-- Lua provided by SkyAPI 
-- Game: Kings of Kung Fu
addappid(316930)
addappid(316931, 1, "553adf07d9185f44173dce12f693104326c50ab40b04f21ce8395d7b53cf150c")
addappid(382950, 0, "57f1d59d9dbb9c27f61ce6a178d5117c78a11f82b20903d867d64d005065cc97")
