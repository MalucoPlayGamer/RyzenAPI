-- Lua provided by RyzenAPI
-- Game: Struggle F.O

-- MAIN APPLICATION
addappid(2633080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2633081, 1, "2530a41d518a5b593d4392543d9f69f69ceb84422c8aa3a3e205075d6e8c1d85")
