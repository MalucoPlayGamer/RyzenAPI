-- Lua provided by RyzenAPI 
-- Game: Hug Survivor
addappid(2271940)
addappid(2271941, 1, "23dc3724a1ae50dbb07b41819bf7b405870d8a103574aad925e8736670142e21")
