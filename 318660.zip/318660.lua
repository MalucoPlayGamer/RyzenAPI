-- Lua provided by RyzenAPI
-- Game: 318660

-- MAIN APPLICATION
addappid(318660)
-- Game: addappid(318660)

-- MAIN APP DEPOTS / PACKAGES
addappid(318661, 1, "b8ca5e717af7bce37ee2329ffe9e5eae4a49fb1c414ae51bc03ed99acc77326f")
addappid(318662, 1, "e1b8921b31677760a4b27b8e4440c887f3eb7af7f9e5b2f89ae757d65e870ce6")
