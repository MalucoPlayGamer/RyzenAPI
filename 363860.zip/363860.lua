-- Lua provided by RyzenAPI
-- Game: addappid(363860)

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(363860)

-- MAIN APP DEPOTS / PACKAGES
addappid(363862,0,"95d289db6425849619bee0c01f4ad1a6394913957d879f06484a6ff93384841a")
addappid(2586060,0,"a26be4be39ded04c4002abfdcd3320daffbaa976a3a7a8af65c2babd18e874a7")
