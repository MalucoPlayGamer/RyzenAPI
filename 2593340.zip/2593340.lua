-- 2593340's Lua and Manifest Created by Hubcap Manifest
-- Wonderia
-- Created: July 23, 2026 at 02:37:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2593340) -- Wonderia
addtoken(2593340, "8000724797120855815")
-- MAIN APP DEPOTS
addappid(2593341, 1, "208e232b6e1a892ffce6084d22bc1cc8756715474738ad62aea7330051b76e2b") -- Depot 2593341
setManifestid(2593341, "8829903306296349840", 1593053731)
addappid(2593342, 1, "14657320bd53c1a27f31edd6960f16a18a02aa801b97b7bcc0dee54c6d64d29d") -- Depot 2593342
setManifestid(2593342, "112582866091670548", 5849059887)
addappid(2593343, 1, "5a2ca35821fad6d662a0f41c587708a7abad2878530ce584e978902b12c6c9b0") -- Depot 2593343
setManifestid(2593343, "5372799145256530287", 1593053731)