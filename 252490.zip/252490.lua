-- Lua provided by RyzenAPI
-- Game: Rust

-- MAIN APPLICATION
addappid(252490)
addappid(494560)
addappid(1174370)
addappid(1353060)
addappid(1374000)
addappid(1670430)

-- MAIN APP DEPOTS / PACKAGES
addappid(252492,0,"96b750328197855f4311ba6ad6d86e9051866cc6b9a6c851de55cc41b8ad9a24")
addappid(252494,0,"5d5f72c0460cb7598666696c1b2f612f22efb43fb87cf4322e596bfec8a231ec")
addappid(252495,0,"728fcdc1c6af4454f3c86e5bc62a75875af5ba790cc8a2623620e216086e034d")
