-- Lua provided by SkyAPI 
-- Game: AGRYOS: Recovering Eden
addappid(1702980)
addappid(1702981, 1, "42871f083aab28b09b848f72536cce08910e9cf91e5c06bdc9c7e02843f7c8a3")
