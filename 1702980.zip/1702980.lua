-- Lua provided by RyzenAPI
-- Game: AGRYOS: Recovering Eden

-- MAIN APPLICATION
addappid(1702980)
-- Game: addappid(1702980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702981, 1, "42871f083aab28b09b848f72536cce08910e9cf91e5c06bdc9c7e02843f7c8a3")
