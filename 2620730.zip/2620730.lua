-- Lua provided by RyzenAPI
-- Game: Game: DEVIATOR

-- MAIN APPLICATION
addappid(2620730)
-- Game: addappid(2620730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620731, 1, "d7a48e5026010c357d7b5c8064679e589f8def84dc2689b353b600df90a785d5")
