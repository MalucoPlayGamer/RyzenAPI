-- Lua provided by RyzenAPI
-- Game: Game: Frostford

-- MAIN APPLICATION
addappid(1213890)
-- Game: addappid(1213890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1213891, 1, "cc9728ddddd9b68c56d584c0ba18387b1158a16e52aaf0e8d0ffbfd8aa99680c")
