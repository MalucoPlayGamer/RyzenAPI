-- Lua provided by SkyAPI 
-- Game: Frostford
addappid(1213890)
addappid(1213891, 1, "cc9728ddddd9b68c56d584c0ba18387b1158a16e52aaf0e8d0ffbfd8aa99680c")
