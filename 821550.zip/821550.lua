-- Lua provided by RyzenAPI
-- Game: The Dreamlands: Aisling's Quest

-- MAIN APPLICATION
addappid(821550)

-- MAIN APP DEPOTS / PACKAGES
addappid(821551,0,"20313c059a29ea9e882fa3201ad29fcca6bc882fde21181540f56fea25fb7fbe")

