-- Lua provided by RyzenAPI
-- Game: Game: Tower of Babel: Survivors of Chaos

-- MAIN APPLICATION
addappid(2665680)
-- Game: addappid(2665680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2665681, 1, "507320342541c2a82b102d5de31fca41214742d1f8b4f3f3add139d5572fb709")
