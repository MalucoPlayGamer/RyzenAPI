-- 2665680's Lua and Manifest Created by Hubcap Manifest
-- Tower of Babel: Survivors of Chaos
-- Created: May 28, 2026 at 02:06:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(2665680, 1, "de31d7496c855b0e87fa991f5c577f1249b1032304c58afb8110d426b96d7a16") -- Tower of Babel: Survivors of Chaos
-- MAIN APP DEPOTS
addappid(2665681, 1, "507320342541c2a82b102d5de31fca41214742d1f8b4f3f3add139d5572fb709") -- Depot 2665681
--setManifestid(2665681, "197286184405294587", 696262897)
addappid(2665682, 1, "cb01e8ee737d8751883bddacd18eab54054e0230f110a29fda8ec14268c0be02") -- Depot 2665682
--setManifestid(2665682, "3178794563955007545", 415620176)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4171170) -- Tower of Babel Survivors of Chaos - Supporter Pack
addappid(4742150) -- Tower of Babel Survivors of Chaos - Golden Dragon Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4171170) -- Depot 4171170 (empty depot)