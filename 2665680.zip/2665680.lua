-- Lua provided by RyzenAPI
-- Game: Tower of Babel: Survivors of Chaos

-- MAIN APPLICATION
addappid(4171170) -- Tower of Babel Survivors of Chaos - Supporter Pack
addappid(4742150) -- Tower of Babel Survivors of Chaos - Golden Dragon Pack
-- addappid(4171170) -- Depot 4171170 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(2665680, 1, "de31d7496c855b0e87fa991f5c577f1249b1032304c58afb8110d426b96d7a16") -- Tower of Babel: Survivors of Chaos
addappid(2665681, 1, "507320342541c2a82b102d5de31fca41214742d1f8b4f3f3add139d5572fb709") -- Depot 2665681
addappid(2665682, 1, "cb01e8ee737d8751883bddacd18eab54054e0230f110a29fda8ec14268c0be02") -- Depot 2665682

