-- Lua provided by RyzenAPI
-- Game: My Singing Monsters Karaoke

-- MAIN APPLICATION
addappid(4633140)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4831810)
addappid(5021110)
