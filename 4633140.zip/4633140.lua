-- Lua provided by RyzenAPI
-- Game: My Singing Monsters Karaoke

-- MAIN APPLICATION
addappid(4633140)
addappid(4831810)
addappid(5021110)

