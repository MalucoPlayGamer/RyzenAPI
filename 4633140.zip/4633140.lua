-- Lua provided by RyzenAPI
-- Game: My Singing Monsters Karaoke

-- MAIN APPLICATION
addappid(4633140)

