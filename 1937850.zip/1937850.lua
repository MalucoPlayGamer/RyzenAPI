-- Lua provided by RyzenAPI
-- Game: Game: Satan's Puzzle 2

-- MAIN APPLICATION
addappid(1937850)
-- Game: addappid(1937850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937851, 1, "2cdee14bdc511e18975afaef9855510e7478b41792bb9829713098971d8eaf95")
