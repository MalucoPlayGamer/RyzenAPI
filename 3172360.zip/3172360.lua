-- Lua provided by RyzenAPI
-- Game: Slitterhead Digital Soundtrack & Artbook

-- MAIN APPLICATION
addappid(3172360)
-- Game: addappid(3172360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172361, 1, "637dec5c0cad3d5a2ae405b72ab265b196b4e50689dead1711315b5c07794a03")
