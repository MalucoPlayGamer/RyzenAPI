-- Lua provided by RyzenAPI
-- Game: 1060230

-- MAIN APPLICATION
addappid(1060230)
-- Game: addappid(1060230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1060231, 1, "f42b9fdda61ea875d9c3be27d29dff037a434b36dab97f7b5d2f53ad3f6e1127")
addappid(1060232, 1, "3a01f22318ca3b19cd4e549dc636c106831a1cfbe97438b4ce9751c7fede5485")
