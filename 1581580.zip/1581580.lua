-- Lua provided by RyzenAPI 
-- Game: The Legend of Bear-Truck Trucker
addappid(1581580)
addappid(1581581, 1, "52dcd9d6953027835343a0c767a9b7bfac88fc4468096f2e404fe37dfe4bdbf5")
