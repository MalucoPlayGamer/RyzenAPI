-- Lua provided by RyzenAPI
-- Game: 2471090

-- MAIN APPLICATION
addappid(2471090)
-- Game: addappid(2471090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471091, 1, "ef41a2f828c3fa1975564e6374c14d480974e30f8c94d2939a11c1d957da3b0b")
