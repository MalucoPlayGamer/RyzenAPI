-- Lua provided by RyzenAPI
-- Game: Game: 镇邪 Zhenxie Playtest

-- MAIN APPLICATION
addappid(2053690)
-- Game: addappid(2053690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2053691, 1, "1aba64691583e8436cd83c21f577c6122a1618c491e525567fe5125d922e7203")
