-- Lua provided by RyzenAPI
-- Game: addappid(3358080)

-- MAIN APPLICATION
addappid(3358080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358080,0,"6146f8b9ef4662268b7ebbe73c86f084c6b391aabecbfdc0c2586cbc59fa0594")
