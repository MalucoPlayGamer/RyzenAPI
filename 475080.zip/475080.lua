-- Lua provided by RyzenAPI
-- Game: Game: AppID 475080

-- MAIN APPLICATION
addappid(475080)
-- Game: addappid(475080)

-- MAIN APP DEPOTS / PACKAGES
addappid(475081, 1, "96c4ccb619c4c745c88e50bb5defafb1c1eed2bbbd6df76988d7df0c3e956602")
