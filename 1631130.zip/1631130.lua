-- Lua provided by RyzenAPI
-- Game: AppID 1631130

-- MAIN APPLICATION
addappid(1631130)
-- Game: addappid(1631130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631131, 1, "b80346d4e8d9e3c715c7262f32c1dae39c582fc1782e3c38ddf17ff3d6a33131")
