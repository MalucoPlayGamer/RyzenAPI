-- Lua provided by SkyAPI 
-- Game: AppID 1631130
addappid(1631130)
addappid(1631131, 1, "b80346d4e8d9e3c715c7262f32c1dae39c582fc1782e3c38ddf17ff3d6a33131")
