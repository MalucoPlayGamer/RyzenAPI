-- Lua provided by RyzenAPI
-- Game: Trash Story Soundtrack

-- MAIN APPLICATION
addappid(875371)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237000,0,"2ca1ee82cff999fd2c7ee660567ab4c0712c49d39a318387099691481f8e7ed1")
