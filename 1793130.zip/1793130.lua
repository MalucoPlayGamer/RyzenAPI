-- Lua provided by RyzenAPI
-- Game: Battle Cry of Freedom Demo

-- MAIN APPLICATION
addappid(1793130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1793131, 1, "18300f32c2ad42248847cd6a9afd783605f77637d71ffda4da8cfae61e6968af")

