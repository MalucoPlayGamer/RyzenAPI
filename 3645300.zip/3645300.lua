-- Lua provided by RyzenAPI
-- Game: Desktop Fisher

-- MAIN APPLICATION
addappid(3645300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3645301, 1, "6826dfc4609f28ead6ce435304e5c0f9eab1f86aaa8750bcd3246b4cf8cfbf2e")
