-- Lua provided by RyzenAPI
-- Game: 3040550

-- MAIN APPLICATION
addappid(3040550)
-- Game: addappid(3040550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3040550,0,"dd8c2eb93a2af8a6460a19012bbe414f38f6fc8537de2f547b0cbdd43cbd974c")
