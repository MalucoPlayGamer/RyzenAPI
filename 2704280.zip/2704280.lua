-- Lua provided by RyzenAPI
-- Game: Game: Fractured Horizon

-- MAIN APPLICATION
addappid(2704280)
-- Game: addappid(2704280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2704281, 1, "428b6031d85b907aa0d11e4324940d8cd739252b992fc7d160eea580a149d306")
