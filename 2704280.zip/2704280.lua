-- Lua provided by RyzenAPI
-- Game: Fractured Horizon

-- MAIN APPLICATION
addappid(2704280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2704281, 1, "428b6031d85b907aa0d11e4324940d8cd739252b992fc7d160eea580a149d306")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
