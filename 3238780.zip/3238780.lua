-- Lua provided by RyzenAPI
-- Game: Game: The Red Hood: Hunting the Wolf

-- MAIN APPLICATION
addappid(3238780)
-- Game: addappid(3238780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3238781, 1, "e06961cff26a531c58547e1db5b46952f6899218579cc47a397060122d85ee6f")
