-- Lua provided by RyzenAPI
-- Game: addappid(928410)

-- MAIN APPLICATION
addappid(928410)

-- MAIN APP DEPOTS / PACKAGES
addappid(928411, 1, "d0fe9dbdefd31ea973bb1d477a4b13f4c80ca24751291028147e67fbcda998a9")
