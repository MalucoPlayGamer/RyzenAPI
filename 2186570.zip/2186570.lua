-- Lua provided by SkyAPI 
-- Game: TELEFORUM
addappid(2186570)
addappid(2186571, 1, "0ce7f4b462c6a8f7e1c0d707230e4655fe286eca8f40c4fc6e14a897bb378ea6")
addappid(2186572, 1, "9a912477250e30616446be3dcf97691505b93de62f9bc8622bd5bb458e644797")
