-- Lua provided by RyzenAPI
-- Game: FUEL - Demo

-- MAIN APPLICATION
addappid(12850)

-- MAIN APP DEPOTS / PACKAGES
addappid(12851, 1, "ee93f26397d2d92931d58e061c885a558d4534bb2644da4e6c181ebfd63647f6")
