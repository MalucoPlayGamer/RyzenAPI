-- Lua provided by SkyAPI 
-- Game: Adapta Solva Legacy
addappid(2752680)
addappid(2752681, 1, "ae11601c5499b9dc72631b80150913ef137057d95c1f1cd04449753c0b56a549")
