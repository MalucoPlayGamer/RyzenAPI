-- Lua provided by RyzenAPI
-- Game: addappid(635390)

-- MAIN APPLICATION
addappid(635390)

-- MAIN APP DEPOTS / PACKAGES
addappid(635391, 1, "8195f2f5dada9a65d3bddc358e63ffaf64654c0bfebfee76ad00fcf9c770f49d")
