-- Lua provided by RyzenAPI
-- Game: Game: 天仙变

-- MAIN APPLICATION
addappid(1424890)
-- Game: addappid(1424890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424891, 1, "a6a8fb63209b8bf7f6dab07bc063c159410b4962070719247e75fe7641c7f684")
