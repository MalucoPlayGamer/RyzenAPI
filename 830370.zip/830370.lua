-- Lua provided by RyzenAPI
-- Game: Game: Monster Crown

-- MAIN APPLICATION
addappid(830370)
-- Game: addappid(830370)

-- MAIN APP DEPOTS / PACKAGES
addappid(830371, 1, "1e0aebf0b8761fe184a13688031f180573c4e4c753c7f562841931d0be598859")
addappid(830373, 1, "bab1da362062f6ff8efe27979f4ed7cecb5954a8c5dd24adde07a51f35a97204")
addappid(830374, 1, "ae661dbdf552db54063a411e7b7a26a03b6454010f62633e174465cc4d62d641")
