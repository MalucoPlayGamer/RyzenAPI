-- Lua provided by RyzenAPI
-- Game: Only Up !

-- MAIN APPLICATION
addappid(2842590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2842591, 1, "e469650c8f4d077de08e2a218951bbcb3fc2f6f7c727bb4ab684816c214905ee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
