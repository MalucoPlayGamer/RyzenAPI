-- Lua provided by RyzenAPI
-- Game: Only Up !

-- MAIN APPLICATION
addappid(2842590)
-- Game: addappid(2842590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2842591, 1, "e469650c8f4d077de08e2a218951bbcb3fc2f6f7c727bb4ab684816c214905ee")
