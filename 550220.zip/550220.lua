-- Lua provided by RyzenAPI
-- Game: Game: Charm Tale Quest

-- MAIN APPLICATION
addappid(550220)
-- Game: addappid(550220)

-- MAIN APP DEPOTS / PACKAGES
addappid(550221, 1, "98ddf0b06fdc499bea657b5d5c5f2d68f0c81622f7dc1b383ae27edf7948a3a7")
