-- Lua provided by RyzenAPI
-- Game: addappid(375790)

-- MAIN APPLICATION
addappid(375790)

-- MAIN APP DEPOTS / PACKAGES
addappid(375791, 1, "5cde40fa699cefb92037917a4c41f0e82d80b4c7d7a7e21e23128a131c99cf2d")
addappid(375792, 1, "21d067666a67a3dffbe38df8cbd91fdcf05d225784270c449ed33dff703e3bf3")
addappid(375793, 1, "b602cac446af59284619c7be93f5f61ec0c66873e1f7c59ab200fa1170a5bce7")
