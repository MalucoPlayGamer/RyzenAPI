-- Lua provided by RyzenAPI
-- Game: Game: Moth Lake: A Horror Story

-- MAIN APPLICATION
addappid(2077720)
-- Game: addappid(2077720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2077721, 1, "d7dc9f8fad1b3e71d5697628154aebc13e5c172076d58d35ab645bfaf6c20505")
