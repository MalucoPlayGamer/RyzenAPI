-- Lua provided by RyzenAPI
-- Game: 3165300

-- MAIN APPLICATION
addappid(3165300)
-- Game: addappid(3165300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3165301, 1, "4f507f6b9d38a1027518c41f93326aa40b5692fea6407cee5d0a0cdbc91ddef2")
