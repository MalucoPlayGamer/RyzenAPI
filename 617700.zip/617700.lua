-- Lua provided by RyzenAPI
-- Game: Weed Shop 2

-- MAIN APPLICATION
addappid(617700)
addappid(617703)

-- MAIN APP DEPOTS / PACKAGES
addappid(617702,0,"478b66c126da3b3c32f40984207e985fc33fa2f03396dc35854816b5f5026f57")
