-- Lua provided by RyzenAPI
-- Game: Treasure Hunter Simulator

-- MAIN APPLICATION
addappid(748300)

-- MAIN APP DEPOTS / PACKAGES
addappid(748301, 1, "90352224c6d5edcc5409e0a231e25fc9580f818427c682d1d2fabd67c9b4d43b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
