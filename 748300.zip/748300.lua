-- Lua provided by RyzenAPI 
-- Game: Treasure Hunter Simulator
addappid(748300)
addappid(748301, 1, "90352224c6d5edcc5409e0a231e25fc9580f818427c682d1d2fabd67c9b4d43b")
