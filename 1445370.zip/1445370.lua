-- Lua provided by RyzenAPI 
-- Game: Imposters: Countdown
addappid(1445370)
addappid(1445371, 1, "7a5438e6c69eb1dad2da7f45edde7b31a169a3e5c385e7f5a3a64ac4adfc2420")
