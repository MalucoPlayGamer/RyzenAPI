-- Lua provided by RyzenAPI
-- Game: Imposters: Countdown

-- MAIN APPLICATION
addappid(1445370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1445371, 1, "7a5438e6c69eb1dad2da7f45edde7b31a169a3e5c385e7f5a3a64ac4adfc2420")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
