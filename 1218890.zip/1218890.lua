-- Lua provided by RyzenAPI
-- Game: Ollie & Bollie: Outdoor Estate

-- MAIN APPLICATION
addappid(1218890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218891, 1, "b1dcdc00e53bd05e50ce1e740ea18d7548b28af0ffffa67c6715dc635e63afe6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
