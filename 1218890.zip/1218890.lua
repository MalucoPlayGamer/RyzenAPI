-- Lua provided by RyzenAPI
-- Game: 1218890

-- MAIN APPLICATION
addappid(1218890)
-- Game: addappid(1218890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218891, 1, "b1dcdc00e53bd05e50ce1e740ea18d7548b28af0ffffa67c6715dc635e63afe6")
