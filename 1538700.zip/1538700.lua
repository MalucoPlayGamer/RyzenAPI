-- Lua provided by RyzenAPI
-- Game: Escape Simulator Demo

-- MAIN APPLICATION
addappid(1538700)
-- Game: addappid(1538700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1538701, 1, "733beb73c9460a3e5cd7e6235c52f61fdc158bc07e2c1e29f43d815356579170")
