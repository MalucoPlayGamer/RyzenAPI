-- Lua provided by RyzenAPI
-- Game: 1801470

-- MAIN APPLICATION
addappid(1801470)
-- Game: addappid(1801470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1801471, 1, "3d5ddcf9c2eba14b1f1c890cd1c4a5c445d35e6b6eda74c7eb7f67140e880c1b")
addappid(1813510, 0, "a08368b568b4d67abb143610c8611ffc242610c90a91cc055639ec8b76c4ee6d")
