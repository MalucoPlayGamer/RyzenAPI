-- Lua provided by RyzenAPI
-- Game: AppID 460970

-- MAIN APPLICATION
addappid(460970)

-- MAIN APP DEPOTS / PACKAGES
addappid(460971, 1, "7b6762e47661360687e682203d6c2aebfcb31a218089c9017a2715f32af04cc4")
addappid(460972, 1, "3033d633f99a439e4d03ad78185532726cba0a49e5af8669ca91dbc0096fad24")
addappid(460973, 1, "1983da58efc96fdf643f9f7a3c140c9973bae59895f1312f906b5ebc48b41aa1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
