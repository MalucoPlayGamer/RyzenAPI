-- Lua provided by RyzenAPI
-- Game: 867800

-- MAIN APPLICATION
addappid(867800)
addappid(869430)
-- Game: addappid(867800)

-- MAIN APP DEPOTS / PACKAGES
addappid(867801, 1, "ea8f0506afb8fbdd3d155e7caa802d85cfe68fcd49de676dc5cff18f45062696")
