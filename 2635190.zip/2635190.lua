-- Lua provided by RyzenAPI
-- Game: Who Wants To Be A Millionaire? - US Movies 90s DLC Pack

-- MAIN APPLICATION
addappid(2635190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635190,0,"e79035b404f0909a6d56f0cd464a72815048c9e492838c0ce571cb3c3963da6a")

