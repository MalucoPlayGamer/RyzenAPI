-- Lua provided by RyzenAPI
-- Game: addappid(1053920)

-- MAIN APPLICATION
addappid(1053920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1053921, 1, "dfb03ecae38c5699ed113ff3af2361594810f1d35ed1299a0e352c848b53f5bb")
