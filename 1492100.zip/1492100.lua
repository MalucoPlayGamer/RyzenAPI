-- 1492100's Lua and Manifest Created by Hubcap Manifest
-- Fantasy Network
-- Created: August 08, 2026 at 06:16:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1492100) -- Fantasy Network
-- MAIN APP DEPOTS
addappid(1492101, 1, "ccbbcae1c12ebd54a4f76c3eb8c8eb2b68a4801c38c6957d1881d8e4a5d7a6b0") -- Depot 1492101
setManifestid(1492101, "2398107647940177280", 3108261810)