-- Lua provided by RyzenAPI
-- Game: Fantasy Network

-- MAIN APPLICATION
addappid(1492100) -- Fantasy Network

-- MAIN APP DEPOTS / PACKAGES
addappid(1492101, 1, "ccbbcae1c12ebd54a4f76c3eb8c8eb2b68a4801c38c6957d1881d8e4a5d7a6b0") -- Depot 1492101

