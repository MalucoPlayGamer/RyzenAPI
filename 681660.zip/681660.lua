-- Lua provided by RyzenAPI
-- Game: Bless Online

-- MAIN APPLICATION
addappid(681660)
addappid(811170)
addappid(811210)
addappid(838460)
addappid(839150)
addappid(839650)
addappid(855170)
addappid(956630)
addappid(956640)
addappid(956650)
addappid(980290)
addappid(980291)
addappid(1007420)
addappid(1007421)
addappid(1017390)
addappid(1017391)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(681661, 1, "026b0a053772482cfccbbfee93ff71db88a97cb895732376cb4268e38461867f")
