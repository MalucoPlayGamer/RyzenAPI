-- Lua provided by RyzenAPI
-- Game: Game: AppID 681660

-- MAIN APPLICATION
addappid(681660)
addappid(838460)
addappid(839150)
addappid(839650)
-- Game: addappid(681660)

-- MAIN APP DEPOTS / PACKAGES
addappid(681661, 1, "026b0a053772482cfccbbfee93ff71db88a97cb895732376cb4268e38461867f")
