-- Lua provided by RyzenAPI
-- Game: 2992930

-- MAIN APPLICATION
addappid(2992930)
-- Game: addappid(2992930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2992931, 1, "0c2e5fd970fc43f108a06350d458a744621d919bab7911bcdd7d313b6f931536")
