-- Lua provided by RyzenAPI 
-- Game: AppID 2992930
addappid(2992930)
addappid(2992931, 1, "0c2e5fd970fc43f108a06350d458a744621d919bab7911bcdd7d313b6f931536")
