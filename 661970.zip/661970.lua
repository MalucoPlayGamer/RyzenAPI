-- Lua provided by RyzenAPI
-- Game: Game: SPACE BATTLE: Humanity

-- MAIN APPLICATION
addappid(661970)
-- Game: addappid(661970)

-- MAIN APP DEPOTS / PACKAGES
addappid(661971, 1, "52d9d992768c4fe80217ab20e1822cfab993deff9cbe20874597f22136efbb0d")
