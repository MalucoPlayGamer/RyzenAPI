-- Lua provided by RyzenAPI
-- Game: Game: AppID 2720970

-- MAIN APPLICATION
addappid(2720970)
-- Game: addappid(2720970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2720971, 1, "a6154140e043399387c1bd54e985eb2e476fd24a5c0c2a4d2c7ab71979df7e25")
