-- Lua provided by RyzenAPI 
-- Game: Reptilian Rebellion
addappid(461760)
addappid(461761, 1, "977431d3466b6c7fa490a60cab0a24b62b8393abeb9ed32aced1a096d8a7358d")
addappid(461762, 1, "82c3ed969c69cb83062d10377f0b56199e5f2310be13580bb813d8ce7ab8db03")
addappid(461763, 1, "8e2e673962318be76013d3cea1ce9cd89b36cdcf37ea23da03ecc5c5df076203")
