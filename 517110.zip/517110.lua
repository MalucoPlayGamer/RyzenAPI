-- Lua provided by RyzenAPI
-- Game: 517110

-- MAIN APPLICATION
addappid(517110)
addappid(517111)
addappid(517112)
addappid(517113)
addappid(517115)

-- MAIN APP DEPOTS / PACKAGES
addappid(517114,0,"260e80fee3f3adfefa6c768c1e54d2cf6a11de3371eddcbe1c0f9024b0c23759")

