-- Lua provided by RyzenAPI
-- Game: SAMURAI SHODOWN V SPECIAL / サムライスピリッツ零スペシャル

-- MAIN APPLICATION
addappid(1076550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076551, 1, "69e24713503fe3d03afe1b87f536aa23da82f0e242e4b2a4f134b289251517aa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
