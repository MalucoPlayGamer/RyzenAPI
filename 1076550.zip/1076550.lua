-- Lua provided by RyzenAPI
-- Game: Game: SAMURAI SHODOWN V SPECIAL / サムライスピリッツ零スペシャル

-- MAIN APPLICATION
addappid(1076550)
-- Game: addappid(1076550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076551, 1, "69e24713503fe3d03afe1b87f536aa23da82f0e242e4b2a4f134b289251517aa")
