-- Lua provided by RyzenAPI
-- Game: 2770350

-- MAIN APPLICATION
addappid(2770350)
-- Game: addappid(2770350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2770351, 1, "1723e5d29b31a2eeb6520cb7e8b3ff6859d56553f9210ef56eacc87397cb3b6a")
