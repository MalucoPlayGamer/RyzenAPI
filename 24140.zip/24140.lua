-- Lua provided by SkyAPI 
-- Game: AppID 24140
addappid(24140)
addappid(24141, 1, "eb45bb679834da0ccae5e9c7f689f7cc4b3e2e122773806e2548d7a09099a866")
