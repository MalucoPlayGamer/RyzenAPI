-- Lua provided by RyzenAPI
-- Game: All Guns On Deck

-- MAIN APPLICATION
addappid(315330)
addappid(407540)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(315331, 1, "0cf94db774c4d60768cedd3093690d3e604b05d2ed602333d22db83ed73c7e11")
