-- Lua provided by SkyAPI 
-- Game: AppID 315330
addappid(315330)
addappid(315331, 1, "0cf94db774c4d60768cedd3093690d3e604b05d2ed602333d22db83ed73c7e11")
addappid(407540)
