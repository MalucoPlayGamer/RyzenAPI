-- Lua provided by RyzenAPI
-- Game: Game: AppID 315330

-- MAIN APPLICATION
addappid(315330)
addappid(407540)
-- Game: addappid(315330)

-- MAIN APP DEPOTS / PACKAGES
addappid(315331, 1, "0cf94db774c4d60768cedd3093690d3e604b05d2ed602333d22db83ed73c7e11")
