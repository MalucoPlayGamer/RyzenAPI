-- 4670130's Lua and Manifest Created by Hubcap Manifest
-- Asymptote
-- Created: July 30, 2026 at 00:33:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4670130) -- Asymptote
-- MAIN APP DEPOTS
addappid(4670132, 1, "bb731878878bd095a6645e6b30341dc9c7c13cad2601ae4b19614b50471e9131") -- Depot 4670132
setManifestid(4670132, "1734621423021278787", 217704163)
addappid(4670133, 1, "0c9af50f6567eb177cc0de8d6894018891e56ff163e7f1b86dc9770a847b118d") -- Depot 4670133
setManifestid(4670133, "7577196724713038267", 235229149)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4670131) -- Depot 4670131 (empty depot)