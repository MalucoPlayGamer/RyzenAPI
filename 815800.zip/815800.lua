-- Lua provided by RyzenAPI
-- Game: 815800

-- MAIN APPLICATION
addappid(815800)
-- Game: addappid(815800)

-- MAIN APP DEPOTS / PACKAGES
addappid(815801, 1, "260358bb00365b19a031745d9d528f04193f263220ad25cb4e1363b8bf4e5bb9")
