-- Lua provided by RyzenAPI
-- Game: Infecto

-- MAIN APPLICATION
addappid(815800)

-- MAIN APP DEPOTS / PACKAGES
addappid(815801, 1, "260358bb00365b19a031745d9d528f04193f263220ad25cb4e1363b8bf4e5bb9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
