-- Lua provided by RyzenAPI
-- Game: Polychromatic

-- MAIN APPLICATION
addappid(384590)

-- MAIN APP DEPOTS / PACKAGES
addappid(384591, 1, "b12442b9fc4eb79ca6ff376e1fba52a945b0d75d571c173f4a44aa74abf2d128")
addappid(384592, 1, "db631f297a2269814773a1ff29c77504588f459aac997d211e94522bb8b395a4")
addappid(384594, 1, "f6c88452d5d4149995a0bf7217909800209031e0e6a1db0dd8c1a2bde36737cd")
addappid(384595, 1, "3b1eb586d0348fb2eda89acde7b14236846959dcd8acf490f5db9d0e84781afb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
