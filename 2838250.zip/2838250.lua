-- Lua provided by RyzenAPI
-- Game: Beat Saber - Daft Punk - "Da Funk / Daftendirekt"

-- MAIN APPLICATION
addappid(2838250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838250,0,"dec5328d26c0ad79781b17b2c5e75dd887d76ddc3d6947aa040b2215aae49d4e")
