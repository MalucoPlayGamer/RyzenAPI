-- Lua provided by RyzenAPI
-- Game: Dune: Imperium

-- MAIN APPLICATION
addappid(1689500)
addappid(3051590)
addappid(3595530)
addappid(4598200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689501, 1, "3e373de600fd15359e36cc7c92050dce9e8395fc94d981e27f4d8ad79f168737")

