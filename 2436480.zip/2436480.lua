-- Lua provided by RyzenAPI
-- Game: addappid(2436480)

-- MAIN APPLICATION
addappid(2436480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2436481, 1, "aea54bea7bbd3ffd4b3c008f683cc8c1a2adbf5c55e29c0a5a40984e2c209894")
