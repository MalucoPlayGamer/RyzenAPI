-- Lua provided by RyzenAPI
-- Game: Pirate Island

-- MAIN APPLICATION
addappid(1552400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1552401, 1, "766d8b533eb16d65ade3c8ecafe1c8f60e139f72400dcce7635d4590c9b55c6a")

