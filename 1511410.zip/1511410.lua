-- Lua provided by RyzenAPI
-- Game: Grass Cutters Academy - Idle Game

-- MAIN APPLICATION
addappid(1511410)
addappid(1521240)
addappid(1521241)
addappid(1521242)
addappid(1521243)
addappid(1521244)
addappid(1521245)
addappid(1521246)
addappid(1521247)
addappid(1570770)
addappid(1570771)
addappid(1570772)
addappid(1578120)
addappid(1578121)
addappid(1578122)
addappid(1578123)
addappid(1578124)
addappid(1578125)
addappid(1578126)
addappid(1578127)
addappid(1578128)
addappid(1578129)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511411, 1, "1d1fb2e5b883a027da646654d00a6d456167787e1d5e55fa10797fc3d7083746")

