-- Lua provided by RyzenAPI
-- Game: Grass Cutters Academy - Idle Game

-- MAIN APPLICATION
addappid(1511410)
-- Game: addappid(1511410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511411, 1, "1d1fb2e5b883a027da646654d00a6d456167787e1d5e55fa10797fc3d7083746")
