-- Lua provided by SkyAPI 
-- Game: WizardChess
addappid(1274210)
addappid(1274211, 1, "8af808712f98089065629509b02dcee804571e6b5d94c0c5d9b24febc6f57ed1")
