-- Lua provided by RyzenAPI
-- Game: addappid(1274210)

-- MAIN APPLICATION
addappid(1274210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274211, 1, "8af808712f98089065629509b02dcee804571e6b5d94c0c5d9b24febc6f57ed1")
