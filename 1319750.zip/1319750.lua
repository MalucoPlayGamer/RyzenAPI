-- Lua provided by RyzenAPI
-- Game: Game: Monster Train Soundtrack

-- MAIN APPLICATION
addappid(1319750)
-- Game: addappid(1319750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1319751, 1, "cfa99b66745e3c29050bbea8c460eab979aa6ce38164c81c88f22d31e91a615f")
addappid(1319752, 1, "9f35bc4a1cf4882c284644616c72be07878be69341b42ad50d9cbd416bc44254")
