-- Lua provided by RyzenAPI
-- Game: Run!ZombieFood!

-- MAIN APPLICATION
addappid(671800)

-- MAIN APP DEPOTS / PACKAGES
addappid(671801, 1, "2f63f62ce7b7943a053a599ea8c0e6eabe0faa7ee89dd0e46e1b3d5db038a1a9")

