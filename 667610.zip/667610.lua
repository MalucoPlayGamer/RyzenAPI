-- Lua provided by RyzenAPI
-- Game: Game: Ancient Cities

-- MAIN APPLICATION
addappid(667610)
-- Game: addappid(667610)

-- MAIN APP DEPOTS / PACKAGES
addappid(667611, 1, "fd2dde360768a68e4e347fb8042dca6a1a6ea926afa87305d1b8355cc5dfcc85")
