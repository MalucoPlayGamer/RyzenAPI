-- Lua provided by RyzenAPI
-- Game: 1557480

-- MAIN APPLICATION
addappid(1557480)
-- Game: addappid(1557480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557481, 1, "1f206f59bb6c792bf66934e1e3809d847f6a31def89adc4d208e0f53ac830164")
