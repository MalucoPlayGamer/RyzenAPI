-- Lua provided by RyzenAPI
-- Game: Project MIKHAIL: A Muv-Luv War Story

-- MAIN APPLICATION
addappid(1557480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557481, 1, "1f206f59bb6c792bf66934e1e3809d847f6a31def89adc4d208e0f53ac830164")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
