-- Lua provided by SkyAPI 
-- Game: AppID 2386070
addappid(2386070)
addappid(2386071, 1, "62cf331b4e0a9219ccc4bb3391eafcc5ad7212b6965b839cb6cd5069b26d3682")
