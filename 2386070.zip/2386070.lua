-- Lua provided by RyzenAPI
-- Game: 反弹枪 Rebound Gun

-- MAIN APPLICATION
addappid(2386070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2386071, 1, "62cf331b4e0a9219ccc4bb3391eafcc5ad7212b6965b839cb6cd5069b26d3682")

