-- Lua provided by RyzenAPI
-- Game: AppID 2386070

-- MAIN APPLICATION
addappid(2386070)
-- Game: addappid(2386070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386071, 1, "62cf331b4e0a9219ccc4bb3391eafcc5ad7212b6965b839cb6cd5069b26d3682")
