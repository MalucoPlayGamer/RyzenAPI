-- Lua provided by RyzenAPI
-- Game: Boost

-- MAIN APPLICATION
addappid(577370)

-- MAIN APP DEPOTS / PACKAGES
addappid(577371,0,"fabb7a440f586cd76ac74d15b9036dbcf3d7a7e05ed7d49cc4e86727cb83c6a1")

