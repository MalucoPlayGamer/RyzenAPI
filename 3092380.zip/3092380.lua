-- Lua provided by RyzenAPI
-- Game: Game: AppID 3092380

-- MAIN APPLICATION
addappid(3092380)
-- Game: addappid(3092380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3092381, 1, "a386fca073cc8dc19cba73977e44d36e6fc50ae1cca5ee8606f4f7db2bbfc3b7")
