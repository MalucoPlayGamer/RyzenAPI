-- 3902800's Lua and Manifest Created by Hubcap Manifest
-- [HERROR] Gas Station Case
-- Created: August 12, 2026 at 00:04:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3902800) -- [HERROR] Gas Station Case
-- MAIN APP DEPOTS
addappid(3902801, 1, "80260118ae6c7cdeb857cf3c377fc3b861545d65df8457a9045d8b40030c6143") -- Depot 3902801
setManifestid(3902801, "7037701948857006012", 6611008757)
-- DLCS WITH DEDICATED DEPOTS
-- [HERROR] Gas Station Case - Supporter Pack (AppID: 4916070)
addappid(4916070)
addappid(4916070, 1, "bd576dac0099dbb269eb5744ffcd2962de80be4e6b50f70b57c102dd28dafe85") -- [HERROR] Gas Station Case - Supporter Pack - Depot 4916070
setManifestid(4916070, "4023098486124453938", 185203044)