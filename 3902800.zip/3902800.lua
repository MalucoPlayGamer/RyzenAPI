-- Lua provided by RyzenAPI
-- Game: Created: August 12, 2026 at 00:04:14 EDT

-- MAIN APPLICATION
addappid(3902800) -- [HERROR] Gas Station Case
addappid(4916070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3902801, 1, "80260118ae6c7cdeb857cf3c377fc3b861545d65df8457a9045d8b40030c6143") -- Depot 3902801
addappid(4916070, 1, "bd576dac0099dbb269eb5744ffcd2962de80be4e6b50f70b57c102dd28dafe85") -- [HERROR] Gas Station Case - Supporter Pack - Depot 4916070

