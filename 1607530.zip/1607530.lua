-- Lua provided by RyzenAPI
-- Game: Treasures of the Aegean

-- MAIN APPLICATION
addappid(1607530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607531, 1, "06befcc0bdb679407f7a511e06b002d57e5e65f5c4ec8535456c06760d1a9026")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1811770)
