-- Lua provided by RyzenAPI
-- Game: "I Know This Place..?"  chapter I (prologue)

-- MAIN APPLICATION
addappid(2243560)
addappid(2662610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2243561, 1, "ac99ffa4edf83bd22a11940365f2afeb905c1762daca335a15c184f360026bc7")

