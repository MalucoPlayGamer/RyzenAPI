-- Lua provided by RyzenAPI
-- Game: Golfing Over It with Alva Majo

-- MAIN APPLICATION
addappid(817510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(817511, 1, "7c4a9c962da81133091bdc3ccd85cc1f2f4bf57878608b321854f5abf25c9596")
addappid(817512, 1, "fca3888a6fc2aea4873b71580e5f413f6d517f51683cd43e9495963202921c75")
addappid(817513, 1, "bdd50a5cb3c2bee54f6a82787e85f83abf60785b15e7b98528bca6a086ab6069")
addappid(817514, 1, "1259a7743d30abb5672192c30b33fcc9ce3f73ae47bc1ff3184e1c40619a2647")
