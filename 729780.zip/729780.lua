-- Lua provided by RyzenAPI
-- Game: Timeless: The Lost Castle

-- MAIN APPLICATION
addappid(729780)

-- MAIN APP DEPOTS / PACKAGES
addappid(729781,0,"5ff021093417e1d01421c5035047809b105c5e726a82bfcc4e817c3abad41d26")

