-- Lua provided by RyzenAPI
-- Game: Trivia Vault: Music Trivia

-- MAIN APPLICATION
addappid(878270)

-- MAIN APP DEPOTS / PACKAGES
addappid(878271, 1, "d714bfef2021dd6c9a84f80b3713745153cbb855a05cf4a83eddb4bed6de5c08")

