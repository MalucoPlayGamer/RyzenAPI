-- Lua provided by SkyAPI 
-- Game: Trivia Vault: Music Trivia
addappid(878270)
addappid(878271, 1, "d714bfef2021dd6c9a84f80b3713745153cbb855a05cf4a83eddb4bed6de5c08")
