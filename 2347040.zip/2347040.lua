-- Lua provided by RyzenAPI
-- Game: Game: RC Revolution

-- MAIN APPLICATION
addappid(2347040)
-- Game: addappid(2347040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2347041, 1, "87fb793604b28d854b5e3f347a9a52aee78cf0dd3c5464e56640772005c861f2")
