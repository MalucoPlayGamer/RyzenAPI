-- Lua provided by SkyAPI 
-- Game: Treasure Hunter Man 2
addappid(870140)
addappid(870141, 1, "0cb3f169198e22040c38c9ccce1a0c220f9bd92c829f243e9923b0e4d36a7f5c")
