-- Lua provided by RyzenAPI
-- Game: Treasure Hunter Man 2

-- MAIN APPLICATION
addappid(870140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(870141, 1, "0cb3f169198e22040c38c9ccce1a0c220f9bd92c829f243e9923b0e4d36a7f5c")

