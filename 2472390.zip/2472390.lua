-- Lua provided by RyzenAPI
-- Game: Game: A Technician's Nightmare

-- MAIN APPLICATION
addappid(2472390)
-- Game: addappid(2472390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2472391, 1, "d1337770fd7a3b77dd3719b30756fc54ac2a8f553219c02f8580225719b7a750")
