-- Lua provided by RyzenAPI
-- Game: A Technician's Nightmare

-- MAIN APPLICATION
addappid(2472390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2472391, 1, "d1337770fd7a3b77dd3719b30756fc54ac2a8f553219c02f8580225719b7a750")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
