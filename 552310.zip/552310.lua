-- Lua provided by RyzenAPI
-- Game: Anguished

-- MAIN APPLICATION
addappid(552310)

-- MAIN APP DEPOTS / PACKAGES
addappid(552311,0,"631d9cb1b42d2c5b53428765e8249b35c279b85a1ad92097bd194d61d6955fb2")

