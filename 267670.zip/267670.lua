-- Lua provided by RyzenAPI
-- Game: Realms of Arkania 1 - Blade of Destiny Classic

-- MAIN APPLICATION
addappid(267670)
-- Game: addappid(267670)

-- MAIN APP DEPOTS / PACKAGES
addappid(267671, 1, "4d657ffa5e35958d691263bfbef102d0a05aed2ee48baa9bf050f0bf348df4ab")
addappid(267672, 1, "32d27670b8e715ab59b073332c4d2b6ae1feedda89f511d3765fd1669db94429")
addappid(267673, 1, "cb29a1216cf4a53551bb1da752315d8ddbf165bba7721bfa44f14309074d0a2a")
addappid(267674, 1, "12332031e521ea2b03342ece5699ec28be69ab350b7b4084ac157c4aded80d09")
addappid(267675, 1, "b1f57377e9a7a5d16b777d0e894b7dd25f80bae9b9b27799a448d3374ea42aa9")
addappid(267676, 1, "7a322e9f627c7ff06bad455fbeae259a404911ac51b2d88a2aeb9e45f5dcc5ab")
addappid(267677, 1, "f6323a196af39cba3e4ae8745f7c99d917713e6d3290adc1bd831eaf96cf81c7")
