-- Lua provided by RyzenAPI
-- Game: Paralax Vr Aim Trainer

-- MAIN APPLICATION
addappid(1370470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370471, 1, "5253a65e76cd3f98c912a290153565789874e234939480668eabaf21f43164fc")
