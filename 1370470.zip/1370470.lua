-- Lua provided by RyzenAPI
-- Game: Paralax Vr Aim Trainer

-- MAIN APPLICATION
addappid(1370470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1370471, 1, "5253a65e76cd3f98c912a290153565789874e234939480668eabaf21f43164fc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
