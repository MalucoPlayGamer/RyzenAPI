-- Lua provided by RyzenAPI
-- Game: Malum

-- MAIN APPLICATION
addappid(1648610)
-- Game: addappid(1648610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1648611, 1, "7f7ce5b1729b56a1849ba2c987ceac4185fe23c64ff9b0fa3152678d5d274bc6")
