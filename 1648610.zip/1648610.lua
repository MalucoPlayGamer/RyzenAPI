-- Lua provided by SkyAPI 
-- Game: Malum
addappid(1648610)
addappid(1648611, 1, "7f7ce5b1729b56a1849ba2c987ceac4185fe23c64ff9b0fa3152678d5d274bc6")
