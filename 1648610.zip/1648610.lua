-- Lua provided by RyzenAPI
-- Game: Malum

-- MAIN APPLICATION
addappid(1648610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1648611, 1, "7f7ce5b1729b56a1849ba2c987ceac4185fe23c64ff9b0fa3152678d5d274bc6")

