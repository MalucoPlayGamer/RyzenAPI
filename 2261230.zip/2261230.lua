-- Lua provided by RyzenAPI
-- Game: iVRy for SteamVR (Pico App Installer)

-- MAIN APPLICATION
addappid(2261230)
-- Game: addappid(2261230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2261232,0,"09f502c6060ead92b12dd00d48233919dc5688b0f05b702531ea40e1ba478ca2")
