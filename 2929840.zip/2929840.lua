-- Lua provided by RyzenAPI
-- Game: Dreams and bubbles

-- MAIN APPLICATION
addappid(2929840)
-- Game: addappid(2929840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2929841, 1, "2b4fb3fa02fa973a64c2439d4d49b0957f70db800d3dcd923f94e4a3a0963f6c")
