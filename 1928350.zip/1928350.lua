-- Lua provided by RyzenAPI
-- Game: Davey

-- MAIN APPLICATION
addappid(1928350)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1928351, 1, "6ef658e4282942f630d0f57d6a2bd7b58cb87ddce923880f6aa406ea98bda14c")

