-- Lua provided by RyzenAPI
-- Game: addappid(3001330)

-- MAIN APPLICATION
addappid(3001330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3001331, 1, "8f6bb53ae79817fe5609ad0e7eefd94ad6e3844c4a4819607350f6845ba2e24a")
