-- Lua provided by RyzenAPI
-- Game: Game: Intergalactic Pawn Shop: Prologue

-- MAIN APPLICATION
addappid(2747240)
-- Game: addappid(2747240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747241, 1, "fb36d300c2954098282cb1bfdf7b615564c9d4387b4d88c8d63c6557dcce8613")
