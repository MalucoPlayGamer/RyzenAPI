-- Lua provided by RyzenAPI
-- Game: Game: Valkyrie Squad Siege Breakers Soundtrack

-- MAIN APPLICATION
addappid(3308680)
-- Game: addappid(3308680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3308681, 1, "6c05ee16c390a5b6a14b3f9464e748b53ce8f80258b639b94e830126344f317f")
