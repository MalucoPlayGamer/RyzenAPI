-- Lua provided by SkyAPI 
-- Game: AppID 982800
addappid(982800)
addappid(982801, 1, "40848b871d093e2809d4324697a9757c846b265ec73fbb1764901208234bf8bf")
