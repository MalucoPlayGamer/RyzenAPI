-- Lua provided by RyzenAPI
-- Game: AppID 982800

-- MAIN APPLICATION
addappid(982800)

-- MAIN APP DEPOTS / PACKAGES
addappid(982801, 1, "40848b871d093e2809d4324697a9757c846b265ec73fbb1764901208234bf8bf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
