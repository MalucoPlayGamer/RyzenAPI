-- Lua provided by RyzenAPI
-- Game: The Valley of Super Flowers

-- MAIN APPLICATION
addappid(1257270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1257271, 1, "67e231616f2dddcc8ac6c6b8b8b56d098e6c9f5980b9d140400add4052e20504")
addappid(1257272, 1, "b85a3cff0ba25e17f12cb8e3323807c2b689a8a3dfaab0fbb7c78c86f7ff9cb0")
