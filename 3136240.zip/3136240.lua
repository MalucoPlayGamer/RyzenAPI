-- Lua provided by RyzenAPI
-- Game: AppID 3136240

-- MAIN APPLICATION
addappid(3136240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3136241, 1, "36f0baea06d9a0f9df14c8b84900955faa1f1fecb15cb96d1837635bb8908b0b")
