-- Lua provided by RyzenAPI
-- Game: 2752220

-- MAIN APPLICATION
addappid(2752220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752222,0,"cb2ae60ff1898fbee6a056ce1307bbbaf8efe720448c5aad07c93c99fea477a5")

