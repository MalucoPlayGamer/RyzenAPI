-- Lua provided by RyzenAPI
-- Game: Project Tower Demo

-- MAIN APPLICATION
addappid(2999190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2999191, 1, "682a9bcb9a05fe39516f69e938b7fb0788367a0e00eb671933fb66bc69df969c")

