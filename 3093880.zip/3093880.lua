-- Lua provided by RyzenAPI
-- Game: Game: AppID 3093880

-- MAIN APPLICATION
addappid(3093880)
-- Game: addappid(3093880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3093881, 1, "c73d7b267246b5d6ae62e59bcd7c9709894eaad573bb9bd385e7e2d1b7eb90c4")
