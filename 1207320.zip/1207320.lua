-- Lua provided by RyzenAPI
-- Game: 1207320

-- MAIN APPLICATION
addappid(1207320)
-- Game: addappid(1207320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1207321, 1, "e7de166554cd1ec6d94e89e3c76219b336a5c2a3948e16b37cb848ba966e321c")
