-- Lua provided by RyzenAPI
-- Game: addappid(2159680)

-- MAIN APPLICATION
addappid(2159680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2159681, 1, "8597a83f672b1b3bc8db69e3d7406acf67b7610cae2ff2514e460e48f0b00dd1")
