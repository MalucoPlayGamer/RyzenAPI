-- Lua provided by RyzenAPI 
-- Game: Touhou Spell Carnival
addappid(3469190)
addappid(3469191, 1, "50d374b0c0e272aff9b980f200e8813606e7b157616cfccad7c5318a30691369")
addappid(3469192, 1, "a5baa832c82725cc193f210b1ca1bd611ae8d45280cb521400ddf3753640fac1")
addappid(3470700)
