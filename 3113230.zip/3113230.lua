-- Lua provided by RyzenAPI 
-- Game: Immortal IDLE
addappid(3113230)
addappid(3113231, 1, "3d1b2cb1bdee2c677fb346065266ad7a4dc5522f101793d371747c0a3cf76984")
