-- Lua provided by RyzenAPI
-- Game: Game: IFO

-- MAIN APPLICATION
addappid(1876000)
-- Game: addappid(1876000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876001, 1, "d2fef97789b9080996507e84b506a4b671c2e1bcb4aa6adf73fb8b06227fbb90")
