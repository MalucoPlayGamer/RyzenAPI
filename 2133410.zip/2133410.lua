-- Lua provided by RyzenAPI
-- Game: addappid(2133410)

-- MAIN APPLICATION
addappid(2133410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2133411, 1, "68e18f35205b6738dd5f4b38abf87abb0a5808309786f3fcffad8437275310a6")
