-- Lua provided by RyzenAPI
-- Game: GoNNER OST

-- MAIN APPLICATION
addappid(533240)
-- Game: addappid(533240)

-- MAIN APP DEPOTS / PACKAGES
addappid(533241, 1, "fd199971a90ff9f1d5187b76b2dd0094ba33e19456493b4c5b2a03e30260c844")
