-- Lua provided by SkyAPI 
-- Game: AppID 1800790
addappid(1800790)
addappid(1800791, 1, "d540a87149fbe7fdb433e7514cebf6016ad294a26c1f7b5950672ca705376ebc")
