-- Lua provided by RyzenAPI
-- Game: addappid(1190690)

-- MAIN APPLICATION
addappid(1190690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190691, 1, "c8dcebe760dc43763b0377671b6d98572d9ef564f23f08c06bbe5c89329cfdd5")
