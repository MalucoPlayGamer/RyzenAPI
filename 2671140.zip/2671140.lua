-- Lua provided by RyzenAPI
-- Game: Galactic Civilizations IV - Warlords

-- MAIN APPLICATION
addappid(2671140)
-- Game: addappid(2671140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2671140,0,"5147c8e384e5edca494279cd278e26ebd290521ae63ab16a7b2c1be9cf6abc86")
