-- Lua provided by RyzenAPI
-- Game: Game: Last Stand Delivery

-- MAIN APPLICATION
addappid(2585110)
-- Game: addappid(2585110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2585111, 1, "d29c902a9f697eea8a0a49c627c9b4fbbd7639b8c7f08bca166f668621d80753")
