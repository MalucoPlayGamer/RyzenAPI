-- Lua provided by RyzenAPI
-- Game: Game: AppID 485360

-- MAIN APPLICATION
addappid(485360)
-- Game: addappid(485360)

-- MAIN APP DEPOTS / PACKAGES
addappid(485361, 1, "e616f2588657e56b4f3c6e8ca4427cebc30fb4a31e28709dbd7f29e3166c19b7")
