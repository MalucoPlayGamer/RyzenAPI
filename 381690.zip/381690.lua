-- Lua provided by RyzenAPI 
-- Game: AppID 381690
addappid(381690)
addappid(381691, 1, "e15459786b05d52c7c0886e98b9583e7f1b70eb40a0a904b30dbb0ef0752013a")
