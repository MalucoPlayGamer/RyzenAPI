-- Lua provided by SkyAPI 
-- Game: Redemption Reapers
addappid(2139300)
addappid(2139301, 1, "53adeff87015d393449756b3d4285d1fa37abeecd52e929a8385eef01cae45a3")
