-- Lua provided by RyzenAPI
-- Game: addappid(2139300)

-- MAIN APPLICATION
addappid(2139300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139301, 1, "53adeff87015d393449756b3d4285d1fa37abeecd52e929a8385eef01cae45a3")
