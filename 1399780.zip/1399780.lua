-- Lua provided by RyzenAPI
-- Game: Spellbreak

-- MAIN APPLICATION
addappid(1399780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399781, 1, "3865bdcfb996789447a5e30e98af2ec7e3bd6b878bac0921bb58f4457e9624e1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1497340)
addappid(1497480)
addappid(1498950)
addappid(1498960)
addappid(1546040)
addappid(1570560)
addappid(1570561)
addappid(1695690)
addappid(1695691)
