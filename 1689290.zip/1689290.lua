-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: MSK Productions - Jinnah Intl Airport

-- MAIN APPLICATION
addappid(1689290)
-- Game: addappid(1689290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689290,0,"c754d3267a166f521156bcc91f886586456386bcfec16efe742bf29754f4a898")
