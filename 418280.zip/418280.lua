-- Lua provided by RyzenAPI
-- Game: Retaliation

-- MAIN APPLICATION
addappid(418280)

-- MAIN APP DEPOTS / PACKAGES
addappid(418281, 1, "9ab2e67ce9e2c6d8616c9b4d656f45ce3f79b17e050228a8c2ab0d0463970a79")
addappid(418282, 1, "7c1a31bd893533a7b102c46fa57af3a7adbf354f5258243085ce3b344089f1f7")

