-- Lua provided by RyzenAPI
-- Game: 587620

-- MAIN APPLICATION
addappid(587620)
-- Game: addappid(587620)

-- MAIN APP DEPOTS / PACKAGES
addappid(587621, 1, "dbef9c5a131af356bcee9780519c447ff2fcf3b38399004c4aa76bd0eb85adec")
addappid(587623, 1, "959eb7d1aa7418826034feb7e0fe4081f67974c4d0121cf9a451742fe660c3d4")
