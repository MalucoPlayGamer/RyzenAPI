-- Lua provided by RyzenAPI
-- Game: AppID 587620

-- MAIN APPLICATION
addappid(587620)
addappid(752250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(587621, 1, "dbef9c5a131af356bcee9780519c447ff2fcf3b38399004c4aa76bd0eb85adec")
addappid(587623, 1, "959eb7d1aa7418826034feb7e0fe4081f67974c4d0121cf9a451742fe660c3d4")

