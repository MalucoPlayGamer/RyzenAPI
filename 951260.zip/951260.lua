-- Lua provided by SkyAPI 
-- Game: AppID 951260
addappid(951260)
addappid(951261, 1, "e0b164562f0c107b929b0169c6f4806618a6d6e536f0295d4303bc9e1a9b2735")
