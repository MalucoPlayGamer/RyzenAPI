-- Lua provided by RyzenAPI
-- Game: Flooded

-- MAIN APPLICATION
addappid(1795470)
-- Game: addappid(1795470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1795471, 1, "78d9b1a08e10574542db91f804c7d1db52c2bc01930c8e341f70a3222760657b")
