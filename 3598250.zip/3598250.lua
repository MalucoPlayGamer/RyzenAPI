-- Lua provided by RyzenAPI
-- Game: Virtual Frenzy- Nexus Corps

-- MAIN APPLICATION
addappid(3598250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3598251, 1, "7e99d50c226b27d781c72ae40f7f9575ac4cd84ced39b8576558a0bcc94e3eea")
