-- Lua provided by RyzenAPI
-- Game: Soundelta

-- MAIN APPLICATION
addappid(2763430)
-- Game: addappid(2763430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2763431, 1, "88399e316b6037209fc7b712362bd5cb3f14e4605a1389b82052fe6aea9d5116")
