-- Lua provided by RyzenAPI
-- Game: Soundelta

-- MAIN APPLICATION
addappid(2763430)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(2763431, 1, "88399e316b6037209fc7b712362bd5cb3f14e4605a1389b82052fe6aea9d5116")

