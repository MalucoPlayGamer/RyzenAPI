-- Lua provided by RyzenAPI
-- Game: GRAL

-- MAIN APPLICATION
addappid(718020)

-- MAIN APP DEPOTS / PACKAGES
addappid(718021,0,"8c6323da6f8eca85459b6ce3cef13745d751be56d4e05cb824b683730cc1da28")

