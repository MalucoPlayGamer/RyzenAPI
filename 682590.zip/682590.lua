-- Lua provided by RyzenAPI 
-- Game: Dungeon Marathon
addappid(682590)
addappid(682591, 1, "9b363456ca8091058f30fad08648eae0eda60f98cd9899d532517572dbaa1f34")
