-- Lua provided by RyzenAPI
-- Game: Dungeon Marathon

-- MAIN APPLICATION
addappid(682590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(682591, 1, "9b363456ca8091058f30fad08648eae0eda60f98cd9899d532517572dbaa1f34")

