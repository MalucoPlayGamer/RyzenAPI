-- Lua provided by RyzenAPI
-- Game: Game: Kraven Manor

-- MAIN APPLICATION
addappid(296630)
-- Game: addappid(296630)

-- MAIN APP DEPOTS / PACKAGES
addappid(296631, 1, "70d9c4d4114880690ea2e35776bda9a2135bc6f9d79635daa8d4df92d36906d2")
