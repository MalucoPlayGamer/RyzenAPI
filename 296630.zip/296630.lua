-- Lua provided by RyzenAPI 
-- Game: Kraven Manor
addappid(296630)
addappid(296631, 1, "70d9c4d4114880690ea2e35776bda9a2135bc6f9d79635daa8d4df92d36906d2")
