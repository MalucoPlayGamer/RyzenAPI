-- Lua provided by RyzenAPI
-- Game: addappid(934840)

-- MAIN APPLICATION
addappid(934840)

-- MAIN APP DEPOTS / PACKAGES
addappid(934841, 1, "1b25c09237c15a7bffbc2fad88f265e72c73e0af5aea2beae04d5b62eac519a1")
