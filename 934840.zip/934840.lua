-- Lua provided by RyzenAPI
-- Game: FrostRunner

-- MAIN APPLICATION
addappid(934840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(934841, 1, "1b25c09237c15a7bffbc2fad88f265e72c73e0af5aea2beae04d5b62eac519a1")

