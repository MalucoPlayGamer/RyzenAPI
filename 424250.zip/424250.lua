-- Lua provided by RyzenAPI
-- Game: Game: Balrum

-- MAIN APPLICATION
addappid(424250)
-- Game: addappid(424250)

-- MAIN APP DEPOTS / PACKAGES
addappid(424251, 1, "392f21c20809885997ece5cf4a3d098dd68a75f86ac09174537e427c811f173a")
addappid(424252, 1, "226f29c5e50dd57c3451f59e2e07d4e16148a4d4f5feda44e4d3433bcb1a87dc")
addappid(424253, 1, "1759d26664198fcaa6b357ab4aeb8991de19ce65cf4ecf3417f55387ecdd857b")
addappid(424254, 1, "be4920578599fbc4a7a7ecfa636b6bb4a82c789c041d80d3351b089cdd6309f8")
