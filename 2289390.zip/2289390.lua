-- Lua provided by RyzenAPI
-- Game: Crab God

-- MAIN APPLICATION
addappid(2289390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2289394,0,"ffd6a337a3287e7eea5317a1e358aceb3cf163e2295160f8030e9b703b2ba355")
addappid(3016900,0,"c6880050f24e0aab306cdfa29d27ceeafd7453006a0df2cfa8f5142400957bba")

