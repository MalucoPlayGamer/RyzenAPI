-- Lua provided by RyzenAPI
-- Game: Frontier Legends

-- MAIN APPLICATION
addappid(3032150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3032151, 1, "85cf9fff9efd2b60f37c2788e95923a29c58130b529c982da8294d2f4378f076")

