-- Lua provided by RyzenAPI
-- Game: 3032150

-- MAIN APPLICATION
addappid(3032150)
-- Game: addappid(3032150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3032151, 1, "85cf9fff9efd2b60f37c2788e95923a29c58130b529c982da8294d2f4378f076")
