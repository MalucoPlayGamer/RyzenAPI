-- Lua provided by RyzenAPI
-- Game: Space Expedition

-- MAIN APPLICATION
addappid(2353730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2353731, 1, "b21715a3817350453e2b571333ef2075daf36ab08d7eed76bb383fd61ba69b49")
addappid(2353732, 1, "1cb662fea37c8bd1ff2a67f79302eacd11effb292b418c744a5e498744f46067")

