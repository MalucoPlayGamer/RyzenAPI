-- Lua provided by RyzenAPI
-- Game: Super Flippin' Phones

-- MAIN APPLICATION
addappid(433490)

-- MAIN APP DEPOTS / PACKAGES
addappid(433491, 1, "838d4a6762872b860c1ecced5ebd6a323fade2269968469fa4b69a0b989c3f8c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
