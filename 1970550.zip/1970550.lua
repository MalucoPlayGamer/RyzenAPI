-- Lua provided by RyzenAPI
-- Game: Mystery Quest

-- MAIN APPLICATION
addappid(1970550)
-- Game: addappid(1970550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1970551, 1, "41b68d4aef0309acc875246f11b0d07b34500f2afba70d65c72d6a131adc4abc")
