-- Lua provided by RyzenAPI
-- Game: Atomic Hazard

-- MAIN APPLICATION
addappid(2611110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2611112,0,"690aaf3505bf43080f5c2450bb456083980bb19a183c78c1d2ccd2b6e715ef69")

