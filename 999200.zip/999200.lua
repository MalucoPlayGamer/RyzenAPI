-- Lua provided by RyzenAPI
-- Game: Offendron Warrior

-- MAIN APPLICATION
addappid(999200)
addappid(999980)
-- Game: addappid(999200)

-- MAIN APP DEPOTS / PACKAGES
addappid(999201, 1, "6e74b4c53a0320afae1be59e908c71732962240982c7c650db3629fa72f24c79")
addappid(999202, 1, "1f58c9ca012eaa4e9f5387912407157159a9dd5bd68d05a417b4244a48c62268")
