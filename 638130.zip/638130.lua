-- Lua provided by RyzenAPI 
-- Game: AppID 638130
addappid(638130)
addappid(638131, 1, "5615ea884347bde14995453ad1306768beaf4db9839003c70dc5e3df7505f99f")
