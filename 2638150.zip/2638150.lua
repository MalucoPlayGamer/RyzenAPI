-- Lua provided by RyzenAPI
-- Game: Choose Your Cutie

-- MAIN APPLICATION
addappid(2638150)
addappid(2663080)
-- Game: addappid(2638150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2638151, 1, "bc94f39cfe042e25b20fc650a0230c67d5f7f1e295c6a3f116c816b8a93a732f")
