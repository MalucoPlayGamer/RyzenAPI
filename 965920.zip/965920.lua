-- Lua provided by RyzenAPI
-- Game: RocketGO

-- MAIN APPLICATION
addappid(965920)
-- Game: addappid(965920)

-- MAIN APP DEPOTS / PACKAGES
addappid(965921, 1, "d5dbc7d29cb8958365292275e42d660f79bd8f116c1ff1268e45eff373146f39")
addappid(965922, 1, "0c67dbe420b81d9672b44e1ee5cb1bb3032c4faf863038168b6ea14c8e455667")
