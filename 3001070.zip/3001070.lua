-- Lua provided by RyzenAPI
-- Game: addappid(3001070)

-- MAIN APPLICATION
addappid(3001070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3001071, 1, "976e061cedadc0d0fa4bc826b43ded3561540a126530dee5eb06d2b82f08dc8c")
addappid(3149920, 0, "5269fcffd03514f7effef2f1812afb8aee84a93b5139fb064494d369dce88e3e")
