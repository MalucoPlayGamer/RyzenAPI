-- Lua provided by RyzenAPI
-- Game: Ukrainian Ninja

-- MAIN APPLICATION
addappid(339000)

-- MAIN APP DEPOTS / PACKAGES
addappid(339001, 1, "762dcb49ea573666aac1fb1e1632b5e0202f5eb184fd56aa1b4b4b3db9d91fd7")
addappid(339003, 1, "e21f349aca94f8f6c43c399db4b5170112fae49740f80f2c42cbfd9abe70e3a7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
