-- Lua provided by RyzenAPI
-- Game: Demon Of The Dark

-- MAIN APPLICATION
addappid(2582100)
-- Game: addappid(2582100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2582101, 1, "8375f8e305c3bb08983dc49446f07f8692144535ae6573284293adacd6c032f4")
