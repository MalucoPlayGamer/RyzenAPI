-- Lua provided by RyzenAPI
-- Game: I Heard There Are Monsters Here

-- MAIN APPLICATION
addappid(2248250)
-- Game: addappid(2248250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2248251, 1, "b301b5e103d675a22bf577c46a8ccb88a1d52a5d37b5ec3a6e479a2ffd5a8c59")
addappid(2248252, 1, "60dfdebf51c7613dda3d06d42112b2cfef7f7242141b008d8f60e40425007d1b")
