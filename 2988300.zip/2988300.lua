-- Lua provided by RyzenAPI
-- Game: Game: Bugtopia

-- MAIN APPLICATION
addappid(2988300)
-- Game: addappid(2988300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2988301, 1, "53d66b28bdf2721c233a0e5bd72835548ca9f4510064fa3179b17158b7263e9e")
