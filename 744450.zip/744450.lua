-- Lua provided by RyzenAPI
-- Game: 744450

-- MAIN APPLICATION
addappid(744450)
-- Game: addappid(744450)

-- MAIN APP DEPOTS / PACKAGES
addappid(744451, 1, "ec16dd3c45decece8289ffaa2b873c323bd6fee784145a5d3d165aa84830e8ca")
