-- Lua provided by RyzenAPI
-- Game: Project Dagger

-- MAIN APPLICATION
addappid(1258800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258803,0,"7897c910159317059b0ff88c1120c317e126ce04f0db3e0b35685f6f96c9c410")

