-- Lua provided by RyzenAPI
-- Game: AppID 3310950

-- MAIN APPLICATION
addappid(3310950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3310951, 1, "71fe2b59778f12b80fe3fce38ec5ff55b881a9d809011afe73df2fdd8c3c5fec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
