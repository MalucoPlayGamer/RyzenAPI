-- Lua provided by SkyAPI 
-- Game: Ghostlore
addappid(1783280)
addappid(1783281, 1, "0d1ead4cea09777b847e74d2023f5cdaa28eb5b0ea6a0c85245014f7dbd521aa")
addappid(3204010)
