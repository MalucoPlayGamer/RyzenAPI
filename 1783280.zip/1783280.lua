-- Lua provided by RyzenAPI
-- Game: Ghostlore

-- MAIN APPLICATION
addappid(1783280)
addappid(3204010)
-- Game: addappid(1783280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1783281, 1, "0d1ead4cea09777b847e74d2023f5cdaa28eb5b0ea6a0c85245014f7dbd521aa")
