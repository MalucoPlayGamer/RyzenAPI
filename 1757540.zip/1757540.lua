-- Lua provided by RyzenAPI
-- Game: Axial Drift Dedicated Server

-- MAIN APPLICATION
addappid(1757540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1757541, 1, "ff52f0d705e23f6548f8f93a084da8f91cbab9587d8914df061d941c18cfeb50")

