-- Lua provided by RyzenAPI
-- Game: VetVR Demo

-- MAIN APPLICATION
addappid(2229970)
-- Game: addappid(2229970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229971, 1, "7a0c8d62c44c706bb53eb6d77bb5268f6eeecbda1c1db34d9e2a5a187f51dee2")
