-- Lua provided by RyzenAPI
-- Game: CAGELING

-- MAIN APPLICATION
addappid(3668840)
-- Game: addappid(3668840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3668841, 1, "6bd39d1f4c9e95d5b77d98e9b8f4f9c5a45c5738d1475e944ca222b3a5051641")
