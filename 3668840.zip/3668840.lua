-- Lua provided by RyzenAPI
-- Game: CAGELING

-- MAIN APPLICATION
addappid(3668840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3668841, 1, "6bd39d1f4c9e95d5b77d98e9b8f4f9c5a45c5738d1475e944ca222b3a5051641")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
