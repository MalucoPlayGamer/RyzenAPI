-- Lua provided by SkyAPI 
-- Game: CAGELING
addappid(3668840)
addappid(3668841, 1, "6bd39d1f4c9e95d5b77d98e9b8f4f9c5a45c5738d1475e944ca222b3a5051641")
