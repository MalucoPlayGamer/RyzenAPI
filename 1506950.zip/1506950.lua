-- Lua provided by RyzenAPI
-- Game: GLASS - Eily Brave 18+ Adult Only

-- MAIN APPLICATION
addappid(1506950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506951, 1, "822c2fbbd29d7cf5a3cdd7bc698c61ebc6402808a951c2c2a50c3f3a04f78231")
addappid(1506952, 1, "8783f9ad4d44ca7273c7631314fd93aeaf7cc05b0fa4af88ef767ab3d9a23b31")

