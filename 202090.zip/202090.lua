-- Lua provided by RyzenAPI
-- Game: Game: AppID 202090

-- MAIN APPLICATION
addappid(202090)
-- Game: addappid(202090)

-- MAIN APP DEPOTS / PACKAGES
addappid(202091, 1, "fabf718be3739fc5058e6bc0eff0452a73fbd3eb7961a7d77046b9c92aef8326")
