-- Lua provided by RyzenAPI
-- Game: Magicka: Wizard Wars

-- MAIN APPLICATION
addappid(202090) -- Magicka: Wizard Wars
addappid(202092) -- Magicka Wizard Wars Wizard starter pack activation key
addappid(202093) -- Magicka Wizard Wars Founder Wizard activation key
addappid(202094) -- Magicka Wizard Wars IMPressive founder activation key
addappid(202095) -- Magicka Wizard Wars Wizard starter pack activation key
addappid(300640) -- Magicka Wizard Wars - Apprentice Starter Content
addappid(300641) -- Magicka Wizard Wars - Wizard Starter Content
addappid(300642) -- Magicka Wizard Wars - Archmage Starter Content
addappid(306650) -- Magicka Wizard Wars - E3 Wizard Wars
addappid(307540) -- Magicka Wizard Wars - Flaming Hel Rider Pack
addappid(314130) -- Magicka Wizard Wars - Oozing Shaman Pack
addappid(318140) -- Magicka Wizard Wars - Alienware
addappid(319310) -- Magicka Wizard Wars - Holy Protector Robe
addappid(320940) -- Magicka Wizard Wars - Holy Knights Robe
addappid(321650) -- Magicka Wizard Wars - Salty Pirate Pack
addappid(322200) -- Magicka Wizard Wars - Razer
addappid(323750) -- Magicka Wizard Wars - Crystal Booster Pack
addappid(325460) -- Magicka Wizard Wars - RockPaperShotgun
addappid(325461) -- Magicka Wizard Wars - PCGamer
addappid(325462) -- Magicka Wizard Wars - Paradox Magicka Collection
addappid(326400) -- Magicka Wizard Wars - Glittering Golden Illusionist Robe
addappid(326750) -- Magicka Wizard Wars - GameSpot
addappid(328150) -- Magicka Wizard Wars - MMOBomb
addappid(329850) -- Magicka Wizard Wars - Humble Halloween
addappid(329940) -- Magicka Wizard Wars - Paradoxplaza
addappid(333840) -- Magicka Wizard Wars - Razer 2.0
addappid(334020) -- Magicka Wizard Wars - Yogscast
addappid(337910) -- Magicka Wizard Wars - Frosty Holiday Pack
addappid(353100) -- Magicka Wizard Wars - Magicka 2 Basic pre-order cross promo
addappid(353101) -- Magicka Wizard Wars - Magicka 2 DDE pre-order cross promo
addappid(355610) -- Magicka Wizard Wars - Exclusive Alienware Speedy Robe skin
addappid(355611) -- Magicka Wizard Wars - 20000 Crowns
addappid(355612) -- Magicka Wizard Wars - 3 Treasure Keys
addappid(359590) -- Magicka Wizard Wars - Online Acq
addappid(363260) -- Magicka Wizard Wars - Scholar Starter Pack
addappid(363261) -- Magicka Wizard Wars - Warlock Starter Pack
addappid(365550) -- Magicka Wizard Wars - Razer 3.0
addappid(366170) -- Magicka Wizard Wars - Greenman Gaming Playfire Robe
addappid(366171) -- Magicka Wizard Wars - Indiegala Robe
addappid(366172) -- Magicka Wizard Wars - Games Republic Robe
addappid(366173) -- Magicka Wizard Wars - Amazon Imp
addappid(366174) -- Magicka Wizard Wars - Paradox Platypus Robe
addappid(366300) -- Magicka Wizard Wars - Press 1.0
addappid(367560) -- Magicka Wizard Wars - Small Crown Pack
addappid(367561) -- Magicka Wizard Wars - Medium Crown Pack
addappid(367562) -- Magicka Wizard Wars - Large Crown Pack
addappid(368810) -- Magicka Wizard Wars - Media Giveaway 1
addappid(369090) -- Magicka Wizard Wars - Media Giveaway 2
addappid(369091) -- Magicka Wizard Wars - Media Giveaway 3
addappid(369092) -- Magicka Wizard Wars - Media Giveaway 4
addappid(371560) -- Magicka Wizard Wars - Curse Staff
addappid(373430) -- Magicka Wizard Wars - Paradox Plaza Goodies
addappid(375490) -- Magicka Wizard Wars - E3 Paradox Staff  Sword
addappid(379220) -- Magicka Wizard Wars - Contest Prize

-- MAIN APP DEPOTS / PACKAGES
addappid(202091, 1, "fabf718be3739fc5058e6bc0eff0452a73fbd3eb7961a7d77046b9c92aef8326") -- Magicka: Wizard Wars Base Depot
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- PhysX System Software 9.12.1031 (Shared from App 228980)
addtoken(306650, "2894469303423900383")
addtoken(320940, "14779201540026455609")
addtoken(325462, "1229898221635791483")
addtoken(359590, "11690432596081574224")
addtoken(366171, "12879085362256994759")
addtoken(366174, "7824968532642190462")
addtoken(375490, "888206587452306630")

