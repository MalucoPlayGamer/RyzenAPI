-- Lua provided by RyzenAPI
-- Game: 340130

-- MAIN APPLICATION
addappid(340130)
-- Game: addappid(340130)

-- MAIN APP DEPOTS / PACKAGES
addappid(340131, 1, "8ce74fcdd28380844cd464eeb8187bf85314d7af3284ad35fe71c26271c91897")
