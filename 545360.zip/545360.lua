-- Lua provided by RyzenAPI
-- Game: AppID 545360

-- MAIN APPLICATION
addappid(545360)

-- MAIN APP DEPOTS / PACKAGES
addappid(545361, 1, "6cc07fcdd5445ab0ff1812f87cde0293802b2e6ccfc73011381fb69848c83d49")

