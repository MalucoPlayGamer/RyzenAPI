-- Lua provided by RyzenAPI
-- Game: Love n War: Warlord by Chance - Sisters of Castus

-- MAIN APPLICATION
addappid(1660900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1660900,0,"c691f29c961b6b3fe244951614fa009e9ccc54863cff5905949cadcd35e6dd89")

