-- Lua provided by RyzenAPI
-- Game: Game: AppID 3172560

-- MAIN APPLICATION
addappid(3172560)
-- Game: addappid(3172560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3172561, 1, "24095ad077fe9f9e2a885246e54011875d5c70456b7cfe82b47ed288d18a8205")
