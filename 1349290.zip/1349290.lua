-- Lua provided by RyzenAPI 
-- Game: BAFF F
addappid(1349290)
addappid(1349291, 1, "857bb422715a1e10fb98d0035a83a89ca5146d423bc2037ca2eabd064783587e")
