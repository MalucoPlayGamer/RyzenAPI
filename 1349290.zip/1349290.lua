-- Lua provided by RyzenAPI
-- Game: 1349290

-- MAIN APPLICATION
addappid(1349290)
-- Game: addappid(1349290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1349291, 1, "857bb422715a1e10fb98d0035a83a89ca5146d423bc2037ca2eabd064783587e")
