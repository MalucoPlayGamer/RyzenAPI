-- Lua provided by SkyAPI 
-- Game: Magic City Detective: The Carnival Begins Collector's Edition
addappid(2956500)
addappid(2956501, 1, "57c994d6a526d2b20fea71c7aa62a1d99d31f9fd8283b1dadc246fbcf4654ce6")
addappid(2956660, 0, "0cd96997de86146d039f5232cf1487fafac2b09ffbcc11897f3d0b3f010a4e2b")
