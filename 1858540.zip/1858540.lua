-- Lua provided by RyzenAPI
-- Game: AppID 1858540

-- MAIN APPLICATION
addappid(1858540)
-- Game: addappid(1858540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1858541, 1, "82eb4708d698dc21e276a42a104924af1386d9a17dc7e10ef36f264cfb2fef67")
