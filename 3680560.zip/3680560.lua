-- Lua provided by RyzenAPI
-- Game: Game: AppID 3680560

-- MAIN APPLICATION
addappid(3680560)
-- Game: addappid(3680560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3680561, 1, "cb289cae39ce0a324223e460bb9af6a8c5e1706b8b0bc7932575ea1b65c4efb9")
