-- Lua provided by RyzenAPI
-- Game: 1933800

-- MAIN APPLICATION
addappid(1933800)
-- Game: addappid(1933800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933801, 1, "b096b445b87bcb794fe236dd200a7a977b12fe2e37c2426840180eb81314ea68")
