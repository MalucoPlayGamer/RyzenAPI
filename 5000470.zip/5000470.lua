-- Lua provided by RyzenAPI
-- Game: Roguelike Bricks

-- MAIN APPLICATION
addappid(5000470) -- Roguelike Bricks

-- MAIN APP DEPOTS / PACKAGES
addappid(5000471, 1, "caca542aabd5b7a06710a69a5cf9ada796dc9a005cf844f6d83fae0f6b09de91") -- Depot 5000471

