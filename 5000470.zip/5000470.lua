-- 5000470's Lua and Manifest Created by Hubcap Manifest
-- Roguelike Bricks
-- Created: August 17, 2026 at 13:02:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5000470) -- Roguelike Bricks
-- MAIN APP DEPOTS
addappid(5000471, 1, "caca542aabd5b7a06710a69a5cf9ada796dc9a005cf844f6d83fae0f6b09de91") -- Depot 5000471
setManifestid(5000471, "7815328506756051556", 25463074)