-- Lua provided by RyzenAPI
-- Game: Tekkout2 - Balls Of Rust

-- MAIN APPLICATION
addappid(3792430)
-- Game: addappid(3792430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3792431, 1, "450a46730a0cfc2c089778cecca0b7845442517cd0f427df3234299a0cfe93b6")
