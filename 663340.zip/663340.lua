-- Lua provided by RyzenAPI
-- Game: Game: AppID 663340

-- MAIN APPLICATION
addappid(663340)
-- Game: addappid(663340)

-- MAIN APP DEPOTS / PACKAGES
addappid(663341, 1, "3260a02649cb0ea2ccdac654e2d2d4848f3a258c26ed3a1fe210e935aae1f1db")
