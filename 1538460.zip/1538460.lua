-- Lua provided by RyzenAPI
-- Game: Sword and Fairy 2

-- MAIN APPLICATION
addappid(1538460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1538461, 1, "9d5ae3fcf793574ed5a5d0e0ee9ffc526c91a0c0b95e77a39100e3fda5fbb054")
addappid(1538462, 1, "ad823a4aacde2e2ee5f3a2b585e73b5dbef963a49af5d6ab1194f4decfbb6b2b")
addappid(1538463, 1, "a501f31f3997b12db64d134135bec6724a34ac9a931af2b9bfec8e706fa9bc92")

