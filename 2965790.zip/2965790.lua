-- Lua provided by RyzenAPI
-- Game: Game: Arena of block puzzle

-- MAIN APPLICATION
addappid(2965790)
-- Game: addappid(2965790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2965791, 1, "b7079b88874e776cc3def5f4209fe3ec522f982f4a29ccac2161a1a1bd6212e4")
