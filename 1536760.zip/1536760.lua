-- Lua provided by RyzenAPI
-- Game: 1536760

-- MAIN APPLICATION
addappid(1536760)
-- Game: addappid(1536760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536760,0,"b7a0f0f21bdb8436b8d207f3e2cb6fc38f2975052b981f828b071b83520c69ab")
