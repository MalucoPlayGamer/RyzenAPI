-- Lua provided by RyzenAPI
-- Game: Chronicle of Innsmouth: Mountains of Madness

-- MAIN APPLICATION
addappid(962700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(962701, 1, "da9c964766c78b206bbbc31acafe0eae34a03bd9c1a5e8c72753d98099b0e2b4")

