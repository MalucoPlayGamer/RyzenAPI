-- Lua provided by RyzenAPI
-- Game: Chronicle of Innsmouth: Mountains of Madness

-- MAIN APPLICATION
addappid(962700)

-- MAIN APP DEPOTS / PACKAGES
addappid(962701, 1, "da9c964766c78b206bbbc31acafe0eae34a03bd9c1a5e8c72753d98099b0e2b4")
