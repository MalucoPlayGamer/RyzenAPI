-- Lua provided by RyzenAPI
-- Game: Cut Master Spades

-- MAIN APPLICATION
addappid(2119640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2119641, 1, "74787715598d950eb7b46858ea7d79faac2c78a2e75482783f22077a0c1686cf")
addappid(2119642, 1, "1580a01ddd223d4bc524801162413ba20f25df732ed728efdace047be7c65b49")

