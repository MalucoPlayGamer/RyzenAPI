-- Lua provided by RyzenAPI 
-- Game: AppID 719830
addappid(719830)
addappid(719831, 1, "8c4a061110456b176c778475ad5833a10a6570039aad09071e1280035f783abb")
