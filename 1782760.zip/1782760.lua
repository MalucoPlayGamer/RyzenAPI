-- Lua provided by RyzenAPI
-- Game: FINAL FURY

-- MAIN APPLICATION
addappid(1782760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1782761, 1, "e0bee2fadf1fe5c2a468ba266158e123a4b274d15da0d6e7e0462b188c528ae3")

