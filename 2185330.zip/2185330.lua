-- Lua provided by RyzenAPI
-- Game: Super Adventure Hand Demo

-- MAIN APPLICATION
addappid(2185330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185331, 1, "772d57b48a3e39ebc0fbd98da491ade526ef17edd37b0e4a33f20af978002d11")
