-- Lua provided by RyzenAPI
-- Game: Blade & Soul NEO

-- MAIN APPLICATION
addappid(3669060)
addappid(3843690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3669061, 1, "954cf335a2da6fa57e524ef0408fb1ee568a8dfcbed10abfb8afe4a81d0dca0c")

