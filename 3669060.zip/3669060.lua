-- Lua provided by RyzenAPI
-- Game: Blade & Soul NEO

-- MAIN APPLICATION
addappid(3669060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3669061, 1, "954cf335a2da6fa57e524ef0408fb1ee568a8dfcbed10abfb8afe4a81d0dca0c")

