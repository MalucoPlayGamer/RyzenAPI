-- Lua provided by RyzenAPI
-- Game: AppID 402710

-- MAIN APPLICATION
addappid(402710)

-- MAIN APP DEPOTS / PACKAGES
addappid(402711, 1, "3c9ed174bdbee11fe560c902c7cb266b1f4b27c5ffea4de0d51d5c39a65774c2")
