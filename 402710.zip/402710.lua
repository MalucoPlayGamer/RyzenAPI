-- Lua provided by RyzenAPI
-- Game: AppID 402710

-- MAIN APPLICATION
addappid(402710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(402711, 1, "3c9ed174bdbee11fe560c902c7cb266b1f4b27c5ffea4de0d51d5c39a65774c2")

