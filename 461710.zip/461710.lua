-- Lua provided by RyzenAPI
-- Game: Tales Across Time

-- MAIN APPLICATION
addappid(461710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(461711, 1, "a15c895af87816857bb341dc0ca7ad2dc95b333567916bc8280aa6996a9853dc")

