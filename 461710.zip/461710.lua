-- Lua provided by RyzenAPI
-- Game: addappid(461710)

-- MAIN APPLICATION
addappid(461710)

-- MAIN APP DEPOTS / PACKAGES
addappid(461711, 1, "a15c895af87816857bb341dc0ca7ad2dc95b333567916bc8280aa6996a9853dc")
