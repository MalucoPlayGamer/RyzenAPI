-- Lua provided by RyzenAPI
-- Game: addappid(1318280)

-- MAIN APPLICATION
addappid(1318280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1318281, 1, "4d1c5953c0e2150f87507a0af3e5ef130bf7dc0d024ca257b1013b1e82da539a")
