-- Lua provided by RyzenAPI
-- Game: Our Bad Ending

-- MAIN APPLICATION
addappid(4585000)
