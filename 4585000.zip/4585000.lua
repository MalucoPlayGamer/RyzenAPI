-- Lua provided by RyzenAPI
-- Game: Our Bad Ending

-- MAIN APPLICATION
addappid(4585000)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4646540)
