-- Lua provided by RyzenAPI 
-- Game: AppID 597840
addappid(597840)
addappid(597841, 1, "27a2d303b7e050e94513abf9fc9090c966e462254cfe82e82223d67a52562776")
