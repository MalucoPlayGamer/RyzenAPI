-- Lua provided by RyzenAPI
-- Game: Game: AppID 597840

-- MAIN APPLICATION
addappid(597840)
-- Game: addappid(597840)

-- MAIN APP DEPOTS / PACKAGES
addappid(597841, 1, "27a2d303b7e050e94513abf9fc9090c966e462254cfe82e82223d67a52562776")
