-- Lua provided by RyzenAPI
-- Game: Game: XEL

-- MAIN APPLICATION
addappid(1674640)
addappid(2119840)
-- Game: addappid(1674640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674641, 1, "3502eeb333c94dad88571b3f546b6212ee517d9366911d24c273213ab5d10495")
