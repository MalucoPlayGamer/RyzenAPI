-- Lua provided by RyzenAPI 
-- Game: AppID 2245360
addappid(2245360)
addappid(2245361, 1, "ab5e1eebf448b5c17bd4b43b34dd82f50e777badd292f4f0518e027f2c51b776")
