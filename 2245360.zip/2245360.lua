-- Lua provided by RyzenAPI
-- Game: addappid(2245360)

-- MAIN APPLICATION
addappid(2245360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2245361, 1, "ab5e1eebf448b5c17bd4b43b34dd82f50e777badd292f4f0518e027f2c51b776")
