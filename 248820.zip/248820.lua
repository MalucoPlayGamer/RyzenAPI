-- Lua provided by RyzenAPI
-- Game: Risk of Rain (2013)

-- MAIN APPLICATION
addappid(248820)
-- Game: addappid(248820)

-- MAIN APP DEPOTS / PACKAGES
addappid(248821, 1, "72d5d8df910ce6f6e6e6a596fc4f04cc58dd007c69073c2abeb90ee924256358")
addappid(248822, 1, "b9750cd0187cd9b7c69a241ec5848b480dc0024f2febbd46f24f98067b96dca4")
addappid(248823, 1, "b3a2f8cd3d338603abb3a298a0efa4c70ed23957f8bfd4a52e3afde7fd721188")
