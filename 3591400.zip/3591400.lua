-- Lua provided by RyzenAPI
-- Game: Cosplayer's Quest

-- MAIN APPLICATION
addappid(3591400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3591401,0,"f69e7015e5373738e8a1ab5d9548b84270a5a90198bcc2796a2008451f15e58e")

