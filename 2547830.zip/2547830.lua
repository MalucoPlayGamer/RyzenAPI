-- Lua provided by RyzenAPI
-- Game: One Life Clicker

-- MAIN APPLICATION
addappid(2547830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2547831, 1, "4d6e30c6c00f52f9babe7630a85c5c180922a53a610c93db2dd6c8a281083068")

