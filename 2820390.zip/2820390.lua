-- Lua provided by RyzenAPI
-- Game: Game: Seclusion

-- MAIN APPLICATION
addappid(2820390)
-- Game: addappid(2820390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2820391, 1, "8db2b6923013c287df2b356e30484836e18278f657dd7b2939f5ce63854885ac")
