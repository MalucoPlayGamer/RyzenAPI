-- Lua provided by RyzenAPI
-- Game: Sports Bar VR

-- MAIN APPLICATION
addappid(269170)
-- Game: addappid(269170)

-- MAIN APP DEPOTS / PACKAGES
addappid(269171, 1, "9a60e9258e22dfcd114e0a1e0b0263ea6d64419cada2a212d7167a5693f466d6")
