-- Lua provided by RyzenAPI
-- Game: addappid(2210900)

-- MAIN APPLICATION
addappid(2210900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2210901, 1, "7369648ffec10cd0e885bd3fccd7656d7d59fdb23927ac5f983dbd0ad7b62c47")
