-- Lua provided by SkyAPI 
-- Game: Nanoworld
addappid(1166510)
addappid(1166511, 1, "852fc350769fc76668ee472bb26c5ba6a3e4aa524f7a223bbc7f5c1a034ebe20")
