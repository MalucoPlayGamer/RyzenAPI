-- Lua provided by RyzenAPI
-- Game: addappid(1166510)

-- MAIN APPLICATION
addappid(1166510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166511, 1, "852fc350769fc76668ee472bb26c5ba6a3e4aa524f7a223bbc7f5c1a034ebe20")
