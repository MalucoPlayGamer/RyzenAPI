-- Lua provided by RyzenAPI
-- Game: Ivorfall

-- MAIN APPLICATION
addappid(2901040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2901041, 1, "39edc30c570b401d2511c60bc65d7d43a8635787ba4a0eb2e4b97f88d7a30787")

