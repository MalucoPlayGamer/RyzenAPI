-- Lua provided by RyzenAPI
-- Game: Ivorfall

-- MAIN APPLICATION
addappid(2901040)
-- Game: addappid(2901040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2901041, 1, "39edc30c570b401d2511c60bc65d7d43a8635787ba4a0eb2e4b97f88d7a30787")
