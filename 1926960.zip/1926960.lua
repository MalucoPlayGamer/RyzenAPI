-- Lua provided by RyzenAPI
-- Game: The lost fleet Demo

-- MAIN APPLICATION
addappid(1926960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1926962,0,"f5e179f963596aa4139b93967b460cec26ca5ab18f3464c11e8d463304bdfe91")

