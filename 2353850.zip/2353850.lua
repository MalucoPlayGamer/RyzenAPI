-- Lua provided by RyzenAPI
-- Game: 零号协议AgreementZero

-- MAIN APPLICATION
addappid(2353850)
addappid(2370580)
addappid(2947960)
addappid(2953220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2353851, 1, "267a39d3871010951147dd17a3307ff6596f9c892db20e0d12ed507758e1af44")

