-- Lua provided by RyzenAPI
-- Game: Pixel Game Maker MV - Weapon assets (100 varieties) and Dot Robot Set

-- MAIN APPLICATION
addappid(972400)

-- MAIN APP DEPOTS / PACKAGES
addappid(972401, 1, "ff208509f4e679bc09c6f36560db74b18888dd3320ae4c8d444d903cdbe10645")
