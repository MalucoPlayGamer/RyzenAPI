-- Lua provided by RyzenAPI
-- Game: 972400

-- MAIN APPLICATION
addappid(972400)
-- Game: addappid(972400)

-- MAIN APP DEPOTS / PACKAGES
addappid(972401, 1, "ff208509f4e679bc09c6f36560db74b18888dd3320ae4c8d444d903cdbe10645")
