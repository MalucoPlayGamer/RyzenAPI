-- Lua provided by RyzenAPI
-- Game: The Tale of Onogoro

-- MAIN APPLICATION
addappid(2023880)
-- Game: addappid(2023880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2023881, 1, "16650d533f0fc1ce64372652bfe90cc6f60f333e159f79b904a0718462c0541d")
