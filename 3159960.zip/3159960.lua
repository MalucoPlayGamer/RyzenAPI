-- Lua provided by SkyAPI 
-- Game: The Soldier and the Golden Princess
addappid(3159960)
addappid(3159961, 1, "46379326dfc7a4275711815068fde2b216d8dc209ccdb27b5e71e8908bd5da53")
addappid(3159962, 1, "3e7a3c94cc183c81881d582fb30c5e7e237ed1510c656226e42bd34afd690e29")
addappid(3159963, 1, "5ebe37112ca6754310f3bb364938acad77d7637e2ea8eca74a4c9cbb1f16f566")
