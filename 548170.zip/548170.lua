-- Lua provided by RyzenAPI
-- Game: Arena Master

-- MAIN APPLICATION
addappid(548170)

-- MAIN APP DEPOTS / PACKAGES
addappid(548171,0,"4f63eee391ed8464615f7aa0913490d7d39bdcafc7486a66623215526327cf85")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
