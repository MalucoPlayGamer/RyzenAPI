-- Lua provided by RyzenAPI
-- Game: Arena Master

-- MAIN APPLICATION
addappid(548170)

-- MAIN APP DEPOTS / PACKAGES
addappid(548171,0,"4f63eee391ed8464615f7aa0913490d7d39bdcafc7486a66623215526327cf85")

