-- Lua provided by RyzenAPI
-- Game: Sam & Max 201: Ice Station Santa

-- MAIN APPLICATION
addappid(8260)

-- MAIN APP DEPOTS / PACKAGES
addappid(8261, 1, "ef3418a0908de2da4f405a814be9cf077849b839a0c856bdbb537330d1f67fd9")
addappid(8262, 1, "855d774ac3bd957ab63ccb0ec11b02236eceff81267f364ef218adc58467aff9")

