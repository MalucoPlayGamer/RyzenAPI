-- Lua provided by RyzenAPI
-- Game: Keks Slot Machines

-- MAIN APPLICATION
addappid(2185050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185051, 1, "94c890c6b353a9bb3431c4372e06a30fd9ae53516aed90ddbfe037ed7fdbaa0a")

