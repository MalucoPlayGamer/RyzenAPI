-- Lua provided by RyzenAPI
-- Game: Untitled Goose Game

-- MAIN APPLICATION
addappid(837470)

-- MAIN APP DEPOTS / PACKAGES
addappid(837471, 1, "c0195389642c36e20a08a26e14ad32d825bc4a1b88601fc684b0210922af2e3e")
addappid(837472, 1, "304d5b5db6337ae477a599268e230a3ef7147d46f02a520de4bcbcc73af8a627")

