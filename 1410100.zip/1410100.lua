-- Lua provided by RyzenAPI 
-- Game: Saving Punyville
addappid(1410100)
addappid(1410101, 1, "c053e007768bffe81dff158b08b41a5c3f9eb04b7b526f59537ee7c1c1142967")
addappid(1410102, 1, "68ca6bee038b2882df141e33cda9f40c9d80b8da4c418bbe6506f20755246752")
