-- Lua provided by RyzenAPI
-- Game: 2259260

-- MAIN APPLICATION
addappid(2259260)
addappid(3729840)
-- Game: addappid(2259260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2259261, 1, "aa2650859aadcdbb629fb0a080eec79020ca4840d4d6e1da873f965d7f9c420d")
