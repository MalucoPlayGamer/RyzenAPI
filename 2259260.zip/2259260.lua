-- Lua provided by RyzenAPI
-- Game: Tyrant's Realm

-- MAIN APPLICATION
addappid(2259260)
addappid(3729840)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2259261, 1, "aa2650859aadcdbb629fb0a080eec79020ca4840d4d6e1da873f965d7f9c420d")

