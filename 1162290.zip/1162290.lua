-- Lua provided by RyzenAPI
-- Game: Easy hentai puzzle 2

-- MAIN APPLICATION
addappid(1162290)
addappid(1165220)
addappid(1165221)
addappid(1165260)
addappid(1165261)
addappid(1165262)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162291, 1, "9b82aee7b8d8ad19c9e43f99a4556740906f55bd556f7a2219fb5a70d13275f3")

