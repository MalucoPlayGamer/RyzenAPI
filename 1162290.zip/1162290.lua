-- Lua provided by RyzenAPI
-- Game: AppID 1162290

-- MAIN APPLICATION
addappid(1162290)
-- Game: addappid(1162290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162291, 1, "9b82aee7b8d8ad19c9e43f99a4556740906f55bd556f7a2219fb5a70d13275f3")
