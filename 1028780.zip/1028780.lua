-- Lua provided by RyzenAPI
-- Game: AppID 1028780

-- MAIN APPLICATION
addappid(1028780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028781, 1, "d22e277bd45db61720bc924deab018c3aefb192d3494101da9ac63e7711f4b7d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
