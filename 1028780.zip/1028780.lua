-- Lua provided by RyzenAPI
-- Game: AppID 1028780

-- MAIN APPLICATION
addappid(1028780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028781, 1, "d22e277bd45db61720bc924deab018c3aefb192d3494101da9ac63e7711f4b7d")

