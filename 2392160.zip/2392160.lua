-- Lua provided by SkyAPI 
-- Game: Abscission
addappid(2392160)
addappid(2392161, 1, "3a7a500e8b3879fbf66fb15c3e8c4141d5d0dab8159675ee71bb8cd0acf61d67")
