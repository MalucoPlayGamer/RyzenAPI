-- Lua provided by RyzenAPI
-- Game: R-COIL

-- MAIN APPLICATION
addappid(717070)

-- MAIN APP DEPOTS / PACKAGES
addappid(717071, 1, "8eeea37efe8e8fa83068ca1103f424d0a03bf7569968b77c0a1b4ef1a8e51d4c")

