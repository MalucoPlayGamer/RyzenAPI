-- Lua provided by RyzenAPI
-- Game: Game: Three Finger Battle Arena

-- MAIN APPLICATION
addappid(1893860)
-- Game: addappid(1893860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1893861, 1, "bc4d2392bda0c6d5bf6a14551904c483102f4aa9773502b1ee1bf13fe1311ff9")
