-- Lua provided by RyzenAPI
-- Game: AppID 3498270

-- MAIN APPLICATION
addappid(3498270)
-- Game: addappid(3498270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3498271, 1, "f9a8672f59ce9964e872dfb6e6bfaff3baa16dad3ddc7f2b2fb12bd5b1e66ad3")
