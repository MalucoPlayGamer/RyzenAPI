-- Lua provided by RyzenAPI
-- Game: Kingpin: Reloaded

-- MAIN APPLICATION
addappid(1224700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1224701, 1, "224fadd9a3e3c1ea59844148fc0d6f33007e147a82b3b6c08c5b5ffdca77b164")

