-- Lua provided by RyzenAPI
-- Game: Miniland Adventure: Prologue

-- MAIN APPLICATION
addappid(2152460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152461, 1, "4608aec815bfdbb28ee72608b58ddedba7e27b1c3207171c5148b4157fb65003")
