-- Lua provided by RyzenAPI
-- Game: addappid(1646700)

-- MAIN APPLICATION
addappid(1646700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646701, 1, "22e9c7b1d91d3a5ea45ec2205ea43e468471992d19e32cc33bc09a684cda032a")
