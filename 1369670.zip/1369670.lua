-- Lua provided by RyzenAPI
-- Game: Motor Town: Behind The Wheel

-- MAIN APPLICATION
addappid(1369670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1369671, 1, "2997d5be0b53d13cde83335f41136a55c7198a843f319a2e9e3667ef228a1aed")

