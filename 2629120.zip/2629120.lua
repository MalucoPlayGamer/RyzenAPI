-- Lua provided by RyzenAPI
-- Game: Floating girl

-- MAIN APPLICATION
addappid(2629120)
-- Game: addappid(2629120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2629121, 1, "5b7942f5bde53140d150921d06a333f727eadf134b070afe7e957b443f660834")
