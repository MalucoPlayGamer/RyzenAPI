-- Lua provided by RyzenAPI
-- Game: Another_World

-- MAIN APPLICATION
addappid(1246390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1246391, 1, "cd10ee84512b1080a98ae279aea4eb04f5a6e1561e13e17b5ef4bf496900cb7b")

