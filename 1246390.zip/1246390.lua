-- Lua provided by RyzenAPI
-- Game: 1246390

-- MAIN APPLICATION
addappid(1246390)
-- Game: addappid(1246390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1246391, 1, "cd10ee84512b1080a98ae279aea4eb04f5a6e1561e13e17b5ef4bf496900cb7b")
