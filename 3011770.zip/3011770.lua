-- Lua provided by RyzenAPI
-- Game: Rubbings Demo

-- MAIN APPLICATION
addappid(3011770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3011771, 1, "3b21113f3a3709d489b012f059753f436ac1202ccf2aed4b17aef2a9ef0366bf")
