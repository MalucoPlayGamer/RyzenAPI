-- Lua provided by SkyAPI 
-- Game: AppID 3011770
addappid(3011770)
addappid(3011771, 1, "3b21113f3a3709d489b012f059753f436ac1202ccf2aed4b17aef2a9ef0366bf")
