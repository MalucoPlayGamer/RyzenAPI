-- Lua provided by RyzenAPI
-- Game: Game: Chloé’s Requiem -encore-

-- MAIN APPLICATION
addappid(2320500)
-- Game: addappid(2320500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2320501, 1, "76c51cc5b8972b9978814647f1fcfb0e98497fdd4b334d3abf0ff9241ff4023e")
