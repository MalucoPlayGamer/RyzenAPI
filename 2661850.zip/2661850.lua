-- Lua provided by RyzenAPI 
-- Game: AppID 2661850
addappid(2661850)
addappid(2661851, 1, "83aa977f6511eb9ca613c52c4046531be39a457e51c683c272082ecc9858c095")
