-- Lua provided by RyzenAPI
-- Game: AppID 2661850

-- MAIN APPLICATION
addappid(2661850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2661851, 1, "83aa977f6511eb9ca613c52c4046531be39a457e51c683c272082ecc9858c095")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
