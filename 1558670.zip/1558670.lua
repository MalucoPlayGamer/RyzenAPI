-- Lua provided by RyzenAPI
-- Game: Survive The Dark

-- MAIN APPLICATION
addappid(1558670)
-- Game: addappid(1558670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558671, 1, "448e1673c4e2ac7b2a338d57149286383053012268f29efe78dda8612203c456")
