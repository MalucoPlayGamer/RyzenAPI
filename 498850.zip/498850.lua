-- Lua provided by RyzenAPI
-- Game: Game: Ortus Arena, strategy board game online, FOR FREE

-- MAIN APPLICATION
addappid(498850)
-- Game: addappid(498850)

-- MAIN APP DEPOTS / PACKAGES
addappid(498851, 1, "6cfa6eee492cb7a050828b4f010ed086b553c1639692b7501fa801716c633c54")
