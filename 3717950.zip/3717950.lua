-- Lua provided by RyzenAPI
-- Game: Rune Factory: Guardians of Azuma - Art Book

-- MAIN APPLICATION
addappid(3717950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3717950,0,"b12e4d792b17735ff82a052e418ef9f13f6d10a415e43c14c5f636d5a6494a7e")

