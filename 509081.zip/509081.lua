-- Lua provided by RyzenAPI
-- Game: CLANNAD - Mabinogi Arrange Album

-- MAIN APPLICATION
addappid(509081)

-- MAIN APP DEPOTS / PACKAGES
addappid(509081,0,"665ab0db87bcf73b830feaa76ca6c8b9acb067ba4ef39dd005d444527125a376")
addappid(2058550,0,"86bd283578c62eb1f41a7a72bec1e9724442450c70bcd599783e7878737c85ef")
