-- Lua provided by RyzenAPI
-- Game: addappid(1056470)

-- MAIN APPLICATION
addappid(1056470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056471, 1, "a89a70514a791e0bc64ed5759f26e5096747bde0eb43179f0e9c6479a3089bc6")
