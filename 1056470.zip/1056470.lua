-- Lua provided by SkyAPI 
-- Game: AppID 1056470
addappid(1056470)
addappid(1056471, 1, "a89a70514a791e0bc64ed5759f26e5096747bde0eb43179f0e9c6479a3089bc6")
