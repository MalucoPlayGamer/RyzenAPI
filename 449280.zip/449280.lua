-- Lua provided by RyzenAPI
-- Game: DinoOps

-- MAIN APPLICATION
addappid(449280)

-- MAIN APP DEPOTS / PACKAGES
addappid(449281, 1, "aecd6e768a9db6753f3bf6bce19055931e2cd7306c6014bb2e4f7d035272438d")

