-- Lua provided by RyzenAPI
-- Game: Game: Find Girl | 发现女孩

-- MAIN APPLICATION
addappid(1564630)
-- Game: addappid(1564630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564631, 1, "5cabb9c74ab791f471357f45667171a8c38c666bda52594f009417701a6c0d18")
