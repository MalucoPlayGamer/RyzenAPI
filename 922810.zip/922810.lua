-- Lua provided by RyzenAPI
-- Game: MeatPossible: Chapter 1.5

-- MAIN APPLICATION
addappid(922810)

-- MAIN APP DEPOTS / PACKAGES
addappid(922811, 1, "e4d39ee4ed499dae6602643ec768a0d5e4de95100a6014d48830fa31718a9b91")
addappid(922812, 1, "f5e1b6c2cf265f18fc7185839cdb8f67d81dec92efc75d5bbe3d0fb1eef4e777")
addappid(922813, 1, "880fc891b3027f28eec0fe4d2c5613ff45561dc81b44769c0500fa284bafdb67")
addappid(922814, 1, "2a8dd2a7ca87619d1d1daee38e1ee2f12590101de9c9062e65d3676ed9c7e92a")
addappid(922815, 1, "e4bc150a61c2887c1dd50a98adbce27a79c365c6f671e41f40fe7b33bd60c82e")
