-- Lua provided by RyzenAPI
-- Game: 3028630

-- MAIN APPLICATION
addappid(3028630)
-- Game: addappid(3028630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3028631, 1, "2f82863422c7624dcbc186eaf724e1d009f01d0e620b45fd3a0611e86111caf9")
