-- Lua provided by SkyAPI 
-- Game: Surmount: A Mountain Climbing Adventure
addappid(1675000)
addappid(1675001, 1, "22a8912a0dce71ac70d0f5a8f5291a7c609922adb1883e0d8b6f74fdc481cf1d")
