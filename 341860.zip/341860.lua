-- Lua provided by RyzenAPI
-- Game: AppID 341860

-- MAIN APPLICATION
addappid(341860)

-- MAIN APP DEPOTS / PACKAGES
addappid(341861, 1, "df4cfb0bb1aa23b7f3d50343143c49b6e4be0894e4154752c7bf1d0cd92e0a19")
addappid(341862, 1, "e4660e7411b1cedb1151024196764a9d3c6324e307bdc1d31b6ba343eb0bbad2")
addappid(341863, 1, "b1e994c34f6bb8fd1962d39769a7b747555b176352d95933a08a77f96ce3557d")
addappid(341864, 1, "2a7e1c3e449b5920660dbc467a08b6bfc7ba6e60e0ff0601b6be46be8de9bc05")
addappid(571300, 0, "3323d5732c6cd2f8fadbe52696ef3c7b046c7eb0c2a6629686ff9f588061d219")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
