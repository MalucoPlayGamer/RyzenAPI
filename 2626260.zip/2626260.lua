-- Lua provided by RyzenAPI
-- Game: addappid(2626260)

-- MAIN APPLICATION
addappid(2626260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626261, 1, "f71902f52515c79380ef4e0d0acd2fec709236a3aedf78a7e39ee21aa54d02b9")
