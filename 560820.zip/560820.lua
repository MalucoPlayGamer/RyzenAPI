-- Lua provided by SkyAPI 
-- Game: AppID 560820
addappid(560820)
addappid(560821, 1, "99797a18e63b3c7a90d4f300d6ead8a56957b3081babf2df6a90493eed8c59c1")
