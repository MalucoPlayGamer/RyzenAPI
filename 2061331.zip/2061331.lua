-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2061331)
addappid(2243751)
addappid(2243752)
addappid(2243753)
addappid(2243754)
addappid(2243755)
addappid(2243757)
addappid(2243758)
addappid(2243759)
addappid(2243761)
addappid(2243762)
addappid(2243763)
addappid(2243764)
addappid(2243765)
addappid(2243766)
addappid(2243767)
-- Game: addappid(2061331)

-- MAIN APP DEPOTS / PACKAGES
addappid(2061331,0,"7a9f814cf1b5668e22ee59ecb68f823142c2f484bf672b9dacdba118292940b1")
addappid(2243750,0,"964587931561dfedab19cbf5bee320011789faaabb83f2803ec7d97f51c7585f")
addappid(2243756,0,"53a93a641927bce7a1dec79866b8b03dd4f9451ea8d364f23535a032d534f6cd")
addappid(2243760,0,"48406d1c3d0c189ef05d2ecb545910810098f92256ebeb7558fac666dc814fcb")
