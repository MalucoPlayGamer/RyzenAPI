-- Lua provided by RyzenAPI
-- Game: Crumple Zone

-- MAIN APPLICATION
addappid(785760)

-- MAIN APP DEPOTS / PACKAGES
addappid(785761,0,"30a9fc6bcc882ce9ccfd9a23e3915bb38d1ddd22a6fb22afec4499da0c0620b5")

