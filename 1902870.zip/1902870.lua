-- Lua provided by RyzenAPI
-- Game: Vertical Kingdom

-- MAIN APPLICATION
addappid(1902870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1902871, 1, "db56532ce1d242159bbd67a35ce6ee34cc113852fa3e367570dc98d386b14579")
