-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2483490)
-- Game: addappid(2483490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2483490,0,"79fcc0b09ab9a9ef32b64de63623c91965222857fc2d2e9a9b668df06c666d18")
