-- Lua provided by RyzenAPI 
-- Game: AppID 1927250
addappid(1927250)
addappid(1927251, 1, "ccafab03da98d561afa82900991dcc5f7705eed249f75eb7aea6824c2be856c9")
