-- Lua provided by RyzenAPI
-- Game: addappid(1927250)

-- MAIN APPLICATION
addappid(1927250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1927251, 1, "ccafab03da98d561afa82900991dcc5f7705eed249f75eb7aea6824c2be856c9")
