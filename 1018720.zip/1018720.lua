-- Lua provided by RyzenAPI
-- Game: X-POINT

-- MAIN APPLICATION
addappid(1018720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018721, 1, "fdb74366a5a2ee993b777bfc47b263551fc126c40af2c2cb56fc2179b86d676b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
