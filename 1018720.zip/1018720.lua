-- Lua provided by RyzenAPI
-- Game: Game: X-POINT

-- MAIN APPLICATION
addappid(1018720)
-- Game: addappid(1018720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018721, 1, "fdb74366a5a2ee993b777bfc47b263551fc126c40af2c2cb56fc2179b86d676b")
