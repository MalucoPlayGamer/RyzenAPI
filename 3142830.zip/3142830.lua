-- Lua provided by RyzenAPI
-- Game: addappid(3142830)

-- MAIN APPLICATION
addappid(3142830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3142831, 1, "8e9db92c6f741ac1c66732fa1be8348c8c09867cb3c05df3c70b8513f806181e")
