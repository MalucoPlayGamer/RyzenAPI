-- Lua provided by RyzenAPI
-- Game: 1377300

-- MAIN APPLICATION
addappid(1377300)
-- Game: addappid(1377300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1377301, 1, "33dc514bc6fa16d5b9821a916f5b57519f715fb844882c694cc180a7781fbbc7")
