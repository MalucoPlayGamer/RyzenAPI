-- Lua provided by RyzenAPI
-- Game: Game: After Death

-- MAIN APPLICATION
addappid(713160)
-- Game: addappid(713160)

-- MAIN APP DEPOTS / PACKAGES
addappid(713161, 1, "63847f07cc0d6ca2533304965f3c8b43d66216dd3ded53558c67ff8cd6e6f676")
