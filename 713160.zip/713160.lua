-- Lua provided by RyzenAPI
-- Game: After Death

-- MAIN APPLICATION
addappid(713160)

-- MAIN APP DEPOTS / PACKAGES
addappid(713161, 1, "63847f07cc0d6ca2533304965f3c8b43d66216dd3ded53558c67ff8cd6e6f676")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
