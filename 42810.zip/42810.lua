-- Lua provided by RyzenAPI
-- Game: For The Glory: A Europa Universalis Game

-- MAIN APPLICATION
addappid(42810)

-- MAIN APP DEPOTS / PACKAGES
addappid(42811, 1, "c624ca5f2d8e7814a427471e93715296b308ad878d2cb7f3bf0182de5657aaa2")
