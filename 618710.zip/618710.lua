-- Lua provided by RyzenAPI
-- Game: Elminage ORIGINAL - Priestess of Darkness and The Ring of the Gods

-- MAIN APPLICATION
addappid(618710)

-- MAIN APP DEPOTS / PACKAGES
addappid(618711,0,"26a13174a44cb54c5d1e162c9359bd639eef92d489412d45e41ceccc44cd0207")

