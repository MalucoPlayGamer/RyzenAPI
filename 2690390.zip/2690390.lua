-- Lua provided by RyzenAPI
-- Game: Movavi Video Suite 2024 - Cyberpunk Overlay Pack

-- MAIN APPLICATION
addappid(2690390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2690390,0,"6e39dd876ec272b51842b86dfbd5bb94d0021034226da4eb602d5d6f16391795")

