-- Lua provided by SkyAPI 
-- Game: AppID 1234940
addappid(1234940)
addappid(1234941, 1, "46bab4b1f6fe608d024e2a79e0658f8965fbfe29f49b5c5c19d0a0a88ce5b399")
