-- Lua provided by RyzenAPI
-- Game: DFF NT: Golbez Starter Pack

-- MAIN APPLICATION
addappid(1022443)
-- Game: addappid(1022443)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022443,0,"3bb64e35fb08df98478bb52d8ccecc8b004d52f3bc8c0ad3b9e4131c94455495")
