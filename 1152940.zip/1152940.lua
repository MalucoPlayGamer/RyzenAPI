-- Lua provided by RyzenAPI
-- Game: Trails of the Black Sun

-- MAIN APPLICATION
addappid(1152940)
-- Game: addappid(1152940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1152941, 1, "a1404e8fe04707fa751d8a39abe8f0b49c7af4b9741e020b0bb7456a77e05dd7")
addappid(1152942, 1, "579a1151e54b1c9f0213d43f4839dba0823ed65de3c119163343a6907596979d")
