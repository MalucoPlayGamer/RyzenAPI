-- Lua provided by RyzenAPI
-- Game: Trails of the Black Sun

-- MAIN APPLICATION
addappid(1152940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1152941, 1, "a1404e8fe04707fa751d8a39abe8f0b49c7af4b9741e020b0bb7456a77e05dd7")
addappid(1152942, 1, "579a1151e54b1c9f0213d43f4839dba0823ed65de3c119163343a6907596979d")
