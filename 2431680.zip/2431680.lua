-- Lua provided by RyzenAPI
-- Game: AppID 2431680

-- MAIN APPLICATION
addappid(2431680)
-- Game: addappid(2431680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2431681, 1, "8f3475dbf59cb54d430f76325cedc36a35bbec63ad5fda19fe554ad8044c4ce1")
