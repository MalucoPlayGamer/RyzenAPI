-- Lua provided by RyzenAPI
-- Game: HeXen II

-- MAIN APPLICATION
addappid(9060)

-- MAIN APP DEPOTS / PACKAGES
addappid(9061, 1, "aa03e466ff2b46478a4d5ecc292065644f58c5efbd4116ad3af928308dc662f8")

