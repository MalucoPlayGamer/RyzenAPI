-- Lua provided by RyzenAPI
-- Game: Escape Academy Demo

-- MAIN APPLICATION
addappid(1987090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1987091, 1, "26371320271d9c71f777a0fcc67d5900929db3772507a12e117d5ea35acb530b")

