-- Lua provided by RyzenAPI
-- Game: addappid(1513510)

-- MAIN APPLICATION
addappid(1513510)
addappid(1513511)
addappid(1513512)
addappid(1513514)

-- MAIN APP DEPOTS / PACKAGES
addappid(1513513,0,"1f7c605563ba7c9e0d30f6a6a037cbee3c995d881bbe1b780ee4992016b3d764")
