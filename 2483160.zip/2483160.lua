-- Lua provided by RyzenAPI
-- Game: 2483160

-- MAIN APPLICATION
addappid(2483160)
-- Game: addappid(2483160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2483161, 1, "b17ea42108dc62c53fbea149ca350a47dc2c13205de5f2cddbd7909175fc6250")
