-- Lua provided by RyzenAPI
-- Game: Ben 10

-- MAIN APPLICATION
addappid(703180)

-- MAIN APP DEPOTS / PACKAGES
addappid(703181, 1, "7e020cecf56f7315a793d93c25a424c228c832fe45b04152ffc1692c1a6f7b2f")

