-- Lua provided by RyzenAPI
-- Game: Sir Noggin

-- MAIN APPLICATION
addappid(628360)

-- MAIN APP DEPOTS / PACKAGES
addappid(628362,0,"f87bb57a1430c0a5c9dbfca4da4686406a27ddbd159c5a620dc0f8003b2c513f")

