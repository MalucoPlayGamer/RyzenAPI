-- Lua provided by RyzenAPI
-- Game: Mark of the Deep - Supporter Pack

-- MAIN APPLICATION
addappid(3480440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3480441, 1, "a77215836227c0c0a7f67a64a3da77fa7e9c921460502930c0acecf424998318")

