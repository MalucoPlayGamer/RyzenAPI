-- Lua provided by RyzenAPI
-- Game: Jin & Jan

-- MAIN APPLICATION
addappid(3024110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3024111, 1, "e039cac416f5f69698c439b2219e0262bcb0df1c98e5ef0407bb03dd476635d9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
