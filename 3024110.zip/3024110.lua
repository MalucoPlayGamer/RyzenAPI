-- Lua provided by RyzenAPI
-- Game: Jin & Jan

-- MAIN APPLICATION
addappid(3024110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3024111, 1, "e039cac416f5f69698c439b2219e0262bcb0df1c98e5ef0407bb03dd476635d9")
