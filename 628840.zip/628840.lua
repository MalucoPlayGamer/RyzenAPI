-- Lua provided by RyzenAPI
-- Game: 628840

-- MAIN APPLICATION
addappid(628840)
-- Game: addappid(628840)

-- MAIN APP DEPOTS / PACKAGES
addappid(628841, 1, "b366b53c495f567d0b5f0c406054a533ee5d61bd019f5523a3c040335f1e6f3f")
