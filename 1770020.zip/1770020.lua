-- Lua provided by SkyAPI 
-- Game: Sex monsters for Clip maker
addappid(1770020)
addappid(1770021, 1, "34519e66826256cb1ea06ea3a98a83b9bfe16559c0d7b0ef5873c582cd7fb9f2")
