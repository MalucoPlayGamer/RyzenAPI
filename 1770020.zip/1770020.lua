-- Lua provided by RyzenAPI
-- Game: addappid(1770020)

-- MAIN APPLICATION
addappid(1770020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770021, 1, "34519e66826256cb1ea06ea3a98a83b9bfe16559c0d7b0ef5873c582cd7fb9f2")
