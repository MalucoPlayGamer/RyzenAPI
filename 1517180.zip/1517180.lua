-- Lua provided by RyzenAPI
-- Game: Game: Mindcop

-- MAIN APPLICATION
addappid(1517180)
-- Game: addappid(1517180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1517181, 1, "24c46be0da12d827d8f7b10575577ea3721057d13fb13116551918a7b97e2c13")
