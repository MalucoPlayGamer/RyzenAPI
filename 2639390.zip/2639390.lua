-- Lua provided by RyzenAPI 
-- Game: AppID 2639390
addappid(2639390)
addappid(2639391, 1, "fbfbbc838a8e83c9939ae941afc76dd5dab0417e32cb0d4cb6393568ff654667")
