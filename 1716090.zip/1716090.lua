-- Lua provided by RyzenAPI
-- Game: DIY Your Lady and Beat Her with a Love Hammer (PC)

-- MAIN APPLICATION
addappid(1716090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716090,0,"a58a05aaa050673c952545f934dd05967e3eb84319830edad5c49d59c732c24d")

