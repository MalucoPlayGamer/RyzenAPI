-- Lua provided by RyzenAPI
-- Game: Game: AppID 1147620

-- MAIN APPLICATION
addappid(1147620)
-- Game: addappid(1147620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147621, 1, "84f522c6f55ed66503ddbc56e2b1f3a60a746aa770ef75719703b353923b1ec4")
