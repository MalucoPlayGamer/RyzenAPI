-- Lua provided by RyzenAPI
-- Game: The lost dungeon of knight

-- MAIN APPLICATION
addappid(1147620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1147621, 1, "84f522c6f55ed66503ddbc56e2b1f3a60a746aa770ef75719703b353923b1ec4")
