-- Lua provided by RyzenAPI 
-- Game: AppID 1147620
addappid(1147620)
addappid(1147621, 1, "84f522c6f55ed66503ddbc56e2b1f3a60a746aa770ef75719703b353923b1ec4")
