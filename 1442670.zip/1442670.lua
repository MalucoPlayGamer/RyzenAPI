-- Lua provided by RyzenAPI
-- Game: Hamster Playground

-- MAIN APPLICATION
addappid(1442670)
addappid(2184750)
addappid(2646880)
addappid(2646890)
addappid(2646900)
addappid(2646910)
addappid(2646920)
addappid(2646930)
addappid(2646940)
addappid(2646950)
addappid(2646960)
addappid(2646980)
addappid(2646990)
addappid(2647000)
addappid(2647010)
addappid(2647020)
addappid(3119840)
addappid(3327290)
addappid(3676280)
addappid(3676290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1442671, 1, "9fdcc2dc1cf9b3627eae4a3f586dbf0390eeefd651ced0378bbf0d86db2d416b")
addappid(1442672, 1, "142507075cfb3b1ff3c26defb72a653a662a02033b90164069b8a24c2f93c3d0")
addappid(1442673, 1, "ef9d58329b1385542ad2f35c686bec23fdc5158ae73a07017101a74a4371d1e2")

