-- Lua provided by RyzenAPI
-- Game: 2137210

-- MAIN APPLICATION
addappid(2137210)
-- Game: addappid(2137210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2137211, 1, "156ca2c1af066d2290bce2450d20efd3b1ea0e413bd07982143c0a771c844754")
