-- Lua provided by RyzenAPI
-- Game: Game: Bitardia

-- MAIN APPLICATION
addappid(405010)
-- Game: addappid(405010)

-- MAIN APP DEPOTS / PACKAGES
addappid(405011, 1, "324c986d604a787b85a29cdf855e47b0db7f950938472639e017abbc355cadab")
