-- Lua provided by RyzenAPI
-- Game: Shattered Dimension Demo

-- MAIN APPLICATION
addappid(3253740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3253741, 1, "fe11e84e0a64446f761e314e50980ea8ea76f98477fd4523a43f15f70654b083")

