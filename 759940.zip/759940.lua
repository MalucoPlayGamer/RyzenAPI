-- Lua provided by RyzenAPI
-- Game: 前程似锦 Excellent Expectations

-- MAIN APPLICATION
addappid(759940)

-- MAIN APP DEPOTS / PACKAGES
addappid(759941, 1, "43b6735d03928a69a6ae96deb1ec2724d3108cfdae00a7ac53e7f1993b51228e")
addappid(759942, 1, "d2fdad03d5f0ddc695a6304e0cbca43aade345e37eea7e4ab85733b6c5fb5740")
addappid(759943, 1, "627e83c7f5da05dd72dbabf14b817c645b81a7fca9e897ab696c5bee5a6ab813")
addappid(759944, 1, "f90f855d0fb77dbd2b69351b81c25c3a2d76a1a842770f5b20588713b826d8cc")
addappid(759945, 1, "496dc65017d2a18ccd1ac8cbcf031e2e7b2b0e93ca45b35821772a61fc1234ae")
addappid(759946, 1, "b9aaa103ed974ef24deb31e197cc8f308bece37283fd30c690afeb50c9c6700c")

