-- Lua provided by RyzenAPI
-- Game: Big Adventure: Trip to Europe 5 - Collector's Edition

-- MAIN APPLICATION
addappid(2533980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2533982,0,"70b2ec85c422f7da61cc9355f8eb5367555cd68a40cbacdfed27948ef44e71f6")
addappid(2533985,0,"a391785fcf0578671859543b539485966772f444a3734b0e053645d7ca71275b")
