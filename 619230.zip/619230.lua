-- Lua provided by RyzenAPI
-- Game: VEmpire - The Kings of Darkness

-- MAIN APPLICATION
addappid(619230)

-- MAIN APP DEPOTS / PACKAGES
addappid(619231,0,"0c1b1e8b14f563e8d801890456225180dbc85f6d7936dc154cb3cf0f4ce17c78")

