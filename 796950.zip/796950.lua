-- Lua provided by RyzenAPI
-- Game: addappid(796950)

-- MAIN APPLICATION
addappid(796950)

-- MAIN APP DEPOTS / PACKAGES
addappid(796951, 1, "b06b36123ce630cc8a93b4d1427ffa1ad90351ea63334a35c7996c1d8e3cd52a")
