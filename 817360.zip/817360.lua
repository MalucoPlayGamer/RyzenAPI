-- Lua provided by RyzenAPI
-- Game: addappid(817360)

-- MAIN APPLICATION
addappid(817360)

-- MAIN APP DEPOTS / PACKAGES
addappid(817361, 1, "749cb5015fec2d7a106ee6d8a1b9d06b9c291e269c296de4520edf82b0348f65")
