-- Lua provided by SkyAPI 
-- Game: Trials® Rising
addappid(641080)
addappid(641081, 1, "bfea411507c36965ee98094f2ae5df471b0eb17d340851ac0a4307c7587d45d6")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
