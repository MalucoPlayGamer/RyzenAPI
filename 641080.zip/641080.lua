-- Lua provided by RyzenAPI
-- Game: Trials® Rising

-- MAIN APPLICATION
addappid(641080)
addappid(924180)
addappid(924181)
addappid(924182)
addappid(924183)
addappid(924184)
addappid(924185)
addappid(924840)
addappid(924841)
addappid(928770)
addappid(928771)
addappid(1309100)
addappid(1309101)
addappid(1309102)
addappid(1309103)

-- MAIN APP DEPOTS / PACKAGES
addappid(641081,0,"bfea411507c36965ee98094f2ae5df471b0eb17d340851ac0a4307c7587d45d6")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")

