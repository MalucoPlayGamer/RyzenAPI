-- Lua provided by SkyAPI 
-- Game: Christmas Drift - Delivery Simulator
addappid(3392670)
addappid(3392671, 1, "8684c566a7e2ce22aa6f4f4d4105ff2feb59d8e80be4630fd4aaed6bf7da7a69")
