-- Lua provided by RyzenAPI
-- Game: Shu

-- MAIN APPLICATION
addappid(528720)
addappid(535780)

-- MAIN APP DEPOTS / PACKAGES
addappid(528721, 1, "7fe260454a9b515329ac59410baefc1ae71fe94e88047f9f4db6abf48660921b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
