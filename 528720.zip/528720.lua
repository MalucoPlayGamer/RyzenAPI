-- Lua provided by RyzenAPI
-- Game: Shu

-- MAIN APPLICATION
addappid(528720)
addappid(535780)
-- Game: addappid(528720)

-- MAIN APP DEPOTS / PACKAGES
addappid(528721, 1, "7fe260454a9b515329ac59410baefc1ae71fe94e88047f9f4db6abf48660921b")
