-- Lua provided by RyzenAPI
-- Game: Peregrin

-- MAIN APPLICATION
addappid(573080)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(573081, 1, "fb510032c6228d6224079654559ea2cb379d65c5b0df2b583a48ceccd0c34e86")

