-- Lua provided by RyzenAPI
-- Game: AppID 573080

-- MAIN APPLICATION
addappid(573080)
-- Game: addappid(573080)

-- MAIN APP DEPOTS / PACKAGES
addappid(573081, 1, "fb510032c6228d6224079654559ea2cb379d65c5b0df2b583a48ceccd0c34e86")
