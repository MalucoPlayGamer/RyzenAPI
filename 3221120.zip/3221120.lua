-- Lua provided by RyzenAPI
-- Game: 3221120

-- MAIN APPLICATION
addappid(3221120)
-- Game: addappid(3221120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3221121, 1, "176995870810f2d40d313729dd2626bdb3bccf9db0df7554a3103815eea07d7b")
