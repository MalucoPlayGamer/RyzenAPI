-- Lua provided by RyzenAPI
-- Game: Game: The Agony

-- MAIN APPLICATION
addappid(568720)
-- Game: addappid(568720)

-- MAIN APP DEPOTS / PACKAGES
addappid(568721, 1, "fcaf16560f6278df565d708d3bf80bfa9c5cc5e88b62e5b4d95dfaa45a11280e")
addappid(568722, 1, "fa6d1c928560c362b02f9b4322f551202c97cac78f3b1d55ae996226f6a34023")
