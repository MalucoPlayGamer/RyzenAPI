-- Lua provided by RyzenAPI
-- Game: addappid(1921550)

-- MAIN APPLICATION
addappid(1921550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921551, 1, "9c22da604a143fd018587708fd3acb9e6b7b73fa80c4e033af753e1988da5577")
