-- Lua provided by RyzenAPI 
-- Game: 缠罗深梦
addappid(2557940)
addappid(2557941, 1, "24be9799cad08f83a46269b392f5cce75055fd5922e9d878269a8000e255494a")
