-- Lua provided by RyzenAPI
-- Game: 378270

-- MAIN APPLICATION
addappid(378270)
-- Game: addappid(378270)

-- MAIN APP DEPOTS / PACKAGES
addappid(378271, 1, "f81f704398feb1d2ae1054d3daadc3ee88ff894a090a8c57b5fbe0160521f6e1")
