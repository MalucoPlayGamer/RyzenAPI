-- Lua provided by RyzenAPI
-- Game: AppID 862210

-- MAIN APPLICATION
addappid(862210)
-- Game: addappid(862210)

-- MAIN APP DEPOTS / PACKAGES
addappid(862211, 1, "2b045fdc58f87acb5dbfa275be3d67b60c49a43d0c13d1add6df07803f821a25")
