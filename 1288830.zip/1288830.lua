-- Lua provided by RyzenAPI
-- Game: addappid(1288830)

-- MAIN APPLICATION
addappid(1288830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1288831, 1, "ec1e411f18af796502c0800fc9f08e716eb459c75a4244c92fcf140e0bac955f")
