-- Lua provided by RyzenAPI
-- Game: Push The Box 3D

-- MAIN APPLICATION
addappid(1549620)
-- Game: addappid(1549620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549621, 1, "8268efc685fe76acc6fb85fe0693c6e6c9a97b4c7ebaf33c81361f0fdac78d37")
