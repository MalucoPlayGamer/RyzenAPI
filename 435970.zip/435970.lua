-- Lua provided by RyzenAPI
-- Game: RefRain - prism memories -

-- MAIN APPLICATION
addappid(435970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(435971, 1, "54a94bce7ba60c4aa0627d06867d751dd2589ee699eb1075260b5046480cd17d")
addappid(485010, 0, "cecd5bb1a9dcfc2dc76bae8504b04ccc1671c23bfa7c7104317c2fd46c1a9728")

