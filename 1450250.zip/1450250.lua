-- Lua provided by RyzenAPI
-- Game: addappid(1450250)

-- MAIN APPLICATION
addappid(1450250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450251, 1, "093183dd2764e9a1d02409f726dcb2ba2cff191ed4debe9cd2f02c949ba837b7")
