-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Add-on: Aerosoft - Airport Marseille

-- MAIN APPLICATION
addappid(2427060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2427060,0,"53110e8ce2688d55eca61770b8f72041d6d62e988c3b5879a0cbac21cab1a86a")

