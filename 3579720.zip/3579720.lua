-- Lua provided by RyzenAPI
-- Game: Game: World War II Armored Recon

-- MAIN APPLICATION
addappid(3579720)
-- Game: addappid(3579720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3579721, 1, "63ffe1f26fa65d2d9af753d533d2b834af80e7b41de2e29477ecd3bef86de413")
