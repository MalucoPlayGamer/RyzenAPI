-- Lua provided by RyzenAPI
-- Game: Game: OmegaBot

-- MAIN APPLICATION
addappid(1620850)
-- Game: addappid(1620850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620851, 1, "a03018a3711ba62052b91480fc6136313754686b980afb7f21f89b0ee643b375")
