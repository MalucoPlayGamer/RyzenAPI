-- Lua provided by RyzenAPI
-- Game: War Blade Demo

-- MAIN APPLICATION
addappid(228990)
addappid(933580)
addappid(933582)
addappid(933583)

-- MAIN APP DEPOTS / PACKAGES
addappid(392041,0,"606caa3c4dd52f52d6315d13e6ece6bb656c26ef1b38b30fa06e57987db7773c")

