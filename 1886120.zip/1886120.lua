-- Lua provided by RyzenAPI
-- Game: Voice of Chernobyl

-- MAIN APPLICATION
addappid(1886120)
-- Game: addappid(1886120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1886121, 1, "2b53011f8a6931ac605e20e9dc6535bc22d1d0ee87883be8585b563c6959c3ff")
