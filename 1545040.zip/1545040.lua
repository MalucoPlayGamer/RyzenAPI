-- Lua provided by RyzenAPI
-- Game: Jump/Die/Live

-- MAIN APPLICATION
addappid(1545040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545041, 1, "e9c762ecc4437534ea3cf413e1e942cdf8e59e74cfc0c859c5c478166aa508a5")

