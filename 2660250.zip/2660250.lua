-- Lua provided by RyzenAPI
-- Game: 49 Keys

-- MAIN APPLICATION
addappid(2660250)
-- Game: addappid(2660250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660251, 1, "a4944ed12c611d0d48e575c1920d250e645fdb6df55be4e853c61daedaf27323")
