-- Lua provided by RyzenAPI 
-- Game: AppID 2063890
addappid(2063890)
addappid(2063891, 1, "a7091c021ff13a4c86a9795a36cd89d821cf3a580251c5f7cfeb49f44728daf4")
