-- Lua provided by RyzenAPI
-- Game: Inside The Gear

-- MAIN APPLICATION
addappid(333120)

-- MAIN APP DEPOTS / PACKAGES
addappid(333121, 1, "c303bfed6e752d3c050238f60be42617400409fdb063e6e324e0bb088143f848")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
