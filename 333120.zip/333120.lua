-- Lua provided by RyzenAPI
-- Game: addappid(333120)

-- MAIN APPLICATION
addappid(333120)

-- MAIN APP DEPOTS / PACKAGES
addappid(333121, 1, "c303bfed6e752d3c050238f60be42617400409fdb063e6e324e0bb088143f848")
