-- Lua provided by RyzenAPI
-- Game: Game: AppID 533540

-- MAIN APPLICATION
addappid(533540)
-- Game: addappid(533540)

-- MAIN APP DEPOTS / PACKAGES
addappid(533541, 1, "2754a1f6814771a5d95e5a7c6b81587ef1e36d373fd9918150610a8711ef0236")
