-- Lua provided by RyzenAPI
-- Game: Workplace Fantasy - Raina's ending

-- MAIN APPLICATION
addappid(2626400)
-- Game: addappid(2626400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626400,0,"9faaeab00864fc722e7ba01773578d2f988824fc3b82aad4aa798787b5bf5a0b")
