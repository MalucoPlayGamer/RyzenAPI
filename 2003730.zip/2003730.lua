-- Lua provided by RyzenAPI
-- Game: Game: The Fantasy World of Mahjong Princess: General Version

-- MAIN APPLICATION
addappid(2003730)
-- Game: addappid(2003730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2003731, 1, "b0b55c3b90a2c0f4c91f7b8a5659907334a9c417d47419b83219c4c27a09e416")
