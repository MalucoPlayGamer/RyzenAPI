-- Lua provided by RyzenAPI
-- Game: 736570

-- MAIN APPLICATION
addappid(736570)
-- Game: addappid(736570)

-- MAIN APP DEPOTS / PACKAGES
addappid(736571, 1, "af3193bd621d54f4ad8d049e0af8a60d5a834149b44421c3c48042ce6460f115")
addappid(736572, 1, "f2162ca0c47b0ba12b171bedf77abaf413d81b2870615dc914485c7e1816265d")
addappid(736573, 1, "41416f65545eca70aa5643e74dbc9a1456c424f071db9b41016ac24530bb137e")
addappid(736574, 1, "4d221ae18d32a07c57b49cd6df264f9cd603fafe1d969d13ecfe4ea10fa2fff4")
addappid(736575, 1, "408c903cccea0eba197332cfc0b0bfceab7e162d43f6fc43dcf0a9b9d959f052")
addappid(736576, 1, "8505289feb84f8ebe1259db14d5bd5d2b98284e480d9ab3bc9515dbfd0ca248b")
