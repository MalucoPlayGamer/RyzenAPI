-- Lua provided by SkyAPI 
-- Game: AppID 631830
addappid(631830)
addappid(631831, 1, "c61d1db22069843cbc0a010a0bc180a932a6e4d8d73615b25e4bb5d82b7cbdb8")
