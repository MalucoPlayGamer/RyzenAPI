-- Lua provided by RyzenAPI
-- Game: Game: AppID 507210

-- MAIN APPLICATION
addappid(507210)
-- Game: addappid(507210)

-- MAIN APP DEPOTS / PACKAGES
addappid(507211, 1, "ca1b19208fbc5ac231e77f3d612f8db44296244e3b3cd350b3db6356fe7a08ad")
addappid(507212, 1, "f0e45bda725d6bc17c2779ae8d141a805e33b905f65953a985512ff0cdfb4bdd")
addappid(507213, 1, "16a9eee429596d3d0ba4bd9d1132f9689fb6ff8812637e9ca34b5a0e022a2f6a")
