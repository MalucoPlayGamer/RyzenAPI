-- Lua provided by RyzenAPI
-- Game: Chess Royal

-- MAIN APPLICATION
addappid(2371670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2371671, 1, "40cde46b1ddc06ea52e16c23891ebd9259471435a337f5ca7710809fc8786984")
