-- Lua provided by RyzenAPI 
-- Game: Culling of Normality
addappid(2904860)
addappid(2904861, 1, "6f3aef27a0cac0a799fdfbc2e94fc5db22c62fdc7557054a69e27ef61be264f9")
