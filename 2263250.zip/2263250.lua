-- Lua provided by RyzenAPI
-- Game: A Song Of Sunlight

-- MAIN APPLICATION
addappid(2263250)
