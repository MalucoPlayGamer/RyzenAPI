-- 2600970's Lua and Manifest Created by Hubcap Manifest
-- Flawed Tactics
-- Created: July 30, 2026 at 09:51:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2600970, 1, "5e45f8a0140f363512235b0a5760b1dc820094562b6be564fb22635dbdd251c5") -- Flawed Tactics
-- MAIN APP DEPOTS
addappid(2600971, 1, "4e1dbbb5fc997d75c4a3e08e801067f16bc74ab4492612c20942d4aecad1867e") -- Depot 2600971
setManifestid(2600971, "4184444245557449607", 1769039923)