-- Lua provided by RyzenAPI
-- Game: Ghostist

-- MAIN APPLICATION
addappid(1552760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1552761, 1, "2f4e3307147fe791927f30556ef363097dff4d56d72d8adc1b23fb8c1282e15f")
