-- Lua provided by RyzenAPI
-- Game: addappid(2842830)

-- MAIN APPLICATION
addappid(2842830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2842831, 1, "3a99d7132d655823a40bb0f5fa3bb0eeb228af9bfd5a46459fce5e69a173735c")
