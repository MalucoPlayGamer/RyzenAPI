-- Lua provided by RyzenAPI
-- Game: Game: AppID 398620

-- MAIN APPLICATION
addappid(398620)
-- Game: addappid(398620)

-- MAIN APP DEPOTS / PACKAGES
addappid(398621, 1, "5641bb063cd824691f8d3b8ee401756a53cc8f69d78257cc2511035dc13d9708")
addappid(398622, 1, "6df96922e0eb28c98d2cc304de7523aa2df9abd98c8c2b924c1744a9e76f6f3e")
addappid(398623, 1, "324bf05caf56bd3d96c56a098efd7a5c2c16ad6d8429925bae244d55ecd91dc7")
addappid(398624, 1, "85d5b0adbecefb44854e59fefd890b8b54888c2e7fe029f6b7e1d96f757d9ae1")
addappid(398625, 1, "76fddcb899988d1400449c8228d97d09921f8ed54ccd8ceb9666c96061ff6f77")
