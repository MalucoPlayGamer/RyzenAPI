-- Lua provided by RyzenAPI
-- Game: LAST WAR 2044

-- MAIN APPLICATION
addappid(804460)

-- MAIN APP DEPOTS / PACKAGES
addappid(804461, 1, "71352dd86aed88395c1846691ab95d12a0f641ea0dfe75d774f49dc015806d5d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
