-- Lua provided by RyzenAPI
-- Game: Game: LAST WAR 2044

-- MAIN APPLICATION
addappid(804460)
-- Game: addappid(804460)

-- MAIN APP DEPOTS / PACKAGES
addappid(804461, 1, "71352dd86aed88395c1846691ab95d12a0f641ea0dfe75d774f49dc015806d5d")
