-- Lua provided by RyzenAPI
-- Game: addappid(2520950)

-- MAIN APPLICATION
addappid(2520950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2520951, 1, "3d6600c30553c3cf15f4cc6d6412cd2b1b4c9acbcf3ef1a8bc526a2168a25e11")
addappid(2520952, 1, "3964fe440289eddf37385c9e26e54ff800b3f03e78115ff0622e1b5ce658deed")
