-- Lua provided by RyzenAPI
-- Game: The Light in the Darkness

-- MAIN APPLICATION
addappid(2520950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2520951, 1, "3d6600c30553c3cf15f4cc6d6412cd2b1b4c9acbcf3ef1a8bc526a2168a25e11")
addappid(2520952, 1, "3964fe440289eddf37385c9e26e54ff800b3f03e78115ff0622e1b5ce658deed")

