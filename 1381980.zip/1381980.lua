-- Lua provided by RyzenAPI
-- Game: AppID 1381980

-- MAIN APPLICATION
addappid(1381980)
-- Game: addappid(1381980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1381981, 1, "08a595e4f1eab1caafaee514a4e2317a9790aa310576c306d5bd992bf697aaef")
