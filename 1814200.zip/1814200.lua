-- Lua provided by RyzenAPI
-- Game: He Will Shoot

-- MAIN APPLICATION
addappid(1814200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814201, 1, "277bcd1f67b771bee13708134efea2ebda3d0d0a0fd4f1ffd16686edd651f266")
