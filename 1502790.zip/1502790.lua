-- Lua provided by RyzenAPI
-- Game: Gun Witch

-- MAIN APPLICATION
addappid(1502790)
addappid(1503650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502791, 1, "4fa96be7b657e3e5dd52d6b74a8fa796d7d3478f56769bee8954117de0a2b2e9")
