-- Lua provided by RyzenAPI
-- Game: 1464390

-- MAIN APPLICATION
addappid(1464390)
-- Game: addappid(1464390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1464391, 1, "f47c920c374ed2dce6b4b32a9d1a0f931963f84ba113043bc0286995527c7d99")
