-- Lua provided by RyzenAPI
-- Game: Game: IRON REBELLION

-- MAIN APPLICATION
addappid(1192900)
-- Game: addappid(1192900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1192901, 1, "fb618fb08fc5b7a271ef9017703b9366009522ea6df61715a625b474de1686ea")
