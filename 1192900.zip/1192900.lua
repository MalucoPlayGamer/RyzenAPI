-- Lua provided by RyzenAPI 
-- Game: IRON REBELLION
addappid(1192900)
addappid(1192901, 1, "fb618fb08fc5b7a271ef9017703b9366009522ea6df61715a625b474de1686ea")
