-- Lua provided by RyzenAPI
-- Game: AppID 1270990

-- MAIN APPLICATION
addappid(1270990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1270991, 1, "cdf67e7ea01ba43047fb7e3a5c197d72268ebae2334ffe46c47df739de58cd39")
