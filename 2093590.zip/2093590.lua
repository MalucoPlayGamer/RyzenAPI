-- Lua provided by RyzenAPI
-- Game: 2093590

-- MAIN APPLICATION
addappid(2093590)
-- Game: addappid(2093590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2093591, 1, "ce6ec72df2039050995218e7bb3e4d6e6dbc00d3b109a5c3f7720ab8a7380a1a")
