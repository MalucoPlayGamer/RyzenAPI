-- Lua provided by RyzenAPI
-- Game: Momodora: Reverie Under the Moonlight OST

-- MAIN APPLICATION
addappid(449360)
-- Game: addappid(449360)

-- MAIN APP DEPOTS / PACKAGES
addappid(449360,0,"187e274d27784e401ecacc4ba58c329633fd917ad6dfd1b8d96c9a5459cb1daf")
