-- Lua provided by SkyAPI 
-- Game: Geneticognito
addappid(655490)
addappid(655491, 1, "30a5db11bf0a522d4dcccdb05176a2898a31f77ed3221b579f10b7f5cc702167")
