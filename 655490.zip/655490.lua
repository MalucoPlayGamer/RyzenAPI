-- Lua provided by RyzenAPI
-- Game: Geneticognito

-- MAIN APPLICATION
addappid(655490)
-- Game: addappid(655490)

-- MAIN APP DEPOTS / PACKAGES
addappid(655491, 1, "30a5db11bf0a522d4dcccdb05176a2898a31f77ed3221b579f10b7f5cc702167")
