-- Lua provided by RyzenAPI
-- Game: Rogue Factory

-- MAIN APPLICATION
addappid(3212630) -- Rogue Factory

-- MAIN APP DEPOTS / PACKAGES
addappid(3212631, 1, "5300e98e510ec8b0c1d2c846c3edb14b5a805b8a1946b83b904a90b6c392cb61") -- Depot 3212631

