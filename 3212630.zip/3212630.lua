-- 3212630's Lua and Manifest Created by Hubcap Manifest
-- Rogue Factory
-- Created: February 05, 2026 at 04:25:02 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3212630) -- Rogue Factory
-- MAIN APP DEPOTS
addappid(3212631, 1, "5300e98e510ec8b0c1d2c846c3edb14b5a805b8a1946b83b904a90b6c392cb61") -- Depot 3212631
--setManifestid(3212631, "8884605346279291515", 223540615)