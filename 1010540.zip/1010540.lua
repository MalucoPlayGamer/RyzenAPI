-- Lua provided by RyzenAPI
-- Game: Game: AppID 1010540

-- MAIN APPLICATION
addappid(1010540)
-- Game: addappid(1010540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010541, 1, "3935acd140ae6c9b69d7dd015d1ab47e3a8de8940251dad9ac04791a6454c6b0")
