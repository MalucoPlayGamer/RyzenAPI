-- Lua provided by RyzenAPI
-- Game: Hell Cleaners

-- MAIN APPLICATION
addappid(4554270) -- Hell Cleaners

-- MAIN APP DEPOTS / PACKAGES
addappid(4554271, 1, "a7956655b7043f4e55bb5470c73252bd4b68c52030a32a781879d43a4104cff9") -- Depot 4554271

