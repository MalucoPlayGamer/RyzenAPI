-- 4554270's Lua and Manifest Created by Hubcap Manifest
-- Hell Cleaners
-- Created: August 24, 2026 at 13:19:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4554270) -- Hell Cleaners
-- MAIN APP DEPOTS
addappid(4554271, 1, "a7956655b7043f4e55bb5470c73252bd4b68c52030a32a781879d43a4104cff9") -- Depot 4554271
setManifestid(4554271, "754384431014841862", 764732500)