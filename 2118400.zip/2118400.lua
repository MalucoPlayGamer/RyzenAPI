-- Lua provided by RyzenAPI
-- Game: addappid(2118400)

-- MAIN APPLICATION
addappid(2118400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2118401, 1, "2f585689f79f5636f8027636024d246211bb0e68def6d81c36ab5fb1936cd6cb")
