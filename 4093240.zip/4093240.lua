-- Lua provided by RyzenAPI
-- Game: Tokyo Valkyries

-- MAIN APP DEPOTS / PACKAGES
addappid(4093240, 1, "995fc6bfadd5278635e4c50a58f1f804e04e5a9a996a75ba72516568e6e9b86c") -- Tokyo Valkyries
addappid(4093241, 1, "798eee11b2ab4f71937a86781b2aa2b2ef44abc5674620ad9a0320e342f138c2") -- Depot 4093241

