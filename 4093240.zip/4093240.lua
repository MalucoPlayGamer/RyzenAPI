-- 4093240's Lua and Manifest Created by Hubcap Manifest
-- Tokyo Valkyries
-- Created: August 13, 2026 at 11:16:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4093240, 1, "995fc6bfadd5278635e4c50a58f1f804e04e5a9a996a75ba72516568e6e9b86c") -- Tokyo Valkyries
-- MAIN APP DEPOTS
addappid(4093241, 1, "798eee11b2ab4f71937a86781b2aa2b2ef44abc5674620ad9a0320e342f138c2") -- Depot 4093241
setManifestid(4093241, "646461545089037460", 1194117072)