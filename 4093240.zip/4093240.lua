-- 4093240's Lua and Manifest Created by Hubcap Manifest
-- Tokyo Valkyries
-- Created: July 08, 2026 at 12:06:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4093240) -- Tokyo Valkyries
-- MAIN APP DEPOTS
addappid(4093241, 1, "798eee11b2ab4f71937a86781b2aa2b2ef44abc5674620ad9a0320e342f138c2") -- Depot 4093241
setManifestid(4093241, "8729121579081876299", 1192942677)