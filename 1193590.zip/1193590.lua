-- Lua provided by RyzenAPI
-- Game: Abomi Nation

-- MAIN APPLICATION
addappid(1193590)
-- Game: addappid(1193590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193591, 1, "6beccf240b7cd041a0f8c047861070685c77acdd7919d95535f6051b88087411")
