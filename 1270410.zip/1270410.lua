-- Lua provided by RyzenAPI
-- Game: Going Under Demo

-- MAIN APPLICATION
addappid(1270410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1270411, 1, "dd7fb33cf9a60e6d70575d470aa9d9277d7c0f7566c1e8fe98e5ed494b97be8d")
