-- Lua provided by RyzenAPI
-- Game: 941150

-- MAIN APPLICATION
addappid(941150)
addappid(995150)
-- Game: addappid(941150)

-- MAIN APP DEPOTS / PACKAGES
addappid(941151, 1, "1fef567658d0bf78cfc71fa72b34e63da2e52029ab913c9f8efc1af64f4e30a8")
