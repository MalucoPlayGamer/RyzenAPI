-- Lua provided by RyzenAPI 
-- Game: AppID 3241370
addappid(3241370)
addappid(3241371, 1, "45c665222684fd54b4d3055f398c2e7e339dfd2d4a6ad9c3c124673bc49112a4")
