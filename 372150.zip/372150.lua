-- Lua provided by RyzenAPI
-- Game: Yasai Ninja

-- MAIN APPLICATION
addappid(372150)
-- Game: addappid(372150)

-- MAIN APP DEPOTS / PACKAGES
addappid(372151, 1, "9e357fdd5f0e8369973c2a9a735e75d0ad5405a575d11c4a128bb69ea18063ca")
