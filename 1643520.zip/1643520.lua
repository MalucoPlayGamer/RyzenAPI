-- Lua provided by RyzenAPI
-- Game: Game: Mutant

-- MAIN APPLICATION
addappid(1643520)
-- Game: addappid(1643520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1643521, 1, "b3ec0291e1c96bf86ef3b152483b2abdc36685ca4dcdb36cced8f764a18f621e")
