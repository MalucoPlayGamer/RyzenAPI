-- Lua provided by RyzenAPI
-- Game: Plastic Playground

-- MAIN APPLICATION
addappid(458560)

-- MAIN APP DEPOTS / PACKAGES
addappid(458561, 1, "37ed01c298cee9dbb9a965291e98c20205c349993da8d8bb951b77b4613c7a22")
