-- Lua provided by RyzenAPI
-- Game: Disfigure

-- MAIN APPLICATION
addappid(2083160)
addappid(2497100)
-- Game: addappid(2083160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2083161, 1, "ab5d38b44afb84e371210fbd060536d5bdf40b2032c65c8de4eb54ca2f72e751")
