-- Lua provided by RyzenAPI
-- Game: addappid(609920)

-- MAIN APPLICATION
addappid(609920)

-- MAIN APP DEPOTS / PACKAGES
addappid(609921, 1, "841da19f9c4dbd845c65c4ca2a5ee49a5640ff5cebf496595f7ac59cc533414a")
addappid(609922, 1, "ba996086aae081ae22bbc64b96367a8aade0ab0f8204fad2a4dc386b6e3baebf")
addappid(609923, 1, "60269df9ad02bfb88f134c12cef3199c4ebfcb0bfed950c29de4597c4453a91f")
