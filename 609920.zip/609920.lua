-- Lua provided by RyzenAPI
-- Game: Hotshot Racing

-- MAIN APPLICATION
addappid(609920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(609921, 1, "841da19f9c4dbd845c65c4ca2a5ee49a5640ff5cebf496595f7ac59cc533414a")
addappid(609922, 1, "ba996086aae081ae22bbc64b96367a8aade0ab0f8204fad2a4dc386b6e3baebf")
addappid(609923, 1, "60269df9ad02bfb88f134c12cef3199c4ebfcb0bfed950c29de4597c4453a91f")

