-- Lua provided by RyzenAPI
-- Game: Game: 101 Cats in India

-- MAIN APPLICATION
addappid(3127270)
-- Game: addappid(3127270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3127271, 1, "bc08607921e5436a664283702442ed6cdc1ed8a0759fa561059f012e98c90951")
