-- Lua provided by RyzenAPI
-- Game: 3113130

-- MAIN APPLICATION
addappid(3113130)
-- Game: addappid(3113130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3113130,0,"d599bff2a5cf7c111a24f0fdceff1571f319bd064f49239e640c15c6356b8fd7")
