-- Lua provided by RyzenAPI
-- Game: Bakso Simulator

-- MAIN APPLICATION
addappid(2022270)
