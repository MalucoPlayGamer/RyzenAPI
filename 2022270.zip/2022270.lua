-- Lua provided by RyzenAPI
-- Game: Bakso Simulator

-- MAIN APPLICATION
addappid(2022270)
addappid(2066820)
addappid(2066930)
addappid(2066931)

