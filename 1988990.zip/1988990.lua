-- Lua provided by RyzenAPI
-- Game: Animals Transport Simulator

-- MAIN APPLICATION
addappid(1988990)
-- Game: addappid(1988990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988991, 1, "2641514a0059cf035dea7eaab8849ce415d3a538458029a8728219e209f9a9df")
