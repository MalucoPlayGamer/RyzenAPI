-- Lua provided by SkyAPI 
-- Game: Inside Soccer
addappid(1589480)
addappid(1589481, 1, "63f96bb25ff247737a8334cfe41e74e156f280eed035529198954c55df8761d3")
