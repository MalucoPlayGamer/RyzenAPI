-- Lua provided by RyzenAPI
-- Game: Game: Inside Soccer

-- MAIN APPLICATION
addappid(1589480)
-- Game: addappid(1589480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1589481, 1, "63f96bb25ff247737a8334cfe41e74e156f280eed035529198954c55df8761d3")
