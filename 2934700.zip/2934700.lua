-- Lua provided by RyzenAPI
-- Game: 2934700

-- MAIN APPLICATION
addappid(2934700)
-- Game: addappid(2934700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934701, 1, "9469a26f3358e6e316a725c9e80fd388cb5d8ec4a2b5b5dfe13080c5fe1e21f4")
