-- Lua provided by SkyAPI 
-- Game: Grit and Valor - 1949 Demo
addappid(2934700)
addappid(2934701, 1, "9469a26f3358e6e316a725c9e80fd388cb5d8ec4a2b5b5dfe13080c5fe1e21f4")
