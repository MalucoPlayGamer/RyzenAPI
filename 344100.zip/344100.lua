-- Lua provided by RyzenAPI
-- Game: Never Ending Night

-- MAIN APPLICATION
addappid(344100)

-- MAIN APP DEPOTS / PACKAGES
addappid(344101, 1, "8da6c72e2052431bd01e78658852361ef83cb3e8a8e0c7a21b2eae5863fb5019")
addappid(344102, 1, "20528a930ffeef7969a6e58fc890a40e97dafffb6754b9731c46656f676835e1")
addappid(344103, 1, "46ced331c0df42022bb18fa208f1604bdf61b160e0cde9937656879d70ffa88f")
addappid(344104, 1, "9afdb68c3400163be2adca1e332a93a2a8d05b7d82ff7ebf976cd7b09c692b81")

