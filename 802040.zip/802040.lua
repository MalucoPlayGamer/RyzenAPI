-- Lua provided by RyzenAPI
-- Game: Captive

-- MAIN APPLICATION
addappid(802040)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(802041, 1, "5b9fd8c5b48b201e0083f43753d05d7c6c29a5f565648749a96603e970227178")

