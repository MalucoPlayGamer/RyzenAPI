-- Lua provided by RyzenAPI 
-- Game: Captive
addappid(802040)
addappid(802041, 1, "5b9fd8c5b48b201e0083f43753d05d7c6c29a5f565648749a96603e970227178")
