-- Lua provided by RyzenAPI
-- Game: Game: Captive

-- MAIN APPLICATION
addappid(802040)
-- Game: addappid(802040)

-- MAIN APP DEPOTS / PACKAGES
addappid(802041, 1, "5b9fd8c5b48b201e0083f43753d05d7c6c29a5f565648749a96603e970227178")
