-- Lua provided by RyzenAPI
-- Game: Time Loader

-- MAIN APPLICATION
addappid(1301950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301951, 1, "93bf918193a64222bc78d3c8f2d563b2c92bd4a1abbab057af601f9275b0acc6")

