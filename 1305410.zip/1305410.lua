-- Lua provided by RyzenAPI
-- Game: Midsummer-Patch

-- MAIN APPLICATION
addappid(1305410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1305410,0,"f4e8cfce47761da18c8413f6f9093708660bcd9aa8fcca44b7fcf53058a17b6e")
addtoken(1305410,4066461885726751106)

