-- Lua provided by RyzenAPI
-- Game: Chorus

-- MAIN APPLICATION
addappid(1153640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153641, 1, "b4cb3c8e26f72b264958c8e1477606fbc5b2de35f9a07ffac2f1f5c1857ceaac")

