-- Lua provided by RyzenAPI
-- Game: Chorus

-- MAIN APPLICATION
addappid(1153640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153641, 1, "b4cb3c8e26f72b264958c8e1477606fbc5b2de35f9a07ffac2f1f5c1857ceaac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1797160)
