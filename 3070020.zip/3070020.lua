-- Lua provided by RyzenAPI
-- Game: Automaton Heart

-- MAIN APPLICATION
addappid(3070020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3070022,0,"f21d226c42ce710cfe91d099205ba0f07005dae7b9def55bb7333c69fc86101a")

