-- Lua provided by RyzenAPI
-- Game: Game: AppID 3212360

-- MAIN APPLICATION
addappid(3212360)
-- Game: addappid(3212360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3212361, 1, "bd9d74e96ce5d4d9472ec304285ab9c717ecc7e0e2d55f76b1009e717c1a4fa8")
