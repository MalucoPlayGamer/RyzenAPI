-- Lua provided by RyzenAPI
-- Game: Guacamelee! 2 - Soundtrack

-- MAIN APPLICATION
addappid(911610)

-- MAIN APP DEPOTS / PACKAGES
addappid(911610,0,"266a7cbc97f12aa1ef138b65e2c9066d473b591219bbd8f979bd1509a67cc26c")
