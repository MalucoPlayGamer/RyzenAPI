-- Lua provided by RyzenAPI
-- Game: Game: They Are Here Playtest

-- MAIN APPLICATION
addappid(2467730)
-- Game: addappid(2467730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467731, 1, "c97d7278f5db0ecdaa50a80e13d13603aca23ad4f5384ac12ab256770155431d")
