-- Lua provided by RyzenAPI
-- Game: addappid(9500)

-- MAIN APPLICATION
addappid(9500)

-- MAIN APP DEPOTS / PACKAGES
addappid(9501, 1, "be4554304697ed57c3b563dd6a1cd45b52525884c6e2184242cb94bd1cb52ca0")
