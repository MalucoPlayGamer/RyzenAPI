-- Lua provided by RyzenAPI
-- Game: Crossroad OS

-- MAIN APPLICATION
addappid(1783800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1783801, 1, "7117280a52b1a71434081523af8a290c7b9ed85af555d1d9687b8764ec4a77ec")

