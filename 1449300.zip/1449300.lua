-- Lua provided by RyzenAPI
-- Game: 1449300

-- MAIN APPLICATION
addappid(1449300)
-- Game: addappid(1449300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449301, 1, "68b2b9da90cb4aa19175deb4eb7ba1618cfe51b3e68db07dd7d03447372a71cc")
