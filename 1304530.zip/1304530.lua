-- Lua provided by RyzenAPI
-- Game: Sling-A-Thing

-- MAIN APPLICATION
addappid(1304530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304531, 1, "bb1e911c7eeb8d5ca730e521c15d5bd6609a04181ab33c9ab72a3081396c9cda")

