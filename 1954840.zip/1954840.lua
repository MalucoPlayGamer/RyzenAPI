-- Lua provided by RyzenAPI 
-- Game: Fractured Sanity
addappid(1954840)
addappid(1954841, 1, "ab30b0932811ff18579617cef5c058b719ee1d031b51ea0a885ba23907af9caa")
