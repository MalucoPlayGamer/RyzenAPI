-- Lua provided by RyzenAPI
-- Game: 818890

-- MAIN APPLICATION
addappid(818890)
-- Game: addappid(818890)

-- MAIN APP DEPOTS / PACKAGES
addappid(818891, 1, "b159af98ae25132b0ad40450a2a870d6d9d4ffda540308662b7802fd5cd94578")
