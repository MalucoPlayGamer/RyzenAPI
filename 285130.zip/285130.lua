-- Lua provided by RyzenAPI
-- Game: Battleplan: American Civil War

-- MAIN APPLICATION
addappid(285130)

-- MAIN APP DEPOTS / PACKAGES
addappid(285131, 1, "15aabd2d6da354a9b6ea8d8a6b4eeec88feabfb58aa11add9b18f83cf4995ddd")
