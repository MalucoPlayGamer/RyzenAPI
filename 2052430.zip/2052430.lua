-- Lua provided by RyzenAPI 
-- Game: Circles EP: Frostpunk Edition
addappid(2052430)
addappid(2052431, 1, "513ed1fc973a97d678b6c8cf80746562cdfae620baa329ba85ef5492c52eb73e")
addappid(2052432, 1, "493a44aa308d9627be62731cc6d20da66d88202d94359dfe3953391907db97b0")
