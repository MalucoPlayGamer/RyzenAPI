-- Lua provided by RyzenAPI
-- Game: 923840

-- MAIN APPLICATION
addappid(923840)
addappid(955140)
-- Game: addappid(923840)

-- MAIN APP DEPOTS / PACKAGES
addappid(923841, 1, "d1aebcbb900be690ce5dd01e70cd5ceb7d92f307efd274e47267d3d8153bc2d5")
