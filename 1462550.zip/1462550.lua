-- Lua provided by RyzenAPI
-- Game: addappid(1462550)

-- MAIN APPLICATION
addappid(1462550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462551, 1, "2453327fadc074b4e67a5e86d7216175406eb1b87252aeb03e759b3394b9c4cf")
