-- Lua provided by RyzenAPI
-- Game: The Talos Principle 2 Soundtrack

-- MAIN APPLICATION
addappid(2475690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2475691, 1, "29c31dd18666a2c7a425ca6b37ae0d7e3a53fce7dddf568ad75a784eb3c8ec07")

