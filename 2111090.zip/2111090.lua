-- Lua provided by RyzenAPI
-- Game: Let's! Revolution!

-- MAIN APPLICATION
addappid(2111090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2111091, 1, "6883c4db84318574bc0d4c527043e5c59cd6b61f466234d2fc8f00d0f38b5713")

