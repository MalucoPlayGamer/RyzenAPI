-- Lua provided by RyzenAPI
-- Game: Game: FREEDIVER: Triton Down

-- MAIN APPLICATION
addappid(995230)
-- Game: addappid(995230)

-- MAIN APP DEPOTS / PACKAGES
addappid(995231, 1, "4611c2ff3ea5dc17d276e351e647a8310d21295f651fa6620e1e987c11c98239")
