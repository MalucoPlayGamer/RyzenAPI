-- Lua provided by RyzenAPI
-- Game: FREEDIVER: Triton Down

-- MAIN APPLICATION
addappid(995230)

-- MAIN APP DEPOTS / PACKAGES
addappid(995231, 1, "4611c2ff3ea5dc17d276e351e647a8310d21295f651fa6620e1e987c11c98239")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
