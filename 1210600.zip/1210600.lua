-- Lua provided by RyzenAPI
-- Game: Trepang2 Demo

-- MAIN APPLICATION
addappid(1210600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210601, 1, "6d8fe1f9ef007690394542cd9885968321080310f4a85e48ca6b8ba1abec855e")
addappid(1210604, 1, "999873e7765b1c459aaaca7e4f9c8e5ef68fee1e6eca75bc1b0212b6599e9105")

