-- Lua provided by RyzenAPI
-- Game: Keine's Expanding Class!

-- MAIN APPLICATION
addappid(3894520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3894520,0,"6aa7019cbc1e680a3e0b1974ee00659cd4946332f8cc0100e8b8ede772aac70c")
addappid(3894521,0,"d31b020d21e3febbad2448ca8371f5e3f01c57bd214506a4a7e4c3489cfb6cdb")

