-- Lua provided by RyzenAPI
-- Game: Security: The Horrible Nights Demo

-- MAIN APPLICATION
addappid(3102770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3102771, 1, "09ade560c0429acf1b8be2372439686fe2c4c8531945c75b1e8b19f7286f8de3")

