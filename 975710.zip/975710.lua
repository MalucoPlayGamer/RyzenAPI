-- Lua provided by RyzenAPI
-- Game: Qipa World-Hello Big Adventure

-- MAIN APPLICATION
addappid(975710)

-- MAIN APP DEPOTS / PACKAGES
addappid(975711, 1, "808525d129dc6fbaac4b991d969e36c5b8f439a5ed1b92a2a01cf70af1fc9879")
