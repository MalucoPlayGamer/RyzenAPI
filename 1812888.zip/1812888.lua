-- Lua provided by RyzenAPI
-- Game: 1812888

-- MAIN APPLICATION
addappid(1812888)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812888,0,"0a6b3c05ab73d5d49f0b15f6ac03991ac4615d59bbeaa2fc8f1bfb24fe035761")
