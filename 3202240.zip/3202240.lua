-- Lua provided by RyzenAPI
-- Game: AppID 3202240

-- MAIN APPLICATION
addappid(3202240)
-- Game: addappid(3202240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3202241, 1, "b5fc2ee4ca63ce9615e26442d545cef22f4a697833a0dbdde38868d5291b7d11")
