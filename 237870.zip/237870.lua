-- Lua provided by RyzenAPI
-- Game: addappid(237870)

-- MAIN APPLICATION
addappid(237870)

-- MAIN APP DEPOTS / PACKAGES
addappid(237871, 1, "6fc4afd269e2281caeca0e387610cc26d605cff48a692a2c4876e73b15495b14")
addappid(237872, 1, "d79f6e26c0a1aa04b3feee30a528d26ac939dc876ed9b8a2d8bc0a5ac57398c2")
addappid(237873, 1, "96265842ff0bc400ac10142ca6a1e0f1ebcfbd9792f47629c3aa4aedc9f4c9aa")
addappid(237874, 1, "ebc4c8acebcbaa9b20a4256c06b09e93522feaa76d3fd2b44f4c0d3fac82be40")
addappid(237875, 1, "5893e1c857415c3c40aed99db4920328579ffac8a9fc06433702e385c436ac03")
addappid(237876, 1, "0d44cdd5a4c52b8f57ef02b18eeb938e24d1f6bdb02cef6248637307c2b3e598")
addappid(553700, 0, "d29f9ecf9934c13114979f0be731caf56fa515982b5715015ab5e48896ab134d")
