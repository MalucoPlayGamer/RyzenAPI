-- Lua provided by RyzenAPI
-- Game: AppID 314200

-- MAIN APPLICATION
addappid(314200)
-- Game: addappid(314200)

-- MAIN APP DEPOTS / PACKAGES
addappid(314201, 1, "8a6eb4ac63bc62de38999241e63073a24f397de5c9610cab1e12394daad8abbd")
