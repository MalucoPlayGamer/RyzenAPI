-- Lua provided by RyzenAPI
-- Game: 370100

-- MAIN APPLICATION
addappid(370100)
-- Game: addappid(370100)

-- MAIN APP DEPOTS / PACKAGES
addappid(370101, 1, "4a649a3598bf7f06c62d2cd3fa41fb9cfa1fcbc81985d307dc54a41d2e0e0012")
