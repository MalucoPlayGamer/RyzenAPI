-- Lua provided by SkyAPI 
-- Game: Redmatch 2
addappid(1280770)
addappid(1280771, 1, "889f9ec1ef54e9f75161518e1303743308888b0f3203899137908d83003ba482")
addappid(1280772, 1, "8a5f2eb2185211640a7e68b0a0a73edcac7b52b3f7fbc2cd57edeb0adc6f3796")
