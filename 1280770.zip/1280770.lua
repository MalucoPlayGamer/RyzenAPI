-- Lua provided by RyzenAPI
-- Game: Redmatch 2

-- MAIN APPLICATION
addappid(1280770)
addappid(1631890)
addappid(1729610)
addappid(1851250)
addappid(2154680)
addappid(2456220)
addappid(2605540)
addappid(2640340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280770,0,"472fc58c3af7ed40866cc429a19f4d629e7f92fbbffbd8d533543914ed4e8fd7")
addappid(1280771,0,"889f9ec1ef54e9f75161518e1303743308888b0f3203899137908d83003ba482")
addappid(1280772,0,"8a5f2eb2185211640a7e68b0a0a73edcac7b52b3f7fbc2cd57edeb0adc6f3796")

