-- Lua provided by RyzenAPI
-- Game: Byte The Bullet

-- MAIN APPLICATION
addappid(1888380)
-- Game: addappid(1888380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1888381, 1, "2971207f4e6053adace3f32cff2fbc1c81dd7f55361cef44e38d5d40db8bab06")
