-- Lua provided by RyzenAPI
-- Game: Byte The Bullet

-- MAIN APPLICATION
addappid(1888380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(1888381, 1, "2971207f4e6053adace3f32cff2fbc1c81dd7f55361cef44e38d5d40db8bab06")

