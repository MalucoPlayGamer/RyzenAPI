-- Lua provided by RyzenAPI
-- Game: SHE WAS 98

-- MAIN APPLICATION
addappid(3916300)
-- Game: addappid(3916300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3916301, 1, "6bf160f8b2cfdadfda1d5d87bcdf1c6a531e5af93c567e76bf71a4708ff122fa")
