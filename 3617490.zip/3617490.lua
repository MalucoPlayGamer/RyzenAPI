-- Lua provided by RyzenAPI
-- Game: Game: single spark

-- MAIN APPLICATION
addappid(3617490)
-- Game: addappid(3617490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3617491, 1, "68f6fb24af4f1649fb37bd3110b8176764031ffeb8b0b85c31f8a54aa79a851f")
