-- Lua provided by RyzenAPI
-- Game: addappid(313660)

-- MAIN APPLICATION
addappid(313660)

-- MAIN APP DEPOTS / PACKAGES
addappid(313661, 1, "4a5ecfd73000adf5652b8b6cd0840d37c8c3ca82e2641f90aa8d6493d87a7ae6")
