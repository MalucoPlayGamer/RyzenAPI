-- Lua provided by RyzenAPI
-- Game: Alea Jacta Est

-- MAIN APPLICATION
addappid(313660)
addappid(313800)
addappid(329550)
addappid(329551)
addappid(397380)
addappid(397381)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(313661, 1, "4a5ecfd73000adf5652b8b6cd0840d37c8c3ca82e2641f90aa8d6493d87a7ae6")
