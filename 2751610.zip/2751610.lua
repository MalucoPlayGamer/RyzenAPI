-- Lua provided by RyzenAPI
-- Game: Game: 闲侠江湖

-- MAIN APPLICATION
addappid(2751610)
-- Game: addappid(2751610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2751611, 1, "6a231bd167233c051f6035d2299acffde7f8922fc12d177d381f0828e835db84")
