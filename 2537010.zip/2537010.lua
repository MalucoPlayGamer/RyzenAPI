-- Lua provided by RyzenAPI
-- Game: MISTERY

-- MAIN APPLICATION
addappid(2537010)
-- Game: addappid(2537010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2537011, 1, "93216e5e4d6dc2a636ca63d1861ef4e448bf3296f40f79cc3827ddc939a0fb61")
