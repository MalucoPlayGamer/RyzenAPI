-- 4193800's Lua and Manifest Created by Hubcap Manifest
-- Hentai Clicker: Stella is streaming
-- Created: June 18, 2026 at 05:25:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4193800) -- Hentai Clicker: Stella is streaming
-- MAIN APP DEPOTS
addappid(4193801, 1, "b7dc5d2fc872571fdd541861558f261aba229bab9e1367249e66635fdd296012") -- Depot 4193801
setManifestid(4193801, "6225421579335005134", 175212969)