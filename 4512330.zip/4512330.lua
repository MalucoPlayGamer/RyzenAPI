-- Lua provided by RyzenAPI
-- Game: Pretty Girl Puzzle · Summer Phantom

-- MAIN APPLICATION
addappid(4512330)

-- MAIN APP DEPOTS / PACKAGES
addappid(4512331,0,"2a0aa4e9a4945b7fa489a2d2bdcf535460fd499b43ad58224a5fd6ce863db2cb")

