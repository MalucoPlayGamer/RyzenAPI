-- Lua provided by RyzenAPI
-- Game: Disney's Treasure Planet: Battle of Procyon

-- MAIN APPLICATION
addappid(331970)

-- MAIN APP DEPOTS / PACKAGES
addappid(331971, 1, "ee322aebf25c8bd834f2cd02d5ac9a84692122a11f366d1d6167fc1ac12bd77b")
addappid(331972, 1, "e306e604adbbb4b1cc3007f9b767852e94003addcae1bcd77102275c9d757517")
addappid(331973, 1, "2efac0444c269bf602cf1a7c3de70d3c33f0c73aaa7f7a9b1384b016c26ab917")
addappid(331974, 1, "203400d240809d849c5e51d1f84f3cd3d3d6774dbe55027f948b5adb3da82b80")
addappid(331975, 1, "7ee505f085f5394e46fd210d976d95d29aa55c7eeedecd9a8d72fb3575251126")
addappid(331976, 1, "1637a7593fcb0d42bfa68d4d3b30d5f4cc99b34ff9c51bb92a3aaacc4769f7eb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
