-- Lua provided by RyzenAPI 
-- Game: Floating Cuboid
addappid(2545810)
addappid(2545811, 1, "efcf1c779a470ca789613bf9e0a66e61f24431614571827b863db91b98660011")
