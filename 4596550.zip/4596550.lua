-- 4596550's Lua and Manifest Created by Hubcap Manifest
-- Aisle Survive
-- Created: July 28, 2026 at 23:15:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4596550) -- Aisle Survive
-- MAIN APP DEPOTS
addappid(4596551, 1, "856090b2431509ab9d7945be5d145e14b6cd187540f47bfb766aaadbc844182c") -- Depot 4596551
setManifestid(4596551, "7901579500089611042", 1434932014)
-- DLCS WITH DEDICATED DEPOTS
-- Aisle Survive - Keep the Change Supporter Pack (AppID: 4962060)
addappid(4962060)
addappid(4962060, 1, "4be0917bb3a83e02c4af27991a30adfb6dbeffff286eac6c67ee9cd5d1f3d24a") -- Aisle Survive - Keep the Change Supporter Pack - Depot 4962060
setManifestid(4962060, "2406921879385444109", 247969419)