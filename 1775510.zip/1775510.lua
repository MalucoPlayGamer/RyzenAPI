-- Lua provided by RyzenAPI
-- Game: Raiders of the Icepeak Mountains

-- MAIN APPLICATION
addappid(1775510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1775511,0,"18dd76e6e7ae3e6c14200580cdb602c0b7615356475c445b27417c3fdd023685")

