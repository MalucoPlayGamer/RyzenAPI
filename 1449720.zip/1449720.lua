-- Lua provided by RyzenAPI
-- Game: AppID 1449720

-- MAIN APPLICATION
addappid(1449720)
-- Game: addappid(1449720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449721, 1, "8a1cdb0870ffb5856753397f59eb657a6bd4c69157a1f18ce4df986a3b264839")
