-- Lua provided by RyzenAPI
-- Game: Brave survivors

-- MAIN APPLICATION
addappid(2106450)
-- Game: addappid(2106450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2106451, 1, "99b429fa06cb244f9d2ddec21aac3b9dd1db398472e86b3b87bcdbbd5bf327b0")
