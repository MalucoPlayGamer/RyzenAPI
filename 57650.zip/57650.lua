-- Lua provided by RyzenAPI
-- Game: addappid(57650)

-- MAIN APPLICATION
addappid(57650)
addappid(228982)
addappid(228983)
addappid(228990)
addappid(229002)

-- MAIN APP DEPOTS / PACKAGES
addappid(57651, 1, "1d0ef9d1c6906eb8159072c263ff4247b4633a0bce849c304d5efb2ae16d6e69")
addappid(57652, 1, "a0f190c1dc97d8d24eb7dbb098f1ab3578627fb1b04e77c7a969a3333e5fed78")
addappid(57653, 1, "76ad66ccffbc7f101a2dea06faf09a90f2576238f4faaa79599541d273bf1f38")
addappid(57654, 1, "7dc11fe7a3c4450b56312ab50f93d6ceb53bc818b1031139895f882205733c3c")
addappid(57655, 1, "2c1d35528725f84f985a0707da6c81489d35dcc71687f0ca9f491f76e63594e6")
addappid(57656, 1, "1f6226724cc73b617e574dd32bca0ba84cbbd2f93d4a5ee753bcd4f83d3398af")
