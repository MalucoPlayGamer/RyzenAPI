-- Lua provided by RyzenAPI 
-- Game: Hearts of Iron 2 Demo
addappid(22170)
addappid(22171, 1, "c72a434fa6bec514e8eff09fe6b09e513194a5bb7970977521a2e1c02822edb7")
