-- Lua provided by SkyAPI 
-- Game: Nemesis: Distress
addappid(1343620)
addappid(1343621, 1, "22aa5a3e3596cfea03dda51e5b3bc277e4b1b98584d62593b3a7e2555800fd70")
