-- Lua provided by RyzenAPI
-- Game: Nemesis: Distress

-- MAIN APPLICATION
addappid(1343620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1343621, 1, "22aa5a3e3596cfea03dda51e5b3bc277e4b1b98584d62593b3a7e2555800fd70")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
