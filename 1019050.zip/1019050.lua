-- Lua provided by RyzenAPI 
-- Game: Primal Threat
addappid(1019050)
addappid(1019051, 1, "6c20a09dca06525703c12ef141ca06b211775d157485eee5011778ccb18c138c")
addappid(1019052, 1, "51b95e0e77eba8760fa93404318d93192a53f3bbd91d45e1b1c2b3ffa326393d")
