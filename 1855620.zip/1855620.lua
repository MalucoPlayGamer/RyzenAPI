-- Lua provided by RyzenAPI
-- Game: setManifestid(1855622,"5634394934541705860")

-- MAIN APPLICATION
addappid(1855620)
-- Game: addappid(1855620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1855622,0,"ec34148209aa75d07da1d882d053529197e51b524961c9fffccefcf3116d6a44")
