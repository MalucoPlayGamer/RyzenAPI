-- Lua provided by RyzenAPI
-- Game: 2807360

-- MAIN APPLICATION
addappid(2807360)
-- Game: addappid(2807360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2807361, 1, "3cf0245bd1204328b2c089bea35a7ecbb0df0f4e7c0dcd1abfe45ea9bc66d4ef")
