-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin Glowing Crystal Pack

-- MAIN APPLICATION
addappid(2401980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2401980,0,"71a6f89d1bd176c466fbbf1c2e96a97339a04ced16b60cbaa1caf11263c8d998")
