-- Lua provided by RyzenAPI
-- Game: 789680

-- MAIN APPLICATION
addappid(789680)
-- Game: addappid(789680)

-- MAIN APP DEPOTS / PACKAGES
addappid(789681, 1, "da0b4b5bc243d3cfaf38ee97ac7c1692c029cad581ab30a067945ca108b08367")
