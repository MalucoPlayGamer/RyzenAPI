-- Lua provided by RyzenAPI
-- Game: 322770

-- MAIN APPLICATION
addappid(322770)
addappid(1082250)
-- Game: addappid(322770)

-- MAIN APP DEPOTS / PACKAGES
addappid(322771, 1, "6f3182c44019fec5faa5aa00e600fcfae8d843cb67f485622afca66268435cfa")
