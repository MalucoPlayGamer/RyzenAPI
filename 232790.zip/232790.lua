-- Lua provided by RyzenAPI
-- Game: Broken Age

-- MAIN APPLICATION
addappid(232790)

-- MAIN APP DEPOTS / PACKAGES
addappid(232791, 1, "b40039c06ec012db45b47553395a4c38b54f39c0922aaeb8d215bbdc46f1d48a")
addappid(232792, 1, "d48f3d10a7dd7c622eca91784bf60ddfaa79a19be4f72c5c3261594ac36634de")
addappid(232793, 1, "2cd01b01ec1bb225b8e660a5176703a8565526151482fa7ddf61cdcfc34b4e08")
addappid(232794, 1, "38c1fca9bd3eec5f9da49c5faf79bb55ec0ad86fd4c9c7122982b15433ec7420")
