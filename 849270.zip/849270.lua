-- Lua provided by RyzenAPI
-- Game: 849270

-- MAIN APPLICATION
addappid(849270)
-- Game: addappid(849270)

-- MAIN APP DEPOTS / PACKAGES
addappid(849271, 1, "f694c802ae8bc5f7691c0b272970d9f97f2c4eb76f63956bb7cb77e6f253c533")
