-- Lua provided by RyzenAPI
-- Game: The Backrooms: Escape

-- MAIN APPLICATION
addappid(2644620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2644621, 1, "c1e40b4c69f96934adde6bf593afceb6a3055771d5c350b5db14b0dcb56ca12c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
