-- Lua provided by RyzenAPI
-- Game: 2644620

-- MAIN APPLICATION
addappid(2644620)
-- Game: addappid(2644620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2644621, 1, "c1e40b4c69f96934adde6bf593afceb6a3055771d5c350b5db14b0dcb56ca12c")
