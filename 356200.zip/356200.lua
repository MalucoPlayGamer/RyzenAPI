-- Lua provided by RyzenAPI
-- Game: AppID 356200

-- MAIN APPLICATION
addappid(356200)

-- MAIN APP DEPOTS / PACKAGES
addappid(356201, 1, "d10f7c096b2b414b69e6515ea67ac5eaac216b1f9da424c67e917094d461e11d")
addappid(356202, 1, "1a853bb852cb79b597ddf0abd6e65f688ae8454814aba9df1107529129e57975")
addappid(356203, 1, "32438b6fc5ade428d5fb9aec202441f45921e2d7d6362cd0db3fdf5ec471a289")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
