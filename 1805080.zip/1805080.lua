-- Lua provided by RyzenAPI
-- Game: Reta Tus Habilidades

-- MAIN APPLICATION
addappid(1805080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805081, 1, "6ae89141e41bd28c4711b0f7ee293839f9412f8768b4d024e828f98cc54a0588")
addappid(1805082, 1, "f112c2398abf096506738a653cd0059dd23061f1ad97bc94b41b9ef6f04c37a0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
