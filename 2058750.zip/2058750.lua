-- Lua provided by SkyAPI 
-- Game: Monster Energy Supercross - The Official Videogame 6
addappid(2058750)
addappid(2058751, 1, "6b9fc7a68f8d9173ce4ffe86cf84fad5c42db8f8e6adbd3a9beb1cff95f7b969")
