-- Lua provided by RyzenAPI
-- Game: Monster Energy Supercross - The Official Videogame 6

-- MAIN APPLICATION
addappid(2058750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058751, 1, "6b9fc7a68f8d9173ce4ffe86cf84fad5c42db8f8e6adbd3a9beb1cff95f7b969")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2165680)
addappid(2177240)
addappid(2177250)
