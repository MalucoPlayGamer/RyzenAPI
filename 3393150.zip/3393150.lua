-- Lua provided by SkyAPI 
-- Game: Ninth Hotel Demo
addappid(3393150)
addappid(3393151, 1, "80407ff7dc13d950330c243c2d336817a1503566792eb8f6b27a6e5d61e698cc")
