-- Lua provided by SkyAPI 
-- Game: Hot wife Tara
addappid(1880860)
addappid(1880861, 1, "0b3a41daa66d1531bc1294c08cd0ca316c8bb27435a822021f357239b173ada0")
