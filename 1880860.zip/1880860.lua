-- Lua provided by RyzenAPI
-- Game: addappid(1880860)

-- MAIN APPLICATION
addappid(1880860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1880861, 1, "0b3a41daa66d1531bc1294c08cd0ca316c8bb27435a822021f357239b173ada0")
