-- Lua provided by RyzenAPI
-- Game: Behind the Frame: The Finest Scenery

-- MAIN APPLICATION
addappid(1634150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1634151, 1, "355019ff596312e8ebfe24c2ee5a52de02bf8ce5da9b10f5160b2ddb780ee814")
addappid(1634152, 1, "367f3032f8b756efad40e61bdc5916790f5c4ff5ec39294f8415901e4de1efd7")
addappid(1740520, 0, "162e87a29cf4b0725535bd5764fc52d2f3458a261d4107be6aff1aa5ea406aac")
addappid(2013070, 0, "43a39c22fc167fd1e1b17f8f9c2bed89418cff7729cf966787464d022e0681a9")

