-- Lua provided by RyzenAPI
-- Game: NeoPiano

-- MAIN APPLICATION
addappid(1982310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982311, 1, "236c77339332ce5c5ce226999c4ad015d4a4dca86a07f541b3d48ba80f5418b4")

