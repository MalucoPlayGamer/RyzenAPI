-- Lua provided by RyzenAPI
-- Game: NeoPiano

-- MAIN APPLICATION
addappid(1982310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982311, 1, "236c77339332ce5c5ce226999c4ad015d4a4dca86a07f541b3d48ba80f5418b4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
