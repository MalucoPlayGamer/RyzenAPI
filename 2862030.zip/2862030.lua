-- Lua provided by RyzenAPI
-- Game: Lunatic Taxi Driver

-- MAIN APPLICATION
addappid(2862030)
-- Game: addappid(2862030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862031, 1, "00622ff779032d47ac5265c422a49c6b496bbf0b187f607a05009d71f2c28187")
