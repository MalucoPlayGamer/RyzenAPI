-- Lua provided by RyzenAPI 
-- Game: NOODS
addappid(3388690)
addappid(3388691, 1, "c3f14268f1825d876067e0012460d63c1923d0556327db32190e138bf0903b0f")
