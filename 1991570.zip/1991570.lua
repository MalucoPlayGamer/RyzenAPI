-- Lua provided by RyzenAPI
-- Game: Arruyo

-- MAIN APPLICATION
addappid(1991570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1991571, 1, "2020c4b1d094f72d5dfcf14fbd0bdb269fe55df58224587901ee40606ae7ee54")

