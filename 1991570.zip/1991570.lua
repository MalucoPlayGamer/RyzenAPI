-- Lua provided by RyzenAPI
-- Game: Arruyo

-- MAIN APPLICATION
addappid(1991570)
-- Game: addappid(1991570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1991571, 1, "2020c4b1d094f72d5dfcf14fbd0bdb269fe55df58224587901ee40606ae7ee54")
