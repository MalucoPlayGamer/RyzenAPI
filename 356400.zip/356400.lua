-- Lua provided by RyzenAPI
-- Game: Game: AppID 356400

-- MAIN APPLICATION
addappid(356400)
-- Game: addappid(356400)

-- MAIN APP DEPOTS / PACKAGES
addappid(356401, 1, "9fb95254c0c0f808cb1c837dadf44f73649f6e2d8b6ad8bf73328b1fe1412fb6")
