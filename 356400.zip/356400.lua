-- Lua provided by RyzenAPI 
-- Game: AppID 356400
addappid(356400)
addappid(356401, 1, "9fb95254c0c0f808cb1c837dadf44f73649f6e2d8b6ad8bf73328b1fe1412fb6")
