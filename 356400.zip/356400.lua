-- Lua provided by RyzenAPI
-- Game: AppID 356400

-- MAIN APPLICATION
addappid(356400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(356401, 1, "9fb95254c0c0f808cb1c837dadf44f73649f6e2d8b6ad8bf73328b1fe1412fb6")

