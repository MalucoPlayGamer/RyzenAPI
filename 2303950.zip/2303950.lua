-- Lua provided by RyzenAPI
-- Game: TRAUMA Broken Paradise

-- MAIN APPLICATION
addappid(2303950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2303951, 1, "7521b8710a27dd549b3c70906b87768b4ca39d408fe875bf1c48aab25e8c8311")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
