-- Lua provided by RyzenAPI
-- Game: addappid(2303950)

-- MAIN APPLICATION
addappid(2303950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2303951, 1, "7521b8710a27dd549b3c70906b87768b4ca39d408fe875bf1c48aab25e8c8311")
