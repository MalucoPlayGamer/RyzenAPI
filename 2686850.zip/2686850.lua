-- Lua provided by RyzenAPI
-- Game: Tochos vs. Brokens

-- MAIN APPLICATION
addappid(2686850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686851, 1, "18acb747cc6ce6164d4e261cebeb262ca78f8959a2708917fb4a92638152c806")

