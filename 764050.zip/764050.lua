-- Lua provided by RyzenAPI
-- Game: Maelstrom

-- MAIN APPLICATION
addappid(764050)

-- MAIN APP DEPOTS / PACKAGES
addappid(764051, 1, "e3d6e72b2ea98a70258d69a3b1302b67745ca60cee57667374ac1c9c979060eb")

