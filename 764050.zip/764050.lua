-- Lua provided by RyzenAPI
-- Game: Maelstrom

-- MAIN APPLICATION
addappid(764050)
addappid(1227510)
addappid(1257740)
addappid(1257741)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(764051, 1, "e3d6e72b2ea98a70258d69a3b1302b67745ca60cee57667374ac1c9c979060eb")

