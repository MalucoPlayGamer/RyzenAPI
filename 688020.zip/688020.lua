-- Lua provided by RyzenAPI
-- Game: 688020

-- MAIN APPLICATION
addappid(688020)
-- Game: addappid(688020)

-- MAIN APP DEPOTS / PACKAGES
addappid(688021, 1, "669434479b9b8d57f6ebafcec293681e21aa223ea64856a7a7d9510ba7f9370b")
