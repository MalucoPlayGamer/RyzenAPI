-- 3564330's Lua and Manifest Created by Hubcap Manifest
-- The Core
-- Created: August 14, 2026 at 11:07:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3564330) -- The Core
-- MAIN APP DEPOTS
addappid(3564331, 1, "fe2de45cf50d75df4aeaa0681e1ea84ec8fa3f2d457b42860ffa3612aa1e59db") -- Depot 3564331
setManifestid(3564331, "341562765588942969", 16806502647)