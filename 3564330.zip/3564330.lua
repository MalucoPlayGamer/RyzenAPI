-- Lua provided by RyzenAPI
-- Game: The Core

-- MAIN APPLICATION
addappid(3564330) -- The Core

-- MAIN APP DEPOTS / PACKAGES
addappid(3564331, 1, "fe2de45cf50d75df4aeaa0681e1ea84ec8fa3f2d457b42860ffa3612aa1e59db") -- Depot 3564331

