-- Lua provided by RyzenAPI
-- Game: 1866050

-- MAIN APPLICATION
addappid(1866050)
-- Game: addappid(1866050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1866051, 1, "dc33850051cc0da6e3676b600b4eb04cde5d724c4521b99c1155d9cb310e06a6")
