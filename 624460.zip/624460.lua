-- Lua provided by RyzenAPI
-- Game: addappid(624460)

-- MAIN APPLICATION
addappid(624460)

-- MAIN APP DEPOTS / PACKAGES
addappid(624461, 1, "06153ae2d1a47246679adf1b9f4fe48fc942f90adf4a1aa9dc09e32bf25dcf9c")
