-- Lua provided by RyzenAPI
-- Game: Fantasynth One

-- MAIN APPLICATION
addappid(624460)

-- MAIN APP DEPOTS / PACKAGES
addappid(624461, 1, "06153ae2d1a47246679adf1b9f4fe48fc942f90adf4a1aa9dc09e32bf25dcf9c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
