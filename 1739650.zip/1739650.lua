-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1739650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1739652,0,"dce2de55131af141c411c1f631984753fb5f59dfbf0d2f6fa1c93bc056d47c68")

