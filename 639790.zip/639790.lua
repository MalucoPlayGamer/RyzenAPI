-- Lua provided by RyzenAPI
-- Game: DEEP SPACE WAIFU

-- MAIN APPLICATION
addappid(639790)
-- Game: addappid(639790)

-- MAIN APP DEPOTS / PACKAGES
addappid(639791, 1, "f21b6b8d1f9faf07662ccc922077de3e63ad35ee2067435f3b2cb94bc31c6207")
