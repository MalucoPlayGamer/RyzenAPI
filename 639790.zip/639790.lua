-- Lua provided by RyzenAPI
-- Game: DEEP SPACE WAIFU

-- MAIN APPLICATION
addappid(639790)

-- MAIN APP DEPOTS / PACKAGES
addappid(639791, 1, "f21b6b8d1f9faf07662ccc922077de3e63ad35ee2067435f3b2cb94bc31c6207")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(648930)
addappid(701531)
