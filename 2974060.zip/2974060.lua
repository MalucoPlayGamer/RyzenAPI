-- Lua provided by RyzenAPI
-- Game: Game: [REC] Paroxysm

-- MAIN APPLICATION
addappid(2974060)
-- Game: addappid(2974060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2974061, 1, "a199d48bb7085fa5e62fab4364b0eb831d8e352e8374e53a64075d965ac11323")
