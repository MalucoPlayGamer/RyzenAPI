-- Lua provided by RyzenAPI
-- Game: [REC] Paroxysm

-- MAIN APPLICATION
addappid(2974060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2974061, 1, "a199d48bb7085fa5e62fab4364b0eb831d8e352e8374e53a64075d965ac11323")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
