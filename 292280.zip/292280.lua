-- Lua provided by RyzenAPI
-- Game: Game: Spy Fox In: Cheese Chase

-- MAIN APPLICATION
addappid(292280)
-- Game: addappid(292280)

-- MAIN APP DEPOTS / PACKAGES
addappid(292281, 1, "f8a620ae561d3c8159486794857849c9e11c5e101fb8b130df8c9af9461e7382")
addappid(292282, 1, "bb414891af552f2d668d25511f3bc089e47d55bb8c8de8308e761c539c5fd7a0")
addappid(292283, 1, "4e43db998a2d42552d3a73e03872f5c29504d341928216def3f9d5487f3fdf8c")
addappid(292284, 1, "2359bd2b5bfb466631bff983d69fcf5eacdf45eb4949d966b9df6d4393e1e77e")
addappid(292285, 1, "394fc17ee979d0e1fd0ab82a41413c603b4966aaa714387aa24816a9c72533ac")
addappid(292286, 1, "7e6351c3eb413dbe60f2bc6bb4e60e88a7d85d2a87eec0baf9f21feeb416779b")
addappid(292287, 1, "0fcdce1f4d0c68f7205329f47fb0ffcc36bee46fb3a9819f5a986d4c98116a0e")
