-- Lua provided by RyzenAPI
-- Game: Darwin Project

-- MAIN APPLICATION
addappid(544920)

-- MAIN APP DEPOTS / PACKAGES
addappid(544921, 1, "ddc9d4a343b307e464dc9a3b215fffc4f7541bd0c8769a1883d179b5584c2a07")

