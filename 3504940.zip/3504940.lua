-- Lua provided by SkyAPI 
-- Game: Desktop Angel
addappid(3504940)
addappid(3504941, 1, "343bbef71be1fd50adade8a79f7200892b2dcc434970e9d5a93fed902ce7df0b")
