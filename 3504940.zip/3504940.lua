-- Lua provided by RyzenAPI
-- Game: 3504940

-- MAIN APPLICATION
addappid(3504940)
-- Game: addappid(3504940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3504941, 1, "343bbef71be1fd50adade8a79f7200892b2dcc434970e9d5a93fed902ce7df0b")
