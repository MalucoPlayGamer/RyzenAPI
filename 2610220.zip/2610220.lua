-- Lua provided by RyzenAPI
-- Game: Hidden Space Top-Down 3D

-- MAIN APPLICATION
addappid(2610220)
-- Game: addappid(2610220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2610221, 1, "5c6d644a1d5ad4d0a67b96b5290027d11a63aa700d52dde25fd901c80d246843")
