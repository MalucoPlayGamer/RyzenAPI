-- Lua provided by RyzenAPI 
-- Game: Metal Mutation
addappid(1840790)
addappid(1840791, 1, "941a96a5d232518d38bae2ed4f3d53c9c27a76d7b3a3d91e47cbf774f32d580a")
