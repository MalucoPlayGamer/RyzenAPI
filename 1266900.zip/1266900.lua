-- Lua provided by RyzenAPI
-- Game: Game: Operation DogFight

-- MAIN APPLICATION
addappid(1266900)
-- Game: addappid(1266900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1266901, 1, "db9924968ce1cf5f55613476d8bce394dd396515114ac7251998873b7727c874")
