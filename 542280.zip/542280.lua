-- Lua provided by RyzenAPI
-- Game: 542280

-- MAIN APPLICATION
addappid(542280)
-- Game: addappid(542280)

-- MAIN APP DEPOTS / PACKAGES
addappid(542281, 1, "f1c1bfa74efdd4411d61ea115859ff584ca857425052eb24c8ddfd6a014cd9c1")
