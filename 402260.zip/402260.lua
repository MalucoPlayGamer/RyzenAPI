-- Lua provided by RyzenAPI
-- Game: AppID 402260

-- MAIN APPLICATION
addappid(402260)
-- Game: addappid(402260)

-- MAIN APP DEPOTS / PACKAGES
addappid(402261, 1, "77352dd8d64c9aff10e85c29ea1c0fd727c4f7a9275826ef77f0e4a5cd9437ac")
addappid(402262, 1, "9a3b449cff46a5dec24568f5c12cb32c6953490637cb1c5a2b897b2e0d498ada")
addappid(402263, 1, "8f4ec573c14ee0df893aa5970a30dc514a610db4d173bf0a75e543875666cc8e")
