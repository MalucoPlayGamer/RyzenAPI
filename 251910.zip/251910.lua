-- Lua provided by SkyAPI 
-- Game: Solar Flux
addappid(251910)
addappid(251911, 1, "84c8279a16af4af4cb9e98ee30c366b777fe5b50a58187365a124b5d2dd38133")
addappid(251912, 1, "509c989c6edafb10a3de3274d2b0ee13459dbc0826a02041e0809b6da847aea5")
addappid(251913, 1, "f11462dc16ef31794f1af3f787485715fa334a34b10346f4bfe2e1d636bf76ec")
