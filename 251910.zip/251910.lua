-- Lua provided by RyzenAPI
-- Game: Solar Flux

-- MAIN APPLICATION
addappid(251910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(251911, 1, "84c8279a16af4af4cb9e98ee30c366b777fe5b50a58187365a124b5d2dd38133")
addappid(251912, 1, "509c989c6edafb10a3de3274d2b0ee13459dbc0826a02041e0809b6da847aea5")
addappid(251913, 1, "f11462dc16ef31794f1af3f787485715fa334a34b10346f4bfe2e1d636bf76ec")

