-- Lua provided by RyzenAPI 
-- Game: .redruM
addappid(3197050)
addappid(3197051, 1, "eacc3b87cab40760cef9d68ff71ca162202ed75a41a2626e9af265147be1cf77")
