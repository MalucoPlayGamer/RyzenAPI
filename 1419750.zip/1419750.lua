-- Lua provided by RyzenAPI
-- Game: Apostle: Rebellion

-- MAIN APPLICATION
addappid(1419750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419751, 1, "17bce1daac2e0de80a00d44db1a9c33542ab0b34448ef2367a3cd632ea27ef19")
addappid(1419752, 1, "a5ee1eeab7932cf159bcc41043f213713f5114ce61bb8e735e643780697cbd23")
addappid(1419753, 1, "c31023e26380ecd8339fa6716994efa8c37ea7abc6ba22f0c743f3a2ec2ff906")
addappid(1419754, 1, "7168e9d710eeebbb6d259b2ecc75f2fa2fff60078f5ac6fc629f03294b4042cb")

