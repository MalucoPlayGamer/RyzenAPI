-- Lua provided by RyzenAPI
-- Game: Sensual Adventures - Episode 7

-- MAIN APPLICATION
addappid(2175100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2175101, 1, "6e195a91b45db729e60cf4bdeb0db1b0607ea9fd0d869e07025df7495f6dc3fc")
