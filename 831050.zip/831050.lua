-- Lua provided by RyzenAPI
-- Game: Dolmen

-- MAIN APPLICATION
addappid(831050)
addappid(1818330)

-- MAIN APP DEPOTS / PACKAGES
addappid(831051,0,"ae8181cb0a9be49b55f3391d2c5709b2af1154be122c804569bed23a2a5293b8")

