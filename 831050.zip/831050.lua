-- Lua provided by RyzenAPI
-- Game: Dolmen

-- MAIN APPLICATION
addappid(831050)
addappid(1818330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(831051,0,"ae8181cb0a9be49b55f3391d2c5709b2af1154be122c804569bed23a2a5293b8")

