-- Lua provided by RyzenAPI
-- Game: 831050

-- MAIN APPLICATION
addappid(831050)
-- Game: addappid(831050)

-- MAIN APP DEPOTS / PACKAGES
addappid(831051, 1, "ae8181cb0a9be49b55f3391d2c5709b2af1154be122c804569bed23a2a5293b8")
