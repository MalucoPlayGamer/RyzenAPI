-- Lua provided by RyzenAPI
-- Game: Legend of the Outlaw Mage

-- MAIN APPLICATION
addappid(1702990)
addappid(1913260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702991, 1, "29b51d8448a9df43ef29be7e0fa01911a6284afcb1a62738bbf9d9a111882c4a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
