-- Lua provided by RyzenAPI
-- Game: addappid(1702990)

-- MAIN APPLICATION
addappid(1702990)
addappid(1913260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1702991, 1, "29b51d8448a9df43ef29be7e0fa01911a6284afcb1a62738bbf9d9a111882c4a")
