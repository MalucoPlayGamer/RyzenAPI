-- Lua provided by SkyAPI 
-- Game: 1$ Fun: Nice Slice
addappid(589260)
addappid(589261, 1, "15fc04aa4b594f50f06db07255e520ba70a23469dd7e6bec2847450f57b2cba8")
