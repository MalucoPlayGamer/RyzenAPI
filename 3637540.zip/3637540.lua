-- Lua provided by RyzenAPI
-- Game: Cricket Captain 2025

-- MAIN APPLICATION
addappid(3637540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3637541, 1, "5dcf180ad32c922806d2da5e98a65b17fe859b22761984ca223dc1cf31bec5a9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
