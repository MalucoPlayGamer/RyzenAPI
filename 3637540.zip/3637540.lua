-- Lua provided by RyzenAPI
-- Game: 3637540

-- MAIN APPLICATION
addappid(3637540)
-- Game: addappid(3637540)

-- MAIN APP DEPOTS / PACKAGES
addappid(3637541, 1, "5dcf180ad32c922806d2da5e98a65b17fe859b22761984ca223dc1cf31bec5a9")
