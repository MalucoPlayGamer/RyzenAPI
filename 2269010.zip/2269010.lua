-- Lua provided by RyzenAPI
-- Game: Game: Hentai Casual Slider

-- MAIN APPLICATION
addappid(2269010)
-- Game: addappid(2269010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2269011, 1, "2c98969d18f8ac27ca3748edf3898f86d083989864bf65ed7e31dddb5d369f06")
