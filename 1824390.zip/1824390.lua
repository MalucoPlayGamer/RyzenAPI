-- Lua provided by RyzenAPI 
-- Game: Prototype Blocks 2
addappid(1824390)
addappid(1824391, 1, "6a90621a05f2bb941225a483f99c5725528c5a182f107c004ebc5369e2876316")
