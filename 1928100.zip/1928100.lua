-- Lua provided by RyzenAPI
-- Game: Sex Diary - A Slutty Anniversary

-- MAIN APPLICATION
addappid(1928100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928101, 1, "b1801b551807257cc6915919e34f5d49503750fc28771c5d9769fe3feb1fab70")
