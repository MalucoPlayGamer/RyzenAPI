-- Lua provided by RyzenAPI
-- Game: ESCAPE FROM VOYNA: Dead Forest

-- MAIN APPLICATION
addappid(588140)

-- MAIN APP DEPOTS / PACKAGES
addappid(588141,0,"bf97674eb936952bdf10ee0b94e2ef66d72ae6041d150012a7b961bcd5cfe09c")

