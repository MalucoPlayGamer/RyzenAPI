-- Lua provided by RyzenAPI
-- Game: ESCAPE FROM VOYNA: Dead Forest

-- MAIN APPLICATION
addappid(588140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(588141,0,"bf97674eb936952bdf10ee0b94e2ef66d72ae6041d150012a7b961bcd5cfe09c")

