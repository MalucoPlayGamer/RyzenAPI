-- Lua provided by RyzenAPI
-- Game: 1299060

-- MAIN APPLICATION
addappid(1299060)
-- Game: addappid(1299060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1299061, 1, "f7877468295d8af69a753371182cc0971a7e9da31a3caadd34add951d94439c0")
