-- Lua provided by RyzenAPI
-- Game: The Dolls: Reborn

-- MAIN APPLICATION
addappid(473670)
-- Game: addappid(473670)

-- MAIN APP DEPOTS / PACKAGES
addappid(473671, 1, "f2e12c24df9351593a2f6f27d989a7eb481cada0162d34819d0926cc8745dfa2")
addappid(473672, 1, "ddcba3642a713a45dfc6b5ad02b918ad0bda5d992198a7beac5b9cc5c16168eb")
addappid(473673, 1, "c7972431b3a6bbc0b7b6dba86bb3cffb95f99783bcd5d579ec6ef907895d8c94")
