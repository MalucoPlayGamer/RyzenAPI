-- Lua provided by RyzenAPI
-- Game: Tiki Tiki Hop

-- MAIN APPLICATION
addappid(2083760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2083761, 1, "59e0990c694a27ef42a916f040dc142ddc9052e5061f54b2c644dd1854c656eb")

