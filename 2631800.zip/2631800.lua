-- Lua provided by SkyAPI 
-- Game: Escape The Glubinka
addappid(2631800)
addappid(2631801, 1, "1500a93221b28337db7c2dc3472e963ab77f753ec2b203adbb04440633150485")
