-- Lua provided by RyzenAPI
-- Game: ORBITAL

-- MAIN APPLICATION
addappid(506670)

-- MAIN APP DEPOTS / PACKAGES
addappid(506671, 1, "4ebbcf0822bda391a8885bf371376bcc51859e0527acaafc62f740e68d7b39cd")
