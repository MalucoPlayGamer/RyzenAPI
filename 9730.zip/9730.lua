-- Lua provided by RyzenAPI
-- Game: Game: Tycoon City: New York

-- MAIN APPLICATION
addappid(9730)
-- Game: addappid(9730)

-- MAIN APP DEPOTS / PACKAGES
addappid(9731, 1, "b05d62087aee95ac10cf76ec9ec11edcf9da77291a4155ac54f5780d4118ad12")
