-- Lua provided by RyzenAPI 
-- Game: PORN Pizza Delivery Boy
addappid(1263130)
addappid(1263131, 1, "0e83292a6b3cfee44792351b096ef2a5abe3271d2863836dd0023961107daa8c")
