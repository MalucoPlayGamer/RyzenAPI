-- Lua provided by RyzenAPI
-- Game: Game: AppID 1391110

-- MAIN APPLICATION
addappid(1391110)
-- Game: addappid(1391110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1391111, 1, "8c0894de187f61e472607bbb2763b8f3195bc050763b506fe829b70baf9040af")
