-- Lua provided by RyzenAPI
-- Game: 四圣传说之黑暗森林

-- MAIN APPLICATION
addappid(1063910)
-- Game: addappid(1063910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1063911, 1, "62f7ec3e00894eaddbab6ab33b1c4b01a34cdf0e5dbc7a655880dbda704f875c")
