-- Lua provided by RyzenAPI
-- Game: AppID 1231520

-- MAIN APPLICATION
addappid(1231520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231521, 1, "d8aa0aff4c870c577ba9ed2010eb1ac8cf8fee1f0a10a93a70ef1d35b09a407d")

