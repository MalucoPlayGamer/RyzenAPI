-- Lua provided by RyzenAPI
-- Game: addappid(2701420)

-- MAIN APPLICATION
addappid(2701420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701421, 1, "e677b97aa737f3b39abd32b4447d361cd936fd56b40b0370e78d01c1fc0d4463")
