-- Lua provided by RyzenAPI
-- Game: Ninpaw

-- MAIN APPLICATION
addappid(2523650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2523651, 1, "0e72b3ae328c3935df5179eb5fac7fb4bb27ad007255f81a345f44788e7eb959")

