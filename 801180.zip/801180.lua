-- Lua provided by RyzenAPI
-- Game: Beer Pong VR

-- MAIN APPLICATION
addappid(801180)

-- MAIN APP DEPOTS / PACKAGES
addappid(801181,0,"66d5041e90e80519b25a74ce6afa6921cfc66c7dc2474d621a694efda5469fa2")

