-- Lua provided by RyzenAPI
-- Game: Run and Jump

-- MAIN APPLICATION
addappid(790120)

-- MAIN APP DEPOTS / PACKAGES
addappid(790121, 1, "27e7272175a84bb38787b243653d5eafb9fbb1f1b786496f089341d1465443e1")

