-- Lua provided by RyzenAPI
-- Game: Nethergate: Resurrection

-- MAIN APPLICATION
addappid(218020)
-- Game: addappid(218020)

-- MAIN APP DEPOTS / PACKAGES
addappid(218021, 1, "91d20a4997be8bc472417cf9efd4f4b2fbf6bd64decc14be7280f2c933334839")
