-- Lua provided by SkyAPI 
-- Game: Don't Fret Demo
addappid(3202450)
addappid(3202451, 1, "66ea222067e75d6445ac4377ff852217111ec454b7794e3f4f86e2df1a812fd1")
