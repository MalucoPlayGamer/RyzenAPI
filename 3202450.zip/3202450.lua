-- Lua provided by RyzenAPI
-- Game: Don't Fret Demo

-- MAIN APPLICATION
addappid(3202450)
-- Game: addappid(3202450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3202451, 1, "66ea222067e75d6445ac4377ff852217111ec454b7794e3f4f86e2df1a812fd1")
