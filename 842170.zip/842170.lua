-- Lua provided by RyzenAPI
-- Game: 842170

-- MAIN APPLICATION
addappid(842170)
-- Game: addappid(842170)

-- MAIN APP DEPOTS / PACKAGES
addappid(842172,0,"c527612a7f6d72eeefacaee273d3a787b531d240cc00526ac239036b28358974")
