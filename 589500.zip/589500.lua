-- Lua provided by RyzenAPI
-- Game: Shovel Knight: Shovel of Hope

-- MAIN APPLICATION
addappid(589500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(589501, 1, "b5ab7c70abf77cbd2a7e092d0def76c42e190160ce6856c6ede02622dff94834")

