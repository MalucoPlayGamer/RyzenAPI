-- Lua provided by RyzenAPI
-- Game: addappid(1965390)

-- MAIN APPLICATION
addappid(1965390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1965391, 1, "d9153a08378002d3611c1df2a77f505581cdd4dd30f70bad6f95c3de461a430c")
