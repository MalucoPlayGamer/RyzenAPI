-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 Naturally sadistic, Sweet Little Devil GP-02

-- MAIN APPLICATION
addappid(2325560)
-- Game: addappid(2325560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2325561, 1, "5f9f6c1d82bd8ee81aa53ac234b7907e966fa18c5b3f63d04a3b9452d8f0554e")
addappid(2325562, 1, "368f6887c7d69a90cb60c8c6fedc3a9a25c895375ddcd7d28c56787f3a5edaf6")
