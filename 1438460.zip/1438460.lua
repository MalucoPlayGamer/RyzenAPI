-- Lua provided by RyzenAPI
-- Game: 1438460

-- MAIN APPLICATION
addappid(1438460)
-- Game: addappid(1438460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1438461, 1, "d526e4de17779f0f0a33d16f018bea3cdf416f3c424d79e1151b6c1327d0911e")
