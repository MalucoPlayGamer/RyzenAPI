-- Lua provided by RyzenAPI
-- Game: 39550

-- MAIN APPLICATION
addappid(39550)
addappid(228990)
-- Game: addappid(39550)

-- MAIN APP DEPOTS / PACKAGES
addappid(39551, 1, "1fc18b541b2092b9bae9846c6bd1867281940fba4b8c1c2a3985638a7cc4d376")
addappid(39552, 1, "f9461ea67b4c14734c474c0ee838efe867388e5e1228efaaf2d49f64f1d425d6")
addappid(39553, 1, "db85120ffd565a86b4133224ba1316a08e9470a38afa61c6bb4450ced80870d1")
addappid(39554, 1, "b00c6e3e551ffb8a5c6921efc4d5c78d67cbcc739953f0fefa5b7da315451e7b")
addappid(39555, 1, "2894e3c53e8f4066723f71518ba30278fdd96bcc753a787e85122ea1fad9ad8f")
addappid(39556, 1, "dd4150c62b9ce9275398bd25a3b7eefa98afd4f2e01af8e0ae44b5e51d5eaa7e")
addappid(39557, 1, "4e1ff38088d60baf7d6cdea4aba40803c8235264558a3a5cfd9a66d1ec1ce6f2")
addappid(39558, 1, "0e194e569bf5c1a79a132489edf75992a13d8c8d8cdd936f9f7bb7acb75a3096")
