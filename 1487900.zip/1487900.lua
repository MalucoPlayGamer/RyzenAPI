-- Lua provided by RyzenAPI
-- Game: 1487900

-- MAIN APPLICATION
addappid(1487900)
-- Game: addappid(1487900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1487901, 1, "ecf42b4148cbf8f186b623f0c823d57256ad7a6802f39713e05d721daaefbb07")
