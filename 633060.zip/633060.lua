-- Lua provided by RyzenAPI
-- Game: Orwell: Ignorance is Strength

-- MAIN APPLICATION
addappid(633060)

-- MAIN APP DEPOTS / PACKAGES
addappid(633061, 1, "115ccd00243411c514b46f0e0d1c63d1d7a82f2d7e66fd9dc47a1cc5729bd6ca")
addappid(633062, 1, "43f359619d45ee7ee228aa6144120a1483976a94a03efbc0d8b28e18cd008849")
addappid(633063, 1, "c2d433105b503aa001e8a503b984ed67af0da9f3eab6dc93894ca645224d4d33")
