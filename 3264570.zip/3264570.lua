-- Lua provided by RyzenAPI
-- Game: Last Landlord

-- MAIN APPLICATION
addappid(3264570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3264576,0,"23340f04de5087724d516abe87e9038d95bf2b1a1d591f761ec08fa4c811cc0d")
