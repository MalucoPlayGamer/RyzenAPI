-- Lua provided by RyzenAPI
-- Game: Chocolate makes you happy: Valentine's Day

-- MAIN APPLICATION
addappid(1006880)
-- Game: addappid(1006880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1006881, 1, "7f17d296b33243355bead2bb564e9e42d3c45c2d74c4259c52ae54ed972b4bb4")
