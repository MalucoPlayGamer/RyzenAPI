-- Lua provided by RyzenAPI
-- Game: Shooty Skies Overdrive

-- MAIN APPLICATION
addappid(1300490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1300491, 1, "9d5493e68ad36d77c0378af556d0668445e9fff3e24a850a1857e006e8398f5d")

