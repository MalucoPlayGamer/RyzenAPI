-- Lua provided by RyzenAPI
-- Game: 3354530

-- MAIN APPLICATION
addappid(3354530)
-- Game: addappid(3354530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354530,0,"3afbba7ed07b20dc4d4fcf96652e58660e0caad3daf34c8df641a6152531195f")
