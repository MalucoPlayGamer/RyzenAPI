-- Lua provided by RyzenAPI
-- Game: 1根香腸走江湖

-- MAIN APPLICATION
addappid(4172690)

