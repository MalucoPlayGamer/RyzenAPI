-- Lua provided by RyzenAPI
-- Game: 1根香腸走江湖

-- MAIN APPLICATION
addappid(4172690)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4193030)
addappid(4193040)
