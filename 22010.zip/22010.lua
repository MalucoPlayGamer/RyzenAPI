-- Lua provided by RyzenAPI
-- Game: Game: World of Goo Demo

-- MAIN APPLICATION
addappid(22010)
-- Game: addappid(22010)

-- MAIN APP DEPOTS / PACKAGES
addappid(22011, 1, "d5d72b008050a2e8e93079efa72a3f0e5038a9b6fdf83a17e707c658cd4ab475")
