-- Lua provided by SkyAPI 
-- Game: Bargain Invaders
addappid(2274990)
addappid(2274991, 1, "0473f2baa01f2a44e7fa03f9b348bd96c903fafddb08e3ae2f6e6a760821ff2a")
