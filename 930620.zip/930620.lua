-- Lua provided by RyzenAPI
-- Game: addappid(930620)

-- MAIN APPLICATION
addappid(930620)

-- MAIN APP DEPOTS / PACKAGES
addappid(930621, 1, "d2ea3e79a620d02602759360221df2c1c4d742de47c96e72bff873cda3acbd23")
