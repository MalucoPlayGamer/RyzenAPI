-- Lua provided by RyzenAPI
-- Game: Game: Radio the Universe Demo

-- MAIN APPLICATION
addappid(2268080)
-- Game: addappid(2268080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2268081, 1, "9b27dbdb5dffb41200b0a6e3bce7c2b7a49edbba74e43369cc2d258308129c55")
