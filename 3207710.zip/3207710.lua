-- Lua provided by RyzenAPI
-- Game: 3207710

-- MAIN APPLICATION
addappid(3207710)
-- Game: addappid(3207710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3207711, 1, "18f5a98e23e9e1b847121359863530a3a9a3d6fcc2e2f16177fb9ef661e10be8")
