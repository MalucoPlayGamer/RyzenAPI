-- Lua provided by RyzenAPI
-- Game: Fantasy Mosaics 21: On the Movie Set

-- MAIN APPLICATION
addappid(797300)

-- MAIN APP DEPOTS / PACKAGES
addappid(797301,0,"725437c72e1fd9a2900d34472ddac04710095cac99489aa0a4dae3dd1d0a8ea2")

