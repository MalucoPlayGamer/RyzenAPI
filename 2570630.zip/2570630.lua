-- Lua provided by RyzenAPI
-- Game: 20 Small Mazes

-- MAIN APPLICATION
addappid(2570630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570632,0,"fae18f665fb5eb79e1054e0ae49d1d8b855a00b23db3dddc00a54abb07437cd4")
