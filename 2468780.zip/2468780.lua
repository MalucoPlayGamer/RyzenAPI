-- Lua provided by RyzenAPI 
-- Game: AppID 2468780
addappid(2468780)
addappid(2468781, 1, "9bf9944d191dcd0ecf00984801658de0cac0d7ee5da0d780987dd1010a963de4")
