-- Lua provided by RyzenAPI
-- Game: TEAM SIX - Armored Troops

-- MAIN APPLICATION
addappid(2468780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2468781, 1, "9bf9944d191dcd0ecf00984801658de0cac0d7ee5da0d780987dd1010a963de4")
