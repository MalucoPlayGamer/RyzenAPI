-- Lua provided by RyzenAPI
-- Game: 2922710

-- MAIN APPLICATION
addappid(2922710)
-- Game: addappid(2922710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2922711, 1, "8e0ff6b5b05bf6bf0f092b9b832732d368a2e7ea02db9f0e033b13969a245ceb")
