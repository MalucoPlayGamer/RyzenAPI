-- Lua provided by RyzenAPI
-- Game: Beneath the Cardboard: Be Happy

-- MAIN APPLICATION
addappid(2922710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2922711, 1, "8e0ff6b5b05bf6bf0f092b9b832732d368a2e7ea02db9f0e033b13969a245ceb")

