-- Lua provided by RyzenAPI
-- Game: TRIBES 3: Rivals Playtest

-- MAIN APPLICATION
addappid(2708610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2708611, 1, "1644e93740dcf9a625b1bd87a74800c4ac765e0ec00b180755aba7b299b7b4e5")
