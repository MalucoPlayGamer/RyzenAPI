-- Lua provided by RyzenAPI
-- Game: Body swap story—Aunty Yui & Yuto

-- MAIN APPLICATION
addappid(3676460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3676461, 1, "f2310c1f3a44a4040ea03e95daf4715451c0599f969d1171af79cb3335df80c4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
