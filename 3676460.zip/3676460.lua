-- Lua provided by RyzenAPI
-- Game: addappid(3676460)

-- MAIN APPLICATION
addappid(3676460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3676461, 1, "f2310c1f3a44a4040ea03e95daf4715451c0599f969d1171af79cb3335df80c4")
