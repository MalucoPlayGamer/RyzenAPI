-- Lua provided by RyzenAPI
-- Game: Dungeon Origins

-- MAIN APPLICATION
addappid(1220120)
-- Game: addappid(1220120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1220121, 1, "b42ad3f00cb32fac07c298a2463879b8c2dba235b7cbfacf65346261b40d802c")
