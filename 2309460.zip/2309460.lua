-- Lua provided by RyzenAPI
-- Game: The Faceless

-- MAIN APPLICATION
addappid(2309460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2309461, 1, "1740814f65a9b580a2cf84a9f6f7b80afc5c9a5ef3bdf4a61a7958fe1d6c0ecc")

