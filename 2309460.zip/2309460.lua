-- Lua provided by SkyAPI 
-- Game: The Faceless
addappid(2309460)
addappid(2309461, 1, "1740814f65a9b580a2cf84a9f6f7b80afc5c9a5ef3bdf4a61a7958fe1d6c0ecc")
