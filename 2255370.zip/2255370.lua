-- Lua provided by RyzenAPI
-- Game: directive 8020

-- MAIN APPLICATION
addappid(2255370) -- Directive 8020
addappid(3883930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(2255378, 1, "f60876d9515aa299bf429dc12729bc5cff3582e82dcc6846811997afbc752238")

