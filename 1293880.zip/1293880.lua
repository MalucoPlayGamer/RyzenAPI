-- Lua provided by RyzenAPI
-- Game: Boo's Balloons

-- MAIN APPLICATION
addappid(1293880)
-- Game: addappid(1293880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293881, 1, "c5ba076afb618743f30c80c12160634ec75c0ead6ec6f125dde43ff59f43ddb4")
