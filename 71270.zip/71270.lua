-- Lua provided by RyzenAPI
-- Game: AppID 71270

-- MAIN APPLICATION
addappid(71270)

-- MAIN APP DEPOTS / PACKAGES
addappid(71271, 1, "a9dea1e2b7e831ee50f84ba225e3af38a83fcd3a1dc30fbacd14f73fd11d13e9")
addappid(71272, 1, "e9476d5082cf2507740539e31434fb47927a48bae10a20e0bc49364b2d61fba7")
addappid(71273, 1, "db1efc9e8abcce54a2efa1ab97820d02252713f9d751691c103a1b21fff321ba")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(71275)
