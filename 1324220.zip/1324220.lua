-- Lua provided by RyzenAPI 
-- Game: AppID 1324220
addappid(1324220)
addappid(1324221, 1, "a933448f815cd10521a32328924b058acdbb23aa9241244d2e5390313d1cdd33")
