-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1912041)
-- Game: addappid(1912041)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912041,0,"385a62f47de2b4e9e73225c9c33361e9d418ca47d37528a031ccedef0dc0de73")
