-- Lua provided by RyzenAPI
-- Game: addappid(1912041)

-- MAIN APPLICATION
addappid(1912041)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912041,0,"385a62f47de2b4e9e73225c9c33361e9d418ca47d37528a031ccedef0dc0de73")
