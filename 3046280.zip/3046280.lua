-- Lua provided by RyzenAPI
-- Game: Game: Hentai Tales: The Brave and Demon

-- MAIN APPLICATION
addappid(3046280)
-- Game: addappid(3046280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3046281, 1, "bfa68c724e9712f0a240d2811cbddc3a46dd83cba99a8b0d8ccbb5f8bae886fa")
