-- Lua provided by SkyAPI 
-- Game: Hentai Tales: The Brave and Demon
addappid(3046280)
addappid(3046281, 1, "bfa68c724e9712f0a240d2811cbddc3a46dd83cba99a8b0d8ccbb5f8bae886fa")
