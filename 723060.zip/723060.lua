-- Lua provided by RyzenAPI
-- Game: addappid(723060)

-- MAIN APPLICATION
addappid(723060)

-- MAIN APP DEPOTS / PACKAGES
addappid(723061, 1, "611a16bf88cb9f0cba7417cf56b51b1cbc62f84e0c7cd2e1ea17ecbe34c6f29c")
