-- Lua provided by RyzenAPI
-- Game: Toby's Island

-- MAIN APPLICATION
addappid(331430)

-- MAIN APP DEPOTS / PACKAGES
addappid(331431,0,"a9a5c42e60fb1d6852a0e115e25b30674ca6d955754e302a6950e9b668140cf4")

