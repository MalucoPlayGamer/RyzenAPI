-- Lua provided by RyzenAPI
-- Game: 1245540

-- MAIN APPLICATION
addappid(1245540)
-- Game: addappid(1245540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245541, 1, "d8e85036c89ff0f82ba7fbd959b5b1deeff880ffd67752a1fd96b49bc98adb69")
