-- 1920320's Lua and Manifest Created by Hubcap Manifest
-- Parasite
-- Created: August 10, 2026 at 08:52:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1920320, 1, "538b39e52dd9bd4f6f05fbca0aaabb6a32dc56aac6d290c286c2e371569d3ca8") -- Parasite
-- MAIN APP DEPOTS
addappid(1920321, 1, "8738639be53ec1021ba52bf5e5d354230291685298ca93aad2c3e0e05bbd62a0") -- Depot 1920321
setManifestid(1920321, "6460206093398271819", 283934767)
addappid(1920322, 1, "227226eb4c0fb51ca47628bbb6860532d363ab30b83b6edfd33c870fae5422e9") -- Depot 1920322
setManifestid(1920322, "8468620190556406797", 366186568)
addappid(1920323, 1, "525dfbadca0858f2e5e2647bfd478b61bc28563739f2c3b17685333ab7289f1b") -- Depot 1920323
setManifestid(1920323, "4820334015003827630", 330946823)