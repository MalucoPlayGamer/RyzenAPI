-- Lua provided by RyzenAPI
-- Game: Super Uriel

-- MAIN APPLICATION
addappid(2207910)
-- Game: addappid(2207910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2207911, 1, "1d8377ef23349ac0c925f140020b2ac2b158b9debc749bdc26ff998ec1f5bceb")
