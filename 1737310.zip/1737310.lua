-- Lua provided by RyzenAPI
-- Game: 灵龙岛 Demo

-- MAIN APPLICATION
addappid(1737310)
-- Game: addappid(1737310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1737311, 1, "0e5aa2073783c7829d971ff3a0ddd288bf46ec687b208b5a09d309d87193c773")
