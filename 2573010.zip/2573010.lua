-- Lua provided by RyzenAPI
-- Game: Game: 启云的世界Qiyun's World

-- MAIN APPLICATION
addappid(2573010)
-- Game: addappid(2573010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2573011, 1, "8b062776068b1e66508452a3852c9c0d24671b2241e64708631788aeefd826ce")
