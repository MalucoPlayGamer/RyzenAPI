-- Lua provided by RyzenAPI
-- Game: 启云的世界Qiyun's World

-- MAIN APPLICATION
addappid(2573010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2573011, 1, "8b062776068b1e66508452a3852c9c0d24671b2241e64708631788aeefd826ce")

