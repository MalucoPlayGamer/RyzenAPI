-- Lua provided by RyzenAPI
-- Game: addappid(910200)

-- MAIN APPLICATION
addappid(910200)

-- MAIN APP DEPOTS / PACKAGES
addappid(910201, 1, "72447f550d6a317fc533363d122db7682afcf954cbf1f8df1bc79a47cd747e2b")
