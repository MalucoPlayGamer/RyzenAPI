-- Lua provided by RyzenAPI
-- Game: Mirage: Beyond The Screen

-- MAIN APPLICATION
addappid(2706140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2706141, 1, "ea73f7474b75f16bd2c5ca8197e574afad3069e4eb25854a5655e65dfd410182")

