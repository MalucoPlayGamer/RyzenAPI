-- Lua provided by RyzenAPI
-- Game: Chip's Challenge 2

-- MAIN APPLICATION
addappid(348300)
addappid(356630)

-- MAIN APP DEPOTS / PACKAGES
addappid(348301, 1, "fa6cb8a22fdbc8ef8cdf9b17877febdfbbeb82a272de817b6dc58b56653e8bf1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
