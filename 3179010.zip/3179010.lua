-- Lua provided by RyzenAPI
-- Game: Game: AppID 3179010

-- MAIN APPLICATION
addappid(3179010)
-- Game: addappid(3179010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3179011, 1, "3cfa096f59c554f7090baa8beae542185e4c8a2f0d390feaf53467e3f4f60928")
