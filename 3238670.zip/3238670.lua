-- Lua provided by RyzenAPI
-- Game: 3238670

-- MAIN APPLICATION
addappid(3238670)
-- Game: addappid(3238670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3238671, 1, "13cd290bb2c0f5a7295e7fb13e3a40c979c54085244db28c2251421edde94157")
