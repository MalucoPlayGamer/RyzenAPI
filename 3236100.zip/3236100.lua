-- Lua provided by RyzenAPI
-- Game: No Fap Island Demo

-- MAIN APPLICATION
addappid(3236100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3236101, 1, "f702dd211291d9128c65eeaf72915fd87c6df55d3a2df587ae04675472f1057f")

