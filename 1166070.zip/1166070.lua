-- Lua provided by RyzenAPI
-- Game: 1166070

-- MAIN APPLICATION
addappid(1166070)
-- Game: addappid(1166070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166071, 1, "bebf6d8b52be9da5f2e1d45a64f6ac9fcaac9809cbf56872b9899a4cc73c139e")
