-- Lua provided by RyzenAPI
-- Game: 3165080

-- MAIN APPLICATION
addappid(3165080)
-- Game: addappid(3165080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3165081, 1, "3c8a20e7b9707e5939f20204e99e2284edb0b868ea84b6ca5764bb48c58337ab")
