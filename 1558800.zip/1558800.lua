-- Lua provided by RyzenAPI
-- Game: Forgot

-- MAIN APPLICATION
addappid(1558800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558801, 1, "c05665b0f99bc941efdfddc15a6f34e4be2cfede2b6522eaa53b4c1dc82801d4")

