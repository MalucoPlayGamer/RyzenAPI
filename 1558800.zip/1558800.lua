-- Lua provided by RyzenAPI
-- Game: Forgot

-- MAIN APPLICATION
addappid(1558800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1558801, 1, "c05665b0f99bc941efdfddc15a6f34e4be2cfede2b6522eaa53b4c1dc82801d4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
