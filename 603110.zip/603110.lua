-- Lua provided by RyzenAPI
-- Game: Grizzland

-- MAIN APPLICATION
addappid(603110)
-- Game: addappid(603110)

-- MAIN APP DEPOTS / PACKAGES
addappid(603111, 1, "452c341301e7fa0a66f50bf8bb428c034857e357ec3c5fccc74860da9075c203")
