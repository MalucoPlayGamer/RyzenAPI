-- Lua provided by RyzenAPI
-- Game: Furry Shakespeare: Dashing Dinosaurs & Sexy Centaurs: Winter's Tale

-- MAIN APPLICATION
addappid(1152210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1152211, 1, "e50884b29d17daa2772ef67daa3f9b1ed78fbd8ca0701d4d6d243169c8e31c05")
addappid(1152212, 1, "7f873c756a75fb657d877d4a2c162ac9ebc849e3d7ff22ea83923f22d6a79448")
