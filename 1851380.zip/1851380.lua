-- Lua provided by RyzenAPI
-- Game: Happy's Humble Burger Barn

-- MAIN APPLICATION
addappid(1851380)
-- Game: addappid(1851380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1851381, 1, "1e2d267c62597f48fe441501807a229e89e02c14151ebd983cc1bf9ea66695ca")
