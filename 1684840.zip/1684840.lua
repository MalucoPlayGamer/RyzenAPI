-- Lua provided by SkyAPI 
-- Game: Hot Tub Simulator
addappid(1684840)
addappid(1684841, 1, "1fe433efc13b3a7d58679b5f8d4c4452cfba4b79bc8b653840bec6de885eda68")
