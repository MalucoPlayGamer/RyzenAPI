-- Lua provided by RyzenAPI
-- Game: addappid(1684840)

-- MAIN APPLICATION
addappid(1684840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684841, 1, "1fe433efc13b3a7d58679b5f8d4c4452cfba4b79bc8b653840bec6de885eda68")
