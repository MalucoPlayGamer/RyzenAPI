-- Lua provided by RyzenAPI
-- Game: Love n War: Hero by Chance II - Harem Secrets Uncensored (18+)

-- MAIN APPLICATION
addappid(1809620)
-- Game: addappid(1809620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809620,0,"fbaea82246be61e1c6c026a81d6858309742e6f837d637a52ef6a5766d0b9537")
