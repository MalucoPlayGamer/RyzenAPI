-- Lua provided by RyzenAPI
-- Game: Dreamsweeper Demo

-- MAIN APPLICATION
addappid(2540850)
-- Game: addappid(2540850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540851, 1, "d83f00a39648177e1b393fe294ed3703ff9fe52c5615f68e90871e87146f671e")
