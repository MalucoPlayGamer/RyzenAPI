-- Lua provided by SkyAPI 
-- Game: Ritual
addappid(1566560)
addappid(1566561, 1, "1f0f6b12c0439d37725841dd5a285228b9f26f3eb213e988b11f58066e4a856a")
