-- Lua provided by RyzenAPI
-- Game: AppID 535760

-- MAIN APPLICATION
addappid(535760)
-- Game: addappid(535760)

-- MAIN APP DEPOTS / PACKAGES
addappid(535761, 1, "7566813757d02e30bcb52054dcd3a796f22efe07ad36d3ad94f54072bc35298c")
