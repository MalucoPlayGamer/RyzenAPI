-- Lua provided by RyzenAPI
-- Game: Beat Saber - Aero Chord - "Boundless"

-- MAIN APPLICATION
addappid(1048870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048870,0,"fe2a7aa8ca1be8a507ed568f4744404b7bc3ee792ad757273c9494cec2c9f695")

