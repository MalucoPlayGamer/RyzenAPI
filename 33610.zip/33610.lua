-- Lua provided by RyzenAPI
-- Game: Game: Broken Sword 3 - the Sleeping Dragon (2003)

-- MAIN APPLICATION
addappid(33610)
-- Game: addappid(33610)

-- MAIN APP DEPOTS / PACKAGES
addappid(33611, 1, "b63689e558ba8a1bb31130cef59669bf26e259b4790a57cc1562b67983774b4a")
