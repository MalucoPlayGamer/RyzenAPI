-- Lua provided by SkyAPI 
-- Game: AppID 2122520
addappid(2122520)
addappid(2122521, 1, "206d1d78ca9c340bc07215b9626c4786cbc359530676eb282e58f39d22f35d39")
