-- Lua provided by RyzenAPI
-- Game: Space Station 51

-- MAIN APPLICATION
addappid(1426570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1426571, 1, "603d13366e5bec896307f17c99f67cb12251135dfc2841fb9411b2552b8c1fb4")

