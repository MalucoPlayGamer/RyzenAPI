-- Lua provided by RyzenAPI
-- Game: Space Station 51

-- MAIN APPLICATION
addappid(1426570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1426571, 1, "603d13366e5bec896307f17c99f67cb12251135dfc2841fb9411b2552b8c1fb4")

