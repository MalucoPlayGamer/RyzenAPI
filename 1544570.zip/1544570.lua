-- Lua provided by RyzenAPI
-- Game: Plot of the Druid: Nightwatch

-- MAIN APPLICATION
addappid(1544570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544571, 1, "d76d6da1a8c659f28603271c70a0126431f6a59bbf55f38a8b3c4b779f455ca1")
addappid(1544572, 1, "e586015c008a7499cb0fdfba184d2d7082199d68b2deffc0db93ff18cd9ca0e1")
addappid(1544573, 1, "e6646196f068d40b6f24877ab80df15f3867000eeb74aaa5b8e580b27512e449")

