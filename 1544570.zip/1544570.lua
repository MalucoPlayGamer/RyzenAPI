-- Lua provided by RyzenAPI
-- Game: Plot of the Druid: Nightwatch

-- MAIN APPLICATION
addappid(1544570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1544571, 1, "d76d6da1a8c659f28603271c70a0126431f6a59bbf55f38a8b3c4b779f455ca1")
addappid(1544572, 1, "e586015c008a7499cb0fdfba184d2d7082199d68b2deffc0db93ff18cd9ca0e1")
addappid(1544573, 1, "e6646196f068d40b6f24877ab80df15f3867000eeb74aaa5b8e580b27512e449")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
