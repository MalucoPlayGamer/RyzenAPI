-- Lua provided by RyzenAPI
-- Game: Perfect Poses

-- MAIN APPLICATION
addappid(2758210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2758211, 1, "ee4d400dfa9117a09b7abb2c18a07ddcbaad010f1e41f0b1ca97744b45f6fb29")

