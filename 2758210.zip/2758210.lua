-- Lua provided by RyzenAPI
-- Game: Perfect Poses

-- MAIN APPLICATION
addappid(2758210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2758211, 1, "ee4d400dfa9117a09b7abb2c18a07ddcbaad010f1e41f0b1ca97744b45f6fb29")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
