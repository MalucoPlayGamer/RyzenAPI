-- Lua provided by RyzenAPI
-- Game: Game: CUSTOM ORDER MAID 3D2 Soft Cuddly Girl GP-02

-- MAIN APPLICATION
addappid(2881140)
-- Game: addappid(2881140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2881141, 1, "deca02ad198f71f0a4498519e052712ee830baa2ad85344305ddb8dc9b9b9f08")
