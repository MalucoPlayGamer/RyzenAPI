-- Lua provided by RyzenAPI
-- Game: addappid(1494610)

-- MAIN APPLICATION
addappid(1494610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1494610,0,"9b1c407914b474517679e4cc1c75a12c7b7f7216066410b2abb5ff4fea7619de")
