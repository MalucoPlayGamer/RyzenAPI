-- Lua provided by RyzenAPI
-- Game: Sparky's Hunt

-- MAIN APPLICATION
addappid(514520)

-- MAIN APP DEPOTS / PACKAGES
addappid(514521,0,"7612ec3a2fc6e52a20f9375b1a712975ffc13f3b9dcbbc80e8ed12659ab7b84e")

