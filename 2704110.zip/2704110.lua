-- Lua provided by RyzenAPI
-- Game: addappid(2704110)

-- MAIN APPLICATION
addappid(2704110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2704111, 1, "3cc2f04cef5b384e21ad0f4ec9a3624efca4f18763f15128c997ef49a611ef4a")
