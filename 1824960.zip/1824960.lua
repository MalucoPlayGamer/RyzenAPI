-- Lua provided by RyzenAPI
-- Game: 1824960

-- MAIN APPLICATION
addappid(1824960)
-- Game: addappid(1824960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1824961, 1, "07c983e39744ab97539aecc2caddacc0191ba05697ba21cd96819d9cda496afd")
