-- Lua provided by RyzenAPI
-- Game: DouDas Danger

-- MAIN APPLICATION
addappid(1995100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995101, 1, "e326f8bebe5c5c139481555fba8575a2f02ff745f9de02badf022d94c990417a")

