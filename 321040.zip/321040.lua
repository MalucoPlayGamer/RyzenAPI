-- Lua provided by RyzenAPI
-- Game: AppID 321040

-- MAIN APPLICATION
addappid(321040)
-- Game: addappid(321040)

-- MAIN APP DEPOTS / PACKAGES
addappid(321041, 1, "a8fcf9cb8be847bc7e617384f9a4746c9796ec67bf64e9bbc73fce4a0b84c86d")
addappid(321042, 1, "11dce22cf110634073cbaa3c5d307ed6c588d4dbd3800e568efc1ccddfa9a24d")
addappid(321043, 1, "8431d194e6dc7b38aca771641beda703d8dc90101cdb348f3962aa7ad7990ee2")
addappid(321044, 1, "77169cd396e1a79fe6b9f0d64f6050593e8ce6c75c928fd59aef549aaf078c05")
addappid(321045, 1, "f3be39b057ad4bb9e60e6a779de8b1231f2f6657714e22a383418fd38b0de06f")
