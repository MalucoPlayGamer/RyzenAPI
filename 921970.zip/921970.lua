-- Lua provided by RyzenAPI
-- Game: AppID 921970

-- MAIN APPLICATION
addappid(921970)

-- MAIN APP DEPOTS / PACKAGES
addappid(921971, 1, "e9f4e4aab9277e91b7fe91b7883be24fa7a1756d78e3e964ac9fae9de262f0aa")
