-- Lua provided by RyzenAPI
-- Game: Outside The Box

-- MAIN APPLICATION
addappid(1563070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563071, 1, "46da09c39adc233ad3e4854f7a6fbe53da1318532b3e157fab32e4614d53602a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
