-- Lua provided by SkyAPI 
-- Game: Outside The Box
addappid(1563070)
addappid(1563071, 1, "46da09c39adc233ad3e4854f7a6fbe53da1318532b3e157fab32e4614d53602a")
