-- Lua provided by RyzenAPI
-- Game: Outside The Box

-- MAIN APPLICATION
addappid(1563070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1563071, 1, "46da09c39adc233ad3e4854f7a6fbe53da1318532b3e157fab32e4614d53602a")

