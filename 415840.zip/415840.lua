-- Lua provided by RyzenAPI
-- Game: Mystic Saga

-- MAIN APPLICATION
addappid(415840)
-- Game: addappid(415840)

-- MAIN APP DEPOTS / PACKAGES
addappid(415841, 1, "03fd4d44b66f2307ee165275492ab1e21e063de6c443dae2ff6e3bd7b016e0e2")
addappid(415842, 1, "ed421c9a1784050705c28dc521c250b78a9a9124ee71d1b9c66245ee8c1d3896")
addappid(415843, 1, "2db1be892cf4532a558e5496211527626efa2c872ce3b13cde2fa190263711da")
