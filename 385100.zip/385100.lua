-- Lua provided by RyzenAPI
-- Game: Space - The Return Of The Pixxelfrazzer

-- MAIN APPLICATION
addappid(385100)

-- MAIN APP DEPOTS / PACKAGES
addappid(385101, 1, "b617159cd0ff73b508d165befdbaabdd2929d0128de65631882fdfc224f677b9")
