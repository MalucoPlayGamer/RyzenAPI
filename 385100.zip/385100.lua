-- Lua provided by RyzenAPI
-- Game: Space - The Return Of The Pixxelfrazzer

-- MAIN APPLICATION
addappid(385100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(385101, 1, "b617159cd0ff73b508d165befdbaabdd2929d0128de65631882fdfc224f677b9")

