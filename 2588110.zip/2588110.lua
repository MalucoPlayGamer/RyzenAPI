-- Lua provided by SkyAPI 
-- Game: Playtown
addappid(2588110)
addappid(2588111, 1, "0e3d101e35028e1d4b680680afeb63d7afe9578ca10a1a066173c711c10d98ac")
