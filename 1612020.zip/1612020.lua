-- Lua provided by RyzenAPI
-- Game: Pure Sniper

-- MAIN APPLICATION
addappid(1612020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(1612021, 1, "4d97f163b978d77532f50499ff8edadcd99f48517210f4d34b000f7c2272eee3")

