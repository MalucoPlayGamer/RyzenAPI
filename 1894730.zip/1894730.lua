-- Lua provided by RyzenAPI
-- Game: Game: Asterix & Obelix XXXL : The Ram From Hibernia

-- MAIN APPLICATION
addappid(1894730)
-- Game: addappid(1894730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894731, 1, "9df8b240dfe169146c5d5a08f52d17c7e0de597bd5904ce17e52dfd2d2e95d83")
