-- Lua provided by RyzenAPI
-- Game: Asterix & Obelix XXXL : The Ram From Hibernia

-- MAIN APPLICATION
addappid(1894730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1894731, 1, "9df8b240dfe169146c5d5a08f52d17c7e0de597bd5904ce17e52dfd2d2e95d83")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
