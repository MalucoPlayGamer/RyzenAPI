-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2764950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2764950,0,"c4c231a528c0f4c95a95fceae57a4530982bd307bd8f07c47070e4a7adebff0b")

