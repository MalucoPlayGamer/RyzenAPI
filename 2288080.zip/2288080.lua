-- Lua provided by RyzenAPI
-- Game: Maumau and the Labyrinth

-- MAIN APPLICATION
addappid(2288080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2288081, 1, "e73b65c8a9783cb2a23f3bc5c023d3f37dda2670c1b7694fd4ce0e807dbdc96e")
addappid(2288082, 1, "0bb42a00b376c4535b7d2910e2509e1255e804287f0a2c4b4f302935ea3b5fa3")
addappid(2288083, 1, "7a7d92ab56065388aa0fe50bddaae713a5c4b1fefa87a5e2c082e60d0f042092")
addappid(2288084, 1, "72e25bea9090526dc68e64e1a57f7ea6aa82c0c8bc7852d514dd50a62c80fe85")
