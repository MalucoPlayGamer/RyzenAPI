-- Lua provided by RyzenAPI
-- Game: Game: AppID 1134320

-- MAIN APPLICATION
addappid(1134320)
-- Game: addappid(1134320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1134321, 1, "0f84e9683641d7ffd3e327c26be911cf48a57d4644155be0b5d3b600e4d4a9f7")
