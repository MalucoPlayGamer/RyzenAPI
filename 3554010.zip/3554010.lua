-- Lua provided by SkyAPI 
-- Game: AppID 3554010
addappid(3554010)
addappid(3554011, 1, "48c7dac47ceef12cc12daa80d4c0cfaa1a51bdb9e29176b2168ba5bd36820c25")
