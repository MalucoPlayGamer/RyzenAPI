-- Lua provided by RyzenAPI
-- Game: addappid(3554010)

-- MAIN APPLICATION
addappid(3554010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3554011, 1, "48c7dac47ceef12cc12daa80d4c0cfaa1a51bdb9e29176b2168ba5bd36820c25")
