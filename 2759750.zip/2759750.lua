-- Lua provided by RyzenAPI
-- Game: Animal Race Run VR

-- MAIN APPLICATION
addappid(2759750)
-- Game: addappid(2759750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2759751, 1, "435c547b997f109fcee9f67facc2f135b86f525a2413fa187415525f304b1b38")
