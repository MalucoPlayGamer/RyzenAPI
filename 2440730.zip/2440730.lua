-- Lua provided by RyzenAPI
-- Game: Snoody: One of the Ayrie

-- MAIN APPLICATION
addappid(2440730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2440731, 1, "439d9ec09b08288b8a5aba77248017f2809eda666f7d7a17c3319d270b35b060")

