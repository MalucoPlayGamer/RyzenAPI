-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(428200)
addappid(428201)
addappid(428203)
addappid(428204)
addappid(486830)

-- MAIN APP DEPOTS / PACKAGES
addappid(428202,0,"748d5511b995cfcd89b6361d1024f2735a46b3066260bf23cc6251a2aa0f77d8")
