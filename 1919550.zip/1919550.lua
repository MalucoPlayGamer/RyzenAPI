-- Lua provided by RyzenAPI
-- Game: addappid(1919550)

-- MAIN APPLICATION
addappid(1919550)
addappid(2544250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919551, 1, "652d7a7d59ecf3d28ec4f342cf3c611287ed5d5f0f7be54d90b1dc0c5096af81")
addappid(1919552, 1, "87d50acbc5ade240fb46c5923d9bf46e6b1c46ee99f00bf4c0803a4432b52f75")
