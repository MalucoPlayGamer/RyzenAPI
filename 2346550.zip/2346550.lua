-- Lua provided by RyzenAPI
-- Game: 2346550

-- MAIN APPLICATION
addappid(2346550)
-- Game: addappid(2346550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2346551, 1, "8d61c9043983abae106ea8241bb683c5604945f0bf49e2638ace99e883c11c74")
