-- Lua provided by RyzenAPI 
-- Game: Rise of Eros
addappid(2346550)
addappid(2346551, 1, "8d61c9043983abae106ea8241bb683c5604945f0bf49e2638ace99e883c11c74")
