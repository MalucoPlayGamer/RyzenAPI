-- Lua provided by RyzenAPI
-- Game: Rise of Eros

-- MAIN APPLICATION
addappid(2346550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2346551, 1, "8d61c9043983abae106ea8241bb683c5604945f0bf49e2638ace99e883c11c74")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4981860)
