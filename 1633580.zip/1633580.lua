-- Lua provided by RyzenAPI
-- Game: AppID 1633580

-- MAIN APPLICATION
addappid(1633580)
-- Game: addappid(1633580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1633581, 1, "1fbfe3a052a7519e99e842a41fa16eb1fbd498bccec8af80ca848072e7badfaf")
