-- Lua provided by RyzenAPI
-- Game: 无奇刀 Wookie's Blade

-- MAIN APPLICATION
addappid(1058750)
-- Game: addappid(1058750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1058751, 1, "af10fda493dccc1147cf55e4030680145418a65c843af302c1e2ef581a251ad6")
