-- Lua provided by RyzenAPI 
-- Game: Brain Syndrome VR
addappid(2059550)
addappid(2059551, 1, "0e15ff817406deafc2958377d0e4384e92199ab6e02b9e7b2b8936a1920c3e36")
