-- Lua provided by RyzenAPI
-- Game: Brain Syndrome VR

-- MAIN APPLICATION
addappid(2059550)
-- Game: addappid(2059550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2059551, 1, "0e15ff817406deafc2958377d0e4384e92199ab6e02b9e7b2b8936a1920c3e36")
