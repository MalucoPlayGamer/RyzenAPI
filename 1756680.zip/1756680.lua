-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Heroine Character Generator 2 for MZ

-- MAIN APPLICATION
addappid(1756680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1756680,0,"67a01516c89efb254ddba1c752a1b2611125e9d5c79bf35b61bd8cdaeecbf2f6")

