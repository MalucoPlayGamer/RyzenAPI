-- Lua provided by RyzenAPI
-- Game: addappid(2274660)

-- MAIN APPLICATION
addappid(2274660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2274661, 1, "ed110f41e6cb85e52cddac689d2d46ac723c96b8477f86fa4cbed4808139c1d0")
