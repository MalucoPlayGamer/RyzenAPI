-- Lua provided by RyzenAPI
-- Game: Primate Signal

-- MAIN APPLICATION
addappid(1153040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1153041, 1, "6d761df3c46b4e3779e726d9490685bf23b395ca8d6bec2de7d5e86f2abeddb2")

