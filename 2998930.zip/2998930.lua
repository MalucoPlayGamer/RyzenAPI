-- Lua provided by RyzenAPI
-- Game: JR EAST Train Simulator: Narita Line (Choshi to Chiba) 209-2100 series Kashima Line (Kashima-Soccer Stadium to Sawara) 209-2100 series

-- MAIN APPLICATION
addappid(2998930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2998931, 1, "b3f4e6431988321e1244692529b04f0d3dfe18150a1beb51feeab0c641484443")
addappid(2998932, 1, "7aeb31fd1d20580e78689954d896628526445513800a908b0dbc8b439472175b")
addappid(2998933, 1, "65d9554d58fc77b931c0c027a94704e90f2dd651e97862d71cee55399c1f6fa9")
addappid(2998934, 1, "de11fb55b34e3a01820a838a82435a00a454101d4cfe9a57dd5e0ae340df00e6")
