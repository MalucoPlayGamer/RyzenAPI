-- Lua provided by RyzenAPI 
-- Game: Hellwatch
addappid(2468720)
addappid(2468721, 1, "fb2edba494f90cac58d1ffa959f16fae97a8efe81e922810b43136c13bc4be2b")
