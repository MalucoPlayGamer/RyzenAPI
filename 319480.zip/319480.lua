-- Lua provided by RyzenAPI
-- Game: AppID 319480

-- MAIN APPLICATION
addappid(319480)
addappid(366120)
addappid(366121)
addappid(366122)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(319481, 1, "fcfda023478201c4bf9232963e853493a8da782d1d3b2da53e3533b3969b8584")
addappid(389590, 0, "dde2f75c956e7b992ed24ea7d60d9acde0e84817e0c2421b61f36deaf73756ef")
addappid(389591, 0, "1ab6fa6b2c2393ed1ec01bd423b2b106a46e57db65e1aea98fc6747cf8f41590")

