-- Lua provided by RyzenAPI
-- Game: addappid(319480)

-- MAIN APPLICATION
addappid(319480)

-- MAIN APP DEPOTS / PACKAGES
addappid(319481, 1, "fcfda023478201c4bf9232963e853493a8da782d1d3b2da53e3533b3969b8584")
addappid(389590, 0, "dde2f75c956e7b992ed24ea7d60d9acde0e84817e0c2421b61f36deaf73756ef")
addappid(389591, 0, "1ab6fa6b2c2393ed1ec01bd423b2b106a46e57db65e1aea98fc6747cf8f41590")
