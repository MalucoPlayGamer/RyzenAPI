-- Lua provided by RyzenAPI
-- Game: Star Survivor - Prologue

-- MAIN APPLICATION
addappid(2289280)
-- Game: addappid(2289280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2289281, 1, "227d65bb9785fcdba56d3b6f651aba41285850c7daf22edecbb737bba90ed9ff")
