-- Lua provided by RyzenAPI
-- Game: addappid(1809250)

-- MAIN APPLICATION
addappid(1809250)
addappid(2264720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1809251, 1, "c28e018e2ab34c8ce960cc799e585ca75b9669cebe4b1aa669dd25b57c545d9e")
