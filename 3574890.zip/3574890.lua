-- Lua provided by RyzenAPI
-- Game: AppID 3574890

-- MAIN APPLICATION
addappid(3574890)
-- Game: addappid(3574890)

-- MAIN APP DEPOTS / PACKAGES
addappid(3574891, 1, "96dafd291e5b1aceeda8bef363b6e6982091e2748c9bdb70c7a3e6804bace857")
