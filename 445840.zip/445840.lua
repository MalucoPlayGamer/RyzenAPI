-- Lua provided by RyzenAPI
-- Game: Undead vs Plants

-- MAIN APPLICATION
addappid(445840)

-- MAIN APP DEPOTS / PACKAGES
addappid(445841, 1, "aa5dc82246e2f2ce1f576b0c0940444fdf1fe4072276f94fd832f988803c910e")

