-- Lua provided by RyzenAPI
-- Game: Game: AppID 1037520

-- MAIN APPLICATION
addappid(1037520)
-- Game: addappid(1037520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1037521, 1, "131fa322dc4ce4243e41ed09e36361dc7daa08fa038a058823fc813c75678f0e")
