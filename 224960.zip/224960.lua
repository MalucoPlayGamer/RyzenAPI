-- Lua provided by RyzenAPI
-- Game: Tomb Raider I (1996)

-- MAIN APPLICATION
addappid(224960)

-- MAIN APP DEPOTS / PACKAGES
addappid(224961, 1, "000cf5fca54372f6c9a80bc4bd91927221a8966a0862fbdde7b22a41fa50b2d5")
