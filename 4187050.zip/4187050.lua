-- 4187050's Lua and Manifest Created by Hubcap Manifest
-- NTR CORE
-- Created: August 28, 2026 at 23:25:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4187050) -- NTR CORE
-- MAIN APP DEPOTS
addappid(4187051, 1, "67665c5fcee5e171a3d5ab2dd829a6e06638a731acfc26e834aef04897b59d77") -- Depot 4187051
setManifestid(4187051, "3490354927824032198", 389389715)