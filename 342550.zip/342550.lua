-- Lua provided by RyzenAPI
-- Game: 342550

-- MAIN APPLICATION
addappid(342550)
-- Game: addappid(342550)

-- MAIN APP DEPOTS / PACKAGES
addappid(342551, 1, "82e06574bda4b679c629cf77a99a6a612e6751d97ebcabf19ca107d55627655f")
