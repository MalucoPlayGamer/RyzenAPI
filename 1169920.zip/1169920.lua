-- Lua provided by SkyAPI 
-- Game: SafeHome
addappid(1169920)
addappid(1169921, 1, "2b590326d38806f7cc5800ba265136dce2f274dab0a493fc4d0a0560b2cb4115")
addappid(1169922, 1, "70bc65c53abf88c3a1e18e7346256ea3e55c96263dca4e780e375ffffb4cc863")
