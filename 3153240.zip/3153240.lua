-- Lua provided by RyzenAPI
-- Game: IF Solitaire

-- MAIN APPLICATION
addappid(3153240)
addappid(4496800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3153241, 1, "fc02d6f7f1a84a14dca32d93c535eefcbc11c61c9fbddae284f5730ab4f74b62")
