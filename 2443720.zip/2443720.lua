-- Lua provided by RyzenAPI
-- Game: addappid(2443720)

-- MAIN APPLICATION
addappid(2443720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443721, 1, "f0892830a844873bbfba514f05ad5a9c1da6fc15e033663ca1bc65ba2b821c6d")
