-- Lua provided by RyzenAPI
-- Game: addappid(429200)

-- MAIN APPLICATION
addappid(429200)

-- MAIN APP DEPOTS / PACKAGES
addappid(429201, 1, "72441db59c1db228bcc3bb758e9775d6635d1277c2ada9329c3ffdb36c277a18")
addappid(429202, 1, "53ec39d0ce7fb8ac7bba9aba66e774c795188a2c3c7691beaf983ff31e1f5483")
addappid(429203, 1, "62e9e7e285c72cc73e452816c73fa7c033f0cda35c2b23a0d60dc2fca8ce9002")
addappid(429204, 1, "34555e64a456dc4027617efdfa3c323c621ba9d9cbf0096eb67e534c8da72c7e")
