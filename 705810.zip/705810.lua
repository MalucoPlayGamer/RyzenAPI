-- Lua provided by RyzenAPI
-- Game: AppID 705810

-- MAIN APPLICATION
addappid(705810)
-- Game: addappid(705810)

-- MAIN APP DEPOTS / PACKAGES
addappid(705811, 1, "9e2fdeed9654865585332acb72e64c389c035bf64ff3439b28c02a6825a3387a")
