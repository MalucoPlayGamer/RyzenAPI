-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1227455)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227455,0,"ad787988cfd6a27397fa72ac6305093fae9b1d483637be74ffe45fc8b02d928c")
