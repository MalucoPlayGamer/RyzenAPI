-- Lua provided by RyzenAPI
-- Game: Back to the Rooms Demo

-- MAIN APPLICATION
addappid(3184850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3184851, 1, "e1e7f2c373dc317f1cdff650c08df3aa49c2bddf3c62eaaf28c5298ab53de6bb")
