-- Lua provided by RyzenAPI
-- Game: Trivia Vault: Art Trivia

-- MAIN APPLICATION
addappid(851710)

-- MAIN APP DEPOTS / PACKAGES
addappid(851711, 1, "9fad7d38245b874504c0783396d1d04c2067d0aa89dc5ea786bb56285c78d3cb")
