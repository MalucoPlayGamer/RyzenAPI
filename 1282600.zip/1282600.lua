-- Lua provided by RyzenAPI
-- Game: Mayhem in Single Valley: Confessions

-- MAIN APPLICATION
addappid(1282600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1282601, 1, "7f5b14480c687e3acbc339534d0aa4990c62c6ed75d16c50c30bb169330251ae")
