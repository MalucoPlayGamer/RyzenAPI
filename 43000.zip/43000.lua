-- Lua provided by RyzenAPI
-- Game: AppID 43000

-- MAIN APPLICATION
addappid(43000)

-- MAIN APP DEPOTS / PACKAGES
addappid(43001, 1, "8d954f82d5d9d4338f03c8cb701b07f060c96ef8e8e4496d422d63c3c5ba8986")
addappid(43002, 1, "1f1f2e66bc0895201b20fef8f71b2b31f4afc682f12c304d9e59d26bd38895c9")
addappid(43003, 1, "054197ae8cf158ca9f2f37d5ce180d184a5aa93bb423af5219b08c34f5da742d")
addappid(43005, 1, "06ec98f534604bf4ee85fc57aab54402e11293d1641b19523e1366d2fe5f9144")
addappid(43006, 1, "109f9a9e026b44610739487ded0c07c83aca34874d2a0d3bc7e089a2c116cc1e")
addappid(43007, 1, "6a2afe9babfd4d4a4a081544c2c5de9d070890b542f7e8b058415ab2c1f75dc7")
addappid(43008, 1, "6127eaa91788165da5e4e9c81a2fa51b1616948b370bd22653ccf09cb848c943")
addappid(43009, 1, "1091adce60020a24e43fbd23c4158aabf1d259a572df015e3ea320bd8684b1e7")
addappid(43010, 1, "264d8ca1be78960a1a6fceb42061fdb742d3cb6035e584da888a202b1d339503")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(43011)
addappid(43012)
addappid(43013)
addappid(43014)
addappid(43015)
addappid(43016)
