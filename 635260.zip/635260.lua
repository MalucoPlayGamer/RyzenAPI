-- Lua provided by RyzenAPI
-- Game: CarX Drift Racing Online

-- MAIN APPLICATION
addappid(635260)
addappid(752440)
addappid(752450)
addappid(769710)
addappid(776950)
addappid(842050)
addappid(858690)
addappid(906130)
addappid(937630)
addappid(965040)
addappid(967320)
addappid(998560)
addappid(1112420)
addappid(1112460)
addappid(1112470)
addappid(1159010)
addappid(1178950)
addappid(1214350)
addappid(1308670)
addappid(1308680)
addappid(1449350)
addappid(1535220)
addappid(1786050)
addappid(1901670)
addappid(2096530)
addappid(2154970)
addappid(2395750)
addappid(2638160)
addappid(3292330)
addappid(3559570)
addappid(3559630)
addappid(3559650)

-- MAIN APP DEPOTS / PACKAGES
addappid(635261, 1, "12eafb480d17be3196fc40eeec87820d98ecf98fc24580764a1b86d14ae04cef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
