-- Lua provided by RyzenAPI
-- Game: 2626650

-- MAIN APPLICATION
addappid(2626650)
-- Game: addappid(2626650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2626651, 1, "86ddecf7b9810ca55616fba0a5637b24132b448ab9a221840ceefa7f2e311d91")
