-- Lua provided by RyzenAPI 
-- Game: Real Cricket Mod Creator
addappid(2626650)
addappid(2626651, 1, "86ddecf7b9810ca55616fba0a5637b24132b448ab9a221840ceefa7f2e311d91")
