-- Lua provided by RyzenAPI
-- Game: 267750

-- MAIN APPLICATION
addappid(267750)
addappid(377730)
addappid(383660)
-- Game: addappid(267750)

-- MAIN APP DEPOTS / PACKAGES
addappid(267751, 1, "1fb3cda1c6543b9b4458a1326d36ded57a49161c67c302072e1d1deb21b7e65d")
addappid(267752, 1, "2f6b6304571ce43927d39d55da87f36c4007f44517483dcae66e3c1d8e03ec92")
addappid(267753, 1, "13f7c7d0a4f5e1933a108447183ac7d9b3fd786d61e579af6bdc9dc05d3fca51")
addappid(267756, 1, "9040586cc03616f311ce47632d4b8329c70f6dc4e43e1ed0a4c6adfb3c67f01c")
addappid(267757, 1, "40f71a20f71e68ceeea6a74ddfa897714d0268421bef866acecd7ecc4726f0a4")
addappid(267759, 1, "2e9af6fdcc2955bd2c992c7de798c46f874b2a01fe60e51248c6ad761bc9a23c")
