-- Lua provided by RyzenAPI
-- Game: Shadowrun Chronicles - Boston Lockdown

-- MAIN APPLICATION
addappid(267750)
addappid(288320)
addappid(288321)
addappid(288322)
addappid(324300)
addappid(363000)
addappid(377700)
addappid(377730)
addappid(383660)
addappid(405730)
addappid(435190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(267751,0,"1fb3cda1c6543b9b4458a1326d36ded57a49161c67c302072e1d1deb21b7e65d")
addappid(267752,0,"2f6b6304571ce43927d39d55da87f36c4007f44517483dcae66e3c1d8e03ec92")
addappid(267753,0,"13f7c7d0a4f5e1933a108447183ac7d9b3fd786d61e579af6bdc9dc05d3fca51")
addappid(267756,0,"9040586cc03616f311ce47632d4b8329c70f6dc4e43e1ed0a4c6adfb3c67f01c")
addappid(267757,0,"40f71a20f71e68ceeea6a74ddfa897714d0268421bef866acecd7ecc4726f0a4")
addappid(267759,0,"2e9af6fdcc2955bd2c992c7de798c46f874b2a01fe60e51248c6ad761bc9a23c")

