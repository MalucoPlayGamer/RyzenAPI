-- Lua provided by RyzenAPI
-- Game: Farmer Adventure

-- MAIN APPLICATION
addappid(1852890)
-- Game: addappid(1852890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1852891, 1, "b94004fabe5c11684c670ecc734f994750896979f56033e90b7192051f6366fa")
