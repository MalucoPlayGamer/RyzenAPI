-- Lua provided by RyzenAPI
-- Game: Game: AppID 1507530

-- MAIN APPLICATION
addappid(1507530)
-- Game: addappid(1507530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507531, 1, "ad1950629b2d4ec3059098f5efba250c6554e2bd292adc88754543e1b5116814")
