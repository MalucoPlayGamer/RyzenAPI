-- Lua provided by SkyAPI 
-- Game: AppID 1507530
addappid(1507530)
addappid(1507531, 1, "ad1950629b2d4ec3059098f5efba250c6554e2bd292adc88754543e1b5116814")
