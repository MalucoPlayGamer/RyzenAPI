-- Lua provided by RyzenAPI
-- Game: Game: Medieval Machines Builder Demo

-- MAIN APPLICATION
addappid(2461510)
-- Game: addappid(2461510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461511, 1, "5fd5003e4f8b0e8bd7816630d82e3c99972b33dc9d327b6e69a542961ed0dc3e")
