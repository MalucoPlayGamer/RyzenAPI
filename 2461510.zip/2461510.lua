-- Lua provided by RyzenAPI 
-- Game: Medieval Machines Builder Demo
addappid(2461510)
addappid(2461511, 1, "5fd5003e4f8b0e8bd7816630d82e3c99972b33dc9d327b6e69a542961ed0dc3e")
