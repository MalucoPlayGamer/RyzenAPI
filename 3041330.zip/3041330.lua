-- Lua provided by RyzenAPI
-- Game: AppID 3041330

-- MAIN APPLICATION
addappid(3041330)
-- Game: addappid(3041330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3041331, 1, "03af4c7927d644367ead7d4f249509d2e5f13d7214db95ecc991619f06b6b014")
