-- Lua provided by RyzenAPI
-- Game: Game: Duck Detective: The Secret Salami

-- MAIN APPLICATION
addappid(2637990)
-- Game: addappid(2637990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2637991, 1, "4d63488abb36eb570989aaf5440185dbddf43c2832f70134924261f83b9e8901")
addappid(2637992, 1, "cf64d0115b6f32262b3d65d86003d96506cbd4912ac5377336ec9633614d0c3d")
addappid(2637993, 1, "f2046ebddcf2f1233f2b21ce04f8a164fe68b818c7de553d4e7d7a009267f9d9")
