-- Lua provided by RyzenAPI
-- Game: Exterminator

-- MAIN APPLICATION
addappid(597670)

-- MAIN APP DEPOTS / PACKAGES
addappid(597672,0,"be94e659a12569d5d649ea03fc8948ec7ad683bc3a0ea46157fda472050f8e08")

