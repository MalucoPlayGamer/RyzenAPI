-- Lua provided by RyzenAPI
-- Game: addappid(2739420)

-- MAIN APPLICATION
addappid(2739420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2739421, 1, "134be2055433f7a9cccd45137b7c0973ba8dfdec971269fed447301b308109c4")
