-- Lua provided by RyzenAPI
-- Game: //N.P.P.D. RUSH//- The milk of Ultraviolet

-- MAIN APPLICATION
addappid(270090)

-- MAIN APP DEPOTS / PACKAGES
addappid(270091, 1, "d6024f3c5c49405b603eec25b123e3d301d6bc26773839ac017eb446098ed1e5")
