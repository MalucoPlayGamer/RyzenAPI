-- Lua provided by RyzenAPI
-- Game: Combat Racers

-- MAIN APPLICATION
addappid(444870)

-- MAIN APP DEPOTS / PACKAGES
addappid(444871, 1, "4fc3c393bbff818a492e1fb8b35fedd403d3d2e4a4af43301aab919b4213d725")
