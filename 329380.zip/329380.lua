-- Lua provided by RyzenAPI
-- Game: Stealth Inc 2: A Game of Clones

-- MAIN APPLICATION
addappid(329380)
-- Game: addappid(329380)

-- MAIN APP DEPOTS / PACKAGES
addappid(329381, 1, "a3c07fd2ece3487a64ab625aefc5048a4582a987ac7a38998f99ee97512cef92")
addappid(390760, 0, "3b8f768c57110fd0dfa08f8c57167eb62dfc5433a386e13223ea4d1b344a5f26")
