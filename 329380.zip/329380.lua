-- Lua provided by RyzenAPI
-- Game: Stealth Inc 2: A Game of Clones

-- MAIN APPLICATION
addappid(329380)

-- MAIN APP DEPOTS / PACKAGES
addappid(329381, 1, "a3c07fd2ece3487a64ab625aefc5048a4582a987ac7a38998f99ee97512cef92")
addappid(390760, 0, "3b8f768c57110fd0dfa08f8c57167eb62dfc5433a386e13223ea4d1b344a5f26")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
