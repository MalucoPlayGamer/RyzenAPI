-- Lua provided by RyzenAPI
-- Game: addappid(598610)

-- MAIN APPLICATION
addappid(598610)

-- MAIN APP DEPOTS / PACKAGES
addappid(598611, 1, "d657fa2c4a2bcf77012a3d14dcef87ac391751267c4d22c713510ec7e42bb2ed")
