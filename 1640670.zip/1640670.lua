-- Lua provided by RyzenAPI
-- Game: Infected City

-- MAIN APPLICATION
addappid(1640670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1640671, 1, "80e970d4a3178d0323c6c68f45c683a6dba37e2ce3da8672ae4dda2ffe5c3c0d")

