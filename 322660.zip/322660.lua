-- Lua provided by RyzenAPI
-- Game: AppID 322660

-- MAIN APPLICATION
addappid(322660)

-- MAIN APP DEPOTS / PACKAGES
addappid(322661, 1, "6c8f5e0423cd4e9f34a9ff9b9f4bc95464e3fd93f03bb699be87ec06402cefc0")

