-- Lua provided by RyzenAPI
-- Game: Game: Roaming Fortress

-- MAIN APPLICATION
addappid(323000)
-- Game: addappid(323000)

-- MAIN APP DEPOTS / PACKAGES
addappid(323001, 1, "7d954583deacb4dbd44bd7594eae4318e72c8303b6011f442dae92e7e51e990c")
