-- Lua provided by SkyAPI 
-- Game: METAL SLUG Soundtrack
addappid(1940590)
addappid(1940591, 1, "a821a44919c51178d4cc60a7eaa906a41ca4d096038f73b2ba0f97aa5e72ae7d")
addappid(1940592, 1, "dc5c313b416e8bab8f17cc4b07d1d13cfdbc0497ee84613ce1a92496098dcd1f")
