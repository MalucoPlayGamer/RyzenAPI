-- Lua provided by RyzenAPI
-- Game: Toby: The Secret Mine

-- MAIN APPLICATION
addappid(395160)
-- Game: addappid(395160)

-- MAIN APP DEPOTS / PACKAGES
addappid(395161, 1, "91b6547841bfc751840cc14d8e8e907938c50548fe8f60b1cda71c801642d4fc")
addappid(395162, 1, "1c9ec01588e16fbe7aabde1a43f9311b4d9e7f653626df7dfb2997eb92682c0c")
addappid(395163, 1, "72826b19bab3151f663522486c00c8993bb767b698ccab2b0213c97a8999956e")
