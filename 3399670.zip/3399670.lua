-- Lua provided by RyzenAPI
-- Game: 3399670

-- MAIN APPLICATION
addappid(3399670)
-- Game: addappid(3399670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3399671, 1, "e830ae2a48697aae34419d6ae0fa399aeb4cda20983161597738da71acf01dce")
