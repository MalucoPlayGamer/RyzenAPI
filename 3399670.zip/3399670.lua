-- Lua provided by RyzenAPI 
-- Game: AppID 3399670
addappid(3399670)
addappid(3399671, 1, "e830ae2a48697aae34419d6ae0fa399aeb4cda20983161597738da71acf01dce")
