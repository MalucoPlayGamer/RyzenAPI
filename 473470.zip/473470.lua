-- Lua provided by RyzenAPI
-- Game: Game: Purgatory

-- MAIN APPLICATION
addappid(473470)
-- Game: addappid(473470)

-- MAIN APP DEPOTS / PACKAGES
addappid(473471, 1, "a9093387d86ce634b32b939688f2526c6ddaec927f60ce0970437b04b7736cef")
addappid(473472, 1, "06b5e5f739f4366c0acbade70a4cd835bcf454487227c7215eb72edfca99d0c0")
addappid(473473, 1, "61a8fb8a9d278524bd9728865ac924cd793a00320e76b18e962a6e80721407cc")
