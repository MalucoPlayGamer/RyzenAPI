-- Lua provided by RyzenAPI
-- Game: addappid(2562730)

-- MAIN APPLICATION
addappid(2562730)
addappid(3060840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2562731, 1, "dbb4d59e95702fce0234b2ac145cf0ff144ba228ab45b29adfbedf5e3885fa9d")
addappid(2562732, 1, "07eb52d61649c609f29b4028c4e0a4ea5f20333ab3f4397a64316b5f76a011c9")
addappid(2562733, 1, "e5eb7d890d42b8eda51c17bea2ad0e4111ab3e02730d6b7aba37b68c37ead7e7")
