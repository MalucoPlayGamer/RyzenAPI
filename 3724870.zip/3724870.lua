-- Lua provided by RyzenAPI 
-- Game: AppID 3724870
addappid(3724870)
addappid(3724871, 1, "cd6efe6b7669e0e4e16a2aeadb4515444f0a0dfc74058c26aeb687f559603567")
