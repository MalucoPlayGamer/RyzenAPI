-- Lua provided by RyzenAPI
-- Game: Game: AppID 834170

-- MAIN APPLICATION
addappid(834170)
-- Game: addappid(834170)

-- MAIN APP DEPOTS / PACKAGES
addappid(834171, 1, "6733b20faca14b277370d6601659f2940972eaff16a99dbd37e2dacb1d28123b")
addappid(834172, 1, "4f40d3b7c0ee35b80597fee3162d1474b2b6533239cfe5ac52c7e960f816b27d")
addappid(834173, 1, "89af74fb4469642fd831c282f0506f9b39f5b4aa5a6a47729edd22bfdbdb54e8")
