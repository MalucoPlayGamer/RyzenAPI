-- Lua provided by RyzenAPI
-- Game: Sex Apartment 💫

-- MAIN APPLICATION
addappid(3362480)
addappid(3495760)
addappid(3495770)
addappid(3495780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3362481, 1, "048a088dec4738e3d2e1643145aef5055fc6de3718f370b526fa3ae18b79250a")

