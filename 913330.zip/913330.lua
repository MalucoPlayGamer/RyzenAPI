-- Lua provided by RyzenAPI
-- Game: Game: AppID 913330

-- MAIN APPLICATION
addappid(913330)
-- Game: addappid(913330)

-- MAIN APP DEPOTS / PACKAGES
addappid(913331, 1, "f117036c41ea8c48e61c4424451f26f2c26b3904eaac86501d3029329d8e8824")
