-- Lua provided by RyzenAPI
-- Game: 11280

-- MAIN APPLICATION
addappid(11280)
-- Game: addappid(11280)

-- MAIN APP DEPOTS / PACKAGES
addappid(11281, 1, "840ab5ef0536f5ddfaccfdd3f8b15de3dd84c68afd0d0797dbca6855d7b9fd29")
addappid(11282, 1, "e8647808fef5398482efe7e0fd2871e33f5e9516e615d0bb7c5a880cf6ce96e1")
