-- Lua provided by RyzenAPI
-- Game: Game: Anomaly Exit

-- MAIN APPLICATION
addappid(2232600)
-- Game: addappid(2232600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232601, 1, "3c17ce9caff29bfcd7dc2122d41ac1296dbe7f1b77678e8139ba4d56a01e42df")
