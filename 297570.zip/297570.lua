-- Lua provided by RyzenAPI 
-- Game: Warrior Kings
addappid(297570)
addappid(297571, 1, "bf9f658b1f7ac1552cabc0d1372f1af0933d266ecc53d9d60cfc0bc5e97ad3a6")
