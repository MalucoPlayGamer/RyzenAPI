-- Lua provided by RyzenAPI
-- Game: Game: AppID 1337010

-- MAIN APPLICATION
addappid(1337010)
-- Game: addappid(1337010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1337011, 1, "68e280c4fe1215b55d8966b0e718e324b3ed8b622ca5ed15fff31501033dc42b")
