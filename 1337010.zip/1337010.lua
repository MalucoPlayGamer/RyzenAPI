-- Lua provided by RyzenAPI
-- Game: Alba: A Wildlife Adventure

-- MAIN APPLICATION
addappid(1337010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1337011, 1, "68e280c4fe1215b55d8966b0e718e324b3ed8b622ca5ed15fff31501033dc42b")
