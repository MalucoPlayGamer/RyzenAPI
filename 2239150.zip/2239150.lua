-- Lua provided by RyzenAPI
-- Game: Thronefall

-- MAIN APPLICATION
addappid(2239150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2239151, 1, "505a16dd8c80b12c26bfa9c7780547cf33fff50602e31744cd4d7e582df2870c")
addappid(2239152, 1, "455a0cb3bb7f77acddf7a891cf8ab8151cb44a5edd2298b022b205cc88fdef63")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
