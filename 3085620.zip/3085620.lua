-- Lua provided by RyzenAPI
-- Game: Game: Sky's The Limit MAH-JONG

-- MAIN APPLICATION
addappid(3085620)
-- Game: addappid(3085620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3085621, 1, "fa2e43a5d217846462b1d851913714bdf4577868496d4f0448c484d2ba3bc4ee")
