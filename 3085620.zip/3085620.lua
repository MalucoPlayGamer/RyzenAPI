-- Lua provided by RyzenAPI
-- Game: Sky's The Limit MAH-JONG

-- MAIN APPLICATION
addappid(3085620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3085621, 1, "fa2e43a5d217846462b1d851913714bdf4577868496d4f0448c484d2ba3bc4ee")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
