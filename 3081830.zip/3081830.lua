-- Lua provided by RyzenAPI
-- Game: Game: FLARE NUINUI QUEST

-- MAIN APPLICATION
addappid(3081830)
-- Game: addappid(3081830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3081831, 1, "dd068a9adcc6204d9b7be77e446c86cb52b17c33441f2c9e7c4c4d357f91ac58")
