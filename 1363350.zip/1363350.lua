-- Lua provided by RyzenAPI
-- Game: Game: Monster Harvest

-- MAIN APPLICATION
addappid(1363350)
-- Game: addappid(1363350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1363351, 1, "58173c80594d295124e503790ce6cdc56dcb85e5eae0bef2f6e1fb5fd9ec77c4")
