-- Lua provided by RyzenAPI
-- Game: The Sims™ 2 Legacy Collection

-- MAIN APPLICATION
addappid(3314070)
-- Game: addappid(3314070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3314071, 1, "c23a39e45d9412b1dd04e0051e20bbb18e8155211fb746406373bd16d6409c50")
