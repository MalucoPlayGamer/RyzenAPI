-- Lua provided by RyzenAPI
-- Game: The Sims™ 2 Legacy Collection

-- MAIN APPLICATION
addappid(3314070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3314071, 1, "c23a39e45d9412b1dd04e0051e20bbb18e8155211fb746406373bd16d6409c50")

