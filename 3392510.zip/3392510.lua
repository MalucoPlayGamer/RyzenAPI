-- Lua provided by RyzenAPI
-- Game: Zexion

-- MAIN APPLICATION
addappid(3392510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3392511, 1, "5d53f23ed21b4ab30e5d0695879fba7a477dc9f550e3d934ccfc2e42317c09e8")
addappid(3392512, 1, "00d802867681ff00c5b399b781484783237bbea9b21626cb26b438d5e435868f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
