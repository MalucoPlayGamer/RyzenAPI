-- Lua provided by RyzenAPI
-- Game: Game: Mall Craze

-- MAIN APPLICATION
addappid(1223530)
-- Game: addappid(1223530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223531, 1, "32031e33c09e7f230b20c581d0c211dc258e91f9210f4d12b75963be4db51bef")
