-- Lua provided by SkyAPI 
-- Game: Mall Craze
addappid(1223530)
addappid(1223531, 1, "32031e33c09e7f230b20c581d0c211dc258e91f9210f4d12b75963be4db51bef")
