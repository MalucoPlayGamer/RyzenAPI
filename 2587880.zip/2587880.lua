-- Lua provided by RyzenAPI
-- Game: 2587880

-- MAIN APPLICATION
addappid(2587880)
-- Game: addappid(2587880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2587881, 1, "0c74783ba49f478a4a4225ee882f01c71a4e62e33429e565d7d5dab6c9411de0")
