-- Lua provided by RyzenAPI
-- Game: CarGo!

-- MAIN APPLICATION
addappid(1272780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1272781, 1, "c960f8b05d44e63e51c16b9568b2cd0001c960c584e0baefc49814678e8c4113")

