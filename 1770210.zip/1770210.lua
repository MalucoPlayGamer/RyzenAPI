-- Lua provided by RyzenAPI
-- Game: Price of Power

-- MAIN APPLICATION
addappid(1770210)
-- Game: addappid(1770210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770211, 1, "cf4b6e15f8b6d17fb6f1ca01ac4fcc0229bc7efbb7a677cf902e5a530b088aea")
