-- Lua provided by SkyAPI 
-- Game: Price of Power
addappid(1770210)
addappid(1770211, 1, "cf4b6e15f8b6d17fb6f1ca01ac4fcc0229bc7efbb7a677cf902e5a530b088aea")
