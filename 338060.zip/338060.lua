-- Lua provided by RyzenAPI
-- Game: Mahjong Pretty Girls Battle

-- MAIN APPLICATION
addappid(338060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(338061, 1, "1c75800ef8ea7b63ff6e44c9d515af599bb30dff03bea678e2b8f451b9ef7111")

