-- Lua provided by RyzenAPI
-- Game: Mahjong Pretty Girls Battle

-- MAIN APPLICATION
addappid(338060)

-- MAIN APP DEPOTS / PACKAGES
addappid(338061, 1, "1c75800ef8ea7b63ff6e44c9d515af599bb30dff03bea678e2b8f451b9ef7111")

