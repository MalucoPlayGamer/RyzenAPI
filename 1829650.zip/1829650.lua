-- Lua provided by RyzenAPI
-- Game: Sekai to Sekai no Mannaka de

-- MAIN APPLICATION
addappid(1829650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1829651, 1, "c93bc1619c2ef4531c17857242cf18a6f3b636c85f3637d1e09d0724fbd38d25")
