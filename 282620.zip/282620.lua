-- Lua provided by RyzenAPI
-- Game: 282620

-- MAIN APPLICATION
addappid(282620)
-- Game: addappid(282620)

-- MAIN APP DEPOTS / PACKAGES
addappid(282621, 1, "78525d9d0ba3ba5ba2b759217a6006f412f3f9aa285fdec30e77e71b2c6c3b46")
