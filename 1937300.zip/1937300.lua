-- Lua provided by RyzenAPI
-- Game: Lillusion

-- MAIN APPLICATION
addappid(1937300)
-- Game: addappid(1937300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1937301, 1, "81896c784412111781e9e8854f532cc78a0152e68602d50e56227396efca03e7")
