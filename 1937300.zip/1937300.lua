-- Lua provided by SkyAPI 
-- Game: Lillusion
addappid(1937300)
addappid(1937301, 1, "81896c784412111781e9e8854f532cc78a0152e68602d50e56227396efca03e7")
