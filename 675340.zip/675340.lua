-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(675340)

-- MAIN APP DEPOTS / PACKAGES
addappid(675340,0,"67bc7c240386211f1163548622e7eeb4dae2f2b670b11af92c0efde9b44103b0")

