-- Lua provided by RyzenAPI
-- Game: RogueLite

-- MAIN APPLICATION
addappid(975600)
-- Game: addappid(975600)

-- MAIN APP DEPOTS / PACKAGES
addappid(975601, 1, "2c605405e4b44ce445e98d619624e76d9213ab3da722f1d135bb718f2cdcf74b")
