-- Lua provided by RyzenAPI
-- Game: Corrupt Them All - Tokyo Meow

-- MAIN APPLICATION
addappid(3249970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3249971, 1, "e0a8ab5896e19b2ef4646aec6ce2134eaebc1b2a07bf9be7578dcdab7b16eca9")
