-- Lua provided by RyzenAPI
-- Game: Pocket Bravery Demo

-- MAIN APPLICATION
addappid(1630860)
-- Game: addappid(1630860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1630861, 1, "7ba5574fedc8fbf0f12856605229e68dfdcb9f9462f7ec024d2b3003a91820b1")
