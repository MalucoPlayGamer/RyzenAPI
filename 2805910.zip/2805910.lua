-- Lua provided by RyzenAPI
-- Game: The Circle Tales: Elvenwoods

-- MAIN APPLICATION
addappid(2805910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2805911, 1, "92489497e5594ceab52df5e82436bf6a84159e85e43d66e37ba0f3a3fc9488df")
addappid(2805912, 1, "95a1050c7f02f2973c94ec08e2baf46e6375ded335278c90723b78582d6f8044")

