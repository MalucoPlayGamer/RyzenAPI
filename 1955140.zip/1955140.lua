-- Lua provided by RyzenAPI
-- Game: Come Home - Jamie Clothing Expansion

-- MAIN APPLICATION
addappid(1955140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1955141, 1, "f9e062e5c5455131beb3caa91442ef0872ef9d0e9112e9cfe965448a38d515a8")

