-- Lua provided by RyzenAPI
-- Game: 3430470

-- MAIN APPLICATION
addappid(3430470)
-- Game: addappid(3430470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3430471, 1, "7f478c739cf9e5b4ccacc2527b6ad86e4bbfc13453783e9bf5db05fd5f371673")
