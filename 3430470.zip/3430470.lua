-- Lua provided by RyzenAPI 
-- Game: PLATiNA :: LAB
addappid(3430470)
addappid(3430471, 1, "7f478c739cf9e5b4ccacc2527b6ad86e4bbfc13453783e9bf5db05fd5f371673")
