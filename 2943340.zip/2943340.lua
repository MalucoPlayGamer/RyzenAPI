-- Lua provided by RyzenAPI
-- Game: addappid(2943340)

-- MAIN APPLICATION
addappid(2943340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2943340,0,"38619ea7ce070878d7fff82d2a1a681c7912a53ba4e1e6c8e2b4183ce0b7661f")
