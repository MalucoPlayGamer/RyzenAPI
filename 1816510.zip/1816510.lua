-- Lua provided by RyzenAPI
-- Game: VenusBlood HOLLOW International Demo

-- MAIN APPLICATION
addappid(1816510)
-- Game: addappid(1816510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816511, 1, "1160264952b3bb876771d9c961a1435612fb8e8cbc5e42d2f261ea135f052096")
