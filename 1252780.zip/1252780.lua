-- Lua provided by RyzenAPI
-- Game: Bloons Monkey City

-- MAIN APPLICATION
addappid(1252780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252781, 1, "b812ff56e32d6bbda79bfa316b0c12a5e5dbda5a358b94a7d1b2280197d138d1")
addappid(1252782, 1, "be15f06556723a448ef19753187631286ae635464a29c24b64ead9adc7a0d70f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1276500)
addappid(1276501)
addappid(1276502)
addappid(1276503)
addappid(1276520)
addappid(1276521)
addappid(1276522)
addappid(1276523)
addappid(1276524)
addappid(1276525)
