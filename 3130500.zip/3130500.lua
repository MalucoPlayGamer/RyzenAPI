-- Lua provided by RyzenAPI
-- Game: 3130500

-- MAIN APPLICATION
addappid(3130500)
-- Game: addappid(3130500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3130501, 1, "38543845d3a8ebb2f970affb49597963cf810de6dfeb15a2f2a5524b813e39a9")
