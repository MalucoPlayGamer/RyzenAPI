-- Lua provided by RyzenAPI
-- Game: Game: Olympia: Festival of the Gods

-- MAIN APPLICATION
addappid(3316450)
-- Game: addappid(3316450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3316451, 1, "5eb454c978cdd287dbaab52834071fc0d0b4d40e3fc7e61d391000293a4ebc3d")
addappid(3316452, 1, "9783f73f6e8787810ab2b4b9cca1c67eca9cfd2498f764651d45e2f2c7d5c277")
