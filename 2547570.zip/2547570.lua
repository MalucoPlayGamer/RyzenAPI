-- Lua provided by RyzenAPI
-- Game: Miss Peach

-- MAIN APPLICATION
addappid(2547570)
-- Game: addappid(2547570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2547571, 1, "a1dacbf271c97cce462420a257b6eb513ad97b39469c302f905c0206e7f3fb9c")
