-- Lua provided by RyzenAPI
-- Game: Territory Idle

-- MAIN APPLICATION
addappid(1017100)

