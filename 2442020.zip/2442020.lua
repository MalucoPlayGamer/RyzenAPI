-- Lua provided by RyzenAPI
-- Game: Dangeresque: The Roomisode Triungulate

-- MAIN APPLICATION
addappid(2442020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2442022,0,"18f2d928930a617a91d5e9652018c2fa3b58d0c49c16ea43e876874e31caa631")

