-- Lua provided by RyzenAPI
-- Game: Children of Zodiarcs

-- MAIN APPLICATION
addappid(436290)
addappid(677670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(436291, 1, "66181abc5d00904fee552d0fe2613cfe1203107d51ad0bf8afd698997e97dff0")
addappid(436292, 1, "493dc49b5d940c0a06a1ec26bdca1bd99d1f202294ce142cf737085ac2274032")
