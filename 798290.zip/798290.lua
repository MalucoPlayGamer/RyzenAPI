-- Lua provided by RyzenAPI
-- Game: 798290

-- MAIN APPLICATION
addappid(798290)
-- Game: addappid(798290)

-- MAIN APP DEPOTS / PACKAGES
addappid(798291, 1, "7cf99319a1bc78b2f5cd24e62d5546c77e1e826bcee5cb270670b94245466c03")
