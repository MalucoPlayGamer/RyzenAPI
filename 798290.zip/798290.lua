-- Lua provided by RyzenAPI
-- Game: MXGP PRO

-- MAIN APPLICATION
addappid(798290)

-- MAIN APP DEPOTS / PACKAGES
addappid(798291, 1, "7cf99319a1bc78b2f5cd24e62d5546c77e1e826bcee5cb270670b94245466c03")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
