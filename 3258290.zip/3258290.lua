-- Lua provided by RyzenAPI
-- Game: Equinox: Homecoming

-- MAIN APPLICATION
addappid(3258290)
-- Game: addappid(3258290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3258291, 1, "73554f5d53f617bf5a2573e47be58a3afa60bdb3bb74882085c201e5d76ef94b")
