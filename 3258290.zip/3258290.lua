-- Lua provided by RyzenAPI
-- Game: Equinox: Homecoming

-- MAIN APPLICATION
addappid(3258290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3258291, 1, "73554f5d53f617bf5a2573e47be58a3afa60bdb3bb74882085c201e5d76ef94b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4438230)
addappid(4438240)
