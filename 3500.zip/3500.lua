-- Lua provided by RyzenAPI
-- Game: Mystery P.I.™ - The Lottery Ticket

-- MAIN APPLICATION
addappid(3500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3501, 1, "92e1f7ab7599c77842e2d7a87211386f1425251f24693e1648af4b615ef2b9de")
