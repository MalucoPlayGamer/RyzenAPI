-- Lua provided by RyzenAPI
-- Game: The Wraith of the Galaxy: Free Trial

-- MAIN APPLICATION
addappid(2192720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2192721, 1, "5397aba9702f95945a27d09a314050b31415e5d5480d5c394392210c24d571cc")

