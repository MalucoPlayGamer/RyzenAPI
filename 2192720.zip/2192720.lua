-- Lua provided by RyzenAPI 
-- Game: The Wraith of the Galaxy: Free Trial
addappid(2192720)
addappid(2192721, 1, "5397aba9702f95945a27d09a314050b31415e5d5480d5c394392210c24d571cc")
