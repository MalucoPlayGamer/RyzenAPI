-- Lua provided by RyzenAPI
-- Game: AppID 773840

-- MAIN APPLICATION
addappid(773840)

-- MAIN APP DEPOTS / PACKAGES
addappid(773841, 1, "3a19d0e615030780f16a3c0152c3032632500b05043f65dffd478a61692079b8")
addappid(773842, 1, "2ad4fb25bcab11a27a624f7ae87a0708387756a07747ff509fb4a4a251791ade")
addappid(773843, 1, "aeec4e68a18dbfde87c51d143a6c786523a6e97389833d211652c3b3c7400500")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
