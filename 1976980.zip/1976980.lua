-- Lua provided by RyzenAPI
-- Game: addappid(1976980)

-- MAIN APPLICATION
addappid(1976980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976983,0,"ad49a46fe36a5cd49c30751939ecccf0097eb0727e7ccfe6f8f4436c2c84f64e")
