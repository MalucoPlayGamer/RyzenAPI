-- Lua provided by RyzenAPI
-- Game: Pid

-- MAIN APPLICATION
addappid(218740)
-- Game: addappid(218740)

-- MAIN APP DEPOTS / PACKAGES
addappid(218741, 1, "d8e121186f060f6f6e629bb2c5010e2366d37dbb214ed02ed526a49c3a1dfe3b")
addappid(218742, 1, "5c6e723b5fae1efdd37aca720e39a642e912e3763ba796f51b75f46187c90f64")
