-- Lua provided by RyzenAPI
-- Game: CUSTOM ORDER MAID 3D2 Unhealthily Obsessed Yamato Nadeshiko GP-01Fb

-- MAIN APPLICATION
addappid(3473300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3473301, 1, "aa63b1ccbdfa293fa83e026e0f2fe1631556c0a2c81daa192429a3f73cc052aa")

