-- Lua provided by RyzenAPI
-- Game: Game: AppID 346290

-- MAIN APPLICATION
addappid(346290)
-- Game: addappid(346290)

-- MAIN APP DEPOTS / PACKAGES
addappid(346291, 1, "2492f879223ec4b187f2d7ca868bf7c24109a51d107c8f4aa9ad62b61ada4405")
addappid(346292, 1, "9258984a825deb11dec8fdc01458ef1f88a95a8d51c9fdc0506bbae9b89ef7a7")
addappid(346293, 1, "9ed4d1a83bf3df24e1cb5ef4605b25cdc36799f4b3754741d1dde52c1219d90d")
addappid(346296, 1, "1981dd37e16646b26ffc6f36fc0b2ff44fba430b08864d9b38979997cefa0aca")
addappid(346297, 1, "26acdd3c4baff75cce7a1372d527aab2d0dd683b09885c9216624a1cad2bff1f")
