-- Lua provided by RyzenAPI
-- Game: Justice.exe

-- MAIN APPLICATION
addappid(1291210)
addappid(2008210)
-- Game: addappid(1291210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291211, 1, "d64b1103eda81b6c66eab85565a284c057cfbf7f2a59d0edd855d202606f6ea3")
