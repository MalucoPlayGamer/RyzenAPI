-- Lua provided by RyzenAPI
-- Game: Virus ON

-- MAIN APPLICATION
addappid(1691170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691171, 1, "3a20a1235d313e12163f4c203390bb7e2ead14bb324dffdbafd2c82bced454ac")

