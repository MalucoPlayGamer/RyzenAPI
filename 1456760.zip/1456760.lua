-- Lua provided by RyzenAPI
-- Game: Game: ROBOBEAT

-- MAIN APPLICATION
addappid(1456760)
-- Game: addappid(1456760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1456761, 1, "b8bc2cde1ecb6eaf6683921c1879482515b41e3483909370a39729920b7e45c2")
