-- Lua provided by RyzenAPI
-- Game: Scroll Of Taiwu - 新衣贺春

-- MAIN APPLICATION
addappid(2764960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2764960,0,"00140a77be9fb80581f68904948537eb5ba3ca04ffc9b2c024d128d98cbf9365")

