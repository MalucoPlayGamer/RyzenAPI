-- Lua provided by RyzenAPI
-- Game: Entropy : Zero

-- MAIN APPLICATION
addappid(714070)

-- MAIN APP DEPOTS / PACKAGES
addappid(714071, 1, "51c2673540cb8f76843a5cf558b78787f8c3acc32a472994660f136dfe851ca0")
addappid(769990, 0, "d23328d8aa7ad3163e7476889fc9dbfe6698ab0e5bf68124ac26955f3202e2eb")
