-- Lua provided by RyzenAPI
-- Game: 776530

-- MAIN APPLICATION
addappid(776530)
-- Game: addappid(776530)

-- MAIN APP DEPOTS / PACKAGES
addappid(776530,0,"95a02a65c2a411225aa20e646c17a50358fcb0cabc60348896aa0ed14254227e")
