-- Lua provided by RyzenAPI
-- Game: Avakin Life

-- MAIN APPLICATION
addappid(3165680)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

