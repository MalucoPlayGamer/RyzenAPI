-- Lua provided by RyzenAPI
-- Game: Avakin Life

-- MAIN APPLICATION
addappid(3165680)

