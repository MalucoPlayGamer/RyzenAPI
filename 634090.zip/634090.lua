-- Lua provided by RyzenAPI
-- Game: Suncore Chronicles: The Tower

-- MAIN APPLICATION
addappid(634090)

-- MAIN APP DEPOTS / PACKAGES
addappid(634091, 1, "fa0b198af25fefcbc7edd025a4f3b4ff7188f8d9a2f25f37f8caa400d733a962")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
