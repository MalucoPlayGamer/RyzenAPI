-- Lua provided by RyzenAPI
-- Game: addappid(634090)

-- MAIN APPLICATION
addappid(634090)

-- MAIN APP DEPOTS / PACKAGES
addappid(634091, 1, "fa0b198af25fefcbc7edd025a4f3b4ff7188f8d9a2f25f37f8caa400d733a962")
