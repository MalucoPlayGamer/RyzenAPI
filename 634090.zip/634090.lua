-- Lua provided by RyzenAPI 
-- Game: Suncore Chronicles: The Tower
addappid(634090)
addappid(634091, 1, "fa0b198af25fefcbc7edd025a4f3b4ff7188f8d9a2f25f37f8caa400d733a962")
