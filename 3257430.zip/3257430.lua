-- Lua provided by RyzenAPI
-- Game: AppID 3257430

-- MAIN APPLICATION
addappid(3257430)
-- Game: addappid(3257430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3257431, 1, "85c4b60e587e3f692793d7933a428eae7aa0729fe7ea4ba70a9454299c4a1577")
