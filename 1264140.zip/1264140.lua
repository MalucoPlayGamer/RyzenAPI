-- Lua provided by RyzenAPI
-- Game: Kyo's Routine

-- MAIN APPLICATION
addappid(1264140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1264141, 1, "5d01eb5e09a7837633e5f7abb51e26d541a9c67e39925629e5038b76d3705362")
