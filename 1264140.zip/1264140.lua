-- Lua provided by RyzenAPI 
-- Game: AppID 1264140
addappid(1264140)
addappid(1264141, 1, "5d01eb5e09a7837633e5f7abb51e26d541a9c67e39925629e5038b76d3705362")
