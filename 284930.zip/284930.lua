-- Lua provided by RyzenAPI
-- Game: 284930

-- MAIN APPLICATION
addappid(284930)
-- Game: addappid(284930)

-- MAIN APP DEPOTS / PACKAGES
addappid(284931, 1, "7d60911244f5e5d2656de34188d1cf1ddf884410c4911cbafb44010da72c4970")
