-- Lua provided by RyzenAPI
-- Game: Speed Kills

-- MAIN APPLICATION
addappid(284930)
addappid(297780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(284931, 1, "7d60911244f5e5d2656de34188d1cf1ddf884410c4911cbafb44010da72c4970")

