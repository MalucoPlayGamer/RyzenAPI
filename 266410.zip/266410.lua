-- Lua provided by RyzenAPI
-- Game: iRacing

-- MAIN APPLICATION
addappid(266410)

-- MAIN APP DEPOTS / PACKAGES
addappid(266411, 1, "c6926148df6b91b2ca1e691ad992d112a63e9ef46f067d86ad73e0e6220a310d")
addappid(266415, 1, "178e63e412c7306dfaef0daf0941e930181b56ae738df0feef6e403dee85aaec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
