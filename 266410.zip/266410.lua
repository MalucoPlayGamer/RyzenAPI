-- Lua provided by SkyAPI 
-- Game: iRacing
addappid(266410)
addappid(266411, 1, "c6926148df6b91b2ca1e691ad992d112a63e9ef46f067d86ad73e0e6220a310d")
addappid(266415, 1, "178e63e412c7306dfaef0daf0941e930181b56ae738df0feef6e403dee85aaec")
