-- Lua provided by RyzenAPI
-- Game: Corporated Robots Wars

-- MAIN APPLICATION
addappid(1233600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1233601, 1, "a964b527a56420cc50f2515dc88a59392b38dc9c84ca9017747386bd529d8a1a")

