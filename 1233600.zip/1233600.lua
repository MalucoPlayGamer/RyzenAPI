-- Lua provided by SkyAPI 
-- Game: AppID 1233600
addappid(1233600)
addappid(1233601, 1, "a964b527a56420cc50f2515dc88a59392b38dc9c84ca9017747386bd529d8a1a")
