-- Lua provided by RyzenAPI
-- Game: addappid(1117670)

-- MAIN APPLICATION
addappid(1117670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117671, 1, "01dc48101be528621644755dfac2945acaf13334cbd8dd8919e2e37128b8d795")
