-- Lua provided by RyzenAPI
-- Game: CloverPit

-- MAIN APPLICATION
addappid(3314790)
addappid(4341120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3314791, 1, "01f256d876a29ffa69ec7fefed5588393e85c3e5326497d7da92427e011759ff")
