-- Lua provided by RyzenAPI
-- Game: 448800

-- MAIN APPLICATION
addappid(448800)
addappid(590350)
-- Game: addappid(448800)

-- MAIN APP DEPOTS / PACKAGES
addappid(448801, 1, "79adf8303be52c8166063a802ba5554d5c0f59653e292b78a14cea0c01909c57")
