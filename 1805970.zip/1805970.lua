-- Lua provided by RyzenAPI 
-- Game: Comixxx Strip
addappid(1805970)
addappid(1805971, 1, "9d0d777bf2a3c7ff9376423eeccaefd8e9db6531e6a08e6966797532ca5f8861")
