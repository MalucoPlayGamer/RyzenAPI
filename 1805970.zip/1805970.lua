-- Lua provided by RyzenAPI
-- Game: Game: Comixxx Strip

-- MAIN APPLICATION
addappid(1805970)
-- Game: addappid(1805970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1805971, 1, "9d0d777bf2a3c7ff9376423eeccaefd8e9db6531e6a08e6966797532ca5f8861")
