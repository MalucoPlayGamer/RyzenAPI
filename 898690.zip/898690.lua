-- Lua provided by RyzenAPI 
-- Game: AppID 898690
addappid(898690)
addappid(898691, 1, "eeab920848ad3c21fd9c80300f59439e0c8367cea33420522e18b0374ca687bb")
