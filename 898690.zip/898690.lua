-- Lua provided by RyzenAPI
-- Game: AppID 898690

-- MAIN APPLICATION
addappid(898690)

-- MAIN APP DEPOTS / PACKAGES
addappid(898691, 1, "eeab920848ad3c21fd9c80300f59439e0c8367cea33420522e18b0374ca687bb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
