-- Lua provided by SkyAPI 
-- Game: Deepest Sword
addappid(1647160)
addappid(1647161, 1, "897b6956fc5bba6d619eedcbd86fdf619d58725ec3cb88e72e984e052d20d954")
addappid(1647162, 1, "78dc21c6f3aad0a73c41ca4b646b748d335a5c8f54e72996d1a9c7e239e8f0a1")
addappid(1647163, 1, "e061b03ae22496dbf451c1bdb5c30c56f1bb91453bc0a5c13db322839fab9f0a")
