-- Lua provided by RyzenAPI
-- Game: addappid(2526160)

-- MAIN APPLICATION
addappid(2526160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2526161, 1, "451ebfef8061d4063eaf5e09ae7ccc9b06852a0044a0bd4c7c2a8c29121f0278")
