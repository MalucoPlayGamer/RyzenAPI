-- Lua provided by RyzenAPI 
-- Game: Slaughter Me Street: 1999
addappid(2922990)
addappid(2922991, 1, "0e486c3047e1d45ac1166364e77c3c3f7a8ee73fd30d143de0c863ae9db896bd")
