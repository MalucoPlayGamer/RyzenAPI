-- Lua provided by RyzenAPI
-- Game: Slaughter Me Street: 1999

-- MAIN APPLICATION
addappid(2922990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2922991, 1, "0e486c3047e1d45ac1166364e77c3c3f7a8ee73fd30d143de0c863ae9db896bd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
