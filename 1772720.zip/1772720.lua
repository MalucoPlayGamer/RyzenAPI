-- Lua provided by RyzenAPI
-- Game: Village of Zombies

-- MAIN APPLICATION
addappid(1772720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1772721, 1, "c10cdf1f35343819299248aa42306aeaf78f8f5b893e8a52e21e21acc03a1334")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1868090)
addappid(1878870)
addappid(1981240)
