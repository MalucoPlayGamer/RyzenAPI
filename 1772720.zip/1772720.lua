-- Lua provided by RyzenAPI 
-- Game: Village of Zombies
addappid(1772720)
addappid(1772721, 1, "c10cdf1f35343819299248aa42306aeaf78f8f5b893e8a52e21e21acc03a1334")
