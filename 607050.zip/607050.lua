-- Lua provided by RyzenAPI
-- Game: Wargroove

-- MAIN APPLICATION
addappid(607050)
addappid(1061140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(607051, 1, "f571baf67e599fe0e04cb1389a9b9f0c11a09dfdab851e7c20c3235be8102634")
addappid(607052, 1, "71023601efd028af565aa2ad939393b03dd07de9e5733bd49e5b505b2f15d573")
addappid(607053, 1, "c10100fabc812eed05d9fd6f7521b74def684801b032c377fbec09e9f0947c4a")
addappid(607054, 1, "676f3a9453dc4b2654926999b3da65944b7655a8d708c060ddf410fc69e54288")
