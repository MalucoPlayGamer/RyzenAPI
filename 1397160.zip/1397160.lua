-- Lua provided by RyzenAPI
-- Game: Game: Pulut Adventure RPG

-- MAIN APPLICATION
addappid(1397160)
-- Game: addappid(1397160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397161, 1, "fc924c8bedb9ecfaa90f076db0cff720207e854d133c90571d7d77a5109851ee")
addappid(1397162, 1, "55d1270e982841ecb0311480a1265d65f4565733d52ea12c032a434d60307c18")
