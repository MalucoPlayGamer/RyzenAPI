-- Lua provided by RyzenAPI
-- Game: addappid(571060)

-- MAIN APPLICATION
addappid(571060)

-- MAIN APP DEPOTS / PACKAGES
addappid(571061, 1, "92afd04cafa22d60f164751b572860e92ee9d38ef5f331739d1490469d2e87d3")
