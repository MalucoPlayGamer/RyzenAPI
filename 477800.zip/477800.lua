-- Lua provided by RyzenAPI 
-- Game: Piñata
addappid(477800)
addappid(477801, 1, "629a10b04b1958bc901677e2a40f0952044d95b47d3e51bc199d238e4572d96c")
