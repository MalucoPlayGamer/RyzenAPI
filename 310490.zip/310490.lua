-- Lua provided by RyzenAPI
-- Game: AppID 310490

-- MAIN APPLICATION
addappid(310490)

-- MAIN APP DEPOTS / PACKAGES
addappid(310491, 1, "b7fb8657688256f340fa7faa4e0204f7bec054f5ea43d6f25797b5cd62b92e09")
addappid(310492, 1, "fd55a53454c6d0efaf62b15c8b26c562c0830d256037710c6544981c90e24531")
addappid(310493, 1, "19753cb643ba172de8f2b632064c35a12654d31514c8aa37a31c3543c2fe956b")
addappid(310494, 1, "8136c1815c54dfa5043e74b060e8ed06adc125447cb5988ce85ead63a696c639")
addappid(310498, 1, "b68014f22268397609757ed8575498d3a209719dc0244669a375ca0d0f075a4e")
addappid(310499, 1, "797cdaf53c1f676439c707e6ffc13d3f9a64a25995c12c365c2830be6024ef2d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(356300)
addappid(356301)
addappid(388760)
