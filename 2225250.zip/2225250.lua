-- Lua provided by RyzenAPI
-- Game: Game: Slobbish Dragon Princess 3

-- MAIN APPLICATION
addappid(2225250)
-- Game: addappid(2225250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225251, 1, "a3fc2d7464275790f77dceee3125e52dea4c942e3d93e75058604fbc75e62bbd")
