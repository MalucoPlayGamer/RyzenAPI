-- Lua provided by RyzenAPI
-- Game: 882070

-- MAIN APPLICATION
addappid(882070)
-- Game: addappid(882070)

-- MAIN APP DEPOTS / PACKAGES
addappid(882071, 1, "969f77d7291fef82fecb4b694b9acf4ed7b8d231df4c4dc976e684cfb10d398e")
