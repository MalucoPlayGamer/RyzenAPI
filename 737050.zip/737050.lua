-- Lua provided by SkyAPI 
-- Game: Open Sorcery: Sea++
addappid(737050)
addappid(737051, 1, "3cf54db5b1bf00cb6778179cbd29a1ff3c0348c81230cc65ad74a7f4ba3ebd56")
addappid(737052, 1, "1094bd8f6b1baa8e99d25e0d0df0bba892b9d007e5bc823aaed0835a1beb96f2")
