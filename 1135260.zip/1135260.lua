-- 1135260's Lua and Manifest Created by Hubcap Manifest
-- The Falconeer: Revolution Remaster
-- Created: April 10, 2026 at 12:02:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 5

-- MAIN APPLICATION
addappid(1135260, 1, "4f4ba2caba0cdfdce2f71ecce7a9b0626a828e827c7c6f6e3e86b142220d899b") -- The Falconeer: Revolution Remaster
-- MAIN APP DEPOTS
addappid(1135261, 1, "c19bb6d1c7ec099597fcc92bc6d90c41f61d7130b01b7ca4593d149e00369da2") -- The Falconeer Content
setManifestid(1135261, "3570043827341605255", 4904602080)
-- DLCS WITH DEDICATED DEPOTS
-- The Falconeer Revolution Remaster - Game Guide (AppID: 1434030)
addappid(1434030)
addappid(1434032, 1, "8c54348f1a55488c827920fc9d4031bb7d6145c9f3903d5491a458cf7d15fe03") -- The Falconeer Revolution Remaster - Game Guide - The Falconeer - Game Guide Depot
setManifestid(1434032, "5917369293562231351", 4753147)
-- The Falconeer Revolution Remaster - Game Manual (AppID: 1474610)
addappid(1474610)
addappid(1474611, 1, "6063864b129b73ad7ef9a55cbe3d703eb1d99a1f6bff8422b0e7a0f49dcbe0ad") -- The Falconeer Revolution Remaster - Game Manual - The Falconeer - Game Manual Depot
setManifestid(1474611, "6662401110288470754", 60974831)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1516140) -- The Falconeer Revolution Remaster - The Hunter
addtoken(1516140, "5019074355029040212")
addappid(1604190) -- The Falconeer - Edge of the World
addappid(4116180) -- Falconeer Chronicles - Supporter DLC
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1434030) -- Depot 1434030 (empty depot)