-- Lua provided by RyzenAPI
-- Game: The Falconeer: Revolution Remaster

-- MAIN APPLICATION
addappid(1135260)
-- Game: addappid(1135260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1135261, 1, "c19bb6d1c7ec099597fcc92bc6d90c41f61d7130b01b7ca4593d149e00369da2")
addappid(1135262, 1, "aa288806c4c65645412b3631bf00753f0c414195d8a606d1f00f166a4f704774")
