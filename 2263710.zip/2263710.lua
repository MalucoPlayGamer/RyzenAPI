-- Lua provided by RyzenAPI
-- Game: addappid(2263710)

-- MAIN APPLICATION
addappid(2263710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263711, 1, "01ec4202bd3c75dbb817123cf41923019f581fa5d41e908f15e933bad9f3dca6")
