-- Lua provided by RyzenAPI
-- Game: T-Rex Dinosaur Game

-- MAIN APPLICATION
addappid(2263710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2263711, 1, "01ec4202bd3c75dbb817123cf41923019f581fa5d41e908f15e933bad9f3dca6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
