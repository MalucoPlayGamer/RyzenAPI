-- Lua provided by RyzenAPI
-- Game: addappid(642810)

-- MAIN APPLICATION
addappid(642810)

-- MAIN APP DEPOTS / PACKAGES
addappid(642811, 1, "7292fd6858780403f4fc229f1bacf7d626f62ae00165648e8f854a4c40becf0d")
