-- 1795690's Lua and Manifest Created by Hubcap Manifest
-- Immerse Gamepack FINAL FANTASY™ XIV Online Edition
-- Created: August 15, 2026 at 22:59:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1795690, 1, "e51092fb1762b448f5042b9ab2169eca30adf5fa821c3f0df7d0166eae472615") -- Immerse Gamepack FINAL FANTASY™ XIV Online Edition
-- MAIN APP DEPOTS
addappid(1795691, 1, "6ef0734f7ea4ee7785320423da83761378490177950d4937a094d004d14778d7") -- Depot 1795691
setManifestid(1795691, "1695898136123120325", 39923645)
addappid(1795692, 1, "312f878c52dece47875f49df138570de6aafaa209b77e559d4f8a9afebf68c0c") -- Depot 1795692
setManifestid(1795692, "1553108984893654694", 5893830)