-- Lua provided by RyzenAPI
-- Game: Immerse Gamepack FINAL FANTASY™ XIV Online Edition

-- MAIN APP DEPOTS / PACKAGES
addappid(1795690, 1, "e51092fb1762b448f5042b9ab2169eca30adf5fa821c3f0df7d0166eae472615") -- Immerse Gamepack FINAL FANTASY™ XIV Online Edition
addappid(1795691, 1, "6ef0734f7ea4ee7785320423da83761378490177950d4937a094d004d14778d7") -- Depot 1795691
addappid(1795692, 1, "312f878c52dece47875f49df138570de6aafaa209b77e559d4f8a9afebf68c0c") -- Depot 1795692

