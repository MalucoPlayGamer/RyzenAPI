-- Lua provided by RyzenAPI
-- Game: Deadly Days

-- MAIN APPLICATION
addappid(740080)

-- MAIN APP DEPOTS / PACKAGES
addappid(740081, 1, "acaac505c20234d41e15a7087a885dbff2d7a1515a6b794b4cb6aba4959a3a31")
addappid(740082, 1, "26e7f814263ae4e21e6fc290c5f16bd1320d66e4b33a9de69d1d2f188effa4e5")
addappid(740083, 1, "07cd91cc78db8cf53b6554f42938396f449c49d030a6364f757402b8315d6a01")
addappid(740084, 1, "ddef783c7bcadb9bf2f9cb613d185dca5f0ec32f9900c48bfb2f1a2d9dabdaac")

