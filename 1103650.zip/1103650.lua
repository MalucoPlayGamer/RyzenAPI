-- Lua provided by RyzenAPI
-- Game: Game: AppID 1103650

-- MAIN APPLICATION
addappid(1103650)
-- Game: addappid(1103650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103651, 1, "ab11fcddf8d0bd46b2dd82660d4069d83a5304a1b07f4d4dd115dc8976163cd8")
