-- Lua provided by RyzenAPI
-- Game: 2224640

-- MAIN APPLICATION
addappid(2224640)
-- Game: addappid(2224640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2224641, 1, "46d866d7d06da5000604b7ddcd02940d6355f2e56c23a2456ba08f6d5b7b93c7")
