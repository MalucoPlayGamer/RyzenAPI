-- Lua provided by RyzenAPI
-- Game: Project Wingman Soundtrack

-- MAIN APPLICATION
addappid(1476780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1476781, 1, "fe1041432da6a78d353dd5d68954e7357ad736baa768d8050066c297c1dbec9f")
addappid(1476782, 1, "d68f490bf3e33ba5e91713432a6b8d43a4bb29097f6a4676734acc5febfb222f")

