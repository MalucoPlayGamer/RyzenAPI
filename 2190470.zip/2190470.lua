-- Lua provided by RyzenAPI
-- Game: Russian Train Trip 2

-- MAIN APPLICATION
addappid(2190470)
-- Game: addappid(2190470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2190471, 1, "51d2403d8c33b90da5edebbafe0ab7894d065810bc7f3348126d59de2bb93733")
