-- Lua provided by RyzenAPI
-- Game: Russian Train Trip 2

-- MAIN APPLICATION
addappid(2190470)
addappid(2272350)
addappid(2402040)
addappid(2402150)
addappid(2402151)
addappid(2402152)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2190471, 1, "51d2403d8c33b90da5edebbafe0ab7894d065810bc7f3348126d59de2bb93733")
