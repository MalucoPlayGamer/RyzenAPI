-- Lua provided by RyzenAPI
-- Game: Game: The Coma 2: Vicious Sisters DLC - Mina - Locks of Love Skin

-- MAIN APPLICATION
addappid(1183520)
-- Game: addappid(1183520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1183521, 1, "b35e7cba80fa7a89c1be62ebf064858a0f68c1e616ef41d761e39d0bacfa9b8c")
addappid(1183522, 1, "d34216524b1d8b8b0a6d3d40a7b79a14d3d430728b017a6ede481499d88868a8")
addappid(1183523, 1, "04f618060eeebf3e3d05bd7c5135a7453bb756f437038cc253e55d02744e1b89")
