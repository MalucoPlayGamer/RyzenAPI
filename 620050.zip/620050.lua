-- Lua provided by RyzenAPI
-- Game: addappid(620050)

-- MAIN APPLICATION
addappid(620050)

-- MAIN APP DEPOTS / PACKAGES
addappid(620051, 1, "e236c98fb12f7bbc45aa8ea1de9722e6b76e0c31fa5281182079c8737d42c3f2")
