-- Lua provided by RyzenAPI
-- Game: Game: Aggregator Elevator System

-- MAIN APPLICATION
addappid(2226610)
-- Game: addappid(2226610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2226611, 1, "527879642b2fea6f9813a78d6273097ce6d52caf142d015c64dc9e40dc0f9d90")
addappid(2226612, 1, "0106419bcc6d10748835f5c0c81245dac371631ec9687cc51395c61bf6322427")
