-- Lua provided by RyzenAPI
-- Game: Escape Rosecliff Island

-- MAIN APPLICATION
addappid(3600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3601, 1, "43ef6f91d4901a73cd4a34c1cd367f8a528adecc1f5dc3a9edb0221b0cd99dfb")
addappid(3603, 1, "cca8929dcb8313330603c5556d9cf1a6edf0899479ef7f34dc947943af499671")
addappid(3604, 1, "4f80b9bd4b9eee92b4a9ac4e7ffdf138ed2bcd61894a66c62e4a764cdbe1d9a3")
addappid(3605, 1, "8c05223c97d900b6456849118f25abf12b9d885035b459cd027aefe5baee5acf")
addappid(3606, 1, "b34bbf37c476a026795579d127492d8d03682fc5d2cc073d95d12250d65e9b19")
addappid(3607, 1, "4f8eadd50f013950daa0ec16624309bdcf952c2fb951725407f839dc9b251e7f")
