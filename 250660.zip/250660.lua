-- Lua provided by RyzenAPI
-- Game: Bunny Must Die! Chelsea and the 7 Devils

-- MAIN APPLICATION
addappid(250660)

-- MAIN APP DEPOTS / PACKAGES
addappid(250661, 1, "bf36034adee74f9abe97457268331a703387f1692c4700f4de547d3c1a2190df")
addappid(250662, 1, "d2101a078036515fb99cb369c7218b4cdf2db8173022076440fec50026562f1a")
addappid(250663, 1, "b536dc8e0d43d473226ed623660e887e7b40c02e2421c4bc9e7d31949f6233fd")
addappid(250664, 1, "dada576a28b878476ea062ee6559baa20d16b6b45576d3bb536bd0848525f908")
addappid(250665, 1, "df92baf0d19f801c55cae852a8902b502599fb8e46a72cd6e3b36d4bd525a7bd")
addappid(250666, 1, "af30f15a470422fdd7ddffa60eb526dd0cbdd3c91c2b0c34cd4a86c51c96c6b9")
addappid(250667, 1, "16f354ea55619181d2de55c0ddb584e08da6e7efe27ee651ec2852fc1949ad34")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
