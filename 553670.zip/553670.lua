-- Lua provided by RyzenAPI
-- Game: Beholder - Original Soundtrack

-- MAIN APPLICATION
addappid(553670)

-- MAIN APP DEPOTS / PACKAGES
addappid(553670,0,"d89eed7438914a1ec9859e58768375bbeba774765b162473181563aacce4936c")
