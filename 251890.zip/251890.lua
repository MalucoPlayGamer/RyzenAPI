-- Lua provided by RyzenAPI
-- Game: World of Diving

-- MAIN APPLICATION
addappid(251890)

-- MAIN APP DEPOTS / PACKAGES
addappid(251891, 1, "9a593a0888afcd286e1f900b587f71ecac6972bc49c7c676a450997bab1a1ee0")
addappid(251892, 1, "a221711fa00ef44242aecf9acdf0f121a8ae8c3e7a3b2ffac43076f077530703")
addappid(251893, 1, "41405c96c8441f38eb46c5b0047d74718efa662b7d2d1f07d3e7651acc670085")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
