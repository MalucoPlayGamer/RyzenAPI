-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1227467)
-- Game: addappid(1227467)

-- MAIN APP DEPOTS / PACKAGES
addappid(1227467,0,"7d020232f39e34a7f28608954ab293c259ec19daa51f5f3eb7aa12658b91f444")
