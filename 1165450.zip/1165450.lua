-- Lua provided by RyzenAPI
-- Game: OCO

-- MAIN APPLICATION
addappid(1165450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1165456,0,"1642cb8df1b245b3ea2b7b8170f0f3fad6b125cfff63ae1e44f4a882bc0244e2")

