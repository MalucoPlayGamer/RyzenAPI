-- Lua provided by RyzenAPI
-- Game: Game: SleepWalk

-- MAIN APPLICATION
addappid(2677930)
-- Game: addappid(2677930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2677931, 1, "8021a2086731a833114a22c5907f7789de4d34f924e30801aa1fb20e09c09a52")
