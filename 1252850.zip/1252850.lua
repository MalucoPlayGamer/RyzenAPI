-- Lua provided by RyzenAPI
-- Game: addappid(1252850)

-- MAIN APPLICATION
addappid(1252850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1252852,0,"fd07f2a98ffcd6f68661c8aeaa6f312cf873db6c9f298a95fade611c04b208c1")
