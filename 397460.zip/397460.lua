-- Lua provided by RyzenAPI
-- Game: AppID 397460

-- MAIN APPLICATION
addappid(397460)

-- MAIN APP DEPOTS / PACKAGES
addappid(397461, 1, "6f2d761b0fc5971b7aee53fd70770a40bf0cbf3ee7912501ced0f3cf774a3218")
addappid(397462, 1, "4337e8d5163008fd8a5b4876687733d57abff5982c02a9764670239c90ee9e32")
addappid(397463, 1, "3236c091a7243e691849d9fa1a22be752ec862524a0c1b8de6095f95267b29d8")
addappid(397464, 1, "bfa41c0c5f726b7d4800f503e1efac4e6fe0ab8ff9315c027cb6415b457523d1")
addappid(397465, 1, "c76d6d7aa043e069aa676ae65bd77d9b5ed29183b30026d146affb9510c3a297")
addappid(2828508, 0, "86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
