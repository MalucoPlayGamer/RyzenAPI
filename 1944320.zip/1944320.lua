-- Lua provided by RyzenAPI
-- Game: addappid(1944320)

-- MAIN APPLICATION
addappid(1944320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1944322,0,"2dcec9091659b28aed36c64b91844760b92f89c000c9d0b3f9eb5e7ad8f0e4a7")
addappid(1944323,0,"0df089618f55abfba31bbeead29ac9ce7292888a48fe02d1fe74de6aacae5e10")
