-- 4261030's Lua and Manifest Created by Hubcap Manifest
-- Orb Breaker
-- Created: August 27, 2026 at 13:04:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4261030, 1, "cac48c2bc8d3b446710c95a1f59cae72dee356c8045c599ff079a4e9bb3ba5ff") -- Orb Breaker
-- MAIN APP DEPOTS
addappid(4261033, 1, "ca001b1cd712f7a1862d3678b939a3d29e2883ef2764dd5898b5758ce474ba3a") -- Depot 4261033
setManifestid(4261033, "743643972047902066", 171585140)
addappid(4261034, 1, "83068ee07f724f0ed3286a417733e0c3797056f3ec2fbc9438c2cc8b72898ba1") -- Depot 4261034
setManifestid(4261034, "5107440317783220143", 150138739)
addappid(4261035, 1, "b6610f7e999064d4325a28373319cf8a6d9a4df024e213fad866bcd20e847724") -- Depot 4261035
setManifestid(4261035, "7171305406984583986", 251046506)