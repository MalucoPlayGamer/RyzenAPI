-- Lua provided by RyzenAPI
-- Game: addappid(2644410)

-- MAIN APPLICATION
addappid(2644410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2644411, 1, "d1e25b7c3c6ca09f0dbcb58e1714fdad7e1ec263744e461c71b6d708a7bb0e1b")
