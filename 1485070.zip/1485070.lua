-- Lua provided by RyzenAPI
-- Game: Esse Proxy

-- MAIN APPLICATION
addappid(1485070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1485071, 1, "4237f2588fc533b3c0dd4af61b6ecf73f2ef589ebf362a5ef64e554683c8061e")
