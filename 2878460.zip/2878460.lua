-- Lua provided by RyzenAPI
-- Game: 2878460

-- MAIN APPLICATION
addappid(2878460)
-- Game: addappid(2878460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2878461, 1, "4096f4e671f8824d338ff3b29b2ec439ae56cb5e31f4e94295279fc441deb6a2")
