-- Lua provided by RyzenAPI
-- Game: addappid(1758410)

-- MAIN APPLICATION
addappid(1758410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758411, 1, "3f20cb9ed968b049ecbf6e02ccc9a74050eadbf497d03e5387917b52fda1d8f8")
