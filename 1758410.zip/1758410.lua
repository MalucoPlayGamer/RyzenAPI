-- Lua provided by RyzenAPI
-- Game: Marriage to the demon wife!

-- MAIN APPLICATION
addappid(1758410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1758411, 1, "3f20cb9ed968b049ecbf6e02ccc9a74050eadbf497d03e5387917b52fda1d8f8")

