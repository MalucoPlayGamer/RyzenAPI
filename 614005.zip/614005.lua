-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: FunnerFlight - Airport Los Angeles International V2

-- MAIN APPLICATION
addappid(614005)

-- MAIN APP DEPOTS / PACKAGES
addappid(615880,0,"9f995a21a5cf901d95ca210391170c5f1017d955560009498ad2f00e50ba6b60")

