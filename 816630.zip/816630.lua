-- Lua provided by RyzenAPI
-- Game: Monkey King: Master of the Clouds

-- MAIN APPLICATION
addappid(816630)

-- MAIN APP DEPOTS / PACKAGES
addappid(816631, 1, "0e9b7b9a970fdd996d7e7706f1b50b8da9ada4275a823338eb59c03c13e1bb48")
