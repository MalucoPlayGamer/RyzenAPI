-- Lua provided by RyzenAPI
-- Game: 3493710

-- MAIN APPLICATION
addappid(3493710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3493710,0,"8e4eadb6d9dce13bfd6b5bf6ec9c5c36502465caaa8e6e61e33df43a372f7f0d")
