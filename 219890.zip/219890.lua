-- Lua provided by RyzenAPI
-- Game: Game: Antichamber

-- MAIN APPLICATION
addappid(219890)
-- Game: addappid(219890)

-- MAIN APP DEPOTS / PACKAGES
addappid(219891, 1, "c78b9505bee137068ced28e19dfa00e0109ca0968ff479852a0e7f78b1c785f5")
addappid(219892, 1, "00c6c30a3e807d92aebaa15028acc2760bcc4ab0da3d57dcf99d5f6740fabca1")
addappid(219893, 1, "d49b4ff0eec328623a73d6bdd8ab0dfe4d8f28cd2eccd4edd7542a4d3ee14420")
