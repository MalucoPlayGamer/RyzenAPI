-- Lua provided by RyzenAPI
-- Game: A Field of Flowers and Stars

-- MAIN APPLICATION
addappid(1363160)
-- Game: addappid(1363160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1363161, 1, "f4d9afa5e2219e4af931174a81063902be122138840a1df49cd57b63bb4a1e38")
