-- Lua provided by RyzenAPI
-- Game: addappid(1191070)

-- MAIN APPLICATION
addappid(1191070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191071, 1, "e6d260ba37853888bae27b1bb5e11efc51d65725ae767a24f944abed378e3228")
