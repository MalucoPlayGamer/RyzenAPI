-- Lua provided by RyzenAPI
-- Game: Kaiju Wars

-- MAIN APPLICATION
addappid(1508400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1508401, 1, "5592812a3a62a916ed2c7bebb9b16dd69ab56940d43433f0703528d3b98e299d")

