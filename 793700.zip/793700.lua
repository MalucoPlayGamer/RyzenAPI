-- Lua provided by RyzenAPI
-- Game: AppID 793700

-- MAIN APPLICATION
addappid(793700)
-- Game: addappid(793700)

-- MAIN APP DEPOTS / PACKAGES
addappid(793701, 1, "81201afbb0b68522b7b80345e756f2252a875e4d7a2e3ae4d0c2580275e3937c")
