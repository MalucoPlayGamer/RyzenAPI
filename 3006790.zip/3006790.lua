-- Lua provided by RyzenAPI
-- Game: Project Castaway Demo

-- MAIN APPLICATION
addappid(3006790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3006791, 1, "005e6e9f74b895f778fdb58d6da51c69179e9554e450ec1c19cd928aa64501a4")

