-- Lua provided by RyzenAPI
-- Game: Joana's Life

-- MAIN APPLICATION
addappid(513740)

-- MAIN APP DEPOTS / PACKAGES
addappid(513741, 1, "9f4d11134177df7c6ff7e0a3ffb21e727de025b4cd9dba84fa12076085b1bde6")

