-- Lua provided by RyzenAPI
-- Game: 1022429

-- MAIN APPLICATION
addappid(1022429)
-- Game: addappid(1022429)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022429,0,"c641d0b38ab9a3f523f8366f35c1d5da115ecbb4d6f3f3171c03382e867ffba0")
