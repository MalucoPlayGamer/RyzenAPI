-- Lua provided by RyzenAPI
-- Game: BRUTAL JOHN 2

-- MAIN APPLICATION
addappid(1859620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859622,0,"05816be06b2152e39fdcd0e6c1f3da03009a197e4401f9b7468ae6353a5b9129")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
