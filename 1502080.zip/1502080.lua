-- Lua provided by RyzenAPI
-- Game: 1502080

-- MAIN APPLICATION
addappid(1502080)
-- Game: addappid(1502080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1502081, 1, "9ed778566e8c376e17f97f10fba6b964fd50a855e45b0a77a7565ad6c94d785a")
addappid(1695300, 0, "7cd3d420ddf17e504c6384c125223c1df3d285d2c9a6a9bda1ce86f73b67f46b")
