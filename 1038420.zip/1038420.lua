-- Lua provided by SkyAPI 
-- Game: SCP: Blackout Demo
addappid(1038420)
addappid(1038421, 1, "34f460e3d41f4d898985cfea51fcf0ea159d7e0a1d3cf30078c6a7b922e98272")
