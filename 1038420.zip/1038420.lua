-- Lua provided by RyzenAPI
-- Game: SCP: Blackout Demo

-- MAIN APPLICATION
addappid(1038420)
-- Game: addappid(1038420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1038421, 1, "34f460e3d41f4d898985cfea51fcf0ea159d7e0a1d3cf30078c6a7b922e98272")
