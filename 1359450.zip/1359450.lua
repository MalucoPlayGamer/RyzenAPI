-- Lua provided by RyzenAPI
-- Game: 1359450

-- MAIN APPLICATION
addappid(1359450)
-- Game: addappid(1359450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1359451, 1, "380e5f8c406937b2fde4895ea6d065149733a55883bfd8127c270aeaaad8fe41")
