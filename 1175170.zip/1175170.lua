-- Lua provided by RyzenAPI
-- Game: Incredible Dracula: The Ice Kingdom

-- MAIN APPLICATION
addappid(1175170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175171, 1, "6355c0b7b197204d29584b404ca5c038a7ba323b84806321d27cf4578aa33d95")
addappid(1175172, 1, "8c76366e7e8cf26a16cfa7b56d307ab7a6aed41ac9fec4ae20a40f37b26cd27c")
addappid(1175173, 1, "c33f7cfcbc1eb1a9a08884ff57d8768aa3c51e4f4ff406ce10f6433304c4476f")
addappid(1175174, 1, "25fbc76e2ee4bd7a0215863725d440a35c316a6ebb8a4596d7ace4771955c46d")
