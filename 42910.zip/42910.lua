-- Lua provided by RyzenAPI
-- Game: Magicka

-- MAIN APPLICATION
addappid(42910)

-- MAIN APP DEPOTS / PACKAGES
addappid(42911, 1, "f3bb3ebeaf1522c6acf10d02ce5e2e2bce8322a3d30d19d0410193123bb864eb")
addappid(42912, 1, "91893929e92a7085918a7f88e8487109efcf2ea829a872d0b833ea40d09fd298")
addappid(42913, 1, "cb6ce859283d26e14ccc33389f09cd63f8009e6dabc9d2558c4cf49e00121551")
addappid(266740, 0, "5c28c32fa738eff52c1c480cbf2a5dd0d704aa61c1e526ec0cbddf87ac9f1613")
