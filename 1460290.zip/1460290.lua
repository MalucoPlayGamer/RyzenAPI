-- Lua provided by RyzenAPI
-- Game: Game: Loop

-- MAIN APPLICATION
addappid(1460290)
-- Game: addappid(1460290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460291, 1, "90953ca9adb5665f027336599aaa7da7c271c97cbeeec55cbb13b2f444ccffc7")
addappid(1460293, 1, "4028a99b4bd4ac2999c647f0c4faf2e23362a6478c0b29985b0f0f7898511830")
addappid(1460294, 1, "9b56cfe6404c5ada266cc2755e9548fa170813b38beb02395fd65c17127f149e")
