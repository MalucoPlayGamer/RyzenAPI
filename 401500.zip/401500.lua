-- Lua provided by RyzenAPI
-- Game: Last Dream Original Soundtrack

-- MAIN APPLICATION
addappid(401500)

-- MAIN APP DEPOTS / PACKAGES
addappid(401500,0,"6f3ac150f40035b3d1a0a46e5d010e26e57d4b721f20ab2f2a1aaacd6c645557")
