-- Lua provided by RyzenAPI
-- Game: Prisoners

-- MAIN APPLICATION
addappid(2725200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2725201, 1, "1e025fd35e40eac3fa13bf88fb8777b9adb426070df49a4a1622461d2da2e5b9")

