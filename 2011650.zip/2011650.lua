-- Lua provided by RyzenAPI
-- Game: Game: SPIRITUS

-- MAIN APPLICATION
addappid(2011650)
-- Game: addappid(2011650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011651, 1, "6d32704174d88e8dceb000d027d12b6dad7da1c804bc56fb9c7d2473cd04cec9")
