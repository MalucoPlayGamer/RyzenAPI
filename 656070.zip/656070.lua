-- Lua provided by RyzenAPI
-- Game: 656070

-- MAIN APPLICATION
addappid(656070)
addappid(656071)
addappid(656072)
-- Game: addappid(656070)

-- MAIN APP DEPOTS / PACKAGES
addappid(656073,0,"e72ec09fee7814f0323d761a1602883440bbddf5be808883bc9282acfa065c8d")
addappid(656074,0,"ac97d9b056d90706d56eca0035f0995d89b63317fdbe89dd7bd78f1587c3f41d")
