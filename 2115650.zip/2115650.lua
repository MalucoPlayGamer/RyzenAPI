-- Lua provided by RyzenAPI
-- Game: Xeno Command

-- MAIN APPLICATION
addappid(2115650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2115655,0,"2e8c1108693dc416503c63161dfd26a8ac641095e518c17472dfdb1401f3fc63")
