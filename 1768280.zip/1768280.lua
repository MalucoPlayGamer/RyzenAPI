-- Lua provided by RyzenAPI
-- Game: AppID 1768280

-- MAIN APPLICATION
addappid(1768280)
addappid(2057780)
addappid(2057781)
addappid(2057782)
addappid(2057783)
addappid(2057784)
addappid(2057785)
addappid(2226120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1768281, 1, "65311719320baaa218623ce4c897ea6ebe89a0031a33aff30e97a77305bf29ce")
addappid(1768282, 1, "0a70958722cf06622ff0dcd532e66869924626ee2145f8350bc27ef4d1d7c4a1")

