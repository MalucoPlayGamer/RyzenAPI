-- Lua provided by RyzenAPI
-- Game: Game: Rock Paper Scissors Champion

-- MAIN APPLICATION
addappid(449050)
-- Game: addappid(449050)

-- MAIN APP DEPOTS / PACKAGES
addappid(449051, 1, "860eeb38b68fa3395f3d347c3b1369e6ceef06de334c34e5fb09141653521d7d")
addappid(451730, 0, "d8599ce38b5d7d9ff5ef202241b8f353e953f54e044d58999685624ed0357dfb")
