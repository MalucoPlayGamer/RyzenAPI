-- Lua provided by RyzenAPI
-- Game: addappid(1393870)

-- MAIN APPLICATION
addappid(1393870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1393871, 1, "255c9cc0f1620031e595db453c2ae66b7b2eb6f897eb487afff665c63abf0ccd")
