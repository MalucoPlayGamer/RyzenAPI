-- Lua provided by RyzenAPI
-- Game: addappid(1576560)

-- MAIN APPLICATION
addappid(1576560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1576561, 1, "32db52124570890a8d14456bceeca7e9f4d6a6fabc6b2cc042d9365e35211161")
