-- Lua provided by RyzenAPI
-- Game: AppID 458380

-- MAIN APPLICATION
addappid(458380)
-- Game: addappid(458380)

-- MAIN APP DEPOTS / PACKAGES
addappid(458381, 1, "ec33d646d2cb242a3c7931bf3dc7e8a8682c143f404b577b454eb972b3e66b1e")
