-- Lua provided by SkyAPI 
-- Game: AppID 1109570
addappid(1109570)
addappid(1109571, 1, "80164c3cba3c8e54a398cc2797ce86e94fddc318ae615cd4a376be0fedfae9bc")
addappid(1109572, 1, "6634723f7faa6d9c38ee231fc0bb01805be928ef32d2d472478170b903ae78bd")
addappid(1109573, 1, "3d78421813021de678adffe80cbc3c0d5b9a7b5bf8462f64ca4a2dd9da25c101")
