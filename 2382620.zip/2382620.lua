-- Lua provided by RyzenAPI
-- Game: The Stoevi Curse

-- MAIN APPLICATION
addappid(2382620)
-- Game: addappid(2382620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2382621, 1, "c114cef56d487920c858122fc08c1dece94c0cf842030d37dbd653e69e6ad963")
