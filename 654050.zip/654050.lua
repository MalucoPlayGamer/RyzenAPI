-- Lua provided by RyzenAPI
-- Game: AppID 654050

-- MAIN APPLICATION
addappid(654050)
-- Game: addappid(654050)

-- MAIN APP DEPOTS / PACKAGES
addappid(654051, 1, "e62d197be9dcdfccba3cd43bc7fdd8e6798e50eee328b3158e75362fd25ad7bb")
