-- Lua provided by RyzenAPI
-- Game: Biggest Stream Hover Racing

-- MAIN APPLICATION
addappid(1775640)
-- Game: addappid(1775640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1775642,0,"649daee055d0938e675a390a9c501864537137e6549868dc36cc1f30675438a3")
