-- Lua provided by RyzenAPI
-- Game: Biggest Stream Hover Racing

-- MAIN APPLICATION
addappid(1775640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1775642,0,"649daee055d0938e675a390a9c501864537137e6549868dc36cc1f30675438a3")

