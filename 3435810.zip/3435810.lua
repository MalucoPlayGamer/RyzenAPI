-- Lua provided by RyzenAPI
-- Game: 3435810

-- MAIN APPLICATION
addappid(3435810)
-- Game: addappid(3435810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3435811, 1, "fce7089bfb6d990eced6cc9ebbe63791dbf75ce48698302af9b945bb2b56040b")
