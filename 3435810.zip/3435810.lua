-- Lua provided by SkyAPI 
-- Game: GoodMan
addappid(3435810)
addappid(3435811, 1, "fce7089bfb6d990eced6cc9ebbe63791dbf75ce48698302af9b945bb2b56040b")
