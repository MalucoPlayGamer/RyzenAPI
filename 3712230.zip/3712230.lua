-- Lua provided by RyzenAPI
-- Game: Pilgrim of Darkness

-- MAIN APPLICATION
addappid(3712230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3712231,0,"dc65246c4f60071b1319ce6ba4d57efea8024281267f91266c96c9a960889213")

