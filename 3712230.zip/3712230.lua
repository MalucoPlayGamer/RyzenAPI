-- Lua provided by RyzenAPI
-- Game: Pilgrim of Darkness

-- MAIN APPLICATION
addappid(3712230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3712231,0,"dc65246c4f60071b1319ce6ba4d57efea8024281267f91266c96c9a960889213")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
