-- Lua provided by RyzenAPI
-- Game: AppID 687800

-- MAIN APPLICATION
addappid(687800)

-- MAIN APP DEPOTS / PACKAGES
addappid(687801, 1, "c2ca504542832cb9bfbb6785fafb8bd15bf790b11ca42c4c627bebcdbdf13e9c")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2517510)
addappid(2618340)
addappid(2747080)
addappid(2850080)
addappid(3172940)
addappid(3857000)
addappid(4177410)
addappid(4623070)
addappid(4900130)
