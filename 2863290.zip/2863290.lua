-- Lua provided by RyzenAPI
-- Game: addappid(2863290)

-- MAIN APPLICATION
addappid(2863290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2863291, 1, "3792fae559fb2d4d6383bd1dba2424d9a790bceb7e67074b348eefe8459df343")
