-- Lua provided by RyzenAPI 
-- Game: Bubsy Two-Fur
addappid(426630)
addappid(426631, 1, "12ae03c3ff0e1346a496e38127492a5c3c77fae0a96d453160b8f9ca6140c282")
