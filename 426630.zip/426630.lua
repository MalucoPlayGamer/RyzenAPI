-- Lua provided by RyzenAPI
-- Game: Game: Bubsy Two-Fur

-- MAIN APPLICATION
addappid(426630)
-- Game: addappid(426630)

-- MAIN APP DEPOTS / PACKAGES
addappid(426631, 1, "12ae03c3ff0e1346a496e38127492a5c3c77fae0a96d453160b8f9ca6140c282")
