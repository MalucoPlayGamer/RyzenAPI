-- Lua provided by RyzenAPI
-- Game: 1156120

-- MAIN APPLICATION
addappid(1156120)
-- Game: addappid(1156120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1156121, 1, "f0668802a2df06060549621fdcea840e7b3f5415c2c79b5fd45cfb9f94d50f95")
