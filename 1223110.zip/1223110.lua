-- Lua provided by SkyAPI 
-- Game: BalloonBoyBob
addappid(1223110)
addappid(1223111, 1, "e1d27855f388e34c40fdd2706e6f6217a9266459815baf9be3a9754811e8570a")
