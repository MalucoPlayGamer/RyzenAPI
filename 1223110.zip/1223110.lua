-- Lua provided by RyzenAPI
-- Game: BalloonBoyBob

-- MAIN APPLICATION
addappid(1223110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223111, 1, "e1d27855f388e34c40fdd2706e6f6217a9266459815baf9be3a9754811e8570a")

