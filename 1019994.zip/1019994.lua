-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Additional Weapon "Bow & Rod" / 追加武器「鞭箭弓」

-- MAIN APPLICATION
addappid(1019994)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019994,0,"d1ba283f99d35ded7684e6e8b9411335ca206eb7a10a62492976f396073d28ae")

