-- Lua provided by RyzenAPI
-- Game: addappid(710030)

-- MAIN APPLICATION
addappid(710030)

-- MAIN APP DEPOTS / PACKAGES
addappid(710031, 1, "43215f3396b3507605c4e4d478e4dac714680082816ad7db77543caae5324491")
addappid(722120, 0, "4d1d04fb06185f8aa3fcdd7b3dc1b1cf99cb7ce8f2806b4b5ce831df909a48b9")
addappid(722820, 0, "7e41241c1efbcca2cfc09fcd8cd572ee20b4d90c0e35c93f926018bfa87a08ac")
