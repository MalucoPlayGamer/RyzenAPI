-- Lua provided by RyzenAPI
-- Game: ImpossiBowl

-- MAIN APPLICATION
addappid(2573610)
addappid(3008370)
addappid(3191480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2573611, 1, "de466e52287d88b597e4774f7f8625509954d992f247df6a968661170e130ecd")

