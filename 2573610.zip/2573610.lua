-- Lua provided by RyzenAPI
-- Game: ImpossiBowl

-- MAIN APPLICATION
addappid(2573610)
-- Game: addappid(2573610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2573611, 1, "de466e52287d88b597e4774f7f8625509954d992f247df6a968661170e130ecd")
