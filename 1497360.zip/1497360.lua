-- Lua provided by RyzenAPI
-- Game: Open Roads

-- MAIN APPLICATION
addappid(1497360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1497361, 1, "48f1011f86f60bccc2df08a80e927cfb8fa21a4e5f7043e0ee576cb816d800f4")

