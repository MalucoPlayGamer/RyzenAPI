-- Lua provided by SkyAPI 
-- Game: Open Roads
addappid(1497360)
addappid(1497361, 1, "48f1011f86f60bccc2df08a80e927cfb8fa21a4e5f7043e0ee576cb816d800f4")
