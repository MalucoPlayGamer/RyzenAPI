-- Lua provided by SkyAPI 
-- Game: Word
addappid(2151420)
addappid(2151421, 1, "cb6f2eaef437bebb343e9f1529ee4b161ab60ca7390688c8f0c0738c2146a5d4")
