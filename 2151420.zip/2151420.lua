-- Lua provided by RyzenAPI
-- Game: Word

-- MAIN APPLICATION
addappid(2151420)
addappid(2212870)
addappid(2212871)
addappid(2212872)
addappid(2212873)
addappid(2212874)
addappid(2212875)
addappid(2212876)
addappid(2212877)
addappid(2212878)

-- MAIN APP DEPOTS / PACKAGES
addappid(2151421, 1, "cb6f2eaef437bebb343e9f1529ee4b161ab60ca7390688c8f0c0738c2146a5d4")

