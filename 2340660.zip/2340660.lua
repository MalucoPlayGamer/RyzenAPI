-- Lua provided by RyzenAPI
-- Game: Game: AppID 2340660

-- MAIN APPLICATION
addappid(2340660)
-- Game: addappid(2340660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340661, 1, "f09a391b11acd6c4fa5a5b3fa3f1f68e370c7a23f45241760297c8e4a57e5b5c")
