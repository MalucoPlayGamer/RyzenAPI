-- Lua provided by RyzenAPI
-- Game: Camping Simulator: The Squad

-- MAIN APPLICATION
addappid(1562260)
-- Game: addappid(1562260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562261, 1, "d2bf766c1b75f19d6e6a875ba4c98ba46036890dd8945e13afa9afae5f70ae8a")
