-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Krachware User Interface Material Steampunk

-- MAIN APPLICATION
addappid(1433690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433690,0,"36237afd58fd0eaa9981155f8b466f80c523113f3b013712728de8a9360b0c66")

