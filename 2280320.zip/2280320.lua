-- Lua provided by RyzenAPI
-- Game: Amigo: Kebab Simulator

-- MAIN APPLICATION
addappid(2280320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2280321, 1, "e00e67d40fd084fe5e7c98928b71b2ff53e2f6f32ae91533b4f579851f6b3afb")

