-- Lua provided by RyzenAPI
-- Game: Epiphany City: Prologue

-- MAIN APPLICATION
addappid(1593730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593731, 1, "e078ad56babe03fc8c4f03b1d962422598fe26cb961de3cd7c8166c41769a86a")
addappid(1593732, 1, "03997c6754b99bc8e054c20bdab11414b286bd86a647eb25007c701feadd72df")

