-- Lua provided by RyzenAPI
-- Game: addappid(1581800)

-- MAIN APPLICATION
addappid(1581800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581801, 1, "31fd48b7f02bb951bb9463fa27c93024f3acfd69047bd6803649592303c2f86c")
