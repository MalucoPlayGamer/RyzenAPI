-- Lua provided by RyzenAPI 
-- Game: KRITIKA: ZERO
addappid(3007020)
addappid(3007021, 1, "2421e36c577bf1b57aefcdfb9d275761607b0f031682cf282b3b58b50d199bb3")
