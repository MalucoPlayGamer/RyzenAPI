-- Lua provided by RyzenAPI
-- Game: Game: AppID 862320

-- MAIN APPLICATION
addappid(862320)
-- Game: addappid(862320)

-- MAIN APP DEPOTS / PACKAGES
addappid(862321, 1, "d5cba32a3677b28a10437150d017f00feddb1c2e827a6bcd9cfbe08b2addb31a")
