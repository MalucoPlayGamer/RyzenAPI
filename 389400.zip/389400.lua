-- Lua provided by RyzenAPI
-- Game: AppID 389400

-- MAIN APPLICATION
addappid(389400)
-- Game: addappid(389400)

-- MAIN APP DEPOTS / PACKAGES
addappid(389401, 1, "8f3136001be973ef499ebe27701c61cc6d776248c445069d54ca4ba26c4d70ec")
