-- Lua provided by RyzenAPI
-- Game: addappid(3514150)

-- MAIN APPLICATION
addappid(3514150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3514151, 1, "73032d6c163eeb8b15bc1392f932fb263b0640faa0d8e4f009274b26781cbeaa")
