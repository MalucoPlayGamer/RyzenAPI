-- Lua provided by RyzenAPI
-- Game: Bacteria

-- MAIN APPLICATION
addappid(448470)
-- Game: addappid(448470)

-- MAIN APP DEPOTS / PACKAGES
addappid(448471, 1, "09ad1fc66a5eee2929a6beb2511648c9d9be3067cfbac8e7ef3718c034aafbdf")
addappid(448472, 1, "66ae528333534dd16782e008b4156fd7736a62d59d701a7ced1ee55dee5ba110")
addappid(448473, 1, "397d42682da37e44258041eda1354853a72893a97a65dac95bff07153329ce75")
addappid(448760, 0, "f961b81b26aaa75ba6999abea1b120cd3056a339a88b3b7edc5d66dbdbafa2b8")
addappid(449400, 0, "414a8470801c917b04744159dc1ac27f786f6ff0b4e566b4c2d03bee69cee6dc")
