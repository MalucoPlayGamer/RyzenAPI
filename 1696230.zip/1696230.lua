-- Lua provided by RyzenAPI
-- Game: 1696230

-- MAIN APPLICATION
addappid(1696230)
-- Game: addappid(1696230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1696231, 1, "8ec8f38d1814933f6499c5cf2aeef3dd68096e4d696e6c904929200cdbc7b5b2")
