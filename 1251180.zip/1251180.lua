-- Lua provided by RyzenAPI
-- Game: Game: Nyanco Channel - Soundtrack

-- MAIN APPLICATION
addappid(1251180)
-- Game: addappid(1251180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1251181, 1, "07dfe5ab193e8922aad4073b8c09e4faaec122691e0e3693bea838bee023777f")
