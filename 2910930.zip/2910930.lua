-- Lua provided by RyzenAPI
-- Game: 最后的传奇

-- MAIN APPLICATION
addappid(2910930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2910931, 1, "9c446eeeae4f93398eee0d779ae3b6630fe700b80341dd2caa5b6d392fd830ef")
