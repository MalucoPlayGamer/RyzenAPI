-- Lua provided by RyzenAPI 
-- Game: Turbo Dismount® 2
addappid(2280350)
addappid(2280351, 1, "05912239d3da3436c0206a9c064eff71dd637b6a9b9e540ba91cd84f6548e541")
