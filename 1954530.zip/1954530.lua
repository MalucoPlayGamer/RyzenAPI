-- Lua provided by RyzenAPI
-- Game: AppID 1954530

-- MAIN APPLICATION
addappid(1954530)
-- Game: addappid(1954530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1954531, 1, "2bd36c0189ae1a4b236d852bfc8d0e2db0d73b8942b64f564adae62327a71890")
