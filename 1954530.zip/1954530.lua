-- Lua provided by RyzenAPI
-- Game: 修理行 Dullpain Demo

-- MAIN APPLICATION
addappid(1954530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1954531, 1, "2bd36c0189ae1a4b236d852bfc8d0e2db0d73b8942b64f564adae62327a71890")

