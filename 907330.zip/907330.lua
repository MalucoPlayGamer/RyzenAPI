-- Lua provided by RyzenAPI
-- Game: addappid(907330)

-- MAIN APPLICATION
addappid(907330)

-- MAIN APP DEPOTS / PACKAGES
addappid(907331, 1, "271293530fe7a8052074d7c8fce4d9b4be12ee871664a54eec1ee079140d7aed")
