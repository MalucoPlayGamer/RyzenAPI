-- Lua provided by RyzenAPI
-- Game: Game: Astro World Demo

-- MAIN APPLICATION
addappid(2057050)
-- Game: addappid(2057050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2057051, 1, "af077a99cdc8f3e1c20be55c83b242b6df681694edbd43b82259bc257370847c")
