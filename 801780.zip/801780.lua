-- Lua provided by RyzenAPI
-- Game: Game: Haters, kill them all!

-- MAIN APPLICATION
addappid(801780)
-- Game: addappid(801780)

-- MAIN APP DEPOTS / PACKAGES
addappid(801781, 1, "c881f1b1a7bd10d8c37ea8a4cc9bbae31ca98fed62abf9cfaeec561038e66eae")
addappid(810310, 0, "c12556a09af30d4ef56e7e59f4579950ef98fab33cb76ccbd5d3adb7fd757cfc")
