-- Lua provided by RyzenAPI 
-- Game: First Customer
addappid(1086490)
addappid(1086491, 1, "318cc30a107039c70154ce6d4fbe0743ee720212f46b46e659badad1112f7680")
