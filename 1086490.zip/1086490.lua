-- Lua provided by RyzenAPI
-- Game: First Customer

-- MAIN APPLICATION
addappid(1086490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1086491, 1, "318cc30a107039c70154ce6d4fbe0743ee720212f46b46e659badad1112f7680")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
