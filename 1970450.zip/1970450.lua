-- Lua provided by RyzenAPI
-- Game: Desert Blossom

-- MAIN APPLICATION
addappid(1970450)
addappid(4153520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1970451, 1, "0d6e46caf81d6d332a6fd015bad3f4f86a3113f28d783b141f7b100746c5234e")
