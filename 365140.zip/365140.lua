-- Lua provided by SkyAPI 
-- Game: DREAMFLIGHT VR
addappid(365140)
addappid(365141, 1, "e02beb14fd37d16fc381b26289829c10ece659f05bc14b1ae4373da9eefc01b4")
