-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Hero Character Generator for MZ

-- MAIN APPLICATION
addappid(3364430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3364430,0,"4508aafb982547410c1ba67a18df074aa034567082b2a199059c61afdd6abdd5")

