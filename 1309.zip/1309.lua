-- Lua provided by RyzenAPI
-- Game: SiN Episodes: Emergence

-- MAIN APPLICATION
addappid(1309)

-- MAIN APP DEPOTS / PACKAGES
addappid(1311,0,"2c6305c96d02b24ddb26c7de12ea9a4ec2948a567dcedc55fb533f99c8dbe616")

