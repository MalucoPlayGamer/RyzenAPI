-- Lua provided by SkyAPI 
-- Game: Darxanadon
addappid(1867070)
addappid(1867071, 1, "ff5d0ff1c23029c8b3a69104948b854075b3b65c6ff1eb02519b5b674ba862ae")
