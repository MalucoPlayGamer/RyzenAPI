-- Lua provided by RyzenAPI
-- Game: Darxanadon

-- MAIN APPLICATION
addappid(1867070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1867071, 1, "ff5d0ff1c23029c8b3a69104948b854075b3b65c6ff1eb02519b5b674ba862ae")
