-- Lua provided by RyzenAPI
-- Game: Game: Tick's Tales

-- MAIN APPLICATION
addappid(411610)
-- Game: addappid(411610)

-- MAIN APP DEPOTS / PACKAGES
addappid(411611, 1, "716417a29ec8a2bfe7a82eddb0c22e307a39535da1b4e897537d6ef61acfd886")
addappid(411612, 1, "86e0118b8086b712a33a984623992c0778fa2acffee124a838c6fb37b0aac136")
addappid(411613, 1, "e50f2be5f6484556329683115734505780965688d82c7f9da23e0d876af56150")
addappid(411614, 1, "bf76a2de44494a2b72e88eb79ecc09622ac8ddbad3b2c22f2f7d89afb8e3a5bd")
