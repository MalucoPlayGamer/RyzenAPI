-- Lua provided by RyzenAPI
-- Game: Game: Conquistadorio

-- MAIN APPLICATION
addappid(2472550)
-- Game: addappid(2472550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2472551, 1, "3c7f8a2a6cb285695313cc45e45e07c1d124b8bf84caf575fe5f571f0dabd603")
