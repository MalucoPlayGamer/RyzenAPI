-- Lua provided by RyzenAPI
-- Game: addappid(1239210)

-- MAIN APPLICATION
addappid(1239210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239211, 1, "6f804f8101feb0438f82b0a2721b175ec7c3bf0fbbc0f5822da9bb17bb789b41")
addappid(1239212, 1, "b22369fdc56ef886afa5ff79a81439ac53acf2a7b80e3bbef183090d14276910")
