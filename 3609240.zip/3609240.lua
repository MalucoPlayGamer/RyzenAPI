-- Lua provided by RyzenAPI
-- Game: 3609240

-- MAIN APPLICATION
addappid(3609240)
-- Game: addappid(3609240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3609240,0,"8910c52f52cdd35759cba7a94fb389bed3c15ab330fe1778b5bab961635d3e28")
