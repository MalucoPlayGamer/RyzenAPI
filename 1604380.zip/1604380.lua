-- Lua provided by RyzenAPI
-- Game: Hamidashi Creative

-- MAIN APPLICATION
addappid(1604380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1604381, 1, "9292a66b2728e068115a1d2f3e8c04ec7aefc3679c84c129aa083a88ad89ad61")
addappid(3407830, 0, "d6dcb3fdc71052751a7b72b7ad2d198d33ce84b7c85d10991b208cf70de122d0")
