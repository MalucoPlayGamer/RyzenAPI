-- Lua provided by RyzenAPI
-- Game: V696

-- MAIN APPLICATION
addappid(1854050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1854051, 1, "b4084b0b032e11ecd43834bd6c34c50f9dadb44f838df33998508b00578bfcb8")

