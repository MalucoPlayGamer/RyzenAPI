-- Lua provided by RyzenAPI
-- Game: Lolly Pang VR

-- MAIN APPLICATION
addappid(942870)
-- Game: addappid(942870)

-- MAIN APP DEPOTS / PACKAGES
addappid(942871, 1, "6edb2a83fe843abaf14889b4da0714b56445651421866a792f0d119abcca8194")
