-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1431500)
-- Game: addappid(1431500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1431502,0,"8ecc9eee1979d5107d04879c2c334ba0cdd646159b8ac3361467f528bddcc1ba")
