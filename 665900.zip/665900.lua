-- Lua provided by RyzenAPI 
-- Game: 火箭星战 Star-Rocket Strike
addappid(665900)
addappid(665901, 1, "8bc1120193ee06716313771c40c8c8d5bcfc1d2b22e6b8e25ebbe581a9dc82b3")
