-- Lua provided by RyzenAPI
-- Game: Shardbound: Forge Your Path, Master Your Strategy

-- MAIN APPLICATION
addappid(586030)
addappid(667980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(586031, 1, "ed488ddbe922cf604b5da58b6755b96604d795cd3570784ff6b79f4cd2afee8b")

