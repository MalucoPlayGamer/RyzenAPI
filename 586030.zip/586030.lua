-- Lua provided by RyzenAPI
-- Game: 586030

-- MAIN APPLICATION
addappid(586030)
-- Game: addappid(586030)

-- MAIN APP DEPOTS / PACKAGES
addappid(586031, 1, "ed488ddbe922cf604b5da58b6755b96604d795cd3570784ff6b79f4cd2afee8b")
