-- Lua provided by RyzenAPI
-- Game: Steam Tactics

-- MAIN APPLICATION
addappid(708950)
-- Game: addappid(708950)

-- MAIN APP DEPOTS / PACKAGES
addappid(708951, 1, "0b93f131b498016f249c29ad74ace62beb8b78aeafd66aafb817fdafbf2e8f45")
