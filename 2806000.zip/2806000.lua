-- Lua provided by RyzenAPI
-- Game: Hentai Senpai: Cosmic Beauties - Premium Pack

-- MAIN APPLICATION
addappid(2806000)
-- Game: addappid(2806000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2806000,0,"166598d8bbdd8c2d76e12cef9745ca37593f5740b65ad0bfebd3a55865104cfb")
