-- Lua provided by RyzenAPI
-- Game: Spirit Mancer

-- MAIN APPLICATION
addappid(2172580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2172581, 1, "b128baba7c33b92f4485822b4f75e3eb43a5f02ed6b85ae2333505efd253c237")
addappid(3239520, 0, "ac8892ce6df2a27d9d40c1975b4ba0d9ceb6a63b3b637500eaedfc9e0cf29200")
addappid(3325230, 0, "525a1e5a9df2819721645b073276e6e53477ad46ae5b4edb118b828907ae6a16")
addappid(3325240, 0, "72cfba234ce9fb70470a267d4e8452be4cdaa5aedfdbfbe4072b41155079f844")
addappid(3325250, 0, "e894a3bbbaf91d4b4a7ae1f468dc7f7783f2b873d5ba0fad8ecb2abbfe3af43d")

