-- Lua provided by RyzenAPI
-- Game: Might & Magic Fates - Heroes TCG

-- MAIN APPLICATION
addappid(3918850)

