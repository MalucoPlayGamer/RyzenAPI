-- Lua provided by RyzenAPI
-- Game: Metal Strike

-- MAIN APPLICATION
addappid(1441090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441091, 1, "2106ecfe5dec0bf3f397b143c185177cca903c939e42a72e48ee8ffa07c9fcad")
