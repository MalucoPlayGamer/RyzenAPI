-- Lua provided by SkyAPI 
-- Game: REDLINE CROOKS
addappid(2454350)
addappid(2454351, 1, "29514f783cf9c6e586751c7802be3621930233fa79adaf93a245f298d01c93a7")
