-- Lua provided by RyzenAPI
-- Game: Game: AppID 1275850

-- MAIN APPLICATION
addappid(1275850)
-- Game: addappid(1275850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1275851, 1, "504af59df8acf3f447e68229b45459427bc57a3032927eeb27bca8bfd4353f47")
