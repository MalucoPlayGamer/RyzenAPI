-- Lua provided by RyzenAPI
-- Game: 3534850

-- MAIN APPLICATION
addappid(3534850)
-- Game: addappid(3534850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3534851, 1, "225761edf0e981c9eeae5fb0e29c5c9847893ccafecdbfcd3af4ede7d86a9f7a")
