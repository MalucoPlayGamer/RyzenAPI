-- Lua provided by RyzenAPI
-- Game: addappid(796340)

-- MAIN APPLICATION
addappid(796340)

-- MAIN APP DEPOTS / PACKAGES
addappid(796341, 1, "41d7e2f9c818d0e489962b40aa24da0775f9e96239bac4a93d4bf82211890e02")
