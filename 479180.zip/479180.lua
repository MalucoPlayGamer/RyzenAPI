-- Lua provided by RyzenAPI
-- Game: 479180

-- MAIN APPLICATION
addappid(479180)
-- Game: addappid(479180)

-- MAIN APP DEPOTS / PACKAGES
addappid(479181, 1, "8b4e018936da4ea0ac20e946bdb3294c612a89e21cda757e93fec05ff50f99cb")
