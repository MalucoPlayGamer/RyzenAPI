-- Lua provided by RyzenAPI
-- Game: Game: Reflection of a Fallen Feather

-- MAIN APPLICATION
addappid(594310)
-- Game: addappid(594310)

-- MAIN APP DEPOTS / PACKAGES
addappid(594311, 1, "33c7e8fb93c4d3b8e7cab5ba2db2e02e10bff8b15c2285b62b5a71a6800d473a")
addappid(594312, 1, "795fe12e996b64f62b423fd1606ff1bd7dff425169d22b0fec88c0c252da75c3")
addappid(594313, 1, "99de8294ca0ac0516556b668c078c645d406e54f1d31efba1274790a8b80a3fb")
