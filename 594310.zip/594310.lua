-- Lua provided by RyzenAPI
-- Game: Reflection of a Fallen Feather

-- MAIN APPLICATION
addappid(594310)

-- MAIN APP DEPOTS / PACKAGES
addappid(594311, 1, "33c7e8fb93c4d3b8e7cab5ba2db2e02e10bff8b15c2285b62b5a71a6800d473a")
addappid(594312, 1, "795fe12e996b64f62b423fd1606ff1bd7dff425169d22b0fec88c0c252da75c3")
addappid(594313, 1, "99de8294ca0ac0516556b668c078c645d406e54f1d31efba1274790a8b80a3fb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
