-- Lua provided by RyzenAPI
-- Game: addappid(1419640)

-- MAIN APPLICATION
addappid(1419640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419641, 1, "675e6f0c3deade48418dd1235e5c0e165acd110af809e14dac4c93b97832dd4f")
