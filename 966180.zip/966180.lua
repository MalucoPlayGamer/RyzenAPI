-- Lua provided by RyzenAPI
-- Game: Slime Research

-- MAIN APPLICATION
addappid(966180)
-- Game: addappid(966180)

-- MAIN APP DEPOTS / PACKAGES
addappid(966181, 1, "fe659b3bcdc7d5d9faefc2636af021da4893ba6759ab467b949369e6f66f3fbb")
