-- Lua provided by RyzenAPI 
-- Game: AppID 2702050
addappid(2702050)
addappid(2702051, 1, "12559eb69f006ca80a770709aeba35eb55c5457f1e1ee157fb213b9db8f3e9f6")
addappid(2702052, 1, "b38468c1ae2adb3ddcd80ea6bc8f328a64de634ad33f7cde27eaea0727ebe4fc")
addappid(2702053, 1, "988f774b0f8c4a05749938fcaa3229b9a65d15d0e7e3d6c61aabd44124a05e27")
