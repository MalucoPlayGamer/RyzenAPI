-- Lua provided by RyzenAPI
-- Game: addappid(3284400)

-- MAIN APPLICATION
addappid(3284400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3284401, 1, "72260e3a8b6da6546bc01991e8680d42e7e84dcdf7cfa842d77251a06b423199")
