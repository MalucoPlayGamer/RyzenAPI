-- Lua provided by RyzenAPI
-- Game: Tetris® Forever

-- MAIN APPLICATION
addappid(3180240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3180241, 1, "07212c3fa4398f303f3a308f7ff9253dc060d732095cf5725710525cd3a9dcc7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
