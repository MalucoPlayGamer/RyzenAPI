-- Lua provided by RyzenAPI
-- Game: Aooni

-- MAIN APPLICATION
addappid(2934190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934191, 1, "308e6b3cfc8029a8670bf0e728086143da69d3c2cc2a95a7b467ecafebbc2cd3")
