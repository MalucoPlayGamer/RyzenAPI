-- Lua provided by RyzenAPI
-- Game: 2058450

-- MAIN APPLICATION
addappid(2058450)
-- Game: addappid(2058450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058451, 1, "97a9008635cfab8fe7a02b9bc019231e00834aca834d165834a26cabd2f29f98")
