-- Lua provided by RyzenAPI
-- Game: World Capitals Quizzer

-- MAIN APPLICATION
addappid(2384860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384861, 1, "a6a88fe811c157c00b9a29ab209c3c5550617afb8bfca70b2cab539fe30cbcc0")
addappid(2384862, 1, "d65fb2585228e7af1dc722fc6b8464399bff5e75f92bb24d229d0678fdd981e9")
