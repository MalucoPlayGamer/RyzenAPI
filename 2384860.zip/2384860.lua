-- 2384860's Lua and Manifest Created by Hubcap Manifest
-- World Capitals Quizzer
-- Created: August 02, 2026 at 06:55:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 10

-- MAIN APPLICATION
addappid(2384860) -- World Capitals Quizzer
-- MAIN APP DEPOTS
addappid(2384861, 1, "a6a88fe811c157c00b9a29ab209c3c5550617afb8bfca70b2cab539fe30cbcc0") -- Depot 2384861
setManifestid(2384861, "2037411931274120973", 555674932)
addappid(2384862, 1, "d65fb2585228e7af1dc722fc6b8464399bff5e75f92bb24d229d0678fdd981e9") -- Depot 2384862
setManifestid(2384862, "5038740524825147830", 689378461)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2497700) -- World Capitals Quizzer - Capitals
addappid(2497710) -- World Capitals Quizzer - Human Networks
addappid(2497720) -- World Capitals Quizzer - Countries
addappid(2497730) -- World Capitals Quizzer - Landmarks
addappid(2497740) -- World Capitals Quizzer - Unlock All Game Modes
addappid(2821650) -- World Capitals Quizzer - Globe
addappid(2821660) -- World Capitals Quizzer - People
addappid(3969240) -- Capitals Quizzer - Symbols Mode
addappid(3969250) -- World Capitals Quizzer - Flags
addappid(4499550) -- World Capitals Quizzer - Compare