-- Lua provided by RyzenAPI
-- Game: Tree Simulator 2020

-- MAIN APPLICATION
addappid(1043500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1043501, 1, "4b5123ab3663534198632ac39a580c820915e34c9349ffeea047d2c6c66e62af")
