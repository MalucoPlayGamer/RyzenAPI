-- Lua provided by RyzenAPI
-- Game: 月白星斗-Lunar Glow Stellar Dance

-- MAIN APPLICATION
addappid(2653460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2653461, 1, "5d2e2ddcf627a85e6b3883603049f31c06f8b581b35059e5e150d1a0e53df22b")

