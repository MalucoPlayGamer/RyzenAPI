-- Lua provided by SkyAPI 
-- Game: Cranky Cat
addappid(236290)
addappid(236291, 1, "eeaa415d7af3e409abe28bbde4e22b06a93faa9cf81029538586e47dc7efda60")
