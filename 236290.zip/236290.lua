-- Lua provided by RyzenAPI
-- Game: Cranky Cat

-- MAIN APPLICATION
addappid(236290)

-- MAIN APP DEPOTS / PACKAGES
addappid(236291, 1, "eeaa415d7af3e409abe28bbde4e22b06a93faa9cf81029538586e47dc7efda60")
