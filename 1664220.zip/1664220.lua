-- Lua provided by RyzenAPI
-- Game: TRAIL OUT

-- MAIN APPLICATION
addappid(1664220)
addappid(2444780)
addappid(2444781)
addappid(2444782)
addappid(2444783)
addappid(2444784)
addappid(2444785)
addappid(2444786)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1664221, 1, "a69c74a65f0018cd92fb6df9aa485cd06c07a6f5946fc74bcd927642d2f0280a")

