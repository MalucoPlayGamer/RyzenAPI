-- Lua provided by RyzenAPI
-- Game: addappid(1664220)

-- MAIN APPLICATION
addappid(1664220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664221, 1, "a69c74a65f0018cd92fb6df9aa485cd06c07a6f5946fc74bcd927642d2f0280a")
