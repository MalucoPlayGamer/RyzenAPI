-- Lua provided by RyzenAPI
-- Game: Nimble Quest

-- MAIN APPLICATION
addappid(228983)
addappid(259780)
addappid(259781)
addappid(259782)

-- MAIN APP DEPOTS / PACKAGES
addappid(259783,0,"b2a3470f1c1d7fd153cc4e24227ebeece580473aad46811e387af9b5f433f434")
