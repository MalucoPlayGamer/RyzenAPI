-- Lua provided by RyzenAPI
-- Game: SunnySide Demo

-- MAIN APPLICATION
addappid(2249750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2249751, 1, "2abb0aac5dee5c8db2052db7c9c688e82f5893edf626369d67ccff1a1c04681a")

