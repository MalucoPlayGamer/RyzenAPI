-- Lua provided by RyzenAPI
-- Game: Battlestations: Midway Demo

-- MAIN APPLICATION
addappid(6940)
-- Game: addappid(6940)

-- MAIN APP DEPOTS / PACKAGES
addappid(6941, 1, "2740a72ca8a3c457ff9fa3c4702445e7705a543e254c89bfdfeb52ca2844daa3")
