-- Lua provided by RyzenAPI
-- Game: Game: AppID 774461

-- MAIN APPLICATION
addappid(774461)
-- Game: addappid(774461)

-- MAIN APP DEPOTS / PACKAGES
addappid(774462, 1, "d8ec2204fb80d45bcf42e02aab2a407094532e34d8a887304bbc9f3ee4dec3a6")
addappid(774463, 1, "33b8c8377eed39c6873a7a4c5f6bcba2a16d9db3ab19c891a8b1cda59c0817c7")
addappid(774464, 1, "daf2ce3dda96103c40e8d8e69d2dae141cd345b7c3266a18ce9e6955da8a012c")
addappid(774465, 1, "08518ab704c6e1749528454fde8651e34f16f7ebd3774ab178facdeae8128809")
addappid(774466, 1, "cc168e4a512fb0c5cd45e8adbfd56e5c290ea2b3fbf5a7c0f0028742c94b7b18")
addappid(2828508, 0, "86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")
