-- Lua provided by SkyAPI 
-- Game: Soulsland: Last Fight
addappid(2105480)
addappid(2105481, 1, "12d4a3b018f257bc532ae54e15ddd542f6b62f4f9bac2f4373462fc62d3792bc")
