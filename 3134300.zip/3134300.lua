-- Lua provided by RyzenAPI
-- Game: 3134300

-- MAIN APPLICATION
addappid(3134300)
-- Game: addappid(3134300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3134301, 1, "f7a0910ea13ae813572808300a3a73069714ab6cf9a8f0fbe1d7bfef0145dcdf")
