-- Lua provided by RyzenAPI
-- Game: Robby's Adventure

-- MAIN APPLICATION
addappid(663140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(663141,0,"5cc9bc1951dac5cb70aa3b53acc940e4f6162d7b76fa52ef5856f0416a90af38")

