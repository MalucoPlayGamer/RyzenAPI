-- Lua provided by RyzenAPI
-- Game: Robby's Adventure

-- MAIN APPLICATION
addappid(663140)

-- MAIN APP DEPOTS / PACKAGES
addappid(663141,0,"5cc9bc1951dac5cb70aa3b53acc940e4f6162d7b76fa52ef5856f0416a90af38")

