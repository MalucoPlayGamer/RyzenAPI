-- Lua provided by RyzenAPI
-- Game: Demon Mark: A Russian Saga

-- MAIN APPLICATION
addappid(635830)

-- MAIN APP DEPOTS / PACKAGES
addappid(635831,0,"00170ab854b8c8c961b9ce130a5854b320cfbe66a9e01cd20c6f6ec9add1519e")

