-- Lua provided by RyzenAPI
-- Game: addappid(785770)

-- MAIN APPLICATION
addappid(785770)

-- MAIN APP DEPOTS / PACKAGES
addappid(785771, 1, "2c7097ddbc5e503a653700238917cebd42e5cb34f1bd54118c32df3457f45516")
