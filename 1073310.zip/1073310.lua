-- Lua provided by RyzenAPI
-- Game: Hentai Zodiac Puzzle

-- MAIN APPLICATION
addappid(1073310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1073311, 1, "6df4fd0df93fddd9806389c72e945a0e44bb99c5391153e35909d3021648b7ff")
addappid(1105350, 0, "b2ba41f7f4bee88ce55b2a38e975e74c780adb11bbaf33f5749a9a7035916fbd")
