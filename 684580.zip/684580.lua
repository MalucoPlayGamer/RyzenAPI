-- Lua provided by RyzenAPI
-- Game: addappid(684580)

-- MAIN APPLICATION
addappid(684580)

-- MAIN APP DEPOTS / PACKAGES
addappid(684581, 1, "54917806ec31a1731b107c0c24a563bdcf52ed50ba9dbb5510763b37ed2f1aae")
addappid(850280, 0, "12d0fc9e0e3cb6b35f588f2679a02afd3c1d7592bf03ad5d906c8dfabf77d9fc")
