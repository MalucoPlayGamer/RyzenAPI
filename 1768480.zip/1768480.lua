-- Lua provided by SkyAPI 
-- Game: ASTRA
addappid(1768480)
addappid(1768481, 1, "d32e3b61e1c42b8b125c22ae28ad7d785a3e0e37662b6cfea37c11947773f914")
