-- Lua provided by RyzenAPI
-- Game: ASTRA

-- MAIN APPLICATION
addappid(1768480)
-- Game: addappid(1768480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768481, 1, "d32e3b61e1c42b8b125c22ae28ad7d785a3e0e37662b6cfea37c11947773f914")
