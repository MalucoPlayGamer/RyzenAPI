-- Lua provided by RyzenAPI
-- Game: 705610

-- MAIN APPLICATION
addappid(705610)
-- Game: addappid(705610)

-- MAIN APP DEPOTS / PACKAGES
addappid(705611, 1, "b8c3dc72fea24491f7b8da77f38bb773790248f414a206d49ea93fd2bbd7efe6")
