-- Lua provided by RyzenAPI
-- Game: Pac Adventures 3D

-- MAIN APPLICATION
addappid(873720)

-- MAIN APP DEPOTS / PACKAGES
addappid(873721, 1, "6486943ac22f8069b77042c284de38020999553cdb10f21c037bbe492ea5557b")
