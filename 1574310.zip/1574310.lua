-- Lua provided by RyzenAPI
-- Game: Game: OXENFREE II: Lost Signals

-- MAIN APPLICATION
addappid(1574310)
-- Game: addappid(1574310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1574311, 1, "4d03fdf2f21a74afd012ffb29d0b8cb9d1b96b0b46c8e392432bf1b15719b303")
addappid(1574312, 1, "11fdc05d586cc806ac5281f676abe0e6613f461da61907eaf063422f65247128")
