-- Lua provided by RyzenAPI
-- Game: 592410

-- MAIN APPLICATION
addappid(592410)
-- Game: addappid(592410)

-- MAIN APP DEPOTS / PACKAGES
addappid(592411, 1, "ab4109cd2615c85c561ee6ccb58ae9b8c3b049a4e4d36de9970f4c5d62b500e9")
