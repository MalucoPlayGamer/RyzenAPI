-- Lua provided by RyzenAPI
-- Game: addappid(1901480)

-- MAIN APPLICATION
addappid(1901480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1901482,0,"63284e36b6de54edde57aaae8974d25835d9b3f0d33c0904dbc542ad59f28f1d")
