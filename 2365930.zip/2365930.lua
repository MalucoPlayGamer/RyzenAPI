-- Lua provided by RyzenAPI
-- Game: 觅光：第一章 - 原画集

-- MAIN APPLICATION
addappid(2365930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2365930,0,"a3b7fd85f9c24b3ed369232790c2ade6c52561cb0c278926136694f54301a516")

