-- Lua provided by RyzenAPI
-- Game: DARK FABLE

-- MAIN APPLICATION
addappid(1047830)
addappid(1084510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1047831, 1, "dc222a614d26d6337b5f7c6cdde7dab22824cd48d213d8b18011f774fe2814e9")
addappid(1047832, 1, "4819f5d5cd037ca65d03bfdaca3572dcfb67f88c3ac884d8b28dd33a04a918d1")
addappid(1084511, 1, "ccc8e0625d245540edff0b6579ca4395ae968092d18703260267226a08de3fa5")
addappid(1084512, 1, "0386483bd6758d7e734f20a91dc22d8abacb1eb2612d3deb77a0a185d84c40ba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
