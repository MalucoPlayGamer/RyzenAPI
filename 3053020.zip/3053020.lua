-- Lua provided by RyzenAPI
-- Game: My Sudoku - Classic 6x6 Medium 1

-- MAIN APPLICATION
addappid(3053020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3053020,0,"9aeed228fb5286d90e1cd6938e900e531fd61b12d8e6541f167f41a71dc5976b")

