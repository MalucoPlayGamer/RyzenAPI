-- Lua provided by RyzenAPI
-- Game: Everything Has Arms

-- MAIN APPLICATION
addappid(2008480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2008481, 1, "e4d7e11fd425471030343f87216139d45b1c9c16e46975f214f3e923a431c2b8")

