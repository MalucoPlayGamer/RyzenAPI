-- Lua provided by RyzenAPI
-- Game: Die drei ??? und der Riesenkrake

-- MAIN APPLICATION
addappid(793310)

-- MAIN APP DEPOTS / PACKAGES
addappid(793311, 1, "93221feef3013750b8a6bd9a22540792532dff0983604499a7a1b84621b5cb0a")
