-- Lua provided by RyzenAPI
-- Game: AppID 792970

-- MAIN APPLICATION
addappid(792970)

-- MAIN APP DEPOTS / PACKAGES
addappid(792971, 1, "bb2af2e0fe8572a0eb681a0ba5e325de8a05e4a5bb631a7d9c477e6c92be89c7")
addappid(792972, 1, "bdfa1248d0bed9bba8666a58547798826c62f8784189ea9e7d2103d5951a376a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
