-- Lua provided by RyzenAPI
-- Game: 792970

-- MAIN APPLICATION
addappid(792970)
-- Game: addappid(792970)

-- MAIN APP DEPOTS / PACKAGES
addappid(792971, 1, "bb2af2e0fe8572a0eb681a0ba5e325de8a05e4a5bb631a7d9c477e6c92be89c7")
addappid(792972, 1, "bdfa1248d0bed9bba8666a58547798826c62f8784189ea9e7d2103d5951a376a")
