-- Lua provided by RyzenAPI
-- Game: addappid(3118870)

-- MAIN APPLICATION
addappid(3118870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3118871, 1, "ab55ee0185043c48e26f8117b49a8ec946766a28e78b41c93e5fea96069ed8c5")
