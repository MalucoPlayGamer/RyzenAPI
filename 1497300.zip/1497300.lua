-- Lua provided by RyzenAPI
-- Game: From Day To Day Demo

-- MAIN APPLICATION
addappid(1497300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1497301, 1, "d77490c39a4d02477bd4f4b6af910ded78421889c77de9a79492c05cf267276b")

