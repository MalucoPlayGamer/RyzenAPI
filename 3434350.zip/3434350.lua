-- Lua provided by RyzenAPI
-- Game: 3434350

-- MAIN APPLICATION
addappid(3434350)
-- Game: addappid(3434350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3434351, 1, "06632ac5f638d54f9ea5a7e76136d585b635c8dc9a950fb74e2ae73cd820825c")
