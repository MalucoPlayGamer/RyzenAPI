-- Lua provided by RyzenAPI
-- Game: Mission: It's Complicated

-- MAIN APPLICATION
addappid(1041210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1041211, 1, "3c56af4071edc63361ef17d467d3ad6d26bf303592bce4c0b18cf30efc3e0f3d")
addappid(1041212, 1, "f852adaf3d3745cbd327df325bcc155a10a181f623832816e513236928b09642")

