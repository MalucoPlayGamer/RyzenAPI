-- Lua provided by RyzenAPI
-- Game: BorderZone

-- MAIN APPLICATION
addappid(289220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(289221, 1, "dd7ad193e527b82b3b462324a48152274a2377bf474bd6ce989362d3573f4cd6")
addappid(289222, 1, "8d3838d844e9e007deeaa72f14733f3344ca516d8bb43e543b8c2cd425d5b4a2")
