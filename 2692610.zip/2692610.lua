-- Lua provided by RyzenAPI
-- Game: addappid(2692610)

-- MAIN APPLICATION
addappid(2692610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2692611, 1, "da0a8c1d9645234c97b56f2747db7879cc9e2b6f955dca9f6ad3485ee8fee2e7")
