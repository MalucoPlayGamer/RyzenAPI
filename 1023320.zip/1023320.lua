-- Lua provided by RyzenAPI
-- Game: addappid(1023320)

-- MAIN APPLICATION
addappid(1023320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023321, 1, "09328b1a7ec9fc0b965c6b2d056d143c1a20c804ef2751db310f53461ef2b862")
