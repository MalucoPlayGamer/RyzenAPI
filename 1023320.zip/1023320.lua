-- Lua provided by RyzenAPI 
-- Game: Clown Thug Cop Zombies
addappid(1023320)
addappid(1023321, 1, "09328b1a7ec9fc0b965c6b2d056d143c1a20c804ef2751db310f53461ef2b862")
