-- Lua provided by RyzenAPI
-- Game: Clown Thug Cop Zombies

-- MAIN APPLICATION
addappid(1023320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023321, 1, "09328b1a7ec9fc0b965c6b2d056d143c1a20c804ef2751db310f53461ef2b862")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
