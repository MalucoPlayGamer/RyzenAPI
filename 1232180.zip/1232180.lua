-- Lua provided by RyzenAPI
-- Game: Sakuya Izayoi Gives You Advice And Dabs

-- MAIN APPLICATION
addappid(1232180)
-- Game: addappid(1232180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1232181, 1, "c1012c16b104854d8fb151eccbc929a73795be9a52a8a5b52d13bda0386fbfff")
addappid(1232182, 1, "8a4c624f4b5a29151583b28cb8a8d54129da16f64712a67d5c06a14c8032df85")
addappid(1232183, 1, "fc3e7deadcc351127aec59ce4af69484682b696f8c9de29be987ff74368fbc0a")
addappid(1232184, 1, "28985a8624a236fefdaf373a0a579e779106ff19654f842265f3eee9d002d32e")
addappid(1232185, 1, "1e9fee5ca7226fb8ed8d208c93aa02e2db80e479d32bddf29165aee88a64ba01")
addappid(1232186, 1, "2b5231f9b725b09260f6e6cf34f151da7feb6554a35cb9c5fdfcc5af1935eb2c")
addappid(1232187, 1, "4e63d687ae4bce7faba44cbce9835665b27bd7ee6da8bf9eff33f06a01fa3587")
addappid(1251640, 0, "da76152735c49874ffb4e65de3385706a7e4d525cd844efb217f43ebde582042")
