-- Lua provided by RyzenAPI
-- Game: Dark Cards

-- MAIN APPLICATION
addappid(1347460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347461, 1, "e81a287240d120ca35adde3a75021b6e05c55422f40cf04a1780066f3d828895")

