-- Lua provided by SkyAPI 
-- Game: DAMN!
addappid(680450)
addappid(680451, 1, "1950c4e3d8f3071f09189b0b380a16839c97922bccc9e5c6df86019426772782")
