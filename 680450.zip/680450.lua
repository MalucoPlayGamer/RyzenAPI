-- Lua provided by RyzenAPI
-- Game: DAMN!

-- MAIN APPLICATION
addappid(680450)
-- Game: addappid(680450)

-- MAIN APP DEPOTS / PACKAGES
addappid(680451, 1, "1950c4e3d8f3071f09189b0b380a16839c97922bccc9e5c6df86019426772782")
