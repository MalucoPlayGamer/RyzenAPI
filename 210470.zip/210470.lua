-- Lua provided by RyzenAPI
-- Game: 210470

-- MAIN APPLICATION
addappid(210470)
-- Game: addappid(210470)

-- MAIN APP DEPOTS / PACKAGES
addappid(210471, 1, "8ba9691cd3786a000baf22e5cc9c61f8d69e97a5013f5f44d14902916ab0d3d5")
addappid(210472, 1, "3383639426e1c5d7e82975eed26736d86821f58a8f15de7eaaa1f33e39d4bf8a")
