-- Lua provided by SkyAPI 
-- Game: AppID 1026100
addappid(1026100)
addappid(1026101, 1, "0e651ef543f93586daecdf9c834929cc8f53ffcf3d22d2c4e851452542bfd0a2")
