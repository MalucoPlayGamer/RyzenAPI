-- Lua provided by RyzenAPI
-- Game: Cabin Corpse - Season 1

-- MAIN APPLICATION
addappid(2945200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945201, 1, "9ff44cfd4b2be8d3ecf8630ce173e4b6f9a2765899ffc6df11ead55c2703888c")
