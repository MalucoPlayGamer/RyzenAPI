-- Lua provided by RyzenAPI
-- Game: addappid(1915780)

-- MAIN APPLICATION
addappid(1915780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1915781, 1, "afb71575ff63d18b687e5650c7f57048888c46b8e7e54008790b69dfdce08d3c")
