-- Lua provided by RyzenAPI
-- Game: Enola

-- MAIN APPLICATION
addappid(263520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(263521, 1, "f8a3a84128d9883c35749612ba32c7656dc56d48129b2f992b2f84e173db6fde")
addappid(263522, 1, "a2e2ed74e30e1cac8278fe00f81a48fe396255d772cef32890abd6ba8b07228f")
