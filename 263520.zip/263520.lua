-- Lua provided by RyzenAPI
-- Game: Game: AppID 263520

-- MAIN APPLICATION
addappid(263520)
-- Game: addappid(263520)

-- MAIN APP DEPOTS / PACKAGES
addappid(263521, 1, "f8a3a84128d9883c35749612ba32c7656dc56d48129b2f992b2f84e173db6fde")
addappid(263522, 1, "a2e2ed74e30e1cac8278fe00f81a48fe396255d772cef32890abd6ba8b07228f")
