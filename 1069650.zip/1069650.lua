-- Lua provided by RyzenAPI
-- Game: Ultimate Admiral: Age of Sail

-- MAIN APPLICATION
addappid(1069650)
addappid(1402920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1069651, 1, "7719549bba8ff4e6501860e10ab9a25a9c2c259d09412bda83c23fa82a1b9d87")
