-- Lua provided by RyzenAPI
-- Game: 1069650

-- MAIN APPLICATION
addappid(1069650)
-- Game: addappid(1069650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1069651, 1, "7719549bba8ff4e6501860e10ab9a25a9c2c259d09412bda83c23fa82a1b9d87")
