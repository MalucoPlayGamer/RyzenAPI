-- Lua provided by RyzenAPI
-- Game: Workhard

-- MAIN APPLICATION
addappid(1138280)
-- Game: addappid(1138280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138281, 1, "10f8799b8d7b274b528997ed667c3a80d049978c21c3ce8691524d8c37640112")
