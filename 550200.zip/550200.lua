-- Lua provided by RyzenAPI
-- Game: World Destroyers

-- MAIN APPLICATION
addappid(550200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(550201, 1, "3e213ad14dff1dfe94a9891379ac4e135aac0aa2d6b6021b071400e1c37948ac")

