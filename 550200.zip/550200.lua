-- Lua provided by RyzenAPI
-- Game: Game: World Destroyers

-- MAIN APPLICATION
addappid(550200)
-- Game: addappid(550200)

-- MAIN APP DEPOTS / PACKAGES
addappid(550201, 1, "3e213ad14dff1dfe94a9891379ac4e135aac0aa2d6b6021b071400e1c37948ac")
