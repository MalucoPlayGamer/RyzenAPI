-- Lua provided by RyzenAPI
-- Game: 夏日事件簿 Summer Fantasy Demo

-- MAIN APPLICATION
addappid(2724380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2724381, 1, "30d4089633ab2d466e9b12f4685ce2888fb134190b0b2d142df201a2862c072c")
