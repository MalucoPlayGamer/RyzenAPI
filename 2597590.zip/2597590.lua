-- Lua provided by RyzenAPI
-- Game: 2597590

-- MAIN APPLICATION
addappid(2597590)
-- Game: addappid(2597590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2597591, 1, "cc1f3e3ecccd1b763b7738d4ba82f9daf7a04a5e50309513e976171157502ccf")
