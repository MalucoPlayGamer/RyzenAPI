-- Lua provided by RyzenAPI
-- Game: Game: Firefighters - Airport Heroes

-- MAIN APPLICATION
addappid(1278690)
-- Game: addappid(1278690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1278691, 1, "e8198ddbff22d0795ef8ddd297c88e89667a8eb768e28cbad6f22b9483d73fc4")
