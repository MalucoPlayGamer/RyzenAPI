-- Lua provided by RyzenAPI
-- Game: Claire

-- MAIN APPLICATION
addappid(252830)
-- Game: addappid(252830)

-- MAIN APP DEPOTS / PACKAGES
addappid(252831, 1, "fabf59414795d9e672f1ec401a13126612604cedf672437b5a383488d41a194f")
addappid(252832, 1, "30794a30546dc1f758c16d13f692c9aec9cbab64f47a86d2c0173b1132c3e977")
addappid(326270, 0, "241c03191ecd566a5f6063d9acef4db4bcde099012e2be40c7c5541ef1aae31b")
