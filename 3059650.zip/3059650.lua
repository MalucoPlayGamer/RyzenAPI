-- Lua provided by RyzenAPI
-- Game: ARK: Aberration Ascended

-- MAIN APPLICATION
addappid(3059650)
-- Game: addappid(3059650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3059650,0,"84b1a413568c28ea0226bbd983fbf08741ead907cc7cd9cdd447056405850bd2")
