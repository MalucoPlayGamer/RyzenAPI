-- Lua provided by RyzenAPI
-- Game: AppID 968250

-- MAIN APPLICATION
addappid(968250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(968251, 1, "00a9d01177a0c165234278cc7d4f0552f8e2771d2c76c1b9cd60bcc3c92f13d7")
addappid(968253, 1, "46f30d67a59c1dca52f743ef9ba92a717b43d84c62d5969c2af7ead1750de600")

