-- Lua provided by RyzenAPI
-- Game: Game: AppID 968250

-- MAIN APPLICATION
addappid(968250)
-- Game: addappid(968250)

-- MAIN APP DEPOTS / PACKAGES
addappid(968251, 1, "00a9d01177a0c165234278cc7d4f0552f8e2771d2c76c1b9cd60bcc3c92f13d7")
addappid(968253, 1, "46f30d67a59c1dca52f743ef9ba92a717b43d84c62d5969c2af7ead1750de600")
