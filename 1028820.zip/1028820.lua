-- Lua provided by RyzenAPI
-- Game: Horror Stories

-- MAIN APPLICATION
addappid(1028820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028821, 1, "56d87aaab04b87a2abf13029231c9c169e9236e9879c00165e43620897f7ea29")

