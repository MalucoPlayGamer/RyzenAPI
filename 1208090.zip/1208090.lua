-- Lua provided by RyzenAPI
-- Game: AppID 1208090

-- MAIN APPLICATION
addappid(1208090)
-- Game: addappid(1208090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208091, 1, "a7d24767add86f21f5dce29c6a1c34dc61ed7536b71008bb58db5d2d550777ae")
