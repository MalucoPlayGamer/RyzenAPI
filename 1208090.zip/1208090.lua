-- Lua provided by RyzenAPI
-- Game: Herbalist simulator

-- MAIN APPLICATION
addappid(1208090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(1208091, 1, "a7d24767add86f21f5dce29c6a1c34dc61ed7536b71008bb58db5d2d550777ae")

