-- Lua provided by RyzenAPI
-- Game: setManifestid(2634563,"2658908101831791272")

-- MAIN APPLICATION
addappid(2634560)
-- Game: addappid(2634560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2634563,0,"1910381c1ad39eec875f738f5fa571e58b8c45b2430415b3f9e4af84c70b77bd")
