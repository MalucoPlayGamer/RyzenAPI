-- Lua provided by RyzenAPI
-- Game: Dodecadone

-- MAIN APPLICATION
addappid(2754840)
addappid(2755530)
addappid(2755540)
addappid(2755550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2754841, 1, "95751499cd7ec3c8bcafb52894a9ef226f04b08ffd1a32ebf8ea3c3d0ca8be3e")
addappid(2754842, 1, "2f8129544d3badcd1c47437439bfe385078eff1d37525655532f45cee0828350")

