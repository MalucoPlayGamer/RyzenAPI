-- Lua provided by RyzenAPI
-- Game: 3017170

-- MAIN APPLICATION
addappid(3017170)
-- Game: addappid(3017170)

-- MAIN APP DEPOTS / PACKAGES
addappid(3017171, 1, "9c3c76afecb6ccfdb5a567bfc1a52af0393e6a33ee38a875969c867ce86b1487")
