-- 3963030's Lua and Manifest Created by Hubcap Manifest
-- Pickle Pete
-- Created: August 26, 2026 at 06:36:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3963030) -- Pickle Pete
-- MAIN APP DEPOTS
addappid(3963031, 1, "56713d06c37d88950d6b48d7afa383180e36ce2d8aa6151262dbfb125d0703f6") -- Depot 3963031
setManifestid(3963031, "6104478336000435351", 1503379692)