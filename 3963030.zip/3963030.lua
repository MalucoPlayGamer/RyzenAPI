-- Lua provided by RyzenAPI
-- Game: Pickle Pete

-- MAIN APPLICATION
addappid(3963030) -- Pickle Pete

-- MAIN APP DEPOTS / PACKAGES
addappid(3963031, 1, "56713d06c37d88950d6b48d7afa383180e36ce2d8aa6151262dbfb125d0703f6") -- Depot 3963031

