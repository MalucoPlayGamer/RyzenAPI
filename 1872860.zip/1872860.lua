-- Lua provided by RyzenAPI
-- Game: Conrad Stevenson's Paranormal P.I.

-- MAIN APPLICATION
addappid(1872860)
-- Game: addappid(1872860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1872861, 1, "e88d2ee6d74acd0cb9b064990c77d0fede6d5e6c580f947f3674b85474f1ca70")
