-- Lua provided by RyzenAPI
-- Game: Conrad Stevenson's Paranormal P.I.

-- MAIN APPLICATION
addappid(1872860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1872861, 1, "e88d2ee6d74acd0cb9b064990c77d0fede6d5e6c580f947f3674b85474f1ca70")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
