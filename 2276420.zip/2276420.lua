-- Lua provided by RyzenAPI
-- Game: Songs Of Death

-- MAIN APPLICATION
addappid(2276420)
-- Game: addappid(2276420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2276421, 1, "20144d869bcfc66791106a12b41e85133d532353e83c9132711bf8e22d71cb4a")
