-- Lua provided by RyzenAPI
-- Game: 947310

-- MAIN APPLICATION
addappid(947310)
-- Game: addappid(947310)

-- MAIN APP DEPOTS / PACKAGES
addappid(947311, 1, "be99b2a1705f9b480e63a885d081133ce247731c5d7e412361f0fb97c97f84fb")
addappid(947312, 1, "2dc357852104cdd42d13dd448817e0775ca82fb45d3bba678d6e25f348f5ff1c")
addappid(947313, 1, "e6daee8496d1aa188d9db25080c5ddb2822a6ecc6d1fa785be8c22436d1ca901")
