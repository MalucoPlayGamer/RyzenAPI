-- Lua provided by RyzenAPI
-- Game: Picture Perfect

-- MAIN APPLICATION
addappid(1357670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1357671, 1, "5f94cc6734eabc5f31c44d35b01d9070bf276a962ed454800e832e1cba9ef363")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1475040)
