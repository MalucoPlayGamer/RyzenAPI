-- Lua provided by RyzenAPI
-- Game: Game: I will make you scared of this Red Box.

-- MAIN APPLICATION
addappid(2549940)
-- Game: addappid(2549940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549941, 1, "987427af9395ee37d0f81840098309a904bb162e902923e4649a121e576ba734")
