-- Lua provided by RyzenAPI
-- Game: Desperados: Wanted Dead or Alive

-- MAIN APPLICATION
addappid(260730)
-- Game: addappid(260730)

-- MAIN APP DEPOTS / PACKAGES
addappid(260731, 1, "6e863d81e4d5b29893100c994036a85a336ab55dc4bac7ade46cd04bc760a881")
addappid(260738, 1, "7e6c8a43688173444d17e5fc2b767f1761710865b4506bf9db6f8cb60c87fc4a")
addappid(260739, 1, "49afbafbdedaa17bde2e3430323960006320044fe869a41cbb396234d44dd0d5")
