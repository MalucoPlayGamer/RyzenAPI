-- Lua provided by RyzenAPI
-- Game: AMBUSH tactics

-- MAIN APPLICATION
addappid(709850)
-- Game: addappid(709850)

-- MAIN APP DEPOTS / PACKAGES
addappid(709851, 1, "6cc18f4ecf178607164de888f0d71a6ef72e4ab636d08a9a97ecca320886f5fa")
