-- Lua provided by RyzenAPI
-- Game: AMBUSH tactics

-- MAIN APPLICATION
addappid(709850)

-- MAIN APP DEPOTS / PACKAGES
addappid(709851, 1, "6cc18f4ecf178607164de888f0d71a6ef72e4ab636d08a9a97ecca320886f5fa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
