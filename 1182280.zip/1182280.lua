-- Lua provided by RyzenAPI
-- Game: 1182280

-- MAIN APPLICATION
addappid(1182280)
-- Game: addappid(1182280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182281, 1, "629b82386aa07852f2d380bfff6de92b538df4bf24e17082cef4a99c31f2ac43")
