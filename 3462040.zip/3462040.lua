-- Lua provided by RyzenAPI
-- Game: addappid(3462040)

-- MAIN APPLICATION
addappid(3462040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3462041, 1, "16e9e5bc931adb14e71c3af3fdbecce03840f9ada18f37bd1663235caf622add")
