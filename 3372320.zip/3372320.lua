-- Lua provided by RyzenAPI
-- Game: GROWING LIGHT: FINAL FANTASY XIV Original Soundtrack

-- MAIN APPLICATION
addappid(3372320)
-- Game: addappid(3372320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372321, 1, "c216cb62410d5b9602ebe6e99742d5db16dff3aed6f670b97723c833b3f48b02")
