-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY XVI Original Soundtrack

-- MAIN APPLICATION
addappid(3372350)
-- Game: addappid(3372350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372351, 1, "08563a78682af9b68bfba279c1bbaac0547124141da786614bcbf79d4721dd91")
