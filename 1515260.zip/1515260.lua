-- Lua provided by RyzenAPI
-- Game: Circle Empires Tactics

-- MAIN APPLICATION
addappid(1515260)
-- Game: addappid(1515260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515261, 1, "5d260ec320fdfcf98763f9c347fd0976b37a2288a29eb7740c38051218e21817")
