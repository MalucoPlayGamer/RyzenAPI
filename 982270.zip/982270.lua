-- Lua provided by RyzenAPI 
-- Game: Dealer's Life
addappid(982270)
addappid(982271, 1, "129b5cef312e206020852dbdff46fcfaab7e355107cab4cdb42fd082d8a16de2")
