-- Lua provided by RyzenAPI
-- Game: Dealer's Life

-- MAIN APPLICATION
addappid(982270)
-- Game: addappid(982270)

-- MAIN APP DEPOTS / PACKAGES
addappid(982271, 1, "129b5cef312e206020852dbdff46fcfaab7e355107cab4cdb42fd082d8a16de2")
