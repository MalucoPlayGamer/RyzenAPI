-- Lua provided by RyzenAPI
-- Game: 果宝跑酷: 挑战 Demo

-- MAIN APPLICATION
addappid(3135960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3135961, 1, "9b11ebbf08538b05881c89c61a66b9a365b292237698c9438542fea9d58ffa79")

