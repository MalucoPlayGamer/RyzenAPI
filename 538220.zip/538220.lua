-- Lua provided by RyzenAPI
-- Game: Game: HAUNTED: Halloween '85 (Original NES Game)

-- MAIN APPLICATION
addappid(538220)
-- Game: addappid(538220)

-- MAIN APP DEPOTS / PACKAGES
addappid(538221, 1, "80afda21d4ceae46875fec1a0fcb779ad0f56de7ed37413c13c772398d8df3f5")
