-- Lua provided by RyzenAPI
-- Game: addappid(18600)

-- MAIN APPLICATION
addappid(18600)

-- MAIN APP DEPOTS / PACKAGES
addappid(18601, 1, "9e02a63e27b7c921cb07834e9427f3dfb5f3da65ee4f97b6469173caa6903816")
