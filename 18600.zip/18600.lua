-- Lua provided by RyzenAPI 
-- Game: Mayhem Intergalactic
addappid(18600)
addappid(18601, 1, "9e02a63e27b7c921cb07834e9427f3dfb5f3da65ee4f97b6469173caa6903816")
