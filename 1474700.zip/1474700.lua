-- Lua provided by RyzenAPI
-- Game: addappid(1474700)

-- MAIN APPLICATION
addappid(1474700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1474701, 1, "8e55f8a9c3ab0f703cbf59d9b47e236eb8ddd1fb9771031947974bb1822a2e25")
