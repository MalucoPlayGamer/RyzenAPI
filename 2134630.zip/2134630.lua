-- Lua provided by RyzenAPI
-- Game: Game: Hot Cleopatra

-- MAIN APPLICATION
addappid(2134630)
addappid(2168910)
-- Game: addappid(2134630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2134631, 1, "9a9e80ab458007419a51474d1083f68a1d33fd8a3b59af1b708e6884aa996a0d")
