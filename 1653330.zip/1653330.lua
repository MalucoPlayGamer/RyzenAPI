-- Lua provided by RyzenAPI
-- Game: Game: Sensual Adventures - Episode 6

-- MAIN APPLICATION
addappid(1653330)
-- Game: addappid(1653330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653331, 1, "d2d6655fc8ffa574f747e805bc79787982fb2cb1eadb92f5d9794d596a569353")
