-- Lua provided by RyzenAPI
-- Game: Rent's Due: The Game

-- MAIN APPLICATION
addappid(1678520)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1678521, 1, "2d2168fa677af58ad1dd851c96784207a0f2aa93596458a89428dfba1c081601")

