-- Lua provided by RyzenAPI
-- Game: Rent's Due: The Game

-- MAIN APPLICATION
addappid(1678520)
-- Game: addappid(1678520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1678521, 1, "2d2168fa677af58ad1dd851c96784207a0f2aa93596458a89428dfba1c081601")
