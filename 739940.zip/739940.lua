-- Lua provided by RyzenAPI
-- Game: Guide The Ball

-- MAIN APPLICATION
addappid(739940)

-- MAIN APP DEPOTS / PACKAGES
addappid(739941,0,"cdf1986ae9054ae6d73dc356f37a4b510181f4e99f683796da49ccddb9451506")

