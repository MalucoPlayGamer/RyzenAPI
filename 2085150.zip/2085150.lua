-- Lua provided by RyzenAPI
-- Game: Darfall Demo

-- MAIN APPLICATION
addappid(2085150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085153,0,"637284f6089627e3d19708833d235d5898d2fd3e5db815666dd55372ba0adbeb")

