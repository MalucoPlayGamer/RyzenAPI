-- Lua provided by RyzenAPI
-- Game: addappid(418940)

-- MAIN APPLICATION
addappid(418940)

-- MAIN APP DEPOTS / PACKAGES
addappid(418942,0,"6d699cd261bea36129a784e1ecd494ef412277704f7dc8fa6b9f39ecae9b9797")
