-- Lua provided by SkyAPI 
-- Game: CRAFTSMAN
addappid(1565910)
addappid(1565911, 1, "e524c166360ade2a92224e010263ee5504d2b027ce6b0f863557272727f2fb76")
