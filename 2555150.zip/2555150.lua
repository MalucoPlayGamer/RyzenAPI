-- Lua provided by RyzenAPI
-- Game: Harem in Another World Demo

-- MAIN APPLICATION
addappid(2555150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2555151, 1, "ba20177af7b3f779dd1a1c5a6b4ede5df8b02095893db8f87986cfa8c80a27e8")
