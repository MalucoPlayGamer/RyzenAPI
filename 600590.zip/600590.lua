-- Lua provided by RyzenAPI
-- Game: 600590

-- MAIN APPLICATION
addappid(600590)
addappid(600593)
-- Game: addappid(600590)

-- MAIN APP DEPOTS / PACKAGES
addappid(600590,0,"6c17e869a165679532f82ff237d8abf19709ce2be903a36076c066bb2217b749")
