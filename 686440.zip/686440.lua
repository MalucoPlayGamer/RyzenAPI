-- Lua provided by RyzenAPI 
-- Game: Hard Time
addappid(686440)
addappid(686441, 1, "e934d69293f53ab13b02ea4a4da2081a7ff0382563e8edc4ba07016c45ef16fe")
