-- Lua provided by RyzenAPI
-- Game: addappid(3341060)

-- MAIN APPLICATION
addappid(3341060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3341061, 1, "8539113e3ba54f714243cb33f2ea1bf1590fb5a20387a503a6aba8910882bf80")
