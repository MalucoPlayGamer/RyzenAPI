-- Lua provided by RyzenAPI
-- Game: 587520

-- MAIN APPLICATION
addappid(587520)
-- Game: addappid(587520)

-- MAIN APP DEPOTS / PACKAGES
addappid(587521, 1, "ee8e7a21188c93683f88190fc1dc1d581d355fe1cec23ac1ac7952be35c47ed6")
