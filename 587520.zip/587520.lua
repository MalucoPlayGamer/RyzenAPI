-- Lua provided by RyzenAPI
-- Game: Dungeons of Sundaria

-- MAIN APPLICATION
addappid(587520)

-- MAIN APP DEPOTS / PACKAGES
addappid(587521, 1, "ee8e7a21188c93683f88190fc1dc1d581d355fe1cec23ac1ac7952be35c47ed6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
