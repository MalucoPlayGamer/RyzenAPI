-- Lua provided by RyzenAPI
-- Game: Still Wakes the Deep Soundtrack

-- MAIN APPLICATION
addappid(3049220)
-- Game: addappid(3049220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3049221, 1, "1f66a38b45b3fe780abd8b7af37186321ad20209f8ce66f21af9329e5f330210")
