-- Lua provided by RyzenAPI
-- Game: Once in Yaissor

-- MAIN APPLICATION
addappid(553790)

-- MAIN APP DEPOTS / PACKAGES
addappid(553791, 1, "9f53a9d2d30728da43a3e58a41d4a202fa9bb64b450abc3b082eac092523737f")
