-- Lua provided by SkyAPI 
-- Game: Once in Yaissor
addappid(553790)
addappid(553791, 1, "9f53a9d2d30728da43a3e58a41d4a202fa9bb64b450abc3b082eac092523737f")
