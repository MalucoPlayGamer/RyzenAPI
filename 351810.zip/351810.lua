-- Lua provided by SkyAPI 
-- Game: MadSpace: To Hell and Beyond
addappid(351810)
addappid(351811, 1, "a149e40dc1af433f4babd9220e8889abd7da19f92dfd4b9f56f4cc2a66d49360")
addappid(351812, 1, "080e3b086a2c9f6ef100fd459528326795c90e577c76d0739eed6465c0e9c2d9")
addappid(351814, 1, "c6dbfc49e9597eb4b34cba1240723fe0398e0111c825e984ebfab22f4d98c4e1")
addappid(351816, 1, "ba10f40d0fb19875e9fb0288f456e7a24bc4011909a72f4af57f9658ba2bbd5e")
