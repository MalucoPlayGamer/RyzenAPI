-- Lua provided by RyzenAPI
-- Game: 2402790

-- MAIN APPLICATION
addappid(2402790)
-- Game: addappid(2402790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2402791, 1, "bcf1eacfe8d94eeed052d805ef1415aa21577b13e44228f54818d4c80e223eeb")
