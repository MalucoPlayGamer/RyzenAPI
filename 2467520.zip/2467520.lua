-- Lua provided by RyzenAPI
-- Game: addappid(2467520)

-- MAIN APPLICATION
addappid(2467520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2467521, 1, "7a75c5896192546bdd27c8f9ddf81fe24a4cf7b0b9089f0df0dd17ce16d69fef")
