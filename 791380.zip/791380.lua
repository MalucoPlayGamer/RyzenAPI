-- Lua provided by RyzenAPI
-- Game: 791380

-- MAIN APPLICATION
addappid(791380)
-- Game: addappid(791380)

-- MAIN APP DEPOTS / PACKAGES
addappid(791381, 1, "7cc29675c9cfd5c4ce44d1ccebaf62c879d50969df85544b711409a0de1206d8")
