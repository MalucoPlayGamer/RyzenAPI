-- Lua provided by SkyAPI 
-- Game: Moto Racer Collection
addappid(324110)
addappid(324111, 1, "01caa53ada21155ce02affb4e4d9181fdaa26d2df2566399559671a7632c3b95")
