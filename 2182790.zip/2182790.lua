-- Lua provided by RyzenAPI
-- Game: Riff XR

-- MAIN APPLICATION
addappid(2182790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2182791, 1, "0aa7274b69bae3fe451c7ca0101244ea8ae302b7c88ef74123290e899fd0bc0f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
