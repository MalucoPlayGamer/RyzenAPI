-- Lua provided by RyzenAPI
-- Game: Riff XR

-- MAIN APPLICATION
addappid(2182790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2182791, 1, "0aa7274b69bae3fe451c7ca0101244ea8ae302b7c88ef74123290e899fd0bc0f")
