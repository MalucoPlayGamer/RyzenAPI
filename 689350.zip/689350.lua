-- Lua provided by RyzenAPI 
-- Game: AppID 689350
addappid(689350)
addappid(689351, 1, "888ba064cbee302081d4a8d3dd00f3d1162fcb3fe2c82ff6b261c684ac2dd645")
