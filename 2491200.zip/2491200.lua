-- Lua provided by RyzenAPI
-- Game: 2491200

-- MAIN APPLICATION
addappid(2491200)
-- Game: addappid(2491200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2491201, 1, "d6f60dbaac3e6c1276a89f86681d1a3515b92b23be7b9e9db4c099e8cab85349")
