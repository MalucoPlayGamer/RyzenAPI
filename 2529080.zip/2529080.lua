-- Lua provided by RyzenAPI 
-- Game: Stellar Initiative
addappid(2529080)
addappid(2529081, 1, "1ef333f095bf09262912946941da1bd272c50b0ae91d1e16bbff6bf7a10912ad")
