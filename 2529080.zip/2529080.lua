-- Lua provided by RyzenAPI
-- Game: Game: Stellar Initiative

-- MAIN APPLICATION
addappid(2529080)
-- Game: addappid(2529080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2529081, 1, "1ef333f095bf09262912946941da1bd272c50b0ae91d1e16bbff6bf7a10912ad")
