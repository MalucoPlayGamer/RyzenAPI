-- Lua provided by RyzenAPI
-- Game: 1060220

-- MAIN APPLICATION
addappid(1060220)
-- Game: addappid(1060220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1060221, 1, "b77999544d6ac2ca6c0a643a0edb7b6b6860a569b70c88486826bf9092be691c")
