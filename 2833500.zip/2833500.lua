-- Lua provided by SkyAPI 
-- Game: AppID 2833500
addappid(2833500)
addappid(2833501, 1, "bd34baa853a51e1be7e3c2e0e71dac6c9a42e5ffff70cc5457d58548e9efcf02")
