-- Lua provided by RyzenAPI
-- Game: 血之诗: 月之蚀 Demo

-- MAIN APPLICATION
addappid(2833500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2833501, 1, "bd34baa853a51e1be7e3c2e0e71dac6c9a42e5ffff70cc5457d58548e9efcf02")

