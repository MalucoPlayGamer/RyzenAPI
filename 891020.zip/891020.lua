-- Lua provided by RyzenAPI
-- Game: AppID 891020

-- MAIN APPLICATION
addappid(891020)

-- MAIN APP DEPOTS / PACKAGES
addappid(891021, 1, "a55007ebc88b7d39265aa7092df76553eab10407d92808094204609e28ab1bd2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
