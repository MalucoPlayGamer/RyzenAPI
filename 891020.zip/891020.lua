-- Lua provided by RyzenAPI
-- Game: AppID 891020

-- MAIN APPLICATION
addappid(891020)
-- Game: addappid(891020)

-- MAIN APP DEPOTS / PACKAGES
addappid(891021, 1, "a55007ebc88b7d39265aa7092df76553eab10407d92808094204609e28ab1bd2")
