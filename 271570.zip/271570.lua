-- Lua provided by RyzenAPI
-- Game: Space Farmers

-- MAIN APPLICATION
addappid(271570)
-- Game: addappid(271570)

-- MAIN APP DEPOTS / PACKAGES
addappid(271571, 1, "06fd0c12300cde031556c0a42d9919ebbb5b341c4376847822d7763f234810b8")
addappid(271572, 1, "324499520c51387f3487eaa01a1893471931cc3cc018c4f32c3432bc828c86fb")
addappid(271573, 1, "48fe4ed6ea9488f82f270c2fd3f7fc549ef02a302a3dd7e2dca3316bd1aa9c4a")
