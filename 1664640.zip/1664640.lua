-- Lua provided by RyzenAPI
-- Game: Game: Highrise City Demo

-- MAIN APPLICATION
addappid(1664640)
-- Game: addappid(1664640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1664641, 1, "105b5dab426712ecd5a2720b712b9639e41c5f6a38f5c206037577480330d82c")
