-- Lua provided by RyzenAPI 
-- Game: Against All Odds
addappid(1465560)
addappid(1465561, 1, "a20022d44b370ca72894733bb667bd86d5b65a37f908d66bbea4b1b2dc9375fd")
