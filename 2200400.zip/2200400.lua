-- Lua provided by RyzenAPI
-- Game: addappid(2200400)

-- MAIN APPLICATION
addappid(2200400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2200401, 1, "e1bbd167b69fbe5e6bcc8c27b3db3dfb9bf235a463cac9fa340df9d81a6d6c75")
