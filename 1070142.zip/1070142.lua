-- Lua provided by RyzenAPI
-- Game: 1070142

-- MAIN APPLICATION
addappid(1070142)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070142,0,"05ba6e2dc5eaff2400d5eaa5a54a6950c19852ceff7eb90251687bb9f9ac13c0")
