-- Lua provided by RyzenAPI
-- Game: addappid(1813860)

-- MAIN APPLICATION
addappid(1813860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813865,0,"71b9effbd1a9b7d7659cc1836ee86610b9619bef45a1dffc21b68a39f4e0c220")
