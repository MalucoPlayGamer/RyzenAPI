-- Lua provided by SkyAPI 
-- Game: AppID 771130
addappid(771130)
addappid(771131, 1, "db2f68b14dfc34299f93f6317f7e478270e21512db52211526cfe6dd5e334e83")
addappid(771132, 1, "86ec54ac2571ace1e6dae09a9d699bbcbce5c23e781ae48ea23b216ddddbc839")
addappid(771133, 1, "199f0cd9c6665d228c20f41f0a25bf874285dc6c217fa6809d177c53b392c14e")
