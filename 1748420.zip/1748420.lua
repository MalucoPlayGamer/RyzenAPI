-- Lua provided by RyzenAPI
-- Game: 1748420

-- MAIN APPLICATION
addappid(1748420)
-- Game: addappid(1748420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397392,0,"d0d92dae796cdbdb47de6b3d30879a3791866a281b5c2ccf5da7c90033324fc6")
