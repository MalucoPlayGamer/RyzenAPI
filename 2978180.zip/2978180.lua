-- Lua provided by RyzenAPI
-- Game: 2978180

-- MAIN APPLICATION
addappid(2978180)
-- Game: addappid(2978180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2978182,0,"d6bea2a0a1765210588d094e276e30ae626646e06aff410a036627892aeb5ceb")
