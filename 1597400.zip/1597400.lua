-- Lua provided by RyzenAPI
-- Game: 1597400

-- MAIN APPLICATION
addappid(1597400)
-- Game: addappid(1597400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1597401, 1, "16ad65591ae671bc4b2a6c239fe5f377e79a513ea8f7ae44d57cb526c1637e72")
