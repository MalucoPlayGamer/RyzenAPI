-- Lua provided by SkyAPI 
-- Game: LOST EGG 2: Be together
addappid(1597400)
addappid(1597401, 1, "16ad65591ae671bc4b2a6c239fe5f377e79a513ea8f7ae44d57cb526c1637e72")
