-- Lua provided by RyzenAPI
-- Game: AppID 963710

-- MAIN APPLICATION
addappid(963710)
addappid(977000)
-- Game: addappid(963710)

-- MAIN APP DEPOTS / PACKAGES
addappid(963711, 1, "1c13acd5a111a666094f69755f771fe223bfbdbf84b01cd4505997928d102ad2")
