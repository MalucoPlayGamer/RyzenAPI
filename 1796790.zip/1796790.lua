-- Lua provided by RyzenAPI
-- Game: Chef RPG

-- MAIN APPLICATION
addappid(1796790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796792,0,"0b0dba64aab4ff027e61e09957f6e9dba4ea9bc96857960210bcec88932b2f43")
addappid(1796793,0,"fcf628f7613f3cceda7b6b27311bbbd15869f67443d18dccb2815b14c2ccb902")
