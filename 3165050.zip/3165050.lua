-- 3165050's Lua and Manifest Created by Hubcap Manifest
-- Outclaw
-- Created: July 30, 2026 at 14:21:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3165050) -- Outclaw
-- MAIN APP DEPOTS
addappid(3165051, 1, "06a5dc425f0fd60881a0d86c557c5f09f2ed31bed4453dbd13077ccd27c74cae") -- Depot 3165051
setManifestid(3165051, "2526407507927475436", 4237925820)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)