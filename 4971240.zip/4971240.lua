-- Lua provided by RyzenAPI
-- Game: Warden of the Sunken Keep

-- MAIN APPLICATION
addappid(4971240) -- Warden of the Sunken Keep

-- MAIN APP DEPOTS / PACKAGES
addappid(4971241, 1, "434ef906d5d3d61499e26233f5df24b69f5fe4a3a778e0993ed506b69915f2cd") -- Depot 4971241

