-- Lua provided by RyzenAPI
-- Game: addappid(751440)

-- MAIN APPLICATION
addappid(751440)

-- MAIN APP DEPOTS / PACKAGES
addappid(751441, 1, "e82f25c0d19ad1aaba95b1d8051bf45163dc0430be1f0bb6bc5c7f44615c166b")
