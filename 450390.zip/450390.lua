-- Lua provided by RyzenAPI
-- Game: addappid(450390)

-- MAIN APPLICATION
addappid(450390)

-- MAIN APP DEPOTS / PACKAGES
addappid(450391, 1, "d578022b01a2c3165dccff8659e185336df15fbcda2d1ed67c79a7340533fe75")
