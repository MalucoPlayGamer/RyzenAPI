-- Lua provided by RyzenAPI
-- Game: addappid(2282330)

-- MAIN APPLICATION
addappid(2282330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2282331, 1, "7b7cb62b0c46e4d075d6a7c8f63c01fb7e093ddfd40e578ca390617d50df3fb4")
