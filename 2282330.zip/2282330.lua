-- Lua provided by SkyAPI 
-- Game: AppID 2282330
addappid(2282330)
addappid(2282331, 1, "7b7cb62b0c46e4d075d6a7c8f63c01fb7e093ddfd40e578ca390617d50df3fb4")
