-- Lua provided by RyzenAPI
-- Game: Hmmsim Metro

-- MAIN APPLICATION
addappid(1591420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1591421, 1, "aafd3273eba85d9340aa81bc0c4396af94e76ae131b05956834369742364bafc")

