-- Lua provided by RyzenAPI
-- Game: addappid(711860)

-- MAIN APPLICATION
addappid(711860)

-- MAIN APP DEPOTS / PACKAGES
addappid(711860,0,"ac4c68f5717ac741c29bd86da0a0bfc29cd313ba005e2169605b68f574d5d1a6")
