-- Lua provided by RyzenAPI
-- Game: Earthtongue

-- MAIN APPLICATION
addappid(358070)
addappid(367150)

-- MAIN APP DEPOTS / PACKAGES
addappid(358071, 1, "bc2fe13f785ba97746e7d1c9fa9504b628dc8f6ad7a35a401715c1c98c617b2b")

