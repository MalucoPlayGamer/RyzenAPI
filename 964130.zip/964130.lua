-- Lua provided by RyzenAPI
-- Game: My Colony

-- MAIN APPLICATION
addappid(964130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(964131, 1, "731a55ee84cb9bbc0cbb1bf0b42ef40f04b8dce13a3e829e49f48ec4bee2c026")

