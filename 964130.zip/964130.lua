-- Lua provided by RyzenAPI
-- Game: 964130

-- MAIN APPLICATION
addappid(964130)
-- Game: addappid(964130)

-- MAIN APP DEPOTS / PACKAGES
addappid(964131, 1, "731a55ee84cb9bbc0cbb1bf0b42ef40f04b8dce13a3e829e49f48ec4bee2c026")
