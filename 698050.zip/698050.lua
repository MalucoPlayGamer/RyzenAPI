-- Lua provided by RyzenAPI
-- Game: All Our Asias

-- MAIN APPLICATION
addappid(698050)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(769140)
