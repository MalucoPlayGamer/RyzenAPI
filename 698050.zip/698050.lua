-- Lua provided by RyzenAPI
-- Game: All Our Asias

-- MAIN APPLICATION
addappid(698050)
addappid(769140)

