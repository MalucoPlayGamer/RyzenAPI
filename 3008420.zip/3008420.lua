-- Lua provided by RyzenAPI 
-- Game: AppID 3008420
addappid(3008420)
addappid(3008421, 1, "5544f315c73f239737e6dffe605b67853ebf091d9f15c0a3c08d46b2eb140aa5")
