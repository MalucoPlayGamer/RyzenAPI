-- Lua provided by RyzenAPI
-- Game: Jacktus Green: The Fluffy, the Spiky and the Spicy

-- MAIN APPLICATION
addappid(1986770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986771, 1, "d0516931d93ee5f2f3bf3185f533659545159ddaa8fb838be17385657c07007d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
