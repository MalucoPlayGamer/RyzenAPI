-- Lua provided by RyzenAPI
-- Game: Jacktus Green: The Fluffy, the Spiky and the Spicy

-- MAIN APPLICATION
addappid(1986770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986771, 1, "d0516931d93ee5f2f3bf3185f533659545159ddaa8fb838be17385657c07007d")

