-- Lua provided by RyzenAPI
-- Game: Adventure Story

-- MAIN APPLICATION
addappid(2547510)
addappid(2547511)
-- Game: addappid(2547510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2547512,0,"592b0cf0914370a3d69d6d84c8137c857bbfcb8f699285fe81481a67339679c5")
