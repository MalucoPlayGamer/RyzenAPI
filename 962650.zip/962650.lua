-- Lua provided by RyzenAPI
-- Game: Game: Paroniria 梦缚

-- MAIN APPLICATION
addappid(962650)
-- Game: addappid(962650)

-- MAIN APP DEPOTS / PACKAGES
addappid(962651, 1, "705fd0ec60497ebf4b03c65cd99e4bc34ea27bb01b04dba7a7c0f80453c9c9f5")
