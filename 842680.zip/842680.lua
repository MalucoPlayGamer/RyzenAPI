-- Lua provided by RyzenAPI
-- Game: CPUCores :: ClearMem Lite

-- MAIN APPLICATION
addappid(842680)

-- MAIN APP DEPOTS / PACKAGES
addappid(842680,0,"2d8007d70801073d8c5222c47a85bb5cc1d51f4f3d6b60b863c50a069d233b28")
