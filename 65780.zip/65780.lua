-- Lua provided by RyzenAPI
-- Game: addappid(65780)

-- MAIN APPLICATION
addappid(65780)

-- MAIN APP DEPOTS / PACKAGES
addappid(65781, 1, "847f8fee18b674905052ad492e0269c17993b2271d434cd2c33d7880ab2ea1cc")
