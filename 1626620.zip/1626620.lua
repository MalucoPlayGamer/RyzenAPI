-- Lua provided by RyzenAPI
-- Game: Koira

-- MAIN APPLICATION
addappid(1626620)
addappid(3602300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1626622,0,"2dde08ba13fea4295ac7843ea72319b9aee0c322b50e94f82a7104ef7d242dea")

