-- Lua provided by RyzenAPI
-- Game: Backswamp Demo

-- MAIN APPLICATION
addappid(2631930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631931, 1, "46603071a095744a080bae848869fa14245d8a4eb264a36b4c5dcd3bfe8b50a7")

