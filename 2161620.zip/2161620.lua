-- Lua provided by RyzenAPI
-- Game: 2161620

-- MAIN APPLICATION
addappid(2161620)
-- Game: addappid(2161620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2161621, 1, "6b24fc186c09fd39d371180a7f89c80237373c2bd7feee4543ff631e0f799325")
