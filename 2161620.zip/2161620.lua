-- Lua provided by SkyAPI 
-- Game: Lysfanga: The Time Shift Warrior
addappid(2161620)
addappid(2161621, 1, "6b24fc186c09fd39d371180a7f89c80237373c2bd7feee4543ff631e0f799325")
