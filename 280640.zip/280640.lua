-- Lua provided by RyzenAPI
-- Game: Dark Shadows - Army of Evil

-- MAIN APPLICATION
addappid(280640)

-- MAIN APP DEPOTS / PACKAGES
addappid(280641, 1, "ee51d5731a23636664540f1b68689d8794e6450e00f24ed839483669db033ede")

