-- Lua provided by RyzenAPI
-- Game: FUSER™ - Schoolboy Q - "Man of the Year"

-- MAIN APPLICATION
addappid(1432169)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432169,0,"82eed6d12fdef1d0a780e9624a5fd474d618112b2c79c57e110ad9ece66ad05a")

