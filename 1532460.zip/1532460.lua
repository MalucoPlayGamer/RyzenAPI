-- Lua provided by RyzenAPI
-- Game: The Fridge is Red

-- MAIN APPLICATION
addappid(1532460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532461, 1, "64352555846e0e06a68617151fa193cc19b91662ff9c2ff895149691fe8a4217")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
