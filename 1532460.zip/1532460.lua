-- Lua provided by RyzenAPI
-- Game: The Fridge is Red

-- MAIN APPLICATION
addappid(1532460)
-- Game: addappid(1532460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1532461, 1, "64352555846e0e06a68617151fa193cc19b91662ff9c2ff895149691fe8a4217")
