-- Lua provided by SkyAPI 
-- Game: WrestleQuest Demo
addappid(1998210)
addappid(1998211, 1, "b07fe61e82c1e752bb2a3ce70d8eb70722d89e24c31431e128e4faeafe6ce11f")
