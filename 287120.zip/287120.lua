-- Lua provided by RyzenAPI
-- Game: Ionball 2: Ionstorm

-- MAIN APPLICATION
addappid(287120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(287121, 1, "822135510b464df98baaffd5704ec05e8e131fda7e862b7826fc7962704b3c88")

