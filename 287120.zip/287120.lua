-- Lua provided by RyzenAPI
-- Game: Game: Ionball 2: Ionstorm

-- MAIN APPLICATION
addappid(287120)
-- Game: addappid(287120)

-- MAIN APP DEPOTS / PACKAGES
addappid(287121, 1, "822135510b464df98baaffd5704ec05e8e131fda7e862b7826fc7962704b3c88")
