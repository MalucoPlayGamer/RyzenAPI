-- Lua provided by RyzenAPI
-- Game: STRIDER™ / ストライダー飛竜®

-- MAIN APPLICATION
addappid(228983)
addappid(235210)

-- MAIN APP DEPOTS / PACKAGES
addappid(235212,0,"f6d661cba339f2c874731a36916f13b62cdd6c17a99cde94fa5decb56e7d3b95")
