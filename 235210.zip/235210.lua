-- Lua provided by RyzenAPI
-- Game: STRIDER™ / ストライダー飛竜®

-- MAIN APPLICATION
addappid(228983)
addappid(235210)
addappid(278610)
addappid(278611)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(235212,0,"f6d661cba339f2c874731a36916f13b62cdd6c17a99cde94fa5decb56e7d3b95")

