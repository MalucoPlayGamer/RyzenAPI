-- Lua provided by RyzenAPI
-- Game: Rebellion: The Beginning

-- MAIN APPLICATION
addappid(2549760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2549761, 1, "81ec84d7560761d69a91b7d3391502b5d7480c569b9bfdce027fea1a54a8772d")

