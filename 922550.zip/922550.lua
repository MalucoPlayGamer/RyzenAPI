-- Lua provided by RyzenAPI
-- Game: keyg: the last prison

-- MAIN APPLICATION
addappid(922550)

-- MAIN APP DEPOTS / PACKAGES
addappid(922551, 1, "4ff6c7f19c10994f3b97f24c19223bf2ff7e293861f74e4ae536aa251c00c291")
addappid(922552, 1, "5020ad37b5b4454135aac544aa3df60b2566ab83193f47622bd0845c0353e8d1")
addappid(922553, 1, "205ee4ce69d3c35f0498a786e836fc06f01b5c91bf3270d3cf868bac31809fe6")
