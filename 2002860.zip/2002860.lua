-- Lua provided by RyzenAPI
-- Game: Raiden III x MIKADO MANIAX

-- MAIN APPLICATION
addappid(2002860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2002861, 1, "b4b4f932cb464b9cf13d3865776db88a661199a156c6971d6ac74c56b94d847b")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2366840)
