-- Lua provided by RyzenAPI
-- Game: King’s Well

-- MAIN APPLICATION
addappid(4332200) -- King’s Well

-- MAIN APP DEPOTS / PACKAGES
addappid(4332201, 1, "e2081bb22969abefe0437b066aa98ba18cf1cee504ec344cbc1cb8b1621794d1") -- Depot 4332201
addappid(4332202, 1, "9643302e27ce278597c33550db6f6df522222b714e9da373f1a18edb147908d3") -- Depot 4332202

