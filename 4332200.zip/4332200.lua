-- 4332200's Lua and Manifest Created by Hubcap Manifest
-- King’s Well
-- Created: August 12, 2026 at 09:12:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4332200) -- King’s Well
-- MAIN APP DEPOTS
addappid(4332201, 1, "e2081bb22969abefe0437b066aa98ba18cf1cee504ec344cbc1cb8b1621794d1") -- Depot 4332201
setManifestid(4332201, "8298612992710742888", 1630696352)
addappid(4332202, 1, "9643302e27ce278597c33550db6f6df522222b714e9da373f1a18edb147908d3") -- Depot 4332202
setManifestid(4332202, "8545147026521263485", 1713369876)