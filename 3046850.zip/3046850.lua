-- Lua provided by RyzenAPI
-- Game: Candy Golf

-- MAIN APPLICATION
addappid(3046850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3046851, 1, "3df5131757399c38e2f740be63c716c5ea1339938f7de9e80e681de8fd9d4c6f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
