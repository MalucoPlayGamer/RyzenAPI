-- Lua provided by RyzenAPI
-- Game: Game: Candy Golf

-- MAIN APPLICATION
addappid(3046850)
-- Game: addappid(3046850)

-- MAIN APP DEPOTS / PACKAGES
addappid(3046851, 1, "3df5131757399c38e2f740be63c716c5ea1339938f7de9e80e681de8fd9d4c6f")
