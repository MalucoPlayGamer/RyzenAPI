-- Lua provided by RyzenAPI 
-- Game: Trash is Fun
addappid(1671310)
addappid(1671311, 1, "4d99969cc85816897beee52913c4673c2b434bf96aba70b1437326de06cdb075")
