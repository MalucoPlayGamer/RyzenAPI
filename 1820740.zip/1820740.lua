-- Lua provided by SkyAPI 
-- Game: AppID 1820740
addappid(1820740)
addappid(1820741, 1, "cda0dcb497009697817ccda0a18588656fa3dab1e11ed06eae5f39b12fc4a8a8")
