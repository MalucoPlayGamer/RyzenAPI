-- Lua provided by RyzenAPI
-- Game: Game: AppID 1820740

-- MAIN APPLICATION
addappid(1820740)
-- Game: addappid(1820740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1820741, 1, "cda0dcb497009697817ccda0a18588656fa3dab1e11ed06eae5f39b12fc4a8a8")
