-- Lua provided by RyzenAPI
-- Game: akabos

-- MAIN APPLICATION
addappid(3294950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3294951, 1, "9d3a09f3970ee3a4edaced1990d423ac34d553a96ffb0c42ce0b029753ec65d8")

