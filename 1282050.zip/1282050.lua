-- Lua provided by RyzenAPI
-- Game: Tabletop Playground Beta

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(1282050)
addappid(1282051)
-- Game: addappid(1282050)

-- MAIN APP DEPOTS / PACKAGES
addappid(838411,0,"dbdc004cf38063713442eb653ef701651ec5491c2d31db24a137e65ae9a8b2d3")
