-- Lua provided by RyzenAPI
-- Game: Реальная Смута

-- MAIN APPLICATION
addappid(2982290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2982291, 1, "7a31332e61469ecb4a2623df63976284a220a2672fd11585143406616fea7ccf")

