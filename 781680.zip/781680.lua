-- Lua provided by RyzenAPI
-- Game: In Darkness

-- MAIN APPLICATION
addappid(781680)
-- Game: addappid(781680)

-- MAIN APP DEPOTS / PACKAGES
addappid(781681, 1, "fa2df36ea2c1c2b7f178498fa8e3e8ad2b4377e81b4c13e952d44594870e7d82")
