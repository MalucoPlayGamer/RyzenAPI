-- Lua provided by RyzenAPI
-- Game: Styx: Blades of Greed

-- MAIN APPLICATION
addappid(3757150) -- Styx: Blades of Greed - Master of Shadows Skin
addappid(3757160) -- Styx: Blades of Greed - Greedy Skin Pack
addappid(3939870) -- Styx: Blades of Greed - Legacy Skin Pack
addappid(3939890) -- Styx: Blades of Greed - Weapon Pack
addappid(4165560) -- Styx: Blades of Greed - Starter Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3290690, 1, "8db17876ed89eb1e8d2543973762172df332711d3c931f3d1219e48389ffa190")
addappid(3290691, 1, "23315be11cd78921beaf6790cba7f22c06698680059f9bf78dbf2105c0426d2f") -- (windows, 64-bit)

