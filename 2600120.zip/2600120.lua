-- Lua provided by RyzenAPI
-- Game: Game: AppID 2600120

-- MAIN APPLICATION
addappid(2600120)
-- Game: addappid(2600120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2600121, 1, "f49c54a8cc4383b7040058b583790797aa8cfbb895bf38f0a92434007d78e69f")
