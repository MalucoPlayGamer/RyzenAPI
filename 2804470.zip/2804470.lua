-- Lua provided by RyzenAPI
-- Game: Game: 灵境 Playtest

-- MAIN APPLICATION
addappid(2804470)
-- Game: addappid(2804470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804471, 1, "d533e92f09f81246cb924f61d132ee7847b456c8f5acddf09b75b5ae31d6ad3f")
