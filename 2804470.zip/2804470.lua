-- Lua provided by SkyAPI 
-- Game: 灵境 Playtest
addappid(2804470)
addappid(2804471, 1, "d533e92f09f81246cb924f61d132ee7847b456c8f5acddf09b75b5ae31d6ad3f")
