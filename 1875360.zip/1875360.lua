-- Lua provided by RyzenAPI
-- Game: Off-Road Farming

-- MAIN APPLICATION
addappid(1875360)
-- Game: addappid(1875360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1875361, 1, "db2d305832342d15853620c213b6250ba82059baac3499c082746df45f8a998e")
