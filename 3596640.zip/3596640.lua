-- Lua provided by RyzenAPI
-- Game: Game: AppID 3596640

-- MAIN APPLICATION
addappid(3596640)
-- Game: addappid(3596640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3596641, 1, "995cadfad7e7320cf61b8bdc6f9907757cc2704562bd3b5ff703b57627d7fb76")
