-- Lua provided by RyzenAPI
-- Game: Awakening: The Golden Age Collector's Edition

-- MAIN APPLICATION
addappid(586680)

-- MAIN APP DEPOTS / PACKAGES
addappid(586681,0,"f199f4db80c328acbc416115f3e61a272d2b485f4613aa778b9a72cc07b69b03")

