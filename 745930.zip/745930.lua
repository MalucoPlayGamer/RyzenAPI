-- Lua provided by RyzenAPI
-- Game: 745930

-- MAIN APPLICATION
addappid(745930)
-- Game: addappid(745930)

-- MAIN APP DEPOTS / PACKAGES
addappid(745931, 1, "f97c92d6a447160bce9ed3c8af76643adc142a46a1539297a240333ff971ad36")
