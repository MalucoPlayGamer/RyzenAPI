-- Lua provided by RyzenAPI
-- Game: AppID 2613460

-- MAIN APPLICATION
addappid(2613460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2613461, 1, "e1f7d4c1917fde2ad977efd72318dab70e267dd547e470d838eade78dd46bc84")

