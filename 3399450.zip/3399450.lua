-- Lua provided by RyzenAPI
-- Game: addappid(3399450)

-- MAIN APPLICATION
addappid(3399450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3399451, 1, "77fc07cf815274bb5488f717bef898b48d14d3144441905bdccdfd0b98c7642c")
