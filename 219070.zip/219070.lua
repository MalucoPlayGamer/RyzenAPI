-- Lua provided by RyzenAPI
-- Game: Miner Wars Arena

-- MAIN APPLICATION
addappid(219070)

-- MAIN APP DEPOTS / PACKAGES
addappid(219071, 1, "8422d50cebf66fd638b6ee871c70432c948fa5cc91a6f38872661959d6c1fdc2")
addappid(219072, 1, "c82b1476b8859218c0420332685a74771f070e0b9ddb6bad6cd4e6369c4de8bb")
