-- Lua provided by RyzenAPI
-- Game: Voyager-19

-- MAIN APPLICATION
addappid(2925510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2925511, 1, "04f4d3ebf5ddc86bf252a083702538d19fb2c235eb0f97fd28ab7b566ce95f76")
addappid(2925512, 1, "d9d0954bce91a5fa9f03cda8d62257e74a4cd9ac01febf233417feb5fb704ca0")
addappid(2925513, 1, "72f3418b297bf2f6d2b1cc1dccbddcf07207f127044c231a96ee333b159623b5")

