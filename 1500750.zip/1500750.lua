-- Lua provided by RyzenAPI
-- Game: 1500750

-- MAIN APPLICATION
addappid(1500750)
addappid(1500751)
-- Game: addappid(1500750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1521940,0,"52f73232e3f700ef321d240503d3d96519add6c252e8fe8d41d4ad5109edc25f")
