-- Lua provided by RyzenAPI 
-- Game: RuneScape ®
addappid(1343400)
addappid(1343401, 1, "74b386e9e10d6a92bc4b84e7dac36e20f5ad9c03e6202fc04146d7eacb0d46df")
addappid(1343402, 1, "34d5ab598e253e3e1744ad62bfcd8ca83538b653aa8c018150913a161966b05f")
