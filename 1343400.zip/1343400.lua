-- Lua provided by RyzenAPI
-- Game: RuneScape ®

-- MAIN APPLICATION
addappid(1343400)
addappid(1401450)
addappid(1401451)
addappid(1401452)
addappid(1664830)
addappid(1664831)
addappid(1664832)
addappid(1998770)
addappid(1998771)
addappid(1998772)
addappid(1998773)
addappid(1998774)
addappid(1998775)
addappid(2148810)
addappid(2148811)
addappid(2148812)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1343401, 1, "74b386e9e10d6a92bc4b84e7dac36e20f5ad9c03e6202fc04146d7eacb0d46df")
addappid(1343402, 1, "34d5ab598e253e3e1744ad62bfcd8ca83538b653aa8c018150913a161966b05f")

