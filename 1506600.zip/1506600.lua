-- Lua provided by RyzenAPI
-- Game: Game: My boss is weird

-- MAIN APPLICATION
addappid(1506600)
-- Game: addappid(1506600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1506601, 1, "e73d6c085fd485de54e5f2dfae869f55445e570b953297de711aff897c3d6070")
addappid(1527740, 0, "60f140de37544926389e2dcafa9566ff657fc7a4ca8b478e379f19c465021a95")
addappid(1540070, 0, "ceb6bd1511277c15133cc182ac32ad6c1791dd4f5183019ed009d85e07242734")
