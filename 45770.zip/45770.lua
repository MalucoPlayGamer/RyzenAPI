-- Lua provided by RyzenAPI
-- Game: Dead Rising 2: Off the Record

-- MAIN APPLICATION
addappid(45770)
addappid(45772)
addappid(45773)
addappid(45774)
addappid(45775)
addappid(45776)
addappid(45777)
addappid(45778)
addappid(228981)

-- MAIN APP DEPOTS / PACKAGES
addappid(45771, 1, "1329c30bbef699a6fd554ab765f9ce546d162d99b49e49391e738d5a47259820")
addappid(45779, 1, "8118d6b20ddb4f92ac7095215f84a066cb76eaebe9f43f250f49fbf719808f69")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
