-- Lua provided by RyzenAPI
-- Game: AppID 45770

-- MAIN APPLICATION
addappid(45770)
addappid(228981)
-- Game: addappid(45770)

-- MAIN APP DEPOTS / PACKAGES
addappid(45771, 1, "1329c30bbef699a6fd554ab765f9ce546d162d99b49e49391e738d5a47259820")
addappid(45779, 1, "8118d6b20ddb4f92ac7095215f84a066cb76eaebe9f43f250f49fbf719808f69")
