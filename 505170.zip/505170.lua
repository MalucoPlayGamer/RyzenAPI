-- Lua provided by RyzenAPI
-- Game: Carmageddon: Max Damage

-- MAIN APPLICATION
addappid(505170)

-- MAIN APP DEPOTS / PACKAGES
addappid(505171, 1, "0a724bbe405339a76bf37b30dc5891eaae9d18f1503e1e52e473a595a8ebe83f")
