-- Lua provided by RyzenAPI
-- Game: Carmageddon: Max Damage

-- MAIN APPLICATION
addappid(505170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(505171, 1, "0a724bbe405339a76bf37b30dc5891eaae9d18f1503e1e52e473a595a8ebe83f")

