-- Lua provided by SkyAPI 
-- Game: Carmageddon: Max Damage
addappid(505170)
addappid(505171, 1, "0a724bbe405339a76bf37b30dc5891eaae9d18f1503e1e52e473a595a8ebe83f")
