-- Lua provided by RyzenAPI
-- Game: Surviving the Abyss

-- MAIN APPLICATION
addappid(1254320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254321, 1, "529b5ecbb6ac0fce55c4ea0e3af1a72db9db655aa65a79414b56c2e69375766b")

