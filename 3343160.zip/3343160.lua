-- Lua provided by RyzenAPI
-- Game: Game: Fill Up The Hole

-- MAIN APPLICATION
addappid(3343160)
-- Game: addappid(3343160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3343161, 1, "6b134e8faff940b08247604707c11e4c99511ae304f931a6a01ddb19952f3f01")
