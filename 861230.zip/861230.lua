-- Lua provided by RyzenAPI
-- Game: Game: Arevoatl Seven Coins

-- MAIN APPLICATION
addappid(861230)
-- Game: addappid(861230)

-- MAIN APP DEPOTS / PACKAGES
addappid(861231, 1, "2dc7e869f6505a890d84206f93f824ddbb5dfc36773107790418a387dfe1a18c")
