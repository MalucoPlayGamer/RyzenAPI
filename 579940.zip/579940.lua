-- Lua provided by RyzenAPI
-- Game: 579940

-- MAIN APPLICATION
addappid(579940)
-- Game: addappid(579940)

-- MAIN APP DEPOTS / PACKAGES
addappid(579941, 1, "e0764d069e0db96c211e6c863110c24626e35d69e79fe9ab5b891ea776fa4b17")
