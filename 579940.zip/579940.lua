-- Lua provided by RyzenAPI
-- Game: Race for the Galaxy

-- MAIN APPLICATION
addappid(579940)
addappid(647070)
addappid(647071)
addappid(762070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(579941, 1, "e0764d069e0db96c211e6c863110c24626e35d69e79fe9ab5b891ea776fa4b17")

