-- Lua provided by RyzenAPI
-- Game: 1142550

-- MAIN APPLICATION
addappid(1142550)
-- Game: addappid(1142550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1142554,0,"a6184ebe218026c610d8ba958fa2a5930f2e6d4697faff2d842810e8209b09a9")
