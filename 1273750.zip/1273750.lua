-- Lua provided by RyzenAPI
-- Game: Button City

-- MAIN APPLICATION
addappid(1273750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273751, 1, "259dc03f2616f2b76ccea06ff90db6fae08ea0e0fece60a46e58578bdcea1431")
addappid(1273752, 1, "8845364a9e034c90a3d6ac1e302d8267ca8aca1eac736bcb5f4e8e4251c02d54")
addappid(2100850, 0, "dd53d8ef583f262269343c4d9033775d8a281f3fc076b0c133df7640a4cc027b")
