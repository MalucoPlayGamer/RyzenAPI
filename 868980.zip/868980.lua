-- Lua provided by RyzenAPI
-- Game: DEEP SPACE WAIFU: NEKOMIMI

-- MAIN APPLICATION
addappid(868980)
addappid(1001620)

-- MAIN APP DEPOTS / PACKAGES
addappid(868981, 1, "e1bd512fadf90ac2e568083aa217e679edccf6d1a1dcab5727925a07ef5027e8")

