-- Lua provided by RyzenAPI
-- Game: 978853

-- MAIN APPLICATION
addappid(978853)
-- Game: addappid(978853)

-- MAIN APP DEPOTS / PACKAGES
addappid(978853,0,"f108a313d2f9bf5736e6d57183af302cc5353ca0d650324e51028f1025e7a54b")
