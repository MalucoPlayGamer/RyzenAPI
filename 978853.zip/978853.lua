-- Lua provided by RyzenAPI
-- Game: DYNASTY WARRIORS 9: Xin Xianying (Concierge Costume) / 辛憲英 「コンシェルジュ風コスチューム」

-- MAIN APPLICATION
addappid(978853)

-- MAIN APP DEPOTS / PACKAGES
addappid(978853,0,"f108a313d2f9bf5736e6d57183af302cc5353ca0d650324e51028f1025e7a54b")

