-- Lua provided by RyzenAPI
-- Game: Game: AppID 488520

-- MAIN APPLICATION
addappid(488520)
-- Game: addappid(488520)

-- MAIN APP DEPOTS / PACKAGES
addappid(488521, 1, "ae3f8910792863533d6964db3498482c59bbb47414ddc6b823e960858eadb7ee")
