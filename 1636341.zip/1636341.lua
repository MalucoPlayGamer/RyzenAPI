-- Lua provided by RyzenAPI
-- Game: Beat Saber - Kendrick Lamar - "DNA."

-- MAIN APPLICATION
addappid(1636341)
-- Game: addappid(1636341)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636341,0,"1d6c710db935024d7ac65b3ad6c19039eec398507a197ec2256b542f602c146e")
