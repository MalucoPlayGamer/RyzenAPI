-- Lua provided by SkyAPI 
-- Game: Mr. Hopp's Playhouse 3
addappid(2176450)
addappid(2176451, 1, "ea982977b72cfb5b1a27f9e80277212c5e4391974440c822cbefdf6ac0f5de5b")
