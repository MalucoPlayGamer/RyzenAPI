-- Lua provided by RyzenAPI
-- Game: GuLady 蛊婆

-- MAIN APPLICATION
addappid(1329350)
addappid(1685280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1329351, 1, "2efcb6fe7a56b07f401cee4843db306c59cf48ccf7a965b90ac3969834fc3240")
addappid(1685290, 0, "feeab4a685316371d54f1e6c3c2f5488aa3b4c841562931cf405b23bd081f681")
addappid(1735710, 0, "f310ace95ab51a1655d1c1c316f93079b96743af0e75af3c18545bc41e41fc7b")
addappid(1735720, 0, "348f66d7dff37f8d6b1e2581197e7c9012206edff0c9a9ec46e25add3325b2f0")
addappid(1740980, 0, "8f41ba12579c5ceb38981f2bc02b50ea9eab0c0a0ba70b0a4ac923844ba14d59")

