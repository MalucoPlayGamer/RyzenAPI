-- Lua provided by RyzenAPI
-- Game: Gunbrella Soundtrack

-- MAIN APPLICATION
addappid(2476880)
-- Game: addappid(2476880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476881, 1, "4bced5a698380030295bc061fe7324e9d3fb39879ae18fda98196985defa195d")
addappid(2476882, 1, "d7346529bd038ba167080c3b48dc6cfefe77ce6686122025bb7ca1a2b3e48015")
