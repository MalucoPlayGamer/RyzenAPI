-- Lua provided by RyzenAPI
-- Game: addappid(2214130)

-- MAIN APPLICATION
addappid(2214130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2214131, 1, "3a2a37bbe62dda3a13701d73f01b50d183bd0c8fbfe682df1b5c62c123bea311")
