-- Lua provided by RyzenAPI
-- Game: 2768000

-- MAIN APPLICATION
addappid(2768000)
-- Game: addappid(2768000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2768001, 1, "7b0d8a79cfc5bb5fff96c4c5c299d86027e477288db4e14108ec9488fd2a1a7b")
