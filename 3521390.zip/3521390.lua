-- Lua provided by RyzenAPI
-- Game: The Devil Ball

-- MAIN APPLICATION
addappid(3521390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3521391, 1, "c3c254f3e9253efb53986b8043cfb169f8bd5f30e505afcbeb05d49d29d43edd")

