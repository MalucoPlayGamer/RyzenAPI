-- Lua provided by RyzenAPI 
-- Game: Ageless
addappid(1210150)
addappid(1210151, 1, "b4eb6231d06ea5f1fbb42334ef559fd5487c9c1b330fdec36ed3b5f45cdaa436")
