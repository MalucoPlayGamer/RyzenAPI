-- Lua provided by SkyAPI 
-- Game: AppID 2358680
addappid(2358680)
addappid(2358681, 1, "9920cff668e58bc093ca5b0bedf0c7135e3e765bcd4e1088a5826f4c9893bdee")
