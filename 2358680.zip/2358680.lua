-- Lua provided by RyzenAPI
-- Game: AppID 2358680

-- MAIN APPLICATION
addappid(2358680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358681, 1, "9920cff668e58bc093ca5b0bedf0c7135e3e765bcd4e1088a5826f4c9893bdee")
