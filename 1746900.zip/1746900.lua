-- Lua provided by RyzenAPI
-- Game: Politicians for Clip maker

-- MAIN APPLICATION
addappid(1746900)
-- Game: addappid(1746900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1746901, 1, "71aea8ab20530d29d972b3085352fafdd51e4ec38d9abeb370eeb515f689d8e9")
