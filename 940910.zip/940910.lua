-- Lua provided by SkyAPI 
-- Game: Minoria
addappid(940910)
addappid(940911, 1, "6765b0608f9ee146aa7f506d5870624af036eb12992dd1617bc0e1861e66160e")
