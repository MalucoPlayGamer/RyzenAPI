-- Lua provided by RyzenAPI
-- Game: Minoria

-- MAIN APPLICATION
addappid(940910)

-- MAIN APP DEPOTS / PACKAGES
addappid(940911, 1, "6765b0608f9ee146aa7f506d5870624af036eb12992dd1617bc0e1861e66160e")

