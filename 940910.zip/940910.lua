-- Lua provided by RyzenAPI
-- Game: Minoria

-- MAIN APPLICATION
addappid(940910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(940911, 1, "6765b0608f9ee146aa7f506d5870624af036eb12992dd1617bc0e1861e66160e")

