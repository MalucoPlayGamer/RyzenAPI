-- Lua provided by RyzenAPI
-- Game: Dodgy Deliveries Demo

-- MAIN APPLICATION
addappid(2855550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2855551, 1, "fd4a28f0398d56833b525361fcd6711db1c3f57c1c0435f7b09783160e391536")

