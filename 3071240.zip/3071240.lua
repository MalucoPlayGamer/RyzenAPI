-- Lua provided by RyzenAPI
-- Game: Voodoo Fishin'

-- MAIN APPLICATION
addappid(3071240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3071241,0,"f1cf0cc34cc7625855cbd7da469cd67c7a7b280328d6338359898ed9cd2d525c")

