-- Lua provided by RyzenAPI
-- Game: Tick, Tank, Boom

-- MAIN APPLICATION
addappid(2237950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2237951, 1, "4f9e92f91a9863b2bd68564fd5a5c98fe6db4bcc2f1c492db75172934974ef45")

