-- Lua provided by SkyAPI 
-- Game: Uh Oh Bartender
addappid(1097760)
addappid(1097761, 1, "605a76c7a881e27b57dbc7d466c8c204bd16952a536845a7618729f3dd4d8676")
