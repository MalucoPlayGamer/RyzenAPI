-- Lua provided by RyzenAPI
-- Game: Game: Cursed to Golf

-- MAIN APPLICATION
addappid(1726120)
-- Game: addappid(1726120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1726121, 1, "ff917a5c81963aae1fe6627a2d979cb4dcb6cbda5eb0ffa51dff36159df26737")
