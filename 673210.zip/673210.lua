-- Lua provided by RyzenAPI
-- Game: Frontier Pilot Simulator

-- MAIN APPLICATION
addappid(673210)

-- MAIN APP DEPOTS / PACKAGES
addappid(673211, 1, "4209b5a22dd5f343b779a00aa63a2ccb94cff1e264a2152a1679448fe211d06c")
