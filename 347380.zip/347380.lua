-- Lua provided by RyzenAPI
-- Game: Game: AppID 347380

-- MAIN APPLICATION
addappid(347380)
-- Game: addappid(347380)

-- MAIN APP DEPOTS / PACKAGES
addappid(347381, 1, "89fc96c195528d54533c4417beb5c791970bd2344b3599f79e3f5d272a94178d")
