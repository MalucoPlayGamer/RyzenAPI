-- Lua provided by RyzenAPI
-- Game: Stoneman's Adventure

-- MAIN APPLICATION
addappid(2434860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2434861, 1, "87fe1097390f361ef0a1b4684fd2d7b380eb63acd85a9cfc4881932e2b1e93c1")
