-- Lua provided by RyzenAPI
-- Game: Game: AppID 604160

-- MAIN APPLICATION
addappid(604160)
-- Game: addappid(604160)

-- MAIN APP DEPOTS / PACKAGES
addappid(604161, 1, "bf562925b7aafbb5ba1e399b942fa7c6eff037c071b19246774d8412a97558fa")
