-- Lua provided by RyzenAPI
-- Game: Short Horror Story

-- MAIN APPLICATION
addappid(2225970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225971, 1, "35eb1a218cdbea265a93610436416fe0440b6957506ac76a0d2d43c61f65f5f3")

