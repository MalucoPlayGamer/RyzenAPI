-- Lua provided by RyzenAPI
-- Game: Short Horror Story

-- MAIN APPLICATION
addappid(2225970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225971, 1, "35eb1a218cdbea265a93610436416fe0440b6957506ac76a0d2d43c61f65f5f3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
