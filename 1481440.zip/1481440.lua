-- Lua provided by RyzenAPI 
-- Game: Guardians Frontline
addappid(1481440)
addappid(1481441, 1, "024750555016380f475e174e86dbfbaf96db87cb4328dc0300b4988ee63eb488")
