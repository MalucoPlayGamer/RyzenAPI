-- Lua provided by RyzenAPI
-- Game: Game: Guardians Frontline

-- MAIN APPLICATION
addappid(1481440)
-- Game: addappid(1481440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1481441, 1, "024750555016380f475e174e86dbfbaf96db87cb4328dc0300b4988ee63eb488")
