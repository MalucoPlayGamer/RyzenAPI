-- Lua provided by RyzenAPI
-- Game: The Big Journey

-- MAIN APPLICATION
addappid(742480)
addappid(789080)

-- MAIN APP DEPOTS / PACKAGES
addappid(742481, 1, "dc6821501e22090587dec1241315efba2853735aac81368388a181333e43275e")

