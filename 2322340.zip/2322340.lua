-- Lua provided by RyzenAPI
-- Game: Game: Monster High™ Skulltimate Secrets™

-- MAIN APPLICATION
addappid(2322340)
-- Game: addappid(2322340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2322341, 1, "1a1e762a01827a8eaaeb05f6b453febda5159a3b158c824c41bf9d59bf721fb0")
