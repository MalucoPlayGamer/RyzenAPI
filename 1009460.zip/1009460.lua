-- Lua provided by RyzenAPI
-- Game: Hello, Goodbye

-- MAIN APPLICATION
addappid(1009460)
-- Game: addappid(1009460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1009461, 1, "f61f74af20dc66c26730aa927f940c4e98598e9731b1f2a2a7124d2005bb6000")
addappid(1064810, 0, "9dd5263e09c4dbf3b1e25e3d0c7719df51772989821f589ee0a827f2fea26e5f")
