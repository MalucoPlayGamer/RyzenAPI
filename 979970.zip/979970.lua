-- Lua provided by RyzenAPI
-- Game: Game: IMAZE.EXE

-- MAIN APPLICATION
addappid(979970)
-- Game: addappid(979970)

-- MAIN APP DEPOTS / PACKAGES
addappid(979971, 1, "970d0f7ee9a89d5a7c4bc2043d6e9af28a060822f12f06afb8ea90ddca2356f3")
