-- Lua provided by SkyAPI 
-- Game: IMAZE.EXE
addappid(979970)
addappid(979971, 1, "970d0f7ee9a89d5a7c4bc2043d6e9af28a060822f12f06afb8ea90ddca2356f3")
