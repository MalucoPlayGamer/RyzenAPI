-- Lua provided by RyzenAPI
-- Game: Warhammer Age of Sigmar: Tempestfall

-- MAIN APPLICATION
addappid(1337100)
-- Game: addappid(1337100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1337101, 1, "5474babe322ad83c6bd45b6f478e0fa8b1f16d7a42a4b87e46fc1da511c0220c")
