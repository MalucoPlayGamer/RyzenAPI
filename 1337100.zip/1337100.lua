-- Lua provided by RyzenAPI
-- Game: Warhammer Age of Sigmar: Tempestfall

-- MAIN APPLICATION
addappid(1337100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1337101, 1, "5474babe322ad83c6bd45b6f478e0fa8b1f16d7a42a4b87e46fc1da511c0220c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
