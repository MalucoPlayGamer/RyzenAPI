-- Lua provided by RyzenAPI
-- Game: Card Cowboy

-- MAIN APPLICATION
addappid(2149480)
-- Game: addappid(2149480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2149481, 1, "12613de321403ea790ca82cfcf80a78aaa9e3423811577a03377ffdef941c1c6")
