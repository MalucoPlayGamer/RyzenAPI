-- Lua provided by RyzenAPI
-- Game: Game: AppID 970090

-- MAIN APPLICATION
addappid(970090)
-- Game: addappid(970090)

-- MAIN APP DEPOTS / PACKAGES
addappid(970091, 1, "41baec278830ae1175c2befd9f005c457295fb11897ccfcfb83086f1865c9885")
