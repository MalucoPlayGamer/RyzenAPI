-- Lua provided by RyzenAPI
-- Game: AppID 579120

-- MAIN APPLICATION
addappid(579120)
-- Game: addappid(579120)

-- MAIN APP DEPOTS / PACKAGES
addappid(579121, 1, "acd0c6935edafe0f99e906b56d72c8e903400efdbeb28de824869eb8e86862fa")
