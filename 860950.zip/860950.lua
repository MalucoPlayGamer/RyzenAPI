-- Lua provided by RyzenAPI
-- Game: AppID 860950

-- MAIN APPLICATION
addappid(860950)

-- MAIN APP DEPOTS / PACKAGES
addappid(860951, 1, "cc1edd2b80374b31917911123d97ff8a647c5b0ad18eb9bb36b32cb9e33f9542")
addappid(860952, 1, "5d8038581b4139f23ca39d7effad4257faead028b1d0259851c1836e3288e942")
addappid(860953, 1, "a163f40c3289cf1469a2fdbdac0d31093d1a13c8714b9c9f867fd54739fcb697")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
