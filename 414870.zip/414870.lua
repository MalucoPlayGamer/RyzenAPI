-- Lua provided by RyzenAPI
-- Game: 414870

-- MAIN APPLICATION
addappid(414870)
-- Game: addappid(414870)

-- MAIN APP DEPOTS / PACKAGES
addappid(414871, 1, "9792c1406bfa2b141d2c89aae05120a55026ff029f2d531d9e8ff350974d1db6")
