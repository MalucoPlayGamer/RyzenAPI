-- Lua provided by RyzenAPI
-- Game: Super Mega Baseball 2

-- MAIN APPLICATION
addappid(414870)
addappid(747740)
addappid(747741)
addappid(747742)
addappid(920350)
addappid(920351)
addappid(920352)
addappid(920353)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(414871, 1, "9792c1406bfa2b141d2c89aae05120a55026ff029f2d531d9e8ff350974d1db6")
