-- Lua provided by RyzenAPI
-- Game: Sid Meier's Civilization VII

-- MAIN APPLICATION
addappid(1295660)
addappid(2778060)
addappid(3004650)
addappid(3004660)
addappid(3087220)
addappid(3087240)
addappid(3087250)
addappid(3087260)
addappid(3087270)
addappid(3087280)
addappid(3087290)
addappid(3087300)
addappid(3087310)
addappid(3087320)
addappid(3087330)
addappid(3087350)
addappid(3087370)
addappid(3087380)
addappid(3087410)
addappid(3087430)
addappid(3087440)
addappid(3087460)
addappid(3490290)
addappid(3502600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1295661, 1, "59cf929fe0be7af1bba7498247138b359bcc8141d6921f65f06f5d3c4e604430")
addappid(1295662, 1, "2d91bb0ac40f79f21d133921c8092cee1bbc5622c1e429d5d5e65a5543a440eb")
addappid(1295663, 1, "129446ed0c86a3cecf211aca2aca7c0ef0b14248fe2e7229afb79e90f2b07531")
addappid(1295665, 1, "ad00cf603a7538a190b6f7e523a9f9b1ff48759aacb39f2b35a70c5302fcef37")
addappid(1295666, 1, "68e1686bc8f5a23173a86f6a5c3fb61ae2714081bf956976f7f837a1f03a9779")

