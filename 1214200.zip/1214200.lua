-- Lua provided by SkyAPI 
-- Game: AppID 1214200
addappid(1214200)
addappid(1214201, 1, "6f77ef11439e397a38f17fa5ae3858053b4823d68205d9daef15fc7fb019f24d")
