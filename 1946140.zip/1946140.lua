-- Lua provided by RyzenAPI 
-- Game: Jigsaw Puzzles Infinite
addappid(1946140)
addappid(1946141, 1, "1c63d8950882c44e978c2ad3dbbd25d60d8b7f1cdf85c75a5c23a61ea5cf0745")
addappid(2404910, 0, "069075aa7c3683f7d26953a5a938b19ef3879239829784b457b1dbd2923abf72")
addappid(2769470, 0, "fa9eac37b4cd644bf522d05d6c09e59282ace6978bf7aeff02ef6c839f503446")
