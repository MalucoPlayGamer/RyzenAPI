-- Lua provided by RyzenAPI
-- Game: Deepening Fire

-- MAIN APPLICATION
addappid(1642790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1642791, 1, "227a8ea7f49384e88d64c7d9ec3bb8645c0f498d9248e4ef316f8d87ea7d16ab")
addappid(1642792, 1, "5c4e3b32d6d491234fe6255272c943aa68001aea2174290eaa8d0235a43ddd55")

