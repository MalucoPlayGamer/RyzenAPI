-- Lua provided by RyzenAPI
-- Game: addappid(1794490)

-- MAIN APPLICATION
addappid(1794490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794491, 1, "4fef4c1ae22b4c23b91b75c01a60ddf5334e0e22daacf18c9244f334b6ee57b3")
