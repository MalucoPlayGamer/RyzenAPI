-- Lua provided by RyzenAPI
-- Game: SPY RUMBLE

-- MAIN APPLICATION
addappid(1794490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794491, 1, "4fef4c1ae22b4c23b91b75c01a60ddf5334e0e22daacf18c9244f334b6ee57b3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2066400)
addappid(2121810)
addappid(2301170)
addappid(2301950)
addappid(2383150)
addappid(2383151)
addappid(2383152)
addappid(2383153)
addappid(2383154)
addappid(2383156)
