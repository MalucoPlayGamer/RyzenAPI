-- Lua provided by RyzenAPI
-- Game: White Wings ホワイトウィングス

-- MAIN APPLICATION
addappid(1185680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1185681, 1, "a0dde99ee657f5a61a2e536c6fd061bfd111245478d0509d027b8a6af66825e1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1187260)
addappid(1204160)
