-- Lua provided by SkyAPI 
-- Game: White Wings ホワイトウィングス
addappid(1185680)
addappid(1185681, 1, "a0dde99ee657f5a61a2e536c6fd061bfd111245478d0509d027b8a6af66825e1")
