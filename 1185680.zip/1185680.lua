-- Lua provided by RyzenAPI
-- Game: Game: White Wings ホワイトウィングス

-- MAIN APPLICATION
addappid(1185680)
-- Game: addappid(1185680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1185681, 1, "a0dde99ee657f5a61a2e536c6fd061bfd111245478d0509d027b8a6af66825e1")
