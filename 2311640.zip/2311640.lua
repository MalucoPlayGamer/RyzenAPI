-- Lua provided by RyzenAPI
-- Game: Love n War: Hero by Chance II - Romance & Reprisal

-- MAIN APPLICATION
addappid(2311640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2311640,0,"25c0749d7d1b7c73dcda4678cc7e488907dc582712ccadd787089f97dd92dd98")
