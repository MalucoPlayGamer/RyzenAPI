-- Lua provided by RyzenAPI
-- Game: addappid(906600)

-- MAIN APPLICATION
addappid(906600)

-- MAIN APP DEPOTS / PACKAGES
addappid(906601, 1, "fac57093fab349d7d131922249e637c0cb3d38708d214ad242158f8bf236312d")
