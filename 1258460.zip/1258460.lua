-- Lua provided by RyzenAPI
-- Game: Game: Escape First 3

-- MAIN APPLICATION
addappid(1258460)
-- Game: addappid(1258460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258461, 1, "12b902982a26b46a9525807a725d865b895330559c1ae2d4507c90e96549c62d")
