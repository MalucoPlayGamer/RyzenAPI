-- Lua provided by RyzenAPI
-- Game: Game: AppID 522470

-- MAIN APPLICATION
addappid(522470)
-- Game: addappid(522470)

-- MAIN APP DEPOTS / PACKAGES
addappid(522471, 1, "385c9dd79ae478ee71d7fae6abaa63d0d722d64c9a555cce416ee1c996873290")
addappid(522472, 1, "e3b81e401f2c51bf408e30269d88894ca31deeff9963fca8ce38f60d1a908689")
addappid(522474, 1, "40bccad96b27b4a834db8625415d3cae954ab69de4fac05dfc4d66ea92f7663c")
addappid(1440830, 0, "c7cae73024722aa71519adf0a48cf930b9dfee802c2c2bd08a2a7427d5226450")
