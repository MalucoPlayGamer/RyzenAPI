-- Lua provided by RyzenAPI
-- Game: 2504460

-- MAIN APPLICATION
addappid(2504460)
-- Game: addappid(2504460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2504461, 1, "ca7da0320a24942b8955e2534bd8402d15c74c25c9b9c6fb8485cd0b3e011c7f")
