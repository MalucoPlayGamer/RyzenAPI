-- Lua provided by SkyAPI 
-- Game: Drunken Fight Simulator
addappid(576480)
addappid(576481, 1, "b2373b9f3b6d85cf65d84a426ea37ec641affe507a1f780319c42d4f5bac3f37")
