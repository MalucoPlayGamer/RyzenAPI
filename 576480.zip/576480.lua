-- Lua provided by RyzenAPI
-- Game: addappid(576480)

-- MAIN APPLICATION
addappid(576480)

-- MAIN APP DEPOTS / PACKAGES
addappid(576481, 1, "b2373b9f3b6d85cf65d84a426ea37ec641affe507a1f780319c42d4f5bac3f37")
