-- Lua provided by RyzenAPI
-- Game: AppID 1944270

-- MAIN APPLICATION
addappid(1944270)
-- Game: addappid(1944270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1944271, 1, "8dcb7b647273f789ef4e33a2f63cfcb04d0fd5d58174b169a4ead28c23c824ce")
