-- Lua provided by RyzenAPI
-- Game: Matryoshka Strike

-- MAIN APPLICATION
addappid(675960)

-- MAIN APP DEPOTS / PACKAGES
addappid(675961,0,"35a677c70c602cad10e8eac1ce3f1d264614424b792ae172ed52b7373cd48eb0")

