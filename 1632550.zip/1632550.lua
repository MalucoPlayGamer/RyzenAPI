-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Winlu Cyberpunk Tileset - Interior

-- MAIN APPLICATION
addappid(1632550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632550,0,"fac4b5be7ab797bb2b0a3aaf9018eee341903e21b457e5c2d718e43eb166272d")

