-- Lua provided by RyzenAPI
-- Game: Game: Life after Death

-- MAIN APPLICATION
addappid(1876830)
-- Game: addappid(1876830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876831, 1, "bb68305990a2d5f37a6a24baa01b24fc24d3e5c4c0cd5b8e87814144eafa1930")
