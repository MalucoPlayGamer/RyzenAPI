-- Lua provided by RyzenAPI
-- Game: Life after Death

-- MAIN APPLICATION
addappid(1876830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876831, 1, "bb68305990a2d5f37a6a24baa01b24fc24d3e5c4c0cd5b8e87814144eafa1930")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
