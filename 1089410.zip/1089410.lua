-- Lua provided by RyzenAPI
-- Game: Depression The Game Music DLC

-- MAIN APPLICATION
addappid(1089410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089410,0,"7f61e4030f06b7f60bc9aba4e251dbd052bdd51f36e7600fbcb64817c8fb0b2e")

