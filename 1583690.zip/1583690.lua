-- Lua provided by RyzenAPI
-- Game: Elijah and the Out of this World Adventure

-- MAIN APPLICATION
addappid(1583690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1583691, 1, "8f06737480bfca2bf9a40ca961be3b51e209dad5799d63c9e7f096649981677d")

