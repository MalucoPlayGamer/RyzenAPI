-- Lua provided by RyzenAPI
-- Game: My Riding Stables: Your Horse world

-- MAIN APPLICATION
addappid(276300)

-- MAIN APP DEPOTS / PACKAGES
addappid(276301, 1, "94413eeb8eeb29df45e75f6295deb9821c53ad7f05fa94f93160a39befa549d7")
addappid(276302, 1, "272adfe3f06e2b3a2d79b104bced459c59751934e3130bd23e2978e3c97522ea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
