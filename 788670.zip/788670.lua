-- Lua provided by RyzenAPI
-- Game: Waxworks: Curse of the Ancestors

-- MAIN APPLICATION
addappid(788670)

-- MAIN APP DEPOTS / PACKAGES
addappid(788671,0,"796398ad0b6c8be8a7cb6376340101f6a173385b656075df115695accedb1c8f")

