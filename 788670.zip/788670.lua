-- Lua provided by RyzenAPI
-- Game: Waxworks: Curse of the Ancestors

-- MAIN APPLICATION
addappid(788670)

-- MAIN APP DEPOTS / PACKAGES
addappid(788671,0,"796398ad0b6c8be8a7cb6376340101f6a173385b656075df115695accedb1c8f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
