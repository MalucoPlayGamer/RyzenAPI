-- Lua provided by RyzenAPI
-- Game: Game: G-MODEアーカイブス+ 探偵・癸生川凌介事件譚 Vol.2「海楼館殺人事件」

-- MAIN APPLICATION
addappid(2307060)
-- Game: addappid(2307060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307061, 1, "e6ef488e39c7023e03c9c2494cb5a8f2a39743a4ae8479b5718f48495124fc47")
