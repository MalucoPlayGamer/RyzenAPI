-- Lua provided by RyzenAPI
-- Game: Game: Smoots Golf

-- MAIN APPLICATION
addappid(1601360)
-- Game: addappid(1601360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601361, 1, "7a8e3431e763a2c8316a7a2e2f0e88d7b5641edc9534f141fe8bff07e7be4a15")
