-- Lua provided by RyzenAPI
-- Game: 3577720

-- MAIN APPLICATION
addappid(3577720)
-- Game: addappid(3577720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3577720,0,"211290cafd5dc11c5fa63d07649e9ac46e0a0bc11536329c83f0c76459d1d05d")
