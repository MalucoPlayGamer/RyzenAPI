-- Lua provided by RyzenAPI
-- Game: Yakuza 0

-- MAIN APPLICATION
addappid(638970)

-- MAIN APP DEPOTS / PACKAGES
addappid(638971, 1, "ed70cc2d7c7ce6db4c6e3ccdd070786dcb37b73a0bc82825d89705311c39a100")
addappid(638972, 1, "882baada465c2da02cf427b6e9744bb4a52e9980c6331beb97b60ad3af9fc0e0")
addappid(638973, 1, "be3eaf318d15138653145447fa244e0838e0c25b21f9f0b797eb1660471c5a5e")
addappid(638975, 1, "7d2df597ac4ddc5ea945aff1ca599b6c21c6604bbb1c070f208bf49244315461")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
