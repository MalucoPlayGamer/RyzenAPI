-- Lua provided by RyzenAPI
-- Game: 东方大战争 免费版转付费版/Touhou big big battle F2P to Paid conversion

-- MAIN APPLICATION
addappid(923720)

-- MAIN APP DEPOTS / PACKAGES
addappid(923720,0,"8079c9af8931b5344a52594395a0cd5800ea044a6ed978175f105521c6dda421")
