-- Lua provided by RyzenAPI 
-- Game: Madohi Shiroki no Kamikakushi
addappid(1854980)
addappid(1854981, 1, "6c1e6d77cfa85bca9a4e9f504a31a4189d50e1eb9f14b3f94d2494d4b1284301")
