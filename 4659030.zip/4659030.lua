-- 4659030's Lua and Manifest Created by Hubcap Manifest
-- CyberDeck
-- Created: August 01, 2026 at 09:12:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4659030) -- CyberDeck
-- MAIN APP DEPOTS
addappid(4659032, 1, "e70dfe245d8432e745e8683cadf5c43a4459701e2fb2997756a67908b275b4c6") -- Depot 4659032
setManifestid(4659032, "4786866917688005812", 2911245200)
addappid(4659034, 1, "8a5ddca2e61e9ab483f4694f8b96763212f22a009efaeb288560c1bb2566c703") -- Depot 4659034
setManifestid(4659034, "1363644647444239177", 2873056794)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4659031) -- Depot 4659031 (empty depot)