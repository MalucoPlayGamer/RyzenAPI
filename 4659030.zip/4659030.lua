-- Lua provided by RyzenAPI
-- Game: CyberDeck

-- MAIN APPLICATION
addappid(4659030) -- CyberDeck
-- addappid(4659031) -- Depot 4659031 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(4659032, 1, "e70dfe245d8432e745e8683cadf5c43a4459701e2fb2997756a67908b275b4c6") -- Depot 4659032
addappid(4659034, 1, "8a5ddca2e61e9ab483f4694f8b96763212f22a009efaeb288560c1bb2566c703") -- Depot 4659034

