-- Lua provided by RyzenAPI
-- Game: addappid(710760)

-- MAIN APPLICATION
addappid(710760)

-- MAIN APP DEPOTS / PACKAGES
addappid(710761, 1, "41ff61dff56919437ab1617ec6bb1e9fdebd4cacd60405bf287427fb92a04546")
