-- Lua provided by RyzenAPI
-- Game: Moonlighter 2: The Endless Vault

-- MAIN APPLICATION
addappid(4935250)
addappid(5026660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2350790, 1, "7c01755933fc3578562800de1e4f630f201b840b836fc2539b9b18836859fb3f") -- Moonlighter 2: The Endless Vault
addappid(2350792, 1, "794eca19bb31db7e79bbc69f303feb210c8e3efca02f89ff7d38d9e0fed8705f") -- Depot 2350792
addappid(4935250, 1, "054d08d3dd6b6dd31345e17a84b408129380db171306d6a94843cd92be6f91dd") -- Moonlighter 2 The Endless Vault - Zen Patio Pack - Depot 4935250
addappid(5026660, 1, "6f8183955467f69728b17ac71fc617859d1d82770038764174245ca5602a4788") -- Moonlighter 2 The Endless Vault - Original Artbook - Depot 5026660
