-- Lua provided by RyzenAPI 
-- Game: 因缘
addappid(1023250)
addappid(1023251, 1, "44b1073ee02cdae154781871f23899aa84fb8ab0507c4e740ba0428da6b838e8")
