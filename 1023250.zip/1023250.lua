-- Lua provided by RyzenAPI
-- Game: Game: 因缘

-- MAIN APPLICATION
addappid(1023250)
-- Game: addappid(1023250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1023251, 1, "44b1073ee02cdae154781871f23899aa84fb8ab0507c4e740ba0428da6b838e8")
