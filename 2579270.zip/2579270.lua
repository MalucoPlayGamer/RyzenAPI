-- Lua provided by RyzenAPI
-- Game: Satellite Odyssey: Prologue

-- MAIN APPLICATION
addappid(2579270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2579271, 1, "3db4ef776544a3a8b8ac0484d0e56993e37d895b65a9396324ceb6efddd56a7e")
