-- Lua provided by SkyAPI 
-- Game: System Purge
addappid(1515490)
addappid(1515491, 1, "51daf9661a640fd66903b8917e54d612e3d17ecc5f645cee0cf4031fa87f2136")
