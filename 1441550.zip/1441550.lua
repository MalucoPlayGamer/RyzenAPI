-- Lua provided by RyzenAPI
-- Game: Regular Human Workshop

-- MAIN APPLICATION
addappid(1441550)
-- Game: addappid(1441550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441551, 1, "5285ca2ce89f0405ff79c94e294b47f77700d1b1d1db3f62e463ee5836f0006a")
