-- Lua provided by RyzenAPI
-- Game: Lucky Panda

-- MAIN APPLICATION
addappid(739990)

-- MAIN APP DEPOTS / PACKAGES
addappid(739991, 1, "71273c8e3866f46f80a7b36c227289d0c5e1382c6026e9f1bdc9e6064e052255")

