-- Lua provided by RyzenAPI
-- Game: 603860

-- MAIN APPLICATION
addappid(603860)
-- Game: addappid(603860)

-- MAIN APP DEPOTS / PACKAGES
addappid(603861, 1, "854acac0b7a9ad4c06e7de9ea2c69f88c44e0799a143fe580e4bde4fce3d01b3")
