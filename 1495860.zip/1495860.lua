-- Lua provided by RyzenAPI
-- Game: Game: AppID 1495860

-- MAIN APPLICATION
addappid(1495860)
-- Game: addappid(1495860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1495861, 1, "1a56a0867bce5f1f9c4c85af26e77b68188c81911638fa7ac16c0239a24df18a")
