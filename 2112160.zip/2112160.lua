-- Lua provided by RyzenAPI
-- Game: Among Ass: Trilogy

-- MAIN APPLICATION
addappid(2112160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2112161, 1, "8e5f4e27f6be5c1649672e82a1dc4ee5fd6992a36d9c665e5e03c30ef9d834c7")

