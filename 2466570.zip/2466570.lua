-- Lua provided by RyzenAPI
-- Game: BoneTown: The Second Coming Edition - Kinks

-- MAIN APPLICATION
addappid(2466570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2466570,0,"97044b0ad309c2ac03360f423149654f1e89af5467168562ccc0dd98bf541be8")

