-- Lua provided by RyzenAPI
-- Game: Tiltagon

-- MAIN APPLICATION
addappid(432260)
-- Game: addappid(432260)

-- MAIN APP DEPOTS / PACKAGES
addappid(432261, 1, "7dffeeee9d77fbb688d2785763d20afeb0a7896b7deb98dfd9285806b66c8b6a")
addappid(432262, 1, "5b17f3d46546feaa83c697adc98e62d2961804a707edbd7203ad6d98f7d280da")
addappid(432263, 1, "9558655a4327b4deedc873c691cafdcc86f62d90b2c457f69bcbfca86db2d579")
addappid(432264, 1, "631db1c5574af642f8ab15183654f891dd9b5fe0c6b5b10321900519eb00e4eb")
addappid(432265, 1, "e59076bde1bc31a16e28ea6f545b88666929b12ae4241e3176b56a7fd1354dce")
addappid(432266, 1, "2e4cecd929e8f0dadd6c35ad7bce7f130f2b90482d45fb13e668bfe392722036")
