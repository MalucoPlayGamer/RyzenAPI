-- Lua provided by RyzenAPI
-- Game: Game: OlliOlli

-- MAIN APPLICATION
addappid(274250)
-- Game: addappid(274250)

-- MAIN APP DEPOTS / PACKAGES
addappid(274251, 1, "519d205648f6d08b5dc11d7578b6dddc88633dd7600493eaa29d76cd8f3d59be")
addappid(274252, 1, "0bbe95829ccd97d4fd4fd6d875f9c77b85fb6ffc6eedd66ab057847a88a9555c")
addappid(274253, 1, "0e0399cbc90dbbf0b1a613ac27555c9fa45fc6ecbe429f01ce2feb4d9369bbc5")
addappid(274254, 1, "c038076f55c14a03c0a1ef1c366e80fc23696b27f72a0f508f626425094fd88c")
