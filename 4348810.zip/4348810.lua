-- Lua provided by RyzenAPI
-- Game: Orbita

-- MAIN APPLICATION
addappid(4348810) -- Orbita

-- MAIN APP DEPOTS / PACKAGES
addappid(4348811, 1, "8b00c00743b9a9cd589e5483a208bc35fa08b2d73d3873edee3bc8419a3d4d85") -- Depot 4348811

