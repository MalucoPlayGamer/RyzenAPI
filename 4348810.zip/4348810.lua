-- 4348810's Lua and Manifest Created by Hubcap Manifest
-- Orbita
-- Created: August 17, 2026 at 14:29:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4348810) -- Orbita
-- MAIN APP DEPOTS
addappid(4348811, 1, "8b00c00743b9a9cd589e5483a208bc35fa08b2d73d3873edee3bc8419a3d4d85") -- Depot 4348811
setManifestid(4348811, "1269603937508409799", 112499363)