-- Lua provided by RyzenAPI
-- Game: MechRunner

-- MAIN APPLICATION
addappid(288100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(288101, 1, "7989c93295c404e9044d45194376a5e6c92cb2589b8db049d7898ebf13231ef6")
addappid(288102, 1, "480ebe3390bae66c5af7253a76d1829faf0d52a3ac0876eea901f8aba4ac2e50")
addappid(288103, 1, "924825dcc9fefa7602548078b2376bb488cdc61316eebc453b49743471018add")

