-- Lua provided by RyzenAPI
-- Game: Game: AppID 1801000

-- MAIN APPLICATION
addappid(1801000)
-- Game: addappid(1801000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1801001, 1, "0f7a12432305dff0643486dac1f91a051c3f413bb9d0494fadf45c09e2f2670e")
