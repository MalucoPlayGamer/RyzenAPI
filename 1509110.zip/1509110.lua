-- Lua provided by RyzenAPI
-- Game: 1509110

-- MAIN APPLICATION
addappid(1509110)
-- Game: addappid(1509110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509112,0,"e8efad8048e52d26a3158fa2cde28890b4d3208c26a83df19ad499102a60f6cc")
