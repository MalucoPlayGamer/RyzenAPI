-- Lua provided by RyzenAPI
-- Game: Wonfourn

-- MAIN APPLICATION
addappid(655980)

-- MAIN APP DEPOTS / PACKAGES
addappid(655981,0,"2a25684522a48b388979cd86e9130a4a0534a5ada2b5f1a7a575bf940efb56c4")

