-- Lua provided by RyzenAPI
-- Game: Stonerid

-- MAIN APPLICATION
addappid(315920)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(315921, 1, "b4101a47549ad0cde2f2eac1bb552da19ccf5c0d5ef2a4b09e3440eeee6d4593")

