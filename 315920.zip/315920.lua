-- Lua provided by RyzenAPI
-- Game: 315920

-- MAIN APPLICATION
addappid(315920)
-- Game: addappid(315920)

-- MAIN APP DEPOTS / PACKAGES
addappid(315921, 1, "b4101a47549ad0cde2f2eac1bb552da19ccf5c0d5ef2a4b09e3440eeee6d4593")
