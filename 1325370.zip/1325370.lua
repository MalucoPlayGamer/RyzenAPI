-- Lua provided by RyzenAPI
-- Game: COVID-19 Isolation

-- MAIN APPLICATION
addappid(1325370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1325372,0,"c90252fcb339098b8b759f97914532210dad031299c98d5990abd23bcabe2a5b")

