-- Lua provided by RyzenAPI
-- Game: Game: SkyDrift

-- MAIN APPLICATION
addappid(91100)
-- Game: addappid(91100)

-- MAIN APP DEPOTS / PACKAGES
addappid(91101, 1, "dc96085db98a104db414bb8344b951927a689c146e05933dbd768b898a810208")
addappid(91104, 1, "a15cadf97174a618914e6ca09df8e2030a2963c1f17d05af5163012bec93f497")
addappid(91106, 1, "f62a7e143a57e70075a9833d535f6adbf143fda55fe4c5f37fa9671e24e1c470")
