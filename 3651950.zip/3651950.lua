-- Lua provided by RyzenAPI
-- Game: Evil Egg

-- MAIN APPLICATION
addappid(3651950)

