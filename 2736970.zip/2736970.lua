-- Lua provided by RyzenAPI
-- Game: Arco Demo

-- MAIN APPLICATION
addappid(2736970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2736971, 1, "540b3fa43fa736bda1627cc0406d542ffd48d0077c72ea01cb35344c92b050b7")

