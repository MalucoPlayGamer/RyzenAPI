-- Lua provided by RyzenAPI
-- Game: Endless Jade Sea -Midori no Umi-

-- MAIN APPLICATION
addappid(925470)

-- MAIN APP DEPOTS / PACKAGES
addappid(925471, 1, "b4a7e02597fd176b2ce594ddf25deb2b7c4af452545889bf427c48623ad3af53")
addappid(925473, 1, "8a2e400550860af17d3005feafb361fb884758a614c019464eaa2fc8e6837cb1")
addappid(961570, 0, "8fcdde8bf20951aa771e0ba904573bab8405f08bbecc69acf792e119a8b9ed41")
addappid(961580, 0, "b5f7eb2a9886d7787ec8f68c3f2e45ea85b2bd5d95145044bf9a498fb03695c2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
