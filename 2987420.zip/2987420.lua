-- Lua provided by RyzenAPI
-- Game: addappid(2987420)

-- MAIN APPLICATION
addappid(2987420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2987421, 1, "5992e71ef36995ccdba87e25c6774aa587b0d49f265d971608b2c378c1f2e2ad")
