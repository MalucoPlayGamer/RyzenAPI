-- Lua provided by RyzenAPI
-- Game: Precursors

-- MAIN APPLICATION
addappid(547930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(547931, 1, "14c6041f424feaaa1af743c5e3e5a43978e086bac6b410699da08cafd1a3a9a8")

