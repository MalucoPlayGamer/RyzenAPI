-- Lua provided by RyzenAPI
-- Game: addappid(547930)

-- MAIN APPLICATION
addappid(547930)

-- MAIN APP DEPOTS / PACKAGES
addappid(547931, 1, "14c6041f424feaaa1af743c5e3e5a43978e086bac6b410699da08cafd1a3a9a8")
