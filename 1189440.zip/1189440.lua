-- Lua provided by RyzenAPI
-- Game: VenusBlood FRONTIER International

-- MAIN APPLICATION
addappid(1189440)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1189441, 1, "59731bc4ba7f8ed991bd4f679fe531057f4db76dc87a3e11d66ba61d37b7440a")
addappid(1189442, 1, "57bcd02eb03a1191990e8f3464c028ef7e0181c1a559a36cce9dc14ebf0add92")

