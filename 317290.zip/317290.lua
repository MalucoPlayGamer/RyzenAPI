-- Lua provided by RyzenAPI
-- Game: Bionic Heart 2

-- MAIN APPLICATION
addappid(317290)

-- MAIN APP DEPOTS / PACKAGES
addappid(317291, 1, "27910aff59a647ad5d876091c74bda0c31006f548fee67d43a124d2eefdb9dd4")
addappid(317540, 0, "899becfea17a2dfc1825d06daf3f10dfe5b2d5778c35a29af1fa4cd08ab197c7")
