-- Lua provided by RyzenAPI
-- Game: addappid(2911100)

-- MAIN APPLICATION
addappid(2911100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911101, 1, "ce105db9066aa4c63d76afa49a2d2f4de72c7bc5342a34a5ac9bb4595f270a3d")
