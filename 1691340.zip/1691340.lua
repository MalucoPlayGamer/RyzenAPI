-- Lua provided by RyzenAPI
-- Game: STEEL HUNTERS

-- MAIN APPLICATION
addappid(1691340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1691341, 1, "ffa4d6dd64223854b047df320dfe448b0bd979de1a92ac9f685b54937cc8849d")

