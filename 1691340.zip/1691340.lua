-- Lua provided by RyzenAPI
-- Game: addappid(1691340)

-- MAIN APPLICATION
addappid(1691340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691341, 1, "ffa4d6dd64223854b047df320dfe448b0bd979de1a92ac9f685b54937cc8849d")
