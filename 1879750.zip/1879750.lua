-- Lua provided by RyzenAPI
-- Game: Game: YONESAWARA HOSPITAL

-- MAIN APPLICATION
addappid(1879750)
-- Game: addappid(1879750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1879751, 1, "8a1da61eb180f9b7c8a387f34ebd1eabd8cc93be81b8b11d6601c852376227a7")
