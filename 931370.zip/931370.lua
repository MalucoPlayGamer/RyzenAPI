-- Lua provided by SkyAPI 
-- Game: Donut County - Original Soundtrack
addappid(931370)
addappid(931371, 1, "ef3ba5db1adc7031bd487c16e4fb49f7cf6f8317ada1e5a22356fa8d733e9b99")
addappid(931372, 1, "1d877e213a14ebc739ba4ed6a583704e619e1f980ec36d88705659291da188c0")
