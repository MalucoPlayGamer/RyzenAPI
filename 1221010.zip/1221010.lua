-- Lua provided by SkyAPI 
-- Game: Senren＊Banka Trial version
addappid(1221010)
addappid(1221011, 1, "3892dd1f30438cf2efdab1bc0bd2e3b62d30cdce4b87b26e4895926965993b58")
