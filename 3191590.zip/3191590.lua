-- Lua provided by RyzenAPI
-- Game: AppID 3191590

-- MAIN APPLICATION
addappid(3191590)
-- Game: addappid(3191590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3191591, 1, "948e0a10f63635a6e47df6f26a6cfef2277d3c9e2cbf1107b976f1c55a15521d")
