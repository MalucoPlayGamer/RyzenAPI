-- Lua provided by RyzenAPI
-- Game: Game: No Time For Caution

-- MAIN APPLICATION
addappid(2085910)
-- Game: addappid(2085910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085911, 1, "4b2ee2446d72468dc8ee8761e80b1954a3e8deddd5db8b315eb04dea73214a75")
