-- Lua provided by RyzenAPI
-- Game: Game: AppID 886300

-- MAIN APPLICATION
addappid(886300)
-- Game: addappid(886300)

-- MAIN APP DEPOTS / PACKAGES
addappid(886301, 1, "35a46d19b9107e37d3724a1e77d1db67ac83fce3a0ad5a23cf9de8d4dd97252a")
