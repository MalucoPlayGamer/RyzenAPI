-- Lua provided by RyzenAPI
-- Game: Game: refarm

-- MAIN APPLICATION
addappid(2857000)
-- Game: addappid(2857000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2857001, 1, "9088d1335ec168c30d94727dcbf95152032da2bf9129301e16f709ea95d52702")
