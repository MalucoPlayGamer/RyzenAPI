-- Lua provided by RyzenAPI
-- Game: addappid(1902890)

-- MAIN APPLICATION
addappid(1902890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1902891, 1, "6885241ebee770121e8edd375a145ec8c5953fa19f3601ef7219f5295c9aa70e")
