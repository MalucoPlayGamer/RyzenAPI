-- Lua provided by RyzenAPI
-- Game: Beat Saber: Gwen Stefani – 'The Sweet Escape ft. Akon'

-- MAIN APPLICATION
addappid(1636346)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636346,0,"71e13b6bab3f411baf9abe5fc93713054b35deab164f0f6e2a4cd244ad8c22b8")

