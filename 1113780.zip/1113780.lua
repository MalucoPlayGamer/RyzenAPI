-- Lua provided by RyzenAPI
-- Game: Uncharted Tides: Port Royal

-- MAIN APPLICATION
addappid(1113780)
-- Game: addappid(1113780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1113781, 1, "ab8dc04793ccac9393b7b146475872b891c7d55a8aa865f84724fd5629ff6eea")
