-- Lua provided by RyzenAPI
-- Game: Succubus Heaven

-- MAIN APPLICATION
addappid(2471660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471661, 1, "e1d2783b94f443f9210a40fdc844c303968fabb90897c8ad95ea534499defbb6")

