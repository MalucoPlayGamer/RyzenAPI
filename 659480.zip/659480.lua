-- Lua provided by RyzenAPI
-- Game: 659480

-- MAIN APPLICATION
addappid(659480)
addappid(690700)
-- Game: addappid(659480)

-- MAIN APP DEPOTS / PACKAGES
addappid(659481, 1, "ccab7746594944e971e0d1d6b25c3af3842be3f1225830593922eeb2db8d3df0")
