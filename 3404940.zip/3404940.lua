-- Lua provided by RyzenAPI
-- Game: Game: 3D Desktop Pets

-- MAIN APPLICATION
addappid(3404940)
-- Game: addappid(3404940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3404941, 1, "33490c39519076b010b82a0e3e3ee616e7b6b69647979ad48e8172734e2c80dc")
