-- Lua provided by RyzenAPI
-- Game: Hentai Cosplay USSR

-- MAIN APPLICATION
addappid(1223250)
addappid(1230970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1223251, 1, "04c5815f9fbd875197c1308e3338d3bf140005e27349ddc70006ff0b94b83551")

