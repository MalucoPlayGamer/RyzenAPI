-- Lua provided by RyzenAPI
-- Game: Exit Kun-Steam Workshop Upload and Management

-- MAIN APPLICATION
addappid(2915580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2915580,0,"8a54eed2b3ffbe511aecf8b5da40d886ef45d00560ab8d7dd7544b70f77ef7f7")

