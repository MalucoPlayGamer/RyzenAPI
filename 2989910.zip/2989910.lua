-- Lua provided by RyzenAPI
-- Game: Tormenture Demo

-- MAIN APPLICATION
addappid(2989910)
-- Game: addappid(2989910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2989911, 1, "fc0b48d25381a60a4297724130455b791f78d1de494b2705aa198f987172424b")
