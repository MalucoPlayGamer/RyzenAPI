-- Lua provided by RyzenAPI
-- Game: Game: BREACH

-- MAIN APPLICATION
addappid(2430870)
-- Game: addappid(2430870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2430871, 1, "a1cb7c5b7a6e7ecc415627e2b56e96ece7dcbd07970a0e0d2dc466834dfb27df")
