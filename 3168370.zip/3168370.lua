-- Lua provided by RyzenAPI
-- Game: Bring Me...

-- MAIN APPLICATION
addappid(3168370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3168371, 1, "10768d45ecb12b0f71c7037b01383edc915db929f04c7ca36c0eec6c720ab0dc")

