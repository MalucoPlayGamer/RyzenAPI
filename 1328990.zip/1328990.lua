-- Lua provided by RyzenAPI
-- Game: addappid(1328990)

-- MAIN APPLICATION
addappid(1328990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328991, 1, "b9e58e79b098867a1aad69b35fa22555511174b817f03ad1535e5ba49a2ea339")
