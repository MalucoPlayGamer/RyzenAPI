-- Lua provided by RyzenAPI
-- Game: 3095750

-- MAIN APPLICATION
addappid(3095750)
-- Game: addappid(3095750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3095751, 1, "e08b3059d9d3cb8de89d96bf9ca96c06717f709386a2894b0a5c1daf5c9332f2")
