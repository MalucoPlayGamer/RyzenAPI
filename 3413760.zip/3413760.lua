-- Lua provided by RyzenAPI
-- Game: M.I.N.S.K. Playtest

-- MAIN APPLICATION
addappid(3413760)
-- Game: addappid(3413760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3413762,0,"f5078e2520009008e0c8e9cac077ff47b19d42d874bf76b287db74735a8c3da8")
addtoken(3413760,"16957441375624260509")
