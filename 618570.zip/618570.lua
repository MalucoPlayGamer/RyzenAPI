-- Lua provided by RyzenAPI
-- Game: Pixel Arcade

-- MAIN APPLICATION
addappid(618570)

-- MAIN APP DEPOTS / PACKAGES
addappid(618571,0,"a7dd7f1b027c1ea5bb06edf656b77f5d669e6d2b214b3426a8fbbddfd94f7757")

