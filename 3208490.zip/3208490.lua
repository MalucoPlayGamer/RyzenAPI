-- Lua provided by RyzenAPI
-- Game: Steam Punks Demo

-- MAIN APPLICATION
addappid(3208490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3208491, 1, "77f7083c3c04e3dd54f684eb11ad89107503838b66151096daad7103077b22c2")
