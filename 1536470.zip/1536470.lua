-- Lua provided by RyzenAPI 
-- Game: A guard walks into a tavern
addappid(1536470)
addappid(1536471, 1, "80707dc2c1770e9045079f644871735b0321b075ffc9177e527ccc7b893234cc")
addappid(1536472, 1, "0739d2056e0a0cc218b6ed9eef500c94df248555837560c14bff719d4c0806f4")
