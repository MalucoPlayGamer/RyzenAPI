-- Lua provided by SkyAPI 
-- Game: AppID 1527850
addappid(1527850)
addappid(1527851, 1, "df312107a7ab55913f3325143f0210af2ba54152958f7829d215880729a5f65a")
