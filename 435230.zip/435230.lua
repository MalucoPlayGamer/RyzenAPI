-- Lua provided by RyzenAPI
-- Game: setManifestid(435232,"3673751097054267144")

-- MAIN APPLICATION
addappid(435230)

-- MAIN APP DEPOTS / PACKAGES
addappid(435232,0,"cee3f40b99bba1be9edf8c6dfb9a1f5712742cdc5001ac5c5f43e925e6b59e34")
