-- Lua provided by SkyAPI 
-- Game: AppID 1308700
addappid(1308700)
addappid(1308701, 1, "8e2cd6a1a36611d2a178edb5ddef89704391742fef5c9384d80a4c93029fc61e")
