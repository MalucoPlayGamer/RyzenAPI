-- Lua provided by RyzenAPI
-- Game: Wizardry: The Five Ordeals

-- MAIN APPLICATION
addappid(1308700)
addappid(1309770)
addappid(1309771)
addappid(1456541)
addappid(2889060)
addappid(4422250)
addappid(4591060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1308701, 1, "8e2cd6a1a36611d2a178edb5ddef89704391742fef5c9384d80a4c93029fc61e")
