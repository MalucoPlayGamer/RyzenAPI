-- Lua provided by RyzenAPI
-- Game: Game: Once upon a time

-- MAIN APPLICATION
addappid(566410)
-- Game: addappid(566410)

-- MAIN APP DEPOTS / PACKAGES
addappid(566411, 1, "76716b6bde443f21c0729587cf7a3dc46ded19894b0f08dcda7e3e6b2c862a58")
