-- Lua provided by RyzenAPI
-- Game: Metal Country

-- MAIN APPLICATION
addappid(1055770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1055771, 1, "fd0c5df02f48500ec1fec6f7d924ef4080e58c87b7820f16ff90f63b06412263")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
