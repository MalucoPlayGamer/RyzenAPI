-- Lua provided by SkyAPI 
-- Game: Metal Country
addappid(1055770)
addappid(1055771, 1, "fd0c5df02f48500ec1fec6f7d924ef4080e58c87b7820f16ff90f63b06412263")
