-- Lua provided by RyzenAPI
-- Game: addappid(1055770)

-- MAIN APPLICATION
addappid(1055770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1055771, 1, "fd0c5df02f48500ec1fec6f7d924ef4080e58c87b7820f16ff90f63b06412263")
