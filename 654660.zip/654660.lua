-- Lua provided by RyzenAPI
-- Game: Pharmakon - Tactical Puzzle

-- MAIN APPLICATION
addappid(654660)

-- MAIN APP DEPOTS / PACKAGES
addappid(654661, 1, "ebfd839c1eda244175e6f07ce0507ca439788a64051f187516bc5fd86e30f164")

