-- Lua provided by RyzenAPI
-- Game: Pharmakon - Tactical Puzzle

-- MAIN APPLICATION
addappid(654660)

-- MAIN APP DEPOTS / PACKAGES
addappid(654661, 1, "ebfd839c1eda244175e6f07ce0507ca439788a64051f187516bc5fd86e30f164")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
