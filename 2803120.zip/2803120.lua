-- Lua provided by RyzenAPI
-- Game: Meta Soulmate Demo

-- MAIN APPLICATION
addappid(2803120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2803121, 1, "b795615a2a720cd4836642bb17501c4f14500ae2d6daa2961ac06de4abc2dc8b")
