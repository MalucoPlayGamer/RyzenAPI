-- Lua provided by RyzenAPI
-- Game: Game: AppID 578830

-- MAIN APPLICATION
addappid(578830)
-- Game: addappid(578830)

-- MAIN APP DEPOTS / PACKAGES
addappid(578831, 1, "663ac6667d862c053e85b178ee8c46622c69be2f315450d0d880c168905fbd51")
