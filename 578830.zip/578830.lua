-- Lua provided by SkyAPI 
-- Game: AppID 578830
addappid(578830)
addappid(578831, 1, "663ac6667d862c053e85b178ee8c46622c69be2f315450d0d880c168905fbd51")
