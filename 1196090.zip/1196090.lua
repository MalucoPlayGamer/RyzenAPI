-- Lua provided by RyzenAPI
-- Game: Scars Above

-- MAIN APPLICATION
addappid(1196090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1196091, 1, "98313c47201079ec1b795e7f7294940e1c585dd04ff55c038eef31ff39ca32f8")
addappid(2334350, 0, "595188717197bf1339aae4ded04f41b3bb9dbe5bf247d38f9a815ad7c4967fbf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
