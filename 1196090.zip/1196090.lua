-- Lua provided by RyzenAPI
-- Game: Game: Scars Above

-- MAIN APPLICATION
addappid(1196090)
-- Game: addappid(1196090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1196091, 1, "98313c47201079ec1b795e7f7294940e1c585dd04ff55c038eef31ff39ca32f8")
addappid(2334350, 0, "595188717197bf1339aae4ded04f41b3bb9dbe5bf247d38f9a815ad7c4967fbf")
