-- Lua provided by RyzenAPI
-- Game: 1054950

-- MAIN APPLICATION
addappid(1054950)
-- Game: addappid(1054950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1054951, 1, "a9068de08fdcb7b2bed81e222a2862aff3979e776d2abd506e5b1a430dc3a4cf")
