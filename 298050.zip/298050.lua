-- Lua provided by RyzenAPI
-- Game: Master of Orion

-- MAIN APPLICATION
addappid(298050)
addappid(456820)
addappid(456821)
addappid(558300)
addappid(558301)
addappid(558302)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(298051, 1, "621aaf910c0593b0ba238a2d44f485ad455788f6d678dbb73e2559a555e27987")
addappid(298053, 1, "4cc655439ad64a12e1561aa282f7009b9c5649d9add45c038e1ea44382e25c5c")
addappid(298054, 1, "ab7012cee84703c4e1208735ea36cc4ab6ff822cee555de511c661ea92cb64c9")
addappid(498200, 0, "79620f58404523b065b1c38bce0290d2481fcd417624ff20cda5b7fec9055520")
