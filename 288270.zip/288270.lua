-- 288270's Lua and Manifest Created by Hubcap Manifest
-- liteCam HD: Capture twitch.tv Live Stream
-- Created: July 10, 2026 at 12:10:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(288270) -- liteCam HD: Capture twitch.tv Live Stream
-- MAIN APP DEPOTS
addappid(288271, 1, "06f3861b4cb396afbd978a4f3b87ba99235a7fb37f07b2f38d9455b7d6e58b61") -- lite Cam HD Content
setManifestid(288271, "8889924261698052098", 55980593)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)