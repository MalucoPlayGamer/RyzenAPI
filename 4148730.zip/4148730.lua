-- Lua provided by RyzenAPI
-- Game: Megastore Simulator: Prologue

-- MAIN APPLICATION
addappid(4148730)

-- MAIN APP DEPOTS / PACKAGES
addappid(4148731,0,"6d285e4911843240870c6843d870581f3955b84266b2abb8ddd3defa2e183c30")
