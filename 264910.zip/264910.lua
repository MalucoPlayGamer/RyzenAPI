-- Lua provided by RyzenAPI
-- Game: AppID 264910

-- MAIN APPLICATION
addappid(264910)

-- MAIN APP DEPOTS / PACKAGES
addappid(264911, 1, "7f137b1ec4e9fe7de0cfb3fa1879774186b61a78b2a162f1718fd57e048d6c73")

