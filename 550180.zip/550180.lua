-- Lua provided by RyzenAPI
-- Game: 550180

-- MAIN APPLICATION
addappid(550180)
-- Game: addappid(550180)

-- MAIN APP DEPOTS / PACKAGES
addappid(550181, 1, "84d836b7f3371e53fdf1e2dc90da3749f29c84072b394f72e19267df93a340f3")
