-- Lua provided by RyzenAPI 
-- Game: AppID 550180
addappid(550180)
addappid(550181, 1, "84d836b7f3371e53fdf1e2dc90da3749f29c84072b394f72e19267df93a340f3")
