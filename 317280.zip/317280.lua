-- Lua provided by RyzenAPI
-- Game: Game: AppID 317280

-- MAIN APPLICATION
addappid(317280)
-- Game: addappid(317280)

-- MAIN APP DEPOTS / PACKAGES
addappid(317281, 1, "233f92102f6a3d18c9cbcef0798139ee29ce540b2db26f349996b79a79160921")
addappid(317282, 1, "bc2f7a45801495416b1052dfcfa67a974787f3fbb17724776d6bee9c783eace2")
