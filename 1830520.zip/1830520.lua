-- Lua provided by RyzenAPI
-- Game: addappid(1830520)

-- MAIN APPLICATION
addappid(1830520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1830521, 1, "aef6f4cd23a66242ba4e1f41d292d67cbd89aef27d79b22507a50e4963d8ff38")
