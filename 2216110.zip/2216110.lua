-- Lua provided by RyzenAPI
-- Game: 枪神出击

-- MAIN APPLICATION
addappid(2216110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2216111, 1, "ffc6c12389893da3d819397844e7214dbae1ccbf715e3a0f9d163fbceb1efd01")
