-- Lua provided by RyzenAPI
-- Game: Game: The Berlin Apartment Demo

-- MAIN APPLICATION
addappid(3153440)
-- Game: addappid(3153440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3153441, 1, "abe7a57e8e951308461e1264752eb12ae520d4bb4fcb02c3a4fbbd50402ae057")
