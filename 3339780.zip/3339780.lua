-- Lua provided by RyzenAPI 
-- Game: Desktop Survivors 98
addappid(3339780)
addappid(3339781, 1, "0a9c417e76754ed4ff6bcde27c0c80b66c47f1b1b0ec8f5708707628e6d642bd")
