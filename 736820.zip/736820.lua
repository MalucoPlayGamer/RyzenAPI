-- Lua provided by RyzenAPI
-- Game: Knights of Honor II: Sovereign

-- MAIN APPLICATION
addappid(736820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(736821, 1, "156e1c92b77e9ff649e567b7add374b0d427f0579ecabe8ff03d61d7065870ad")
