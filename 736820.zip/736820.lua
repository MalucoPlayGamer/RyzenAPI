-- Lua provided by RyzenAPI
-- Game: AppID 736820

-- MAIN APPLICATION
addappid(736820)

-- MAIN APP DEPOTS / PACKAGES
addappid(736821, 1, "156e1c92b77e9ff649e567b7add374b0d427f0579ecabe8ff03d61d7065870ad")

