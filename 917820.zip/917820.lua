-- Lua provided by RyzenAPI
-- Game: Fairtravel Battle CCG

-- MAIN APPLICATION
addappid(917820) -- Fairtravel Battle CCG
addappid(4824390)
-- addappid(917821) -- Depot 917821 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(917822, 1, "d10216a5795b12d0f6a447b821b36dbe4abaf32b44d7e12fcd2c45c6c49e3a12") -- Depot 917822
addappid(917823, 1, "fb4bc1bb67d0a16b76c4d71a55f66a90929e4ea0114fe4d7aa92727b3018a082") -- Depot 917823
addappid(917824, 1, "2b21f54d03424bc3671c540c05424fd41b50d86ef2281ee961c9f42efb94fa15") -- Depot 917824
addappid(917825, 1, "dbaaad143bd1c40d7f8babcc4214e27eeb2a3055c7f20b5edfdc3cc6ae46b563") -- Depot 917825
addappid(917826, 1, "67fdf71f596fbcd41e091dc6a45fe84f40efa9394ce16bf4d75fc89508fd645b") -- Depot 917826
addappid(917827, 1, "8b634a071e374b531a568a76ba631ca2d4ee3a348fa66eee3925a418da3ab2cc") -- Depot 917827
addappid(4824391, 1, "041e53cd86c92e7a0360ffceead3a55bc3a36ac4fb68bdc9b8fee09c8e6d93e3") -- Fairtravel Battle CCG Supporter Pack - Depot 4824391
addappid(4824392, 1, "1a150d071e897d3e8f67c4a3e540e96d2b9b7dda6fa0b2c406a127e13a52ece8") -- Fairtravel Battle CCG Supporter Pack - Depot 4824392
addappid(4824393, 1, "dbcc1acd2f2c4c388cae9215df079ad8352d7e7347cc4bf3814cb51cf825524a") -- Fairtravel Battle CCG Supporter Pack - Depot 4824393

