-- Lua provided by RyzenAPI
-- Game: Game: Retro Three Kingdoms

-- MAIN APPLICATION
addappid(1676980)
-- Game: addappid(1676980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1676981, 1, "0473ff125b247aa4209b34417aa36475f3126cb1d30bedbadcf8100a22a88de3")
