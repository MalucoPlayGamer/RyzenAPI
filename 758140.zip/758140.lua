-- Lua provided by RyzenAPI
-- Game: addappid(758140)

-- MAIN APPLICATION
addappid(758140)

-- MAIN APP DEPOTS / PACKAGES
addappid(758141, 1, "6e605348b15c3dc5c7fbe0f19f6d03721ac303aa61f816039b839a0f68d96cec")
