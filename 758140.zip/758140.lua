-- Lua provided by RyzenAPI 
-- Game: AppID 758140
addappid(758140)
addappid(758141, 1, "6e605348b15c3dc5c7fbe0f19f6d03721ac303aa61f816039b839a0f68d96cec")
