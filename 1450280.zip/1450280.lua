-- Lua provided by RyzenAPI
-- Game: addappid(1450280)

-- MAIN APPLICATION
addappid(1450280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450281, 1, "7b2752c286f8e3550d9d676885e9a525de7ed477abe50b63ede75303eb4db123")
