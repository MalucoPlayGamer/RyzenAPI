-- Lua provided by RyzenAPI
-- Game: addappid(2595080)

-- MAIN APPLICATION
addappid(2595080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2595081, 1, "cd1d75793453b8a6e0dc9b6ac7b656993cbe36a2d35c26de742dcf0b6a566718")
