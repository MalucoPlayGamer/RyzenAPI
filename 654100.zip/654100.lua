-- Lua provided by RyzenAPI
-- Game: Rival Megagun

-- MAIN APPLICATION
addappid(654100)

-- MAIN APP DEPOTS / PACKAGES
addappid(654101, 1, "2a3666f7998f773fd57839b1716d6c03b795dcf8d43f166d70dbf199befff24a")

