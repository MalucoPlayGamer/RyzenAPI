-- Lua provided by RyzenAPI
-- Game: addappid(1094650)

-- MAIN APPLICATION
addappid(1094650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094652,0,"9830dc2b24d648d26c83c29fc43cdaaab49ba70d7d0af9952f9bf073958f3176")
