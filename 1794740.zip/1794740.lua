-- Lua provided by RyzenAPI
-- Game: Fears of Glasses  o-o

-- MAIN APPLICATION
addappid(1794740)
-- Game: addappid(1794740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1794741, 1, "7fc51b96332c7e95e3c9a74e321924728546bde9d98a45258b2fa0afc849d551")
