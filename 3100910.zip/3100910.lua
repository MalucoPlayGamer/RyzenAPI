-- Lua provided by SkyAPI 
-- Game: Play with my balls
addappid(3100910)
addappid(3100911, 1, "b37a0da83ccb22e31ca4d8a67fbb5ddfe9db70b3c8ddbb8883162f9f48800883")
