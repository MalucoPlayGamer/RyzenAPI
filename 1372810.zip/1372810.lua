-- Lua provided by SkyAPI 
-- Game: Teamfight Manager
addappid(1372810)
addappid(1372811, 1, "df6596100d8c79e5b47567902f61ab4351ac02aefa8fdccc6382ce0b44684423")
addappid(1372813, 1, "8d10044d66eae146f1f587e09fd3969e350626d48c277a2f01cc44e6f5a460da")
