-- Lua provided by RyzenAPI
-- Game: AppID 213850

-- MAIN APPLICATION
addappid(213850)
addappid(228982)
addappid(228983)
addappid(228990)
-- Game: addappid(213850)

-- MAIN APP DEPOTS / PACKAGES
addappid(213851, 1, "87ace129bfad8c8ab8c82aced01bb4c47ab8bc881d8460abd1865b2ebad51748")
addappid(213860, 1, "c8ce8f3275cf26accd317dabbc147e32b5b11fa3fad742c78bb32b6f2d93a079")
