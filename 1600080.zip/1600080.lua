-- Lua provided by RyzenAPI
-- Game: Gardens and Girls

-- MAIN APPLICATION
addappid(1600080)
addappid(1689710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600081, 1, "d6baf01513970e77789feb11d556f85e8f9f9b52b898ba8df4f0444e464695a1")

