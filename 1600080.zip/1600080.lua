-- Lua provided by RyzenAPI 
-- Game: Gardens and Girls
addappid(1600080)
addappid(1600081, 1, "d6baf01513970e77789feb11d556f85e8f9f9b52b898ba8df4f0444e464695a1")
