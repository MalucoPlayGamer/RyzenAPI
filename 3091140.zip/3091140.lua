-- Lua provided by RyzenAPI
-- Game: Lootbound

-- MAIN APP DEPOTS / PACKAGES
addappid(3091140, 1, "1f05d6f3ddade4323eb34249f78ed3edae22a7b8d73bbf70c1ca4165965e54ca") -- Lootbound
addappid(3091141, 1, "bfd0833e4e531ac8033b18ae9b79eea5b2ee46b29b62f7959f97caec7547be1c") -- Depot 3091141
addappid(3091142, 1, "487ae9dc13c277989189e32614056f9fc545ad6860e154673c32dfd568b470de") -- Depot 3091142
addappid(3091143, 1, "9f32af5e3cc8ccf9bea79d4f5a5f09f8de74c727d5f64b023cdc40116dbbb9dd") -- Depot 3091143

