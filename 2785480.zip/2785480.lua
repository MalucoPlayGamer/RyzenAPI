-- Lua provided by SkyAPI 
-- Game: Battle Clash
addappid(2785480)
addappid(2785481, 1, "4392e73f305c9d44651798624f866497da1c0fc0ec7335e977b7f0a92d519280")
