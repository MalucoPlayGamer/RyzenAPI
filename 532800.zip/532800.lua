-- Lua provided by RyzenAPI
-- Game: ComPet - Epic Beast Battles

-- MAIN APPLICATION
addappid(532800)

-- MAIN APP DEPOTS / PACKAGES
addappid(532801, 1, "c606e0d12f5da2b18d653fbda6d447a160a39fed3ea623b252bcd090f92acf80")

