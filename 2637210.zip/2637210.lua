-- Lua provided by RyzenAPI
-- Game: Flow Of War

-- MAIN APPLICATION
addappid(2637210) -- Flow Of War

-- MAIN APP DEPOTS / PACKAGES
addappid(2637211, 1, "c23ff6ce338ac7ee35e5c02a862dc9e1d17eb71676a4910680583435bf428ea9") -- Depot 2637211

