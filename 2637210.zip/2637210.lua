-- 2637210's Lua and Manifest Created by Hubcap Manifest
-- Flow Of War
-- Created: August 03, 2026 at 07:24:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2637210) -- Flow Of War
-- MAIN APP DEPOTS
addappid(2637211, 1, "c23ff6ce338ac7ee35e5c02a862dc9e1d17eb71676a4910680583435bf428ea9") -- Depot 2637211
setManifestid(2637211, "584007404247231523", 254434873)