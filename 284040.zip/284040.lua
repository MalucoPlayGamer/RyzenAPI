-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(284040)

-- MAIN APP DEPOTS / PACKAGES
addappid(284040,0,"a73f6c9e1e339115c88efcbf1ad2e75c1728086de24d0b00b64b22709c3f8037")

