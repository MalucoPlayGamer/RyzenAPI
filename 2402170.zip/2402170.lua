-- Lua provided by RyzenAPI
-- Game: Veggie Quest: The Puzzle Game

-- MAIN APPLICATION
addappid(2402170)
addappid(2757020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2402172,0,"0ae86cc954a2443a6def8fc1465092f5b9076f69e7d042acc61d3acb7edf9e7c")

