-- Lua provided by RyzenAPI
-- Game: Weed Simulator

-- MAIN APPLICATION
addappid(3356740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3356741, 1, "647cc0706629b5126fd7ba42176e5e61ab0a9a0138ad2a60b7af50f157aeed90")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
