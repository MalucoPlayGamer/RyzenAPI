-- Lua provided by RyzenAPI
-- Game: Weed Simulator

-- MAIN APPLICATION
addappid(3356740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3356741, 1, "647cc0706629b5126fd7ba42176e5e61ab0a9a0138ad2a60b7af50f157aeed90")

