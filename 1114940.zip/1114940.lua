-- Lua provided by RyzenAPI
-- Game: Game: I Wanna Maker

-- MAIN APPLICATION
addappid(1114940)
-- Game: addappid(1114940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1114941, 1, "2d564317bf8974cf32f0503055f53da131390812658f4ab5066d2d05e2bb487b")
