-- Lua provided by RyzenAPI
-- Game: I Wanna Maker

-- MAIN APPLICATION
addappid(1114940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1114941, 1, "2d564317bf8974cf32f0503055f53da131390812658f4ab5066d2d05e2bb487b")

