-- Lua provided by RyzenAPI
-- Game: Game: Edna & Harvey: The Breakout - Anniversary Edition - Soundtrack

-- MAIN APPLICATION
addappid(1189960)
-- Game: addappid(1189960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1189961, 1, "0fa5cbe1b323605198e26ebcd0da807688674e22527eb58895fa101df694af24")
addappid(1189962, 1, "483bed70c7a6984ca5a3311793495a9059db13b240b885f98bbf0d53a9d6b7ab")
