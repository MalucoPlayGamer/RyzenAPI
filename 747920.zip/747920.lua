-- Lua provided by RyzenAPI
-- Game: Hero Plus

-- MAIN APPLICATION
addappid(747920)
