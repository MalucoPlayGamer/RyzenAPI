-- Lua provided by RyzenAPI
-- Game: RetroDrift: Retrowave Online Road

-- MAIN APPLICATION
addappid(1857140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857141, 1, "ad8f64abf4c0cbdac7ceea1416860d1e91cd534d1117ce5ffecdb8fe059ebb21")
