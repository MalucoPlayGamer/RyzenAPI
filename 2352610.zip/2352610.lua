-- Lua provided by RyzenAPI
-- Game: Chasing the Unseen Demo

-- MAIN APPLICATION
addappid(2352610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2352611, 1, "dbb33f794a0ad78cd905834377f6ed89421ce0ee31e339e7227dcd3d94ec0742")

