-- Lua provided by RyzenAPI
-- Game: 360560

-- MAIN APPLICATION
addappid(360560)
-- Game: addappid(360560)

-- MAIN APP DEPOTS / PACKAGES
addappid(360561, 1, "844db103cbaeed369643505975c589ed068645d92002f7bfebdc6543eab33d59")
