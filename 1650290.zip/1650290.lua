-- Lua provided by RyzenAPI 
-- Game: The Married Manager's Scandalous Services - The Pleasures of the Night Shift
addappid(1650290)
addappid(1650291, 1, "7b4300156d466a5d6c6e7b23b154d0c9f087258c5e9b466282c8ccba612681c6")
addappid(1650292, 1, "c9832a6ef01ad157021f9cc4d29e960e0b11e43ad4448901500a935aa828232b")
