-- Lua provided by RyzenAPI
-- Game: 2605650

-- MAIN APPLICATION
addappid(2605650)
-- Game: addappid(2605650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605650,0,"0f8f8ac8430384cf56fbe67d88b3840c474b0a86599212cddbf3e8cae3807e77")
