-- Lua provided by RyzenAPI
-- Game: 1988710

-- MAIN APPLICATION
addappid(1988710)
-- Game: addappid(1988710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1988711, 1, "a6c31ecca60406bc644b7bbf2fece527a7fb846becfbf6f9e545852c2ca54ce3")
addappid(1988712, 1, "fcc500e75497b65b959e4f204a8bd1cf43aeec305d99c9d1790f6fd795769661")
