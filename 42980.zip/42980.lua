-- Lua provided by RyzenAPI
-- Game: Victoria I Complete

-- MAIN APPLICATION
addappid(42980)

-- MAIN APP DEPOTS / PACKAGES
addappid(42981, 1, "ff89380161c0fa087711e621107fad0dafd5845e0f0bcd2fdfa9c3a1ed18ec16")

