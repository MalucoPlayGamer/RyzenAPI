-- Lua provided by RyzenAPI
-- Game: Pierre's Adventures in French

-- MAIN APPLICATION
addappid(1948870)
addappid(2100580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948871, 1, "a824ab7dddacd4e045a6053bbb069f43b9684e34237334c3b8035b00c60374d0")
