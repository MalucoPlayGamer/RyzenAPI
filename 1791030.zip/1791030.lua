-- Lua provided by RyzenAPI
-- Game: addappid(1791030)

-- MAIN APPLICATION
addappid(1791030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791031, 1, "04f2dd6fd89f1167d8915dac82c31d283c57ae044aa1b2e092fa62ad54bf076e")
