-- Lua provided by RyzenAPI
-- Game: Lovely Planet Arcade

-- MAIN APPLICATION
addappid(436000)

-- MAIN APP DEPOTS / PACKAGES
addappid(436001, 1, "2ebc84a16877798b74b0d1f274dc08c9e2a96c2f6ef1e4354e2f6b35836977f4")
addappid(436002, 1, "0376f7a03c65d1af4f2bade17e6957c1140289f75d6edad3ccc12d920bdd3b0e")
addappid(436003, 1, "5e68a289331ceeff846fe43439e078691dbd630dc45f7792740f382a6a3112f9")
