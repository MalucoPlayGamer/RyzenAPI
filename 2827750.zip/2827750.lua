-- Lua provided by RyzenAPI
-- Game: Fatal Claw

-- MAIN APPLICATION
addappid(2827750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2827751, 1, "6fa752151773dec1703f2ef467723a5fe3f5ec5cfc917b6164e93406eb542bf2")

