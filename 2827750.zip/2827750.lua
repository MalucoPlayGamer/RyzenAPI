-- Lua provided by RyzenAPI
-- Game: Fatal Claw

-- MAIN APPLICATION
addappid(2827750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2827751, 1, "6fa752151773dec1703f2ef467723a5fe3f5ec5cfc917b6164e93406eb542bf2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
