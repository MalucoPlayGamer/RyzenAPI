-- Lua provided by RyzenAPI
-- Game: Wildfrost

-- MAIN APPLICATION
addappid(1811990)
-- Game: addappid(1811990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1811991, 1, "7d4200ce2217d51b0fcbe7eab5e129d459acaeca195aea99d76463c3003eb10a")
