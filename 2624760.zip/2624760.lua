-- Lua provided by RyzenAPI
-- Game: PIMP Life: Sex Simulator 🔞

-- MAIN APPLICATION
addappid(2624760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2624761, 1, "2289aca0aecd349d9727e0eac169378c50276aefd52df4e741572fb2ddc1f2d6")
