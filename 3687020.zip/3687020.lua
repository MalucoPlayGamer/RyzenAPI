-- Lua provided by SkyAPI 
-- Game: WALLS
addappid(3687020)
addappid(3687021, 1, "9a9d233ba3a59d80ce4f7e62cb2f78d63a5a1dffd20b7c0d299c0b3af708d8c7")
