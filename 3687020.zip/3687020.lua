-- Lua provided by RyzenAPI
-- Game: WALLS

-- MAIN APPLICATION
addappid(3687020)

-- MAIN APP DEPOTS / PACKAGES
addappid(3687021, 1, "9a9d233ba3a59d80ce4f7e62cb2f78d63a5a1dffd20b7c0d299c0b3af708d8c7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
