-- Lua provided by RyzenAPI
-- Game: Keyboard Soldier

-- MAIN APPLICATION
addappid(3178910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3178911, 1, "8add7a42860ce4d5832255bab56f85a8b53c4d17ea4eb2b55646fbce0a1f3f9d")

