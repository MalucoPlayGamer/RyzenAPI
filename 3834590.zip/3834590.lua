-- Lua provided by RyzenAPI
-- Game: Now THAT'S a Big Dragon!

-- MAIN APPLICATION
addappid(3834590) -- Now THAT'S a Big Dragon!

-- MAIN APP DEPOTS / PACKAGES
addappid(3834591, 1, "dbd54c0f0fc44b2ab9de20d7fb7f97a37b368f0d0554d323954f69d9505d46f1") -- Depot 3834591
addappid(3834592, 1, "d48335da120235d9a97b4abad2b29e5681c619bd17374a6af7e0e3210753c195") -- Depot 3834592

