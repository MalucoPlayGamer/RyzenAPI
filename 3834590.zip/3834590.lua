-- 3834590's Lua and Manifest Created by Hubcap Manifest
-- Now THAT'S a Big Dragon!
-- Created: August 26, 2026 at 12:21:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3834590) -- Now THAT'S a Big Dragon!
-- MAIN APP DEPOTS
addappid(3834591, 1, "dbd54c0f0fc44b2ab9de20d7fb7f97a37b368f0d0554d323954f69d9505d46f1") -- Depot 3834591
setManifestid(3834591, "1040072014758859075", 270113218)
addappid(3834592, 1, "d48335da120235d9a97b4abad2b29e5681c619bd17374a6af7e0e3210753c195") -- Depot 3834592
setManifestid(3834592, "631835812769675614", 261608711)