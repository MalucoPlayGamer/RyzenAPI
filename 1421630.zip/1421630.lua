-- Lua provided by RyzenAPI
-- Game: Stars Force

-- MAIN APPLICATION
addappid(1421630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1421631, 1, "292eb14b65a51b29b6e216432c88d813abe3314eefe503f14b288eede963e4be")
