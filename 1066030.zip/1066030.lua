-- Lua provided by RyzenAPI
-- Game: Heroland

-- MAIN APPLICATION
addappid(1066030)
-- Game: addappid(1066030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1066031, 1, "a05adea61f10fdfc23b5ab3ff34873e75670bddd514da6f2af18dae7f7ddb3fa")
