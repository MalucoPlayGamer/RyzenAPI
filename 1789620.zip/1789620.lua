-- Lua provided by RyzenAPI
-- Game: Brimstone Manor

-- MAIN APPLICATION
addappid(1789620)
-- Game: addappid(1789620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1789621, 1, "c208efb3699cf8a4a2dc06b4ed0011885ee5bd290fe3a175919435ea6fca3b1f")
