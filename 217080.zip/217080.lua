-- Lua provided by RyzenAPI
-- Game: Doctor Who: The Eternity Clock

-- MAIN APPLICATION
addappid(217080)

-- MAIN APP DEPOTS / PACKAGES
addappid(217081, 1, "c87066b478b489443b96e91b34e31dbea9f91fe6cafba502f3c462ceae4b421d")
addappid(217082, 1, "bb5351c06c0f7238ba5d638ac4c3a8181cd4708038e2d88c378bd2714da1299d")

