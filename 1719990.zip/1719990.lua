-- Lua provided by RyzenAPI
-- Game: SnakeLaw Island

-- MAIN APPLICATION
addappid(1719990)
-- Game: addappid(1719990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1719991, 1, "373b0b0439eca2271c428a96f9b6176f97b15d0423eb1be00e00c655ac828143")
