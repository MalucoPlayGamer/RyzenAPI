-- Lua provided by RyzenAPI
-- Game: Backrooms: Escape Together Playtest

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2172390)
addappid(2172391)
addappid(2172392)

-- MAIN APP DEPOTS / PACKAGES
addappid(2141732,0,"1038f744a70ce5b445cdbfc9ce77601ae45a36279d0a9ad02b59b714acfba762")

