-- Lua provided by RyzenAPI
-- Game: Game: AppID 843350

-- MAIN APPLICATION
addappid(843350)
-- Game: addappid(843350)

-- MAIN APP DEPOTS / PACKAGES
addappid(843351, 1, "13d98342911b2601005667404f7512a2d46af3eb14c4fb0d7b68127d924b15b9")
