-- Lua provided by RyzenAPI
-- Game: Turok

-- MAIN APPLICATION
addappid(405820)

-- MAIN APP DEPOTS / PACKAGES
addappid(405821, 1, "de91936b56f62ac1d0024bb432568e28865b657cfe6eacd1626430f516b01cbb")
addappid(405822, 1, "eb7606a23f80255909a0b05a3c8f71932b097c7bfe3c05b77b2ec32bd6476498")
addappid(405823, 1, "d980041d22de4be97b20d31396109720c6f3f445f3bdd457629c09847e2aee6b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
