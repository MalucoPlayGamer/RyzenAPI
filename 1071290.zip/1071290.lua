-- Lua provided by RyzenAPI
-- Game: Game: Wild West and Wizards

-- MAIN APPLICATION
addappid(1071290)
-- Game: addappid(1071290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071291, 1, "424e333b87fd4e15f7bb9c0fffeebef00e6894406e5e3d3ac336e4b0b2476dd0")
