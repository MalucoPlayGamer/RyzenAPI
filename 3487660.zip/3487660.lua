-- Lua provided by RyzenAPI
-- Game: addappid(3487660)

-- MAIN APPLICATION
addappid(3487660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3487661, 1, "87b69472cff1d543dc34c87f551cf34b73c3aad356cd710f54999b842e6db186")
