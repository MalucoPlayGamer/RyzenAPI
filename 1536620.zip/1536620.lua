-- Lua provided by RyzenAPI
-- Game: addappid(1536620)

-- MAIN APPLICATION
addappid(1536620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536622,0,"d080d42f19b883b12c3c87548cd56cb41f8ffc44671e4fb3391b82b7037078fd")
