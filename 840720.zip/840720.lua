-- Lua provided by RyzenAPI
-- Game: Sword Art Online: Lost Song

-- MAIN APPLICATION
addappid(840720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(840721, 1, "282ecd196d0e2a73c81f4e36f9e4aa0171b8917838aad8eb1010cc7ba4cefeed")

