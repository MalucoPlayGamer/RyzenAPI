-- Lua provided by RyzenAPI
-- Game: addappid(840720)

-- MAIN APPLICATION
addappid(840720)

-- MAIN APP DEPOTS / PACKAGES
addappid(840721, 1, "282ecd196d0e2a73c81f4e36f9e4aa0171b8917838aad8eb1010cc7ba4cefeed")
