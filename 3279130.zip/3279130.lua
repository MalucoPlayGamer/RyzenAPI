-- Lua provided by RyzenAPI
-- Game: Crypto Mining Demo

-- MAIN APPLICATION
addappid(3279130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3279131, 1, "a73d1350f82652d3cc1828cbc282e637e533b77dee4981e6670076141daa8afa")

