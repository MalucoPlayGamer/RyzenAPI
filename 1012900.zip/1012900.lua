-- Lua provided by RyzenAPI
-- Game: AppID 1012900

-- MAIN APPLICATION
addappid(1012900)
-- Game: addappid(1012900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1012901, 1, "d971e7826ccf1bcaa1e6f7b100c91dd248567e0acaf5f1ff3e5c09d1008be2fc")
addappid(1012902, 1, "e83cc9802bf5c71ddaef895398d84b2fed37de089cf8cc31e7bb9b38dae27621")
