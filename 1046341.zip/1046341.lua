-- Lua provided by RyzenAPI
-- Game: 1046341

-- MAIN APPLICATION
addappid(1046341)
-- Game: addappid(1046341)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046341,0,"a84a9e1bbbfbc53be90deb90b80fdb348e0d39b0908c4fd8559ba17f3c8528b0")
