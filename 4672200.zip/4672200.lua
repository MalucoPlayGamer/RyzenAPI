-- Lua provided by RyzenAPI
-- Game: 捉迷藏 - Hide and Seek

-- MAIN APPLICATION
addappid(4672200)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4851770)
addappid(4851780)
