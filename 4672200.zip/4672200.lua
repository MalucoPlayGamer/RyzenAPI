-- Lua provided by RyzenAPI
-- Game: 捉迷藏 - Hide and Seek

-- MAIN APPLICATION
addappid(4672200)
