-- Lua provided by RyzenAPI
-- Game: 1997490

-- MAIN APPLICATION
addappid(1997490)
-- Game: addappid(1997490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997491, 1, "7e76563beaa4cf4d083c45670138ccce38bd989cf6722b6c3eb0cdc56e0a622e")
