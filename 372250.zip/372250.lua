-- Lua provided by RyzenAPI
-- Game: Turnover

-- MAIN APPLICATION
addappid(372250)

-- MAIN APP DEPOTS / PACKAGES
addappid(372251, 1, "c4ce9e7cc72961701052a10555fb86cb291690c42de3fccd81a36604feba5d94")
addappid(372252, 1, "2033413db89b89bf980b336c47bf98bdbd44007917eca226663950661861278c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
