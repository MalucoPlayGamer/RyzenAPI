-- Lua provided by RyzenAPI
-- Game: addappid(1791310)

-- MAIN APPLICATION
addappid(1791310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1791311, 1, "97dd67c9a060320e6910c9855c90ddfeae49f5bc7325761b1027a439ca9c26eb")
