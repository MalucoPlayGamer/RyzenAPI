-- Lua provided by RyzenAPI
-- Game: Memento Infernum

-- MAIN APPLICATION
addappid(1581050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581051, 1, "8546178b5defe81df2db2160035caa22968cf78954d6c705a73ae02cf1025838")
addappid(1581052, 1, "f211318e649db0ce767daf65e0b0a0d3b6e25e780253cf99f17eb89ecc9ae13d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
