-- Lua provided by RyzenAPI
-- Game: Memento Infernum

-- MAIN APPLICATION
addappid(1581050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581051, 1, "8546178b5defe81df2db2160035caa22968cf78954d6c705a73ae02cf1025838")
addappid(1581052, 1, "f211318e649db0ce767daf65e0b0a0d3b6e25e780253cf99f17eb89ecc9ae13d")

