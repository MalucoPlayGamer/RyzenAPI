-- Lua provided by SkyAPI 
-- Game: Dracoslayer
addappid(2623430)
addappid(2623431, 1, "2be930ba4a168ab039f853aaf729c48c72f8ac3f3a132a19c9c0e2f52decaea7")
