-- Lua provided by RyzenAPI
-- Game: Dracoslayer

-- MAIN APPLICATION
addappid(2623430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623431, 1, "2be930ba4a168ab039f853aaf729c48c72f8ac3f3a132a19c9c0e2f52decaea7")

