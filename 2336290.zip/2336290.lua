-- Lua provided by RyzenAPI
-- Game: Game: Well...

-- MAIN APPLICATION
addappid(2336290)
-- Game: addappid(2336290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336291, 1, "36ccdf74fb48edd3cc8734a562935c5c8aab3b2c0dd70ea89c171d61d641fa98")
