-- Lua provided by RyzenAPI
-- Game: Dragon Ruins

-- MAIN APPLICATION
addappid(2929540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2929541, 1, "10b9506e1f0fd94d58ef327e6ccd18d213796c38982c06dc89711108964799bc")
