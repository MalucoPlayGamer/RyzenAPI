-- Lua provided by RyzenAPI
-- Game: Game: Clan N

-- MAIN APPLICATION
addappid(982670)
-- Game: addappid(982670)

-- MAIN APP DEPOTS / PACKAGES
addappid(982671, 1, "cfe594a62229b6066444e007173117bfd0c70821ac98d5922accca64c1988ee9")
