-- Lua provided by RyzenAPI
-- Game: Clan N

-- MAIN APPLICATION
addappid(982670)

-- MAIN APP DEPOTS / PACKAGES
addappid(982671, 1, "cfe594a62229b6066444e007173117bfd0c70821ac98d5922accca64c1988ee9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
