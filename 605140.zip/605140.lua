-- Lua provided by RyzenAPI
-- Game: Kings of Lorn: The Fall of Ebris

-- MAIN APPLICATION
addappid(605140)

-- MAIN APP DEPOTS / PACKAGES
addappid(605143,0,"389c62860346b34c3cf29a07ce1a1911dd744995d1dc78479630fa0d5c55c8e7")

