-- Lua provided by RyzenAPI
-- Game: Kings of Lorn: The Fall of Ebris

-- MAIN APPLICATION
addappid(605140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(605143,0,"389c62860346b34c3cf29a07ce1a1911dd744995d1dc78479630fa0d5c55c8e7")

