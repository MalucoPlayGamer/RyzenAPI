-- Lua provided by RyzenAPI 
-- Game: AppID 955060
addappid(955060)
addappid(955061, 1, "11e38ea52ea877ecb0ac5a5acc87112aca01c5ff0146f082e24d27255adb9932")
