-- Lua provided by RyzenAPI
-- Game: Chef Survivor

-- MAIN APPLICATION
addappid(2506780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506781, 1, "c18d4d2f683d7a4b5021f8a2e49339843ec5e7525c35474fc5ece345559dac80")

