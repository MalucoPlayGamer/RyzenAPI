-- Lua provided by RyzenAPI
-- Game: Verne: The Shape of Fantasy

-- MAIN APPLICATION
addappid(1424600)
-- Game: addappid(1424600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1424601, 1, "c092c21877337d6ad22799d9bc115e2a8364448d321a5dab86667ba4b1394465")
