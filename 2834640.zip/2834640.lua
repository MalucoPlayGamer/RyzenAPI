-- Lua provided by RyzenAPI
-- Game: AppID 2834640

-- MAIN APPLICATION
addappid(2834640)
-- Game: addappid(2834640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2834641, 1, "d8f35c49180b4198f54fa5ae054bd1d917b273e8ef8033add207857f6715beae")
