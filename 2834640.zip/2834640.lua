-- Lua provided by SkyAPI 
-- Game: AppID 2834640
addappid(2834640)
addappid(2834641, 1, "d8f35c49180b4198f54fa5ae054bd1d917b273e8ef8033add207857f6715beae")
