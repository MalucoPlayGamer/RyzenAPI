-- Lua provided by RyzenAPI
-- Game: Quantum Break

-- MAIN APPLICATION
addappid(229002)
addappid(474960)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(474963,0,"774d54ab593c1c10dcc394a9b53aff6cdf77f7ac8f0182f73b9baeb5d3e3f74e")

