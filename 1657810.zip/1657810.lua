-- Lua provided by RyzenAPI
-- Game: Combots

-- MAIN APPLICATION
addappid(1657810)
addappid(1680860)
addappid(1681210)
addappid(1681220)
addappid(1847650)
addappid(1847660)
addappid(1847670)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1657811, 1, "56c42973947d07e3a262694383392cca9d3a66a24503628fccb05f06714ea955")

