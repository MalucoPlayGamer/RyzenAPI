-- Lua provided by RyzenAPI
-- Game: Game: Combots

-- MAIN APPLICATION
addappid(1657810)
-- Game: addappid(1657810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1657811, 1, "56c42973947d07e3a262694383392cca9d3a66a24503628fccb05f06714ea955")
