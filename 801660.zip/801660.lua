-- Lua provided by RyzenAPI
-- Game: Swapper Tiles

-- MAIN APPLICATION
addappid(801660)

-- MAIN APP DEPOTS / PACKAGES
addappid(801661, 1, "e3d52290e46911cde4a33a4ce6ebcb865901cc9cb08c131bca8c461c673f26e4")

