-- Lua provided by SkyAPI 
-- Game: AppID 1299430
addappid(1299430)
addappid(1299431, 1, "605841238efe4bf11bd8d6099c70aac6d97fe47d663b72e6d9e79622e28c15db")
addappid(1299432, 1, "65a68f326c21c0b6a3d0200b0e3a8c7b3508e3332754f78c996eaa820da8c7b9")
