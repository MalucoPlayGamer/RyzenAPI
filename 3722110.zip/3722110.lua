-- Lua provided by RyzenAPI
-- Game: Galaxy Highways Soundtrack

-- MAIN APPLICATION
addappid(3722110)
-- Game: addappid(3722110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3722111, 1, "7b6d91a584e2378c042d03a0e70076422fe25c7c778a72151df04670614ab3ee")
addappid(3722112, 1, "7dea044343104cc28becf9b4a93886f5accbfb12e1f2de26444a328e65d89d8f")
