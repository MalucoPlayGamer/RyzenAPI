-- Lua provided by RyzenAPI
-- Game: 1802710

-- MAIN APPLICATION
addappid(1802710)
-- Game: addappid(1802710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802711, 1, "efefa2a23c0112e13a7cd3198cd6120833afacadc276fda80874af59c1af0504")
addappid(1802712, 1, "08d634f951ebc26371df13ec1e57280541c63f9818fefe7e4f82784d57a2d830")
