-- Lua provided by RyzenAPI
-- Game: Game: Poly Puzzle: Birds

-- MAIN APPLICATION
addappid(1908740)
-- Game: addappid(1908740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1908741, 1, "0ba5e6cddb9979b48dee148b89dcdd403fbf0fb8607459320921245dcede1943")
