-- Lua provided by RyzenAPI
-- Game: RESCUE 2: Everyday Heroes

-- MAIN APPLICATION
addappid(339210)
-- Game: addappid(339210)

-- MAIN APP DEPOTS / PACKAGES
addappid(339211, 1, "8385c7cf7f915e9fb46e4c975c1a993429dff1e14bc369e2ba2d9342fe5d35f7")
addappid(339212, 1, "84a686a4c93907c82ab16a7d3c939d1534c2896f13e931526bb3c2435d80731f")
