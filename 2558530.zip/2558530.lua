-- Lua provided by RyzenAPI
-- Game: The Discrete Era Demo

-- MAIN APPLICATION
addappid(2558530)
-- Game: addappid(2558530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2558531, 1, "2f09fd266390e6dc0523689e6fc5236ca3fbd6551931901354fd1a094f0c7264")
