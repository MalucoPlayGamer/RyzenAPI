-- Lua provided by RyzenAPI
-- Game: Azooma Escape

-- MAIN APPLICATION
addappid(2896760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2896761,0,"00fb982a00a8841eedaa031a2f7a335956be3e924df8de62d1091170264312fa")

