-- Lua provided by RyzenAPI
-- Game: Crystar - Sen's Santa Costume

-- MAIN APPLICATION
addappid(1070056)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070056,0,"77275c465ca9f25c85bc3e762eb1bf28b561576a5c093a4e357f980aa20e2f15")

