-- Lua provided by RyzenAPI
-- Game: Weird West - The Bounty Hunter Journey

-- MAIN APPLICATION
addappid(2063780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063781, 1, "050ab0754cfd216c2a8e47ded8638622644c8e5d6ad5c7fb9061f1486174b068")
