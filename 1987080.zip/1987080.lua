-- Lua provided by RyzenAPI 
-- Game: Inside the Backrooms
addappid(1987080)
addappid(1987081, 1, "6118f908f294c8f78dfe8b12bdf321b389553909a48dc2283805d8c3ecf0eca3")
