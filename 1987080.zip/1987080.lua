-- Lua provided by RyzenAPI
-- Game: Inside the Backrooms

-- MAIN APPLICATION
addappid(1987080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1987081, 1, "6118f908f294c8f78dfe8b12bdf321b389553909a48dc2283805d8c3ecf0eca3")
