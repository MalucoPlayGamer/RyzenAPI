-- 4275920's Lua and Manifest Created by Hubcap Manifest
-- Pickochet
-- Created: July 22, 2026 at 08:03:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4275920) -- Pickochet
-- MAIN APP DEPOTS
addappid(4275921, 1, "899e6b37444ce82c7827acceeafd5234786bdf1bcbfb181be90aaf92b1bf29c5") -- Depot 4275921
setManifestid(4275921, "1060801044107711153", 120231272)