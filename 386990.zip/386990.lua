-- Lua provided by RyzenAPI
-- Game: Asphyxia

-- MAIN APPLICATION
addappid(386990)

-- MAIN APP DEPOTS / PACKAGES
addappid(386991, 1, "14cd78eac4f99e9d7b9b89d585be497ab25f77dde2326c7da1396649b08884d3")

