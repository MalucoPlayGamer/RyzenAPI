-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3197070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3197070,0,"d3bdd3f3f02f51765aa43481349d480fece40a93db387e7d9cf15030577601a0")
