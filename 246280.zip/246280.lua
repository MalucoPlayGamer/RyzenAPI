-- Lua provided by RyzenAPI
-- Game: AppID 246280

-- MAIN APPLICATION
addappid(246280)
addappid(306330)
addappid(318070)
addappid(318071)
addappid(318072)
addappid(318073)
addappid(318074)
addappid(318075)
addappid(318076)
addappid(318077)
addappid(318078)

-- MAIN APP DEPOTS / PACKAGES
addappid(246281, 1, "25e0c796a892c43d00d493fc702789f6cfc9b9e9de736d843bedaadfb38c8e8d")
addappid(246282, 1, "fc2d4321d3f19bc799f23bd47eba080352f6137d4fd874250ad95c1f5a600b80")
addappid(246284, 1, "4fb1d99226090cd74e9ef45874aa157fce70163311a9705d3d6b90f75ee662bc")
