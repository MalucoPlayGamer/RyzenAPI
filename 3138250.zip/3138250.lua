-- Lua provided by RyzenAPI
-- Game: Game: The Spirit and the Mouse (Original Game Soundtrack)

-- MAIN APPLICATION
addappid(3138250)
-- Game: addappid(3138250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3138251, 1, "d20feef51d9c6ab9aa3ef667df14bddf906eaa78026a23565bfff41f1565cd08")
addappid(3138252, 1, "eddb0fb66de5028c419ed8d27259065d9133955ccb96a38f6f726355ff9a5f38")
