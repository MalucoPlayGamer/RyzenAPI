-- Lua provided by RyzenAPI
-- Game: Game: Match it Sexy: FREE

-- MAIN APPLICATION
addappid(2567520)
-- Game: addappid(2567520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2567521, 1, "f4253c1577794256320d1c5a84cc04fac28a64f78ca18c7daf8ad875d9711948")
