-- Lua provided by RyzenAPI
-- Game: Zoo Empire

-- MAIN APPLICATION
addappid(286750)

-- MAIN APP DEPOTS / PACKAGES
addappid(286751, 1, "ad35ebe06d06cdbb32da511a7b9cf74748692f50bc37103f4d84195f522040e9")

