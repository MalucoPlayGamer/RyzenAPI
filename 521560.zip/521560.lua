-- Lua provided by RyzenAPI 
-- Game: The Mystery Of Woolley Mountain
addappid(521560)
addappid(521561, 1, "a51af15fee7d93bcb774d7b92917c0fc3359f46aac16d2e757d4b24018f2f0bc")
addappid(1091120)
