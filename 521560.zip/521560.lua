-- Lua provided by RyzenAPI
-- Game: The Mystery Of Woolley Mountain

-- MAIN APPLICATION
addappid(521560)
addappid(1091120)
addappid(1264780)
addappid(1883900)
addappid(2913960)
addappid(2913970)

-- MAIN APP DEPOTS / PACKAGES
addappid(521561, 1, "a51af15fee7d93bcb774d7b92917c0fc3359f46aac16d2e757d4b24018f2f0bc")

