-- Lua provided by RyzenAPI
-- Game: Tales of Monkey Island Complete Pack: Chapter 3 - Lair of the Leviathan

-- MAIN APPLICATION
addappid(31190)

-- MAIN APP DEPOTS / PACKAGES
addappid(31191, 1, "cef4b106b8b784b8aef53d287b6cfd4dee4fec7a6f1c9db2d2deafa58c7db360")
addappid(31192, 1, "15a26cf25158193917e1dc1b7432da2550576797640d39212c9b54134a0e4612")
addappid(31193, 1, "5eb1a6f7f76ae2375b53efa612d93aa5e24abe22cb5b4fae87d1f8f39dbfbaf0")
addappid(31194, 1, "437393af5f46502e6e63411e5c9eb3ff445b1d20b4093f92d1537d4a73596d4a")
