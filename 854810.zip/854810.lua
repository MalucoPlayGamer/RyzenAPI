-- Lua provided by RyzenAPI
-- Game: Simple Sailing

-- MAIN APPLICATION
addappid(854810)

-- MAIN APP DEPOTS / PACKAGES
addappid(854811, 1, "c7d6529f5b0f727add8271a8706dd07a2fe9077f4955834b4bcdcec0a38ec393")
addappid(854812, 1, "f172192e1dc6fdaac987f169e621dcdeae7b5cba979f051f0ac5f5daf5ddf8b5")
addappid(854813, 1, "af5d19c78f10c5bdb8d8d2f1bd8f358de840a4bdf968e0b46579151dd6d0eacc")
addappid(854814, 1, "6750fbe371dc122d4d844aa5d82e8f1ee9b9ad1e0bbc8ef07d52bd25a2869b8c")
