-- Lua provided by RyzenAPI
-- Game: Cthulhu Saves Christmas

-- MAIN APPLICATION
addappid(1057540)
addappid(1214970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057541, 1, "be44e852a47aeb9d9322023eede9f44b7a2d05a1a3c43d3adeb063ee47216b73")
