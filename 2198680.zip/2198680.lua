-- Lua provided by RyzenAPI 
-- Game: Dead Town Tales
addappid(2198680)
addappid(2198681, 1, "a14e878515c4283f5be0184b8c8c93ee88d43e5d6fc92c151eb4abc91370e49f")
