-- Lua provided by RyzenAPI
-- Game: Cast of the Seven Godsends - Redux

-- MAIN APPLICATION
addappid(373360)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(373361, 1, "eda19585af96227950f550efcb1a416821b792693c644e2158edadd8b1883a23")
addappid(377540, 0, "3aeb1e33129d64811e899af3285da408621187886043957ccb3605e7eba08626")

