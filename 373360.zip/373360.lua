-- Lua provided by RyzenAPI
-- Game: Game: Cast of the Seven Godsends - Redux

-- MAIN APPLICATION
addappid(373360)
-- Game: addappid(373360)

-- MAIN APP DEPOTS / PACKAGES
addappid(373361, 1, "eda19585af96227950f550efcb1a416821b792693c644e2158edadd8b1883a23")
addappid(377540, 0, "3aeb1e33129d64811e899af3285da408621187886043957ccb3605e7eba08626")
