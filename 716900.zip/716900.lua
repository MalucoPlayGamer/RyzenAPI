-- Lua provided by RyzenAPI 
-- Game: El Ministerio del Tiempo VR: Salva el tiempo
addappid(716900)
addappid(716901, 1, "f0a76ccd8f232b2b999eacf54d80334c6b38b3559b663f828db8f07b4473cb69")
