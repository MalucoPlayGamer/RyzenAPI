-- Lua provided by RyzenAPI
-- Game:  

-- MAIN APPLICATION
addappid(1813510)
-- Game: addappid(1813510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813510,0,"a08368b568b4d67abb143610c8611ffc242610c90a91cc055639ec8b76c4ee6d")
