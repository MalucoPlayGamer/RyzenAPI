-- Lua provided by RyzenAPI
-- Game: 348730

-- MAIN APPLICATION
addappid(348730)
-- Game: addappid(348730)

-- MAIN APP DEPOTS / PACKAGES
addappid(348731, 1, "7bbfd09d89035d6994039af9960c86c0c4f0e138adaa970b44d0843d77305341")
