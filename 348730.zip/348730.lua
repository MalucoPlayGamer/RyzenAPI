-- Lua provided by RyzenAPI
-- Game: Abyss Raiders: Uncharted

-- MAIN APPLICATION
addappid(348730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(348731, 1, "7bbfd09d89035d6994039af9960c86c0c4f0e138adaa970b44d0843d77305341")

