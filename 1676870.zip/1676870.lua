-- Lua provided by SkyAPI 
-- Game: ECO HOLE
addappid(1676870)
addappid(1676871, 1, "5a9df0781409792e17895d41da818044d4acc502e215dbb73603104819955eb1")
