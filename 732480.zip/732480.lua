-- Lua provided by RyzenAPI
-- Game: Jam Session VR

-- MAIN APPLICATION
addappid(732480)

-- MAIN APP DEPOTS / PACKAGES
addappid(732481, 1, "99591315b9114f4bc8543fcd83b589c98b170298b9ab7dc61a85cc199e96d414")

