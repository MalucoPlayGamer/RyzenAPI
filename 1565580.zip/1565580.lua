-- Lua provided by RyzenAPI
-- Game: Mini Island: Spring

-- MAIN APPLICATION
addappid(1565580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1565581, 1, "5bacd0cd3311a70028b16c906fd87ba82078c2e3687ce7ee077162e7f2cd1b26")

