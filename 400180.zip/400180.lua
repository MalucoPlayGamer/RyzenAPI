-- Lua provided by RyzenAPI
-- Game: Game: Okhlos: Omega

-- MAIN APPLICATION
addappid(400180)
-- Game: addappid(400180)

-- MAIN APP DEPOTS / PACKAGES
addappid(400181, 1, "adaedf67deb487d3d2341b2d226e0a94e5b37cf0bf70c62fadac31a3e0688c90")
addappid(400182, 1, "1408aab6d2f912cc833bf1f3d8305ca77ebc2aa907dd083e1750aadb0343df05")
addappid(400183, 1, "65c3474feb6b239c3e17102d23e24375fe52fef14fd0d323344919683be3281a")
addappid(509030, 0, "0b090adb0e6d397b6a1b6bff55fd903ce312abfba4661fe2fd645dac030fe4ff")
addappid(509031, 1, "0531c7ee4707ee6d03c15a7f03f5bd0f6367b9bad9e5b67aee4024935d9d46d4")
addappid(509032, 1, "d1a2ca37f07d848a2897f31043de349b0d760ea71a0d2ff859e80f2e4b2e0918")
