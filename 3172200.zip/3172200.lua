-- Lua provided by RyzenAPI 
-- Game: AppID 3172200
addappid(3172200)
addappid(3172201, 1, "46fe58ac71aff3a0c571511d079f7b95123a15c26bcaa442232eea725400f8f4")
