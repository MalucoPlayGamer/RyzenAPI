-- Lua provided by RyzenAPI 
-- Game: Biosys Inc
addappid(486410)
addappid(486411, 1, "4e33249a2c46e6e7ee6dea6e481c0e82e23ca756d9696e6beb17474bea88b075")
