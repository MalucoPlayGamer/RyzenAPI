-- 3530820's Lua and Manifest Created by Hubcap Manifest
-- Puzzling Places - 3D Jigsaw Sim
-- Created: August 07, 2026 at 07:40:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 48
-- Total DLCs: 22
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3530820, 1, "45a8a3b67445c00cc434d435b98d8a2d3b682567772fb37fd334efea9ccfe8cb") -- Puzzling Places - 3D Jigsaw Sim
-- MAIN APP DEPOTS
addappid(3530821, 1, "d28d9ecbd7a185726b6707775ae43a63f67a9a88a2f563555f9e7c7482833a18") -- Depot 3530821
setManifestid(3530821, "64371455859764693", 3339845199)
addappid(3530822, 1, "9b358bca6583f3f1213e89631fbbaf414dd1655e03e99db976b235271442fb5c") -- Depot 3530822
setManifestid(3530822, "6838249236545187526", 2790706937)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Puzzling Places - Ancient Egypt (AppID: 4521570)
addappid(4521570)
addappid(4521570, 1, "69098482169fb44c3906e9e74d3b5bb116f15378cbd9f3d61390f7fe5a31ed6e") -- Puzzling Places - Ancient Egypt - Depot 4521570
setManifestid(4521570, "2889222473828851158", 575487995)
addappid(4521571, 1, "5b5bf302d82f47706792f2b97aa321e01c51c4fc80dc80e33f2b8dd05988e920") -- Puzzling Places - Ancient Egypt - Depot 4521571
setManifestid(4521571, "460229155350148176", 595871669)
-- Puzzling Places - Behind High Walls (AppID: 4684150)
addappid(4684150)
addappid(4684150, 1, "54ee7e61b2e9390d128362a473828eec1897f60053d3352a42fa872362be5780") -- Puzzling Places - Behind High Walls - Depot 4684150
setManifestid(4684150, "3914728631193577390", 485856137)
addappid(4684151, 1, "802069885b7c9662890a421809e1591d76a449c27bcd8ead976721a13dd1b373") -- Puzzling Places - Behind High Walls - Depot 4684151
setManifestid(4684151, "6266933288979453387", 508137454)
-- Puzzling Places - Mars Desert Research Station (AppID: 4684160)
addappid(4684160)
addappid(4684160, 1, "0f9a24c2c73736b921e17447ac56ad314601157f7594217ff25d807c7e7150fb") -- Puzzling Places - Mars Desert Research Station - Depot 4684160
setManifestid(4684160, "8001738725155318886", 438772319)
addappid(4684161, 1, "0e9becf1211cdf8e9157f6a70896717701e4ef1f8ce0da9f210c1887c0b55261") -- Puzzling Places - Mars Desert Research Station - Depot 4684161
setManifestid(4684161, "4465632267227814212", 483868921)
-- Puzzling Places - Variety Pack Vol. 2 (AppID: 4684170)
addappid(4684170)
addappid(4684170, 1, "f2819b4b1ef2fe56fbb213c7110fc5468bdbab838288abb4b8be4c2d021045b2") -- Puzzling Places - Variety Pack Vol. 2 - Depot 4684170
setManifestid(4684170, "3400958953092385432", 417898348)
addappid(4684171, 1, "05dbb05f567447ae777abe8ab76eeb4e8753023b6a07b9ba44361265ba9a3863") -- Puzzling Places - Variety Pack Vol. 2 - Depot 4684171
setManifestid(4684171, "8315589150841444670", 445721870)
-- Puzzling Places - World Heritage Tour (AppID: 4684180)
addappid(4684180)
addappid(4684180, 1, "bab6dc2c1da58d52d16a498e3d383c15eb6b624433bb44e912bac45a62129832") -- Puzzling Places - World Heritage Tour - Depot 4684180
setManifestid(4684180, "3444394987201113202", 839086445)
addappid(4684181, 1, "ee4bd7cdf4b3dffef9e8c8c0fe8e4eaf0cf680aff9048dc9e7decfc6d189f744") -- Puzzling Places - World Heritage Tour - Depot 4684181
setManifestid(4684181, "7919651334918549747", 869485831)
-- Puzzling Places - New York City (AppID: 4684190)
addappid(4684190)
addappid(4684190, 1, "2b4f62aa48879ce80ab6c65cd2258bfc62c40ffd3e3a5613da629a647b9d4b94") -- Puzzling Places - New York City - Depot 4684190
setManifestid(4684190, "7309438852398777436", 636555636)
addappid(4684191, 1, "0c88cb0b6d1619f96001fe49becb1b999f8254fc1e092c3b90026d46181aade1") -- Puzzling Places - New York City - Depot 4684191
setManifestid(4684191, "2100183225163521171", 662953478)
-- Puzzling Places - Return to Greece (AppID: 4684200)
addappid(4684200)
addappid(4684200, 1, "3f292fdb1aa2342b6c7579feb645beab80f0326175e5d3717102dffd840cd629") -- Puzzling Places - Return to Greece - Depot 4684200
setManifestid(4684200, "7796684893367065027", 681194036)
addappid(4684201, 1, "01748a7612b1852db6ff187f7e2d2e087cf04db1e993c54cf97bd96533a94dbd") -- Puzzling Places - Return to Greece - Depot 4684201
setManifestid(4684201, "9168013043778373866", 705550035)
-- Puzzling Places - Tokyo (AppID: 4684210)
addappid(4684210)
addappid(4684210, 1, "2eec44927bee894f0dfbb15b085a397f76f24d7e11af59857053a094ada047b0") -- Puzzling Places - Tokyo - Depot 4684210
setManifestid(4684210, "7419808101917236702", 670583059)
addappid(4684211, 1, "09b46ae2d358f85b29c7d2a76f0edfb2e7003608d034990a68272b701e30ad0c") -- Puzzling Places - Tokyo - Depot 4684211
setManifestid(4684211, "4874387286796955744", 715221964)
-- Puzzling Places - Springtime Pack (AppID: 4684220)
addappid(4684220)
addappid(4684220, 1, "749e5f80467e43a156cd32fcb14369e54104ef374368b48f14a6fe4b0f4a2b86") -- Puzzling Places - Springtime Pack - Depot 4684220
setManifestid(4684220, "5151314684834782986", 989510817)
addappid(4684221, 1, "4896de1ed9fb0e07f439af36fa0eda12ab3a5137f2b8aff02f527fcb15982893") -- Puzzling Places - Springtime Pack - Depot 4684221
setManifestid(4684221, "5025754354346673048", 1032553230)
-- Puzzling Places - Halloween Special The Haunted House (AppID: 4684270)
addappid(4684270)
addappid(4684270, 1, "773bfd97ed26fd6965cf42bdedd4be721927d0f5b2d818b3e83764bba4a306fc") -- Puzzling Places - Halloween Special The Haunted House - Depot 4684270
setManifestid(4684270, "9074017546950543955", 174673356)
addappid(4684271, 1, "f11a8b190e8936ae5fc34dd83a04c45604999637bd122e58178f37e506dd6785") -- Puzzling Places - Halloween Special The Haunted House - Depot 4684271
setManifestid(4684271, "8395084801265719619", 173176656)
-- Puzzling Places - Halloween Special Draculas Dinner (AppID: 4684280)
addappid(4684280)
addappid(4684280, 1, "2ab057ec90f13f1b6ffad29db3115c3be104fe364974d3e4857bd7520b4e7d9b") -- Puzzling Places - Halloween Special Draculas Dinner - Depot 4684280
setManifestid(4684280, "5567069452135800627", 171749476)
addappid(4684281, 1, "5564b3d502d3a65e34418f66bce9d19720131acef95d66a2e06e55c6e1ab3b8c") -- Puzzling Places - Halloween Special Draculas Dinner - Depot 4684281
setManifestid(4684281, "1729392741261606809", 155781196)
-- Puzzling Places - Holiday Special Driving Home for Christmas (AppID: 4684290)
addappid(4684290)
addappid(4684290, 1, "f2729465d3cfe2a9f6c2dccd6786498a944c615ec0dba7250f6486a24b08a68c") -- Puzzling Places - Holiday Special Driving Home for Christmas - Depot 4684290
setManifestid(4684290, "4337998478539558837", 301985244)
addappid(4684291, 1, "0d7f96f69d01f17f5a6f24f89b4c210de1e2147b61f3701e9846327265d08efe") -- Puzzling Places - Holiday Special Driving Home for Christmas - Depot 4684291
setManifestid(4684291, "2445220112481066122", 309515776)
-- Puzzling Places - Monastery of Batalha Day  Night (AppID: 4684310)
addappid(4684310)
addappid(4684310, 1, "7ad8283b2b409372994323c538326607eac37d3e99f2b62d5afd769aaa35e817") -- Puzzling Places - Monastery of Batalha Day  Night - Depot 4684310
setManifestid(4684310, "8378612961776873541", 311581693)
addappid(4684311, 1, "042f164da9bd4a923ac9d4397e5c79ef0ffc6a22d7351395c9d013836349dbec") -- Puzzling Places - Monastery of Batalha Day  Night - Depot 4684311
setManifestid(4684311, "1823902472258294985", 278607274)
-- Puzzling Places - Summer Dive (AppID: 4684340)
addappid(4684340)
addappid(4684340, 1, "370f905ab736de42b5395db652af5b1cb3b4faaeea826908b05c9e6818926684") -- Puzzling Places - Summer Dive - Depot 4684340
setManifestid(4684340, "5242972443224540441", 323160533)
addappid(4684341, 1, "4a7b278feb771268dc3c68e2985058f4be572510cc0a488f23b4b429f25093e8") -- Puzzling Places - Summer Dive - Depot 4684341
setManifestid(4684341, "4512964842198925260", 299602098)
-- Puzzling Places - Halloween Special Undead Afterparty (AppID: 4684350)
addappid(4684350)
addappid(4684350, 1, "7dceaa6f8d8fb50061afc951f00778c242badd7a47a1a44b90757f35bcbf3038") -- Puzzling Places - Halloween Special Undead Afterparty - Depot 4684350
setManifestid(4684350, "6128793547576644595", 346406850)
addappid(4684351, 1, "fec09b2d25d69d92882747400e561e0cf3b372f9c9c456cb149bf26f7c21bf3f") -- Puzzling Places - Halloween Special Undead Afterparty - Depot 4684351
setManifestid(4684351, "2685870513290878078", 345005755)
-- Puzzling Places - A Painters Dream (AppID: 4684360)
addappid(4684360)
addappid(4684360, 1, "5dfee3eb430726acfbcdbb0198ea051b18936b10026e047a64819b5e8e7f2f67") -- Puzzling Places - A Painters Dream - Depot 4684360
setManifestid(4684360, "4130188389798352861", 308552307)
addappid(4684361, 1, "d77fd7f12ce51288beb12b6e0a20248fc2179b7236485e414b51250a968cb0c3") -- Puzzling Places - A Painters Dream - Depot 4684361
setManifestid(4684361, "9045530687438397121", 305077263)
-- Puzzling Places - The Kings Port (AppID: 4684370)
addappid(4684370)
addappid(4684370, 1, "b8ad4221c928e1909531624e85deb804496ed6000a37a156215ffb10e553e824") -- Puzzling Places - The Kings Port - Depot 4684370
setManifestid(4684370, "4921343948836722422", 296977480)
addappid(4684371, 1, "de4129c012fb38858f941ca58a03ea169efc7c60a16066fac631f78885ec9bfd") -- Puzzling Places - The Kings Port - Depot 4684371
setManifestid(4684371, "4713660588150436044", 293731203)
-- Puzzling Places - Our Planet Earth (AppID: 4684380)
addappid(4684380)
addappid(4684380, 1, "70ef98a5a5a049c7978458cdf3eb66baf01c88c34a1ada8c839fc169070d3c89") -- Puzzling Places - Our Planet Earth - Depot 4684380
setManifestid(4684380, "3643488411969981708", 368021586)
addappid(4684381, 1, "cfe383b96523d7c7fe1ae33fface903cb6c32e10cf0bed95e841e548fc91b311") -- Puzzling Places - Our Planet Earth - Depot 4684381
setManifestid(4684381, "3930791960913313701", 366540426)
-- Puzzling Places - Monthly Pack 44 - Inside  Out (AppID: 4791780)
addappid(4791780)
addappid(4791780, 1, "ee3b6d09867f97d54b10a9ebe78548dbc7c3800a60490766bc60ca6178d17de5") -- Puzzling Places - Monthly Pack 44 - Inside  Out - Depot 4791780
setManifestid(4791780, "3509588573595706761", 1035519247)
addappid(4791781, 1, "aab5f0ae3ed76d536af216a49d2d460eebd2bf0a1caf6ebc3bee0b44dc42c644") -- Puzzling Places - Monthly Pack 44 - Inside  Out - Depot 4791781
setManifestid(4791781, "5108976189848609117", 1067380661)
-- Puzzling Places - Dinosaur Disaster (AppID: 4857290)
addappid(4857290)
addappid(4857290, 1, "2c965868e84ad0c4b0d74ebefc6bf8b871c683a4ecc229bbed8d4a512ccd5916") -- Puzzling Places - Dinosaur Disaster - Depot 4857290
setManifestid(4857290, "354010349433369266", 305763164)
addappid(4857291, 1, "89332f2487a01935cfab8f40bef10702c2e2eadc8938f1764c0ade9f6a5d433e") -- Puzzling Places - Dinosaur Disaster - Depot 4857291
setManifestid(4857291, "3719837178906419526", 299846353)
-- Puzzling Places - Monthly Pack 45 (AppID: 4857300)
addappid(4857300)
addappid(4857300, 1, "052c38ca081e8da6cccbe6863a615ee38cc637961c2e8ef7aac0f8c0be6b87d2") -- Puzzling Places - Monthly Pack 45 - Depot 4857300
setManifestid(4857300, "8610826412995551567", 904866669)
addappid(4857301, 1, "bb4cc48f915f989ce842fb769b5e76cbc7562c1f19385d9af0a33b6347a88e15") -- Puzzling Places - Monthly Pack 45 - Depot 4857301
setManifestid(4857301, "1030829611847935056", 929499829)
-- Puzzling Places - Monthly Pack 46 - Faraway Lands (AppID: 4940820)
addappid(4940820)
addappid(4940820, 1, "2217563cb1e1d2e95375d1ab4e13f3d3e36d24e7b9e3e1fb90b9881260932863") -- Puzzling Places - Monthly Pack 46 - Faraway Lands - Depot 4940820
setManifestid(4940820, "7858906946929617680", 987598803)
addappid(4940821, 1, "38c1d584fc2aae036f10d77b013d5dc3f04f77851a5c23db9acf789f7d3c34dd") -- Puzzling Places - Monthly Pack 46 - Faraway Lands - Depot 4940821
setManifestid(4940821, "4041878062580632720", 1028910390)