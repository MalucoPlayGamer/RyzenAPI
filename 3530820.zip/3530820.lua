-- Lua provided by RyzenAPI
-- Game: Puzzling Places - 3D Jigsaw Sim

-- MAIN APPLICATION
addappid(4521570)
addappid(4684150)
addappid(4684160)
addappid(4684170)
addappid(4684180)
addappid(4684190)
addappid(4684200)
addappid(4684210)
addappid(4684220)
addappid(4684270)
addappid(4684280)
addappid(4684290)
addappid(4684310)
addappid(4684340)
addappid(4684350)
addappid(4684360)
addappid(4684370)
addappid(4684380)
addappid(4791780)
addappid(4857290)
addappid(4857300)
addappid(4940820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3530820, 1, "45a8a3b67445c00cc434d435b98d8a2d3b682567772fb37fd334efea9ccfe8cb") -- Puzzling Places - 3D Jigsaw Sim
addappid(3530821, 1, "d28d9ecbd7a185726b6707775ae43a63f67a9a88a2f563555f9e7c7482833a18") -- Depot 3530821
addappid(3530822, 1, "9b358bca6583f3f1213e89631fbbaf414dd1655e03e99db976b235271442fb5c") -- Depot 3530822
addappid(4521570, 1, "69098482169fb44c3906e9e74d3b5bb116f15378cbd9f3d61390f7fe5a31ed6e") -- Puzzling Places - Ancient Egypt - Depot 4521570
addappid(4521571, 1, "5b5bf302d82f47706792f2b97aa321e01c51c4fc80dc80e33f2b8dd05988e920") -- Puzzling Places - Ancient Egypt - Depot 4521571
addappid(4684150, 1, "54ee7e61b2e9390d128362a473828eec1897f60053d3352a42fa872362be5780") -- Puzzling Places - Behind High Walls - Depot 4684150
addappid(4684151, 1, "802069885b7c9662890a421809e1591d76a449c27bcd8ead976721a13dd1b373") -- Puzzling Places - Behind High Walls - Depot 4684151
addappid(4684160, 1, "0f9a24c2c73736b921e17447ac56ad314601157f7594217ff25d807c7e7150fb") -- Puzzling Places - Mars Desert Research Station - Depot 4684160
addappid(4684161, 1, "0e9becf1211cdf8e9157f6a70896717701e4ef1f8ce0da9f210c1887c0b55261") -- Puzzling Places - Mars Desert Research Station - Depot 4684161
addappid(4684170, 1, "f2819b4b1ef2fe56fbb213c7110fc5468bdbab838288abb4b8be4c2d021045b2") -- Puzzling Places - Variety Pack Vol. 2 - Depot 4684170
addappid(4684171, 1, "05dbb05f567447ae777abe8ab76eeb4e8753023b6a07b9ba44361265ba9a3863") -- Puzzling Places - Variety Pack Vol. 2 - Depot 4684171
addappid(4684180, 1, "bab6dc2c1da58d52d16a498e3d383c15eb6b624433bb44e912bac45a62129832") -- Puzzling Places - World Heritage Tour - Depot 4684180
addappid(4684181, 1, "ee4bd7cdf4b3dffef9e8c8c0fe8e4eaf0cf680aff9048dc9e7decfc6d189f744") -- Puzzling Places - World Heritage Tour - Depot 4684181
addappid(4684190, 1, "2b4f62aa48879ce80ab6c65cd2258bfc62c40ffd3e3a5613da629a647b9d4b94") -- Puzzling Places - New York City - Depot 4684190
addappid(4684191, 1, "0c88cb0b6d1619f96001fe49becb1b999f8254fc1e092c3b90026d46181aade1") -- Puzzling Places - New York City - Depot 4684191
addappid(4684200, 1, "3f292fdb1aa2342b6c7579feb645beab80f0326175e5d3717102dffd840cd629") -- Puzzling Places - Return to Greece - Depot 4684200
addappid(4684201, 1, "01748a7612b1852db6ff187f7e2d2e087cf04db1e993c54cf97bd96533a94dbd") -- Puzzling Places - Return to Greece - Depot 4684201
addappid(4684210, 1, "2eec44927bee894f0dfbb15b085a397f76f24d7e11af59857053a094ada047b0") -- Puzzling Places - Tokyo - Depot 4684210
addappid(4684211, 1, "09b46ae2d358f85b29c7d2a76f0edfb2e7003608d034990a68272b701e30ad0c") -- Puzzling Places - Tokyo - Depot 4684211
addappid(4684220, 1, "749e5f80467e43a156cd32fcb14369e54104ef374368b48f14a6fe4b0f4a2b86") -- Puzzling Places - Springtime Pack - Depot 4684220
addappid(4684221, 1, "4896de1ed9fb0e07f439af36fa0eda12ab3a5137f2b8aff02f527fcb15982893") -- Puzzling Places - Springtime Pack - Depot 4684221
addappid(4684270, 1, "773bfd97ed26fd6965cf42bdedd4be721927d0f5b2d818b3e83764bba4a306fc") -- Puzzling Places - Halloween Special The Haunted House - Depot 4684270
addappid(4684271, 1, "f11a8b190e8936ae5fc34dd83a04c45604999637bd122e58178f37e506dd6785") -- Puzzling Places - Halloween Special The Haunted House - Depot 4684271
addappid(4684280, 1, "2ab057ec90f13f1b6ffad29db3115c3be104fe364974d3e4857bd7520b4e7d9b") -- Puzzling Places - Halloween Special Draculas Dinner - Depot 4684280
addappid(4684281, 1, "5564b3d502d3a65e34418f66bce9d19720131acef95d66a2e06e55c6e1ab3b8c") -- Puzzling Places - Halloween Special Draculas Dinner - Depot 4684281
addappid(4684290, 1, "f2729465d3cfe2a9f6c2dccd6786498a944c615ec0dba7250f6486a24b08a68c") -- Puzzling Places - Holiday Special Driving Home for Christmas - Depot 4684290
addappid(4684291, 1, "0d7f96f69d01f17f5a6f24f89b4c210de1e2147b61f3701e9846327265d08efe") -- Puzzling Places - Holiday Special Driving Home for Christmas - Depot 4684291
addappid(4684310, 1, "7ad8283b2b409372994323c538326607eac37d3e99f2b62d5afd769aaa35e817") -- Puzzling Places - Monastery of Batalha Day  Night - Depot 4684310
addappid(4684311, 1, "042f164da9bd4a923ac9d4397e5c79ef0ffc6a22d7351395c9d013836349dbec") -- Puzzling Places - Monastery of Batalha Day  Night - Depot 4684311
addappid(4684340, 1, "370f905ab736de42b5395db652af5b1cb3b4faaeea826908b05c9e6818926684") -- Puzzling Places - Summer Dive - Depot 4684340
addappid(4684341, 1, "4a7b278feb771268dc3c68e2985058f4be572510cc0a488f23b4b429f25093e8") -- Puzzling Places - Summer Dive - Depot 4684341
addappid(4684350, 1, "7dceaa6f8d8fb50061afc951f00778c242badd7a47a1a44b90757f35bcbf3038") -- Puzzling Places - Halloween Special Undead Afterparty - Depot 4684350
addappid(4684351, 1, "fec09b2d25d69d92882747400e561e0cf3b372f9c9c456cb149bf26f7c21bf3f") -- Puzzling Places - Halloween Special Undead Afterparty - Depot 4684351
addappid(4684360, 1, "5dfee3eb430726acfbcdbb0198ea051b18936b10026e047a64819b5e8e7f2f67") -- Puzzling Places - A Painters Dream - Depot 4684360
addappid(4684361, 1, "d77fd7f12ce51288beb12b6e0a20248fc2179b7236485e414b51250a968cb0c3") -- Puzzling Places - A Painters Dream - Depot 4684361
addappid(4684370, 1, "b8ad4221c928e1909531624e85deb804496ed6000a37a156215ffb10e553e824") -- Puzzling Places - The Kings Port - Depot 4684370
addappid(4684371, 1, "de4129c012fb38858f941ca58a03ea169efc7c60a16066fac631f78885ec9bfd") -- Puzzling Places - The Kings Port - Depot 4684371
addappid(4684380, 1, "70ef98a5a5a049c7978458cdf3eb66baf01c88c34a1ada8c839fc169070d3c89") -- Puzzling Places - Our Planet Earth - Depot 4684380
addappid(4684381, 1, "cfe383b96523d7c7fe1ae33fface903cb6c32e10cf0bed95e841e548fc91b311") -- Puzzling Places - Our Planet Earth - Depot 4684381
addappid(4791780, 1, "ee3b6d09867f97d54b10a9ebe78548dbc7c3800a60490766bc60ca6178d17de5") -- Puzzling Places - Monthly Pack 44 - Inside  Out - Depot 4791780
addappid(4791781, 1, "aab5f0ae3ed76d536af216a49d2d460eebd2bf0a1caf6ebc3bee0b44dc42c644") -- Puzzling Places - Monthly Pack 44 - Inside  Out - Depot 4791781
addappid(4857290, 1, "2c965868e84ad0c4b0d74ebefc6bf8b871c683a4ecc229bbed8d4a512ccd5916") -- Puzzling Places - Dinosaur Disaster - Depot 4857290
addappid(4857291, 1, "89332f2487a01935cfab8f40bef10702c2e2eadc8938f1764c0ade9f6a5d433e") -- Puzzling Places - Dinosaur Disaster - Depot 4857291
addappid(4857300, 1, "052c38ca081e8da6cccbe6863a615ee38cc637961c2e8ef7aac0f8c0be6b87d2") -- Puzzling Places - Monthly Pack 45 - Depot 4857300
addappid(4857301, 1, "bb4cc48f915f989ce842fb769b5e76cbc7562c1f19385d9af0a33b6347a88e15") -- Puzzling Places - Monthly Pack 45 - Depot 4857301
addappid(4940820, 1, "2217563cb1e1d2e95375d1ab4e13f3d3e36d24e7b9e3e1fb90b9881260932863") -- Puzzling Places - Monthly Pack 46 - Faraway Lands - Depot 4940820
addappid(4940821, 1, "38c1d584fc2aae036f10d77b013d5dc3f04f77851a5c23db9acf789f7d3c34dd") -- Puzzling Places - Monthly Pack 46 - Faraway Lands - Depot 4940821



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4911590)
addappid(4911600)
addappid(4911610)
addappid(4911620)
addappid(4911630)
addappid(4911640)
addappid(4911650)
addappid(4911660)
addappid(4911670)
addappid(4911680)
addappid(4938840)
addappid(4938850)
addappid(4938860)
addappid(4938870)
addappid(4938880)
addappid(4938890)
addappid(4938900)
addappid(4938910)
addappid(4938920)
addappid(4938930)
addappid(5027140)
addappid(5027160)
addappid(5027170)
addappid(5027180)
addappid(5027190)
addappid(5027200)
addappid(5027210)
addappid(5027220)
addappid(5027230)
addappid(5027240)
