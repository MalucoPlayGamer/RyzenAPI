-- Lua provided by RyzenAPI
-- Game: Bad Meme

-- MAIN APPLICATION
addappid(1298340)
addappid(1317300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1298341, 1, "4798a0e47875cf66efa09e254dbcd5ef3dde1fcbe4a6c229966ae60913c0ccb3")
