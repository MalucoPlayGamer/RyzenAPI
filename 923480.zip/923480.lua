-- Lua provided by RyzenAPI
-- Game: Game: Strategist

-- MAIN APPLICATION
addappid(923480)
-- Game: addappid(923480)

-- MAIN APP DEPOTS / PACKAGES
addappid(923481, 1, "4d454c81cd69b7c44d426dd4b74177f4d835ba5bc6914874ca1dc36ded91e335")
