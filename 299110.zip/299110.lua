-- Lua provided by RyzenAPI
-- Game: Theatre Of The Absurd

-- MAIN APPLICATION
addappid(299110)

-- MAIN APP DEPOTS / PACKAGES
addappid(299111, 1, "ba58dd5b7f67ea4118df8745a246cf56d660ee101a86cca406f01908dced0fb9")

