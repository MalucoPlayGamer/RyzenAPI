-- Lua provided by SkyAPI 
-- Game: AppID 299110
addappid(299110)
addappid(299111, 1, "ba58dd5b7f67ea4118df8745a246cf56d660ee101a86cca406f01908dced0fb9")
