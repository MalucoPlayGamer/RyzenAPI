-- Lua provided by RyzenAPI
-- Game: addappid(332070)

-- MAIN APPLICATION
addappid(332070)

-- MAIN APP DEPOTS / PACKAGES
addappid(332071, 1, "e158988449785ada735b7bc13fa8e771f7fb1363685839c3979bee55c73db8b0")
