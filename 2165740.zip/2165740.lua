-- Lua provided by RyzenAPI
-- Game: SokoFrog

-- MAIN APPLICATION
addappid(2165740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2165742,0,"b00b397d9bd4eb28ee3dc41fdfb59c1d18c74e98e49146250440ea28601ffd9a")
