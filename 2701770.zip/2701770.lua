-- Lua provided by RyzenAPI
-- Game: addappid(2701770)

-- MAIN APPLICATION
addappid(2701770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2701771, 1, "f3242f8e326739d455dd342c1799a2dab3a69533b4aebe6a4994a1fa30620053")
