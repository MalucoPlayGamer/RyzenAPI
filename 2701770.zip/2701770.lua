-- Lua provided by SkyAPI 
-- Game: AppID 2701770
addappid(2701770)
addappid(2701771, 1, "f3242f8e326739d455dd342c1799a2dab3a69533b4aebe6a4994a1fa30620053")
