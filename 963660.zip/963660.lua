-- Lua provided by SkyAPI 
-- Game: Write word
addappid(963660)
addappid(963661, 1, "fb805a855f33952640f6ab071e62edf0a8fd9ee3c0a92f78dd5bda7e2ca14651")
