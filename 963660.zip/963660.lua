-- Lua provided by RyzenAPI
-- Game: Write word

-- MAIN APPLICATION
addappid(963660)
-- Game: addappid(963660)

-- MAIN APP DEPOTS / PACKAGES
addappid(963661, 1, "fb805a855f33952640f6ab071e62edf0a8fd9ee3c0a92f78dd5bda7e2ca14651")
