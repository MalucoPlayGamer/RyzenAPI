-- Lua provided by RyzenAPI
-- Game: Kunitsu-Gami: Path of the Goddess

-- MAIN APPLICATION
addappid(2510710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2510711, 1, "0442261b453491b8ff8a733d5e971bcff7a9ac403c434f7ff65852c56a63701a")
addappid(2510712, 1, "dff8a57d0e0c043f126fab74bfc97bf9b19a598fee37b6e831cfd76c607aba74")
addappid(2831770, 0, "6eecfc662590d9a66247a70614b99864499bb2656c5b7ca7d17443b5d86aa06c")
addappid(2831780, 0, "a9497030c311c9e6d7fac9080132b08471d895e55938fa5c60eaf06682bf4b17")
addappid(2831860, 0, "67d8cc7a1a5c2bd4d55006bc14817f180545b0d4af84b52a09cbdbd8b4eddaee")
