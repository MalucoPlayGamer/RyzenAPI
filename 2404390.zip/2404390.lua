-- Lua provided by SkyAPI 
-- Game: B.E.S.T
addappid(2404390)
addappid(2404391, 1, "5d8d29659c12b8e99311c773599f78045adcf1503d8192e9199bbecc92abb1ce")
addappid(2722810, 0, "e5e30ddb394c56c59908d49d962e8f4585b64ce809af786875214692a0721f42")
