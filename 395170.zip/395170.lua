-- Lua provided by RyzenAPI
-- Game: 395170

-- MAIN APPLICATION
addappid(395170)
-- Game: addappid(395170)

-- MAIN APP DEPOTS / PACKAGES
addappid(395171, 1, "3752cf88832905a9cde92c6c40b87e3e6140fc7fee05cf876be15b5ffd0977b1")
