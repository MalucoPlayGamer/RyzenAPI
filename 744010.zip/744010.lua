-- Lua provided by RyzenAPI 
-- Game: Mount Hill
addappid(744010)
addappid(744011, 1, "5fa7071e79c7d852d4a4a34074ad83d76c1067da0e4f003d046c14e3851297d4")
