-- Lua provided by RyzenAPI
-- Game: Mage Arena

-- MAIN APPLICATION
addappid(3716600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3716601, 1, "e310c1b9ef27e0d9ec00ac3593dc3851ee94ffa39699fed48341039f9ec50fc6")
