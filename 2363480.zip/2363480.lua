-- Lua provided by RyzenAPI
-- Game: Fantasy Quest Prologue

-- MAIN APPLICATION
addappid(2363480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2363481, 1, "c87a712176eadff10887d0eced8a1638f9f31e04181c96ae062baa4ef39049e2")

