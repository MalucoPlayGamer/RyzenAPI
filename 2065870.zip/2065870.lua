-- Lua provided by RyzenAPI
-- Game: Prescience

-- MAIN APPLICATION
addappid(2065870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2065871, 1, "4b693ead9d9112ab2b7a1d019250cbd4a72cb5f9fc27a00d204f0ffe6af0f4fe")

