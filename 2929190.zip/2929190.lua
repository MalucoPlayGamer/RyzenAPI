-- Lua provided by RyzenAPI
-- Game: Game: Delic Demo

-- MAIN APPLICATION
addappid(2929190)
-- Game: addappid(2929190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2929191, 1, "7797d78245868c8d02a7fe69826cb4e6a94cc877841f495740857a2ca014ea02")
