-- Lua provided by RyzenAPI
-- Game: Trainz Trouble

-- MAIN APPLICATION
addappid(319300)

-- MAIN APP DEPOTS / PACKAGES
addappid(319301, 1, "5703923ac829c6372a834b494d04438e19dc34be9cbae669ed1bf9093c2c7500")

