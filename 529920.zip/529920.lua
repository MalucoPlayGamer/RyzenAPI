-- Lua provided by RyzenAPI
-- Game: Game: Resurgence

-- MAIN APPLICATION
addappid(529920)
-- Game: addappid(529920)

-- MAIN APP DEPOTS / PACKAGES
addappid(529921, 1, "cf4c630390f79c55bb81e6ab569dc835398023e160acafa20a5a4f3c03ca8fa1")
