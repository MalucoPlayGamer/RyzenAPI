-- Lua provided by RyzenAPI
-- Game: Asteroides

-- MAIN APPLICATION
addappid(1815170)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1815171, 1, "2bb3b010011920a11f2b039006565c9eb313b4846b07b7a1559d2d6a3f4293b1")
addappid(1815172, 1, "d404f2af6364d3b8dc9944fe7f2b51618310d56b2f4ed2311556a9c8ddc291bf")

