-- Lua provided by RyzenAPI
-- Game: Game: Asteroides

-- MAIN APPLICATION
addappid(1815170)
-- Game: addappid(1815170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815171, 1, "2bb3b010011920a11f2b039006565c9eb313b4846b07b7a1559d2d6a3f4293b1")
addappid(1815172, 1, "d404f2af6364d3b8dc9944fe7f2b51618310d56b2f4ed2311556a9c8ddc291bf")
