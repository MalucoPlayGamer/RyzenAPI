-- Lua provided by RyzenAPI
-- Game: addappid(2737700)

-- MAIN APPLICATION
addappid(2737700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2737701, 1, "ede74d4dcd62d9907da1084ac732ab4a25634f7122381303065ff11ebce31ab2")
