-- Lua provided by RyzenAPI
-- Game: Russian Subway Dogs

-- MAIN APPLICATION
addappid(762610)

-- MAIN APP DEPOTS / PACKAGES
addappid(762611, 1, "19da37f43be4164802d2255a4017022240df261d1439fa882a417ae550d0084f")
