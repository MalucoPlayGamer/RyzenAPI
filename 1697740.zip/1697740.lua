-- Lua provided by SkyAPI 
-- Game: Dungeon Coup Demo
addappid(1697740)
addappid(1697741, 1, "a815b6fa86a4c9cffbe6bf702a8f946bc2eac76b8e8d20c0eb4a3b78892749a8")
