-- Lua provided by RyzenAPI
-- Game: Quest for Glory Collection

-- MAIN APPLICATION
addappid(502750)

-- MAIN APP DEPOTS / PACKAGES
addappid(502751, 1, "d504e1f1fb04429e56900944866701c2c3ecea028151f34cdb38707b7cbb13b6")
