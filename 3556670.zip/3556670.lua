-- Lua provided by RyzenAPI
-- Game: Beach Invasion 1915-Gallipoli

-- MAIN APPLICATION
addappid(3556670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3556671, 1, "c78d83acb0ace1d4c3678d3ee77fe8e5a4ebb63e252f97449d28487374d1f251")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
