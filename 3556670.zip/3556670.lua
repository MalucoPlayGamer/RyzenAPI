-- Lua provided by RyzenAPI
-- Game: Beach Invasion 1915-Gallipoli

-- MAIN APPLICATION
addappid(3556670)
-- Game: addappid(3556670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3556671, 1, "c78d83acb0ace1d4c3678d3ee77fe8e5a4ebb63e252f97449d28487374d1f251")
