-- Lua provided by RyzenAPI
-- Game: AppID 291190

-- MAIN APPLICATION
addappid(291190)

-- MAIN APP DEPOTS / PACKAGES
addappid(291191, 1, "6cfd095c5d3be7862fa09cd27aad1afe5530c15005dd402f7d122cb28d3b5916")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
