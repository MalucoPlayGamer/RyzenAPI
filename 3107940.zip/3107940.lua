-- Lua provided by RyzenAPI
-- Game: Game: Maniac Path 3

-- MAIN APPLICATION
addappid(3107940)
-- Game: addappid(3107940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107941, 1, "5db7758275dc0887bea03a6e094ad2acbd5cdf086a074a39b579918987cb563c")
