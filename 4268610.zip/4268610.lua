-- Lua provided by RyzenAPI
-- Game: Isekai Sex Kingdom 👑

-- MAIN APPLICATION
addappid(4268610)

-- MAIN APP DEPOTS / PACKAGES
addappid(4268611,0,"ca7db71da3b576c19dfd7a0f540da183b8d84c7572464a177d4833a2ca7df13f")
addappid(4417780,0,"29c54cb0124ae18323a08c819e6d6042a1a4ead8db98d20cdc1d8e42dc07fa92")

