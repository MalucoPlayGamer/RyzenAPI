-- Lua provided by RyzenAPI
-- Game: Magnetic By Nature

-- MAIN APPLICATION
addappid(296510)

-- MAIN APP DEPOTS / PACKAGES
addappid(296511, 1, "a29357be4eb6f7e4ca81f9f96c5f6da22c882248308dd345d99c40c7a3e7b680")
addappid(296512, 1, "00c586ce84661f39019c25673e4c6e43596f8fe95614fff7fa6235b399b55ddf")
addappid(296513, 1, "2197ef56e84c9103078a1cec5d026eb6b8475ebc91efe611f6c1ae70d42b2d62")
addappid(332030, 0, "cc2ed1f7903b7fcef4029cd8f4c2b895b56dddb83ae4a14ef07be52cbb718d8a")
