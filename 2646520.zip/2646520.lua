-- Lua provided by RyzenAPI
-- Game: 2646520

-- MAIN APPLICATION
addappid(2646520)
-- Game: addappid(2646520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646521, 1, "d10228b25c069d4d65c1ac7ed034e7cf037b1f3cfbd6fd2c4093d394b41ab350")
addappid(2646522, 1, "1c6b46fcf75c2efe98330024f8e81411dcf922ee7c73be2da5721dd9f10329bf")
