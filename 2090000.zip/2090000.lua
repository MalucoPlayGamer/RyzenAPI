-- Lua provided by RyzenAPI
-- Game: Chicken Journey Demo

-- MAIN APPLICATION
addappid(2090000)
-- Game: addappid(2090000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2090001, 1, "6b84069004c77e144cc2ab995a5c6da9711d763f59422996ca9a42c014b0631a")
