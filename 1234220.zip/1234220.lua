-- Lua provided by RyzenAPI
-- Game: 1234220

-- MAIN APPLICATION
addappid(1234220)
-- Game: addappid(1234220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234221, 1, "ea806ad5df7ffdab7b496247f3675b81b986c440323dea33d8917ad3b574faa4")
