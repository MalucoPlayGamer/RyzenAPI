-- Lua provided by RyzenAPI
-- Game: Used Cars Simulator

-- MAIN APPLICATION
addappid(2637940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2637941, 1, "56d2f745877aba504b691efdce96381d17cb378d8a816e741d27ebcc9328e7cb")
