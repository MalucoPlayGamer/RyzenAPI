-- Lua provided by RyzenAPI
-- Game: Goodbye Volcano High Soundtrack

-- MAIN APPLICATION
addappid(2570270)
-- Game: addappid(2570270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2570271, 1, "a5c8017602f86a768a444d9099a239c86125326471eb2b7e277a64e3f83f6fc0")
addappid(2570272, 1, "1b39dd199e1f5461ffd47d168ee8a5898a8d9f983f9cef338b55c0c7a308d7f4")
