-- Lua provided by RyzenAPI
-- Game: Dark Rift

-- MAIN APPLICATION
addappid(2308120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2308121, 1, "0d51a2d3965a72c9df3aa6e5b90e6992225d24f06b49ea9de980559dd8ca7735")
