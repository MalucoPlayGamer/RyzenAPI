-- Lua provided by RyzenAPI
-- Game: Game: Pro Cycling Manager 2021

-- MAIN APPLICATION
addappid(1453850)
-- Game: addappid(1453850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453851, 1, "cc926ee4e76a8539b1f7f21397224c9b0d4aca2ab7192621caafc020f46fe61a")
