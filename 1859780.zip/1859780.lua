-- Lua provided by RyzenAPI
-- Game: AppID 1859780

-- MAIN APPLICATION
addappid(1859780)
-- Game: addappid(1859780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859781, 1, "d63131e0dfd145f519f970e5864797fea55c4da95c5b0fda071ea38d65284716")
