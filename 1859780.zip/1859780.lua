-- Lua provided by SkyAPI 
-- Game: AppID 1859780
addappid(1859780)
addappid(1859781, 1, "d63131e0dfd145f519f970e5864797fea55c4da95c5b0fda071ea38d65284716")
