-- Lua provided by RyzenAPI
-- Game: Astrea: Six-Sided Oracles

-- MAIN APPLICATION
addappid(1755830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755831, 1, "7929644c919935b45cd67ace72fe843e68a55b2f15aafbc4d146754bedfa2b45")
addappid(2608590, 0, "ac752c56d48a76ff7168e14caa019ddb0731059e3800703356850b9f37c0ab4e")

