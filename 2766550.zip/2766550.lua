-- Lua provided by RyzenAPI
-- Game: Moon Tower

-- MAIN APPLICATION
addappid(2766550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2766551, 1, "6745d9cde0b3463c6edfc7dac2034b22124f0bdf56f6f08adfc226cc918bf595")
