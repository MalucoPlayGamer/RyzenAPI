-- Lua provided by RyzenAPI
-- Game: Game: Action Ball 2

-- MAIN APPLICATION
addappid(1186340)
-- Game: addappid(1186340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1186341, 1, "5ba3a5c1e2af91d54e14d4b96e6191ddc47700c9bc7ae9f02440ff2bee076aa7")
