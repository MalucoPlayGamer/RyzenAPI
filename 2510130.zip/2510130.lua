-- Lua provided by RyzenAPI
-- Game: Auto Sale Life

-- MAIN APPLICATION
addappid(2510130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2510131, 1, "d83765616f5bff23acae750c77801250ac76370bd2f32e4201544b7ec0da3178")
