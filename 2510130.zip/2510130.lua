-- Lua provided by SkyAPI 
-- Game: Auto Sale Life
addappid(2510130)
addappid(2510131, 1, "d83765616f5bff23acae750c77801250ac76370bd2f32e4201544b7ec0da3178")
