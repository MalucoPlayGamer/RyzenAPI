-- Lua provided by RyzenAPI
-- Game: Ashina: The Red Witch

-- MAIN APPLICATION
addappid(1259140)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1259141, 1, "13f0d759d78abc3eefd3f295567aa77420e5ace878b0669653b4c8a904848262")
