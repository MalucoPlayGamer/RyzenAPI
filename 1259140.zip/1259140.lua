-- Lua provided by SkyAPI 
-- Game: AppID 1259140
addappid(1259140)
addappid(1259141, 1, "13f0d759d78abc3eefd3f295567aa77420e5ace878b0669653b4c8a904848262")
