-- Lua provided by RyzenAPI
-- Game: Gone Home

-- MAIN APPLICATION
addappid(232430)
-- Game: addappid(232430)

-- MAIN APP DEPOTS / PACKAGES
addappid(232431, 1, "4185ee73389cf01034a05653ad72dbe10244d522e72d6a4f627c60b4de7f2938")
addappid(232432, 1, "62486effedf75478d67cca4b59392633962fc2280c6c55e1c9ae18cceb06f3b6")
addappid(232433, 1, "043f465d1fc1a17418f5ca9bba8d19f41e14cdd516645bfaf0e11d29090977ab")
addappid(232434, 1, "eaf2de6047c9dd128a2c68a2ae0f4c814ad8991c5718f97b7d0a17e4c81b61e7")
