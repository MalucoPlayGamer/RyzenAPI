-- Lua provided by RyzenAPI
-- Game: Airborne Kingdom Soundtrack

-- MAIN APPLICATION
addappid(1928920)
-- Game: addappid(1928920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1928921, 1, "75635ffac72a87dfb2d674f3b282401529b9481248d481f47cf19c4ddbe6c2b9")
addappid(1928922, 1, "bfbeaf5ac0b888d9580cb2ba7044827b665678ad87df57506a2133ba395283b2")
