-- 4915240's Lua and Manifest Created by Hubcap Manifest
-- Compile & Defend
-- Created: July 24, 2026 at 06:10:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4915240, 1, "a8914cc858c9d749fefaf8200d1e914e5f96f4a193589183a5490bbdd1e04c19") -- Compile & Defend
-- MAIN APP DEPOTS
addappid(4915242, 1, "69ac649e0a29889f46f8c7ede5e68b5b41f366dc2cda9ff8d498ddefa8182ea5") -- Depot 4915242
setManifestid(4915242, "8375489231889449976", 121162488)
addappid(4915243, 1, "c6748f34dd99e763564f86f8cf0c8a2b1eb42d990a22ddc3c4cff6b985783dd2") -- Depot 4915243
setManifestid(4915243, "6283711677209701141", 86195984)