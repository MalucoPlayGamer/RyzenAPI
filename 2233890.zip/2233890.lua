-- Lua provided by SkyAPI 
-- Game: Prison Wars
addappid(2233890)
addappid(2233891, 1, "db51427336c64551f20cfc4963b6243d4e4ec277c89aafae3dd9d1f9ef47af7d")
