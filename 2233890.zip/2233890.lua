-- Lua provided by RyzenAPI
-- Game: Prison Wars

-- MAIN APPLICATION
addappid(2233890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2233891, 1, "db51427336c64551f20cfc4963b6243d4e4ec277c89aafae3dd9d1f9ef47af7d")

