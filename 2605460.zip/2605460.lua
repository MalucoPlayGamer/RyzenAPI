-- Lua provided by RyzenAPI
-- Game: addappid(2605460)

-- MAIN APPLICATION
addappid(2605460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605461, 1, "08a4d3f5636afe15baec481a4067bcce152355631a7e1d3eede86232571f5f93")
