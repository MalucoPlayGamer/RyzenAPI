-- Lua provided by RyzenAPI
-- Game: X-Plane 12 Global Scenery: South America

-- MAIN APPLICATION
addappid(2126101)

-- MAIN APP DEPOTS / PACKAGES
addappid(2126101,0,"bc983cd4ccc0cf1b8b9e4215ad596c825c4d2798223e739dec9944aa2dbe7249")
