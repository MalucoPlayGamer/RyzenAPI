-- Lua provided by RyzenAPI
-- Game: AppID 539280

-- MAIN APPLICATION
addappid(539280)
-- Game: addappid(539280)

-- MAIN APP DEPOTS / PACKAGES
addappid(539281, 1, "7fac1775a4a023999b0607887ce2ccbf729650d103055c7f1bf5d1e5ba7aa4c1")
