-- Lua provided by RyzenAPI
-- Game: Urban Trial Freestyle

-- MAIN APPLICATION
addappid(243450)

-- MAIN APP DEPOTS / PACKAGES
addappid(243451, 1, "d4e85fa02923b97b6620f0b145eaeeaf0c66ddc52db941b22249395006d728c1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(249700)
