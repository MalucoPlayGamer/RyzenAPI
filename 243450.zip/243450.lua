-- Lua provided by RyzenAPI
-- Game: Urban Trial Freestyle

-- MAIN APPLICATION
addappid(243450)

-- MAIN APP DEPOTS / PACKAGES
addappid(243451, 1, "d4e85fa02923b97b6620f0b145eaeeaf0c66ddc52db941b22249395006d728c1")
