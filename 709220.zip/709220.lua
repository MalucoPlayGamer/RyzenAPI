-- Lua provided by RyzenAPI
-- Game: AppID 709220

-- MAIN APPLICATION
addappid(709220)

-- MAIN APP DEPOTS / PACKAGES
addappid(709221, 1, "11bcb83cac7423f2a683fc9c3fc0255cb36999668eaf759c5b9a37ad9268568c")

