-- Lua provided by RyzenAPI
-- Game: Miner Warfare

-- MAIN APPLICATION
addappid(354620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(354621, 1, "d862da3ab9e821606b212084588806caf330aa0b65e049abd0247cf5fe5382a0")

