-- Lua provided by RyzenAPI
-- Game: Game: Miner Warfare

-- MAIN APPLICATION
addappid(354620)
-- Game: addappid(354620)

-- MAIN APP DEPOTS / PACKAGES
addappid(354621, 1, "d862da3ab9e821606b212084588806caf330aa0b65e049abd0247cf5fe5382a0")
