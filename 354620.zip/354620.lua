-- Lua provided by RyzenAPI 
-- Game: Miner Warfare
addappid(354620)
addappid(354621, 1, "d862da3ab9e821606b212084588806caf330aa0b65e049abd0247cf5fe5382a0")
