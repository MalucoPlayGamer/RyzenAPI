-- Lua provided by RyzenAPI
-- Game: addappid(3449840)

-- MAIN APPLICATION
addappid(3449840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3449841, 1, "0716a9315162c640fe56c0cb7ba00bcd1529f8d203b1e4afd779bbd0efa78952")
