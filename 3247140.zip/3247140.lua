-- Lua provided by RyzenAPI
-- Game: addappid(3247140)

-- MAIN APPLICATION
addappid(3247140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3247141, 1, "b11e5b63b50e95740b5ba1b29d7c7aa4e6a9d3046a606d0cdebb8495c02c874f")
