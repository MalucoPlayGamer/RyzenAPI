-- Lua provided by RyzenAPI
-- Game: 964230

-- MAIN APPLICATION
addappid(964230)
-- Game: addappid(964230)

-- MAIN APP DEPOTS / PACKAGES
addappid(964231, 1, "f2726537f0b2db9c25e30057c2002189cad9d05195dcce96ae4d0e9af7675377")
