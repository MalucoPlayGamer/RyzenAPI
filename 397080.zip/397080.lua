-- Lua provided by RyzenAPI
-- Game: Magicka 2: Spell Balance Beta

-- MAIN APPLICATION
addappid(397080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(397081, 1, "1102dc8d8337f9f7dff455006cdfcd070726a5b80490b69b5175eb73b15b661f")
addappid(397082, 1, "a1f6a496a71ae8dcd0be5c7f5e09d8fb1c73ccf5ed0d925dabb4e657e42dd540")
addappid(397083, 1, "3ce93503bbc2d0f2426018818f146dd9cc8436886ce89e8dfcdeb648a5f9fbd3")
addappid(397084, 1, "24aa056dfecbf55ce4352b69f8877a319bf081a4a1a98bc81f5b083f03b3c792")
addappid(397085, 1, "987d766062eb7b72b1803911e1da3585c30a31139af8615014b83cb377795a6e")
addappid(397086, 1, "41cf36a2f57a7f14b38ce6e1db6d59061ba7f8e713b41ed2e38299d907e318d4")
addappid(397087, 1, "9c61fcc40d06560a05856166b865f7002a8c8557d16547761c9fbad0fea66a9c")
