-- Lua provided by RyzenAPI
-- Game: Game: Poodle Clicker

-- MAIN APPLICATION
addappid(3077520)
-- Game: addappid(3077520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3077521, 1, "09441fc4d13837e7187f589af99e1a1e018c987bfe406b63dfa94cb2af2e3c8c")
