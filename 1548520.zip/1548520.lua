-- Lua provided by RyzenAPI
-- Game: DARKEST DAYS

-- MAIN APPLICATION
addappid(1548520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548521, 1, "cb5fd3889ee4935dc9cb386546e20929666d0fa9b4afdc6fd1862caa33cb58b3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3750400)
