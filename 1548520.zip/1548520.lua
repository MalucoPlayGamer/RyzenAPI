-- Lua provided by RyzenAPI
-- Game: DARKEST DAYS

-- MAIN APPLICATION
addappid(1548520)
-- Game: addappid(1548520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548521, 1, "cb5fd3889ee4935dc9cb386546e20929666d0fa9b4afdc6fd1862caa33cb58b3")
