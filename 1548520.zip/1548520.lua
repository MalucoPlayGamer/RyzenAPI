-- Lua provided by SkyAPI 
-- Game: DARKEST DAYS
addappid(1548520)
addappid(1548521, 1, "cb5fd3889ee4935dc9cb386546e20929666d0fa9b4afdc6fd1862caa33cb58b3")
