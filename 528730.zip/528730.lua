-- Lua provided by RyzenAPI
-- Game: Crypt of the Serpent King

-- MAIN APPLICATION
addappid(528730)

-- MAIN APP DEPOTS / PACKAGES
addappid(528731, 1, "cf18605843e90bc7022e7c3022f4097cb9b60b70bfefc25f7ed524f37bff0fab")
