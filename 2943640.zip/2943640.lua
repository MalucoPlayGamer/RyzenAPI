-- Lua provided by RyzenAPI
-- Game: Симулятор ПВЗ

-- MAIN APPLICATION
addappid(2943640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2943641, 1, "9b8d5126acb81d61dee1798cf8da52d121453e7cec560d3b12087a55dd68b7e9")
