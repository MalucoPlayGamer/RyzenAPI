-- Lua provided by RyzenAPI
-- Game: The Sundew

-- MAIN APPLICATION
addappid(1468380)
addappid(1468381)
addappid(1468382)
addappid(1468383)
addappid(1468384)
addappid(1468385)
addappid(1468386)
addappid(1468387)
addappid(1468389)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468388,0,"863b4da8a122ae5fac61db7aa4e552f569dc87c2adf2ac167c53a47a7e5f0463")
