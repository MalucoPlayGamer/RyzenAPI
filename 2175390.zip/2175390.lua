-- Lua provided by RyzenAPI
-- Game: Game: Going Rogue

-- MAIN APPLICATION
addappid(2175390)
-- Game: addappid(2175390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2175391, 1, "ce7be88bfb664b41e4ce5b5a453ad7804fc7b8591758ed202b44c5e0f67cf1d6")
addappid(2175395, 1, "b6ab3ea21a2084e689eb973e5e220169d97332fca1dee4519fea993fefec48c4")
addappid(2206550, 0, "4f7788fe7193fe042424fd0750244c5a5d06fc4eb1d529e5bb111ff12c7b266f")
