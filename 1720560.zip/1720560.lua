-- Lua provided by RyzenAPI
-- Game: addappid(1720560)

-- MAIN APPLICATION
addappid(1720560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1720561, 1, "897ee8cd47cda9ca4552270928afff4e9d4b37a39065e98a40861a764b8abb14")
