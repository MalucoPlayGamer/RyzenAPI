-- Lua provided by RyzenAPI
-- Game: 708640

-- MAIN APPLICATION
addappid(708640)
-- Game: addappid(708640)

-- MAIN APP DEPOTS / PACKAGES
addappid(708641, 1, "fa8289845e5604f88ccbb37f91cc1b34b0641b6bfb4c317c8028eacd083cd1c5")
