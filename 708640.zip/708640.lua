-- Lua provided by RyzenAPI
-- Game: Nudist Beach Survival Simulator

-- MAIN APPLICATION
addappid(708640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(708641, 1, "fa8289845e5604f88ccbb37f91cc1b34b0641b6bfb4c317c8028eacd083cd1c5")
