-- Lua provided by RyzenAPI
-- Game: Trolley Problem, Inc.

-- MAIN APPLICATION
addappid(1582680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582681, 1, "6777aac904aa3af99ba8147dc462a6ffd184255b8fba3a0ec5a9fc171bf2dd6c")
