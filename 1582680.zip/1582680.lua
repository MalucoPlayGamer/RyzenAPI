-- Lua provided by SkyAPI 
-- Game: Trolley Problem, Inc.
addappid(1582680)
addappid(1582681, 1, "6777aac904aa3af99ba8147dc462a6ffd184255b8fba3a0ec5a9fc171bf2dd6c")
