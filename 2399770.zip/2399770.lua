-- Lua provided by RyzenAPI
-- Game: addappid(2399770)

-- MAIN APPLICATION
addappid(2399770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399771, 1, "a3be1bc037c3bc0ee26a960c2ce0033f8d805b077b4df17263ffe9bfeaffcc72")
