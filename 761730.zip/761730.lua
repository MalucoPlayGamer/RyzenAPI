-- Lua provided by RyzenAPI
-- Game: non - The First Warp

-- MAIN APPLICATION
addappid(761730)

-- MAIN APP DEPOTS / PACKAGES
addappid(761734,0,"6380c915fd13f1eaba079a666899372b4d308cd0b0a43f4f432a8cdd1f232a40")

