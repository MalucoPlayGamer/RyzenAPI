-- Lua provided by RyzenAPI
-- Game: non - The First Warp

-- MAIN APPLICATION
addappid(761730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(761734,0,"6380c915fd13f1eaba079a666899372b4d308cd0b0a43f4f432a8cdd1f232a40")

