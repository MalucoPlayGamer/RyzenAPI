-- Lua provided by RyzenAPI
-- Game: addappid(1665230)

-- MAIN APPLICATION
addappid(1665230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1665231, 1, "042a702f259e9057ed5d4d58f0960230fd00758f04e5d113ef9587df08eccc7c")
