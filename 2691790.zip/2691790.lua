-- Lua provided by RyzenAPI
-- Game: 2691790

-- MAIN APPLICATION
addappid(2691790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2691792,0,"41d5c1652304f7d60902f941d169ab3ce3d31aaf68a9dbfd9cdee91e3bd5f690")

