-- Lua provided by RyzenAPI
-- Game: Arcana: Heat and Cold. Season 1

-- MAIN APPLICATION
addappid(1357830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1357831, 1, "4fe01eb656ff10b3f57c038287634ab47908100cd23bfadb6c199b6c477eb7c8")

