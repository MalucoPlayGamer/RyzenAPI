-- Lua provided by RyzenAPI
-- Game: addappid(2312510)

-- MAIN APPLICATION
addappid(2312510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2312511, 1, "fe2b205d6d19d7ea75c8905184dd2307aaa3843f4bb713461f860185584aa0c0")
