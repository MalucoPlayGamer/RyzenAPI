-- Lua provided by RyzenAPI
-- Game: Isles of Limbo

-- MAIN APPLICATION
addappid(1389260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1389261, 1, "95d7470bd056005495b0581ea63ab3ac44394d26588c438c3d893feab38dadfe")

