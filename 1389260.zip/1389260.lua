-- Lua provided by RyzenAPI
-- Game: Isles of Limbo

-- MAIN APPLICATION
addappid(1389260)
-- Game: addappid(1389260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1389261, 1, "95d7470bd056005495b0581ea63ab3ac44394d26588c438c3d893feab38dadfe")
