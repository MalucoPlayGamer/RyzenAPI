-- Lua provided by RyzenAPI
-- Game: AppID 543920

-- MAIN APPLICATION
addappid(543920)

-- MAIN APP DEPOTS / PACKAGES
addappid(543921, 1, "45f6de007d9bcbe91393b7de137a2da6fe8a97e2366e6a3c31dabbfb2be88ba8")

