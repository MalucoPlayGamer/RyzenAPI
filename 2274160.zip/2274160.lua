-- Lua provided by RyzenAPI
-- Game: Gimmick's Gadgets

-- MAIN APPLICATION
addappid(2274160)
addappid(2384870)
addappid(2384871)
addappid(2407790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2274161, 1, "dfe9c615d6703918cc423fe1964cde17fd206c6f18ede038a3bb8cba8e984b5b")

