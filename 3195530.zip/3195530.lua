-- Lua provided by RyzenAPI
-- Game: Streamer's Journey 💖

-- MAIN APPLICATION
addappid(3195530)
addappid(3539190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3195531, 1, "2ec5b593cc6d2b5e123ff28cd266c67569c756b7457a53c5860fc39a097eeb89")
