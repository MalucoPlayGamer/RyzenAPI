-- Lua provided by SkyAPI 
-- Game: Streamer's Journey 💖
addappid(3195530)
addappid(3195531, 1, "2ec5b593cc6d2b5e123ff28cd266c67569c756b7457a53c5860fc39a097eeb89")
addappid(3539190)
