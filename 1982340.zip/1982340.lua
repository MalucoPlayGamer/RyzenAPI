-- Lua provided by RyzenAPI
-- Game: addappid(1982340)

-- MAIN APPLICATION
addappid(1982340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982346,0,"e1b9ce1f2d6178b386bc8efa1b0807e7f0072260be53a95e5fa947f32d7f036d")
