-- Lua provided by RyzenAPI
-- Game: Blanc

-- MAIN APPLICATION
addappid(1982340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1982346,0,"e1b9ce1f2d6178b386bc8efa1b0807e7f0072260be53a95e5fa947f32d7f036d")

