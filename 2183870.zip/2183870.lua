-- Lua provided by RyzenAPI 
-- Game: DIMENSIONLESS
addappid(2183870)
addappid(2183871, 1, "664c0e944095c5841ee9b2dc1e4a650231b223748fcebd921e38fd0ee194b35d")
