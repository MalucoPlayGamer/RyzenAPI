-- Lua provided by RyzenAPI
-- Game: 2183870

-- MAIN APPLICATION
addappid(2183870)
-- Game: addappid(2183870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183871, 1, "664c0e944095c5841ee9b2dc1e4a650231b223748fcebd921e38fd0ee194b35d")
