-- Lua provided by RyzenAPI
-- Game: Open Country

-- MAIN APPLICATION
addappid(1192010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1192011, 1, "a482bb7216e2c261d0979cac0c11a018ebd9df530fb5c1824d0a690f5cd32762")
addappid(1192013, 1, "b1ee3e123a7c4c30ecebee2d78b1f54109c27545aa21ec45fb49f3e4bbf3478f")
addappid(1192014, 1, "156a1af8732e0fb8a52cc9ade7a7a1f1f4566f73d91c3b5ba141b573e9be87e4")

