-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3354520)
-- Game: addappid(3354520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3354520,0,"cae25ace6d86b99623ce36858a35ba791294daf6badb732772c408fff65752e2")
