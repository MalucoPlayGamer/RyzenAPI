-- Lua provided by RyzenAPI 
-- Game: AppID 584890
addappid(584890)
addappid(584891, 1, "f5b7b16e6e26b8ee5b73ae6dabebde958f4c9cb10abd2f8102101f05dca915e8")
addappid(584892, 1, "870fc1a72cb1f2f9223fe460a4e387d617163bc1108f518409d1de46d616fef3")
