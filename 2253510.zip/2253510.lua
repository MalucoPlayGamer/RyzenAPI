-- Lua provided by RyzenAPI
-- Game: air star

-- MAIN APPLICATION
addappid(2253510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2253511, 1, "a8910e80a17adfad04945682841c27061b9e051acc90416e1e9615d3aa29ae2a")

