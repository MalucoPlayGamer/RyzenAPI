-- Lua provided by RyzenAPI
-- Game: 878350

-- MAIN APPLICATION
addappid(878350)
-- Game: addappid(878350)

-- MAIN APP DEPOTS / PACKAGES
addappid(878351, 1, "5cbce6e5f82928155ce36c410b16b29a1c210ffb4220dd3764561c5466a18768")
