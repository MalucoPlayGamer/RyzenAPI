-- Lua provided by RyzenAPI
-- Game: Momodora: Moonlit Farewell

-- MAIN APPLICATION
addappid(1747760)
-- Game: addappid(1747760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747761, 1, "b4e8d739f24007acda65e481ee1fba73d4e6b00f695ae8f352b686041b016432")
