-- Lua provided by RyzenAPI
-- Game: 8730

-- MAIN APPLICATION
addappid(8721)
addappid(8730)
-- Game: addappid(8730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004,0,"f21faa4f29ecee9d192fc1784d1701376eb87e13521824ceaf0116b10c558a81")
