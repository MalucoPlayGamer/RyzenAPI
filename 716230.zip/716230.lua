-- Lua provided by RyzenAPI
-- Game: AppID 716230

-- MAIN APPLICATION
addappid(716230)
-- Game: addappid(716230)

-- MAIN APP DEPOTS / PACKAGES
addappid(716231, 1, "3afa597064d5f5e262b823334a0b2a78a90ebb7d50cc78bfaa62a980daea583f")
addappid(754650, 0, "1ba53dc41144bafe077410b98652c0ae8ff0e0475b154ad497e1e8252dace455")
