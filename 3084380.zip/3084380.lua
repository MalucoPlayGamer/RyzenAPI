-- Lua provided by RyzenAPI
-- Game: addappid(3084380)

-- MAIN APPLICATION
addappid(3084380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3084381, 1, "98bd04a2ebd272a7beef65ee206e2ccb6e65b7bd8b6cc0ed5736b4dde4609e4a")
