-- Lua provided by RyzenAPI
-- Game: Concordia: Digital Edition

-- MAIN APPLICATION
addappid(1450330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1450331, 1, "c491d9e241d1f10381235b198dd561f535e5a7963c449c229554255dd29c617d")
addappid(1707530, 0, "5e1878c7e47839fe9011c8476488f8e663ebfacb3c247bd89f60e572a97d1699")
addappid(1707531, 0, "5838ab46263d1d2dfc9342bfb6e52320d821230b6e9da2e98f4c8df303954415")
addappid(1707532, 0, "852e06e4bd9bece205cbf25993e24320a76ef67bde7a5f3f3a5b50281dd1ab58")
addappid(1707533, 0, "03ba102ac57aad9a71110711b1d815f74cff62f38affa77b716b7c56a14ae44e")
addappid(1707534, 0, "00b4b5e0eb0496f9a14afcc5a0d0d3bdde02fe56782e4e8e30c712c604b0b029")
addappid(1707535, 0, "de442c7de0cfe79d19c44f264d80c1080e5459adb93d5b68037ce9b90748a67f")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1708670)
