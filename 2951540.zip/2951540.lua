-- Lua provided by RyzenAPI
-- Game: addappid(2951540)

-- MAIN APPLICATION
addappid(2951540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2951541, 1, "e089852efbe924984e137b7c02cf0f4d4481f091625dd22b61be2e5ffd02b994")
