-- Lua provided by RyzenAPI 
-- Game: AppID 2951540
addappid(2951540)
addappid(2951541, 1, "e089852efbe924984e137b7c02cf0f4d4481f091625dd22b61be2e5ffd02b994")
