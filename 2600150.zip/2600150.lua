-- Lua provided by RyzenAPI
-- Game: Family Crush

-- MAIN APPLICATION
addappid(2600150)
-- Game: addappid(2600150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2600151, 1, "0a282e0d84355c826ca256045373d8bafb87a69725d7dabf9586db66ea8b1b77")
