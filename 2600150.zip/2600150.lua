-- Lua provided by SkyAPI 
-- Game: Family Crush
addappid(2600150)
addappid(2600151, 1, "0a282e0d84355c826ca256045373d8bafb87a69725d7dabf9586db66ea8b1b77")
