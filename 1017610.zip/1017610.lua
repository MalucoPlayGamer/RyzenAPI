-- Lua provided by SkyAPI 
-- Game: Butterfly
addappid(1017610)
addappid(1017611, 1, "7a770e7657615b82c4ff077f482b399f448bc25aa4de449b8d72144969b3d888")
