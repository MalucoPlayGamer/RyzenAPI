-- Lua provided by RyzenAPI
-- Game: Butterfly

-- MAIN APPLICATION
addappid(1017610)
-- Game: addappid(1017610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1017611, 1, "7a770e7657615b82c4ff077f482b399f448bc25aa4de449b8d72144969b3d888")
