-- Lua provided by RyzenAPI
-- Game: addappid(1601830)

-- MAIN APPLICATION
addappid(1601830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1601831, 1, "95bd0ad3d6df89fcdffa6ed7bfd5ef6c72fab7fe533cc2b198a979cd26dac523")
