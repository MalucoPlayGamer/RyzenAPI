-- Lua provided by RyzenAPI 
-- Game: AppID 383960
addappid(383960)
addappid(383961, 1, "338e5deefbf0127481f77791720477c085248b39a5eb8a6c47becba97b16d6f9")
addappid(383962, 1, "6998aec4c14127a655465c1fe92ba544c58d7c2bb4400a05295c889013270d9e")
