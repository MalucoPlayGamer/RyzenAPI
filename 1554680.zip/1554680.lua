-- Lua provided by RyzenAPI
-- Game: 北斗将星录

-- MAIN APPLICATION
addappid(1554680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554681, 1, "82f1ddd8e1895bd314052f6fe19b2215d88f18bbac22d5b598ad31f4c95bb590")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
