-- Lua provided by RyzenAPI
-- Game: Game: 北斗将星录

-- MAIN APPLICATION
addappid(1554680)
-- Game: addappid(1554680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554681, 1, "82f1ddd8e1895bd314052f6fe19b2215d88f18bbac22d5b598ad31f4c95bb590")
