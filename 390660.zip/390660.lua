-- Lua provided by RyzenAPI
-- Game: 390660

-- MAIN APPLICATION
addappid(390660)
-- Game: addappid(390660)

-- MAIN APP DEPOTS / PACKAGES
addappid(390661, 1, "1db8dc9c6156b5a2ff89d5f7f1cf5874a71a04a083aac2ffc7bd3ed5356ad24e")
