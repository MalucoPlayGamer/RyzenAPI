-- Lua provided by RyzenAPI 
-- Game: Call of Tomsk-7
addappid(390660)
addappid(390661, 1, "1db8dc9c6156b5a2ff89d5f7f1cf5874a71a04a083aac2ffc7bd3ed5356ad24e")
