-- Lua provided by RyzenAPI
-- Game: Game: AppID 1920030

-- MAIN APPLICATION
addappid(1920030)
-- Game: addappid(1920030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920031, 1, "1431a89b407f68d8095cdf064555f487922dbbcc7898d172d4ed9f3220167b85")
