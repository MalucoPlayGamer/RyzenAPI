-- Lua provided by RyzenAPI
-- Game: AppID 760990

-- MAIN APPLICATION
addappid(760990)

-- MAIN APP DEPOTS / PACKAGES
addappid(760991, 1, "4da9b94eb06e3eec970542ed6ac1b5bc610b43914a126fe40e0aa4c5b1f232a2")
