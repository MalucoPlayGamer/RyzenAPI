-- Lua provided by RyzenAPI
-- Game: Drago Noka

-- MAIN APPLICATION
addappid(1984790)
-- Game: addappid(1984790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1984791, 1, "b067e7e327dc376b23556aa5f84ace95846d93eb9a7507504580e3ab872a8cef")
addappid(1984792, 1, "dc9f6fade411de94bd7e1c219179a2c30a9e015fa9a5bccbc1bf330590fb576c")
addappid(1984793, 1, "660fb39d7e3a30922ff02e6af4527a03764302483fbdf5c09bbaf2887249d3ba")
