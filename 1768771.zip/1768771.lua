-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1768771)

-- MAIN APP DEPOTS / PACKAGES
addappid(1768771,0,"c1412815bbd3074667794554dad05cd0e986863c68362c9cf5a1b2bc0cb04817")

