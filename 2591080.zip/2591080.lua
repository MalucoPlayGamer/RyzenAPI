-- Lua provided by RyzenAPI
-- Game: Game: The Friends We Left Behind Demo

-- MAIN APPLICATION
addappid(2591080)
-- Game: addappid(2591080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2591081, 1, "5f30a2b55870815d5b771e224f40d17aeaa42afc100548dc99bd6b8107795461")
