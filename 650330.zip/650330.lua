-- Lua provided by RyzenAPI
-- Game: addappid(650330)

-- MAIN APPLICATION
addappid(650330)

-- MAIN APP DEPOTS / PACKAGES
addappid(650331, 1, "6d630882e465de823a40532ada1ae9be73881203c47ae3d86cab9371b7ef1791")
addappid(1073730, 0, "6deac3df09d878168f649301d6aba8075b395baeb217691b0bb1aec25934f7c0")
addappid(1079350, 0, "ec6a84ad63d177d45b2eefbbea4bba1669c470da80970380fb6abe064f4300f2")
