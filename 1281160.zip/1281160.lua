-- Lua provided by RyzenAPI
-- Game: Castle in The Clouds DX

-- MAIN APPLICATION
addappid(1281160)
-- Game: addappid(1281160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1281161, 1, "35aedc74e762a95acd5892f1d18533c20ccea01487562c6b6390ad4e709985e2")
