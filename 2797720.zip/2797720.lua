-- Lua provided by RyzenAPI
-- Game: Game: Robber Knight Soundtrack

-- MAIN APPLICATION
addappid(2797720)
-- Game: addappid(2797720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2797721, 1, "70227a173b98c2ed2f49194aaf74a20612a8842c688678c3bf48c43ae5a16f37")
