-- Lua provided by RyzenAPI
-- Game: The Patient

-- MAIN APPLICATION
addappid(3233080)
addappid(3233083)
-- Game: addappid(3233080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3233082,0,"5450a64233671a0a018e23389890a71342782216e9c114c2a57f2ba6b3b4cb8a")
