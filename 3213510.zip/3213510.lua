-- Lua provided by RyzenAPI
-- Game: Summer For You - Digital Artbook

-- MAIN APPLICATION
addappid(3213510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3213510,0,"9d96347f138f2d728ce0d42a0b0254df8ab0d23be0f6fbb6badafcc90d6f0275")
