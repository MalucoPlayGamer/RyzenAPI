-- Lua provided by RyzenAPI
-- Game: Destiny of a Wizard

-- MAIN APPLICATION
addappid(670140)

-- MAIN APP DEPOTS / PACKAGES
addappid(670141,0,"b29cee36eb064e2105fc74246ae115f93b7dea9f35b713cad1b4dfb7fcc434a8")

