-- Lua provided by SkyAPI 
-- Game: Milk Bottle And Monster Girl
addappid(1839700)
addappid(1839701, 1, "74348a75aac6521cdbf475d71465272d67c169e852d7ea44d6cefcbeb576f9f5")
addappid(1852160, 0, "9c2b5af7a3f22175396129ba140b9e2c4358353fdabd752b995a3d3e2701e900")
