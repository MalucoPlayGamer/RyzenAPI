-- Lua provided by RyzenAPI
-- Game: Cube Hero Odyssey

-- MAIN APPLICATION
addappid(2954730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2954731, 1, "9d8dabd8a9015447c6e0987db13b668ce250bac1172ac7a74d0bc925eb8e1be1")
