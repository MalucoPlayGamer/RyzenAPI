-- Lua provided by RyzenAPI
-- Game: Ninja Maker

-- MAIN APPLICATION
addappid(2546680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2546681, 1, "9abd3c448fc8cfcc576a9c6daa55ab76f308d237e1cb696fb142b23938e93d27")
