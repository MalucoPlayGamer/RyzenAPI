-- 4805600's Lua and Manifest Created by Hubcap Manifest
-- SCAVENGE PROTOCOL
-- Created: August 01, 2026 at 09:12:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4805600) -- SCAVENGE PROTOCOL
-- MAIN APP DEPOTS
addappid(4805601, 1, "15b38549f11c330de93052887bffd80e154d24ea2bd0bd2499e5dd159105351a") -- Depot 4805601
setManifestid(4805601, "1094541180502723829", 715746235)