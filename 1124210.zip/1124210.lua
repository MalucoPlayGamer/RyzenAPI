-- Lua provided by SkyAPI 
-- Game: AppID 1124210
addappid(1124210)
addappid(1124211, 1, "f6ec0ef665b59b0ce287551a7d6ee8b529825f28ab2534e8c5986e2490db672b")
