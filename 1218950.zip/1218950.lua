-- Lua provided by RyzenAPI
-- Game: 战神七魄

-- MAIN APPLICATION
addappid(1218950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1218951, 1, "14d4cee2ba64e8dcc38f8c4137667cce7e3d003cc18cbbb212490cb77769f9c7")

