-- Lua provided by RyzenAPI
-- Game: 2007710

-- MAIN APPLICATION
addappid(2007710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2007713,0,"7a0aa3af848776e9cab0fd8a00caace9566b9bb5ad43e1a4e2723e958e71a88c")
addappid(2007714,0,"fedcdfe1e93067cefc1cec92abbcbd3505285d7f2276fe3c3b63a91ec3a097de")

