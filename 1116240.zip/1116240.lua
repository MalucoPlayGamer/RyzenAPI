-- Lua provided by RyzenAPI
-- Game: Game: Android Amazones

-- MAIN APPLICATION
addappid(1116240)
addappid(1131321)
-- Game: addappid(1116240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116241, 1, "890f344b5bdf7d863b23383231db49b7c22dee2de249a212e4509f36de7879a5")
