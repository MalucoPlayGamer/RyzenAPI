-- Lua provided by RyzenAPI
-- Game: Android Amazones

-- MAIN APPLICATION
addappid(1116240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116241,0,"890f344b5bdf7d863b23383231db49b7c22dee2de249a212e4509f36de7879a5")
addappid(1190771,0,"1540d90a99aa6e8ee14a04acc038775f241f602faf4bf234a0ab64144e1a97b0")
addappid(1207561,0,"0a7b38216698bc75c0e73d8f6ee0236bd14bf2bd56ed5f563971a8b85334ab84")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1190770)
addappid(1207560)
