-- Lua provided by RyzenAPI
-- Game: 2220450

-- MAIN APPLICATION
addappid(2220450)
-- Game: addappid(2220450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2220451, 1, "f2dde691f9199d3f2017131788c1b92d6e811f84b82d097fa03cbcb8b0f333dc")
