-- Lua provided by RyzenAPI
-- Game: addappid(3660080)

-- MAIN APPLICATION
addappid(3660080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3660081, 1, "ed27199bf1b9fa7cc97288b4f56cbd43a9f4376333404bbaa900901900f901fe")
