-- Lua provided by RyzenAPI
-- Game: A Piece of Wish upon the Stars

-- MAIN APPLICATION
addappid(899190)
-- Game: addappid(899190)

-- MAIN APP DEPOTS / PACKAGES
addappid(899191, 1, "da6d39266bdfc475b5df12a61a9aad7f96509730fec43015ee24ee0445ee7013")
