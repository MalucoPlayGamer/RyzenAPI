-- Lua provided by RyzenAPI
-- Game: Collect Baby Oil

-- MAIN APPLICATION
addappid(3487490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3487492,0,"ebd98268fed49467e1e1ef4df6f469039ae37312e0f9330256fbb92f23d8a572")

