-- Lua provided by RyzenAPI
-- Game: addappid(924650)

-- MAIN APPLICATION
addappid(924650)

-- MAIN APP DEPOTS / PACKAGES
addappid(924651, 1, "7ad31b2eb0db73f291dc2afa0ac0936c24b24d5d8b4e56e028ea7258576b1397")
