-- Lua provided by RyzenAPI
-- Game: AppID 924650

-- MAIN APPLICATION
addappid(924650)

-- MAIN APP DEPOTS / PACKAGES
addappid(924651, 1, "7ad31b2eb0db73f291dc2afa0ac0936c24b24d5d8b4e56e028ea7258576b1397")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
