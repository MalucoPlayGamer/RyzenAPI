-- Lua provided by RyzenAPI 
-- Game: Envy the Dead
addappid(453960)
addappid(453961, 1, "454afb483d9596d79ace43a2196c667ad80b5849a00c62b5f93d08ada0c2ab3e")
