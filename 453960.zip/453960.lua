-- Lua provided by RyzenAPI
-- Game: Game: Envy the Dead

-- MAIN APPLICATION
addappid(453960)
-- Game: addappid(453960)

-- MAIN APP DEPOTS / PACKAGES
addappid(453961, 1, "454afb483d9596d79ace43a2196c667ad80b5849a00c62b5f93d08ada0c2ab3e")
