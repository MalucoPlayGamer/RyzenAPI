-- Lua provided by RyzenAPI
-- Game: Dr. Cares - Pet Rescue 911

-- MAIN APPLICATION
addappid(679770)

-- MAIN APP DEPOTS / PACKAGES
addappid(679771, 1, "727d49d1d0d0d3184c1ac1c3f566b6403d5a5948cf04b2f65284533958d71480")
