-- Lua provided by RyzenAPI
-- Game: click to ten

-- MAIN APPLICATION
addappid(1910580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1910581, 1, "2ed90a0a3f3a5c0690ec088893b8f87728e2aa1cc8f733305f1d3912e7637499")

