-- Lua provided by RyzenAPI
-- Game: addappid(2471930)

-- MAIN APPLICATION
addappid(2471930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471931, 1, "0a65a9d10cd8fad21f1feae765ff9cafbb0a65370ff8394eb81fcb961e8d6ff1")
