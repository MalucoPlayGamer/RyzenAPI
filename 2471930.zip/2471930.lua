-- Lua provided by RyzenAPI
-- Game: Game: KISS: K-pop Idol StorieS - Road to Debut Playtest

-- MAIN APPLICATION
addappid(2471930)
-- Game: addappid(2471930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471931, 1, "0a65a9d10cd8fad21f1feae765ff9cafbb0a65370ff8394eb81fcb961e8d6ff1")
