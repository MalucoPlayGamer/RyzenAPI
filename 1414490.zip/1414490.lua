-- Lua provided by RyzenAPI
-- Game: AppID 1414490

-- MAIN APPLICATION
addappid(1414490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414491, 1, "b0ad165bcdd24a07bef7284a07582e63a7bd8e01c9c3b5b9ba7c42d96b31d22b")

