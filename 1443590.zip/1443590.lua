-- Lua provided by RyzenAPI
-- Game: addappid(1443590)

-- MAIN APPLICATION
addappid(1443590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1443592,0,"62c5de7dd8d7f590de7629e5f08c913718080c444b0b3ff3784b24b49ef74ab9")
