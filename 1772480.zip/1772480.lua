-- Lua provided by RyzenAPI
-- Game: Jelle's Marble League

-- MAIN APPLICATION
addappid(1772480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1772481, 1, "a4056c1c58724259cfb25c799bac27142d3aaa7ea800484532c864d9be221671")
