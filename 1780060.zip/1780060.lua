-- Lua provided by RyzenAPI
-- Game: Game: Megacraft Hentai Apocalipsis

-- MAIN APPLICATION
addappid(1780060)
-- Game: addappid(1780060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1780061, 1, "528265eae6af76aba5e7d5fe0302ae428084f03e5922d2fd8d6f0bf801719807")
