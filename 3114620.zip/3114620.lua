-- Lua provided by RyzenAPI
-- Game: Toy Voyage

-- MAIN APPLICATION
addappid(3114620)
-- Game: addappid(3114620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3114621, 1, "d67de4bf2a16f445b00f9ad9f0226943084ea43a71d823191f00ae03ed840638")
