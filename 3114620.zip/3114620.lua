-- Lua provided by RyzenAPI
-- Game: Toy Voyage

-- MAIN APPLICATION
addappid(3114620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3114621, 1, "d67de4bf2a16f445b00f9ad9f0226943084ea43a71d823191f00ae03ed840638")

