-- Lua provided by SkyAPI 
-- Game: Toy Voyage
addappid(3114620)
addappid(3114621, 1, "d67de4bf2a16f445b00f9ad9f0226943084ea43a71d823191f00ae03ed840638")
