-- Lua provided by RyzenAPI
-- Game: AppID 704920

-- MAIN APPLICATION
addappid(704920)

-- MAIN APP DEPOTS / PACKAGES
addappid(704921, 1, "226c044efd0d0a7daaf7acba8f58a755ad320030568f1c8de27f0a5a04550757")
