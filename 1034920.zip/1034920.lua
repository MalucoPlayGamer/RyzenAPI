-- Lua provided by RyzenAPI
-- Game: Whipseey and the Lost Atlas

-- MAIN APPLICATION
addappid(1034920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034921, 1, "57e8a89bedc54b013b4d4d0603a8496163b8d0962b315e559070dd007c3c9d0b")

