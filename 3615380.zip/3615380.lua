-- Lua provided by RyzenAPI
-- Game: 3615380

-- MAIN APPLICATION
addappid(3615380)
-- Game: addappid(3615380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3615381, 1, "a805615f6fd85443b0e8bd8255db9dbd743a7a7fdb22ab491c2377b04e162a17")
