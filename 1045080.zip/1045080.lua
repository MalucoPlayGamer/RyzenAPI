-- Lua provided by RyzenAPI
-- Game: Curious Cases

-- MAIN APPLICATION
addappid(1045080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045081, 1, "7be8f7d7fb090af02429d98129d64770a2807c89f0a4523d60d7ab0d46556808")
