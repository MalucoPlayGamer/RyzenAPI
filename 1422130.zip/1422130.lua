-- Lua provided by RyzenAPI
-- Game: SimRail - The Railway Simulator

-- MAIN APPLICATION
addappid(1422130)
addappid(2868050)
addappid(4009020)
addappid(4380650)
addappid(4916490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1422130,0,"a543494297f1016f380dd11d59d887fc3190460a20e7836f2bcf0a41bc87e6ec")
addappid(1422131,0,"1619b6c1fac954e2ca5ad8b46b1e5073af05feea9be14ef642832dc14e76a5d1")
addappid(1422132,0,"5ba05793cfe06281329404679e35c9916f808892b239e8e11f26360f0a6614af")
addappid(1422133,0,"03e8f3d92041be292986b8d84398fa901e2679f3eb8ebbea2fdef8ef623b3eaa")
addappid(1422134,0,"94a2e078e11a6ba3a441b41c83704e96dd97b8581f49fa6d0fd5116167e7b5ff")
addappid(3583200,0,"35592f2d0dede2624b2620b56c4ee6070629e682ca1de506136164a6bd3260f3")
addappid(4009000,0,"3d4cbaa1d7db5e2aba0b3fde9ca95ac715a3bc49067a668728cc820ff06b4a00")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
