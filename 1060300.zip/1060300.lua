-- Lua provided by RyzenAPI
-- Game: 1060300

-- MAIN APPLICATION
addappid(1060300)
-- Game: addappid(1060300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1060301, 1, "e2ae9808adfaad34967c9e32989eb3db33213942cc76002e6eccd613966d82ef")
