-- Lua provided by RyzenAPI
-- Game: Axiom Verge 2

-- MAIN APPLICATION
addappid(946030)

-- MAIN APP DEPOTS / PACKAGES
addappid(946031, 1, "161660e0144db7d4c099677bbd5d70a054677ff2782696467287be96d3144eb4")
addappid(946032, 1, "1effacd7919a90c003c4b0b1e781eb6434eadc313c368a79605168f2df0e3800")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
