-- Lua provided by RyzenAPI
-- Game: Game: OPUS: Echo of Starsong Official Game Script -Vol.1-

-- MAIN APPLICATION
addappid(1856570)
-- Game: addappid(1856570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1856571, 1, "0a781d550d24498557374c666db6498a8906d36842eb108e7d44b053fcebbe6e")
