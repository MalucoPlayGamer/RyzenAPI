-- Lua provided by RyzenAPI
-- Game: TwelveSky 2 Classic

-- MAIN APPLICATION
addappid(539650)

-- MAIN APP DEPOTS / PACKAGES
addappid(539651, 1, "353adc5e09c3a728247124ccd576284e160f7f130613ae40161e4c330efb3617")

