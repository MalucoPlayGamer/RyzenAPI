-- Lua provided by RyzenAPI
-- Game: TwelveSky 2 Classic

-- MAIN APPLICATION
addappid(539650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(539651, 1, "353adc5e09c3a728247124ccd576284e160f7f130613ae40161e4c330efb3617")

