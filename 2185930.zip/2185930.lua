-- Lua provided by RyzenAPI
-- Game: Game: Football Club Management 2023

-- MAIN APPLICATION
addappid(2185930)
-- Game: addappid(2185930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185931, 1, "a27edba68bcf8aacfec8f5c89b2d89753492adb2bb4e73f79038bcf65172ab88")
