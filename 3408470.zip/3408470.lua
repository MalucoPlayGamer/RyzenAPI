-- Lua provided by RyzenAPI
-- Game: 7 Days Shrine

-- MAIN APPLICATION
addappid(3408470)
-- Game: addappid(3408470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3408471, 1, "486f61ae7796d72b38813d4e17f68885f44889f699d1bf964d14f7642a74be05")
