-- Lua provided by RyzenAPI 
-- Game: 7 Days Shrine
addappid(3408470)
addappid(3408471, 1, "486f61ae7796d72b38813d4e17f68885f44889f699d1bf964d14f7642a74be05")
