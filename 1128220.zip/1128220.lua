-- Lua provided by RyzenAPI
-- Game: Game: AppID 1128220

-- MAIN APPLICATION
addappid(1128220)
-- Game: addappid(1128220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128221, 1, "08868186b5b3bba0a68b5983fd058005a8c9d0a2f4834c74c055eb053365a82c")
