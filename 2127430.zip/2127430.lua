-- Lua provided by RyzenAPI
-- Game: Loop8: Summer of Gods

-- MAIN APPLICATION
addappid(2127430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2127431, 1, "9c053c822cb5da6b16b205829c23063ff00e17c4722110cb2ab1be64e4f3501e")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2154600)
addappid(2154601)
addappid(2154602)
addappid(2154603)
addappid(2154604)
addappid(2410090)
addappid(2429740)
addappid(2429741)
