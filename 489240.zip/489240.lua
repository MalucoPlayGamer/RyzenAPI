-- Lua provided by RyzenAPI
-- Game: AppID 489240

-- MAIN APPLICATION
addappid(489240)

-- MAIN APP DEPOTS / PACKAGES
addappid(489241, 1, "3128466d1d8feff11bfd4363a5e0d9ab724b141157990cfc4cbc93e4031bae27")
