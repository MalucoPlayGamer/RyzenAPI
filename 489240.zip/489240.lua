-- Lua provided by RyzenAPI
-- Game: AppID 489240

-- MAIN APPLICATION
addappid(489240)

-- MAIN APP DEPOTS / PACKAGES
addappid(489241, 1, "3128466d1d8feff11bfd4363a5e0d9ab724b141157990cfc4cbc93e4031bae27")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
