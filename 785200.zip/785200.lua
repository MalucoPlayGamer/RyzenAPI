-- Lua provided by RyzenAPI
-- Game: AppID 785200

-- MAIN APPLICATION
addappid(785200)
-- Game: addappid(785200)

-- MAIN APP DEPOTS / PACKAGES
addappid(785201, 1, "2229c89cd68ca49542d48889a78094aa8e3d84194e48ef72465c9fa11085fb88")
