-- Lua provided by RyzenAPI
-- Game: Reborn In Wild City 迷城重生

-- MAIN APPLICATION
addappid(949970)

-- MAIN APP DEPOTS / PACKAGES
addappid(949971, 1, "789072c961fb1af15396f5b04538148fde393891adf76513bdc0fc6c5a117ca0")
