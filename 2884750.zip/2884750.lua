-- Lua provided by RyzenAPI
-- Game: Monstrous Liberation

-- MAIN APPLICATION
addappid(2884750)
-- Game: addappid(2884750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2884751, 1, "21441e03e68e9179af6bc572cfc0205ae9347ff06ed593d4d078e3b0f75b76a7")
