-- Lua provided by SkyAPI 
-- Game: Monstrous Liberation
addappid(2884750)
addappid(2884751, 1, "21441e03e68e9179af6bc572cfc0205ae9347ff06ed593d4d078e3b0f75b76a7")
