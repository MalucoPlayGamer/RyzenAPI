-- Lua provided by RyzenAPI
-- Game: 1254950

-- MAIN APPLICATION
addappid(1254950)
-- Game: addappid(1254950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254951, 1, "936f24fbb9a5c5c12e6dd5f31396a5c631bcdf0e2e357953f3ae87c88417f6bd")
