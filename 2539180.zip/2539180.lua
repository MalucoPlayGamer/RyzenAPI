-- Lua provided by RyzenAPI
-- Game: Mayhem Survivors: Animals

-- MAIN APPLICATION
addappid(2539180)
-- Game: addappid(2539180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2539181, 1, "e633b06a0c0535a449e7aa974116238e94a8a79b8fd9e199b678cffc8396ef6b")
