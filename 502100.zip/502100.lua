-- Lua provided by RyzenAPI
-- Game: Death's Life

-- MAIN APPLICATION
addappid(502100)

-- MAIN APP DEPOTS / PACKAGES
addappid(502101, 1, "b69c6a046d71ece308345d11f61a2353ff16ef76944293efeaecd0f0229df515")

