-- Lua provided by RyzenAPI
-- Game: addappid(434790)

-- MAIN APPLICATION
addappid(434790)

-- MAIN APP DEPOTS / PACKAGES
addappid(434791, 1, "af32f8701fcbc84d92a50fe2c6fc4e72ae41c2d1d133eb67544c520e37a0420f")
