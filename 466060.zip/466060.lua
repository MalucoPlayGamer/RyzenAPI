-- Lua provided by RyzenAPI
-- Game: 466060

-- MAIN APPLICATION
addappid(466060)
-- Game: addappid(466060)

-- MAIN APP DEPOTS / PACKAGES
addappid(466061, 1, "a156a0d52d5d935ea47b52754b5d3a3345dcc54854f9209d28c10901bffb55fa")
