-- Lua provided by RyzenAPI
-- Game: 580420

-- MAIN APPLICATION
addappid(580420)
-- Game: addappid(580420)

-- MAIN APP DEPOTS / PACKAGES
addappid(580421, 1, "c916e265077872b08461cf7ad694054c25a41292ab94c48d7d5106a44ef171ad")
