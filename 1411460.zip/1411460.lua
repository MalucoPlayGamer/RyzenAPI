-- Lua provided by RyzenAPI
-- Game: AppID 1411460

-- MAIN APPLICATION
addappid(1411460)
-- Game: addappid(1411460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411461, 1, "599ce02c2f8ccd17c605c9e1222ed14aae719ada8d057dfa686beaab9c1d807b")
addappid(1411463, 1, "d8b68ef1832ec9ac4dd08539cb5e57cc824929b94578ffa434a91b129440bb67")
