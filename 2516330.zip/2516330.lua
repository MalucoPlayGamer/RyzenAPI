-- Lua provided by RyzenAPI
-- Game: AppID 2516330

-- MAIN APPLICATION
addappid(2516330)
-- Game: addappid(2516330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2516331, 1, "cd81d9cc75238e0e8a31baacc4638958deb934c37e444abf40611709885346ff")
