-- Lua provided by SkyAPI 
-- Game: Package
addappid(2266580)
addappid(2266581, 1, "962339221fef47f43032e056aea18dfd3463ba366042c5acc273e130a071c47e")
