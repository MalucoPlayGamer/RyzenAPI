-- Lua provided by RyzenAPI
-- Game: Nusakana

-- MAIN APPLICATION
addappid(401290)

-- MAIN APP DEPOTS / PACKAGES
addappid(401291, 1, "59ea953c0da1859ea684a18ec368fecb4599cf41d3d9aac13be7ed154fdb8507")
addappid(441760, 0, "52b9438eddc0d247c4e54a92ac74c39144b03a33e0a5bcbc90f956cb9bc9b6d1")
addappid(764600, 0, "d950f19e5c823dccfb509316c621e46ff32c713cc1beb9097dc9309b92a17c06")

