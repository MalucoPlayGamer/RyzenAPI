-- Lua provided by RyzenAPI
-- Game: AppID 414340

-- MAIN APPLICATION
addappid(414340)

-- MAIN APP DEPOTS / PACKAGES
addappid(414341, 1, "b52b49b1aa5b2931a20af4d509e604d4e96a00895d7e75bf04acaffa573ebe09")
addappid(626750, 0, "da8b16e5fa6895ec08a5589fd5b68f1adfe6f1f24c7120e06dc2fdcda3219b4a")
