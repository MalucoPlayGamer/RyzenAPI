-- Lua provided by RyzenAPI
-- Game: AppID 414340

-- MAIN APPLICATION
addappid(414340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(414341, 1, "b52b49b1aa5b2931a20af4d509e604d4e96a00895d7e75bf04acaffa573ebe09")
addappid(626750, 0, "da8b16e5fa6895ec08a5589fd5b68f1adfe6f1f24c7120e06dc2fdcda3219b4a")

