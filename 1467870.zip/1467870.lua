-- Lua provided by RyzenAPI
-- Game: AppID 1467870

-- MAIN APPLICATION
addappid(1467870)
-- Game: addappid(1467870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1467871, 1, "1827f44f44749252f0a6fa8fd0d060637a2007b470882d7ca0eb2e2ebd0057de")
