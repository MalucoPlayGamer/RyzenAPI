-- Lua provided by SkyAPI 
-- Game: AppID 1467870
addappid(1467870)
addappid(1467871, 1, "1827f44f44749252f0a6fa8fd0d060637a2007b470882d7ca0eb2e2ebd0057de")
