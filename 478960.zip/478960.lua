-- Lua provided by RyzenAPI
-- Game: Game: AppID 478960

-- MAIN APPLICATION
addappid(478960)
-- Game: addappid(478960)

-- MAIN APP DEPOTS / PACKAGES
addappid(478961, 1, "db0367033ec6b8e66f4aee9b773379ee5ac5ab37b9df5a4b7a3a26ba50ce0ac4")
