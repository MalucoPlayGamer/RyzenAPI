-- Lua provided by RyzenAPI
-- Game: AppID 872240

-- MAIN APPLICATION
addappid(872240)
addappid(872250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(872241, 1, "7ad4aaffa223bda049dc72bd0f503b86b1443e7bc864eae45a8abae9a5fe14f2")

