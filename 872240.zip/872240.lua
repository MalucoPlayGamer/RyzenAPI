-- Lua provided by RyzenAPI
-- Game: AppID 872240

-- MAIN APPLICATION
addappid(872240)

-- MAIN APP DEPOTS / PACKAGES
addappid(872241, 1, "7ad4aaffa223bda049dc72bd0f503b86b1443e7bc864eae45a8abae9a5fe14f2")

