-- Lua provided by RyzenAPI 
-- Game: War Brokers
addappid(750470)
addappid(750471, 1, "fbd154969f4e3cb7de9b28388358176a6f69a7daf275d61da88d0816561df44c")
