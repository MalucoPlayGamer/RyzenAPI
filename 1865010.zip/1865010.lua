-- Lua provided by RyzenAPI
-- Game: addappid(1865010)

-- MAIN APPLICATION
addappid(1865010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1865011, 1, "2f07cf3e1dbbfdfdc8ee9cb08cd082003a83e2e9eb0b0f67eca58bc874dc7a49")
