-- Lua provided by RyzenAPI
-- Game: Game: High School Otome

-- MAIN APPLICATION
addappid(1168000)
-- Game: addappid(1168000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1168001, 1, "00408f52cd137955ae448a68fb9fe6f34cb9f6796912bb3d3c6548022cbaaa21")
addappid(1168002, 1, "7143aae116ad017e8b808a73bc782941cbeb5295cf116ce184e7edb14f65657c")
addappid(1168003, 1, "c21386697ff59d11930ff8cc7367288495116d14f78f3fd153a8f3600db41f81")
