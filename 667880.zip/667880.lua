-- Lua provided by RyzenAPI
-- Game: Dog Theatre

-- MAIN APPLICATION
addappid(667880)

-- MAIN APP DEPOTS / PACKAGES
addappid(667881,0,"c6478bc3f6b026eca3904b5daba1d9cf56e01e7fd5d4d46c35d18e71e0ede154")

