-- Lua provided by RyzenAPI
-- Game: Weyrwood

-- MAIN APPLICATION
addappid(955370)
-- Game: addappid(955370)

-- MAIN APP DEPOTS / PACKAGES
addappid(955371, 1, "14748636620bb7a55cdc4b48596c6c9954cd47b237ad32f0429b3363a7677367")
