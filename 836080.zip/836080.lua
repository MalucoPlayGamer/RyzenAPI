-- Lua provided by RyzenAPI
-- Game: 836080

-- MAIN APPLICATION
addappid(836080)
-- Game: addappid(836080)

-- MAIN APP DEPOTS / PACKAGES
addappid(836081, 1, "de9fa69b19344ea5b4c0f27986cad156454db8fde28c67c4410798b03558f249")
