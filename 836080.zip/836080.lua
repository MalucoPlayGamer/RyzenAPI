-- Lua provided by RyzenAPI
-- Game: BARRAGE / 铁幕

-- MAIN APPLICATION
addappid(836080)

-- MAIN APP DEPOTS / PACKAGES
addappid(836081, 1, "de9fa69b19344ea5b4c0f27986cad156454db8fde28c67c4410798b03558f249")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
