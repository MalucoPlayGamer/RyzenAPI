-- Lua provided by RyzenAPI
-- Game: Dinosaur World

-- MAIN APPLICATION
addappid(2684370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2684371, 1, "1d51135b1ec009d1df95ef89b2834484566f41f36cde0679a1ce602a635d9fd6")

