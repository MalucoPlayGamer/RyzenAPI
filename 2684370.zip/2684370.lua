-- Lua provided by RyzenAPI
-- Game: Dinosaur World

-- MAIN APPLICATION
addappid(2684370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684371, 1, "1d51135b1ec009d1df95ef89b2834484566f41f36cde0679a1ce602a635d9fd6")

