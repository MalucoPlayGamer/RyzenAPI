-- Lua provided by RyzenAPI
-- Game: Creature Crafter

-- MAIN APPLICATION
addappid(1990050)
addappid(4845920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1990051, 1, "1a899ea1a518a54b37c7002a421793a3d8ec2ee9c3908a6f93baae6a43adc4c3")
addappid(1990052, 1, "fde5bd69ef570158f5d5e2569a21b4871f40462ed19cf5d320f3e2a3fb8c5da9")
addappid(1990053, 1, "d2a1b2a500779621519677ffeff04104eeffd7138b71311487bfa463b314a2e7")
