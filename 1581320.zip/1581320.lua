-- Lua provided by RyzenAPI
-- Game: Earth Guard: Egypt

-- MAIN APPLICATION
addappid(1581320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581321, 1, "b733a067d4c6aee42fc72522dec6d02ef618fcc2b8e735509eaaa833412d6519")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
