-- Lua provided by RyzenAPI
-- Game: Earth Guard: Egypt

-- MAIN APPLICATION
addappid(1581320)
-- Game: addappid(1581320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1581321, 1, "b733a067d4c6aee42fc72522dec6d02ef618fcc2b8e735509eaaa833412d6519")
