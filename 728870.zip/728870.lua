-- Lua provided by RyzenAPI
-- Game: Viaerium

-- MAIN APPLICATION
addappid(728870)
-- Game: addappid(728870)

-- MAIN APP DEPOTS / PACKAGES
addappid(728871, 1, "52177c0733268f85f9b83963dfcd10567f5cf101a45cdac74caa68e99cfcf017")
