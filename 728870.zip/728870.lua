-- Lua provided by RyzenAPI
-- Game: Viaerium

-- MAIN APPLICATION
addappid(728870)

-- MAIN APP DEPOTS / PACKAGES
addappid(728871, 1, "52177c0733268f85f9b83963dfcd10567f5cf101a45cdac74caa68e99cfcf017")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
