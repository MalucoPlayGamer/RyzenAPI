-- Lua provided by RyzenAPI
-- Game: addappid(37220)

-- MAIN APPLICATION
addappid(37220)

-- MAIN APP DEPOTS / PACKAGES
addappid(37221, 1, "f4fb1b41b5fc134b9f6df39f6cbafec576ecadd47d1bf6c2ba5a19e076dc62a6")
