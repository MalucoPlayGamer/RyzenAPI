-- Lua provided by RyzenAPI
-- Game: 2814150

-- MAIN APPLICATION
addappid(2814150)
-- Game: addappid(2814150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2814150,0,"22154b7a022dc68007d4c410facb0d28ac8b4a49313db6ea5c84acfe56497596")
