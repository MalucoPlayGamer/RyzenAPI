-- Lua provided by RyzenAPI
-- Game: WANDERER: Broken Bed - Digital Artbook

-- MAIN APPLICATION
addappid(2814150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2814150,0,"22154b7a022dc68007d4c410facb0d28ac8b4a49313db6ea5c84acfe56497596")

