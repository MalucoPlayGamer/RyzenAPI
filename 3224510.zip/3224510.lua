-- Lua provided by RyzenAPI
-- Game: 3224510

-- MAIN APPLICATION
addappid(3224510)
addappid(3231622)
-- Game: addappid(3224510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3224510,0,"50b5bebde24f276b8f010802cb8153f563e1e403c10df5051a0bdab0039e3b9b")
addappid(3231620,0,"8d317087585b36595d5ccba43d46c93672e355e58d255301ec0fbdb9c2f6b7fa")
