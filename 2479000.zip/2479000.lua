-- Lua provided by RyzenAPI
-- Game: Noise-o-matic

-- MAIN APPLICATION
addappid(2479000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2479001, 1, "f99f8b999e8d4e38a3d473f98e8a2e82918be24e42e446735bd2f89be509fe80")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
