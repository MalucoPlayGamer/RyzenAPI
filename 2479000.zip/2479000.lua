-- Lua provided by SkyAPI 
-- Game: Noise-o-matic
addappid(2479000)
addappid(2479001, 1, "f99f8b999e8d4e38a3d473f98e8a2e82918be24e42e446735bd2f89be509fe80")
