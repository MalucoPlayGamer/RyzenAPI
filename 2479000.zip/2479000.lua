-- Lua provided by RyzenAPI
-- Game: Game: Noise-o-matic

-- MAIN APPLICATION
addappid(2479000)
-- Game: addappid(2479000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2479001, 1, "f99f8b999e8d4e38a3d473f98e8a2e82918be24e42e446735bd2f89be509fe80")
