-- Lua provided by RyzenAPI
-- Game: Knocking Up my Nympho Neighbors

-- MAIN APPLICATION
addappid(2222370)
-- Game: addappid(2222370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2222371, 1, "4b97529b16647c90d68ef8a061b4a4585c9ce7181f5c6653a5de32cfc9b3977a")
