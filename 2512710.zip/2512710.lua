-- Lua provided by RyzenAPI
-- Game: Fuga: Melodies of Steel 2 - Demo

-- MAIN APPLICATION
addappid(2512710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2512711, 1, "49ee9124044c0a6138c883ba250a52ce073fd750461ed01194ff7003ab39a374")
