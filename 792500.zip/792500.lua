-- Lua provided by RyzenAPI
-- Game: Streets Ablaze

-- MAIN APPLICATION
addappid(792500)

-- MAIN APP DEPOTS / PACKAGES
addappid(792501, 1, "817aaa0d9e47f415a8bec95d848d26ed61c5ab5b28ed13193de758e16f6d6e8d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
