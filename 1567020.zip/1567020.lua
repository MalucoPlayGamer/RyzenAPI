-- Lua provided by RyzenAPI
-- Game: The Dark Pictures Anthology: The Devil in Me

-- MAIN APPLICATION
addappid(1567020)
addappid(2108830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1567021, 1, "826b5e1a80a24942cab1635c2015b33bc4a9f6d112e2e39c12fd9546540a123a")
addappid(1567022, 1, "ef30593e1e64890edf4867a53871fbe94c12597c9dd6ead55357bc380474bd65")
addappid(1567023, 1, "28dcdb18ee45b8bd73cc670a2f5900f7c5d61826a48e574471c6d0a7b5afa224")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
