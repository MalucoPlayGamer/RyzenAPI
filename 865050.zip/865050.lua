-- Lua provided by RyzenAPI
-- Game: addappid(865050)

-- MAIN APPLICATION
addappid(865050)

-- MAIN APP DEPOTS / PACKAGES
addappid(865051, 1, "19399769c7dbfaa5eeac4f116ced99a788200c04a05ab9060a0487e6170d1895")
