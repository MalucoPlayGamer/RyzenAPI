-- Lua provided by RyzenAPI
-- Game: AppID 812020

-- MAIN APPLICATION
addappid(812020)
-- Game: addappid(812020)

-- MAIN APP DEPOTS / PACKAGES
addappid(812021, 1, "f60ec3b596e6d7da51815d11c0a07760db081526e95d9bd5f81d9b021cdc1f3e")
