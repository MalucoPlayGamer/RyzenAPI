-- Lua provided by RyzenAPI
-- Game: addappid(2283240)

-- MAIN APPLICATION
addappid(2283240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2283241, 1, "d4267e6917c358630ced3b5ea8e30bfc12885c30970fcab928c835fe78baa89d")
