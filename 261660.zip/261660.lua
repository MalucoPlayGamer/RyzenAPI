-- Lua provided by RyzenAPI 
-- Game: AppID 261660
addappid(261660)
addappid(261661, 1, "0ca46c5e29bf082a9c2a843b0167164e227bb78f4e52a6422d620d552bbcdf72")
