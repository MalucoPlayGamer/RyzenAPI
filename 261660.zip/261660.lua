-- Lua provided by RyzenAPI
-- Game: Serious Sam Classics: Revolution Toolkit

-- MAIN APPLICATION
addappid(261660)

-- MAIN APP DEPOTS / PACKAGES
addappid(261661, 1, "0ca46c5e29bf082a9c2a843b0167164e227bb78f4e52a6422d620d552bbcdf72")
