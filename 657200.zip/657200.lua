-- Lua provided by RyzenAPI
-- Game: Hand Simulator

-- MAIN APPLICATION
addappid(657200)

-- MAIN APP DEPOTS / PACKAGES
addappid(657201, 1, "98696297d19b950f17a54b6507fafdea956f0034d8ba3ab01810a1e7b707aa82")

