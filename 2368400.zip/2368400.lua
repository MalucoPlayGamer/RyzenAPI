-- Lua provided by RyzenAPI
-- Game: Complex Loop

-- MAIN APPLICATION
addappid(2368400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2368401, 1, "63ef612589793ca23db97a808e3376f1e580e34cd4d5662c4bfdb32e29c6597a")
