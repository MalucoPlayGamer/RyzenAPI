-- Lua provided by RyzenAPI
-- Game: Cow Girls 18+ Adult Only Content

-- MAIN APPLICATION
addappid(1839790)
-- Game: addappid(1839790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1839790,0,"9d7416e2d3853a689c3642f42a800e64237431e3c972506158ab4e8d8ff940fc")
