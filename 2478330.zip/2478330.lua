-- Lua provided by RyzenAPI
-- Game: Barbie Project Friendship™

-- MAIN APPLICATION
addappid(2478330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478331, 1, "e49eba53be7529ceb62748e296029ebecd9406d4b10850828490079ed981e154")
