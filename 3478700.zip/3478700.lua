-- Lua provided by RyzenAPI
-- Game: The Children of Clay

-- MAIN APPLICATION
addappid(3478700)

