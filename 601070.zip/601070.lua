-- Lua provided by RyzenAPI
-- Game: VoiceAttack Demo

-- MAIN APPLICATION
addappid(601070)

-- MAIN APP DEPOTS / PACKAGES
addappid(601071, 1, "e6385c341a2889e5c9f1146ff067671009a9b749f1cedbbb13d540940e488302")

