-- Lua provided by RyzenAPI
-- Game: 2102750

-- MAIN APPLICATION
addappid(2102750)
-- Game: addappid(2102750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102751, 1, "cfe7c78629700fcfea0f4a72226a066cb6aaf130b5a3ce78884d80639d06a295")
addappid(2102752, 1, "04abd3646a0c43c2abdf8ac7b3aec7d009731c10c024356d21195cf3bf7b2f58")
addappid(2102753, 1, "7340c0bf910b9b8ff17cb215c6c5a171bbcb50e450f69ecd6d0caf227a494b9e")
