-- Lua provided by RyzenAPI
-- Game: Cat's Kiss - ArtBook

-- MAIN APPLICATION
addappid(3001080)
-- Game: addappid(3001080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3001080,0,"7df367d17bdc49e855f3e87857a323fe74bdd009da4085a3cff74aac3f7a6423")
