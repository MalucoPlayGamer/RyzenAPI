-- Lua provided by RyzenAPI
-- Game: StarVaders Demo

-- MAIN APPLICATION
addappid(2417280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2417281, 1, "f9fb3d910c0845c6ccf50025b56936000b9197675ecf1e55e203ec65b3e2b585")

