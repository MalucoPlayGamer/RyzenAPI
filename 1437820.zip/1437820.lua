-- Lua provided by RyzenAPI
-- Game: addappid(1437820)

-- MAIN APPLICATION
addappid(1437820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437821, 1, "4cc3e9f102cf89e0b57c706fa46615a76ab145eba3ab35d6b6703929e6623fa9")
addappid(1437822, 1, "e5db8c962dc3a9d422a8242c6d999a7fb978e9aee2cd5d649215b88761d8dca2")
