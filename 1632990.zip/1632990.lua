-- Lua provided by RyzenAPI
-- Game: The last tank fight

-- MAIN APPLICATION
addappid(1632990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632992,0,"b5c5756b7ad4ee7a621a8153a57c9596bb759ee7c60a2f1620e5d58861ea9479")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
