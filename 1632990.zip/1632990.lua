-- Lua provided by RyzenAPI
-- Game: The last tank fight

-- MAIN APPLICATION
addappid(1632990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1632992,0,"b5c5756b7ad4ee7a621a8153a57c9596bb759ee7c60a2f1620e5d58861ea9479")

