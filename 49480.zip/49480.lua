-- Lua provided by RyzenAPI
-- Game: Game: Magic the Gathering: Duels of the Planeswalkers 2012 Demo

-- MAIN APPLICATION
addappid(49480)
-- Game: addappid(49480)

-- MAIN APP DEPOTS / PACKAGES
addappid(49481, 1, "3ec725a82d598e1111a2f32d1fb6ac2b9c8fcd60854b92e28957e1560c8281ea")
