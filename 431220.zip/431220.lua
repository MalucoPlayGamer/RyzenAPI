-- Lua provided by RyzenAPI
-- Game: Porradaria 2: Pagode of the Night

-- MAIN APPLICATION
addappid(431220)
addappid(502980)
addappid(812820)
addappid(812830)

-- MAIN APP DEPOTS / PACKAGES
addappid(431221, 1, "ae99d553bf906130c89db93a239de9b9366cb4fddd15fa01e78ab5b2fd69cb1e")
addappid(431222, 1, "f3b6de262d08b2871d4bd9cfc050a253e882fd938f417968550462c308198885")
