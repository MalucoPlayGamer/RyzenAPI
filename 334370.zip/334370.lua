-- Lua provided by RyzenAPI
-- Game: addappid(334370)

-- MAIN APPLICATION
addappid(334370)

-- MAIN APP DEPOTS / PACKAGES
addappid(334371, 1, "4433242192361dceb3511d13aeec557c20a2535dbebeace22603c792692c3c84")
