-- Lua provided by RyzenAPI
-- Game: 1324530

-- MAIN APPLICATION
addappid(1324530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1324532,0,"93ba9fa3b21fcd353c2c8762a2c9adc8f29aec232ff6cf8053f1502de6312d42")
addappid(1324533,0,"eb1364bbe55e335d430ddca29f36b8c32df10ca582a4a715a5cdcd99db9e2ae2")

