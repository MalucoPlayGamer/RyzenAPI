-- Lua provided by RyzenAPI
-- Game: Dark Skeleton Survival

-- MAIN APPLICATION
addappid(1084910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1084911, 1, "3d8a773294417446215f57d45ca96204322946200ed37cca8519dc126cafd168")

