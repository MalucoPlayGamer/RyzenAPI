-- Lua provided by RyzenAPI
-- Game: addappid(3192510)

-- MAIN APPLICATION
addappid(3192510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3192511, 1, "b88a9f67eb1eb3b720a45780770ff76d5fa908c6dd63636edd3d473c9f1dca8a")
