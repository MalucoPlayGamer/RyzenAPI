-- Lua provided by RyzenAPI
-- Game: PowerSlave Exhumed

-- MAIN APPLICATION
addappid(1678430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1678431, 1, "e5cd82c8c8368c64e573b9b28291fc5b8a4ccac818fcb5fcf414021b2181dc5a")
addappid(1678432, 1, "a70b44bde0abadbf93474f6765e7a2771bc0a6455e80a180efa09a7c9a6db9a3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
