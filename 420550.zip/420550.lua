-- Lua provided by RyzenAPI
-- Game: Super Arcade Football

-- MAIN APPLICATION
addappid(420550)

-- MAIN APP DEPOTS / PACKAGES
addappid(420551, 1, "1df7eead428ee077eac68da90b9ae8e19f2333eaa99fd71d74db4ec8aeb8b590")
