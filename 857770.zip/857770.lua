-- Lua provided by RyzenAPI
-- Game: Game: The Risers

-- MAIN APPLICATION
addappid(857770)
-- Game: addappid(857770)

-- MAIN APP DEPOTS / PACKAGES
addappid(857771, 1, "84021c2f431626558aece669fd31de88a57938c65d5cbd868c4fc568ed24f283")
