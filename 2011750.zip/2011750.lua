-- Lua provided by RyzenAPI
-- Game: Silver Lines

-- MAIN APPLICATION
addappid(2011750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2011752,0,"8862d5cb586b6eac973ef690603b0376947c50a27c38a9b2592e48e1bdcdb854")
addappid(2011753,0,"dc13efaea8ba992a6a7ae9cd7cb3fd64c4ec37f7b605fefd81260af0ad70cccc")
addappid(2011754,0,"0476848edf56b6c7d7e1b1c27b005a7cd3f19494d0152ddb5fa7e37fb7e1322d")

