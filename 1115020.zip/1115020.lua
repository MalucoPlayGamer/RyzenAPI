-- Lua provided by RyzenAPI
-- Game: 老板攻略

-- MAIN APPLICATION
addappid(1115020)
addappid(1115021)
addappid(1115022)
-- Game: addappid(1115020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1115023,0,"dbcdaecd856bafe10cb9e4093c3a7dceb9b03b79eb4520843186a7f086579324")
