-- Lua provided by RyzenAPI
-- Game: Liminal Space

-- MAIN APPLICATION
addappid(2413230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413231, 1, "03f8bdfa7438b5d3754968c15451520f05eaf7f8edc6d42f4008339671d14b5c")
