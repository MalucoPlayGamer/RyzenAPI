-- Lua provided by RyzenAPI
-- Game: AppID 579720

-- MAIN APPLICATION
addappid(579720)

-- MAIN APP DEPOTS / PACKAGES
addappid(579721, 1, "f260bf2098cee646a3a3ed40fd4513eafb7229735d8c1dd1ff45cf6f19551673")

