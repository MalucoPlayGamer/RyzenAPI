-- Lua provided by RyzenAPI
-- Game: AppID 982880

-- MAIN APPLICATION
addappid(982880)
-- Game: addappid(982880)

-- MAIN APP DEPOTS / PACKAGES
addappid(982881, 1, "c31fec4c8d3cd942bb61b4b992b0381a67087a56dbe994cd0c24651299a35434")
