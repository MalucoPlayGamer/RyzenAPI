-- Lua provided by RyzenAPI
-- Game: AppID 546400

-- MAIN APPLICATION
addappid(546400)
-- Game: addappid(546400)

-- MAIN APP DEPOTS / PACKAGES
addappid(546401, 1, "9b80ace49cbde89e40e5b8e64e1a5d152ff1150b235ca501725d6ebc6d6e5b6d")
