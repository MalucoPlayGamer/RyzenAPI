-- Lua provided by RyzenAPI
-- Game: Cavern Escape

-- MAIN APPLICATION
addappid(546400)
addappid(579750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(546401, 1, "9b80ace49cbde89e40e5b8e64e1a5d152ff1150b235ca501725d6ebc6d6e5b6d")
