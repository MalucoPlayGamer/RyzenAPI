-- Lua provided by SkyAPI 
-- Game: AppID 546400
addappid(546400)
addappid(546401, 1, "9b80ace49cbde89e40e5b8e64e1a5d152ff1150b235ca501725d6ebc6d6e5b6d")
