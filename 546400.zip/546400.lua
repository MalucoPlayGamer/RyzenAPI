-- Lua provided by RyzenAPI
-- Game: AppID 546400

-- MAIN APPLICATION
addappid(546400)

-- MAIN APP DEPOTS / PACKAGES
addappid(546401, 1, "9b80ace49cbde89e40e5b8e64e1a5d152ff1150b235ca501725d6ebc6d6e5b6d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(579750)
