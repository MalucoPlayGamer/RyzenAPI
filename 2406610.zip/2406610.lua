-- Lua provided by RyzenAPI
-- Game: Game: AppID 2406610

-- MAIN APPLICATION
addappid(2406610)
-- Game: addappid(2406610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406611, 1, "58f75d89d5f14636fb2587dd71a058e79452e09bea06f5ad4f4684f9ec938b15")
