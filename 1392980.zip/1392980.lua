-- Lua provided by RyzenAPI
-- Game: Game: AppID 1392980

-- MAIN APPLICATION
addappid(1392980)
-- Game: addappid(1392980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1392981, 1, "4f4511b54568ae7c269a852d029f86bb01bcdbd292f2d13822ac4d7fdd29caf5")
