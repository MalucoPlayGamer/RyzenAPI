-- Lua provided by RyzenAPI
-- Game: 2242550

-- MAIN APPLICATION
addappid(2242550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242552,0,"abc141bc2821e422d64c0f0e03edea8d59b43dbb8c8342c634a3bcd2c131bddb")
addappid(2242553,0,"30d3626cbf593ec499808fc5ea16d7774ecfbd719fe61eb2f866c271e8862716")
addappid(2242554,0,"09b39fddc6ea30aa0518f9ff5f3a1343ebe649e0c4fddba118dbe92e8b2eb74e")
