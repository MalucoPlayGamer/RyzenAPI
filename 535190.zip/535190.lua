-- Lua provided by RyzenAPI
-- Game: Chunky Orbits

-- MAIN APPLICATION
addappid(535190)

-- MAIN APP DEPOTS / PACKAGES
addappid(535191,0,"fa3f012a64602c397a258ee7d68e7019b8c0ced461479f712685008f52dc3d0c")

