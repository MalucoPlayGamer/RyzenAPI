-- Lua provided by RyzenAPI
-- Game: Game: Love n War: Hero by Chance

-- MAIN APPLICATION
addappid(1433420)
addappid(1434450)
-- Game: addappid(1433420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1433421, 1, "485f83a6148c298e5597c867aa560d8fb0a03f3080ae78b9abf98ef631913362")
