-- Lua provided by RyzenAPI
-- Game: Progressbar95

-- MAIN APPLICATION
addappid(1304550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304551, 1, "1b0f19a431e308f5cd8444531c97409fd46eebe8d4d00ccf93b757d4b8e8279e")
