-- Lua provided by RyzenAPI
-- Game: 912380

-- MAIN APPLICATION
addappid(912380)

-- MAIN APP DEPOTS / PACKAGES
addappid(912383,0,"c16acf05eb788cc4f1fe7c7c8dbf9dd34c0942586a4898e07dc9e2d8bd9340c8")

