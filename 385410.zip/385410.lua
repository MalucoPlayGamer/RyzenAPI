-- Lua provided by RyzenAPI
-- Game: The Journey: Bob's Story

-- MAIN APPLICATION
addappid(385410)

-- MAIN APP DEPOTS / PACKAGES
addappid(385411, 1, "2f940c2654b591e00cb7f3fe93a1c61bca68f7173bec9e0b170a8373b7fd8bee")
addappid(385415, 1, "b11feada0d1ee6f9f967ee87d06e5c5ee4f8da61e208c12c40cdece3366b2c34")

