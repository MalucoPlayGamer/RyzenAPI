-- Lua provided by RyzenAPI
-- Game: Trinoline All Ages Version

-- MAIN APPLICATION
addappid(965010)

-- MAIN APP DEPOTS / PACKAGES
addappid(965011, 1, "b52e727da2f1b0e967c6a17f180b1d8f3fd2049663c71d7d5d2fb15f15bbdb21")
addappid(965012, 1, "782a7e4fbee43da0017c7b5a6abd588bec9c17a9871d5304fae68b570594c53e")
