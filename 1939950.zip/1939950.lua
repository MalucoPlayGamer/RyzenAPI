-- Lua provided by RyzenAPI
-- Game: Game: Toziuha Night: Dracula's Revenge Soundtrack - Lydium Music

-- MAIN APPLICATION
addappid(1939950)
-- Game: addappid(1939950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939951, 1, "c1ad1e7c5bbc34d3d6644344123132e9f8017e841d38ed2bfe8ff917d906e94a")
