-- Lua provided by RyzenAPI
-- Game: Laika: Aged Through Blood

-- MAIN APPLICATION
addappid(1796220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796221, 1, "408f773b77855a7d717242c7888fd324568fb64132fef6bdb24c500ce3837c29")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
