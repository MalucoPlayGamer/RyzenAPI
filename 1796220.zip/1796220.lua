-- Lua provided by RyzenAPI
-- Game: Laika: Aged Through Blood

-- MAIN APPLICATION
addappid(1796220)
-- Game: addappid(1796220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1796221, 1, "408f773b77855a7d717242c7888fd324568fb64132fef6bdb24c500ce3837c29")
