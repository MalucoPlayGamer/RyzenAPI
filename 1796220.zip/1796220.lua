-- Lua provided by SkyAPI 
-- Game: Laika: Aged Through Blood
addappid(1796220)
addappid(1796221, 1, "408f773b77855a7d717242c7888fd324568fb64132fef6bdb24c500ce3837c29")
