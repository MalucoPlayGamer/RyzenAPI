-- Lua provided by RyzenAPI
-- Game: Game: Undead World

-- MAIN APPLICATION
addappid(2193420)
-- Game: addappid(2193420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2193421, 1, "3d75f0cefe4b8797b73678042c6c97dc0be2da6b8786997c909fd342f984aceb")
