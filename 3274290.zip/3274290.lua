-- Lua provided by RyzenAPI
-- Game: 3274290

-- MAIN APPLICATION
addappid(3274290)
-- Game: addappid(3274290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274290,0,"9e3faa44c9b3388e76b6295d61402cade160d03a99e9a39ee2fcd6f5d3a97a4b")
