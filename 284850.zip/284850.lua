-- Lua provided by RyzenAPI 
-- Game: Grim Legends: The Forsaken Bride
addappid(284850)
addappid(284851, 1, "2509f91956f635c0a4c69258cb244b61a36ea92fab5e7ac23978bc73b4f7dd4c")
addappid(284852, 1, "3f19d943bb70e055dea601d96a483090dee0f5279dada53346e4442886e7e392")
addappid(284853, 1, "8f4ffd4602f2e2b65add6bb05908549811ca9efdf2a011725ad39c0c24e74d15")
