-- Lua provided by RyzenAPI
-- Game: Game: Boxville 2

-- MAIN APPLICATION
addappid(3131280)
-- Game: addappid(3131280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3131281, 1, "70f89e2cfbcc63a105e9b01e105a61415e6ae9ebdfe4e1332b8e2abfc413b5dc")
addappid(3720850, 0, "9340606699d84a264f8bc6bb3c8fe6157c9dfea6dce79c9d1192741dbc8c7b57")
