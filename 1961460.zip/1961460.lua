-- Lua provided by RyzenAPI
-- Game: addappid(1961460)

-- MAIN APPLICATION
addappid(1961460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961461, 1, "17956181b3ebd93ab3c4bd1e835e167974ae62c25accdf18dc9257d576a2c955")
