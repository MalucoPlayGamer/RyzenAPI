-- Lua provided by SkyAPI 
-- Game: Unicorns on Unicycles
addappid(1418990)
addappid(1418991, 1, "bc7741d0322880cb69d73e9d2b83bd23b1aca06ecf24dc62e39b4531a33a23ef")
