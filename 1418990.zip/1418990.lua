-- Lua provided by RyzenAPI
-- Game: addappid(1418990)

-- MAIN APPLICATION
addappid(1418990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418991, 1, "bc7741d0322880cb69d73e9d2b83bd23b1aca06ecf24dc62e39b4531a33a23ef")
