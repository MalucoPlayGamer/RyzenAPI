-- Lua provided by RyzenAPI
-- Game: Russian Psychiatric Pastoral Demo

-- MAIN APPLICATION
addappid(2465050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2465051, 1, "00fa1497a628df650405d7c49ec2281e79ccf70e636a5d8479994fd41d60d0df")

