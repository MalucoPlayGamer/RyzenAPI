-- Lua provided by RyzenAPI
-- Game: Game: AppID 446250

-- MAIN APPLICATION
addappid(446250)
-- Game: addappid(446250)

-- MAIN APP DEPOTS / PACKAGES
addappid(446251, 1, "5260a6528fdb586a0852699070be0a8bb7ce184649a8343415d439ca5c20442a")
