-- Lua provided by RyzenAPI
-- Game: AppID 858420

-- MAIN APPLICATION
addappid(858420)
-- Game: addappid(858420)

-- MAIN APP DEPOTS / PACKAGES
addappid(858421, 1, "9f920f5d4e95505f3307a54c75d6259fed38b76c96f0a0d7fee5f8ac94d9e592")
