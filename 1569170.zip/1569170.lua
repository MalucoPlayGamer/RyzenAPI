-- Lua provided by RyzenAPI
-- Game: A Way Back

-- MAIN APPLICATION
addappid(1569170)
-- Game: addappid(1569170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1569172,0,"01aeab064e3b5fb6a7a701c356cd2b209c336daa493fd0262d46100460ef9d5a")
