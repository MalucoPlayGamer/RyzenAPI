-- Lua provided by RyzenAPI
-- Game: addappid(3289470)

-- MAIN APPLICATION
addappid(3289470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3289471, 1, "b1ee693a60983ed8c51105df2df4e8873611e1012a34a05c3b6efadeba1fe997")
