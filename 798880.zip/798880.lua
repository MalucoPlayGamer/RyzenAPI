-- Lua provided by RyzenAPI
-- Game: addappid(798880)

-- MAIN APPLICATION
addappid(798880)

-- MAIN APP DEPOTS / PACKAGES
addappid(798880,0,"e93184e1084c21e08fdf30e4ba3bc50ad166d284790b4e8bc8558532ed1be543")
