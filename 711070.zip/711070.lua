-- Lua provided by RyzenAPI
-- Game: 711070

-- MAIN APPLICATION
addappid(711070)
-- Game: addappid(711070)

-- MAIN APP DEPOTS / PACKAGES
addappid(711071, 1, "237603a74faccec2c9345d8eddeac5a42975bc098a9b58d1f403157a548320f1")
