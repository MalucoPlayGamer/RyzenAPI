-- Lua provided by RyzenAPI
-- Game: Revenge Of Noxi

-- MAIN APPLICATION
addappid(2448620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2448621, 1, "954c2bfac638ff7fe7fb9e3809394538054812191b67e56e3ea2b6c430516450")
