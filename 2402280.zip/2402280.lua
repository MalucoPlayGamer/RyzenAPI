-- Lua provided by RyzenAPI
-- Game: Werewolf: The Apocalypse — The Book of Hungry Names

-- MAIN APPLICATION
addappid(2402280)
-- Game: addappid(2402280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2402281, 1, "b90f12907cbc9568250aeb7ed1edc521a45ae3b33b6899dbc1a1fb928057e1d5")
