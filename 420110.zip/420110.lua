-- Lua provided by RyzenAPI
-- Game: NEKOPARA Vol. 2

-- MAIN APPLICATION
addappid(420110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(420111, 1, "9cf997ac955b6d9fe36be077adff4c110376a54dfdefc6977881ea3a920c1f15")
addappid(947660, 0, "4569d5df4d3a3c91e6fa8a0aaa88868f7db832f060bdb8251cd89f277745cc40")
addappid(1088340, 0, "bec13995fdf7953ad89f88584281ef6e98dbb865cf9efe70ed758c260498aa1e")

