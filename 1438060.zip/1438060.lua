-- Lua provided by RyzenAPI
-- Game: Rolls and Girls

-- MAIN APPLICATION
addappid(1438060)
-- Game: addappid(1438060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1438061, 1, "7d31a8d341b04349cad32b639dbbb1618addec17e85b6f56442b1cffab704b89")
