-- Lua provided by RyzenAPI
-- Game: Unknown Signal

-- MAIN APPLICATION
addappid(2808760)
-- Game: addappid(2808760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2808761, 1, "96618305dedbc3aff03bfd1af2339f201ab00935e492b327b3c69b0319dbc925")
