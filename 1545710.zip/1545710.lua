-- Lua provided by RyzenAPI 
-- Game: Snowpainters
addappid(1545710)
addappid(1545711, 1, "99dc7a8bb1db267fee198e7eca189679462c6c43b0dfe0d31c3742b9fe493759")
