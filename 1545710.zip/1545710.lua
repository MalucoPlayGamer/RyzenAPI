-- Lua provided by RyzenAPI
-- Game: addappid(1545710)

-- MAIN APPLICATION
addappid(1545710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1545711, 1, "99dc7a8bb1db267fee198e7eca189679462c6c43b0dfe0d31c3742b9fe493759")
