-- Lua provided by RyzenAPI
-- Game: addappid(800600)

-- MAIN APPLICATION
addappid(800600)

-- MAIN APP DEPOTS / PACKAGES
addappid(800601, 1, "2ac4cef0f47108a7fb8138b4f5fabf8a23d8e1b681d4b595c04d4475f49c3275")
