-- Lua provided by RyzenAPI
-- Game: addappid(2838290)

-- MAIN APPLICATION
addappid(2838290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838290,0,"4c79a41246d3077e638638dcb6dd607acae87c4fdacfd64ced5d5f6bac282d5b")
