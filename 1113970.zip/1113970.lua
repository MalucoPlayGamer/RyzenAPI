-- Lua provided by RyzenAPI
-- Game: addappid(1113970)

-- MAIN APPLICATION
addappid(1113970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1113971, 1, "e4edaed8759e1a705c580da8221e32c962e003e94f40432286131c93cf65e3d2")
