-- Lua provided by RyzenAPI
-- Game: Little Brother Jim

-- MAIN APPLICATION
addappid(1113970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1113971, 1, "e4edaed8759e1a705c580da8221e32c962e003e94f40432286131c93cf65e3d2")

