-- Lua provided by RyzenAPI
-- Game: Sink or Skim

-- MAIN APPLICATION
addappid(761290)
-- Game: addappid(761290)

-- MAIN APP DEPOTS / PACKAGES
addappid(761291, 1, "8fc105f24046875b036ec47b698821d60ab2d6483924565da77d1a874ab7c5d3")
