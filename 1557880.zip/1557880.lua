-- Lua provided by RyzenAPI
-- Game: Wood Killer

-- MAIN APPLICATION
addappid(1557880)
-- Game: addappid(1557880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1557881, 1, "ad5938aca1f5ea068851b29108cad91356a5d03cbc97bbb68cb4595e4485d95e")
