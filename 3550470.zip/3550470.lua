-- Lua provided by RyzenAPI
-- Game: 3550470

-- MAIN APPLICATION
addappid(3550470)
-- Game: addappid(3550470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3550471, 1, "67f4ff1832c38eca69da8452d2ad4f672c9d8951d2ad590e30a901adf63d5b67")
