-- Lua provided by RyzenAPI
-- Game: Where's My Mommy?

-- MAIN APPLICATION
addappid(423610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(423611, 1, "73765a82a96361a2584438f8d8b5dabfcc40a86a0d0ac13f688b62cfc07fdf73")
addappid(423612, 1, "a9e6397388759d0daef262d97d60b93bc4eb42716e3f85e08cb180ba414dc604")
addappid(423613, 1, "cd5c43aa1ca7d0f267b9ba509ef864f1e613f87edd3afef123fc811a58433a43")
addappid(446350, 0, "d219bc6dc05b50152e72293a2d35efdb4906e40f7a42cfb46b31138c5d9adbc6")
