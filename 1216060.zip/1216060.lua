-- Lua provided by RyzenAPI
-- Game: addappid(1216060)

-- MAIN APPLICATION
addappid(1216060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216061, 1, "799d0e8b731a8b1acee2238bb479c2e3023d26597704ae7edcb5c19569f1d30e")
