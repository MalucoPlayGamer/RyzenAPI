-- Lua provided by RyzenAPI
-- Game: DNF DUEL

-- MAIN APPLICATION
addappid(1216060) -- DNF DUEL
addappid(2223030) -- DNF Duel - DLC 1 Spectre
addappid(2430130) -- DNF Duel - Season Pass
addappid(2463770) -- DNF Duel - DLC 2 Brawler
addappid(2463771) -- DNF Duel - DLC 3 Battle Mage
addappid(2463772) -- DNF Duel - DLC 4 Monk
addappid(2463773) -- DNF Duel - DLC 5 Nen Master

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(1216061, 1, "799d0e8b731a8b1acee2238bb479c2e3023d26597704ae7edcb5c19569f1d30e") -- Depot 1216061

