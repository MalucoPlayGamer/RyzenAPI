-- Lua provided by RyzenAPI
-- Game: addappid(3142110)

-- MAIN APPLICATION
addappid(3142110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3142110,0,"56a84d1eba4c610625e7fe6abff1f0a3bf063d5e8095550c005d0e7b2b40c6e7")
