-- Lua provided by RyzenAPI
-- Game: Robbery Bob: Man of Steal

-- MAIN APPLICATION
addappid(372960)
-- Game: addappid(372960)

-- MAIN APP DEPOTS / PACKAGES
addappid(372961, 1, "2eae495bbc866ad7a2b5c4c8cf5f0610c618504bea06cdb03b9134c1f5f079a6")
