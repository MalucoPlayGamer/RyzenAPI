-- Lua provided by RyzenAPI
-- Game: Robbery Bob: Man of Steal

-- MAIN APPLICATION
addappid(372960)

-- MAIN APP DEPOTS / PACKAGES
addappid(372961, 1, "2eae495bbc866ad7a2b5c4c8cf5f0610c618504bea06cdb03b9134c1f5f079a6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
