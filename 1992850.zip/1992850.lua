-- Lua provided by RyzenAPI
-- Game: Cyrah's Ascent

-- MAIN APPLICATION
addappid(1992850)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1992851, 1, "9a66a77db19bb015e77680629dee58cb1ae3d9902e3261910bd0b5f8275c7495")

