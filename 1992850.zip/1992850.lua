-- Lua provided by RyzenAPI
-- Game: Game: Cyrah's Ascent

-- MAIN APPLICATION
addappid(1992850)
-- Game: addappid(1992850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1992851, 1, "9a66a77db19bb015e77680629dee58cb1ae3d9902e3261910bd0b5f8275c7495")
