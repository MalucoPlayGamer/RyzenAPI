-- Lua provided by SkyAPI 
-- Game: Cyrah's Ascent
addappid(1992850)
addappid(1992851, 1, "9a66a77db19bb015e77680629dee58cb1ae3d9902e3261910bd0b5f8275c7495")
