-- Lua provided by RyzenAPI
-- Game: Game: Trivia Vault: Food Trivia

-- MAIN APPLICATION
addappid(861720)
-- Game: addappid(861720)

-- MAIN APP DEPOTS / PACKAGES
addappid(861721, 1, "6ff12891b6f1c743f6752cf18fe3b35b0a5c3d87f4c49dbde3eab935939ac206")
