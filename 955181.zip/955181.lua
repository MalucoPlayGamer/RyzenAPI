-- Lua provided by RyzenAPI
-- Game: addappid(955181)

-- MAIN APPLICATION
addappid(955181)

-- MAIN APP DEPOTS / PACKAGES
addappid(955181,0,"80f6199af636654f38656dcc4a228b9c176045570a731f9d6b0e9f73dd09bb9b")
