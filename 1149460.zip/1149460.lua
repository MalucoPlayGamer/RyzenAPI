-- Lua provided by RyzenAPI
-- Game: ICARUS

-- MAIN APPLICATION
addappid(1149460)
addappid(1648532)
addappid(1648533)
addappid(1648540)
addappid(1648541)
addappid(1995690)
addappid(2445280)
addappid(2536360)
addappid(2536370)
addappid(2536380)
addappid(2536390)
addappid(2679990)
addappid(2686540)
addappid(2790990)
addappid(2791000)
addappid(2923820)
addappid(2923830)
addappid(3052290)
addappid(3315290)
addappid(3364360)
addappid(3984230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1149461,0,"c71fc47ef9e1e718df06677c0d6cf06fc0f01145d8481e0db444a26eed261296")

