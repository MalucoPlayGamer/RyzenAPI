-- Lua provided by RyzenAPI 
-- Game: AppID 838390
addappid(838390)
addappid(838391, 1, "d71b9ac6de72917f6f6c1c6731e1da0dc1cfcb46b80f359e3ee02f555c6c765c")
addappid(859600)
