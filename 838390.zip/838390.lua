-- Lua provided by RyzenAPI
-- Game: 838390

-- MAIN APPLICATION
addappid(838390)
addappid(859600)
-- Game: addappid(838390)

-- MAIN APP DEPOTS / PACKAGES
addappid(838391, 1, "d71b9ac6de72917f6f6c1c6731e1da0dc1cfcb46b80f359e3ee02f555c6c765c")
