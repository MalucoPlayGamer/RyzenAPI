-- Lua provided by RyzenAPI
-- Game: addappid(2443560)

-- MAIN APPLICATION
addappid(2443560)
addappid(2453540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443561, 1, "68430f79fad57dc8844a659b60bb85ea42e7c3eca7d981dc5b2a0f2e198364ae")
