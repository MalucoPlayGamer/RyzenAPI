-- Lua provided by RyzenAPI
-- Game: addappid(2724570)

-- MAIN APPLICATION
addappid(2724570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2724571, 1, "14cedd63d8c6ae82f790917644537a265a64f453cd441f223dd6405bea75c33c")
