-- Lua provided by RyzenAPI
-- Game: Magical Mysteries: Path of the Sorceress

-- MAIN APPLICATION
addappid(548320)
addappid(549940)

-- MAIN APP DEPOTS / PACKAGES
addappid(548321, 1, "9ffb20fac2d22ad7a348b140d05b6efd969ac6e9a773f1bd56029717a90dc2ad")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
