-- Lua provided by RyzenAPI
-- Game: Magical Mysteries: Path of the Sorceress

-- MAIN APPLICATION
addappid(548320)
addappid(549940)

-- MAIN APP DEPOTS / PACKAGES
addappid(548321, 1, "9ffb20fac2d22ad7a348b140d05b6efd969ac6e9a773f1bd56029717a90dc2ad")

