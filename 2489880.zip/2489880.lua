-- Lua provided by RyzenAPI 
-- Game: Guerra Sangrenta
addappid(2489880)
addappid(2489881, 1, "742d2309728020437c36c14ec028b57c93a80ec4061ce151bb6125cbad5fb2c9")
