-- Lua provided by RyzenAPI
-- Game: Holyday City: Reloaded

-- MAIN APPLICATION
addappid(728730)

