-- Lua provided by RyzenAPI
-- Game: Game: Flatinside Simulator

-- MAIN APPLICATION
addappid(3318000)
-- Game: addappid(3318000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3318001, 1, "54a4a4373a13cd661225fbbc6dea32af207d9c82d659270c80804a2b4c8175cf")
