-- Lua provided by RyzenAPI
-- Game: Flatinside Simulator

-- MAIN APPLICATION
addappid(3318000)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3318001, 1, "54a4a4373a13cd661225fbbc6dea32af207d9c82d659270c80804a2b4c8175cf")

