-- Lua provided by RyzenAPI
-- Game: Game: TerraTech Worlds Demo

-- MAIN APPLICATION
addappid(2540300)
-- Game: addappid(2540300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2540301, 1, "fdac7cdd827513fbaed27ab21d8271181ad566b59c0bf16702747c01f39a7c62")
