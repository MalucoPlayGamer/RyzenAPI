-- Lua provided by RyzenAPI
-- Game: 90 Minute Fever

-- MAIN APPLICATION
addappid(468070)
addappid(492810)

-- MAIN APP DEPOTS / PACKAGES
addappid(468071, 1, "e2fffc3d364bb3860f9a90f5322ba572cc7f3dd98395d3b66076e021bf28a057")
addappid(468072, 1, "bc9faf1db3dfd34f17b6a15d26b73602d4b4cbbfc5b034a27012ee721add1176")
addappid(468073, 1, "ba86c8af63f0671e749ae54a9ecbf8310c2fe8c9df5b97554395645d1b962bac")

