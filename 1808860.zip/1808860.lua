-- Lua provided by RyzenAPI
-- Game: Game: Pizza Man

-- MAIN APPLICATION
addappid(1808860)
-- Game: addappid(1808860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808861, 1, "2abb965011c3dcbefc43a57429521af2a43cac0a1cc86bdc266f2447f5006a63")
