-- Lua provided by RyzenAPI
-- Game: Fate/hollow ataraxia REMASTERED

-- MAIN APPLICATION
addappid(2396990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396991, 1, "5100b046f94ce318bd23122f91c9d90b4a0e8c0e873bee7bde1cea354300cc52")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
