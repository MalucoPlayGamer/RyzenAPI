-- Lua provided by RyzenAPI
-- Game: 2396990

-- MAIN APPLICATION
addappid(2396990)
-- Game: addappid(2396990)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396991, 1, "5100b046f94ce318bd23122f91c9d90b4a0e8c0e873bee7bde1cea354300cc52")
