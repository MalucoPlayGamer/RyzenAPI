-- Lua provided by RyzenAPI
-- Game: VR Hentai Simulation Desktop mode

-- MAIN APPLICATION
addappid(2417820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2417820,0,"9db971750fee9f6b59b367a948ac509da525c254bd5bcb88daaf678a848edb82")

