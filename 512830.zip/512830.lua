-- Lua provided by RyzenAPI
-- Game: addappid(512830)

-- MAIN APPLICATION
addappid(512830)

-- MAIN APP DEPOTS / PACKAGES
addappid(512831, 1, "a86e821865abb3d4d9f8c7a7948cb274c02ea308348934abbea43406caf7308f")
