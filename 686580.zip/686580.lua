-- Lua provided by RyzenAPI
-- Game: Storms of Shambhala

-- MAIN APPLICATION
addappid(686580)

-- MAIN APP DEPOTS / PACKAGES
addappid(686581, 1, "44c65718c41da46d730c4001d8ee9eecc0176b5e0e951c09c25c232d2c8be202")
addappid(686582, 1, "242bcf6df2a8439373d344087e8d3b6892493fec4c9bb7fd774c4b315e17c9c4")
addappid(686583, 1, "27b13919e0787d9cbb3db706a81a95007a85feda39fd1540bd1157dee4ae554f")

