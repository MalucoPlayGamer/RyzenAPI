-- Lua provided by RyzenAPI 
-- Game: Skewer of Heroes: Bubble Survivors
addappid(3251240)
addappid(3251241, 1, "bdcb48a5b4eaf7d2b60876b29b7825f45bd9e5a2cc483ad55aaba3bf1d882422")
