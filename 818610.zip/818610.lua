-- 818610's Lua and Manifest Created by Hubcap Manifest
-- The Great Gaias
-- Created: July 03, 2026 at 12:37:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(818610, 1, "05d08161548764d9047e92f68b16284804fa72944e4c0bc54e80f8c81afa7b89") -- The Great Gaias
-- MAIN APP DEPOTS
addappid(818612, 1, "3b43f097e02578f82c7141030edd435094973fc90837f9bc9a848e5e285302a2") -- The Great Gaias Windows Depot
setManifestid(818612, "5098567852983773752", 1627183653)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- The Great Gaias - Lord of Sorcery (AppID: 3791150)
addappid(3791150)
addappid(3791150, 1, "bc1a9dc99fcb55f8895e3e153701207ed824fe4667e596cc874df22aded5635a") -- The Great Gaias - Lord of Sorcery - Depot 3791150
setManifestid(3791150, "3323862027926430873", 15)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(818613) -- Depot 818613 (empty depot)