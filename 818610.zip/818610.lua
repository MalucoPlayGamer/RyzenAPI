-- Lua provided by RyzenAPI
-- Game: The Great Gaias

-- MAIN APPLICATION
addappid(3791150)
-- addappid(818613) -- Depot 818613 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(818610, 1, "05d08161548764d9047e92f68b16284804fa72944e4c0bc54e80f8c81afa7b89") -- The Great Gaias
addappid(818612, 1, "3b43f097e02578f82c7141030edd435094973fc90837f9bc9a848e5e285302a2") -- The Great Gaias Windows Depot
addappid(3791150, 1, "bc1a9dc99fcb55f8895e3e153701207ed824fe4667e596cc874df22aded5635a") -- The Great Gaias - Lord of Sorcery - Depot 3791150

