-- Lua provided by RyzenAPI 
-- Game: The Fabled Woods Soundtrack
addappid(1573680)
addappid(1573681, 1, "0b8b86d5752216f2da8caeb90ed169c6afb17e39580ec7ae558781b2f3331aa3")
