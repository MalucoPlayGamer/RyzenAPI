-- Lua provided by RyzenAPI
-- Game: Tower!3D - ZBAD airport

-- MAIN APPLICATION
addappid(1562960)
-- Game: addappid(1562960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1562960,0,"99b221c0d48031e49f9ce06006194d7f0c7c4c1aacd370e724ff65633bcd4803")
