-- Lua provided by RyzenAPI
-- Game: Demon Grade VR

-- MAIN APPLICATION
addappid(574410)

-- MAIN APP DEPOTS / PACKAGES
addappid(574411, 1, "bed5d09a7183bd3c2142e10146159b2922adc326c288de90fe2b3fd07f9b5da2")

