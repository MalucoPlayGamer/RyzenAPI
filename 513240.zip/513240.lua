-- Lua provided by RyzenAPI
-- Game: Birdtual Reality

-- MAIN APPLICATION
addappid(513240)

-- MAIN APP DEPOTS / PACKAGES
addappid(513241,0,"fa5c820e00b4d545578af64e3bcfedc840cdab84c0e4035ad94768a3657dbcf9")

