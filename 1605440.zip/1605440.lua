-- Lua provided by SkyAPI 
-- Game: Ragdoll Madness
addappid(1605440)
addappid(1605441, 1, "b38bae86b954e958336570eec4eec3865733f18c5af56fb6a89c0032f7e42305")
