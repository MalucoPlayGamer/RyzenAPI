-- Lua provided by RyzenAPI
-- Game: Game: Ragdoll Madness

-- MAIN APPLICATION
addappid(1605440)
-- Game: addappid(1605440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1605441, 1, "b38bae86b954e958336570eec4eec3865733f18c5af56fb6a89c0032f7e42305")
