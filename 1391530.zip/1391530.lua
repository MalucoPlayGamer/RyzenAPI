-- Lua provided by RyzenAPI
-- Game: Game: Mud and Blood

-- MAIN APPLICATION
addappid(1391530)
-- Game: addappid(1391530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1391531, 1, "8ec8805c0e8598e536c76d8366797b988c8c6057635d9ac6883d7711628e43c5")
