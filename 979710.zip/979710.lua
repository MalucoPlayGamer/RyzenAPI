-- Lua provided by RyzenAPI
-- Game: Game: Easy Pose

-- MAIN APPLICATION
addappid(979710)
-- Game: addappid(979710)

-- MAIN APP DEPOTS / PACKAGES
addappid(979711, 1, "cea1ca8b0c0eec33d59f57eacff67372e5ef3a915499d15964e6a9f11d810733")
