-- Lua provided by RyzenAPI
-- Game: The Last Winter Knight

-- MAIN APPLICATION
addappid(2768420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2768429,0,"45392ad5c18fb1eefa059dbaae6f26f8f4adde9c5007a65cd5252de8b2026cdb")

