-- Lua provided by RyzenAPI
-- Game: Masterwork Fantasy Map Cartographer

-- MAIN APPLICATION
addappid(3448790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3448791, 1, "07b44d31218d7d8320590ff6c25d0caf19253f1bbdbd1801456dab367520f25b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
