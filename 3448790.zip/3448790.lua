-- Lua provided by RyzenAPI
-- Game: Masterwork Fantasy Map Cartographer

-- MAIN APPLICATION
addappid(3448790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3448791, 1, "07b44d31218d7d8320590ff6c25d0caf19253f1bbdbd1801456dab367520f25b")
