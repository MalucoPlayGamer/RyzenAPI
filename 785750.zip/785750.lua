-- Lua provided by RyzenAPI
-- Game: [東方二次] Senran Meisuishu Tactics / 戦乱命萃酒タクティクス

-- MAIN APPLICATION
addappid(785750)
-- Game: addappid(785750)

-- MAIN APP DEPOTS / PACKAGES
addappid(785751, 1, "6ff3447365bf3940ac3995a80d3c6b69d8d15ee94f411890a35c517718d8c74c")
