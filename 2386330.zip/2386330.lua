-- Lua provided by RyzenAPI
-- Game: addappid(2386330)

-- MAIN APPLICATION
addappid(2386330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2386331, 1, "8da55d754ea2011f66bbbe168b383ec1db933ecee077775401ba1c7563d74cad")
