-- Lua provided by RyzenAPI
-- Game: Video Horror Society

-- MAIN APPLICATION
addappid(611360)
addappid(1984660)
addappid(1984661)
addappid(1984662)
addappid(2175760)
addappid(2243460)
addappid(2359250)

-- MAIN APP DEPOTS / PACKAGES
addappid(611362,0,"203509d95412635bee538fb579343e30f5956a69bdeda1df96b6e4591a004e1c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
