-- Lua provided by RyzenAPI
-- Game: 611360

-- MAIN APPLICATION
addappid(228988)
addappid(228990)
addappid(611360)

-- MAIN APP DEPOTS / PACKAGES
addappid(611362,0,"203509d95412635bee538fb579343e30f5956a69bdeda1df96b6e4591a004e1c")

