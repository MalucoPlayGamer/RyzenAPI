-- Lua provided by RyzenAPI
-- Game: Video Horror Society

-- MAIN APPLICATION
addappid(611360)
addappid(1984660)
addappid(1984661)
addappid(1984662)
addappid(2175760)
addappid(2243460)
addappid(2359250)

-- MAIN APP DEPOTS / PACKAGES
addappid(611362,0,"203509d95412635bee538fb579343e30f5956a69bdeda1df96b6e4591a004e1c")

