-- Lua provided by SkyAPI 
-- Game: Chorus Demo
addappid(1791040)
addappid(1791041, 1, "0ea746500b263313c7ea0dd0622985bc6bae6412e2ab07984e9401d0fc34e44c")
