-- Lua provided by RyzenAPI
-- Game: Lhama Clicker Prologue

-- MAIN APPLICATION
addappid(2399310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2399311, 1, "b07ef37539ed41a92373210099806a993d152b5981bb4186ce16437c597cbadf")
