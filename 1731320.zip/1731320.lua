-- Lua provided by RyzenAPI
-- Game: Relentless Frontier Demo

-- MAIN APPLICATION
addappid(1731320)
-- Game: addappid(1731320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731321, 1, "7b4b7fdd86071f61624bf9d4488485a1dcbbadcb57242ff14756cb7421ead49b")
