-- Lua provided by RyzenAPI
-- Game: Catgirls From My Sweet Dream

-- MAIN APPLICATION
addappid(1949000)
-- Game: addappid(1949000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1949001, 1, "2999728e2d4162ce626f1cb0b1b2bc5b77f62ab81699016491a067754498d8a0")
addappid(2209920, 0, "f014beaffc0d04aa66a37e5f4d7978a4e4678c2ca8318562748caa985a71d56e")
addappid(2229770, 0, "33f4fa1a45ac20c64096163da93e105b7c2fe951d1e6cca8bc80bf22bd21196c")
