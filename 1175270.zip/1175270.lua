-- Lua provided by RyzenAPI
-- Game: addappid(1175270)

-- MAIN APPLICATION
addappid(1175270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175272,0,"cb91b42a16eb285bc1f7821cf11070f820f45a72ebc423a8fa388db76702006a")
