-- Lua provided by RyzenAPI
-- Game: 1094050

-- MAIN APPLICATION
addappid(1094050)
addappid(1125430)
-- Game: addappid(1094050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094051, 1, "6b6182d2393bbc3f7295d5da107edf23be2cee160016e6ce3d65de3bb908321b")
