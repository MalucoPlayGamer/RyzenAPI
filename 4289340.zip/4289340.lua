-- 4289340's Lua and Manifest Created by Hubcap Manifest
-- UNHUMAN
-- Created: August 12, 2026 at 06:14:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4289340, 1, "0472abfbc8ca74a7c99de82debcc6661dc7290016aecce34096c6ad472b8b93f") -- UNHUMAN
-- MAIN APP DEPOTS
addappid(4289341, 1, "9e6eb8ca02c660b15aa655752e65a31274d1a31b006e9d042770b2d76dc0497f") -- Depot 4289341
setManifestid(4289341, "6201075652196330474", 717224083)