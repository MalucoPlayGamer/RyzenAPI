-- Lua provided by RyzenAPI 
-- Game: AppID 2713730
addappid(2713730)
addappid(2713731, 1, "3b3b9196527a6a9e142f8879c4ed3a7c62890c7dba51716cb4a1bab87a477c89")
