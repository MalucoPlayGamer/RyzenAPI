-- Lua provided by RyzenAPI
-- Game: Game: DEATHWATCH

-- MAIN APPLICATION
addappid(2165030)
-- Game: addappid(2165030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2165031, 1, "7ed3e7084ead9141245cd2f4c1887dd8d1b97b439d975b9d35db926fcb1a48f0")
