-- 3240250's Lua and Manifest Created by Hubcap Manifest
-- Auto Blobber
-- Created: July 05, 2026 at 18:06:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3240250, 1, "f199f00492d70450fefeac8032ce598bcf3fac6e3cde0be5006aedabe64d28b9") -- Auto Blobber
-- MAIN APP DEPOTS
addappid(3240251, 1, "ff778f2bb6b4885e17fb388d6c0ef85caaa7f274be6d046b927d86c85b0d4fe6") -- Depot 3240251
setManifestid(3240251, "2371964247450040532", 292124583)