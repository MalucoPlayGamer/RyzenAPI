-- Lua provided by RyzenAPI
-- Game: Game: AppID 3151780

-- MAIN APPLICATION
addappid(3151780)
-- Game: addappid(3151780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3151781, 1, "f472a96f40a617fe0d6c837c448cd6c5430c91c967b6a2afeef1da7be1ac970c")
