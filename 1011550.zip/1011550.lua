-- Lua provided by RyzenAPI 
-- Game: Light The Way
addappid(1011550)
addappid(1011551, 1, "a1630779443f3daa92374fd68f885c007e49aa346eea0f9a9aed606972b179a7")
