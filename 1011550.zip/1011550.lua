-- Lua provided by RyzenAPI
-- Game: Light The Way

-- MAIN APPLICATION
addappid(1011550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1011551, 1, "a1630779443f3daa92374fd68f885c007e49aa346eea0f9a9aed606972b179a7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
