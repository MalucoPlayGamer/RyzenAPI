-- Lua provided by RyzenAPI
-- Game: AppID 275510

-- MAIN APPLICATION
addappid(275510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(275511, 1, "af48820ac14f05b81096b95899d691d7a62603ac6dad7268039d67792c3e3912")

