-- Lua provided by RyzenAPI
-- Game: Z Steel Soldiers

-- MAIN APPLICATION
addappid(275510)
-- Game: addappid(275510)

-- MAIN APP DEPOTS / PACKAGES
addappid(275511, 1, "af48820ac14f05b81096b95899d691d7a62603ac6dad7268039d67792c3e3912")
