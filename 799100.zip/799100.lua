-- Lua provided by RyzenAPI
-- Game: Stormworks: Build and Rescue Demo

-- MAIN APPLICATION
addappid(799100)

-- MAIN APP DEPOTS / PACKAGES
addappid(799101, 1, "98f6a6674c44764411670781527b9d55d38f39105ba277214f111ab61e04368b")

