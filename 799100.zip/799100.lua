-- Lua provided by RyzenAPI 
-- Game: AppID 799100
addappid(799100)
addappid(799101, 1, "98f6a6674c44764411670781527b9d55d38f39105ba277214f111ab61e04368b")
