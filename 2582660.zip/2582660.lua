-- Lua provided by RyzenAPI
-- Game: And the Hero Was Never Seen Again

-- MAIN APPLICATION
addappid(2582660)
-- Game: addappid(2582660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2582661, 1, "3f28164e45f91a8ea2f3439f1d6e08ac410703d44e07ca6bf50bbd9a034256b3")
addappid(2582662, 1, "b403db2ef212db42142cd36193892bae3dc6805caa610e2ec9bbfae9a8095da0")
addappid(2582663, 1, "d08e15cb8e658a4bc03adde77cfa7e11a0fe69cdb7c050e3c457fe5be3e6e69a")
