-- Lua provided by RyzenAPI
-- Game: Boom Box Blue!

-- MAIN APPLICATION
addappid(705240)

-- MAIN APP DEPOTS / PACKAGES
addappid(705241, 1, "61fb1bf1fd780f7b3fac3144d4834a792b681db39c30f3116da4d1b4d2c6a647")
