-- Lua provided by SkyAPI 
-- Game: Boom Box Blue!
addappid(705240)
addappid(705241, 1, "61fb1bf1fd780f7b3fac3144d4834a792b681db39c30f3116da4d1b4d2c6a647")
