-- Lua provided by RyzenAPI
-- Game: addappid(727480)

-- MAIN APPLICATION
addappid(727480)

-- MAIN APP DEPOTS / PACKAGES
addappid(727481, 1, "4bc58d05b380718c3cd6383429ce8355e87ba1571edb50be5c4a7225dfddd452")
