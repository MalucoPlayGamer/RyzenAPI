-- Lua provided by RyzenAPI
-- Game: Gem Wars: Attack of the Jiblets

-- MAIN APPLICATION
addappid(370590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(370591, 1, "c43433143e9f358a2e29d9ba68b67ad6b36c83ac23d899ad07de08ba87c98ad6")

