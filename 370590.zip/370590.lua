-- Lua provided by RyzenAPI
-- Game: Gem Wars: Attack of the Jiblets

-- MAIN APPLICATION
addappid(370590)

-- MAIN APP DEPOTS / PACKAGES
addappid(370591, 1, "c43433143e9f358a2e29d9ba68b67ad6b36c83ac23d899ad07de08ba87c98ad6")

