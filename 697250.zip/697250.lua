-- Lua provided by RyzenAPI
-- Game: Beyond Enemy Lines 2 Enhanced Edition

-- MAIN APPLICATION
addappid(697250)
addappid(1049990)

-- MAIN APP DEPOTS / PACKAGES
addappid(697251, 1, "8af93ad453d7efa8c223760e10974c9a9739a91f8f3f25d8f9685ce219196986")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1049980)
addappid(1082120)
addappid(1082150)
addappid(1082160)
addappid(1082161)
addappid(1082170)
addappid(1082171)
addappid(1082172)
