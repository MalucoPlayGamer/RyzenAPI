-- Lua provided by RyzenAPI
-- Game: Beyond Enemy Lines 2 Enhanced Edition

-- MAIN APPLICATION
addappid(697250)
addappid(1049990)
-- Game: addappid(697250)

-- MAIN APP DEPOTS / PACKAGES
addappid(697251, 1, "8af93ad453d7efa8c223760e10974c9a9739a91f8f3f25d8f9685ce219196986")
