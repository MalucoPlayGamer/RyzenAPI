-- Lua provided by RyzenAPI
-- Game: 491650

-- MAIN APPLICATION
addappid(491650)
-- Game: addappid(491650)

-- MAIN APP DEPOTS / PACKAGES
addappid(491651, 1, "3dbf8b9c62d2db04f0d7ea786e2cebe392087a2ff228ca16c6a85dd9809b4930")
