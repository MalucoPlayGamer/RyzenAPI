-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Trails of Cold Steel

-- MAIN APPLICATION
addappid(538680)
addappid(605270)
addappid(605280)
addappid(605320)
addappid(605321)
addappid(605322)
addappid(605323)
addappid(605324)
addappid(605325)
addappid(605326)
addappid(605327)
addappid(605328)
addappid(605330)
addappid(605331)
addappid(605332)
addappid(605333)
addappid(605334)
addappid(605335)
addappid(605350)
addappid(605351)
addappid(605352)
addappid(605353)
addappid(605354)
addappid(605360)
addappid(605361)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(538682,0,"56c145c4ef0c13fae87ed6fd963957233f34e4fd02f2156cecbf9660053b4988")
addappid(538683,0,"9b949fb015a0af07d1c6ab9dc9cb02eb237524510d9fce197e1ddd57d35c57a5")

