-- Lua provided by RyzenAPI
-- Game: The Legend of Heroes: Trails of Cold Steel

-- MAIN APPLICATION
addappid(538680)

-- MAIN APP DEPOTS / PACKAGES
addappid(538682,0,"56c145c4ef0c13fae87ed6fd963957233f34e4fd02f2156cecbf9660053b4988")
addappid(538683,0,"9b949fb015a0af07d1c6ab9dc9cb02eb237524510d9fce197e1ddd57d35c57a5")
