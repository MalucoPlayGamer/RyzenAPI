-- Lua provided by RyzenAPI
-- Game: Game: AppID 830590

-- MAIN APPLICATION
addappid(830590)
-- Game: addappid(830590)

-- MAIN APP DEPOTS / PACKAGES
addappid(830591, 1, "9fd4b954b50dcb823a77af2af7ac825fedd489df92f7a9bd1c36a821e8fc73e7")
addappid(830592, 1, "9cbe835ec5b2941163bf1a33a17fd8004c328493868f4fa01b7442c88860edda")
addappid(830593, 1, "12d4265f86b21be62d9f22946e159bb366b76447c9878c24648310ffdf7d5ec5")
