-- Lua provided by RyzenAPI
-- Game: AppID 1032510

-- MAIN APPLICATION
addappid(1032510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1032511, 1, "3cbcc5ab00ea2bfef4830e3db6e13369484f7d6b5caa7d13cf82a24b10254571")
