-- Lua provided by RyzenAPI
-- Game: Drunk or Dead

-- MAIN APPLICATION
addappid(577290)

-- MAIN APP DEPOTS / PACKAGES
addappid(577291, 1, "967c33e476e94a41a5b27a7aabedd1511dfd148513e492d9dd1b1d5d5a2494a1")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(705950)
addappid(776990)
