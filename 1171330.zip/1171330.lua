-- Lua provided by RyzenAPI
-- Game: Game: Reviser

-- MAIN APPLICATION
addappid(1171330)
-- Game: addappid(1171330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171331, 1, "7e95c4a85be9009b0b60c4279b2cc0f9787ae81ae19116aefa9e934cdd92098a")
