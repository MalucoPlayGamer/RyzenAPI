-- Lua provided by RyzenAPI 
-- Game: A Family of Love - Episode 1
addappid(2540680)
addappid(2540681, 1, "d8d930778cdf726739d1574e042d4da1b1892387aa9b290d73b6de389aaafaa1")
