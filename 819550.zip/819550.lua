-- Lua provided by RyzenAPI
-- Game: addappid(819550)

-- MAIN APPLICATION
addappid(819550)

-- MAIN APP DEPOTS / PACKAGES
addappid(819551, 1, "018e508be5dda46de8daca686562ed89019fcafa3a25e141f7fdec0e9a4a7a19")
