-- Lua provided by RyzenAPI
-- Game: Cherry Tree High Comedy Club

-- MAIN APPLICATION
addappid(214610)

-- MAIN APP DEPOTS / PACKAGES
addappid(214611, 1, "0e5b6b44b4556099602b19daac2fef30f5734bbfa2b6455703d405254d84653f")
