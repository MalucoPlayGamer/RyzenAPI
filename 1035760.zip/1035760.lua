-- Lua provided by RyzenAPI
-- Game: Glimmer in Mirror

-- MAIN APPLICATION
addappid(1035760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1035761, 1, "49f13494191a8c25893207584c85bd1cd79ef369d017c7c02591eb4e06cd9081")
