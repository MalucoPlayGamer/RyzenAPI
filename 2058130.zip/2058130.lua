-- Lua provided by RyzenAPI
-- Game: Fortitude invasion

-- MAIN APPLICATION
addappid(2058130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058131, 1, "3b256e3b2a019b3bec02fffb9d1f41c8adf4b973ccbd184cfec397eb8b20ab46")
