-- Lua provided by RyzenAPI
-- Game: Game: INVASION

-- MAIN APPLICATION
addappid(2262070)
-- Game: addappid(2262070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2262071, 1, "fb86c9e8ce4f75b4de647abe1b40cfeb54883f1702e02e207416caa8ff1bd979")
