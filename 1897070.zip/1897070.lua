-- Lua provided by RyzenAPI
-- Game: Game: Gone rogue Demo

-- MAIN APPLICATION
addappid(1897070)
-- Game: addappid(1897070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1897071, 1, "0627d931e98ff41623361093809fbcc4466c7fbec5d1d3fb9e57ce00f2e29a24")
