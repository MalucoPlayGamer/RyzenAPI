-- Lua provided by RyzenAPI
-- Game: Game: AppID 776920

-- MAIN APPLICATION
addappid(776920)
-- Game: addappid(776920)

-- MAIN APP DEPOTS / PACKAGES
addappid(776921, 1, "6715a06eda5b854f2e4238aecf6de02f493648b5e64686d074b085b32ad00641")
