-- Lua provided by RyzenAPI
-- Game: Game: Hazy Mind

-- MAIN APPLICATION
addappid(2380340)
-- Game: addappid(2380340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2380341, 1, "2daf1c8c66986ffa8eea8ff92e99827c5079e070ba669a9715b689c812cd8890")
