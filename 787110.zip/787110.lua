-- Lua provided by RyzenAPI
-- Game: 787110

-- MAIN APPLICATION
addappid(787110)
-- Game: addappid(787110)

-- MAIN APP DEPOTS / PACKAGES
addappid(787111, 1, "51671c60cd4cd5f0f23a4010c3cb21ec14ddde7062ae0f30846177397919b8c3")
