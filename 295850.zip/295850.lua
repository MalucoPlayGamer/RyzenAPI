-- Lua provided by RyzenAPI
-- Game: Game: Vlad the Impaler

-- MAIN APPLICATION
addappid(295850)
-- Game: addappid(295850)

-- MAIN APP DEPOTS / PACKAGES
addappid(295851, 1, "4d206c317ca730255501014720528ad01dc884bd83cdaf8a629055a5767029ce")
addappid(295852, 1, "85bc297c8684aee9559be5c764c6917c4bf92242b869aec1fe8287132e884814")
