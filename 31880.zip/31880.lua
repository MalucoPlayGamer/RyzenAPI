-- Lua provided by RyzenAPI
-- Game: Nancy Drew: Secret of the Old Clock

-- MAIN APPLICATION
addappid(31880)

-- MAIN APP DEPOTS / PACKAGES
addappid(31881, 1, "7afbb93534bed14c16e52d0f99b652c2a06efb58c8e82fe4977621ff22961417")
