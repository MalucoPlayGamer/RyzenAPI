-- Lua provided by RyzenAPI 
-- Game: AppID 31880
addappid(31880)
addappid(31881, 1, "7afbb93534bed14c16e52d0f99b652c2a06efb58c8e82fe4977621ff22961417")
