-- Lua provided by RyzenAPI
-- Game: AppID 844880

-- MAIN APPLICATION
addappid(844880)
-- Game: addappid(844880)

-- MAIN APP DEPOTS / PACKAGES
addappid(844881, 1, "e8a8ca5ef0276e9321292620e5d3417b2d13d5352d5ffa44b547cf229310f76d")
