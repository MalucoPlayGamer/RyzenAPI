-- Lua provided by RyzenAPI
-- Game: Game: Arc Wizards 2

-- MAIN APPLICATION
addappid(1414710)
-- Game: addappid(1414710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1414711, 1, "ce037fe36dec2c77b012153c089fc21a0401b2e59a638174fd1cd9d361a7f868")
