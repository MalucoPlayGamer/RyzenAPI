-- Lua provided by RyzenAPI
-- Game: 2444170

-- MAIN APPLICATION
addappid(2444170)
-- Game: addappid(2444170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2444171, 1, "e28b874d27af16f241333de28ccfd453b67f425a37a75e68fa5cd54c031e3afb")
