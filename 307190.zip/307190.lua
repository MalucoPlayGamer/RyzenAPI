-- Lua provided by RyzenAPI
-- Game: Nicole

-- MAIN APPLICATION
addappid(307190)
-- Game: addappid(307190)

-- MAIN APP DEPOTS / PACKAGES
addappid(307191, 1, "3d32a79a78be9dbaa14b1ef4b2d31b3543df912ef756506fb0bb22d34d87caf4")
addappid(309940, 0, "f57fbeb39a049cc2aa8331c2e45c120e99843cd7653590e351b5674be6e79522")
