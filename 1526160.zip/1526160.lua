-- Lua provided by RyzenAPI
-- Game: Four Kings: Video Poker

-- MAIN APPLICATION
addappid(1526160)
-- Game: addappid(1526160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526161, 1, "43087700dac9a035470f1b3722427275f9f8bbb4468669e6eda0a9ba0aa98cc2")
