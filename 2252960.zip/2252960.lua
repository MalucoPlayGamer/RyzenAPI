-- Lua provided by RyzenAPI
-- Game: Game: Flashback

-- MAIN APPLICATION
addappid(2252960)
-- Game: addappid(2252960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2252961, 1, "9a80857c30634eee480565bd1590cb0539f5a407b796381d112c85b18ff54a29")
