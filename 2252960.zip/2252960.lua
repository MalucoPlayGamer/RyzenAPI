-- Lua provided by RyzenAPI 
-- Game: Flashback
addappid(2252960)
addappid(2252961, 1, "9a80857c30634eee480565bd1590cb0539f5a407b796381d112c85b18ff54a29")
