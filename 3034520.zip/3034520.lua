-- Lua provided by RyzenAPI
-- Game: The Fox's Way Home

-- MAIN APPLICATION
addappid(3034520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3034521, 1, "8bbe671086e0d584a01d1a80f755ec8d75f06da6dc391580864874574746d32f")
