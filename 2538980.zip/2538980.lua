-- Lua provided by SkyAPI 
-- Game: AppID 2538980
addappid(2538980)
addappid(2538981, 1, "a19fae8d3d0ec2a8cf762317a555e547e61e7a21de9941fb924b5e2c2777475f")
