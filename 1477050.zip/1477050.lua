-- Lua provided by RyzenAPI
-- Game: addappid(1477050)

-- MAIN APPLICATION
addappid(1477050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1477052,0,"d1630599e89e5d09bcb0e1299f763ea4c1923f4477acdf76bc23d80c7037d40f")
