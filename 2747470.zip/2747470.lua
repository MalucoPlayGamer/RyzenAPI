-- Lua provided by RyzenAPI
-- Game: Swing Into Zero-G: Space Parkour Race

-- MAIN APPLICATION
addappid(2747470)
addappid(3076690)
addappid(3076700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2747471, 1, "c7076d0193a13d3787bce7c5700223d5ab90192f05fef2881002057a4e1e58e5")
addappid(2747472, 1, "746ef0296ba075b83412cddf8caf4821936d2738ca52121613834c43940c8d1c")

