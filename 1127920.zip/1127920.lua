-- Lua provided by RyzenAPI
-- Game: 1127920

-- MAIN APPLICATION
addappid(1127920)
-- Game: addappid(1127920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1127921, 1, "a0550ce9af120c7a366e8e097da732cc00c17ebbb6a6bd20f4e7cc5839de04f0")
addappid(1127922, 1, "11e4ac6ea5d008ef7b34d16d11d6dc80fa19d25705a9613469d415ba3f5e13b8")
