-- Lua provided by RyzenAPI
-- Game: Tcheco in the Castle of Lucio

-- MAIN APPLICATION
addappid(377600)

-- MAIN APP DEPOTS / PACKAGES
addappid(377601, 1, "46e62eb225f2487a53956a325a98ef162a268abb009851735a00b368c2abe05c")
addappid(377602, 1, "26017d78b9a065c190929375d031032a0f356931c397f0df25bb527167540aba")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
