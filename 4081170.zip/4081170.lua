-- 4081170's Lua and Manifest Created by Hubcap Manifest
-- Phone Flipper Simulator
-- Created: June 13, 2026 at 00:51:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4081170) -- Phone Flipper Simulator
-- MAIN APP DEPOTS
addappid(4081171, 1, "4f571281c4f333118532f78e95589dea4eba577ce4c34e5cba0035ee6c7c9b62") -- Depot 4081171
-- setManifestid(4081171, "8914247927885017477", 4605863087)