-- Lua provided by RyzenAPI
-- Game: addappid(1483210)

-- MAIN APPLICATION
addappid(1483210)
addappid(1483211)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483210,0,"9f2728c10d8ace7d581dc2b68bfe800f69ee8d53ac664bea4e35d9801e0be942")
