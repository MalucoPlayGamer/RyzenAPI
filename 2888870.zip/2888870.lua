-- Lua provided by SkyAPI 
-- Game: Dadish 3D
addappid(2888870)
addappid(2888871, 1, "37a521da6cbe7f5e6e42d1d642c6f4f1c5db6a8f55ec0b62b499dd35743a36a8")
