-- Lua provided by RyzenAPI
-- Game: addappid(1585590)

-- MAIN APPLICATION
addappid(1585590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1585591, 1, "df31aafc5c829b3a4d98f6185386b6a4dcbba85221df2bed486d725761e03f38")
