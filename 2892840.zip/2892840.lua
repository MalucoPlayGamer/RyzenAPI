-- Lua provided by RyzenAPI
-- Game: 2892840

-- MAIN APPLICATION
addappid(2892840)
-- Game: addappid(2892840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2892841, 1, "73e323cfdacf8b9a4cdc9f69e993d23db19bc43625e90efee6c25e44905606e1")
addappid(2980930, 0, "d7bf33e4c9807f82ae2b3a63c7a796b36e984863f9c6e2dad0d9fd75957ca404")
