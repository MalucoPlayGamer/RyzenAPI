-- Lua provided by RyzenAPI
-- Game: DR4X

-- MAIN APPLICATION
addappid(1704830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1704831, 1, "dc94b336e7063a10070cd519ec0933dbb2a97082d3899fabd5fafb22f632afa2")

