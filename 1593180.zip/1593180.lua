-- Lua provided by RyzenAPI
-- Game: 1593180

-- MAIN APPLICATION
addappid(1593180)
-- Game: addappid(1593180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593181, 1, "2cdf10052c86562db580b6c7cd829d0923638ccf589ebc36fb1f988ba92630eb")
