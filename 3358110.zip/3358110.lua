-- Lua provided by RyzenAPI
-- Game: WARRIORS: Abyss - 3,000 Karma Embers

-- MAIN APPLICATION
addappid(3358110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358110,0,"2f525b2ffbe129a613aa2a8d468d4aeed107e092c88d8ab33c53654d6794bb89")

