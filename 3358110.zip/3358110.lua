-- Lua provided by RyzenAPI
-- Game: 3358110

-- MAIN APPLICATION
addappid(3358110)
-- Game: addappid(3358110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3358110,0,"2f525b2ffbe129a613aa2a8d468d4aeed107e092c88d8ab33c53654d6794bb89")
