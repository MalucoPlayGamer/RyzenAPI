-- Lua provided by SkyAPI 
-- Game: Revolution Ace
addappid(274560)
addappid(274561, 1, "d4800eef472f1dc413c47afa47d05a1ad0391db30b1b1188bc0a7d9f797e660a")
