-- Lua provided by RyzenAPI
-- Game: addappid(274560)

-- MAIN APPLICATION
addappid(274560)

-- MAIN APP DEPOTS / PACKAGES
addappid(274561, 1, "d4800eef472f1dc413c47afa47d05a1ad0391db30b1b1188bc0a7d9f797e660a")
