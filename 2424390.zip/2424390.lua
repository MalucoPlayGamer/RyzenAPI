-- Lua provided by RyzenAPI
-- Game: MythForce Demo

-- MAIN APPLICATION
addappid(2424390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2424391, 1, "eadbca51736eff73a2d32e536ef37fa50063a8a1bad353e7ba268337e5628b96")

