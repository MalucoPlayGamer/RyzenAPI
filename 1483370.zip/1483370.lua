-- Lua provided by RyzenAPI
-- Game: addappid(1483370)

-- MAIN APPLICATION
addappid(1483370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1483371, 1, "d1ef3aef3226f5fa54875cdd981fddb402c1906a07b736d958cf078dd869bb50")
