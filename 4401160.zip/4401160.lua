-- Lua provided by RyzenAPI
-- Game: Fireboy & Watergirl and Friends

-- MAIN APPLICATION
addappid(4401160)

-- MAIN APP DEPOTS / PACKAGES
addappid(4401161, 1, "fc6292c5f1389e3b4e8e2fe7f504ea83d381695f57fb6ed6880fa96f4c15ba12")

