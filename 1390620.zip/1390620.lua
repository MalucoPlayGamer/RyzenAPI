-- Lua provided by RyzenAPI
-- Game: Drone Swarm - Deluxe Upgrade

-- MAIN APPLICATION
addappid(1390620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390621, 1, "4591fb784d2819c3d94c2c330dff846bda8da96cc15a62d295959fb70a813e43")

