-- Lua provided by RyzenAPI
-- Game: 20 Minute Metropolis - The Action City Builder

-- MAIN APPLICATION
addappid(700200)

-- MAIN APP DEPOTS / PACKAGES
addappid(700201, 1, "f58ef6b9d52017287652146e0a37398d6e090289d5a4ba8fa9ec9de753eb7874")

