-- Lua provided by RyzenAPI
-- Game: Sniper Game

-- MAIN APPLICATION
addappid(1789270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1789271, 1, "bef5c16d917c44eee04d2e0ac831e7cf1deb8d8853edd7032ae44fbfcbb47a55")

