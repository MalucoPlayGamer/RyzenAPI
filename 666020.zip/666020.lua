-- Lua provided by RyzenAPI
-- Game: Shark Dating Simulator XL+

-- MAIN APPLICATION
addappid(666020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(666021, 1, "9dbc556b220fa9f4411ac74ff8efe84f31fd085047fcc7754a2c6918d386d3c9")

