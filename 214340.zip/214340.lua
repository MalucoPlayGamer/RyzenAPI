-- Lua provided by RyzenAPI
-- Game: Deponia

-- MAIN APPLICATION
addappid(214340)
addappid(566450)

-- MAIN APP DEPOTS / PACKAGES
addappid(214341, 1, "c1e5680c3aabd510b1e926d2856e7de33eec5a662753bcff794a8bb91e10073c")
addappid(214342, 1, "20b341406d8aec8973a60789f3709a75466001137fb23e605d1f50cc5ca9b2c7")
addappid(214351, 1, "5f3c594c766f1e9384be92f510c9ae4110ef13ea933c76c542f1aaf893d78c0c")
addappid(214352, 1, "e0b2c2d46dc4642cb8dad61e3cbc5a16189e83f06c3ac1b900a8f2582c125af1")
addappid(214358, 1, "5ac131fd46217a2bd807d71d1f146e9b96cbba34442a2df5397d93a71f88aea5")
addappid(214359, 1, "cb13f37f8f5c96fc2ac34a7296165e2aa8e720e6853f1c94916248d502903141")
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)