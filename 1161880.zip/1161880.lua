-- Lua provided by RyzenAPI
-- Game: Vaporum: Lockdown

-- MAIN APPLICATION
addappid(1161880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1161881, 1, "80caf23e14cc7cad0f96285a66a52eaf74e6c4b7d7551d1afae9e7a5c49d2663")
addappid(1161883, 1, "d13a138c436f31f3ab3bb6dbf40ad3a39e32b3b1a6b075b114529229dcdfeba0")
addappid(1161884, 1, "6c1b455ff25126f5dd0cfdd45619218e62af3f019a293c93930adacc1626ae49")

