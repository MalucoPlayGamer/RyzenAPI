-- Lua provided by RyzenAPI
-- Game: AppID 460920

-- MAIN APPLICATION
addappid(460920)
addappid(556390)
addappid(556391)
addappid(556392)
addappid(562850)
addappid(564360)
addappid(564410)
addappid(564411)
addappid(564412)
addappid(564413)
addappid(564414)
addappid(564415)
addappid(564416)
addappid(623290)
addappid(623291)
addappid(686890)
addappid(729770)
addappid(729771)
addappid(730470)
addappid(732380)
addappid(732381)
addappid(744850)
addappid(744851)
addappid(951660)
addappid(951661)
addappid(951662)
addappid(951663)
addappid(951664)
addappid(951665)
addappid(951666)
addappid(951667)
addappid(951668)

-- MAIN APP DEPOTS / PACKAGES
addappid(460921, 1, "ad7a201700dc69ef545a3ff1a412d171e7b914226451c05bf95162f98f6de430")
addappid(1716751, 0, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
