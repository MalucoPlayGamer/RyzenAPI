-- Lua provided by RyzenAPI
-- Game: Stereo Aereo

-- MAIN APPLICATION
addappid(535890)
addappid(570440)

-- MAIN APP DEPOTS / PACKAGES
addappid(535891, 1, "e39a3115126b2d5f509942e52a5ef1c355035aeaf94309b5708027ed4dfc295e")

