-- Lua provided by RyzenAPI
-- Game: AppID 1594950

-- MAIN APPLICATION
addappid(1594950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594951, 1, "2b9fd1bd9b1d320ff4cc6e5d03c959605cc71e95270af082f412b93307486d7f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
