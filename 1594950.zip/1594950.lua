-- Lua provided by RyzenAPI
-- Game: addappid(1594950)

-- MAIN APPLICATION
addappid(1594950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1594951, 1, "2b9fd1bd9b1d320ff4cc6e5d03c959605cc71e95270af082f412b93307486d7f")
