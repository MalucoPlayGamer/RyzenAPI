-- Lua provided by RyzenAPI
-- Game: Doomsday Robot Girl

-- MAIN APPLICATION
addappid(1870310)
-- Game: addappid(1870310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1870311, 1, "a3d341658a9283c196433c193eaf54cb9f02505dd8c33bd4f6a966ae86d34cd2")
