-- Lua provided by SkyAPI 
-- Game: Triennale Game Collection 2
addappid(2061460)
addappid(2061461, 1, "5f718763f51dd33ec41c1c03c49039ba039e7f3ba21ecbebf7990e2b1c99f053")
addappid(2061462, 1, "2d6d3fcfcb00b434657262e2e657e031aaf45ec8b490da6c7ecfcffb63f84c27")
