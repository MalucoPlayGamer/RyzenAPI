-- Lua provided by RyzenAPI
-- Game: Citor3 Hallucinations VR Adult XXX Game

-- MAIN APPLICATION
addappid(1548600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1548601, 1, "1934b79a438e583a580f7acc8ccec16a1672ae51ed88590dd28d268ef845ffcb")
