-- Lua provided by RyzenAPI
-- Game: 286160

-- MAIN APPLICATION
addappid(286160)
-- Game: addappid(286160)

-- MAIN APP DEPOTS / PACKAGES
addappid(286161, 1, "44c1a2d71883ae73e086c3a9635ce91ce552c7f967b577cdfe7a371fbbe5a454")
addappid(286162, 1, "1a643eb767c6bf74e7a80ce613d74244d133e1c53607e20d44ce9ca75740776b")
addappid(286163, 1, "cc860200bf120e6acf8e7b8ae107bf5c80a427cb0ef48911a954af6ac9593e0a")
addappid(286164, 1, "384bd8817c99571c89493aff2c944cdabfa94c61e03b976afc07ca9d3aafa3c6")
