-- Lua provided by RyzenAPI
-- Game: Sin Slayers: Reign of The 8th Demo

-- MAIN APPLICATION
addappid(2861940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2861941, 1, "c6575d6a06fd37d3ca2b13b75fbdae8b48c6990e33b2ac280839ec69a7eda4cf")

