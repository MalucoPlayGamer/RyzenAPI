-- Lua provided by RyzenAPI
-- Game: Echoes of Yi : Samsara

-- MAIN APPLICATION
addappid(2776940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2776941, 1, "5405af9cbdda39dc278fb8dd7b2dca27fc7c9f441a61a3487c8ae40ea29199ad")

