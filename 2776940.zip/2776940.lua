-- Lua provided by SkyAPI 
-- Game: Echoes of Yi : Samsara
addappid(2776940)
addappid(2776941, 1, "5405af9cbdda39dc278fb8dd7b2dca27fc7c9f441a61a3487c8ae40ea29199ad")
