-- Lua provided by RyzenAPI
-- Game: METAL GEAR SURVIVE BETA

-- MAIN APPLICATION
addappid(797470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(797471, 1, "cf70288ee39e7eb4328debdd6b7d850099aeac78763da97ba2a84a34aad6092f")

