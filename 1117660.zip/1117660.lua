-- Lua provided by RyzenAPI
-- Game: 1117660

-- MAIN APPLICATION
addappid(1117660)
-- Game: addappid(1117660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1117661, 1, "bd1d9311849351a17ac8bd82c3379c71a5ec3ec5ae1041f0b08e78f5601317f1")
