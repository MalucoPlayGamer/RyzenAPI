-- 4823350's Lua and Manifest Created by Hubcap Manifest
-- Tridan
-- Created: August 24, 2026 at 13:21:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4823350) -- Tridan
-- MAIN APP DEPOTS
addappid(4823351, 1, "18ee3fbcb710f29af029ac93bc0fb5e5dbbc34c142b829058d6598686049c4f3") -- Depot 4823351
setManifestid(4823351, "4392014566130849410", 139918819)