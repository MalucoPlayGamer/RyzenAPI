-- Lua provided by RyzenAPI
-- Game: Tridan

-- MAIN APPLICATION
addappid(4823350) -- Tridan

-- MAIN APP DEPOTS / PACKAGES
addappid(4823351, 1, "18ee3fbcb710f29af029ac93bc0fb5e5dbbc34c142b829058d6598686049c4f3") -- Depot 4823351

