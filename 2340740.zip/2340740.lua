-- Lua provided by RyzenAPI
-- Game: 2340740

-- MAIN APPLICATION
addappid(2340740)
-- Game: addappid(2340740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340741, 1, "250fce82672dafe1fd1be5a40f5decb83f4b3e4e7dbf9b2873d18df69a1436fd")
