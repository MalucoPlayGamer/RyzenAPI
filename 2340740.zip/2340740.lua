-- Lua provided by RyzenAPI
-- Game: 明日战线 - 放置就能开宝箱（放置挂机探索卡牌策略）

-- MAIN APPLICATION
addappid(2340740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340741, 1, "250fce82672dafe1fd1be5a40f5decb83f4b3e4e7dbf9b2873d18df69a1436fd")

