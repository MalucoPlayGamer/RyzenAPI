-- Lua provided by RyzenAPI 
-- Game: AppID 2340740
addappid(2340740)
addappid(2340741, 1, "250fce82672dafe1fd1be5a40f5decb83f4b3e4e7dbf9b2873d18df69a1436fd")
