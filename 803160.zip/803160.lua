-- Lua provided by RyzenAPI
-- Game: Game: AppID 803160

-- MAIN APPLICATION
addappid(803160)
-- Game: addappid(803160)

-- MAIN APP DEPOTS / PACKAGES
addappid(803161, 1, "c88a9a8433c49cb3da676f73d7687077ae024b279462f5126830eb6687146fd2")
