-- Lua provided by RyzenAPI
-- Game: Game: AppID 1187520

-- MAIN APPLICATION
addappid(1187520)
-- Game: addappid(1187520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1187521, 1, "803867c852ca135bb6efdb9201a0e5f7c2a7a7409e50f632d4fcb08548395460")
