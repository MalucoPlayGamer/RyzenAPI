-- Lua provided by RyzenAPI
-- Game: addappid(315840)

-- MAIN APPLICATION
addappid(315840)

-- MAIN APP DEPOTS / PACKAGES
addappid(315841, 1, "877d5c3facb6806f22760b3238a883ad6b32db4a7abdfcdb06e4157f0f8172fc")
