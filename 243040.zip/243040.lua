-- Lua provided by RyzenAPI
-- Game: Startopia

-- MAIN APPLICATION
addappid(243040)

-- MAIN APP DEPOTS / PACKAGES
addappid(243041, 1, "3563a2e3354f81cf2284d6a2b7520aa90966f2da79ddff2b413ce7898128f728")
addappid(243042, 1, "6ea1a3ebfbf10ea62e79e683958895c0349fcd94cef912edbc663b359f1bc35b")
