-- Lua provided by RyzenAPI
-- Game: Charles the Bee

-- MAIN APPLICATION
addappid(2485090)

