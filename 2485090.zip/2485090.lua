-- Lua provided by RyzenAPI
-- Game: Charles the Bee

-- MAIN APPLICATION
addappid(2485090)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2702150)
