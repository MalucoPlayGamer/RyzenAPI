-- Lua provided by RyzenAPI
-- Game: Windmills

-- MAIN APPLICATION
addappid(1803760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803761, 1, "b03d8d9e408614f3461572df4c839cfcc09af5163510827a9fdd22f56fae107b")
