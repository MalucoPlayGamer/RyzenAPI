-- Lua provided by RyzenAPI
-- Game: 我的机器人女友

-- MAIN APPLICATION
addappid(4137460)
addappid(4158630)

-- MAIN APP DEPOTS / PACKAGES
addappid(4137461,0,"b65605494b1ea5aa23e1c0fb211124f88141ed1d702a6927d2dd65c583055f06")

