-- Lua provided by RyzenAPI
-- Game: 888690

-- MAIN APPLICATION
addappid(888690)
-- Game: addappid(888690)

-- MAIN APP DEPOTS / PACKAGES
addappid(888691, 1, "ac0a4b1c643cffadcb1745b1351d934d92a597ca77d3930a556023b1b699f817")
