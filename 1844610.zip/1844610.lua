-- Lua provided by RyzenAPI
-- Game: Reality Mixer - Mixed Reality for VR headsets

-- MAIN APPLICATION
addappid(1844610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844611, 1, "f8a82f8e958ca27a79edc0e1e1395a044b98b82639951902177389e8371173d3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
