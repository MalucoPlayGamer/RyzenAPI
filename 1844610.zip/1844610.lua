-- Lua provided by RyzenAPI 
-- Game: Reality Mixer - Mixed Reality for VR headsets
addappid(1844610)
addappid(1844611, 1, "f8a82f8e958ca27a79edc0e1e1395a044b98b82639951902177389e8371173d3")
