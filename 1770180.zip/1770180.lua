-- Lua provided by RyzenAPI
-- Game: Heroes of Agora

-- MAIN APPLICATION
addappid(1770180)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1770181, 1, "e5b8f0f7cf5e86fbc583ffdce84f7ece7ca943a0650dd8c5c911fc9e75dd9bab")

