-- Lua provided by RyzenAPI
-- Game: Heroes of Agora

-- MAIN APPLICATION
addappid(1770180)
-- Game: addappid(1770180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770181, 1, "e5b8f0f7cf5e86fbc583ffdce84f7ece7ca943a0650dd8c5c911fc9e75dd9bab")
