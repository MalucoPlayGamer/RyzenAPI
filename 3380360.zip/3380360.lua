-- Lua provided by RyzenAPI
-- Game: The Ghost Treasure

-- MAIN APPLICATION
addappid(3380360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3380361, 1, "a98ca8527bd493ce48efbec2369d9adeb8bfe0c101595ea227479c1a2ca840fc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
