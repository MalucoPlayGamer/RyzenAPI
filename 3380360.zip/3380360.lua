-- Lua provided by RyzenAPI
-- Game: 3380360

-- MAIN APPLICATION
addappid(3380360)
-- Game: addappid(3380360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3380361, 1, "a98ca8527bd493ce48efbec2369d9adeb8bfe0c101595ea227479c1a2ca840fc")
