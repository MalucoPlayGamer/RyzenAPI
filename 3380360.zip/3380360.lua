-- Lua provided by SkyAPI 
-- Game: The Ghost Treasure
addappid(3380360)
addappid(3380361, 1, "a98ca8527bd493ce48efbec2369d9adeb8bfe0c101595ea227479c1a2ca840fc")
