-- Lua provided by RyzenAPI
-- Game: Tiny Terry's Turbo Trip Soundtrack

-- MAIN APPLICATION
addappid(2927350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2927351, 1, "1b68a750e55ece288325985c41ea07793571ede8bc271b4ed8419dd5e6fbf313")
addappid(2927352, 1, "0a972da807fe98555c4821a318f29485f4165d8019d0a1e581a7d58393231c7d")

