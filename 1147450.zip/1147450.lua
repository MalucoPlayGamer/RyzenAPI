-- Lua provided by RyzenAPI
-- Game: Divine Miko Koyori

-- MAIN APPLICATION
addappid(1147450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147451, 1, "829bde79d93fbe80cdbc5cc971f83e804c446e26008d04c6cd05737e48e69fcb")
addappid(1147452, 1, "f3d063175be1c3e05a9d12ddcc88c38c0c65b87112f893a3e530c0c64e39cc69")
