-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1133140)
-- Game: addappid(1133140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133140,0,"776e5f3b894f05d0848e7f86cc0c323e586b5b64beeeb9d039334664f0df9893")
