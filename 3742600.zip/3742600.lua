-- Lua provided by RyzenAPI
-- Game: addappid(3742600)

-- MAIN APPLICATION
addappid(3742600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3742600,0,"35ece2a582e26accd4bd2553789230099afb8e56a30c00dcc892c52286e3c084")
