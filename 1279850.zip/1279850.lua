-- Lua provided by RyzenAPI
-- Game: Game: Peaky Blinders: Mastermind Soundtrack

-- MAIN APPLICATION
addappid(1279850)
-- Game: addappid(1279850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279851, 1, "20e148381345282fee5c32f4927ee07ece1a4b3833d870bc1e5b294f21de5da0")
