-- Lua provided by RyzenAPI
-- Game: Game: Xeno Runners

-- MAIN APPLICATION
addappid(2696850)
-- Game: addappid(2696850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696851, 1, "d8dab4c26ad8bd3ec928e1fcff6d511a238fd2773500d815ecde828c25802c0a")
