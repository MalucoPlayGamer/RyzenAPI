-- Lua provided by SkyAPI 
-- Game: AppID 384320
addappid(384320)
addappid(384321, 1, "364866ad3b14be6b3c33a2c36e4de68424652005d56cc103a9adb443b3a72f92")
