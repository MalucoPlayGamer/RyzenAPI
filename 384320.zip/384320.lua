-- Lua provided by RyzenAPI
-- Game: Game: AppID 384320

-- MAIN APPLICATION
addappid(384320)
-- Game: addappid(384320)

-- MAIN APP DEPOTS / PACKAGES
addappid(384321, 1, "364866ad3b14be6b3c33a2c36e4de68424652005d56cc103a9adb443b3a72f92")
