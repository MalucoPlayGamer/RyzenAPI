-- Lua provided by RyzenAPI
-- Game: addappid(2511570)

-- MAIN APPLICATION
addappid(2511570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2511571, 1, "c7c8f2f9e1c975e8dfb4848fe2885b49d4b1c5398b00d1a6f4602703b8930a6f")
