-- Lua provided by RyzenAPI
-- Game: No throwing

-- MAIN APPLICATION
addappid(3467620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3467621, 1, "2aa9e842b67acd1973c8ef4f1c8c32cacff0142a6a9a91c1ac2fb0aef2d19447")

