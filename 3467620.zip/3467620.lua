-- Lua provided by RyzenAPI
-- Game: 3467620

-- MAIN APPLICATION
addappid(3467620)
-- Game: addappid(3467620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3467621, 1, "2aa9e842b67acd1973c8ef4f1c8c32cacff0142a6a9a91c1ac2fb0aef2d19447")
