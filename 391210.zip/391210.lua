-- Lua provided by RyzenAPI
-- Game: Game: Arclight Cascade

-- MAIN APPLICATION
addappid(391210)
-- Game: addappid(391210)

-- MAIN APP DEPOTS / PACKAGES
addappid(391211, 1, "cf543160ae2e8192b99d5178f805898700e947bac1751a4952c722d9b2b92b1a")
addappid(391212, 1, "5cd4c56fdd24500487c2aa6180ae7e6bd9a2be48b383ed91f80e8cf24deb75ad")
