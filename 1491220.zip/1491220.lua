-- Lua provided by RyzenAPI
-- Game: Game: AppID 1491220

-- MAIN APPLICATION
addappid(1491220)
-- Game: addappid(1491220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1491221, 1, "22f185295710c33edc1401e71491cd7c15fea379a7d2a94a3babf9a5e577f386")
