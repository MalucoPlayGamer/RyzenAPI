-- Lua provided by RyzenAPI
-- Game: addappid(1374330)

-- MAIN APPLICATION
addappid(1374330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1374331, 1, "3c185d5e5993374e438d1e8e287b3ba7ca9f159d0adb8cbca4384f7e647a5f22")
