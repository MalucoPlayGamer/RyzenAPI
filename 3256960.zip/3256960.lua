-- 3256960's Lua and Manifest Created by Hubcap Manifest
-- SynthetiCell BioClicker
-- Created: June 21, 2026 at 11:44:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3256960, 1, "e1eecf5598a90d9ff3a5260e0edf3f05aa1ce52a2f5382c6312cd01c6d7c7f5c") -- SynthetiCell BioClicker
-- MAIN APP DEPOTS
addappid(3256961, 1, "069a0962dfc1522b25e6dd6191f136e9a35f0164bcdb241f145807ae5f23ec4f") -- Depot 3256961
-- setManifestid(3256961, "5655104901741470131", 3258178206)