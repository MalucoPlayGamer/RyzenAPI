-- Lua provided by SkyAPI 
-- Game: AppID 3012530
addappid(3012530)
addappid(3012531, 1, "fdd386bbf8aef36dffbab9488bd66b58df4d3a0389d67fd693ceaeb790810d50")
