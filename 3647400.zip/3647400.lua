-- Lua provided by RyzenAPI
-- Game: Femtazio

-- MAIN APPLICATION
addappid(3647400)
-- Game: addappid(3647400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3647401, 1, "43159e26fb02ce3d28bac9b7c67d5bc6da3f79d01754f4bf09816a20696283ae")
