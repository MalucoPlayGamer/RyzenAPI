-- Lua provided by RyzenAPI
-- Game: addappid(629310)

-- MAIN APPLICATION
addappid(629310)

-- MAIN APP DEPOTS / PACKAGES
addappid(629311, 1, "137f9fc8bbe06ce8548c4ab09eb35b9af7f36a03b6d42b58d00ca72d8afd838d")
