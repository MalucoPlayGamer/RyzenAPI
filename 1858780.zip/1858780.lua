-- Lua provided by RyzenAPI 
-- Game: Spooky Story
addappid(1858780)
addappid(1858781, 1, "e128ea4c2789b92aa5245cdcb1b62eb736f15a035c8513bc85b31de384eaac69")
