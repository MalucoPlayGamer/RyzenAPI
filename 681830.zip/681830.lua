-- Lua provided by RyzenAPI
-- Game: addappid(681830)

-- MAIN APPLICATION
addappid(681830)

-- MAIN APP DEPOTS / PACKAGES
addappid(681831, 1, "6fec93a9ec26498aa4786b1ae814144303b065803457e5f7e92575cf0daeb18d")
