-- Lua provided by RyzenAPI
-- Game: 2902970

-- MAIN APPLICATION
addappid(2902970)
-- Game: addappid(2902970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2902970,0,"afd37068ea44404dcc0a5a8f412a84338641cf43bc2b59dddd6249f127103281")
