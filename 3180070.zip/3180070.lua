-- Lua provided by RyzenAPI
-- Game: addappid(3180070)

-- MAIN APPLICATION
addappid(3180070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3180071, 1, "46e2cd1b157fec728146480948f03addd84b05ad244310eea46c81c3ebb47971")
