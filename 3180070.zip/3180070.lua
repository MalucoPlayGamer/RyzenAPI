-- Lua provided by RyzenAPI
-- Game: No, I'm not a Human

-- MAIN APPLICATION
addappid(3180070)
addappid(4521370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3180071, 1, "46e2cd1b157fec728146480948f03addd84b05ad244310eea46c81c3ebb47971")

