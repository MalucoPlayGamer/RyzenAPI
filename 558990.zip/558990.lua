-- Lua provided by RyzenAPI
-- Game: Opus Magnum

-- MAIN APPLICATION
addappid(558990)
addappid(3107410)

-- MAIN APP DEPOTS / PACKAGES
addappid(558991, 1, "09339350bc6714ad13bf66b687b56c9b5984f0a150a97a400e961897d9b26616")
addappid(558992, 1, "e146677097fcd064344b1717b5f75bdfa79708958eb313ebb069439734a8927b")
addappid(558993, 1, "ef26a3fbad64d8dbdf6413753c75892e1d9dc517a3cfa4f95485eb022633e136")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
