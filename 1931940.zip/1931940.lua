-- Lua provided by RyzenAPI
-- Game: Game: AppID 1931940

-- MAIN APPLICATION
addappid(1931940)
-- Game: addappid(1931940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931941, 1, "5de0d1aff90ed053bf408479f5e5ee0e4dc74b6d10aa97c7bb289b0d47c08648")
