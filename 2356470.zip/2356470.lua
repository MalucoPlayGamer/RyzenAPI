-- Lua provided by RyzenAPI
-- Game: Lost Chapter

-- MAIN APPLICATION
addappid(2356470)
addappid(2646640)
-- Game: addappid(2356470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2356471, 1, "59c36d8857255bb55a2b9511a949068fb700b404c0e53c2398fa9ff4fe047117")
addappid(2356472, 1, "e8dce446e51a6744e50a17fabe1de85de72ddab031526f8b58bd5586a44f9e05")
