-- Lua provided by RyzenAPI
-- Game: AppID 3253710

-- MAIN APPLICATION
addappid(3253710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3253711, 1, "36a69d30b091ada9f1a3f8ef0f6782b3b509519d86eb253bb6d1c1c93e3bd27f")
