-- Lua provided by RyzenAPI
-- Game: Game: Protecting the Base

-- MAIN APPLICATION
addappid(2593390)
-- Game: addappid(2593390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593391, 1, "b07d2f2a476c8d8fcdcf34214920f5da4abc2d0c1ab6a3f3b9edb075bb0deb3e")
