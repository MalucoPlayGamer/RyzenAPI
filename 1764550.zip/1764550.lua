-- Lua provided by RyzenAPI
-- Game: 100 Pumpkins

-- MAIN APPLICATION
addappid(1764550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1764551, 1, "3833259260b4f24c0947fc8f1d7c29606eda0c0b9d1a65d351cab31124da3b4a")

