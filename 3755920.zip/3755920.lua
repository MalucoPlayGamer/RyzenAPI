-- Lua provided by RyzenAPI
-- Game: Walking In

-- MAIN APPLICATION
addappid(3755920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3755921, 1, "0bd337ae602fac70fb9b5d851d541d56932316ab245befad7a4aaf5c25779fb7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
