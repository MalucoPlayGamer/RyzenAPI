-- Lua provided by RyzenAPI
-- Game: addappid(3755920)

-- MAIN APPLICATION
addappid(3755920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3755921, 1, "0bd337ae602fac70fb9b5d851d541d56932316ab245befad7a4aaf5c25779fb7")
