-- Lua provided by RyzenAPI
-- Game: Game: AppID 332780

-- MAIN APPLICATION
addappid(332780)
-- Game: addappid(332780)

-- MAIN APP DEPOTS / PACKAGES
addappid(332781, 1, "f3c2b9ec59f0823fb3c1234f2e4a46c74713ceb9f643a265fb4d2bb3ed000112")
