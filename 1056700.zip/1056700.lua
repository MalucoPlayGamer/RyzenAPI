-- Lua provided by RyzenAPI
-- Game: Hentai Story Purple

-- MAIN APPLICATION
addappid(1056700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056701, 1, "7b0ba94b428412182cbb6f3a982aa5604064cb932f9ba501d6e3aa9a3d96785b")
addappid(1077700, 0, "0787afd8d729043b9a07fb616221d79cafe8aec5d85e8216f47a7d3e398c5040")
addappid(1077710, 0, "bd7dcbfed1960b786a2be9eb1a482a35f95a4914c745fc0f1d4f7418296bd8bd")
