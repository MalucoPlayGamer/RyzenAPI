-- Lua provided by RyzenAPI
-- Game: Puzzle Dimension

-- MAIN APPLICATION
addappid(57200)

-- MAIN APP DEPOTS / PACKAGES
addappid(57201, 1, "c322f5b2690acaf20a333c270a0fe7d222441c1ec5b26706ec83888d32a4df5a")
addappid(57202, 1, "217ac4769b27265d2822769ccc398fcb38694c84540599ec2b7e3d3a0ab38060")
