-- Lua provided by RyzenAPI
-- Game: 1432148

-- MAIN APPLICATION
addappid(1432148)
-- Game: addappid(1432148)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432148,0,"314e36dace1342b1169587e4d8ac34ca41b3fa58f7c3d0a1a391a7d255ac9121")
