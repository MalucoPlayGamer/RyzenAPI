-- Lua provided by RyzenAPI
-- Game: Kings Of Streets

-- MAIN APPLICATION
addappid(1292700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1292701, 1, "237a2ca240465b6f79f9b9d5fb8580c8f741381001ff5f2bbaaf5ad5c35c8668")
