-- Lua provided by RyzenAPI
-- Game: Game: AppID 2928730

-- MAIN APPLICATION
addappid(2928730)
-- Game: addappid(2928730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2928731, 1, "16f983083f062313c2d04717228db34cec0f9d9d1ff3ec83a919f27797a72ea0")
