-- Lua provided by RyzenAPI
-- Game: Teenage Mutant Ninja Turtles: The Cowabunga Collection

-- MAIN APPLICATION
addappid(1659600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1659601, 1, "5023f9ba2117c0ff8e49a8f0db2c1cee99a49f811f9d4d7de07b833f45df831c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
