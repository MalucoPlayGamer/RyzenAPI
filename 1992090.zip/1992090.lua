-- Lua provided by RyzenAPI
-- Game: Legend of Mortal Demo

-- MAIN APPLICATION
addappid(1992090)
-- Game: addappid(1992090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1992091, 1, "5224228ac5a00f14c6ad09d1e3a4397c66b03e1c42d98decacc83e121915b669")
