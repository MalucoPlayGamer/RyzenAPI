-- Lua provided by RyzenAPI
-- Game: Umbra: The Last Summoner

-- MAIN APPLICATION
addappid(2710560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2710561, 1, "17fa3e65a25dd93cef4fb7c7ff54a48db4f57c0dfd7bc082610cb519a43e3589")

