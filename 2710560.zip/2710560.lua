-- Lua provided by RyzenAPI
-- Game: addappid(2710560)

-- MAIN APPLICATION
addappid(2710560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2710561, 1, "17fa3e65a25dd93cef4fb7c7ff54a48db4f57c0dfd7bc082610cb519a43e3589")
