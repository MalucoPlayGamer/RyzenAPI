-- Lua provided by RyzenAPI
-- Game: Midair

-- MAIN APPLICATION
addappid(439370)

-- MAIN APP DEPOTS / PACKAGES
addappid(439371, 1, "24212d8e941f457f8eee1b65958bcf5a2ba1f783b22518b12cac2dbf2df0475b")
