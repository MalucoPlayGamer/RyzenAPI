-- Lua provided by RyzenAPI
-- Game: Hexodius

-- MAIN APPLICATION
addappid(236490)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(236491, 1, "baf4f3a610d19c06f0488e0625dd8451a475c5a76c6f99541b131740b26bb784")

