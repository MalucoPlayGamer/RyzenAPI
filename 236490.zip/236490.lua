-- Lua provided by RyzenAPI
-- Game: Hexodius

-- MAIN APPLICATION
addappid(236490)

-- MAIN APP DEPOTS / PACKAGES
addappid(236491, 1, "baf4f3a610d19c06f0488e0625dd8451a475c5a76c6f99541b131740b26bb784")
