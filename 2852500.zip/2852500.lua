-- Lua provided by RyzenAPI
-- Game: DeepWeb Simulator

-- MAIN APPLICATION
addappid(2852500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2852501, 1, "87f9c880fad9d9d17b323a47f8a7dddf0cf1717a1e4a5dd3385a689ea3d26bad")
