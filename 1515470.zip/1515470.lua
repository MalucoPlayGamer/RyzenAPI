-- Lua provided by RyzenAPI
-- Game: 1515470

-- MAIN APPLICATION
addappid(1515470)
-- Game: addappid(1515470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1515471, 1, "dd8e8c71640125c375fee868f50653650f195000c7bfae8a2b4e1bac214297ff")
