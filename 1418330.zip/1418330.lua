-- Lua provided by RyzenAPI
-- Game: Sweet Halloween

-- MAIN APPLICATION
addappid(1418330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418331, 1, "e338f2310bd7925403973393e3eb233a68c76c5a113965fd605e582c0c0a6473")

