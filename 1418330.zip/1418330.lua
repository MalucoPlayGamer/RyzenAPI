-- Lua provided by SkyAPI 
-- Game: AppID 1418330
addappid(1418330)
addappid(1418331, 1, "e338f2310bd7925403973393e3eb233a68c76c5a113965fd605e582c0c0a6473")
