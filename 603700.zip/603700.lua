-- Lua provided by RyzenAPI
-- Game: addappid(603700)

-- MAIN APPLICATION
addappid(603700)

-- MAIN APP DEPOTS / PACKAGES
addappid(603701, 1, "c7e0183ab08d0a2102f923f11ceff0d467eb92e2f08b05b7658c408f427ac4e8")
addappid(603702, 1, "5a6204dedf367b19d806f4896c158b53d64a4c3c85d3d8597418681b7b4bf6d1")
addappid(603706, 1, "67ac459a755a96adeca57e8b56fbb971e6df13c3db63a16dbf7355fcdfda21c1")
