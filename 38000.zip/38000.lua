-- Lua provided by RyzenAPI
-- Game: Mahjong Quest

-- MAIN APPLICATION
addappid(38000)

-- MAIN APP DEPOTS / PACKAGES
addappid(38001, 1, "e827daa97a9fcd2f9e958120322aaa233523b911d90a77eb5222ba402d855b47")

