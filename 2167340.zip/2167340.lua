-- Lua provided by RyzenAPI
-- Game: addappid(2167340)

-- MAIN APPLICATION
addappid(2167340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167342,0,"ca92c6e49c370cb5649efdea7ae9ceda09ba383f9de8740377e09d039a1ede35")
