-- Lua provided by RyzenAPI
-- Game: Human Diaspora

-- MAIN APPLICATION
addappid(1395420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1395421, 1, "7be7899a210eb36a10b9ff5af3eb9fc380d8fafb6fd1413869bd4ec93a9d0bed")
addappid(1395422, 1, "6a5e34149ef8101a15f39f4ca37f840ba3236b7c46dacab5e60baae788577b4b")
