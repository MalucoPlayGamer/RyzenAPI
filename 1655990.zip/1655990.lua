-- Lua provided by RyzenAPI
-- Game: Mortal Rite

-- MAIN APPLICATION
addappid(1655990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1655991, 1, "dbea863090b8e8ddf511ba39ff065af6c90ab4dae136f0d334d4350e4d5a3aa2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
