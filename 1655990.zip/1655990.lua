-- Lua provided by RyzenAPI
-- Game: Mortal Rite

-- MAIN APPLICATION
addappid(1655990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1655991, 1, "dbea863090b8e8ddf511ba39ff065af6c90ab4dae136f0d334d4350e4d5a3aa2")
