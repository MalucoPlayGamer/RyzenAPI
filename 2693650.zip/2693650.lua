-- Lua provided by RyzenAPI 
-- Game: Kill Invaders
addappid(2693650)
addappid(2693651, 1, "d65ba4432758863aca195fe4ffde52e75d434763161325cd86ddd996ccbebec7")
