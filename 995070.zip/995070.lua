-- Lua provided by RyzenAPI
-- Game: Game: AppID 995070

-- MAIN APPLICATION
addappid(995070)
-- Game: addappid(995070)

-- MAIN APP DEPOTS / PACKAGES
addappid(995071, 1, "a615bf6918b96ed2006cc29d122ffbe8450448e5754dc1fbd44345579b51c871")
