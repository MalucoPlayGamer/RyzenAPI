-- Lua provided by RyzenAPI
-- Game: AppID 995070

-- MAIN APPLICATION
addappid(995070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(995071, 1, "a615bf6918b96ed2006cc29d122ffbe8450448e5754dc1fbd44345579b51c871")

