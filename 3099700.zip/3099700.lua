-- Lua provided by RyzenAPI
-- Game: World Crafter TD Demo

-- MAIN APPLICATION
addappid(3099700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3099701, 1, "22c26f83db3972c9c57d65497bc557ee17f53ae656871a6609dd6b7cefe0a3e4")
