-- Lua provided by RyzenAPI
-- Game: Brushwood Buddies

-- MAIN APPLICATION
addappid(434820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(434821, 1, "a51d4c0d7ac45be40aba765a41534e640b1a37d4207866863156858d93105c9c")
addappid(434822, 1, "70b1ce769307fb197b724a39f60d3d311dfdc0ef25de6940ea6e09b05fa1328f")
