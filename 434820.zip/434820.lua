-- Lua provided by SkyAPI 
-- Game: AppID 434820
addappid(434820)
addappid(434821, 1, "a51d4c0d7ac45be40aba765a41534e640b1a37d4207866863156858d93105c9c")
addappid(434822, 1, "70b1ce769307fb197b724a39f60d3d311dfdc0ef25de6940ea6e09b05fa1328f")
