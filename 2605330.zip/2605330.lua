-- Lua provided by RyzenAPI
-- Game: Game: HordeFighter 2D

-- MAIN APPLICATION
addappid(2605330)
-- Game: addappid(2605330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2605331, 1, "8b8ef787d9f22f6f1a44958e352bc871627c7bb3c74d877a1f9937959b53504b")
