-- Lua provided by RyzenAPI 
-- Game: HordeFighter 2D
addappid(2605330)
addappid(2605331, 1, "8b8ef787d9f22f6f1a44958e352bc871627c7bb3c74d877a1f9937959b53504b")
