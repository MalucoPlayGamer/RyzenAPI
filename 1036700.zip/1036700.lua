-- Lua provided by RyzenAPI
-- Game: My Beautiful Paper Smile

-- MAIN APPLICATION
addappid(1036700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1036701, 1, "0f5fd0188683a800ab0be558ee651a23ffec99b9ff704c8932b050fa281b94a3")
addappid(1036702, 1, "88d990eed0d62312378d03edb66e8ba522287347bfda7fcc68e7cc1b5e1a6b3e")

