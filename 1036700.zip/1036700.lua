-- Lua provided by RyzenAPI
-- Game: My Beautiful Paper Smile

-- MAIN APPLICATION
addappid(1036700)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1036701, 1, "0f5fd0188683a800ab0be558ee651a23ffec99b9ff704c8932b050fa281b94a3")
addappid(1036702, 1, "88d990eed0d62312378d03edb66e8ba522287347bfda7fcc68e7cc1b5e1a6b3e")

