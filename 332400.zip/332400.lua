-- Lua provided by RyzenAPI
-- Game: Girlfriend Rescue

-- MAIN APPLICATION
addappid(332400)

-- MAIN APP DEPOTS / PACKAGES
addappid(332401, 1, "539af1bbb06771a5b65e4b2163a43614543b3f630c5d3d18663497fb2faf61b2")
addappid(363040, 0, "e95fab81e08eba66c4e995f9f4e220148d987f2c286998d7d3cd60bd1f9b2809")
addappid(409180, 0, "fb26219217e3f4085e9f3ef583f2db184d6041e365e4e9e8e022eb44993d93c0")
addappid(468010, 0, "7b0ee9efbf0426d51417db6cc70b86b877823c1a863305e67ab3ec58d6404c6e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
