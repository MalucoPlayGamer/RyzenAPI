-- Lua provided by RyzenAPI
-- Game: addappid(3410340)

-- MAIN APPLICATION
addappid(3410340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3410341, 1, "468c34d7b6e5e631588c1b84cb7a5796d5b0e9c5295f468af990c1e1bc01f8f1")
