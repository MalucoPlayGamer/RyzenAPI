-- Lua provided by RyzenAPI
-- Game: Dao's Cover

-- MAIN APPLICATION
addappid(3410340)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3410341, 1, "468c34d7b6e5e631588c1b84cb7a5796d5b0e9c5295f468af990c1e1bc01f8f1")

