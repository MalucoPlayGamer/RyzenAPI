-- Lua provided by RyzenAPI
-- Game: Game: 彼岸之旅

-- MAIN APPLICATION
addappid(2810670)
-- Game: addappid(2810670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2810671, 1, "eeb95a079aa4e86b39cde324c94084215b9e2a88b09bb30e2d6b4134d4daa1e2")
