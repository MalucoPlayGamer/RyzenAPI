-- Lua provided by RyzenAPI 
-- Game: Zombies for Clip maker
addappid(1628080)
addappid(1628081, 1, "002d3110d4303184cb81ccc00f6abb6509b96d78f4289b31267fed243187cdce")
