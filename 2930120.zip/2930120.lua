-- Lua provided by RyzenAPI
-- Game: AppID 2930120

-- MAIN APPLICATION
addappid(2930120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2930121, 1, "700728292236a24b02ee1beb9a3d6e1d9688f7a7941471248bc46ca1bf1d9b99")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
