-- Lua provided by RyzenAPI
-- Game: addappid(2930120)

-- MAIN APPLICATION
addappid(2930120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2930121, 1, "700728292236a24b02ee1beb9a3d6e1d9688f7a7941471248bc46ca1bf1d9b99")
