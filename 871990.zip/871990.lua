-- Lua provided by RyzenAPI
-- Game: Game: AppID 871990

-- MAIN APPLICATION
addappid(871990)
-- Game: addappid(871990)

-- MAIN APP DEPOTS / PACKAGES
addappid(871991, 1, "49a75e1272cea815db4c000a18c835d0c0547ee1ff436742332f7cdadc54700f")
