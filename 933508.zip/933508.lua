-- Lua provided by RyzenAPI
-- Game: Special Mounts Pack 1

-- MAIN APPLICATION
addappid(933508)
-- Game: addappid(933508)

-- MAIN APP DEPOTS / PACKAGES
addappid(933508,0,"59a0da3079c1d99dc9e78b4259645843e938d45f9499307eedddd632817aac87")
addtoken(933508,1433903658582379655)
