-- Lua provided by RyzenAPI
-- Game: The New Flesh

-- MAIN APPLICATION
addappid(3692660)

