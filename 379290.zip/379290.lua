-- Lua provided by RyzenAPI
-- Game: 379290

-- MAIN APPLICATION
addappid(379290)
addappid(382190)
-- Game: addappid(379290)

-- MAIN APP DEPOTS / PACKAGES
addappid(379291, 1, "713fc54f035660ae27aef4a9f963f3cf457d4ae2115f6dcf3a288b7002b11c89")
