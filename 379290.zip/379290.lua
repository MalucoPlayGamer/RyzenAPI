-- Lua provided by RyzenAPI
-- Game: Sumo Revise

-- MAIN APPLICATION
addappid(379290)
addappid(382190)

-- MAIN APP DEPOTS / PACKAGES
addappid(379291, 1, "713fc54f035660ae27aef4a9f963f3cf457d4ae2115f6dcf3a288b7002b11c89")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
