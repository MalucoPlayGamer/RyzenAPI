-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2715320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2715320,0,"1cdfa640f718ce55ff2b75d6131b80452f695f4736b360f92c7a5f0c1c826116")

