-- Lua provided by RyzenAPI
-- Game: Game: AppID 2357050

-- MAIN APPLICATION
addappid(2357050)
-- Game: addappid(2357050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2357051, 1, "916b679b1ca931a18079d3185bca9d7cdcb3f84a2e19f336a11146179dd67015")
