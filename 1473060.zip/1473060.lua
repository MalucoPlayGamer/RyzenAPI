-- Lua provided by RyzenAPI
-- Game: Reality Break

-- MAIN APPLICATION
addappid(1473060)
addappid(4012290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473061, 1, "813b4f7543cf33a09418f93a9486d5a134acd5e5926b333f838cda068f746ec8")

