-- Lua provided by RyzenAPI
-- Game: Bro YuanShen Survivors

-- MAIN APPLICATION
addappid(2879130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2879132,0,"46998c145b3b6fe1df1f9d36e3277146870b5b049ce09b2b0c2c3f804a415099")

