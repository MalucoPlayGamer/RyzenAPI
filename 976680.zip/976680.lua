-- Lua provided by RyzenAPI
-- Game: Minimal Move

-- MAIN APPLICATION
addappid(976680)
-- Game: addappid(976680)

-- MAIN APP DEPOTS / PACKAGES
addappid(976681, 1, "5652ef05436b2a127fb45dc83ff5a698c0e0adefd3bb92b715feb3c63f91c637")
