-- Lua provided by RyzenAPI
-- Game: Minimal Move

-- MAIN APPLICATION
addappid(976680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(976681, 1, "5652ef05436b2a127fb45dc83ff5a698c0e0adefd3bb92b715feb3c63f91c637")

