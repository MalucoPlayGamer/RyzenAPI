-- Lua provided by RyzenAPI 
-- Game: Once Again Demo
addappid(2109760)
addappid(2109761, 1, "20742aef3aea1101096b06cd3d8b09b190e52a5351fde21b556cd7e3ba4ac78c")
