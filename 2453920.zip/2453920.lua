-- Lua provided by RyzenAPI
-- Game: addappid(2453920)

-- MAIN APPLICATION
addappid(2453920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2453922,0,"4bdc2af695fc38d16cb97c646d3f99593b8da7a5deae777f12b0ee0b9e1ed780")
