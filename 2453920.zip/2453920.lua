-- Lua provided by RyzenAPI
-- Game: Amygdala

-- MAIN APPLICATION
addappid(2453920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2453922,0,"4bdc2af695fc38d16cb97c646d3f99593b8da7a5deae777f12b0ee0b9e1ed780")

