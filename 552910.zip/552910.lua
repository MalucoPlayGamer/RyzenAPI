-- Lua provided by RyzenAPI
-- Game: addappid(552910)

-- MAIN APPLICATION
addappid(552910)
addappid(732791)

-- MAIN APP DEPOTS / PACKAGES
addappid(552911, 1, "3961fd3b19f366c627183099d6c78ee29ddc47c259027bc990e13b7a91a48191")
