-- Lua provided by RyzenAPI
-- Game: I'm from area 51

-- MAIN APPLICATION
addappid(1126550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1126552,0,"dbd2c68bf716e661681ebd62c67731095036684c18a30266527c36bb828294a4")
addappid(1126553,0,"1365c1db53f0a4fce51ca558684d1da34360e970f6f8dda69078e998c872f15d")

