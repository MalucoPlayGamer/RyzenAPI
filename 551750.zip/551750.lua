-- Lua provided by RyzenAPI
-- Game: Survival VR

-- MAIN APPLICATION
addappid(551750)

-- MAIN APP DEPOTS / PACKAGES
addappid(551751, 1, "6b9e7bc052cd59c62dbb1953aa4d45fed4dc237e5d9d799e44f6e837adfc1884")
