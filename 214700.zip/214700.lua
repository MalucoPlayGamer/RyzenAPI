-- Lua provided by RyzenAPI
-- Game: Game: AppID 214700

-- MAIN APPLICATION
addappid(214700)
-- Game: addappid(214700)

-- MAIN APP DEPOTS / PACKAGES
addappid(214701, 1, "7f614d936ee306f515c30cf0babcf3148bc35136ac78410d0d13f8242bea81c3")
addappid(214702, 1, "cb9fbf3fef90b41c77ec68865e47ab089a808e7f5a7b5b609e9433857a2e4cd2")
addappid(214703, 1, "e4e4547552de2c80efa826378ced5391dd03d34c8f4523f0d6774b42bd099bb2")
addappid(214706, 1, "6adf250aceddcc2147103aff56769908c1cc095e30cd88ffdb2d48f0c6a68c8e")
