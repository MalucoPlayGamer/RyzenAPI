-- Lua provided by RyzenAPI
-- Game: Game: リアルタイムバトル将棋オンライン

-- MAIN APPLICATION
addappid(1499540)
-- Game: addappid(1499540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499541, 1, "c709f36a672f01022f68b02157a1a894ba6b20a354a22e71b962b9b2fdb30127")
