-- Lua provided by RyzenAPI
-- Game: Sleengster

-- MAIN APPLICATION
addappid(559500)

-- MAIN APP DEPOTS / PACKAGES
addappid(559501, 1, "1438382e1da971f47903e755c3a435dbbc9b22b274d842e179cb0abfc9facefa")

