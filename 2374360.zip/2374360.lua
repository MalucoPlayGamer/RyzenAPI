-- Lua provided by RyzenAPI
-- Game: addappid(2374360)

-- MAIN APPLICATION
addappid(2374360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2374361, 1, "849ff4ffcb3f970b4bb0a9aa0cb2aea3d9f97737aa3ca576209517dcfcdc6717")
