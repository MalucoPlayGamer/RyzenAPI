-- Lua provided by RyzenAPI
-- Game: Amnesia Fortnight

-- MAIN APPLICATION
addappid(629160)

-- MAIN APP DEPOTS / PACKAGES
addappid(629161, 1, "e1c84e6ec50d883f604065a7b0fa5868e10d51daa5bb923a2fef8c516c4f65a8")

