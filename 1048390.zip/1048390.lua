-- Lua provided by RyzenAPI
-- Game: AppID 1048390

-- MAIN APPLICATION
addappid(1048390)
-- Game: addappid(1048390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048391, 1, "7b5272bdcaab90e22f5de7cde1ea478118edf260954216b00feb2a8ad5337bc6")
