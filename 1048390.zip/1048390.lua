-- Lua provided by SkyAPI 
-- Game: AppID 1048390
addappid(1048390)
addappid(1048391, 1, "7b5272bdcaab90e22f5de7cde1ea478118edf260954216b00feb2a8ad5337bc6")
