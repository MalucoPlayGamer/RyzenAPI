-- Lua provided by RyzenAPI
-- Game: Game: Neurodeck : Psychological Deckbuilder

-- MAIN APPLICATION
addappid(1253860)
addappid(1524740)
-- Game: addappid(1253860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1253861, 1, "a413f0623457407e6ba860cde72d57a4d5d513e80d42e967ed38685a4e80df93")
