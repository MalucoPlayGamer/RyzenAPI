-- Lua provided by RyzenAPI
-- Game: Game: AppID 2429520

-- MAIN APPLICATION
addappid(2429520)
-- Game: addappid(2429520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429521, 1, "1cd09265326c1477ffe22f287118df832c8a6535afc5e32d8346e0a1e66b0164")
