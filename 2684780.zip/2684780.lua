-- Lua provided by RyzenAPI
-- Game: Chromatic Isle

-- MAIN APPLICATION
addappid(2684780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2684781, 1, "fe64a07c5e270cccbfb3da9534232aabebcb89a898208d43d67b0133e95c7b65")
