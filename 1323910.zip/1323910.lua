-- Lua provided by RyzenAPI
-- Game: Game: Wall Ninja

-- MAIN APPLICATION
addappid(1323910)
-- Game: addappid(1323910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323911, 1, "7cbfbc74ba8ca655d54cea37f8df87bffa47ff4229336237ef7a2958b8797901")
