-- Lua provided by RyzenAPI
-- Game: Shattered Lights

-- MAIN APPLICATION
addappid(1057720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057721, 1, "7ddb32a0f30740b513a20e6d122802ddb44fb096d9a643ab565fb225f44bfb57")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
