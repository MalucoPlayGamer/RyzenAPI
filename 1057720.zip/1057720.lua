-- Lua provided by RyzenAPI
-- Game: addappid(1057720)

-- MAIN APPLICATION
addappid(1057720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1057721, 1, "7ddb32a0f30740b513a20e6d122802ddb44fb096d9a643ab565fb225f44bfb57")
