-- Lua provided by RyzenAPI
-- Game: Cats on Duty Demo

-- MAIN APPLICATION
addappid(2604440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2604441, 1, "5d0b86aa96eb49d7ba115a5564c76225e691b98fdf8d4a3db34c83770951ec18")
