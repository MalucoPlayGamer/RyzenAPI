-- Lua provided by RyzenAPI
-- Game: DFF NT: Lightning Starter Pack

-- MAIN APPLICATION
addappid(1022468)
-- Game: addappid(1022468)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022468,0,"eb206b3bcf585c9d9e0f818d360b180acce20c3c9881c6213c190143c0577152")
