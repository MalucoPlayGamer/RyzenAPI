-- Lua provided by RyzenAPI
-- Game: TimeMelters - Challenges

-- MAIN APPLICATION
addappid(2058240)
-- Game: addappid(2058240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2058241, 1, "7c6b06592fafb147a806aabf0871a76a62de8532e918bbc74583916391395209")
