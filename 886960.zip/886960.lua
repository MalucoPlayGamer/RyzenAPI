-- Lua provided by RyzenAPI 
-- Game: Dragon Spear
addappid(886960)
addappid(886961, 1, "c1f67b4b53d0bd23773bbd557e29f8eec01bffe4b1d12c38b6929c8f49c44147")
addappid(886962, 1, "d7ca2f90390e528aeba5062110e0eeaaa97c7a59b8293632fabd41a5224b30bf")
addappid(886963, 1, "1951b93cfd74d96912e3f9f855ee11f5d14b1f08e5f7ffb8f7879dec14e08ee6")
addappid(886965, 1, "ba7bce01da20748eeb0a14907bc0afc145ae89afca071fc31eb8f4f79b84e648")
addappid(886967, 1, "cc44412b4eb497338cffbac2099d587fad1f4763bfa2b7209353a9eec9c189ea")
