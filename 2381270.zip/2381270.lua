-- Lua provided by RyzenAPI
-- Game: Game: Stickman and the sword of legends

-- MAIN APPLICATION
addappid(2381270)
-- Game: addappid(2381270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2381271, 1, "e7749292912d5eefba775c9c019ae60259f528417b1432f1770b34a8add383dd")
addappid(2381272, 1, "3f8e3c3aad6bbe1455e2b30cd65d51549bc256c81f8ca55b47fa35c116815cd2")
