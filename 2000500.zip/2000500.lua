-- Lua provided by RyzenAPI 
-- Game: 勇者与亡灵之都 试玩版
addappid(2000500)
addappid(2000501, 1, "169745b9e91214421885f0481c562744779d1dabcb26bc69cebd50e2d1f3089f")
