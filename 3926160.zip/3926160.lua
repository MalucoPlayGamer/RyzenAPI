-- Lua provided by RyzenAPI
-- Game: Skewer Squad

-- MAIN APPLICATION
addappid(3926160)

-- MAIN APP DEPOTS / PACKAGES
addappid(3926161, 1, "ddb3b8429be1990a35e1d667b072073bfcc2da32d0a7068f497cf56509b65fee")

