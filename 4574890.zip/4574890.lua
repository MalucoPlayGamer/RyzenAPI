-- 4574890's Lua and Manifest Created by Hubcap Manifest
-- MEGAKO☆PUNCH!
-- Created: August 11, 2026 at 03:02:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4574890) -- MEGAKO☆PUNCH!
-- MAIN APP DEPOTS
addappid(4574891, 1, "db47b9961281d70f01aba5bfef15a34d7b9f517f6449734810d80449eaf1a98a") -- Depot 4574891
setManifestid(4574891, "5761209333076783772", 341105590)