-- Lua provided by RyzenAPI
-- Game: Ship Simulator: Maritime Search and Rescue

-- MAIN APPLICATION
addappid(274010)

-- MAIN APP DEPOTS / PACKAGES
addappid(274011, 1, "692c3a14a148e15e2203f57649e2e7ae754ee6059f9fb276c31ac8e170e4c0ce")
addappid(274012, 1, "c8d13762d1ef608f57fea6907533658fd6d15c51a1976a9606c2a8b2728e35a9")
