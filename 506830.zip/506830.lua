-- Lua provided by SkyAPI 
-- Game: Goo Saga
addappid(506830)
addappid(506831, 1, "859af8c102bd998b5065ac9722ad9618e99a1f64d7c0f46afcd3a12013dcf511")
