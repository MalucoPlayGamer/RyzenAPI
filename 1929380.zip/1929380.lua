-- Lua provided by RyzenAPI 
-- Game: Caverns of Evil
addappid(1929380)
addappid(1929381, 1, "264007ac7ac5debc6ebe084188a9bb4a55d2375205c085c7f5e5f8314f5f88a7")
