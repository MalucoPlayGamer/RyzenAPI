-- Lua provided by RyzenAPI
-- Game: addappid(1929380)

-- MAIN APPLICATION
addappid(1929380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1929381, 1, "264007ac7ac5debc6ebe084188a9bb4a55d2375205c085c7f5e5f8314f5f88a7")
