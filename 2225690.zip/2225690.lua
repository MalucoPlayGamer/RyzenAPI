-- Lua provided by RyzenAPI 
-- Game: HugeHead
addappid(2225690)
addappid(2225691, 1, "472a0cf26912d445cc18ce64a13c960b764465798e2be6fd2f25c49d620c6ea8")
