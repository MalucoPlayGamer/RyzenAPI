-- Lua provided by RyzenAPI
-- Game: HugeHead

-- MAIN APPLICATION
addappid(2225690)
-- Game: addappid(2225690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225691, 1, "472a0cf26912d445cc18ce64a13c960b764465798e2be6fd2f25c49d620c6ea8")
