-- Lua provided by RyzenAPI
-- Game: AppID 771810

-- MAIN APPLICATION
addappid(771810)
-- Game: addappid(771810)

-- MAIN APP DEPOTS / PACKAGES
addappid(771811, 1, "f8bc2e78c6743868b401247a1e948d6bbd76b9794c500f8f526c9b098aace241")
