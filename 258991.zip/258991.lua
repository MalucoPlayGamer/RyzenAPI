-- Lua provided by RyzenAPI
-- Game: X Rebirth Soundtrack Vol. 2

-- MAIN APPLICATION
addappid(258991)
-- Game: addappid(258991)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239961,0,"802ff3218e39e552b188f88679d1274910b15daa01dea9c3c83f1d5dc5ca3336")
addappid(1239962,0,"65344fb31126a4b2902e4e86f320c9bc991c81528cfb231391442f1a3f819c83")
