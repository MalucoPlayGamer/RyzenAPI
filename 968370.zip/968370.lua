-- Lua provided by RyzenAPI
-- Game: addappid(968370)

-- MAIN APPLICATION
addappid(968370)

-- MAIN APP DEPOTS / PACKAGES
addappid(968372,0,"aa6d4a59f9f860f56cf3fd8044219496c72b409c2469a70f73c48efca9c28c45")
