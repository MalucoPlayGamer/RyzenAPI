-- Lua provided by RyzenAPI
-- Game: LoveXLust

-- MAIN APPLICATION
addappid(2647060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2647062,0,"1eeff9296d2b048f8d60177445cab55c7f44d2f23d6490a7abfff7bb46500435")

