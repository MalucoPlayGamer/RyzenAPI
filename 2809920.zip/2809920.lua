-- Lua provided by RyzenAPI
-- Game: Drop Mahjong tiles

-- MAIN APPLICATION
addappid(2809920)
-- Game: addappid(2809920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2809921, 1, "9d045ceb035639193bb332b2481f76d8d39ad387b419d5a20c54fd31637e6416")
