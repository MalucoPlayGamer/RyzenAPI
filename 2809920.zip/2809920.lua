-- Lua provided by SkyAPI 
-- Game: Drop Mahjong tiles
addappid(2809920)
addappid(2809921, 1, "9d045ceb035639193bb332b2481f76d8d39ad387b419d5a20c54fd31637e6416")
