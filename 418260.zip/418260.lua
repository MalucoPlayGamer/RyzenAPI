-- Lua provided by SkyAPI 
-- Game: AppID 418260
addappid(418260)
addappid(418261, 1, "db85b43a95d9cf29490a463ff01c9e21d3857029eecaacc4579693f413a5a753")
