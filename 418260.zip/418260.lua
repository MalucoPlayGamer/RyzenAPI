-- Lua provided by RyzenAPI
-- Game: Gumball Drift

-- MAIN APPLICATION
addappid(418260)

-- MAIN APP DEPOTS / PACKAGES
addappid(418261, 1, "db85b43a95d9cf29490a463ff01c9e21d3857029eecaacc4579693f413a5a753")

