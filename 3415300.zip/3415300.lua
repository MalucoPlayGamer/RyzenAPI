-- Lua provided by RyzenAPI
-- Game: Supercat Survivors

-- MAIN APPLICATION
addappid(3415300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3415301, 1, "0383f6f81a76ef6e18abcf143a9b2db3f599cff081e549595a8939e5036089d1")

