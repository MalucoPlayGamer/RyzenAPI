-- Lua provided by RyzenAPI
-- Game: 1752310

-- MAIN APPLICATION
addappid(1752310)
-- Game: addappid(1752310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752310,0,"4aae2e539c3ddc7c507314294e4f9db054b7b11cd9dd6493b5edda2fa4272fc0")
