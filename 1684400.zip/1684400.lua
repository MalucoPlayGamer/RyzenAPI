-- Lua provided by RyzenAPI
-- Game: Best Month Ever!

-- MAIN APPLICATION
addappid(1684400)
-- Game: addappid(1684400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684401, 1, "0c2bbfc1eaeda683cbbbbb7681fc751c5f5c945ab59f98808145230c8c9c9f19")
