-- Lua provided by RyzenAPI 
-- Game: Shiro
addappid(1290710)
addappid(1290711, 1, "54979ed6c5a66f4c7e6a82a4d0903af13f320b74c4893719a8c8d0ceb6cb97d9")
