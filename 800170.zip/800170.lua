-- Lua provided by RyzenAPI
-- Game: 隐-Stealth

-- MAIN APPLICATION
addappid(800170)

-- MAIN APP DEPOTS / PACKAGES
addappid(800171,0,"77e8d396577682b54fea0b3dbfda6d9993a2e760fa606269130651d0f9b01068")

