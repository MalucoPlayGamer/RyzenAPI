-- Lua provided by RyzenAPI
-- Game: Game: Kaigrad

-- MAIN APPLICATION
addappid(1530760)
-- Game: addappid(1530760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1530761, 1, "90a3a486cf9f42e8748c8a845f75308f48750ef288f224bf1a1c71bc72128663")
