-- Lua provided by RyzenAPI
-- Game: Kaigrad

-- MAIN APPLICATION
addappid(1530760)
addappid(1623360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1530761, 1, "90a3a486cf9f42e8748c8a845f75308f48750ef288f224bf1a1c71bc72128663")

