-- Lua provided by RyzenAPI
-- Game: 430230

-- MAIN APPLICATION
addappid(430230)
-- Game: addappid(430230)

-- MAIN APP DEPOTS / PACKAGES
addappid(430231, 1, "245dccedb74201bbdbf6df2322e94e501627d18e26fc62ce182978774c19b3e6")
