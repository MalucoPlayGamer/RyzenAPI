-- Lua provided by RyzenAPI
-- Game: 682290

-- MAIN APPLICATION
addappid(682290)
-- Game: addappid(682290)

-- MAIN APP DEPOTS / PACKAGES
addappid(682291, 1, "a19efe2d231a15609917b3e0c08d42758dbbfe2bcecbf81cfc425da277364c81")
