-- Lua provided by RyzenAPI
-- Game: Game: AppID 1110910

-- MAIN APPLICATION
addappid(1110910)
-- Game: addappid(1110910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110911, 1, "c6a18b263aa9a616ceb8bd5abf647a4c2190ed55748548225a1a44cc4d4c117e")
