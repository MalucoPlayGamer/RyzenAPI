-- Lua provided by RyzenAPI
-- Game: AppID 1110910

-- MAIN APPLICATION
addappid(1110910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110911, 1, "c6a18b263aa9a616ceb8bd5abf647a4c2190ed55748548225a1a44cc4d4c117e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1672210)
