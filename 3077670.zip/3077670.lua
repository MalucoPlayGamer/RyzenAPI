-- Lua provided by RyzenAPI
-- Game: Water Delivery

-- MAIN APPLICATION
addappid(3077670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3077671, 1, "e379293fbc464426abd6c8832d37834dd6bcfca4b272f939b0d4a4c7a7c88099")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
