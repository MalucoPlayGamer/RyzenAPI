-- Lua provided by RyzenAPI
-- Game: Water Delivery

-- MAIN APPLICATION
addappid(3077670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3077671, 1, "e379293fbc464426abd6c8832d37834dd6bcfca4b272f939b0d4a4c7a7c88099")
