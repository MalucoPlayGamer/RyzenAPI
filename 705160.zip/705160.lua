-- Lua provided by RyzenAPI
-- Game: Game: Moon VR Video Player

-- MAIN APPLICATION
addappid(705160)
-- Game: addappid(705160)

-- MAIN APP DEPOTS / PACKAGES
addappid(705161, 1, "2d5ce30d1d6f479cf0a2ebff2c89adcc95858db04bf1cdcfd9719ea4de823ac6")
