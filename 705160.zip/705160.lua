-- Lua provided by RyzenAPI
-- Game: Moon VR Video Player

-- MAIN APPLICATION
addappid(705160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(705161, 1, "2d5ce30d1d6f479cf0a2ebff2c89adcc95858db04bf1cdcfd9719ea4de823ac6")

