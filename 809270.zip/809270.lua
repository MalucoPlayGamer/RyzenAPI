-- Lua provided by RyzenAPI
-- Game: addappid(809270)

-- MAIN APPLICATION
addappid(809270)
addappid(809271)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005,0,"aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a")
