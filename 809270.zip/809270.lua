-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(809270)
addappid(809271)
-- Game: addappid(809270)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005,0,"aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a")
