-- Lua provided by RyzenAPI
-- Game: Movavi Video Suite 2022 - Let's Start a Vlog Set

-- MAIN APPLICATION
addappid(1784536)

-- MAIN APP DEPOTS / PACKAGES
addappid(1784536,0,"308bea38a89abaca81cff534409459a48053a656d0b6d7365d2945164016b535")
