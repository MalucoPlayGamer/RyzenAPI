-- Lua provided by RyzenAPI
-- Game: 长梦 Demo

-- MAIN APPLICATION
addappid(2149720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2149721, 1, "961eb01a4eaa4bc23e4944ec3e4458e1df934d66e3801a96b7355dafad386664")

