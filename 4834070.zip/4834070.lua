-- Lua provided by RyzenAPI
-- Game: Don't Sleep With The Fishes

-- MAIN APPLICATION
addappid(4834070)

-- MAIN APP DEPOTS / PACKAGES
addappid(4834071, 1, "70cfd76fff28231b404a5dc01589ab84149810ae65712e51a0e263b12410fe25")
