-- Lua provided by RyzenAPI
-- Game: Gridworld

-- MAIN APPLICATION
addappid(396890)

-- MAIN APP DEPOTS / PACKAGES
addappid(396891, 1, "db807237d9d3800c70c44d48914ec4f30a28d16551ec59b90ae6447b9e6a6cc6")
addappid(396892, 1, "c3b4191894521fb76ee7cf82d0c64b60fa7cde69cfa331fedf5ef040ae248f10")
addappid(396894, 1, "f1df6960176358cdc8aea001ae50f5aa2054082da8517f3d8b7b649275bce6a1")

