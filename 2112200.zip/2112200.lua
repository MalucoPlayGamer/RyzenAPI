-- Lua provided by RyzenAPI
-- Game: addappid(2112200)

-- MAIN APPLICATION
addappid(2112200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2112201, 1, "6cab0f6b85aa1b7c01e84144509969002559afbd1ee4a7cf417f0ccafd7d148a")
