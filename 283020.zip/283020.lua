-- Lua provided by SkyAPI 
-- Game: The Campaign Series: Fall Weiss
addappid(283020)
addappid(283021, 1, "fdf3df4e6c674d9f6f382b959d81930291ef2f9595800783e71796b6510ba6ba")
addappid(283022, 1, "ac01ba755fa32758af2c5d1ae90c21ff68fca6a9b63dc96dc7b8b77dd9e7e1bc")
addappid(283023, 1, "3ef499260b788309239afa604abab854e44d45db6cad17fc6e52fa2d7e24249d")
