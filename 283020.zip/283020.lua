-- Lua provided by RyzenAPI
-- Game: The Campaign Series: Fall Weiss

-- MAIN APPLICATION
addappid(283020)

-- MAIN APP DEPOTS / PACKAGES
addappid(283021, 1, "fdf3df4e6c674d9f6f382b959d81930291ef2f9595800783e71796b6510ba6ba")
addappid(283022, 1, "ac01ba755fa32758af2c5d1ae90c21ff68fca6a9b63dc96dc7b8b77dd9e7e1bc")
addappid(283023, 1, "3ef499260b788309239afa604abab854e44d45db6cad17fc6e52fa2d7e24249d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
