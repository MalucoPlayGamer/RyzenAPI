-- Lua provided by RyzenAPI
-- Game: Game: TFC: The Fertile Crescent

-- MAIN APPLICATION
addappid(1674820)
-- Game: addappid(1674820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674821, 1, "bc5bb1336bed89caa879622a67ed838203029809307934d8f3ecd7e82888255a")
