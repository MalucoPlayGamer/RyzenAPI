-- Lua provided by RyzenAPI
-- Game: The Sandbox

-- MAIN APPLICATION
addappid(265810)
addappid(278120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(265811, 1, "7e9e7acb211e1c83e8a8a2febe72bfcdd34642b2077f18dd0efe155039ec128f")

