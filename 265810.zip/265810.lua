-- Lua provided by RyzenAPI
-- Game: The Sandbox

-- MAIN APPLICATION
addappid(265810)
addappid(278120)
-- Game: addappid(265810)

-- MAIN APP DEPOTS / PACKAGES
addappid(265811, 1, "7e9e7acb211e1c83e8a8a2febe72bfcdd34642b2077f18dd0efe155039ec128f")
