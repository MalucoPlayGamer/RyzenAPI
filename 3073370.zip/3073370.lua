-- Lua provided by RyzenAPI
-- Game: addappid(3073370)

-- MAIN APPLICATION
addappid(3073370)

-- MAIN APP DEPOTS / PACKAGES
addappid(3073371, 1, "f144b0b2031ae79fb5959f8c86d35dba74ae77d796a9cc2d0b588158dfde3bbb")
