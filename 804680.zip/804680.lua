-- Lua provided by RyzenAPI
-- Game: Game: AppID 804680

-- MAIN APPLICATION
addappid(804680)
-- Game: addappid(804680)

-- MAIN APP DEPOTS / PACKAGES
addappid(804681, 1, "0faed3dece7ac1c4ada5b6ce1e45747426759e68905d08e3f18465f789946cc9")
