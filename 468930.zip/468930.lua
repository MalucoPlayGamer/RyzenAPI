-- Lua provided by RyzenAPI 
-- Game: AppID 468930
addappid(468930)
addappid(468931, 1, "04997ab86b1d25658d31864241d7f2d294e7688378657cfb612f0331c516c73d")
addappid(468933, 1, "d09b4762f6c8e1d9150fd0bd00edfe0cd7901eb9dd8af3e7e98dce92c22bfa6e")
addappid(512930, 0, "0753ecb3ce4d9575b1de4c4cb43a525f70ba97637063cc1286a8bf8798dc48ae")
