-- Lua provided by RyzenAPI
-- Game: Game: Madness Cubed

-- MAIN APPLICATION
addappid(453270)
-- Game: addappid(453270)

-- MAIN APP DEPOTS / PACKAGES
addappid(453271, 1, "3a73bddb7c2f4b3aea48acbc1d3ca4a88e76febad1078b9c98a31c0104e20b53")
addappid(547630, 0, "8b3190705fbca4a7f74140f9ee7a9cba1a8a2279478f63e49aa54334c38dbb0d")
