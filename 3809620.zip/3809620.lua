-- Lua provided by RyzenAPI
-- Game: 100 Cats Lost in Thailand Find & Color

-- MAIN APPLICATION
addappid(3809620)

