-- Lua provided by RyzenAPI
-- Game: Cradle

-- MAIN APPLICATION
addappid(361550)
addappid(380710)

-- MAIN APP DEPOTS / PACKAGES
addappid(361551, 1, "d54ec6072f7a80a78b20f58af4941ec1b804ede33abc940164b6f36ce91b0765")
addappid(361552, 1, "bb74dc42f24f5c17444eb106282f688c7262a3186edeb12944a4cb54d4926bd3")
addappid(361553, 1, "a4008e248bf1be6e7aa0905ee8f1813e004b6b8715689fc55e05e13990492625")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
