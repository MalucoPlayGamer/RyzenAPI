-- Lua provided by RyzenAPI
-- Game: Game: Cradle

-- MAIN APPLICATION
addappid(361550)
addappid(380710)
-- Game: addappid(361550)

-- MAIN APP DEPOTS / PACKAGES
addappid(361551, 1, "d54ec6072f7a80a78b20f58af4941ec1b804ede33abc940164b6f36ce91b0765")
addappid(361552, 1, "bb74dc42f24f5c17444eb106282f688c7262a3186edeb12944a4cb54d4926bd3")
addappid(361553, 1, "a4008e248bf1be6e7aa0905ee8f1813e004b6b8715689fc55e05e13990492625")
