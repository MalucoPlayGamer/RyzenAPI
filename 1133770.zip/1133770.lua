-- Lua provided by RyzenAPI
-- Game: AppID 1133770

-- MAIN APPLICATION
addappid(1133770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1133771, 1, "6cba47120744e559fc1b3983d93f9eec8b4c4c82ada780518fafa66fb64e3ae6")
addappid(1201050, 0, "8f434389c8624fb91d9ece208ddc47596f4f6547f2e6ede50bf4f93bef15f113")
addappid(1214310, 0, "8bb0fc2c020ec8237a65aab01cc7778982eaabc25b2893a5b3769f2aa0465152")
addappid(1313800, 0, "9ea1661f9122dba5ace4092b3f9ad4ab853420a08b2fcb69ef34ae15bc700f21")

