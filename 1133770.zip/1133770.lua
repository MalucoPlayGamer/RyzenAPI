-- Lua provided by RyzenAPI
-- Game: Game: AppID 1133770

-- MAIN APPLICATION
addappid(1133770)
-- Game: addappid(1133770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133771, 1, "6cba47120744e559fc1b3983d93f9eec8b4c4c82ada780518fafa66fb64e3ae6")
addappid(1201050, 0, "8f434389c8624fb91d9ece208ddc47596f4f6547f2e6ede50bf4f93bef15f113")
addappid(1214310, 0, "8bb0fc2c020ec8237a65aab01cc7778982eaabc25b2893a5b3769f2aa0465152")
addappid(1313800, 0, "9ea1661f9122dba5ace4092b3f9ad4ab853420a08b2fcb69ef34ae15bc700f21")
