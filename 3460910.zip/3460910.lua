-- Lua provided by RyzenAPI
-- Game: Whale Flesh

-- MAIN APPLICATION
addappid(3460910)

-- MAIN APP DEPOTS / PACKAGES
addappid(3460911, 1, "8f98eb6652b6577517afee220d4ee84991483fc9c156e70655f3113a2e3c7575")
