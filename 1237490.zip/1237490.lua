-- Lua provided by RyzenAPI
-- Game: Redneck Ed: Astro Monsters Show

-- MAIN APPLICATION
addappid(1237490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1237491, 1, "a72fc0f985b291e1c4201c6288c412e7abb42d933f2849d93ef1294ce59026d5")

