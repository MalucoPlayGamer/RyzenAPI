-- Lua provided by RyzenAPI 
-- Game: AppID 1237490
addappid(1237490)
addappid(1237491, 1, "a72fc0f985b291e1c4201c6288c412e7abb42d933f2849d93ef1294ce59026d5")
