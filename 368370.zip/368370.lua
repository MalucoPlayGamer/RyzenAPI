-- Lua provided by RyzenAPI 
-- Game: Her Story
addappid(368370)
addappid(368371, 1, "66c71db2a6a8e03e728512c0d2706ef821d278d04ca6622f27e6f0ceebab36db")
addappid(368372, 1, "58bc4cefaafbaaa6571b19b2c6f58af23af92695ee92a8c98c0bb42230ce3dfc")
addappid(368373, 1, "2f32296d8c1b808573265016cbfc3e8c494e6471ddcdb1c078e4b87ed1f5615c")
addappid(368374, 1, "85cba7b86f659633e91bae6328a75e37041139fcc73ce87a1a1069c587970f9f")
