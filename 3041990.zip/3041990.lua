-- Lua provided by RyzenAPI
-- Game: addappid(3041990)

-- MAIN APPLICATION
addappid(3041990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3041991, 1, "ac9fb4a2f9e1caeb414f9fa4e5f3b5dc84f75a79c9f00a47055e20b6b7e1ef9b")
