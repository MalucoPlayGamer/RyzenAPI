-- Lua provided by RyzenAPI
-- Game: Magicka Demo

-- MAIN APPLICATION
addappid(73050)
-- Game: addappid(73050)

-- MAIN APP DEPOTS / PACKAGES
addappid(73051, 1, "899b687f189aa956c4f4c3e1a5fff6fe03781037acb0b5f871613b3a4794c0f1")
addappid(73052, 1, "30f5892aebd3ce7e5c6c3bb63e0f5de6fac1ee14ea50801aa0ef0cb4d9fc90a3")
addappid(73053, 1, "f7925c1e0b52758ecc787e3f00cc0613a3dbd1e3e4172fc9fbb2023cf90773c3")
