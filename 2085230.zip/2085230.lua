-- Lua provided by RyzenAPI
-- Game: 2085230

-- MAIN APPLICATION
addappid(2085230)
addappid(2085231)
addappid(2085232)
-- Game: addappid(2085230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085233,0,"b5da304bdf9a9cee1f8461f5f9c62676e7b40c021f4b42a7cb464994c20636ce")
