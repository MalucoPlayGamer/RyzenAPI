-- Lua provided by RyzenAPI
-- Game: addappid(1705220)

-- MAIN APPLICATION
addappid(1705220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1705221, 1, "7bc533a03a354bc01e54db10726448fd045b08bc4efa21a3d09eaf93341ae7ee")
