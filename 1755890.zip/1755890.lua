-- Lua provided by RyzenAPI
-- Game: Repit

-- MAIN APPLICATION
addappid(1755890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755891, 1, "917ac4919ce99f8c29c88b4327f91c94a8483680e1856bd0ae76a351035beeb9")
