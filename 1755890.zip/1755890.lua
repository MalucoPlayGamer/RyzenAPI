-- Lua provided by SkyAPI 
-- Game: Repit
addappid(1755890)
addappid(1755891, 1, "917ac4919ce99f8c29c88b4327f91c94a8483680e1856bd0ae76a351035beeb9")
