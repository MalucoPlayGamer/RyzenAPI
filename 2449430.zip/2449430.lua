-- Lua provided by RyzenAPI
-- Game: addappid(2449430)

-- MAIN APPLICATION
addappid(2449430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2449434,0,"67e471f177bf298e7bfe2e1cd2f8619192bf4a42195c85dcc8fc384aa8ae9ca7")
