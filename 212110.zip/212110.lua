-- Lua provided by RyzenAPI
-- Game: Sugar Cube: Bittersweet Factory

-- MAIN APPLICATION
addappid(212110)
-- Game: addappid(212110)

-- MAIN APP DEPOTS / PACKAGES
addappid(212111, 1, "f7fd7b55dab67062aa4e7fcaed223b2a9a17b512593d0373492944f9d955e272")
addappid(212112, 1, "e8f04c67eb9effcc2d602d32a06665ccb6dc254ff83e19d85912099f20e93c0e")
