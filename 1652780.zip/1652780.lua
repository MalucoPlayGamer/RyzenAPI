-- Lua provided by RyzenAPI
-- Game: Spectral Ascension

-- MAIN APPLICATION
addappid(1652780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1652781, 1, "b37f5a11fbfe2c3dbfe2f34e996b7e66af4443bb01916c91cfb08b3296402bcf")

