-- Lua provided by RyzenAPI
-- Game: 1652780

-- MAIN APPLICATION
addappid(1652780)
-- Game: addappid(1652780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1652781, 1, "b37f5a11fbfe2c3dbfe2f34e996b7e66af4443bb01916c91cfb08b3296402bcf")
