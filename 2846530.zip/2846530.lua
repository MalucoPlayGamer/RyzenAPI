-- Lua provided by RyzenAPI
-- Game: 2846530

-- MAIN APPLICATION
addappid(2846530)
-- Game: addappid(2846530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2846531, 1, "cb1c119f53135eaccde366c97613cbeb361b3139e30fe0143c8422a959abb388")
