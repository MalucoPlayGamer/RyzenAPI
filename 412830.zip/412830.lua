-- Lua provided by RyzenAPI
-- Game: AppID 412830

-- MAIN APPLICATION
addappid(412830)

-- MAIN APP DEPOTS / PACKAGES
addappid(412831, 1, "c6d8356cba3661b9f15d7360a123b3c097f2283000750595e5daef6912853b24")
addappid(412832, 1, "0b929be0342269fc3cc235eea9a5f655f1648531a2d3a262c6e46f217188f0ba")
addappid(412833, 1, "8cc48dcd8dbdd722765c602fa4c7f9306d1ad40f364db023bf7078d68dbea010")
addappid(412834, 1, "30e2baf354e33e9938750cfffb49d4ee8891bf4eb4ff74881fb7d1baab4e8281")
addappid(412835, 1, "10005b9d315c52464dde3f0c50ce68e2b704ab6b6b40a9aad2b6ba3ffa8f7c3d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
