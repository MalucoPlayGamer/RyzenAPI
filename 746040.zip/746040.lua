-- Lua provided by RyzenAPI
-- Game: INMATE: Survival

-- MAIN APPLICATION
addappid(746040)
-- Game: addappid(746040)

-- MAIN APP DEPOTS / PACKAGES
addappid(746042,0,"78a371d192562ec2d8503ced268c88653447e09c1103e039b1b292c2551da995")
