-- Lua provided by RyzenAPI
-- Game: GLASS- Kuromiya Kasumi 18+ Adult Only

-- MAIN APPLICATION
addappid(1770870)
-- Game: addappid(1770870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1770871, 1, "6bcfd3ab1eaea12f3a565dc6e689281d9a2198f376b508b645e58aa74b418bc1")
addappid(1770872, 1, "a50a750ad3a581747e0a78245f39a7853d9a6acf378081b91d40efb3ca7bb5e4")
