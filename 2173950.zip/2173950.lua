-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2173950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2173950,0,"505d233981b8db8bb1b8c834d1c437116202075ff0e9e0d3632165ef45c53c02")
