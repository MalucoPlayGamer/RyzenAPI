-- Lua provided by RyzenAPI
-- Game: GIRLDIVERS

-- MAIN APPLICATION
addappid(2892310)
-- Game: addappid(2892310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2892311, 1, "a7012073df3c23aa0bff820c99ca8f8092527f2bfad313cd09d7d3fc20d78066")
