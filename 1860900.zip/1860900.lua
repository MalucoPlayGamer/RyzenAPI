-- Lua provided by RyzenAPI
-- Game: Antivine

-- MAIN APPLICATION
addappid(1860900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1860901, 1, "6b79f30db9211aaad0a2f8ee21971b0b6d7aa57308a2c904e27ab53331a1a7ad")
