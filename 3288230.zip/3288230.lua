-- Lua provided by RyzenAPI
-- Game: addappid(3288230)

-- MAIN APPLICATION
addappid(3288230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3288230,0,"fab1f63b7c3b54f1b7c6d709f4b063a31bcf1341d4e715eea288cd55ff49eb74")
