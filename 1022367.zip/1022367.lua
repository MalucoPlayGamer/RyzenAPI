-- Lua provided by RyzenAPI
-- Game: DFF NT: Archduke of Jeuno I Appearance for Kam'lanaut

-- MAIN APPLICATION
addappid(1022367)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022367,0,"85f168028dc4a5ebc991fbc4b1f2b3485dccc996953bead37c6cc7752101e420")

