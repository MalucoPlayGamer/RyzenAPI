-- Lua provided by RyzenAPI
-- Game: SCP: Secret Files

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(1718130)
-- Game: addappid(1718130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718132,0,"20b7e1fba1d9d2276149ef9e61f90a2e9e729876c094bf8536c3f03b01819601")
