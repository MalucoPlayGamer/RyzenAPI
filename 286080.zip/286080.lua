-- Lua provided by RyzenAPI
-- Game: addappid(286080)

-- MAIN APPLICATION
addappid(286080)

-- MAIN APP DEPOTS / PACKAGES
addappid(286081, 1, "f9892cae01a61e76f0b62c7ad78996e1f06ab0657fcaad21ab3f96bbf6ab3c4f")
addappid(286082, 1, "658f0d3d4724616cf71af1721c80b2abe977e39b920916b0fd282f189711c46e")
addappid(286083, 1, "920f5c87fcd97ac95549c6f59bf07cf650817db79caa789d0f0c7fd3014391e7")
addappid(286084, 1, "26afb2fa388c4a6b1f15d064d08dc35d58aea242c68e4f6099db66c7b9bce214")
addappid(286085, 1, "f00890fd9a254b87eebded5c1aa0e3fe31933176ec779e6bc4e9052bf18b66ed")
