-- Lua provided by SkyAPI 
-- Game: Supernatural Rules Suppress Ghosts
addappid(2991290)
addappid(2991291, 1, "95959f1bd12312bdbdfee41e2596af2e69dd88cdbc966c81c1144e642ed04baa")
