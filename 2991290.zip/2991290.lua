-- Lua provided by RyzenAPI
-- Game: Supernatural Rules Suppress Ghosts

-- MAIN APPLICATION
addappid(2991290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2991291, 1, "95959f1bd12312bdbdfee41e2596af2e69dd88cdbc966c81c1144e642ed04baa")

