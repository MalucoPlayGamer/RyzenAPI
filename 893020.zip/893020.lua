-- Lua provided by RyzenAPI
-- Game: Slave's Sword 2

-- MAIN APPLICATION
addappid(893020)
-- Game: addappid(893020)

-- MAIN APP DEPOTS / PACKAGES
addappid(893021, 1, "ea0b628dba9cc59bf1f3b672e65967f9e4d6aa2a3a4380e6e06137bc307a4ac0")
addappid(893022, 1, "ebe462d8f7c9183f3755125deed5e81a4b14c59196b3b4c14c763a850169ef58")
addappid(893023, 1, "71efbe25fb970279513ee763638efa720aaac2fa87f272e831a7b9732fb3a441")
