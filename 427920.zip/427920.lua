-- Lua provided by SkyAPI 
-- Game: AppID 427920
addappid(427920)
addappid(427921, 1, "033a0c6ede2c69b0524dfec6cb16fbe8a158fe969445b13a12e6cff4f958cc1f")
