-- Lua provided by RyzenAPI
-- Game: 427920

-- MAIN APPLICATION
addappid(427920)
-- Game: addappid(427920)

-- MAIN APP DEPOTS / PACKAGES
addappid(427921, 1, "033a0c6ede2c69b0524dfec6cb16fbe8a158fe969445b13a12e6cff4f958cc1f")
