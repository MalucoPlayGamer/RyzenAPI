-- Lua provided by RyzenAPI
-- Game: Curvatron

-- MAIN APPLICATION
addappid(404700)
-- Game: addappid(404700)

-- MAIN APP DEPOTS / PACKAGES
addappid(404701, 1, "53dd6d3c7c3ed6b17ec52dc37013286b3ea9d5094884fe55b11ecaf529411024")
addappid(404702, 1, "c1873b8f7a4d3b0cbf0323929c93bff4f2b2b3f1d621537e3af1782b8cb5666c")
addappid(404703, 1, "6d32d0647c312b0f22302875f4a0e942abbf37c420c96bd5e43d430baf16157b")
addappid(404704, 1, "1ec2b942fc52e584689dfa3c1321df70d1bb792df6dc8f56576ad0fce766c811")
