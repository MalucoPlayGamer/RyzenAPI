-- Lua provided by RyzenAPI
-- Game: Hot Dogs, Horseshoes & Hand Grenades

-- MAIN APPLICATION
addappid(450540)

-- MAIN APP DEPOTS / PACKAGES
addappid(450541, 1, "d8909d31b2dab9e3a81423e760b9f59dd71f37ff1d2eb2c6efb3f1ea188b8038")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
