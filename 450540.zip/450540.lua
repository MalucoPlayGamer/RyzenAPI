-- Lua provided by RyzenAPI
-- Game: addappid(450540)

-- MAIN APPLICATION
addappid(450540)

-- MAIN APP DEPOTS / PACKAGES
addappid(450541, 1, "d8909d31b2dab9e3a81423e760b9f59dd71f37ff1d2eb2c6efb3f1ea188b8038")
