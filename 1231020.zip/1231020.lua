-- Lua provided by RyzenAPI
-- Game: Art of Beauties - Artbook 18+

-- MAIN APPLICATION
addappid(1231020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1231020,0,"ab3316f1db90f744b989f92f319ed65f5440a774539fdebb2559abe010f8179f")

