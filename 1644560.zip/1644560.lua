-- Lua provided by RyzenAPI
-- Game: setManifestid(1644562,"7765188406514572777")

-- MAIN APPLICATION
addappid(1644560)
-- Game: addappid(1644560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1644562,0,"686d7622ef2542ca14fb0ac2d07ce03e868c4d90bd44172d722c2176dbec42bb")
