-- Lua provided by RyzenAPI
-- Game: Hentai Senpai: Thicc Fairies of Forest Lake

-- MAIN APPLICATION
addappid(3068080)
addappid(4343300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3068081, 1, "56d623b5006778e464bc1960aea25a969d4daabb38a78c319404f7a449952499")

