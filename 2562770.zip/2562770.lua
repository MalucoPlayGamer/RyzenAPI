-- Lua provided by RyzenAPI
-- Game: 2562770

-- MAIN APPLICATION
addappid(2562770)
-- Game: addappid(2562770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2562770,0,"bb42dca18c2a98201d6aea5ab2bbd1d9374f894cabe1c3e49b8d378557a24378")
