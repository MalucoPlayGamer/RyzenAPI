-- Lua provided by RyzenAPI
-- Game: addappid(395900)

-- MAIN APPLICATION
addappid(395900)

-- MAIN APP DEPOTS / PACKAGES
addappid(395901, 1, "d54629b5623d9c6585cc1eff9ff12cc1657eee69e325423bb2fc77bdaf2fea8f")
addappid(395902, 1, "20a1ba29864d7d4a3b961a7e94271e20a8f543a4f03a6c08fea6ec14da79a8e8")
addappid(395903, 1, "6b21a50c12e548bcd410c006bdf5c3f51f1f1c47a6bdb9e889a0ba43e621556c")
