-- Lua provided by RyzenAPI
-- Game: Backgammon Blitz

-- MAIN APPLICATION
addappid(395900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(395901, 1, "d54629b5623d9c6585cc1eff9ff12cc1657eee69e325423bb2fc77bdaf2fea8f")
addappid(395902, 1, "20a1ba29864d7d4a3b961a7e94271e20a8f543a4f03a6c08fea6ec14da79a8e8")
addappid(395903, 1, "6b21a50c12e548bcd410c006bdf5c3f51f1f1c47a6bdb9e889a0ba43e621556c")

