-- Lua provided by RyzenAPI
-- Game: Horde Hunters

-- MAIN APPLICATION
addappid(2178560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2178561, 1, "d89c9170bab1e0683cd85c8f621b03934940bae470213640f8a2fdf11018fa63")

