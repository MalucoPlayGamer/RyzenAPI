-- Lua provided by RyzenAPI
-- Game: addappid(1214850)

-- MAIN APPLICATION
addappid(1214850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1214851, 1, "06bfc16b349d30801c00693251cd0ae8eda5e9b1fe0d7220f87653fd2d4d76d7")
