-- Lua provided by RyzenAPI
-- Game: Ni no Kuni™ II: Revenant Kingdom

-- MAIN APPLICATION
addappid(589360)

-- MAIN APP DEPOTS / PACKAGES
addappid(589361,0,"9402d58bea96df572890e2739abfdddef9706b87e79a208795d15596a74e4e3f")

