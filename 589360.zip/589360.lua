-- Lua provided by RyzenAPI
-- Game: Ni no Kuni™ II: Revenant Kingdom

-- MAIN APPLICATION
addappid(589360)

-- MAIN APP DEPOTS / PACKAGES
addappid(589361,0,"9402d58bea96df572890e2739abfdddef9706b87e79a208795d15596a74e4e3f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(689800)
addappid(689810)
addappid(689860)
addappid(804740)
addappid(804741)
addappid(804742)
addappid(804750)
addappid(898570)
