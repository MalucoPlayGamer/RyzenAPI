-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Fantasy Heroine Character Pack

-- MAIN APPLICATION
addappid(1499320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1499320,0,"68fbb42499428e477cf02217f01944cdc348d33bf445924234f1be872b39cb2d")

