-- Lua provided by RyzenAPI
-- Game: FPS Infinite

-- MAIN APPLICATION
addappid(1256380)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1256381, 1, "7b3d28bad9ce722f67541b6c938831e73c54db172e0097cce10e1ca2d2c04ddd")
addappid(1256382, 1, "5c8db1b141c779a634ab01730176ac1cf81048ada956c33e3ebea614ecab005a")
addappid(1256383, 1, "273eb928210abd52478e921a1afa8db15e013ba0b65504a26db9c154ed01b480")
