-- Lua provided by RyzenAPI
-- Game: 2968830

-- MAIN APPLICATION
addappid(2968830)
-- Game: addappid(2968830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2968831, 1, "596b0032be18ade7c823b841ae21eaf88e2663de0470064e49533516c46a6aa9")
