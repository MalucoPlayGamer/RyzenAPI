-- Lua provided by RyzenAPI
-- Game: 281080

-- MAIN APPLICATION
addappid(281080)
-- Game: addappid(281080)

-- MAIN APP DEPOTS / PACKAGES
addappid(281082,0,"05c03175dff66cf2ae009591a636f5667a74641be7c4d766f425ecc429f47769")
