-- Lua provided by RyzenAPI
-- Game: AppID 883330

-- MAIN APPLICATION
addappid(883330)
-- Game: addappid(883330)

-- MAIN APP DEPOTS / PACKAGES
addappid(883331, 1, "897590f352f0448b8bcbc99bd286ed50c31571d6d798dba5cd689c2c22cfa861")
