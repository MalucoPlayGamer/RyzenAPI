-- Lua provided by RyzenAPI
-- Game: Hypermind

-- MAIN APPLICATION
addappid(1889330)
-- Game: addappid(1889330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889331, 1, "c4f744e5fb31794b974b8164a4ee47dec9ed8333b6987ea6dd81855a7e91a0e1")
