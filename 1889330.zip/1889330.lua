-- Lua provided by RyzenAPI
-- Game: Hypermind

-- MAIN APPLICATION
addappid(1889330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1889331, 1, "c4f744e5fb31794b974b8164a4ee47dec9ed8333b6987ea6dd81855a7e91a0e1")

