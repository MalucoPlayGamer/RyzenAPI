-- Lua provided by RyzenAPI
-- Game: addappid(2096030)

-- MAIN APPLICATION
addappid(2096030)
addappid(3967810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2096031, 1, "4e2c22138fdf5e47bfe4d75e51360d167256c71f32aad159c9c841d483d3dc4c")
