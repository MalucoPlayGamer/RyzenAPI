-- Lua provided by RyzenAPI
-- Game: Snow Plowing Simulator

-- MAIN APPLICATION
addappid(2096030)
addappid(3967810)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2096031, 1, "4e2c22138fdf5e47bfe4d75e51360d167256c71f32aad159c9c841d483d3dc4c")

