-- Lua provided by RyzenAPI
-- Game: Project AURA

-- MAIN APPLICATION
addappid(305940)
addappid(788980)
addappid(788981)
addappid(788982)
addappid(788983)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(305941, 1, "1fb88de82ce83e8b59de0513baeaa65b05b2a757af2d84f8c3f7064699fe9ac0")
addappid(305942, 1, "fc172ca744fc01aee38bb15b1866352848d45bf74889660672a48f93932926ef")

