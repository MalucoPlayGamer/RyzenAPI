-- Lua provided by RyzenAPI
-- Game: DogFighter

-- MAIN APPLICATION
addappid(42500)
addappid(42520)
addappid(42521)
addappid(228984)
addappid(228990)
addappid(229032)

-- MAIN APP DEPOTS / PACKAGES
addappid(42501, 1, "067d3ed4d8b73ef420345b0b49f01c70470089dcbdde9b83f62da86fed4b8310")
