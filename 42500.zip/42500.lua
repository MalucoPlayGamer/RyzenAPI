-- Lua provided by RyzenAPI
-- Game: Game: AppID 42500

-- MAIN APPLICATION
addappid(42500)
addappid(228984)
addappid(228990)
addappid(229032)
-- Game: addappid(42500)

-- MAIN APP DEPOTS / PACKAGES
addappid(42501, 1, "067d3ed4d8b73ef420345b0b49f01c70470089dcbdde9b83f62da86fed4b8310")
