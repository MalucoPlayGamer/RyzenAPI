-- Lua provided by RyzenAPI
-- Game: Deep Space

-- MAIN APPLICATION
addappid(1453940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453941, 1, "b0cd930e3b49c4384ab47aced4e1d89894922454215a010de920753f87d7b615")
