-- Lua provided by RyzenAPI 
-- Game: UFO 50
addappid(1147860)
addappid(1147861, 1, "fc4b85d767f513b33d22062a73c72e11855638912726e6927cb6bbc79cc698f2")
