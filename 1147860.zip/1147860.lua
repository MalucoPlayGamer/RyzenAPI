-- Lua provided by RyzenAPI
-- Game: UFO 50

-- MAIN APPLICATION
addappid(1147860)
-- Game: addappid(1147860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147861, 1, "fc4b85d767f513b33d22062a73c72e11855638912726e6927cb6bbc79cc698f2")
