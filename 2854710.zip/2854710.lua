-- Lua provided by RyzenAPI
-- Game: Chocolate Factory

-- MAIN APPLICATION
addappid(2854710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2854711, 1, "84fce5e9642a918516c4ae043ab19514277dd62fb1caf9b41b24470fb54ec88f")

