-- Lua provided by RyzenAPI
-- Game: addappid(2854710)

-- MAIN APPLICATION
addappid(2854710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2854711, 1, "84fce5e9642a918516c4ae043ab19514277dd62fb1caf9b41b24470fb54ec88f")
