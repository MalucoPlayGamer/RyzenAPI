-- Lua provided by RyzenAPI
-- Game: AppID 937610

-- MAIN APPLICATION
addappid(937610)

-- MAIN APP DEPOTS / PACKAGES
addappid(937611, 1, "d5b769421f7f230bbb08598abbce58a9c3f5a1d6cf3deb087ca53f1b23b771b1")

