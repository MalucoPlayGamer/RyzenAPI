-- Lua provided by RyzenAPI
-- Game: Survive or Thrive

-- MAIN APPLICATION
addappid(1397030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1397031, 1, "9234823d1fd98e5c7e781063edb59363843d056aae56e38566651eb73a83017c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
