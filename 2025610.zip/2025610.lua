-- Lua provided by RyzenAPI
-- Game: addappid(2025610)

-- MAIN APPLICATION
addappid(2025610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2025611, 1, "13aca0f06fbc465201c3c255eb4323ba435b117feace359c10ec90fcc76cd090")
addappid(2025612, 1, "4e6d66f42f0decc1e380db89874eddbfe367cad3a89e3c2d3ca26bad6324d992")
