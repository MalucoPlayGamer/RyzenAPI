-- Lua provided by RyzenAPI
-- Game: pear potion🍐

-- MAIN APPLICATION
addappid(1405950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1405951, 1, "89cd62c25484c1f7b63b16f09a6581e5a99f848321040bc7d9cd859cc9bf9be6")

