-- Lua provided by RyzenAPI
-- Game: 495700

-- MAIN APPLICATION
addappid(495700)
-- Game: addappid(495700)

-- MAIN APP DEPOTS / PACKAGES
addappid(495701, 1, "dda119540608c39c727cfb48799cff4cacaf422f5357933b5f898b1ab938f13e")
