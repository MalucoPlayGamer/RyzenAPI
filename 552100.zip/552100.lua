-- Lua provided by RyzenAPI
-- Game: AppID 552100

-- MAIN APPLICATION
addappid(552100)
-- Game: addappid(552100)

-- MAIN APP DEPOTS / PACKAGES
addappid(552101, 1, "2655dc8f6778dc013bae87f3f20881b6b118c6beaca59114be62b0dd6a551679")
