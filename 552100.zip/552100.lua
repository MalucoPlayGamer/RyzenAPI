-- Lua provided by RyzenAPI
-- Game: AppID 552100

-- MAIN APPLICATION
addappid(552100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(552101, 1, "2655dc8f6778dc013bae87f3f20881b6b118c6beaca59114be62b0dd6a551679")

