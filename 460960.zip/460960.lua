-- Lua provided by RyzenAPI
-- Game: The Deed: Dynasty

-- MAIN APPLICATION
addappid(460960)

-- MAIN APP DEPOTS / PACKAGES
addappid(460961, 1, "4d9dd8c90c7fe750a19bfda5b96142314274cbcad3f5dfd832921192199582e5")
addappid(460962, 1, "ed974515857c7f61fe8854df4299715a3e83794e1d4ff7ef207e439f30669b0f")
