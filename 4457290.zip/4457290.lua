-- 4457290's Lua and Manifest Created by Hubcap Manifest
-- Noire Police Detective: Gangster Drama Simulator
-- Created: July 28, 2026 at 14:07:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4457290) -- Noire Police Detective: Gangster Drama Simulator
-- MAIN APP DEPOTS
addappid(4457291, 1, "754e0aba84e2511e8604d5432beb11b80f3243e0d3a27a0ac0a642c3394261cc") -- Depot 4457291
setManifestid(4457291, "6521668814481031261", 6035016164)