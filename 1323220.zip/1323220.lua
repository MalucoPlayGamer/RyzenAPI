-- Lua provided by RyzenAPI
-- Game: Hoops Madness

-- MAIN APPLICATION
addappid(1323220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323221, 1, "6912cdc328c2043be4ea6d7aec0cf5a49879d4371911129aa08fe94e0f53b69a")
