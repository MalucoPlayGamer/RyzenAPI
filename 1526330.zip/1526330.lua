-- Lua provided by RyzenAPI
-- Game: addappid(1526330)

-- MAIN APPLICATION
addappid(1526330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526331, 1, "e94c77c7b452efd223c45793a6531cc563fb790fc1ec045f1cef271ee33880d2")
addappid(1526332, 1, "f5e3f9438dce5fdfede824fb6650e7367ffc5d19364fbf8ba939884e1f3484c0")
