-- Lua provided by RyzenAPI
-- Game: 242820

-- MAIN APPLICATION
addappid(242820)
addappid(662290)
-- Game: addappid(242820)

-- MAIN APP DEPOTS / PACKAGES
addappid(242822,0,"1de3368a5eee089ea9bfcdead3f657e73b83c1d83705e4ff839d0cbf1b76a90b")
addappid(242823,0,"05f7221da577b7e9048ddad15af2960aadc3ef6e2a684594fa99c0ceaa0b8f23")
addappid(242824,0,"fdd0404414f05d7c8739a3939cf9a94b97dca3f60c25680853a843d6780af041")
