-- Lua provided by RyzenAPI
-- Game: Bard Idle

-- MAIN APPLICATION
addappid(1803580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803581, 1, "2132e6ea79d0b392a67659caf62abcae1a1a51121f7c7f7ade23d4b735081616")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2276160)
addappid(2276170)
addappid(2276710)
addappid(2276750)
addappid(2276790)
addappid(3075860)
addappid(3075870)
addappid(3075910)
addappid(3075920)
addappid(3075930)
addappid(3075940)
addappid(3075950)
addappid(3075960)
addappid(3075970)
addappid(3075980)
addappid(3075990)
addappid(3076000)
addappid(3076040)
addappid(3076050)
addappid(3076060)
addappid(3076070)
addappid(3076080)
addappid(3076090)
addappid(3867470)
addappid(3867480)
addappid(3867490)
