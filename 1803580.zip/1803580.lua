-- Lua provided by RyzenAPI
-- Game: Bard Idle

-- MAIN APPLICATION
addappid(1803580)
-- Game: addappid(1803580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803581, 1, "2132e6ea79d0b392a67659caf62abcae1a1a51121f7c7f7ade23d4b735081616")
