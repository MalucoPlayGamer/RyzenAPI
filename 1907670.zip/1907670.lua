-- Lua provided by RyzenAPI
-- Game: Game: GoBangTetris Demo

-- MAIN APPLICATION
addappid(1907670)
-- Game: addappid(1907670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1907671, 1, "68937fbc58238bf43edc3a2a296f5162dbc701c2b3c2992bc96caf7df4e8a3e9")
