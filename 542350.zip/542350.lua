-- Lua provided by RyzenAPI
-- Game: addappid(542350)

-- MAIN APPLICATION
addappid(542350)
addappid(566790)

-- MAIN APP DEPOTS / PACKAGES
addappid(542351, 1, "a4988706ee3b4a31675971dcfefb1dfb2afcaeef3042eba2e8480fc3ec0bd743")
