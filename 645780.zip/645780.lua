-- Lua provided by RyzenAPI
-- Game: AppID 645780

-- MAIN APPLICATION
addappid(645780)

-- MAIN APP DEPOTS / PACKAGES
addappid(645781, 1, "706355dc7e16012a1ca805810bd902e936310019791a57a4b960483db8f7653b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
