-- Lua provided by RyzenAPI
-- Game: Robot Pirates

-- MAIN APPLICATION
addappid(645780)
-- Game: addappid(645780)

-- MAIN APP DEPOTS / PACKAGES
addappid(645781, 1, "706355dc7e16012a1ca805810bd902e936310019791a57a4b960483db8f7653b")
