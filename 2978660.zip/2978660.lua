-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2978660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2978660,0,"2ffe02eea6c29440b5a63a8c79d3739d573c477edf7d381795da645ff0e5b9f5")

