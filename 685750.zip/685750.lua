-- Lua provided by RyzenAPI 
-- Game: AppID 685750
addappid(685750)
addappid(685751, 1, "80437d31c66fa3b0348ff17dd13d6ab03e89e79b1eae05f12e1f9d0e0bd3fb06")
