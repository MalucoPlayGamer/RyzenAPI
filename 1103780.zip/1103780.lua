-- Lua provided by RyzenAPI
-- Game: 1103780

-- MAIN APPLICATION
addappid(1103780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1103782,0,"610b6d8c7e91417af6006ecdcb3a38a2e5ade6aa40951c3db2f94e5d1ee27c4b")
addappid(1103783,0,"c16af6f95df9e3289f03ab64ce4fc7a508ead0cf5b1cd6576f3eaa0938028454")
