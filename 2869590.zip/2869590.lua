-- Lua provided by RyzenAPI
-- Game: Created: January 13, 2026 at 20:13:38 EST

-- MAIN APPLICATION
addappid(2869590) --  No Retreat! The Russian Front 

-- MAIN APP DEPOTS / PACKAGES
addappid(2869592, 1, "1fe65fe6a2cdc38556ddc8e096e892b81fdc9c8ac8a9feb4709a5da701bfe4e6") -- Depot 2869592

