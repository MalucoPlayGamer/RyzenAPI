-- Lua provided by RyzenAPI
-- Game: Starship Corporation

-- MAIN APPLICATION
addappid(292330)
addappid(926590)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(292331, 1, "258d61fe8342ed2ca38d0ec1e1c7e6d37b084a91ee4b43b837b84f9a1fc62d94")

