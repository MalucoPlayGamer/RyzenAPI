-- Lua provided by RyzenAPI
-- Game: 292330

-- MAIN APPLICATION
addappid(292330)
addappid(926590)
-- Game: addappid(292330)

-- MAIN APP DEPOTS / PACKAGES
addappid(292331, 1, "258d61fe8342ed2ca38d0ec1e1c7e6d37b084a91ee4b43b837b84f9a1fc62d94")
