-- Lua provided by SkyAPI 
-- Game: Starship Corporation
addappid(292330)
addappid(292331, 1, "258d61fe8342ed2ca38d0ec1e1c7e6d37b084a91ee4b43b837b84f9a1fc62d94")
addappid(926590)
