-- Lua provided by RyzenAPI
-- Game: 577460

-- MAIN APPLICATION
addappid(577460)
-- Game: addappid(577460)

-- MAIN APP DEPOTS / PACKAGES
addappid(577461, 1, "3fcf92824a4bc1a46b8c8a2d946ad908aa691b3882b0b6be7bc090d18ef3d2df")
