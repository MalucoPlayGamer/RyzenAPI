-- Lua provided by RyzenAPI
-- Game: Zoop! - Hunter's Grimm

-- MAIN APPLICATION
addappid(577460)

-- MAIN APP DEPOTS / PACKAGES
addappid(577461, 1, "3fcf92824a4bc1a46b8c8a2d946ad908aa691b3882b0b6be7bc090d18ef3d2df")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
