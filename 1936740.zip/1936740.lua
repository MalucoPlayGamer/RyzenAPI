-- Lua provided by RyzenAPI
-- Game: Timmy l'escargot

-- MAIN APPLICATION
addappid(1936740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1936741, 1, "37134a87d174a2a849716402522fcdc692da2ea3fa6182f4f35467821a47fbca")

