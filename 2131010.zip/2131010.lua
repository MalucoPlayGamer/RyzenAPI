-- Lua provided by RyzenAPI
-- Game: The Land Beneath Us

-- MAIN APPLICATION
addappid(2131010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2131011, 1, "f8f00ff2d1c236f035e4f473ac76ad51ee2273d4bed592798505848c790e0f64")

