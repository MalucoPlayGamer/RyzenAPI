-- Lua provided by RyzenAPI
-- Game: Shing! Demo

-- MAIN APPLICATION
addappid(1293290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1293291, 1, "eb47145bed726fad15f0c97511bcc4552bdbc284228e2204e029e2655664220d")
