-- Lua provided by RyzenAPI
-- Game: Game: Lost in Paradise

-- MAIN APPLICATION
addappid(381170)
-- Game: addappid(381170)

-- MAIN APP DEPOTS / PACKAGES
addappid(381171, 1, "0e76eea2bc0c3916b0ef7988c25ffcd01cffbc164f89b0cadfc609f013e9ab19")
addappid(381172, 1, "131875ef3996344e8f72e213e147bd314ddaf88576b4937adf0eb447e93c1ef5")
addappid(381173, 1, "8c946294791a0052ad5e18bf6764134da5269cff7a16b267092e86487bb4002c")
addappid(381174, 1, "2073a8d4914c7791675ac4cdf6437faee57f015b9fb8ada694c3b4dd3a5775b1")
