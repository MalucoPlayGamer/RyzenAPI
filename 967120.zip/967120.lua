-- Lua provided by RyzenAPI
-- Game: Cursed Mansion

-- MAIN APPLICATION
addappid(967120)
addappid(2696880)
addappid(2928260)
addappid(3294850)
addappid(4115820)
addappid(4189980)

-- MAIN APP DEPOTS / PACKAGES
addappid(967121,0,"e442e4554ff2b0cc8e462b62ad407e1437582ba9701b6dfec96a687992c4339b")
addappid(967122,0,"716554a4c38497fd7cddb6085fb6988dbdf7b86f58db96365998b0af7c20f33d")

