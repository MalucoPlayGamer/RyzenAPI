-- Lua provided by RyzenAPI
-- Game: Cursed Mansion

-- MAIN APPLICATION
addappid(967120)
addappid(2696880)
addappid(2928260)
addappid(3294850)
addappid(4115820)
addappid(4189980)

-- MAIN APP DEPOTS / PACKAGES
addappid(967121,0,"e442e4554ff2b0cc8e462b62ad407e1437582ba9701b6dfec96a687992c4339b")
addappid(967122,0,"716554a4c38497fd7cddb6085fb6988dbdf7b86f58db96365998b0af7c20f33d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
