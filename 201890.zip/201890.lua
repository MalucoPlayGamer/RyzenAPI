-- Lua provided by RyzenAPI
-- Game: 201890

-- MAIN APPLICATION
addappid(201890)
-- Game: addappid(201890)

-- MAIN APP DEPOTS / PACKAGES
addappid(201891, 1, "a788953ef6c6a4333c9294c42fb3e1bf7f0ecad72d5a5e385621fbe2ab2188d9")
