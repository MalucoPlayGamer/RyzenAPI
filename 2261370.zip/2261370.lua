-- Lua provided by RyzenAPI
-- Game: Game: Monstrous Love Demo

-- MAIN APPLICATION
addappid(2261370)
-- Game: addappid(2261370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2261371, 1, "5f38bbdfd8a0849f550dee58db273dcb630c114692048be7c3d2fa64c39f74ec")
