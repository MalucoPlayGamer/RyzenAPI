-- Lua provided by RyzenAPI
-- Game: Game: Crashlands

-- MAIN APPLICATION
addappid(391730)
-- Game: addappid(391730)

-- MAIN APP DEPOTS / PACKAGES
addappid(391731, 1, "31db48045139ccd5e4b431c76c2d9831552e9b3877879501bac6b0ea8130551a")
addappid(391732, 1, "42943e1707294ffbb6e5e87b3e3627a37d39edb7b10039a4781119eab9716f96")
addappid(391733, 1, "e52eb7bae24fd420c5fdd24263e55cf1029e74cc18a9fef19b8d62288c5a91a5")
