-- Lua provided by RyzenAPI
-- Game: Sons Of The Dream Forest

-- MAIN APPLICATION
addappid(2408920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(2408921, 1, "75744141562a3fb10eda0de8ea4cf7cb2b9f3fbdac79e2813824dc13e30f296f")

