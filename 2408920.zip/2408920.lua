-- Lua provided by RyzenAPI
-- Game: 2408920

-- MAIN APPLICATION
addappid(2408920)
-- Game: addappid(2408920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2408921, 1, "75744141562a3fb10eda0de8ea4cf7cb2b9f3fbdac79e2813824dc13e30f296f")
