-- Lua provided by SkyAPI 
-- Game: Blinky
addappid(1842130)
addappid(1842131, 1, "868506705056be7ead80d29a08c9968e63d2699ac5ae5923c02a2226363d2488")
