-- Lua provided by RyzenAPI
-- Game: Game: Blinky

-- MAIN APPLICATION
addappid(1842130)
-- Game: addappid(1842130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1842131, 1, "868506705056be7ead80d29a08c9968e63d2699ac5ae5923c02a2226363d2488")
