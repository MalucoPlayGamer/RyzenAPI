-- Lua provided by RyzenAPI
-- Game: Game: Lovely Brides

-- MAIN APPLICATION
addappid(2506430)
-- Game: addappid(2506430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506431, 1, "7cbb0ea63ec480cb37b3a51df4182ed2bd774992b35136d479102e32ce63497e")
