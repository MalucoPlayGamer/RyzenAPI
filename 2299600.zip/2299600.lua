-- Lua provided by RyzenAPI
-- Game: addappid(2299600)

-- MAIN APPLICATION
addappid(2299600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2299601, 1, "7b224c1ab8a42f2b04a5b730cebb65f46e26ceb1500809d9d122c919a637f6da")
