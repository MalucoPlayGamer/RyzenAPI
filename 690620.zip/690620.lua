-- Lua provided by RyzenAPI
-- Game: Downward Spiral: Horus Station

-- MAIN APPLICATION
addappid(690620)

-- MAIN APP DEPOTS / PACKAGES
addappid(690621,0,"822e2f2fc0294c85c6f0c3a5d0819bf382a9143ddd7457f602ddadff7ca7414a")

