-- Lua provided by RyzenAPI
-- Game: Fray Fight

-- MAIN APPLICATION
addappid(1910780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1910782,0,"90ba0286eaa211fa6a49b341e4b5d9f6e806e4ec2ce5af5d583efd5b4cc7892d")
