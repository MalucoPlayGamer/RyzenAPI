-- Lua provided by RyzenAPI
-- Game: Publisher Tycoon

-- MAIN APPLICATION
addappid(517300)

-- MAIN APP DEPOTS / PACKAGES
addappid(517301,0,"8819a4f5013b08f754c3b563e94f063b844568ca30f42174ad15fba456158c7d")

