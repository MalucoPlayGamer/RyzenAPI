-- Lua provided by SkyAPI 
-- Game: AppID 688630
addappid(688630)
addappid(688631, 1, "bb53856f7753c6de71f32382d61629f2f469569c2bfba0e67b01b69371b828e6")
