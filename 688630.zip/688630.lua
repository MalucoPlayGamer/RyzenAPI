-- Lua provided by RyzenAPI
-- Game: Game: AppID 688630

-- MAIN APPLICATION
addappid(688630)
-- Game: addappid(688630)

-- MAIN APP DEPOTS / PACKAGES
addappid(688631, 1, "bb53856f7753c6de71f32382d61629f2f469569c2bfba0e67b01b69371b828e6")
