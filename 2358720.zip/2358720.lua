-- Lua provided by RyzenAPI
-- Game: addappid(2358720)

-- MAIN APPLICATION
addappid(2358720)
addappid(2672610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2358721, 1, "78d5a284965b2206de191dc4ca99d43c9caf5b5e78b47cf0c366fbbb884190d8")
addappid(2672611, 1, "9f7513ce3953f71d2f994a9a331b862c8a41aeae89b0ff0933336aeef1796220")
