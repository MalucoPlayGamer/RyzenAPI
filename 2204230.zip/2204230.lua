-- Lua provided by RyzenAPI
-- Game: MineSweeper Tetris

-- MAIN APPLICATION
addappid(2204230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2204231, 1, "407695efc059b3bba5a45ca807a70a64fb8c2f764b339672d596229c6309af33")

