-- Lua provided by RyzenAPI
-- Game: Yar's Revenge

-- MAIN APPLICATION
addappid(99120)
-- Game: addappid(99120)

-- MAIN APP DEPOTS / PACKAGES
addappid(99121, 1, "0ca9fe917b466de96d68e8018abb49e06b1902360e1505a339970b1f3aa0a768")
addappid(99122, 1, "6bff861ea67c9d4e9f48a032d0eb5a55613ac6a885f933ba2449668d0ed8e036")
addappid(99123, 1, "ae7d87c65794dfcf79578f7032bab83505958f9efab5a07c401997e37745f622")
