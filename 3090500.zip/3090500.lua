-- Lua provided by RyzenAPI
-- Game: The Awakening of a Villainous Lady: A Crimson and Pure White Romance

-- MAIN APPLICATION
addappid(3090500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3090501, 1, "07af095a6263f0cf2b92f1989bd5cec306bbae71141c65be09e9b21a3f9a24e4")

