-- Lua provided by RyzenAPI
-- Game: Fancy Skiing: Speed

-- MAIN APPLICATION
addappid(1081910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1081911, 1, "ae0c52ec8489d2ef8b7ab3efa751dc96732d049f9a1fd26414ce324954486d74")
