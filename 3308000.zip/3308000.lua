-- Lua provided by RyzenAPI
-- Game: Game: AppID 3308000

-- MAIN APPLICATION
addappid(3308000)
-- Game: addappid(3308000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3308001, 1, "cd1de533d044ea57f5c7e1061f95c26d7704de9e357301b9b529c113f7cd69ab")
