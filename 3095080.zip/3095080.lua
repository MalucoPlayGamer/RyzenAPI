-- Lua provided by RyzenAPI 
-- Game: Together in Between: Chapter One
addappid(3095080)
addappid(3095081, 1, "84aaab5f0d1b3c89b518cf7c43f6db725161808e13c3178445b6eaf3fccc01d9")
