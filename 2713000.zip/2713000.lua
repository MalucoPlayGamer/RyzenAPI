-- Lua provided by RyzenAPI
-- Game: Game : Resonance: A Plague Tale Legacy

-- MAIN APPLICATION
addappid(2713000) -- Resonance: A Plague Tale Legacy
-- addappid(2713002) -- Depot 2713002 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(2713001, 1, "7085af990ca726e5a5e97ac1acd51bf4f32ba387d0f3d5edb114720e52b536b4") -- Depot 2713001
addtoken(2713000, "17223300556103744127")

