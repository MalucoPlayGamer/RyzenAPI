-- Lua provided by RyzenAPI
-- Game: AppID 243200

-- MAIN APPLICATION
addappid(243200)

-- MAIN APP DEPOTS / PACKAGES
addappid(243201, 1, "2f8788d52b36a2bac76de95d595eb93e5b2245e26161fc34fe0f8a647fcd4e87")
addappid(243202, 1, "150750d6fce93f68acbeb4b22d28bcee4695a7b4d46a834329cd3c1508a9b9b7")
addappid(243203, 1, "b8045133b598537f9135915124ba286ccd6bd534adf297996322b77bc964351d")
addappid(243204, 1, "6855001873f71a1e7e31da540f86bd2cb28cba2bc028adfa856681a9f0831476")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
