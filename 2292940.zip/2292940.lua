-- Lua provided by RyzenAPI
-- Game: Multiplayer Werewolves

-- MAIN APPLICATION
addappid(2292940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2292941, 1, "a71e76b5ce330c4efa86bff8726c37e3e4474701d1bf7e6cb9b4f79c67330cf6")
