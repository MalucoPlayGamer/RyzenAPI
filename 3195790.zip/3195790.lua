-- Lua provided by RyzenAPI
-- Game: White Knuckle

-- MAIN APPLICATION
addappid(3195790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3195791, 1, "5ca40880a5993420bafa2b8361350f6f806bc4ad220384095505b4b65a35209e")

