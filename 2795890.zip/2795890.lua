-- Lua provided by RyzenAPI
-- Game: AppID 2795890

-- MAIN APPLICATION
addappid(2795890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2795891, 1, "e5cdedb94cf9932a87b101163c03f8269b3607a6bbce74d72ad363cc7ce4e39a")

