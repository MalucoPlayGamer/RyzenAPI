-- Lua provided by RyzenAPI
-- Game: 494320

-- MAIN APPLICATION
addappid(494320)
-- Game: addappid(494320)

-- MAIN APP DEPOTS / PACKAGES
addappid(494321, 1, "ba055579987fc89e6dee71678d083fa47ac65a094671b12d267a79158be55e0f")
