-- Lua provided by RyzenAPI
-- Game: Valis: The Fantasm Soldier Collection Launcher

-- MAIN APPLICATION
addappid(3097550)
addappid(3097600)
addappid(3097610)
addappid(3097620)
addappid(3141640)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

