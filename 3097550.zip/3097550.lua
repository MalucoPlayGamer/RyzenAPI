-- Lua provided by RyzenAPI
-- Game: Valis: The Fantasm Soldier Collection Launcher

-- MAIN APPLICATION
addappid(3097550)
