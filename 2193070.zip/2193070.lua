-- Lua provided by RyzenAPI
-- Game: Returning To Mia

-- MAIN APPLICATION
addappid(2193070)
addappid(2958360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2193071, 1, "b55b5af0c4b9ebfbf468ae0ccce3d7d74b8e7f16295ff9231ac269abaacac9f8")
