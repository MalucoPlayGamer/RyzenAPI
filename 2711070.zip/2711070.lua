-- Lua provided by RyzenAPI
-- Game: addappid(2711070)

-- MAIN APPLICATION
addappid(2711070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2711071, 1, "ca4e34d4c43dbb1258d12072ebe2bdbb5101e59d5b8dd02322eb9f48436b94f1")
