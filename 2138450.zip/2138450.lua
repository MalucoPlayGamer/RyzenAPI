-- Lua provided by RyzenAPI
-- Game: Game: The Agnietta ~The holy healer & the cursed dungeon~

-- MAIN APPLICATION
addappid(2138450)
-- Game: addappid(2138450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138451, 1, "11b26f2e7be1a5f1d3747a2c63e5aefad80f7998e69c1639caa116cf025e1f14")
