-- Lua provided by RyzenAPI
-- Game: addappid(1205980)

-- MAIN APPLICATION
addappid(1205980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205980,0,"9a76360217f619bfa9d52ea7d38c0203e7e830fb68c29fb04fd608e9b98835a7")
