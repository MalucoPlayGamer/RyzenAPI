-- Lua provided by RyzenAPI
-- Game: Blackjack Championship

-- MAIN APPLICATION
addappid(1178160)
