-- Lua provided by RyzenAPI
-- Game: Geometric Sniper - Z

-- MAIN APPLICATION
addappid(1683000)
-- Game: addappid(1683000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1683001, 1, "b9247a7a153cad9c368a4b0ebf16f77a030b6db1e11d83dc6e30a20747a3044b")
