-- Lua provided by RyzenAPI 
-- Game: AppID 1048660
addappid(1048660)
addappid(1048661, 1, "5bef250b21ae7b0e26731f630f3ca69a1c0b88194129c999df1636838db11f44")
