-- Lua provided by RyzenAPI
-- Game: Knight Squad 2

-- MAIN APPLICATION
addappid(1048660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1048661, 1, "5bef250b21ae7b0e26731f630f3ca69a1c0b88194129c999df1636838db11f44")
