-- Lua provided by RyzenAPI 
-- Game: The Precinct Demo
addappid(2893830)
addappid(2893831, 1, "20060f344d636a4b9968688b8616e052404ed32de2c1060605c253e66348103b")
