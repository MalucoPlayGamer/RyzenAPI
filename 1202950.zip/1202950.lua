-- Lua provided by RyzenAPI 
-- Game: AppID 1202950
addappid(1202950)
addappid(1202951, 1, "5253928ab35eaad268c7ef8cb9a5405908d0bb04af6ceec2384687bd22dadf23")
