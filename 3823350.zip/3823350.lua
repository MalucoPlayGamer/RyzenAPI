-- Lua provided by RyzenAPI
-- Game: 3823350

-- MAIN APPLICATION
addappid(3823350)
-- Game: addappid(3823350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3823351, 1, "fa7fb4a639507ba49f8810cc16e0370edaab838106416f583d7b3950ea62d754")
