-- Lua provided by SkyAPI 
-- Game: AppID 94620
addappid(94620)
addappid(94621, 1, "06a792b13cac40de76c5b422533668f517da8db68a847fbe92f3d588f212d841")
addappid(94622, 1, "76720fc14c358e75aa719321ddcf216e7452c181f2a1bb434386a8f770bbc4d2")
