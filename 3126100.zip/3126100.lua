-- Lua provided by RyzenAPI
-- Game: No More Money - Season 3

-- MAIN APPLICATION
addappid(3126100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3126100,0,"57ab6dbc2f321409dd886084b43019685ba6c8a4733520e1d54d25d5715519cf")

