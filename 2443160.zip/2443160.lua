-- Lua provided by RyzenAPI
-- Game: Rat Catcher

-- MAIN APPLICATION
addappid(2443160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443161, 1, "5e4828d238150ecaefd5667ac066cfd47b98123fba41c36110224b1af8615c22")
