-- Lua provided by RyzenAPI
-- Game: Game: Sproots

-- MAIN APPLICATION
addappid(1215410)
-- Game: addappid(1215410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1215411, 1, "47c0f9a63a3973cca62b841da28bf7a462de5e065556b91784f8944c95fe5383")
