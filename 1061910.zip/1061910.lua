-- Lua provided by RyzenAPI
-- Game: Metal: Hellsinger

-- MAIN APPLICATION
addappid(1061910)
addappid(2252490)
addappid(2386360)
addappid(2392613)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061912,0,"e83614873185226a5ca38092a8111176d537fd1252760470e0bb7de6708b7a87")

