-- Lua provided by RyzenAPI
-- Game: Metal: Hellsinger

-- MAIN APPLICATION
addappid(1061910)
addappid(2252490)
addappid(2386360)
addappid(2392613)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061912,0,"e83614873185226a5ca38092a8111176d537fd1252760470e0bb7de6708b7a87")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
