-- Lua provided by RyzenAPI
-- Game: Fire With Fire Tower Attack and Defense

-- MAIN APPLICATION
addappid(351630)

-- MAIN APP DEPOTS / PACKAGES
addappid(351631, 1, "8b3e12cff0f3a713d9c4851b8a05c2c7dd8bbd9ef9d41fed0f0907538568817a")
