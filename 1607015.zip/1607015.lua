-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1607015)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607015,0,"5ed76f78b1c19a832c3429e1b6dcf20f47728b9929345c2baf5ab3999efec18d")
