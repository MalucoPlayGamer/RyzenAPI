-- Lua provided by RyzenAPI
-- Game: Rogue Ninjas

-- MAIN APPLICATION
addappid(3665300)
-- Game: addappid(3665300)

-- MAIN APP DEPOTS / PACKAGES
addappid(3665301, 1, "d1d056ec70d23c65bd5e7f4fa1e677740b6743f58405890f95c7075ecdc6fb56")
