-- Lua provided by RyzenAPI
-- Game: Color Splash: Dogs

-- MAIN APPLICATION
addappid(2551260)
-- Game: addappid(2551260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2551261, 1, "05b8e6182330f58be06312b58912fc4b3233ee7b0bcd1ef3ebb73b2b374d2d69")
