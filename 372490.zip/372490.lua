-- Lua provided by RyzenAPI
-- Game: Game: GROOVY

-- MAIN APPLICATION
addappid(372490)
-- Game: addappid(372490)

-- MAIN APP DEPOTS / PACKAGES
addappid(372491, 1, "876d03e830a575e890e83daa29dfdc38b24dca4a4b168362df80918000d9a19b")
addappid(372492, 1, "3e4e412b5d49a1cd8287354f7e18052ddf76dac25ea19fb6d80f31d80b2c8686")
addappid(486520, 0, "2c0f72712a7fd4cdfbdc9965b591a7751acfa0d35157cffdd0e26457b4d543bf")
