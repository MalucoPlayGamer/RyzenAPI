-- Lua provided by RyzenAPI
-- Game: Blaster Master Zero

-- MAIN APPLICATION
addappid(1034900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1034901, 1, "4de6285a32a47987e8fd482dd63c0eec145ab2dae294962d1794ba19b24f62fc")
addappid(1095770, 0, "b1e79e1fe9d6acbee28e7ff2e51ad30efe096f0193210bacd1bbb9bee80d61d6")
addappid(1095780, 0, "a207ae0d68fe3961860acb952465865509a6f5a5a622d62f5523a6e1bca9e424")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
