-- Lua provided by RyzenAPI
-- Game: addappid(2171100)

-- MAIN APPLICATION
addappid(2171100)
addappid(2239880)
addappid(2302790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2171101, 1, "7f86c3c9188c15df4bc55bf2aedd5185c77a55278ed9962d1a522b04a1b6650d")
