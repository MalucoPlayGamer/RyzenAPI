-- Lua provided by RyzenAPI
-- Game: Game: AppID 1376170

-- MAIN APPLICATION
addappid(1376170)
-- Game: addappid(1376170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1376171, 1, "3a32a01356e8c266c6014edac922f771f3638a09b3386aaac62239da0eebec3b")
