-- Lua provided by RyzenAPI
-- Game: AppID 1376170

-- MAIN APPLICATION
addappid(1376170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1376171, 1, "3a32a01356e8c266c6014edac922f771f3638a09b3386aaac62239da0eebec3b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
