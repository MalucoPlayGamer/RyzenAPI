-- Lua provided by RyzenAPI
-- Game: Florensia

-- MAIN APPLICATION
addappid(384030)

-- MAIN APP DEPOTS / PACKAGES
addappid(384031, 1, "4f0c343c11afe2250267751f9f1f0fbe77a0d7dce8884e8c83fceed29a3dbe6a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
