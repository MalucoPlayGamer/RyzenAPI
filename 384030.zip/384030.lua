-- Lua provided by RyzenAPI
-- Game: Florensia

-- MAIN APPLICATION
addappid(384030)

-- MAIN APP DEPOTS / PACKAGES
addappid(384031, 1, "4f0c343c11afe2250267751f9f1f0fbe77a0d7dce8884e8c83fceed29a3dbe6a")

