-- Lua provided by SkyAPI 
-- Game: UNREAL LIFE Original Soundtrack "Sound of the Mind"
addappid(1464980)
addappid(1464981, 1, "d62bee94f7becb24f9e001fefb654fef91c3ae833b9511e599331030863db8c4")
addappid(1464982, 1, "e862a0fe64b91518d92a708a37d291cb9a26530c3cc8c1df3b23504d72cb00ff")
addappid(1464983, 1, "06a849abb9e12d461377dd0a93c249aa4358f6996605efbab19912aea511cc25")
