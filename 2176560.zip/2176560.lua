-- Lua provided by RyzenAPI 
-- Game: Dreamland
addappid(2176560)
addappid(2176561, 1, "fbb6e1ea641616b771f3b94a21569492e562c6e4eed8e68b0f4126cc2237d99e")
