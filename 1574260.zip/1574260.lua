-- Lua provided by RyzenAPI
-- Game: My Friendly Neighborhood

-- MAIN APPLICATION
addappid(1574260)
-- Game: addappid(1574260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1574261, 1, "c0eae99422a76e3eaa5f34391a3ae06817cd2c712c876212c8da996dacec2baa")
