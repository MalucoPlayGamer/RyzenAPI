-- Lua provided by RyzenAPI 
-- Game: My Friendly Neighborhood
addappid(1574260)
addappid(1574261, 1, "c0eae99422a76e3eaa5f34391a3ae06817cd2c712c876212c8da996dacec2baa")
