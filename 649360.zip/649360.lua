-- Lua provided by RyzenAPI
-- Game: Yesterday

-- MAIN APPLICATION
addappid(649360)
-- Game: addappid(649360)

-- MAIN APP DEPOTS / PACKAGES
addappid(649361, 1, "78867cdf79f6992a69a1760ffca0cb71c81a0bc634b9f34d84f2d490c68b4c97")
