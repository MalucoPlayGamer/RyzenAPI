-- Lua provided by RyzenAPI 
-- Game: Tempest: Pirate Action RPG
addappid(418180)
addappid(418181, 1, "049a645c3130ea5143e12a06f71eaa096628f847df3b4d5ee26318762531315e")
addappid(418182, 1, "407b2b0a1dce8e5f42a122d19b95635148f619d420397d366895eba7f03d5fe4")
addappid(418183, 1, "a1d8dc0dc490fc010ee135927bd81f4fc8674559a4bb271f7f5062414161e4a3")
