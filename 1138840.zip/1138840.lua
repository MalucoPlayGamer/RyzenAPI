-- Lua provided by RyzenAPI
-- Game: addappid(1138840)

-- MAIN APPLICATION
addappid(1138840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1138841, 1, "2b256c75536cadb9a9a0883fdf44087085d73b0fcb9d8a3c6a3114ddbc50c6d0")
