-- Lua provided by RyzenAPI
-- Game: Northern Lights

-- MAIN APPLICATION
addappid(1144620)
-- Game: addappid(1144620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1144621, 1, "e8d28a059d3f77d6303d58e2ce4732d82241b8b13aa244f3c856b6b4c10ad636")
