-- Lua provided by RyzenAPI
-- Game: Northern Lights

-- MAIN APPLICATION
addappid(1144620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1144621, 1, "e8d28a059d3f77d6303d58e2ce4732d82241b8b13aa244f3c856b6b4c10ad636")

