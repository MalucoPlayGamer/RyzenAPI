-- Lua provided by SkyAPI 
-- Game: Northern Lights
addappid(1144620)
addappid(1144621, 1, "e8d28a059d3f77d6303d58e2ce4732d82241b8b13aa244f3c856b6b4c10ad636")
