-- Lua provided by RyzenAPI
-- Game: Ancient Guardian

-- MAIN APPLICATION
addappid(557580)

-- MAIN APP DEPOTS / PACKAGES
addappid(557581, 1, "9035e2da6d67f15d6d6768fc9ffb37540a48ccd623011997f724b283b0f416ef")
addappid(557582, 1, "85a4f56164a59aca965a76e9e03a31f0879421a640b0a934e26fbaa3617f68d8")
addappid(557584, 1, "1abe66b8f14dc25ef8df0a8eae7a11cf65f45cf285ac2bc19b8f62ad87da3ffb")

