-- Lua provided by RyzenAPI
-- Game: Below Sunshade

-- MAIN APPLICATION
addappid(1162170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1162178,0,"561146f19d54245cacdee762b55923068f0af37f69fb51ac7c9f74775ff116f0")
