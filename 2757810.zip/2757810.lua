-- Lua provided by RyzenAPI
-- Game: The Jump Guys

-- MAIN APPLICATION
addappid(2757810)
-- Game: addappid(2757810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2757811, 1, "831ec699965321fede9b6efa07fba8bb71bc8ea657f7986e84d2ff2c74043e06")
