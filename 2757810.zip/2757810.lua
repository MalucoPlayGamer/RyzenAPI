-- Lua provided by SkyAPI 
-- Game: The Jump Guys
addappid(2757810)
addappid(2757811, 1, "831ec699965321fede9b6efa07fba8bb71bc8ea657f7986e84d2ff2c74043e06")
