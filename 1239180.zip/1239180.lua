-- Lua provided by SkyAPI 
-- Game: AZ: Oath of Brotherhood Prologue 1
addappid(1239180)
addappid(1239181, 1, "7a9dcc288e5f969c625b058facc97d8bc524c4da29dc2bcee28424a3b2df97e1")
