-- Lua provided by SkyAPI 
-- Game: Punch Club 2: Fast Forward
addappid(1161590)
addappid(1161591, 1, "9873564f2a9ac4b27fdba0569cbe1af44b087cb3098138889d0c08f04765e57a")
addappid(1161592, 1, "31f371fa499049d473c35fdc5af950c4f1661d8bc609097cd18f99a31e3a0311")
