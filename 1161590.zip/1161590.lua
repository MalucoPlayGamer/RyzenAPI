-- Lua provided by RyzenAPI
-- Game: Punch Club 2: Fast Forward

-- MAIN APPLICATION
addappid(2456610)
addappid(2470820)
addappid(2923090) -- Punch Club 2 Iron Fist

-- MAIN APP DEPOTS / PACKAGES
addappid(1161590, 1, "76ad1f73f451d94853fc80b0f2bb515f03dca560336bd3f41878837741b0b703") -- Punch Club 2: Fast Forward
addappid(1161591, 1, "9873564f2a9ac4b27fdba0569cbe1af44b087cb3098138889d0c08f04765e57a") -- Depot 1161591
addappid(1161592, 1, "31f371fa499049d473c35fdc5af950c4f1661d8bc609097cd18f99a31e3a0311") -- Depot 1161592
addappid(2456610, 1, "ea7a1903ef082e2654d39d87384776997ff16ce4d0d1ed43030cf1a833fee129") -- Punch Club 2 - Cyberpets Power Pack DLC - Depot 2456610
addappid(2470820, 1, "3d45bb02ba7676b784d53c25d4a4fd194f1f5b4d6978c2ea7c068a07430ad233") -- Punch Club 2 Fast Forward - Artbook and Comic Book - Depot 2470820
addtoken(2456610, "17792956582198371615")

