-- Lua provided by RyzenAPI
-- Game: Game: AppID 2546150

-- MAIN APPLICATION
addappid(2546150)
-- Game: addappid(2546150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2546151, 1, "2186ab845fed1d8784d4bfe93fa87e6c15352563e83a453d810ce99d64881263")
