-- Lua provided by RyzenAPI
-- Game: AppID 2546150

-- MAIN APPLICATION
addappid(2546150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2546151, 1, "2186ab845fed1d8784d4bfe93fa87e6c15352563e83a453d810ce99d64881263")

