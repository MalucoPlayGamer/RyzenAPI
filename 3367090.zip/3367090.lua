-- Lua provided by RyzenAPI
-- Game: Kingdom of Cards Demo

-- MAIN APPLICATION
addappid(3367090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3367091, 1, "5444b74fb8d5d3c87e69ea6f138d192386361cf51903565b8d518878a5cc2ed3")
