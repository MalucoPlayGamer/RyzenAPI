-- Lua provided by RyzenAPI
-- Game: Hentai Journey

-- MAIN APPLICATION
addappid(2342240)
-- Game: addappid(2342240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2342241, 1, "4613e7ab3526bbc0a0770cf40bdaa1c65eea8bafea680fdd64e4fca9d3dddc0e")
