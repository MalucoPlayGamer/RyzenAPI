-- Lua provided by RyzenAPI
-- Game: Distant Kingdoms

-- MAIN APPLICATION
addappid(1090760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090761, 1, "6f8986130f228bd276577c6bae3d2fa677971fd31b3d06ed352a51fb4e677603")

