-- Lua provided by RyzenAPI
-- Game: addappid(434240)

-- MAIN APPLICATION
addappid(434240)

-- MAIN APP DEPOTS / PACKAGES
addappid(434241, 1, "cf14d139910eda330280d2806da8b7e829eb40f3256f0f59df859ad2e43ede3c")
addappid(434242, 1, "cc42f1132f4af7675829801efd820c6e1b02ca5c2badcfc496051eafc0fa1418")
addappid(434243, 1, "b14afc5835644668e5d48e64e1692ef4e15c4ccec5dee8017b93f597bf40b765")
