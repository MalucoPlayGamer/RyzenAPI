-- Lua provided by RyzenAPI
-- Game: Game: Caster

-- MAIN APPLICATION
addappid(29800)
-- Game: addappid(29800)

-- MAIN APP DEPOTS / PACKAGES
addappid(29801, 1, "a49645e0aa65cf3c5c617c86edcdd5b61afccc0c4cc4d764d4f03dcf16666ee2")
addappid(29802, 1, "3e44177327d498d388446724069020c2ec32949a048595ea1547ac62349bd760")
