-- Lua provided by RyzenAPI
-- Game: Game: AppID 1435720

-- MAIN APPLICATION
addappid(1435720)
-- Game: addappid(1435720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1435721, 1, "ab1a419226df58be35ee806649b8b5db2cf50847d64d450660f4b0f02de40830")
