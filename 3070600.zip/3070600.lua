-- Lua provided by RyzenAPI
-- Game: Senpai and the Mysterious Island

-- MAIN APPLICATION
addappid(3070600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3070603,0,"929f289de26cc1a85c304c22091e37905571d60a95938020e80e33e5fff126d1")

