-- Lua provided by RyzenAPI
-- Game: Game: Hentai Sexy Nurses

-- MAIN APPLICATION
addappid(2166370)
-- Game: addappid(2166370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2166371, 1, "572c5ba92643da1e6725872b9200732cd51759299886476d94eafb5c5c2a1bd8")
