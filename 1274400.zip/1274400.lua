-- Lua provided by RyzenAPI
-- Game: Prisoner Breaker

-- MAIN APPLICATION
addappid(1274400)
addappid(1274401)
-- Game: addappid(1274400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1274402,0,"315b34a64bf49d2b4eb9c6755c08d020ceec2b4aeef6d5b9bee2e8508611386b")
