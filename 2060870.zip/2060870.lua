-- Lua provided by RyzenAPI
-- Game: Game: Invincible Presents: Atom Eve

-- MAIN APPLICATION
addappid(2060870)
-- Game: addappid(2060870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2060871, 1, "3e91e0a1305afee8a04ef84df0661fcb91626772e4191e1fe7329fa404194d4b")
