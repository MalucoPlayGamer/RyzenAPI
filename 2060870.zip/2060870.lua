-- Lua provided by RyzenAPI
-- Game: Invincible Presents: Atom Eve

-- MAIN APPLICATION
addappid(2060870)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2060871, 1, "3e91e0a1305afee8a04ef84df0661fcb91626772e4191e1fe7329fa404194d4b")

