-- Lua provided by RyzenAPI 
-- Game: Harmony's Odyssey Demo
addappid(1658130)
addappid(1658131, 1, "77689f966024a711207e1466c0f461f2a8dde39c1d38278448ed74b1e6a475d0")
