-- Lua provided by RyzenAPI
-- Game: Game: Gloomwood

-- MAIN APPLICATION
addappid(1150760)
-- Game: addappid(1150760)

-- MAIN APP DEPOTS / PACKAGES
addappid(1150761, 1, "4fe756af50289f72bf1ed9a6a53ab9720376691d264abce579523e8f39bbe662")
