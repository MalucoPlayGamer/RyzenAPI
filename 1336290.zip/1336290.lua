-- Lua provided by RyzenAPI
-- Game: ARTHA

-- MAIN APPLICATION
addappid(1336290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336291,0,"118ce9948dae074d11b6c788ae0a5d1c0dea67e03d4f25c9be8639e6d1af1ece")
addappid(1336292,0,"8b17f27e4cf7bf0ab5ab4a5ad90914180840d65c3bcd0d1ea1f8b160054d9812")

