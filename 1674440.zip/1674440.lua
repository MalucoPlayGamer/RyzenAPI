-- Lua provided by RyzenAPI
-- Game: addappid(1674440)

-- MAIN APPLICATION
addappid(1674440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674441, 1, "cbc273c1ca531eeef2236ad6ea7a1c4457133ad2c29cf6b2ca0cc1b960996466")
