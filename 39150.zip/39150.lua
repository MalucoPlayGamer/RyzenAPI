-- Lua provided by RyzenAPI
-- Game: FINAL FANTASY VIII

-- MAIN APPLICATION
addappid(39150)
addappid(228982)

-- MAIN APP DEPOTS / PACKAGES
addappid(39152,0,"e558b9046ec22b767b35511916e351e654d9a9b0f1c27b59154923322537504b")
addappid(39153,0,"64b7842864b60c45dc99d38b350b0aa14a345546ad7e014571d832f9562d86ef")
addappid(39154,0,"d90df33528a0580eb0c14b511b00f5992090cf7123ef30ec623ca062c5afe819")
addappid(39158,0,"738b122bf6cbfb185b4c74972aaeb17ba5b526de93ecb44bde2d3fe3f3950ed5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
