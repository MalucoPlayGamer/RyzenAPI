-- Lua provided by RyzenAPI
-- Game: H-Isekai Loves : True Love (18+)

-- MAIN APPLICATION
addappid(1845310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1845310,0,"6b1e2ce8dec9f7318b11a4e3b7b6ec960cb4575c4cb4002912ce2c4cfb186350")

