-- Lua provided by RyzenAPI
-- Game: Psychedelic world

-- MAIN APPLICATION
addappid(1240830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240831, 1, "9685f91a2d0341e76dcd55a11312bb39c24117521ba3295bc284546c4770bed7")
