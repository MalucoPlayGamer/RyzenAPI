-- Lua provided by RyzenAPI
-- Game: Selaco Official Soundtrack

-- MAIN APPLICATION
addappid(3047790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3047791, 1, "97322e66aff48af46b50031bcc732089efe06a31b3ec39aa00d81f94c591dd1a")
addappid(3047792, 1, "5845da176cfa35c6dbed6a9c07178decd631369e02ae8f19e8c942acba144d93")
