-- Lua provided by RyzenAPI
-- Game: Heroes of the Three Kingdoms 3

-- MAIN APPLICATION
addappid(1437840)
-- Game: addappid(1437840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1437841, 1, "b6e41e430c9818ea1f27519d74b77de8c29a5e833255955259feba0691335e33")
addappid(1437842, 1, "64b877b9a4599a1e749ad3d5124b559119efdbb1fcc67678aeca7f91b13d4d6e")
