-- Lua provided by RyzenAPI
-- Game: Game: Skelethrone: The Prey

-- MAIN APPLICATION
addappid(2139870)
-- Game: addappid(2139870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139871, 1, "470fefa841e950b78e90c24fb41f25eca37315cede73a45b8ca7a244f7b99439")
