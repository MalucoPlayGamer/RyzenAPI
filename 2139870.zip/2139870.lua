-- Lua provided by RyzenAPI
-- Game: Skelethrone: The Prey

-- MAIN APPLICATION
addappid(2139870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2139871, 1, "470fefa841e950b78e90c24fb41f25eca37315cede73a45b8ca7a244f7b99439")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
