-- Lua provided by RyzenAPI
-- Game: 2868180

-- MAIN APPLICATION
addappid(2868180)
-- Game: addappid(2868180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2868181, 1, "47fa0e642c40c5ecad63dbc9d44492d169da87a0eca7663e830dc179352039d4")
