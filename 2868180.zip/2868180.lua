-- Lua provided by SkyAPI 
-- Game: AppID 2868180
addappid(2868180)
addappid(2868181, 1, "47fa0e642c40c5ecad63dbc9d44492d169da87a0eca7663e830dc179352039d4")
