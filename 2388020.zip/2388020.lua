-- Lua provided by SkyAPI 
-- Game: Invasion: Family Ties
addappid(2388020)
addappid(2388021, 1, "31221f88e330479516c2bf98cf00a82cdee137b9f70679aca4290fc1869566d7")
