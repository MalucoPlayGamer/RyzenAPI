-- Lua provided by RyzenAPI
-- Game: Invasion: Family Ties

-- MAIN APPLICATION
addappid(2388020)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2388021, 1, "31221f88e330479516c2bf98cf00a82cdee137b9f70679aca4290fc1869566d7")

