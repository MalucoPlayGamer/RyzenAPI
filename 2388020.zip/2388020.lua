-- Lua provided by RyzenAPI
-- Game: Invasion: Family Ties

-- MAIN APPLICATION
addappid(2388020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2388021, 1, "31221f88e330479516c2bf98cf00a82cdee137b9f70679aca4290fc1869566d7")

