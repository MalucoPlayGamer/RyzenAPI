-- Lua provided by RyzenAPI
-- Game: Beauty VS Zombie

-- MAIN APPLICATION
addappid(2687050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2687051, 1, "57ab2b6bfe9aa6bddf27ce09cb0b015b7c66ddef8488f566b89a5aebda6021c6")
