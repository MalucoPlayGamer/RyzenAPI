-- Lua provided by RyzenAPI
-- Game: Qvabllock

-- MAIN APPLICATION
addappid(840700)
-- Game: addappid(840700)

-- MAIN APP DEPOTS / PACKAGES
addappid(840701, 1, "1d1b60de722dea85a3cae449cb6a978a7df070415c6416e8fc3f0b341a5db6e6")
