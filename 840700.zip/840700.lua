-- Lua provided by SkyAPI 
-- Game: Qvabllock
addappid(840700)
addappid(840701, 1, "1d1b60de722dea85a3cae449cb6a978a7df070415c6416e8fc3f0b341a5db6e6")
