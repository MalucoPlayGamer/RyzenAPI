-- Lua provided by RyzenAPI
-- Game: AppID 1907690

-- MAIN APPLICATION
addappid(1907690)
-- Game: addappid(1907690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1907691, 1, "042a7ab66d3e5e7653e8077c41bfe6e6c120c6102aa530b792c775ad3f43e2f7")
