-- Lua provided by RyzenAPI
-- Game: Chicken Police: Into the HIVE!

-- MAIN APPLICATION
addappid(2362090)
-- Game: addappid(2362090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2362091, 1, "56d078c048102bb7e7ab8a76ba4a2af15a602a683a4c902519ff3025cb97c08d")
