-- Lua provided by RyzenAPI
-- Game: Survivalist

-- MAIN APPLICATION
addappid(340050)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(340051, 1, "730782494a436dd3b5d0a933732c72583b4db156ef2c92d957bf2b28ebb81b82")

