-- Lua provided by RyzenAPI
-- Game: Game: AppID 340050

-- MAIN APPLICATION
addappid(340050)
-- Game: addappid(340050)

-- MAIN APP DEPOTS / PACKAGES
addappid(340051, 1, "730782494a436dd3b5d0a933732c72583b4db156ef2c92d957bf2b28ebb81b82")
