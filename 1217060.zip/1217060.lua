-- Lua provided by RyzenAPI
-- Game: Gunfire Reborn

-- MAIN APPLICATION
addappid(1217060)
addappid(2111850)
addappid(2430400)
addappid(3063250)
addappid(3920680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1217061, 1, "572c9d118c2d97b0d21798e01e43f4402b71b563c6aa09942c2ceb46b36d8300")

