-- Lua provided by RyzenAPI
-- Game: 642020

-- MAIN APPLICATION
addappid(642020)
-- Game: addappid(642020)

-- MAIN APP DEPOTS / PACKAGES
addappid(642022,0,"e27918317073ebe1c08689b7ee8bea56cb2c69db382fd2cee40b02a3af413b13")
addappid(642023,0,"6c5dd16ea672adfbd607067ace8af79516bee1cc36f52680173901c32ad3648f")
addappid(642024,0,"d37b4aca0df8e4d306d666974e31dabd4ee339c1c215f4683c0e06b5b3f99eb1")
