-- Lua provided by RyzenAPI 
-- Game: I Am Future: Cozy Apocalypse Survival
addappid(1658040)
addappid(1658041, 1, "77ecb47b430884d91e502d8757a26fe9752a4334e7ca64047be83f04827aaf5d")
addappid(2487020, 0, "d99612aa965615d6f1ff622a5b0161799911de6acfcf2e5fa26fd79245bf40c6")
