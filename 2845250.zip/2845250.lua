-- Lua provided by RyzenAPI
-- Game: 100 Istanbul Cats

-- MAIN APPLICATION
addappid(2845250)
addappid(2934360)
addappid(2934370)

