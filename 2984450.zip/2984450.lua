-- Lua provided by RyzenAPI
-- Game: The Story Page

-- MAIN APPLICATION
addappid(2984450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2984451,0,"7d18530859e55ad26bf3e420fc4ebf10c31fabe77683eb51acfc3fd1e3f21677")

