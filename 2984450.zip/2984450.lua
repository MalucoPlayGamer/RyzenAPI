-- Lua provided by RyzenAPI
-- Game: The Story Page

-- MAIN APPLICATION
addappid(2984450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2984451,0,"7d18530859e55ad26bf3e420fc4ebf10c31fabe77683eb51acfc3fd1e3f21677")

