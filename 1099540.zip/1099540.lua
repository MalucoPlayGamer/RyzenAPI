-- Lua provided by RyzenAPI
-- Game: 1099540

-- MAIN APPLICATION
addappid(1099540)
addappid(1099541)
addappid(1099542)
addappid(1099543)
addappid(1099544)
-- Game: addappid(1099540)

-- MAIN APP DEPOTS / PACKAGES
addappid(980481,0,"bc843312f69960af3cebe7dd824718fac4e12a853037d5ba205fe39c0adad279")
