-- Lua provided by SkyAPI 
-- Game: Blue Rose Demo
addappid(365630)
addappid(365631, 1, "4c849e84849edae7ca3e347f2ba14c2e6e9a35ab011b901bd79ee095299ce823")
