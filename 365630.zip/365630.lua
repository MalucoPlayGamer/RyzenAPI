-- Lua provided by RyzenAPI
-- Game: Game: Blue Rose Demo

-- MAIN APPLICATION
addappid(365630)
-- Game: addappid(365630)

-- MAIN APP DEPOTS / PACKAGES
addappid(365631, 1, "4c849e84849edae7ca3e347f2ba14c2e6e9a35ab011b901bd79ee095299ce823")
