-- Lua provided by RyzenAPI
-- Game: Game: Fruity Kitchen

-- MAIN APPLICATION
addappid(3781010)
-- Game: addappid(3781010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3781011, 1, "c2968e2f72eb484522e59d0bd49dfc55885e046b523db019b1b5d1036963043a")
