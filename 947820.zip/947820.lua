-- Lua provided by RyzenAPI
-- Game: AppID 947820

-- MAIN APPLICATION
addappid(947820)
-- Game: addappid(947820)

-- MAIN APP DEPOTS / PACKAGES
addappid(947821, 1, "bc331d1f24b4576e2486da43e368577ac01c54a938172beb3e23e5ca91030065")
