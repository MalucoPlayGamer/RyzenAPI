-- Lua provided by RyzenAPI
-- Game: addappid(3545420)

-- MAIN APPLICATION
addappid(3545420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3545421, 1, "eaea06fa726d824228ec4e745ee01a94eb5edbf8e3f4098354bef6abd92864d2")
