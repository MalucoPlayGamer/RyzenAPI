-- Lua provided by RyzenAPI
-- Game: I drink Sorrel Coffee to reboot reality, but I'm being hunted by Monster Girls and armed agents - DLC 18+

-- MAIN APPLICATION
addappid(3649220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3649220,0,"13b49031393840261c7664bfca8e1c6c6266bf2bef8caafeec7c6d5ffcb7e502")
