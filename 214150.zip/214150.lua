-- Lua provided by RyzenAPI
-- Game: Galactic Civilizations® I: Ultimate Edition

-- MAIN APPLICATION
addappid(214150)
-- Game: addappid(214150)

-- MAIN APP DEPOTS / PACKAGES
addappid(214151, 1, "ff4226d376339d9365e724bcb1c8d241798a8e18bead51766cf77d7a41f06bc8")
