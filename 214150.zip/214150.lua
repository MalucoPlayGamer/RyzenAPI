-- Lua provided by RyzenAPI
-- Game: Galactic Civilizations® I: Ultimate Edition

-- MAIN APPLICATION
addappid(214150)
addappid(648840)

-- MAIN APP DEPOTS / PACKAGES
addappid(214151, 1, "ff4226d376339d9365e724bcb1c8d241798a8e18bead51766cf77d7a41f06bc8")
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

