-- Lua provided by RyzenAPI
-- Game: Fast Detect

-- MAIN APPLICATION
addappid(353220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(353221, 1, "bb797387522f1303e005c272267db5d8d52a5597bf053b467e8269d54aeb0d1c")

