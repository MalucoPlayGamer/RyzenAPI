-- Lua provided by RyzenAPI
-- Game: Fast Detect

-- MAIN APPLICATION
addappid(353220)

-- MAIN APP DEPOTS / PACKAGES
addappid(353221, 1, "bb797387522f1303e005c272267db5d8d52a5597bf053b467e8269d54aeb0d1c")
