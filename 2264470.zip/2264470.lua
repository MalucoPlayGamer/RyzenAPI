-- Lua provided by RyzenAPI
-- Game: 2264470

-- MAIN APPLICATION
addappid(2264470)
-- Game: addappid(2264470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2264471, 1, "a99b9c2694a3b5680fe3fd0c217a50f600a14119a926ec4c9d7b38378df21578")
