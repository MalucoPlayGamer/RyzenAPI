-- Lua provided by RyzenAPI
-- Game: 无尽战线 Infinity War

-- MAIN APPLICATION
addappid(2191820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191821, 1, "3641dfaceb6f38536491327b3f1a42a0679b8965430aa64e7552056204c1a2ef")

