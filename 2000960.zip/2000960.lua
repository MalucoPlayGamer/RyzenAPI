-- Lua provided by RyzenAPI 
-- Game: Highwater
addappid(2000960)
addappid(2000961, 1, "198593773b1b8c01457c056e2f045ef69797503cf8c53b41d0c9d33bcf53157b")
