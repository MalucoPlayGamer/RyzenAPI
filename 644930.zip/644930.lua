-- Lua provided by RyzenAPI
-- Game: They Are Billions

-- MAIN APPLICATION
addappid(644930)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(644931, 1, "44dfb497f7adb842912ea368c2535be6c163e2d25e1a4a9b06f682f60508a673")
addappid(1100130, 0, "58b125475d5c892070bc9b783a235987f0838d35e87719d52be3a3036b15955e")

