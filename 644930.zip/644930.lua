-- Lua provided by SkyAPI 
-- Game: They Are Billions
addappid(644930)
addappid(644931, 1, "44dfb497f7adb842912ea368c2535be6c163e2d25e1a4a9b06f682f60508a673")
addappid(1100130, 0, "58b125475d5c892070bc9b783a235987f0838d35e87719d52be3a3036b15955e")
