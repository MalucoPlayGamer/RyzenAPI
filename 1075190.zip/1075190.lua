-- Lua provided by RyzenAPI
-- Game: A Game of Thrones: The Board Game

-- MAIN APPLICATION
addappid(1075190)
addappid(1416390)
addappid(1416391)

-- MAIN APP DEPOTS / PACKAGES
addappid(1075191,0,"0776c426b3cfe73cc6a8639e8ee248f204495ca77662902dc998abb19f67d0ee")
addappid(1075192,0,"95131551f8e91694e1bf3b5f9b369417cf8cc5cf7f5eea65a89d17bac35aa37a")

