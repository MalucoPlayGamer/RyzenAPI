-- Lua provided by RyzenAPI
-- Game: addappid(3830880)

-- MAIN APPLICATION
addappid(3830880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3830881, 1, "1ac0214f02fa3a64896a05096ac91c58de09d8f5a99c8a50f6ae59f1c6cf90b5")
