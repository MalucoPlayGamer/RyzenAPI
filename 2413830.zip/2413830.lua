-- Lua provided by RyzenAPI
-- Game: Dungeons & Degenerate Gamblers Demo

-- MAIN APPLICATION
addappid(2413830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2413833,0,"c5a917843648262b1d5e26ca97b0b7e5376a623c14f1ec7b944f5260d71bc9e9")
