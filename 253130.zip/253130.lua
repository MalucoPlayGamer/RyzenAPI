-- Lua provided by RyzenAPI
-- Game: 253130

-- MAIN APPLICATION
addappid(253130)
-- Game: addappid(253130)

-- MAIN APP DEPOTS / PACKAGES
addappid(253135,0,"6a2dc05dee84043cf935fa2e84d8c2e2213bc62ababdda4aff7ad7bf38955e5d")
