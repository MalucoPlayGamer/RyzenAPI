-- Lua provided by RyzenAPI
-- Game: addappid(1716600)

-- MAIN APPLICATION
addappid(1716600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1716601, 1, "c5f0b01318ca1a49fa18b386e28466d7cd41abdf0e3285cd978e072ce7036d2e")
