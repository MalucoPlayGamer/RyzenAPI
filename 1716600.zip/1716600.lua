-- Lua provided by RyzenAPI 
-- Game: Brinefall
addappid(1716600)
addappid(1716601, 1, "c5f0b01318ca1a49fa18b386e28466d7cd41abdf0e3285cd978e072ce7036d2e")
