-- Lua provided by RyzenAPI
-- Game: Game: Hopeless Sea

-- MAIN APPLICATION
addappid(2732210)
-- Game: addappid(2732210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2732211, 1, "e318a1fb64e76a6599af407777e8d9389075d4851bf122c32624ee52a28f7401")
