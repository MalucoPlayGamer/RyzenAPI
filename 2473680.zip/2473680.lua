-- Lua provided by RyzenAPI
-- Game: Game: AppID 2473680

-- MAIN APPLICATION
addappid(2473680)
-- Game: addappid(2473680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2473681, 1, "b23c08ec74a339bf19831de1bb1fe6ad9640dae711bcf8ee96b1dcde3da79a49")
addappid(2473682, 1, "ad8593db8329fda0d0dda004e3bfc148b495548ad0934a49394e7004fcb3fa9a")
