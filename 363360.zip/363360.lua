-- Lua provided by RyzenAPI
-- Game: Interstellar Rift

-- MAIN APPLICATION
addappid(363360)
addappid(1504750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(363361, 1, "1e3f890fc7e1491e22c95e9068fe992516d1c7cee530902fb48c8f9133a62727")
addappid(648690, 0, "00051c42c91a8684fa81d5c3816990b0af5759f59fca692034b887c5704a3c43")

