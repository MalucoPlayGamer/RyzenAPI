-- Lua provided by RyzenAPI 
-- Game: Interstellar Rift
addappid(363360)
addappid(363361, 1, "1e3f890fc7e1491e22c95e9068fe992516d1c7cee530902fb48c8f9133a62727")
addappid(648690, 0, "00051c42c91a8684fa81d5c3816990b0af5759f59fca692034b887c5704a3c43")
