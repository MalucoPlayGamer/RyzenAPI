-- Lua provided by RyzenAPI
-- Game: 2490420

-- MAIN APPLICATION
addappid(2490420)
-- Game: addappid(2490420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2490421, 1, "dfa6faf20da0240c6392219e789773c48003b0e2f7c28cdec3256f091ae7be07")
