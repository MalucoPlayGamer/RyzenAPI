-- Lua provided by SkyAPI 
-- Game: Who Are You?
addappid(1411840)
addappid(1411841, 1, "2445d2ab41d2378c7a6496ec7ab0d422eb0a81dbe10ff8b2991e99eeae84741a")
