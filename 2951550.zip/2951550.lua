-- Lua provided by RyzenAPI
-- Game: 子归 Demo

-- MAIN APPLICATION
addappid(2951550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2951551, 1, "e9ba357813edd0e8e0fc465162ea4edcc9d9de575c1c109a7173618edfd5c3b4")
