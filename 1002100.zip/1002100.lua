-- Lua provided by RyzenAPI
-- Game: Negligee: Love Stories

-- MAIN APPLICATION
addappid(1002100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1002101, 1, "021d334e968b36b9f19b89a34c8581ab69e6c2cdf08b0f9ee6a3a5f90a4805e6")
addappid(1012200, 0, "4507d0637ed7d24f5d5b0c85200fdd4ca03db00a1cf879d768cdaf94e04e9ab3")
addappid(1012201, 0, "64124c6392888a0283db24cdb59d90a4ad791e887bbdfb8fa499183e8ab843b9")
addappid(1012202, 0, "7fbe8164a729d5286dbb034699acfff7b211d598c94a880008ff96a68bfa45a3")
addappid(1012203, 0, "13301331c3b1e171efeefeb4b738ddf9b44339d3b37c40a02d29fcb16aac7d9e")
