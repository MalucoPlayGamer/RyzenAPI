-- Lua provided by RyzenAPI
-- Game: Madballs in...Babo: Invasion

-- MAIN APPLICATION
addappid(25700)
addappid(25750)
addappid(25751)
addappid(25752)
addappid(25753)
addappid(25754)
addappid(25755)
addappid(25756)
addappid(25757)
addappid(25758)
addappid(25759)
addappid(25760)
addappid(25761)
addappid(25762)
addappid(25763)
addappid(25764)
addappid(25765)

-- MAIN APP DEPOTS / PACKAGES
addappid(25701,0,"8f756da3e55dea3507361e808459f0ff98e3712c3eabb9e4dadabfc20e7b6513")
addappid(25702,0,"2cbe35bf026991c26584894ee427d022c47070dd80d62d5a7f43c5876f3dccfe")
addappid(25703,0,"a14b0c1941d49170f9278ea39e5ce070aab21e8ec3842ec4f5173468e6594c37")

