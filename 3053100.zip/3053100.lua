-- Lua provided by RyzenAPI
-- Game: My Sudoku - Classic 9x9 Medium 1

-- MAIN APPLICATION
addappid(3053100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3053100,0,"5acdba7947d6645736e36b19f58cb937f9959368233b688ce07e0b385a710212")

