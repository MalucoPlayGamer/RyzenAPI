-- Lua provided by RyzenAPI
-- Game: AppID 588740

-- MAIN APPLICATION
addappid(588740)
-- Game: addappid(588740)

-- MAIN APP DEPOTS / PACKAGES
addappid(588741, 1, "2d646dfc4f7c730cc32c2fdc401254f9479c7bf1b799e006d4670541e05d0b31")
