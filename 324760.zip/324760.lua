-- Lua provided by RyzenAPI 
-- Game: AppID 324760
addappid(324760)
addappid(324761, 1, "5ddf1e7a91c8695a55b6e36769450f4e2d77b3cd2eddecdb1b1f6e3027ed9272")
addappid(324762, 1, "c5fb6eb27523ebf9e605d3fd4e49d456afaf922f2bb9e1fb78fb8c1be1dbfd9f")
addappid(324763, 1, "65f409dafd57067dc7183faac2a1027b7779e19afa40c3642fe63aad6e742833")
