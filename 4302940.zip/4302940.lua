-- 4302940's Lua and Manifest Created by Hubcap Manifest
-- Corner Market
-- Created: July 27, 2026 at 14:20:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4302940) -- Corner Market
addtoken(4302940, "10027838505778757706")
-- MAIN APP DEPOTS
addappid(4302942, 1, "433e39bcb6a4ad1f15d2de66b8fe09ab631a0f909eeca7243e60e6c5dcaa06a5") -- Depot 4302942
setManifestid(4302942, "2746895611490239855", 179190376)