-- Lua provided by RyzenAPI
-- Game: Game: Timeloop: Sink Again Beach

-- MAIN APPLICATION
addappid(2094750)
-- Game: addappid(2094750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094751, 1, "41c148ea7365746c6fd829f8525a60daf52975a51bece12db919d68a2609cc30")
