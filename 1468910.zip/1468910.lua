-- Lua provided by RyzenAPI
-- Game: addappid(1468910)

-- MAIN APPLICATION
addappid(1468910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1468910,0,"6a0299568f6c2c1c1d515c032c297bb6aced63a6e010d30a5180bca36832bf59")
