-- Lua provided by RyzenAPI
-- Game: ALLON3

-- MAIN APPLICATION
addappid(2190420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2190421, 1, "a5bfd0bf72a2ea16f5394f0e32e9545f29eedd012ba77d29abcb12952bac0e49")

