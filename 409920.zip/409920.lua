-- Lua provided by SkyAPI 
-- Game: Brilliant Shadows - Part One of the Book of Gray Magic
addappid(409920)
addappid(409921, 1, "92cf8f78cc2dc0cba01556daf0e8d819e30b6217d9b4587942d175b524836599")
