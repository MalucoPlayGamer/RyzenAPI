-- Lua provided by RyzenAPI
-- Game: 2145010

-- MAIN APPLICATION
addappid(2145010)
-- Game: addappid(2145010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2145011, 1, "ce2b69a7c066dba8b61a3d4e72b8b844964a689ba9130c1a48dfa8028ff44201")
