-- Lua provided by RyzenAPI
-- Game: Game: Run For Your Life

-- MAIN APPLICATION
addappid(1383490)
-- Game: addappid(1383490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383491, 1, "c7626ba0f4fdca7f108d55378b9c9ac31ca0ef19ef23a633b79a0280610b8346")
