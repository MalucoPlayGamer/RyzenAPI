-- Lua provided by RyzenAPI
-- Game: Brisca

-- MAIN APPLICATION
addappid(3866010) -- Brisca

-- MAIN APP DEPOTS / PACKAGES
addappid(3866011, 1, "803949cd6fded0c75e69deb0aa147413c97ab11a4dfb9b1d969c86082ca872aa") -- Depot 3866011

