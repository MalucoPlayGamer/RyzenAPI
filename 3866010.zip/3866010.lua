-- 3866010's Lua and Manifest Created by Hubcap Manifest
-- Brisca
-- Created: August 06, 2026 at 11:24:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3866010) -- Brisca
-- MAIN APP DEPOTS
addappid(3866011, 1, "803949cd6fded0c75e69deb0aa147413c97ab11a4dfb9b1d969c86082ca872aa") -- Depot 3866011
setManifestid(3866011, "5820325793096590919", 170753587)