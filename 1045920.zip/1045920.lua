-- Lua provided by RyzenAPI
-- Game: Hentai beautiful girls 2

-- MAIN APPLICATION
addappid(1045920)
-- Game: addappid(1045920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1045921, 1, "4ad172723b39eb07fa5df17aa57def0569be608b096f7f6ce04d143a3af7c01e")
addappid(1055860, 0, "fa0cad8268c64a380cc1d41288d16a60cca6f486f79cac1f0633cccc8b59bb17")
addappid(1055861, 0, "a39eb50a0db8fb8912e44c14386c4f8d689a03a2f75d7af8bbf077598b27bb10")
