-- Lua provided by RyzenAPI
-- Game: SoulSwap

-- MAIN APPLICATION
addappid(4539000)

-- MAIN APP DEPOTS / PACKAGES
addappid(4539001,0,"8187355496d0fa443d17e252bfca322e2e50dd475a185f6ea9d7a27a8515c93d")

