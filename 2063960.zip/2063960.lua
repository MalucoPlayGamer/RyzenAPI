-- Lua provided by RyzenAPI
-- Game: 69 Berta Hot

-- MAIN APPLICATION
addappid(2063960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063961, 1, "e44cbfbd06772dbbb7e8adf3a36348136edcc8818e2dcd7529d0ba23ea7cdaff")