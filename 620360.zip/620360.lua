-- Lua provided by RyzenAPI
-- Game: AppID 620360

-- MAIN APPLICATION
addappid(620360)
-- Game: addappid(620360)

-- MAIN APP DEPOTS / PACKAGES
addappid(620361, 1, "46e9fe2903eb11844b0cda19e75d389e7a0c1945ec6ada999b03d6d9fe866eb3")
