-- Lua provided by RyzenAPI
-- Game: Toy Clash

-- MAIN APPLICATION
addappid(620360)
addappid(769570)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(620361, 1, "46e9fe2903eb11844b0cda19e75d389e7a0c1945ec6ada999b03d6d9fe866eb3")

