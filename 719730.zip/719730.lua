-- Lua provided by RyzenAPI
-- Game: Uptasia

-- MAIN APPLICATION
addappid(719730)

-- MAIN APP DEPOTS / PACKAGES
addappid(719731, 1, "847bdbb2539bee300c2f3796820c69fb95e912d5cb56dcf1713db2eaea866093")

