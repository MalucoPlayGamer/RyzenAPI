-- Lua provided by RyzenAPI
-- Game: addappid(1915550)

-- MAIN APPLICATION
addappid(1915550)

-- MAIN APP DEPOTS / PACKAGES
addappid(1915551, 1, "7b5dae9370f7b053a9a586e662bd669a59ff532a1acfd20bc43aaa8c90e0c756")
