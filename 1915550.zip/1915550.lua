-- Lua provided by RyzenAPI 
-- Game: Nemesis: Lockdown
addappid(1915550)
addappid(1915551, 1, "7b5dae9370f7b053a9a586e662bd669a59ff532a1acfd20bc43aaa8c90e0c756")
