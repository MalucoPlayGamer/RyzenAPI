-- Lua provided by RyzenAPI
-- Game: Intrusion of Alice

-- MAIN APPLICATION
addappid(1989820)
addappid(2245560)
-- Game: addappid(1989820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989821, 1, "df8f95fa60623c7c9d21795d906062237c31854932826cafdbadb7d6a48aecb6")
