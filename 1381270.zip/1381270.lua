-- Lua provided by RyzenAPI
-- Game: 休止符 StopSign

-- MAIN APPLICATION
addappid(1381270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1381271, 1, "b4b05a65691f165139005a82c779795dbb677be1ee89f951745ade17f9294cea")

