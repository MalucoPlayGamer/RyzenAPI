-- Lua provided by RyzenAPI
-- Game: Voice of Cards: The Forsaken Maiden

-- MAIN APPLICATION
addappid(1748660) -- Voice of Cards: The Forsaken Maiden
addappid(1818620) -- Voice of Cards The Forsaken Maiden 2B Avatar
addappid(1818700) -- Voice of Cards The Forsaken Maiden Puppets Costume
addappid(1818701) -- Voice of Cards The Forsaken Maiden YoRHa Emblem
addappid(1818702) -- Voice of Cards The Forsaken Maiden The Copied City Board
addappid(1818703) -- Voice of Cards The Forsaken Maiden Machine Lifeform Table
addappid(1818704) -- Voice of Cards The Forsaken Maiden Automata Dice
addappid(1818705) -- Voice of Cards The Forsaken Maiden Resistance Jukebox
addappid(1818890) -- Voice of Cards The Forsaken Maiden Pixel Art Set
addappid(1836750) -- Voice of Cards The Forsaken Maiden Ocean Tile Table
addappid(1836751) -- Voice of Cards The Forsaken Maiden Whale of Fortune Pattern

-- MAIN APP DEPOTS / PACKAGES
addappid(1748661, 1, "c0c07258d6f9301adf7b6c572a905205b5746d9f46c9c68903b30e59a7673163") -- Depot 1748661
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
