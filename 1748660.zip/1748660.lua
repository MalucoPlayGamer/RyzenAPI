-- Lua provided by SkyAPI 
-- Game: Voice of Cards: The Forsaken Maiden
addappid(1748660)
addappid(1748661, 1, "c0c07258d6f9301adf7b6c572a905205b5746d9f46c9c68903b30e59a7673163")
