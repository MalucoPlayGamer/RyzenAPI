-- Lua provided by RyzenAPI
-- Game: Game: Voice of Cards: The Forsaken Maiden

-- MAIN APPLICATION
addappid(1748660)
-- Game: addappid(1748660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1748661, 1, "c0c07258d6f9301adf7b6c572a905205b5746d9f46c9c68903b30e59a7673163")
