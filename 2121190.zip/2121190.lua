-- Lua provided by RyzenAPI
-- Game: addappid(2121190)

-- MAIN APPLICATION
addappid(2121190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2121191, 1, "10acf84b3a7b3dca176d30ea25896da60cae9db494d509f7f2810e25b57b7a35")
addappid(2121192, 1, "e8aced1a98d152cb5328f29857f02cc974bc524c2b4989091f25bde5688c091f")
