-- Lua provided by RyzenAPI
-- Game: Sphinx and the Cursed Mummy: Authoring Tools

-- MAIN APPLICATION
addappid(750430)
-- Game: addappid(750430)

-- MAIN APP DEPOTS / PACKAGES
addappid(750431, 1, "a8da53bbf7fc1180ad69c8ecde97be329b1ba6bd5e99173e915e33cf8546dd2e")
