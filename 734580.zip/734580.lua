-- Lua provided by RyzenAPI
-- Game: BattleRush

-- MAIN APPLICATION
addappid(734580)

-- MAIN APP DEPOTS / PACKAGES
addappid(734581, 1, "8d323819f1ceb5a1817ba294b4aae8b4dc6551b625c4afbf9115b787229125fd")
addappid(734582, 1, "c93a5bcc6927022a58277a9c80daf8d5a167306804e77d975afb3e75a9d4b6c7")
addappid(734583, 1, "a3bdec9c7fd685e378ee16f772f6eb663d8358348a327f27ac08c099e260fb47")
addappid(734584, 1, "9ca534267307d77da271471664b16dc90a62be05ff54531b170ba25ca7ccb660")
addappid(734586, 1, "4078f559ef223a59b1dd4aff0d91d7684b49fc69b800e56f88f0de2fc79785f6")
addappid(734588, 1, "2555c7e665de0b2100c05cb5aa10771ea648ec10ba62e110b0785378570b0d2a")
addappid(734589, 1, "d5ea241692b372b65caaa803dd2688ecbe4771d965ea0bada5fbe2e6afa4b024")
addappid(739257, 0, "639151a5b70f836802f605c57509a4f4b1b277eab44c62b814266e87a866db7b")
addappid(739258, 0, "16f5d3f7073053012a47bc199fd72b2d3b09f4dd50f5837f4779ae12ac5c6951")
addappid(739259, 0, "9a3bb21c836c3401f6ab5d6957d7f58af64663c6f0d324fed275986e57b11b6d")
addappid(750493, 0, "d3a54af8fee6cbf9813177a91b002784a5bde3d139be72a3c00dc6c717cd838c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(739250)
addappid(739251)
addappid(739253)
addappid(739255)
addappid(739256)
addappid(750490)
addappid(750491)
addappid(750492)
addappid(764660)
addappid(764661)
