-- Lua provided by RyzenAPI 
-- Game: Another Otter
addappid(886470)
addappid(886471, 1, "72e3123637113b446c3f792483798c441f5c7d2c5257f1a06b561c91ca60cefd")
