-- Lua provided by RyzenAPI
-- Game: Another Otter

-- MAIN APPLICATION
addappid(886470)

-- MAIN APP DEPOTS / PACKAGES
addappid(886471, 1, "72e3123637113b446c3f792483798c441f5c7d2c5257f1a06b561c91ca60cefd")
