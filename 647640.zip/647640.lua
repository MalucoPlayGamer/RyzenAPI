-- Lua provided by RyzenAPI
-- Game: AppID 647640

-- MAIN APPLICATION
addappid(647640)
addappid(673490)

-- MAIN APP DEPOTS / PACKAGES
addappid(647641, 1, "fae0ab8fafc1862fc438ea781930f918edc951df3cd9cfaa9c3a9266cdb2949f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
