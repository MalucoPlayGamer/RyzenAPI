-- Lua provided by RyzenAPI
-- Game: 769020

-- MAIN APPLICATION
addappid(769020)
-- Game: addappid(769020)

-- MAIN APP DEPOTS / PACKAGES
addappid(769021, 1, "ab3c4df43961571de3c5529fc96fdb123ed9bf1acbc938b03769c82a3efee8f6")
