-- Lua provided by RyzenAPI
-- Game: Burning Cars

-- MAIN APPLICATION
addappid(269430)

-- MAIN APP DEPOTS / PACKAGES
addappid(269431, 1, "de404468962348a64866105b235340f7bcdcbe23790ff1fec6e7e5441f8c4c40")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- (windows)
