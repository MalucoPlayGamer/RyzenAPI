-- Lua provided by RyzenAPI
-- Game: Burning Cars

-- MAIN APPLICATION
addappid(269430)

-- MAIN APP DEPOTS / PACKAGES
addappid(269431, 1, "de404468962348a64866105b235340f7bcdcbe23790ff1fec6e7e5441f8c4c40")

