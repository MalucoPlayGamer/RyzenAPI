-- Lua provided by RyzenAPI
-- Game: Federal Reserve Simulator

-- MAIN APPLICATION
addappid(4366260)

-- MAIN APP DEPOTS / PACKAGES
addappid(4366263,0,"972c27ff381dcd36c0b61c5c6057737579394aa990db18cd92d9d424f5e48d50")

