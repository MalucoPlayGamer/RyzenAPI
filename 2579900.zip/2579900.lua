-- Lua provided by RyzenAPI
-- Game: 滩涂地—在魅魔统治的世界追求男♂魂！ Demo

-- MAIN APPLICATION
addappid(2579900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2579901, 1, "fe2bb1c52e21a5b3a3de3f390fa8053fe5ef608aeed52793a07887fc2d968b86")
