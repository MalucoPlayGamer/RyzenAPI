-- Lua provided by RyzenAPI
-- Game: Game: AppID 2579900

-- MAIN APPLICATION
addappid(2579900)
-- Game: addappid(2579900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2579901, 1, "fe2bb1c52e21a5b3a3de3f390fa8053fe5ef608aeed52793a07887fc2d968b86")
