-- Lua provided by SkyAPI 
-- Game: AppID 2579900
addappid(2579900)
addappid(2579901, 1, "fe2bb1c52e21a5b3a3de3f390fa8053fe5ef608aeed52793a07887fc2d968b86")
