-- Lua provided by RyzenAPI
-- Game: Halo 3 Mod Tools - MCC

-- MAIN APPLICATION
addappid(1695791)

-- MAIN APP DEPOTS / PACKAGES
addappid(1701231,0,"02d9a90fd599a0f3ffe3d2d1a1adabbd4606ca0871833f5e56e9142e636108bd")

