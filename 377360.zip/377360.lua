-- Lua provided by RyzenAPI
-- Game: AppID 377360

-- MAIN APPLICATION
addappid(377360)

-- MAIN APP DEPOTS / PACKAGES
addappid(377361, 1, "6fa72a8b7d557a5d87102c01c4f174ac7399159bf18e6934953a070b64787a18")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(487490)
addappid(488090)
