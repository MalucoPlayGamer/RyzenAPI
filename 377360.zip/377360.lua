-- Lua provided by SkyAPI 
-- Game: AppID 377360
addappid(377360)
addappid(377361, 1, "6fa72a8b7d557a5d87102c01c4f174ac7399159bf18e6934953a070b64787a18")
