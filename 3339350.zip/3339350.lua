-- Lua provided by RyzenAPI
-- Game: Game: AppID 3339350

-- MAIN APPLICATION
addappid(3339350)
-- Game: addappid(3339350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3339351, 1, "7fedf21ffcc8a694b83cb7a6233b6fd6dec60afbed54325244e81f77579b6d55")
