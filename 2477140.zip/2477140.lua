-- Lua provided by RyzenAPI
-- Game: 2477140

-- MAIN APPLICATION
addappid(2477140)
-- Game: addappid(2477140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2477141, 1, "0100839f74bd14eed5d79657f8665d6c2f27e21b7df928e69b45b0636a8def0d")
