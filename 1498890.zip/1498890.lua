-- Lua provided by RyzenAPI
-- Game: Kids Memory Game 2

-- MAIN APPLICATION
addappid(1498890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1498891, 1, "435b9aff214145fe1a3e24be1c84dead0c24e3fd21c1e2bce354c6d4b1359064")

