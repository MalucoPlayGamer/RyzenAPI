-- Lua provided by RyzenAPI
-- Game: addappid(2517890)

-- MAIN APPLICATION
addappid(2517890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2517892,0,"b1b45db4da8e221ea8b9e06d7b0493efd181ea6ed68ed76b3ae71993f60c72e3")
