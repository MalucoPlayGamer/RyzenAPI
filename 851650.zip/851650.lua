-- Lua provided by RyzenAPI
-- Game: 851650

-- MAIN APPLICATION
addappid(851650)
-- Game: addappid(851650)

-- MAIN APP DEPOTS / PACKAGES
addappid(851651, 1, "f8c2c3924668909847c97204f2a63fc44a8ec33c9f337399cb6f39d48d6e2c13")
