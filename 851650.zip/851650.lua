-- Lua provided by RyzenAPI
-- Game: LOGistICAL: ABC Islands

-- MAIN APPLICATION
addappid(851650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(851651, 1, "f8c2c3924668909847c97204f2a63fc44a8ec33c9f337399cb6f39d48d6e2c13")
