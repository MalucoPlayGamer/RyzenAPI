-- Lua provided by RyzenAPI 
-- Game: AppID 851650
addappid(851650)
addappid(851651, 1, "f8c2c3924668909847c97204f2a63fc44a8ec33c9f337399cb6f39d48d6e2c13")
