-- Lua provided by RyzenAPI 
-- Game: AppID 747360
addappid(747360)
addappid(747361, 1, "4dcb1a5178b6e4f0ca6286882404dc73ed63572918d4d304a9999a643f71bc43")
