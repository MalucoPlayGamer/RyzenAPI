-- Lua provided by RyzenAPI
-- Game: Gray Dawn

-- MAIN APPLICATION
addappid(747360)
-- Game: addappid(747360)

-- MAIN APP DEPOTS / PACKAGES
addappid(747361, 1, "4dcb1a5178b6e4f0ca6286882404dc73ed63572918d4d304a9999a643f71bc43")
