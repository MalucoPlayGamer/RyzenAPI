-- Lua provided by RyzenAPI
-- Game: AppID 1565210

-- MAIN APPLICATION
addappid(1565210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1565211, 1, "2c909c8784c4db987ca527fbdd57db8fc6734ed4fac597c44bdf711cd500a471")
