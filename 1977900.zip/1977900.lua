-- Lua provided by RyzenAPI
-- Game: Bonza Boom

-- MAIN APPLICATION
addappid(1977900)
addappid(1981475)

-- MAIN APP DEPOTS / PACKAGES
addappid(1977901, 1, "3cf75008da8481e7edc93e067279b930364a7942c4881a65c3ba65b1cc552198")
