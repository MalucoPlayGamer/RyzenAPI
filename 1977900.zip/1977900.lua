-- Lua provided by SkyAPI 
-- Game: Bonza Boom
addappid(1977900)
addappid(1977901, 1, "3cf75008da8481e7edc93e067279b930364a7942c4881a65c3ba65b1cc552198")
addappid(1981475)
