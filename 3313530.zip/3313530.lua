-- Lua provided by RyzenAPI
-- Game: 3313530

-- MAIN APPLICATION
addappid(3313530)
-- Game: addappid(3313530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3313531, 1, "170f5f88fdfe41ce782063b2ddf618b4ebe520519f4ca3c52026b9162e7263f8")
