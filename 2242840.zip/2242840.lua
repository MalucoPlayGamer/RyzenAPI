-- Lua provided by RyzenAPI
-- Game: 2242840

-- MAIN APPLICATION
addappid(2242840)
-- Game: addappid(2242840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242841, 1, "2827f66b89c4a8e5034bae9afe24a081a5593786278497fad8f4ee32c189c779")
