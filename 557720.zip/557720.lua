-- Lua provided by RyzenAPI
-- Game: Love Chronicles: The Spell Collector's Edition

-- MAIN APPLICATION
addappid(557720)

-- MAIN APP DEPOTS / PACKAGES
addappid(557721,0,"1d6f71ad9058d37a627b2646a37f7bb6f62ee4578bcab6ef08a8b8beaa582c3c")

