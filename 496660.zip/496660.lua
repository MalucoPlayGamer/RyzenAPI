-- Lua provided by RyzenAPI
-- Game: 496660

-- MAIN APPLICATION
addappid(496660)
-- Game: addappid(496660)

-- MAIN APP DEPOTS / PACKAGES
addappid(496661, 1, "dd47442de7a57e92b5e11688a3e231cc798a94277fd799d8ec980e9421c24b85")
