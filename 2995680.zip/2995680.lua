-- Lua provided by RyzenAPI
-- Game: Dinosaur Huntress

-- MAIN APPLICATION
addappid(2995680)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2995681, 1, "9d1d86494122c5e1b3c71a4793305632f1505615d708b6224f3d7580f43df3b8")
