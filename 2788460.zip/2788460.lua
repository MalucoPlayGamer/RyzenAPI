-- Lua provided by RyzenAPI
-- Game: Game: Party Party Time 2

-- MAIN APPLICATION
addappid(2788460)
-- Game: addappid(2788460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2788461, 1, "cc570168024bb862832611324f5068a8f382733147d6c5b24e581d882db6485b")
