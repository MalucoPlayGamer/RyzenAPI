-- Lua provided by RyzenAPI
-- Game: The Banner Saga 3 - Soundtrack

-- MAIN APPLICATION
addappid(509590)
-- Game: addappid(509590)

-- MAIN APP DEPOTS / PACKAGES
addappid(509590,0,"b1ee1e38f8f345091e062fa5ea078d0e14ef843091b87db7f13db65f87f39faf")
