-- Lua provided by RyzenAPI
-- Game: Paranormal VHS

-- MAIN APPLICATION
addappid(2298390)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2298391, 1, "f8bc30ace47b94a0bebb495847d272560241fe9dcf7efe7144b026b448858859")

