-- Lua provided by RyzenAPI
-- Game: Game: Paranormal VHS

-- MAIN APPLICATION
addappid(2298390)
-- Game: addappid(2298390)

-- MAIN APP DEPOTS / PACKAGES
addappid(2298391, 1, "f8bc30ace47b94a0bebb495847d272560241fe9dcf7efe7144b026b448858859")
