-- Lua provided by RyzenAPI
-- Game: Game: Rodent Rumble Playtest

-- MAIN APPLICATION
addappid(2663130)
-- Game: addappid(2663130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2663131, 1, "17569d27dd92eb018e757f7e3238a05b6503fc0a4d898ee55514871df3518de5")
