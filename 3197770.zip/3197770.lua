-- Lua provided by RyzenAPI
-- Game: Locator Playtest

-- MAIN APPLICATION
addappid(3197770)
-- Game: addappid(3197770)

-- MAIN APP DEPOTS / PACKAGES
addappid(3388651,0,"eb7a30cc4b60ed277c689d8992cdb410069623388b24b92b2102c0cfdeaf9115")
