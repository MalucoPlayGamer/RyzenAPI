-- Lua provided by RyzenAPI
-- Game: 3290040

-- MAIN APPLICATION
addappid(3290040)
-- Game: addappid(3290040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3290041, 1, "8b2e34a9eb9a538c920d12e08f58f370a647b3a18e74c189de077f72de3ab4da")
