-- Lua provided by RyzenAPI
-- Game: Game: Kotama and Academy Citadel

-- MAIN APPLICATION
addappid(3639650)
-- Game: addappid(3639650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3639651, 1, "1d8e7052572c205bad0554d9198e38b66c9e5c7e9633df56ec3fe95b9636f264")
addappid(3639652, 1, "3046b907177f645936ef93f5f9b17a6383113f9f9f7a4feeac5806c14fc2aacf")
