-- Lua provided by RyzenAPI
-- Game: Game: Counter-Strike: Source

-- MAIN APPLICATION
addappid(240)
-- Game: addappid(240)

-- MAIN APP DEPOTS / PACKAGES
addappid(241, 1, "d07ffb24e34c3b78dd848ab86e57b6bdd1977062c6fec53f9f32b2a3285096da")
addappid(243, 1, "d976afda521b9dc2524e5cf43335f62ea5ebf4b5999ab2d9e5bff6122f6e1f19")
addappid(244, 1, "9a6218cef94f81f0447ce533721ccf993254118ac92a0b26bd2ded4d5781d467")
addappid(245, 1, "6dd908eb13ff887a70e5241cd8f784d8af9a07cef0d27571cb784396c7da6885")
addappid(246, 1, "52fef06ff9ee94cb9e0ea67a839bea714a3918f4f9b3a7b2976a9a3b178b6f8e")
addappid(247, 1, "e454424da3658a49af32bdc85b4a22ca8deb1bb206d653f095d19bcccd26df1c")
addappid(249, 1, "372d8ebbf841bb65d036bb5d7b35dd1412761d4cc9a004d40e81ea61bbff204e")
addappid(250, 1, "9ee3ba74a8485d8d5895407a0cd2391bce7597f4fb8a89f8fcd0f9237aabc9a3")
addappid(251, 1, "d851fe3ec76f099d11ccc77a7ef4fa1a54216ec6b215b36ca43112afc4141a12")
addappid(252, 1, "8a511c5321a1b95615de0de04b328c355cfc53fbd77f4aba0d3be774ff6dc610")
addappid(253, 1, "6396e7ad5e36503e7f4f48108d324ec8e94e8c397b21110107e20bd0e37653cd")
addappid(232331, 0, "54199e376bd48ed470f028a662aff042826c9ffbba7ef90f4dcbd6a50bda0bd2")
addappid(232332, 0, "56750a1d7fa95694087e431b4d8cf2e142ab06d767a25c33813c77526c2c94ca")
addappid(232333, 0, "2a8061ebc8ef4cc51cfdf4b0a2597d079fba1c06b769457f3fdb466e76020011")
