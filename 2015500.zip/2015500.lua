-- Lua provided by SkyAPI 
-- Game: Hatup
addappid(2015500)
addappid(2015501, 1, "5a32a9c6f066015e03edfc0d5affdc069aa263d173c3f8d8bdac58402f987a83")
