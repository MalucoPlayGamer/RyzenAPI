-- Lua provided by RyzenAPI
-- Game: Hatup

-- MAIN APPLICATION
addappid(2015500)
-- Game: addappid(2015500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015501, 1, "5a32a9c6f066015e03edfc0d5affdc069aa263d173c3f8d8bdac58402f987a83")
