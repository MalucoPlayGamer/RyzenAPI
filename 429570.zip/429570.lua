-- Lua provided by RyzenAPI
-- Game: AppID 429570

-- MAIN APPLICATION
addappid(429570)

-- MAIN APP DEPOTS / PACKAGES
addappid(429571, 1, "462b73c44f6817082855d4645aa6be07ceaccf0058656d7d6e8c5f6a632e7ce3")
addappid(429572, 1, "2911d84a5786e2c5287659088c607f9922e90562d8165e41fcff1c4e442aa422")
addappid(429573, 1, "02ac70bca7dc0d5c03e69becb7d5110b4f23f700a356170cf0b4dc8b0a56a8da")
addappid(429574, 1, "cb3ba5e4d67e1c5b9f81c55c452d894bbc20a4e71eaee2a307154e4e9913d1ba")
addappid(429575, 1, "850da48a7914c069cd48b1cac8386bee69e209d44dd161eb6b12733a250b08a7")
addappid(429576, 1, "effb4ed2d66c9b7100d880a79caae7e37ca4cbbc6862813477a49bf12305570b")
addappid(429577, 1, "4db8c37d01d45f7fcb40779860e4392a960c87e359d3185f82f6e99f51129228")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
