-- Lua provided by RyzenAPI
-- Game: 1588961

-- MAIN APPLICATION
addappid(1588961)
-- Game: addappid(1588961)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588961,0,"68a4bf042580e5a325a7fd745023f33bf20820a473febfc46b85a216a7edadf0")
