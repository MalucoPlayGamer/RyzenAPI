-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2693970)
-- Game: addappid(2693970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2693970,0,"8af346d8e9c0bdddc92e42252d6d5012abe212b38bff9792bd47610b805ac6f5")
