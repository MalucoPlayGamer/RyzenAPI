-- Lua provided by RyzenAPI
-- Game: addappid(1000280)

-- MAIN APPLICATION
addappid(1000280)
addappid(1757640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1000281, 1, "75d8d966b1159c52c3807539077824574e719b2aa2f4c17fc1a1d28bf8ba191f")
