-- Lua provided by RyzenAPI
-- Game: 1745980

-- MAIN APPLICATION
addappid(1745980)
-- Game: addappid(1745980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1745981, 1, "9a1bd820bab06c23588edafe3e9b260b78e45f8bc58fd9491c6abd6e49e64ec9")
