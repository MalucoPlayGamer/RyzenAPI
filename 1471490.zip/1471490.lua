-- Lua provided by RyzenAPI
-- Game: addappid(1471490)

-- MAIN APPLICATION
addappid(1471490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1471491, 1, "8c2bd8253085d470569da8782c6d3fcc9066f169eef36cdae24d3390ac50e091")
