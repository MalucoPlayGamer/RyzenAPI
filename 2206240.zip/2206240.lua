-- Lua provided by RyzenAPI
-- Game: Game: Footgun: Underground

-- MAIN APPLICATION
addappid(2206240)
-- Game: addappid(2206240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2206241, 1, "8a0bfbe6923d1f6ef8ab748c9bf22695e72ced838483ae9256a451d8a2b1781f")
