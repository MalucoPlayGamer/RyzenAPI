-- Lua provided by SkyAPI 
-- Game: Footgun: Underground
addappid(2206240)
addappid(2206241, 1, "8a0bfbe6923d1f6ef8ab748c9bf22695e72ced838483ae9256a451d8a2b1781f")
