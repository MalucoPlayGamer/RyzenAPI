-- Lua provided by RyzenAPI
-- Game: Space Hulk: Ascension (Classic)

-- MAIN APPLICATION
addappid(317620)
addappid(335260)
addappid(347980)
addappid(347981)
addappid(355900)

-- MAIN APP DEPOTS / PACKAGES
addappid(317621, 1, "9e8f85b5198c26753388f8d7143d064a474b1dd5819cf321e058909fed8b8184")

