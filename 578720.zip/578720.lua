-- Lua provided by RyzenAPI
-- Game: Game: A Mortician's Tale

-- MAIN APPLICATION
addappid(578720)
-- Game: addappid(578720)

-- MAIN APP DEPOTS / PACKAGES
addappid(578721, 1, "ec9351f86cdeeee6c4bcd95b52bdaa7d36f095a77601dc44a2e509349ffd752f")
addappid(578722, 1, "6a54037f00c26452681a4169c2ad199e0c066f029fd2027dafc32f304c134333")
addappid(578723, 1, "c0027e072af28aab29239357cf395859113d71f8cfa46b355eadcabb01a57489")
