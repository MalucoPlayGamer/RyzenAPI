-- Lua provided by RyzenAPI
-- Game: KFZ

-- MAIN APPLICATION
addappid(2155500)
-- Game: addappid(2155500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2155501, 1, "d84a80f377cf52fa064b68b7941273170e0b30def69a0b752533014c500a21bf")
