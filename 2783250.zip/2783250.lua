-- Lua provided by SkyAPI 
-- Game: AppID 2783250
addappid(2783250)
addappid(2783251, 1, "6d95e204d158fd8c1a04286e6a02895faab4a73a4debf80a337d53db54442910")
