-- Lua provided by RyzenAPI
-- Game: 883140

-- MAIN APPLICATION
addappid(883140)
-- Game: addappid(883140)

-- MAIN APP DEPOTS / PACKAGES
addappid(883141, 1, "a1c40376704596f2d7caf31bdb54f611b333c47ddcbea67ad50115fc41b75563")
