-- Lua provided by RyzenAPI
-- Game: Master Bladesmith

-- MAIN APPLICATION
addappid(1194830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1194831, 1, "7bc16758d1695c74e5c689d7190a9121803bc3dc8db2bffb756b3ffcb4389459")
