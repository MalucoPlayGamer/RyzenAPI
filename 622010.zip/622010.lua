-- Lua provided by RyzenAPI
-- Game: The Fall of Lazarus

-- MAIN APPLICATION
addappid(622010)
addappid(726140)

-- MAIN APP DEPOTS / PACKAGES
addappid(622011, 1, "3eabf0555b557a72e7f62934514e0c8d83e6c536da3630b9bebe39597693b5ac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
