-- Lua provided by RyzenAPI
-- Game: Game: The Fall of Lazarus

-- MAIN APPLICATION
addappid(622010)
addappid(726140)
-- Game: addappid(622010)

-- MAIN APP DEPOTS / PACKAGES
addappid(622011, 1, "3eabf0555b557a72e7f62934514e0c8d83e6c536da3630b9bebe39597693b5ac")
