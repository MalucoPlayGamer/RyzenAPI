-- Lua provided by RyzenAPI
-- Game: Game: AppID 3156460

-- MAIN APPLICATION
addappid(3156460)
-- Game: addappid(3156460)

-- MAIN APP DEPOTS / PACKAGES
addappid(3156461, 1, "16db06d295f2a3653b8e48971c32a207339960dba712ad933d909e5ea865371f")
