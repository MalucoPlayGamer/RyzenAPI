-- Lua provided by RyzenAPI
-- Game: 101 Cats in Dubai

-- MAIN APPLICATION
addappid(2834780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2834781, 1, "49c70ceb1d295a377b9f8a5bfe137a09ef1857966056db3130a623697549ed77")

