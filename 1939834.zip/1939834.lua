-- Lua provided by RyzenAPI
-- Game: Beat Saber - Fall Out Boy - 'Irresistible'

-- MAIN APPLICATION
addappid(1939834)

-- MAIN APP DEPOTS / PACKAGES
addappid(1939834,0,"86f5234d4240bcd75378e2c325dc3557bb8aa669a1d0d3e83892f515e7ca0ad2")

