-- Lua provided by RyzenAPI
-- Game: addappid(2356930)

-- MAIN APPLICATION
addappid(2356930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2356931, 1, "2f63efaa5b9cf5445bad66b1eea4d9990b7f206eb64bb2c2b2f8037085c56347")
