-- Lua provided by RyzenAPI
-- Game: Game: Jigsaw With Animals

-- MAIN APPLICATION
addappid(1711160)
-- Game: addappid(1711160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1711161, 1, "b5694b4b0ba1f45d5c84a2c853d0d6dc73ffcca91f961630afdff73ac9c34ac9")
