-- Lua provided by RyzenAPI 
-- Game: Jigsaw With Animals
addappid(1711160)
addappid(1711161, 1, "b5694b4b0ba1f45d5c84a2c853d0d6dc73ffcca91f961630afdff73ac9c34ac9")
