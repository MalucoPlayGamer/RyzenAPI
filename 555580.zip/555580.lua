-- Lua provided by RyzenAPI
-- Game: The Legend of Dark Witch 2 （魔神少女エピソード２）

-- MAIN APPLICATION
addappid(555580)
addappid(556460)
-- Game: addappid(555580)

-- MAIN APP DEPOTS / PACKAGES
addappid(555581, 1, "2635b60a571c162d0225364845de680944cadbe4607c6dac5e258a913e7c2f44")
