-- Lua provided by RyzenAPI
-- Game: addappid(48280)

-- MAIN APPLICATION
addappid(48280)

-- MAIN APP DEPOTS / PACKAGES
addappid(48281, 1, "b8ac070598c8da3c9ea3f7952e4ebcef8a55bdaccce67dfd1d72c0892a32e7dd")
