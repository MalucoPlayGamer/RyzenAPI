-- Lua provided by RyzenAPI
-- Game: Silicon City

-- MAIN APPLICATION
addappid(1121200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1121201, 1, "1dddc2c85e71f81229115c54ce1baddabe319591352124b329edab456ced637a")
addappid(1121202, 1, "ab45dc6eec1b3d5331ec55db5f43997667f358f03d7ef05f4e7f154a14de099f")
addappid(1121203, 1, "02fc05ffc74abe94d6a60860b86a56d0b957abfbed8b503a89ffaeb7f619c8bd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
