-- Lua provided by RyzenAPI
-- Game: 55130

-- MAIN APPLICATION
addappid(55130)
-- Game: addappid(55130)

-- MAIN APP DEPOTS / PACKAGES
addappid(55131, 1, "e1eab8a897eb02e7724b9aa24a9172852b22499ff71fd9ad147434c1aa0d2f38")
addappid(55132, 1, "73c84370bbff9aefc0cf309c82352fd5e6e67ee1f62882e1d09b717a3523e222")
addappid(55133, 1, "6ca5164b9b6c6eb400bb75c2f2beaf028f114753fbd32a7fa9e2c1575aefeb64")
addappid(55134, 1, "e1b2368cdfb14b556d091ded2a680f77710b9124b93b892e6dbc0ecb0ca0d023")
addappid(55135, 1, "45ec47fe721ba1151a68b5eccdd4bb79808bb28a005295838875bd42b9148e22")
addappid(55136, 1, "12219c653edce00b6d273a03829f4741ba229e7ce8158cde8b93646cbc30cff2")
addappid(55138, 1, "65f3483314afde69312fc85974237fef4eef9e5ccf25bdd1e9da1308dfdf6571")
