-- Lua provided by RyzenAPI
-- Game: Hiiro

-- MAIN APPLICATION
addappid(464960)
addappid(468040)

-- MAIN APP DEPOTS / PACKAGES
addappid(464961, 1, "b0de00da86efe2a0b91e3cf3c0c8ca577ff05bebb3a00006178d563087ea16ba")

