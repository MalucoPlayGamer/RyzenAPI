-- Lua provided by RyzenAPI
-- Game: Last Call BBS

-- MAIN APPLICATION
addappid(1511780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1511781, 1, "2da9758415e0f574035bc36faae59c3974015a4aaa890b481763f192d3aafc61")
addappid(1511782, 1, "7c987321089fa77a357594a6ec5d71aa592c0c1389fa9f437d12001e5724f6e3")
addappid(1511783, 1, "a10fd4c777d4feaef4bfc462bcb0792302ce08073c9f795baf71a3d076154f2b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
