-- Lua provided by RyzenAPI
-- Game: Game: Fat Chicken

-- MAIN APPLICATION
addappid(325860)
addappid(326250)
-- Game: addappid(325860)

-- MAIN APP DEPOTS / PACKAGES
addappid(325861, 1, "34c5aa029b569fe3c2437b25e6e15b597216be0192c8c159599df4b8398a22f8")
addappid(325862, 1, "6f5f4d29c58af69df90c1e5e34f9de8d994f40d5a02e4b2f19a54760681e73f7")
addappid(325863, 1, "5cacbef84b3ff3b633c318920ad0246a27270ce86b0c32494320dd80a7f0de44")
