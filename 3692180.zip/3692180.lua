-- Lua provided by RyzenAPI
-- Game: Game: Washout

-- MAIN APPLICATION
addappid(3692180)
-- Game: addappid(3692180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3692181, 1, "bd2082621009f9a42c7ce6f85c65f95815547a63f5ccb8917538196fec7cb41a")
