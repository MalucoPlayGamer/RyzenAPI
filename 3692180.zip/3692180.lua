-- Lua provided by SkyAPI 
-- Game: Washout
addappid(3692180)
addappid(3692181, 1, "bd2082621009f9a42c7ce6f85c65f95815547a63f5ccb8917538196fec7cb41a")
