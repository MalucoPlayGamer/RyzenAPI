-- 3878620's Lua and Manifest Created by Hubcap Manifest
-- Red Tape Rampage
-- Created: August 13, 2026 at 04:04:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3878620) -- Red Tape Rampage
-- MAIN APP DEPOTS
addappid(3878621, 1, "ca8290473d0c7119e89fd2b05510933c4df21b7dfdbe12bcd6f2cefb68e751b7") -- Depot 3878621
setManifestid(3878621, "4381649709345436126", 460492960)