-- Lua provided by RyzenAPI
-- Game: Red Tape Rampage

-- MAIN APPLICATION
addappid(3878620) -- Red Tape Rampage

-- MAIN APP DEPOTS / PACKAGES
addappid(3878621, 1, "ca8290473d0c7119e89fd2b05510933c4df21b7dfdbe12bcd6f2cefb68e751b7") -- Depot 3878621

