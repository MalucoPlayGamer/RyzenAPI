-- Lua provided by RyzenAPI
-- Game: GLASS - Celestina Demonic 18+ Adult Only

-- MAIN APPLICATION
addappid(1507810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507811, 1, "70cee5d90169bf441681c46f852febc61b2b25c1d925da2dabbee29e6ce12dd0")
addappid(1507812, 1, "077e48cada1f9067ef9acb36438c235824da467ce6d79215da657c3159e457ba")

