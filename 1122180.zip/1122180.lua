-- Lua provided by RyzenAPI
-- Game: Curse of Anabelle

-- MAIN APPLICATION
addappid(1122180)
-- Game: addappid(1122180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122181, 1, "675c7ad936714c922fdb751b46ecfb808707660902c9a676d0c4a67b5c9103c4")
