-- Lua provided by RyzenAPI
-- Game: VR Solo Noble(Peg solitaire)

-- MAIN APPLICATION
addappid(2185890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185891, 1, "f1b0f107bbc168b1e4cdda7cd32bdaefa747332a3014e0c0989b272f79e90e5b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
