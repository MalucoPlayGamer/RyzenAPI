-- Lua provided by RyzenAPI
-- Game: VR Solo Noble(Peg solitaire)

-- MAIN APPLICATION
addappid(2185890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2185891, 1, "f1b0f107bbc168b1e4cdda7cd32bdaefa747332a3014e0c0989b272f79e90e5b")

