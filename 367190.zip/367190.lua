-- Lua provided by RyzenAPI
-- Game: CopperCube 5 Demo

-- MAIN APPLICATION
addappid(367190)

-- MAIN APP DEPOTS / PACKAGES
addappid(367191, 1, "032c9fdd6dfabf7b804233409dfe420a46da01aeb726424ec6680f2fb9c3c577")

