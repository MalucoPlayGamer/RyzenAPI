-- Lua provided by RyzenAPI
-- Game: Game: Tanki Online

-- MAIN APPLICATION
addappid(562010)
addappid(640070)
-- Game: addappid(562010)

-- MAIN APP DEPOTS / PACKAGES
addappid(562011, 1, "39b9d8bad1ded6737fe507ff493a5ee5d9f4501ce031e89361fd81461269350a")
addappid(562012, 1, "43736153487938582221091b85c012a873928c6bf51f911c242e302e0bab62f6")
addappid(562015, 1, "76f2b776b3d989be515fd8d6f42f5677ea87d6ee285eeda47560dc4bf45190e1")
