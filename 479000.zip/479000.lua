-- Lua provided by RyzenAPI
-- Game: IrreVRsible

-- MAIN APPLICATION
addappid(479000)

-- MAIN APP DEPOTS / PACKAGES
addappid(479001, 1, "b71b77fe6e5be73cc66465e69479fb555e185c2253698c2e2a19c1915582098a")

