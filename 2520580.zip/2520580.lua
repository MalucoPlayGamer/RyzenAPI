-- Lua provided by RyzenAPI
-- Game: Up N' Down

-- MAIN APPLICATION
addappid(2520580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2520581, 1, "4df4bc15ae159b034516e4946278e58a82063496c93f38d10f9cbbe00f9298ff")
