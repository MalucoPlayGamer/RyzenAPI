-- Lua provided by RyzenAPI 
-- Game: BattleCON: Online
addappid(792570)
addappid(792571, 1, "b691c68ade832dff28f00c637bf12d946be1cd6c2b2abb06119d84575ffbc47f")
addappid(792572, 1, "9f4526b0aca55516913eb35972a79a245cfa443081028017f2be899f9d5718bb")
addappid(792573, 1, "57f286281af03de902737e4c71461e2677dcd30004d2c98fa7fad81022b0954e")
addappid(940970)
