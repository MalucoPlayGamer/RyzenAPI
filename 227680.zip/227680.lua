-- Lua provided by RyzenAPI
-- Game: AppID 227680

-- MAIN APPLICATION
addappid(227680)
addappid(228983)
addappid(234730)
addappid(234731)

-- MAIN APP DEPOTS / PACKAGES
addappid(227681, 1, "afd8589c82eedf2b6e85adff61a68420dfb786e03dfb62b0daa342a086dbb75e")

