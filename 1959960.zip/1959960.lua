-- Lua provided by RyzenAPI
-- Game: Game: AppID 1959960

-- MAIN APPLICATION
addappid(1959960)
-- Game: addappid(1959960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1959961, 1, "09a79f186d4b97923c6e8a85b448753e58c4ca5c8ea966c301a088379f0bb524")
