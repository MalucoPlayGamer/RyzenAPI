-- Lua provided by RyzenAPI
-- Game: Sex Industry XXX

-- MAIN APPLICATION
addappid(3026440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3026441, 1, "af4bf1f1b900ad7c88a21762711d2a62594e2884dcaa00c20df3a8599d44ec16")

