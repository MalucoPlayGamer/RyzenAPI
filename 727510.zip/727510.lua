-- Lua provided by RyzenAPI
-- Game: 727510

-- MAIN APPLICATION
addappid(727510)
-- Game: addappid(727510)

-- MAIN APP DEPOTS / PACKAGES
addappid(727511, 1, "f2ab03f5899de8696168faa87cb816f34ace7e735dfdcf4b98c1d93cf3bca1e0")
