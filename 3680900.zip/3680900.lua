-- Lua provided by RyzenAPI
-- Game: addappid(3680900)

-- MAIN APPLICATION
addappid(3680900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3680901, 1, "e86fa1bd6d18976bc427c1b63138ba2c0759faccfbb5128661831d607a7fa5b8")
