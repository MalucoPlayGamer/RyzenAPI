-- Lua provided by RyzenAPI
-- Game: addappid(1554170)

-- MAIN APPLICATION
addappid(1554170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554171, 1, "2fbe85add0bfc5976ea48d8feae3ae83fef253ece5c17d253b1a60547257eb34")
