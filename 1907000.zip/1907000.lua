-- Lua provided by RyzenAPI
-- Game: Game: Gloomgrave

-- MAIN APPLICATION
addappid(1907000)
-- Game: addappid(1907000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1907001, 1, "a5b41dba6e5e623bd832e34c16f90b81b9aa8bdcbb6d55a12129e305b54ac78f")
