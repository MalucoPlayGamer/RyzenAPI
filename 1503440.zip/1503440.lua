-- Lua provided by RyzenAPI
-- Game: DreamScapes Dimensions

-- MAIN APPLICATION
addappid(1503440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1503445,0,"4a747d80996d24e6e97de3592de014f900707e9fdd82630b32565c92be83e10f")

