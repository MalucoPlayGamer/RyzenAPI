-- Lua provided by RyzenAPI
-- Game: Road Z : The Last Drive

-- MAIN APPLICATION
addappid(1357410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1357411, 1, "03f50409b24a737d86c389281ea5f3a770f260c4ae7aec13fd0f3210148c1dd7")
