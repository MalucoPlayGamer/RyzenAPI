-- Lua provided by RyzenAPI
-- Game: GTH 3033 - Grand Theft Hunter 3033

-- MAIN APPLICATION
addappid(2703270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2703271, 1, "6570d9addbed0f9d68530007ffe1968a18e8996842ec83d71c9f2340644f35ac")
