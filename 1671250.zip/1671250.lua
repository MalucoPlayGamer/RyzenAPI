-- Lua provided by RyzenAPI
-- Game: Hentai Girls - Anime Puzzle 18+

-- MAIN APPLICATION
addappid(1671250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1671251, 1, "cb526ebcb348b71a353f0f4a824a0ed6ef297e660e62da2d6ca0d94e0b3710be")
