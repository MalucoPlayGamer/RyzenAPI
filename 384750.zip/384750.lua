-- Lua provided by RyzenAPI 
-- Game: AppID 384750
addappid(384750)
addappid(384751, 1, "5a0758337296991d796801f403a4ad0c2712149c0579f2d1b8cd04c17d5d8eb9")
