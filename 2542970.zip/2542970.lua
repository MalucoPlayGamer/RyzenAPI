-- Lua provided by RyzenAPI
-- Game: Coffee Talk Episode 2: Hibiscus & Butterfly - Modding Tool

-- MAIN APPLICATION
addappid(2542970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2542971, 1, "e53570333fc9cc1bd161e05e1455efce1436446f799d8ff0b295549a7301d9fe")
addappid(2542972, 1, "da8e77b76c59bd26f9b9baca5155284b31292c433c0c67449a5ecd8bed6d25e8")
