-- Lua provided by RyzenAPI
-- Game: Beasties - Monster Trainer Puzzle RPG

-- MAIN APPLICATION
addappid(1592600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1592601, 1, "49ba4d5577722f20209fedfd91f27ad67cb54c5a105814655276bcd948e6fa01")

