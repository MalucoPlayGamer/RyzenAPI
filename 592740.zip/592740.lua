-- Lua provided by RyzenAPI
-- Game: Drift 7 Islands (survival)

-- MAIN APPLICATION
addappid(592740)
-- Game: addappid(592740)

-- MAIN APP DEPOTS / PACKAGES
addappid(592741, 1, "5fd2bbac27d668538984e6f3789ee7578465147440f14d567185c7c0edd5805c")
