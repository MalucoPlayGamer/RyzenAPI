-- Lua provided by RyzenAPI
-- Game: addappid(763730)

-- MAIN APPLICATION
addappid(763730)

-- MAIN APP DEPOTS / PACKAGES
addappid(763731, 1, "987491f848217ae581d2251e3c8e74dc89c6df0025fd5c0c7728681446dae0ea")
