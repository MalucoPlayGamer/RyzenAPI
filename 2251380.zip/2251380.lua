-- Lua provided by RyzenAPI
-- Game: Escape From Russia: Mobilization

-- MAIN APPLICATION
addappid(2251380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251381, 1, "8b09bf27471c9cce0ed425c6413ed2954bf7ebe8bef9c5cdd0c253d8949fc443")
addappid(2251382, 1, "41cb84075e11e599752f3a88b5e71985dd37ff1fd44c611c1adbe6fe53a704bc")

