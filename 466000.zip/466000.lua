-- Lua provided by RyzenAPI
-- Game: addappid(466000)

-- MAIN APPLICATION
addappid(466000)

-- MAIN APP DEPOTS / PACKAGES
addappid(466001, 1, "a89cdee0e8179fb831d96ca4b36cdbc2127832267e3bdef96d00dd4a1aae5ed0")
addappid(501250, 0, "4fc5d883f11da46efc978138d786abc99100ccb90c2c1e30ebea0e11c3d7044a")
