-- Lua provided by RyzenAPI
-- Game: Grind Hero: MMORPG

-- MAIN APPLICATION
addappid(3882310)
