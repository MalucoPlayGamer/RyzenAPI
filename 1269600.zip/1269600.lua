-- Lua provided by RyzenAPI 
-- Game: AppID 1269600
addappid(1269600)
addappid(1269601, 1, "c41d17cc20301f8f2a7b1d424e7d329f739305e650a669ef40ee11a3d295298e")
