-- Lua provided by RyzenAPI
-- Game: Adventure Field™ 3 Definitive Edition

-- MAIN APPLICATION
addappid(1269600)
addappid(1269740)
addappid(1269741)
addappid(1269742)
addappid(1269743)
addappid(1269744)
addappid(1269745)
addappid(1269746)
addappid(1269747)
addappid(1269748)
addappid(1269749)
addappid(1269750)
addappid(1269751)
addappid(1269752)
addappid(1269753)
addappid(1269754)
addappid(1269755)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(1269601, 1, "c41d17cc20301f8f2a7b1d424e7d329f739305e650a669ef40ee11a3d295298e")
