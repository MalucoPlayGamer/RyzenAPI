-- Lua provided by RyzenAPI
-- Game: Volleyborne: Unbound Horizons

-- MAIN APPLICATION
addappid(3052520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3052521, 1, "a1f36cab6c5f6a7d440ccd2fc0c67c6c760ad8755613defbf8bc3820907eefd0")

