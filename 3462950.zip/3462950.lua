-- Lua provided by RyzenAPI
-- Game: 3462950

-- MAIN APPLICATION
addappid(3462950)
-- Game: addappid(3462950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3462951, 1, "742eb4541ab81decf84de223a0a1c93a50755944eb62d8be395742a31673790b")
