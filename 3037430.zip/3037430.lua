-- Lua provided by RyzenAPI
-- Game: Game: AppID 3037430

-- MAIN APPLICATION
addappid(3037430)
-- Game: addappid(3037430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3037431, 1, "ca11af42bc90c184113b1e30fd86ba7f0148f69b9102f22a12104a0df8b695ca")
