-- Lua provided by RyzenAPI
-- Game: PALS

-- MAIN APPLICATION
addappid(3808900)
addappid(4610150)
addappid(4610160)

