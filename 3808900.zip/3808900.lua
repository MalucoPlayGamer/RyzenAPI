-- Lua provided by RyzenAPI
-- Game: PALS

-- MAIN APPLICATION
addappid(3808900)

