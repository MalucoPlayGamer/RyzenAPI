-- Lua provided by RyzenAPI
-- Game: 1711500

-- MAIN APPLICATION
addappid(1711500)
-- Game: addappid(1711500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1711501, 1, "5a56ca31e84d4298e4f295f8d8b47fa313233dbe3a51f2de675ecd2e5adffe4b")
