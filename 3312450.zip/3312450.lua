-- Lua provided by RyzenAPI
-- Game: Unaware in The City - Extended

-- MAIN APPLICATION
addappid(3312450)
addappid(3312451)
addappid(3312452)

-- MAIN APP DEPOTS / PACKAGES
addappid(3312450,0,"e8c80dbbd711db602977b32a384c9fd3b33b8e3dd8c2a593ba5c0f186af63976")
