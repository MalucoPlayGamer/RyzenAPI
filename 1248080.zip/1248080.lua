-- Lua provided by RyzenAPI
-- Game: CYGNI: All Guns Blazing

-- MAIN APPLICATION
addappid(1248080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248081, 1, "f123e55ae84d73a62eb32beda558276b860fe9c4b42c4f198a40e2253fa176eb")

