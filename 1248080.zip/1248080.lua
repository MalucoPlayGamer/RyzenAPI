-- Lua provided by RyzenAPI
-- Game: CYGNI: All Guns Blazing

-- MAIN APPLICATION
addappid(1248080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248081, 1, "f123e55ae84d73a62eb32beda558276b860fe9c4b42c4f198a40e2253fa176eb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
