-- Lua provided by RyzenAPI 
-- Game: AppID 759460
addappid(759460)
addappid(759461, 1, "37ce152f9bf2d95faec56f413abaf430708177139e2602b1b99be6bd776e9ce7")
