-- Lua provided by RyzenAPI
-- Game: Orgasm Academy 💦

-- MAIN APPLICATION
addappid(2820600)
-- Game: addappid(2820600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2820601, 1, "5e954ecaa1dd4e606d4dbce6e0b50c4a3148e0f84a8a4669b341500f7f9ecb5d")
