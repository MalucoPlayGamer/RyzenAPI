-- Lua provided by SkyAPI 
-- Game: Orgasm Academy 💦
addappid(2820600)
addappid(2820601, 1, "5e954ecaa1dd4e606d4dbce6e0b50c4a3148e0f84a8a4669b341500f7f9ecb5d")
