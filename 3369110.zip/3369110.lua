-- Lua provided by RyzenAPI
-- Game: Bubble girl

-- MAIN APPLICATION
addappid(3369110)
-- Game: addappid(3369110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3369111, 1, "aed057a5eb675d0e4f3c517593e35827df04e852372b08b62a17cbe8a68c7b03")
