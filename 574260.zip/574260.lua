-- Lua provided by RyzenAPI
-- Game: addappid(574260)

-- MAIN APPLICATION
addappid(574260)

-- MAIN APP DEPOTS / PACKAGES
addappid(574261, 1, "863f4155150311891a27442f51bb4fb5ebcaff10c09131d998a411ccf60299c6")
