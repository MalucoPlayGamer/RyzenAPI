-- Lua provided by RyzenAPI
-- Game: The Secret Order 5: The Buried Kingdom

-- MAIN APPLICATION
addappid(574260)

-- MAIN APP DEPOTS / PACKAGES
addappid(574261, 1, "863f4155150311891a27442f51bb4fb5ebcaff10c09131d998a411ccf60299c6")
