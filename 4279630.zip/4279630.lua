-- Lua provided by RyzenAPI
-- Game: Friendly Steps

-- MAIN APPLICATION
addappid(4279630)

-- MAIN APP DEPOTS / PACKAGES
addappid(4279631, 1, "98085d698486e71620b4fcfb2ba3bd01b131dacf60c441cc457e6d7c519e2a46") -- (windows)

