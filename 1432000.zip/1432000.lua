-- Lua provided by RyzenAPI
-- Game: Timeline Traveler II: Dream

-- MAIN APPLICATION
addappid(1432000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432001, 1, "3110d88e13473730e2905aa528d9726fa27afe59e213d0210aedc06bd11b53cb")
