-- Lua provided by RyzenAPI
-- Game: 1662850

-- MAIN APPLICATION
addappid(1662850)
-- Game: addappid(1662850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662851, 1, "2a5ff486794d8d9833e8d82cccf24d84e36b77486204f24162aef47c6b63bd70")
