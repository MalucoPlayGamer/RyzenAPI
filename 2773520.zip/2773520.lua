-- Lua provided by RyzenAPI
-- Game: 完美恋人~fragile love

-- MAIN APPLICATION
addappid(2773520)
-- Game: addappid(2773520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2773524,0,"e45a3f2bda75df3b55ccb5e271ef65316325ed8f224cc22bd76732f0932aa696")
