-- Lua provided by RyzenAPI 
-- Game: Soulstone Survivors
addappid(2066020)
addappid(2066021, 1, "77548840219e976662662089b95dff8d5aebb105e927a5a9e4ae5a7e1dcc20b3")
addappid(2066022, 1, "fbf81679edbc1631bbdab249108645437b827556e0caf38758aef81283945689")
addappid(2066023, 1, "ebf46700a15e9cfe604b9259944a1a232b677b5a294933df6c266cffdad5147f")
