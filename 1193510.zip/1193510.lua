-- Lua provided by RyzenAPI
-- Game: Game: Antarctic Heritage Trust

-- MAIN APPLICATION
addappid(1193510)
-- Game: addappid(1193510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193511, 1, "78c57d4e84e370161dad782ec3eaee449798039ccc85c045285a6b6b1e26ec1a")
