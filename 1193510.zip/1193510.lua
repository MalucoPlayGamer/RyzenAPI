-- Lua provided by RyzenAPI
-- Game: Antarctic Heritage Trust

-- MAIN APPLICATION
addappid(1193510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1193511, 1, "78c57d4e84e370161dad782ec3eaee449798039ccc85c045285a6b6b1e26ec1a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
