-- Lua provided by RyzenAPI
-- Game: Autumn Night 3D Shooter

-- MAIN APPLICATION
addappid(581730)

-- MAIN APP DEPOTS / PACKAGES
addappid(581731,0,"d52adffc44ca5797129e73557c905326707fd87a92173aa8df6186808d2195b0")
addappid(581732,0,"77f8bfffdb42b3bbbfa8a7690f6f054f42cdc4c7ec3ee9b88fc63e0af5d356c6")

