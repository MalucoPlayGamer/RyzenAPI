-- Lua provided by RyzenAPI
-- Game: 769030

-- MAIN APPLICATION
addappid(769030)
-- Game: addappid(769030)

-- MAIN APP DEPOTS / PACKAGES
addappid(769031, 1, "3ecaae43c0f45bcbf1a395d2ac1ac41d1e4e9f287368b24fca6605f6a2e9100c")
