-- Lua provided by RyzenAPI
-- Game: Game: AppID 3467440

-- MAIN APPLICATION
addappid(3467440)
-- Game: addappid(3467440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3467441, 1, "2dde3aa36099586442ffd9c4218b6e0618aae756346d83778632184af9ab416c")
