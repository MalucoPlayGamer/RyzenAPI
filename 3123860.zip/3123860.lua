-- Lua provided by RyzenAPI
-- Game: addappid(3123860)

-- MAIN APPLICATION
addappid(3123860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3123861, 1, "52497a5d15dfe77adf54089fcf57bf27bb9a82d1374d7db1b2e342ab85455b89")
