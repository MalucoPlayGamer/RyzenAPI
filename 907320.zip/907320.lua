-- Lua provided by RyzenAPI
-- Game: Game: AppID 907320

-- MAIN APPLICATION
addappid(907320)
addappid(978080)
-- Game: addappid(907320)

-- MAIN APP DEPOTS / PACKAGES
addappid(907321, 1, "7bf2208acd3d8e13f777182e31deec5a5b6006301ee7337930896e079047399e")
