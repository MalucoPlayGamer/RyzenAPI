-- Lua provided by RyzenAPI
-- Game: Game: Kurokami-sama's Feast

-- MAIN APPLICATION
addappid(1814930)
-- Game: addappid(1814930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1814931, 1, "0599dab104ae60bc2642b02d5ab6e8819c0b5c3c42fe2d4d1902e72420d68f4f")
