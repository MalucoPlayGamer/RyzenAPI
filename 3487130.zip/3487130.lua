-- Lua provided by RyzenAPI
-- Game: addappid(3487130)

-- MAIN APPLICATION
addappid(3487130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3487131, 1, "fa2c0c66277b7be63491f9da25345300848620f403fd90b951f27ce0b8a65eec")
