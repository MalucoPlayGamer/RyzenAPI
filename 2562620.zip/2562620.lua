-- Lua provided by RyzenAPI
-- Game: The Palace on the Hill

-- MAIN APPLICATION
addappid(2562620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2562621, 1, "d82520e73aff6538a7d859c9a805a5635b13ad866ef17cec87312827b4f38c65")
