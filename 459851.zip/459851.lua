-- Lua provided by RyzenAPI
-- Game: Gremlins, Inc. – Original Soundtrack

-- MAIN APPLICATION
addappid(459851)

-- MAIN APP DEPOTS / PACKAGES
addappid(459851,0,"167318272d304a453c970d07ee0fb24a5251683699f6191ed2fe34192265c6f4")
