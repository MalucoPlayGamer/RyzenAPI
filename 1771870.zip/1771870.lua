-- Lua provided by RyzenAPI
-- Game: My Furry Dictator Demo

-- MAIN APPLICATION
addappid(1771870)
-- Game: addappid(1771870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771871, 1, "3ff9e7208264d82b2009c5b767888f6f7102358ed132ef51d0766582baa65b25")
