-- Lua provided by RyzenAPI
-- Game: 63920

-- MAIN APPLICATION
addappid(63911)
addappid(63920)

-- MAIN APP DEPOTS / PACKAGES
addappid(63912,0,"92c67afcdca1ce026d46e83cb5f8d1cc52b1c16bba24d0b1f3073aa67aa7f1e3")

