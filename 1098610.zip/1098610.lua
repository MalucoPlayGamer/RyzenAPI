-- Lua provided by RyzenAPI
-- Game: Crush the Industry

-- MAIN APPLICATION
addappid(1098610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1098611, 1, "7b3348fb976c50c94a91a5f1d988935891c6e94d398a0842ce9698937aa10fdf")

