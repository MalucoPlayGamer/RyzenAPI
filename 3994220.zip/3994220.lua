-- Lua provided by RyzenAPI
-- Game: Pile Up

-- MAIN APPLICATION
addappid(3994220) -- Pile Up

-- MAIN APP DEPOTS / PACKAGES
addappid(3994221, 1, "1ca1f96fd9415394b121c13d8245498760b18d6f77fae1b006c0063a0a97c750") -- Depot 3994221
