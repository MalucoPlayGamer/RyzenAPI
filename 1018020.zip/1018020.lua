-- Lua provided by RyzenAPI
-- Game: AppID 1018020

-- MAIN APPLICATION
addappid(1018020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1018021, 1, "557cd6dc63286605d96fdb50f3d8064a19cfe7b3076680e134d83c27957da242")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
