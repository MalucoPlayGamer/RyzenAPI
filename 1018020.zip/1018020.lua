-- Lua provided by RyzenAPI 
-- Game: AppID 1018020
addappid(1018020)
addappid(1018021, 1, "557cd6dc63286605d96fdb50f3d8064a19cfe7b3076680e134d83c27957da242")
