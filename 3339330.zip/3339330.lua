-- Lua provided by SkyAPI 
-- Game: Junkyard Builder
addappid(3339330)
addappid(3339331, 1, "3b66c312e31f8601136acfb71627f8b86904a62555395569f8acb4cfd2dfb57f")
