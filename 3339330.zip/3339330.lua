-- Lua provided by RyzenAPI
-- Game: 3339330

-- MAIN APPLICATION
addappid(3339330)
-- Game: addappid(3339330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3339331, 1, "3b66c312e31f8601136acfb71627f8b86904a62555395569f8acb4cfd2dfb57f")
