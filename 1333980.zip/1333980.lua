-- Lua provided by RyzenAPI
-- Game: Flyist

-- MAIN APPLICATION
addappid(1333980)
-- Game: addappid(1333980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1333981, 1, "fd7b9352f2c3c89d40cae8e0adddecdb1f472124be63d71cee06cb37657dd15a")
