-- Lua provided by RyzenAPI
-- Game: AppID 713800

-- MAIN APPLICATION
addappid(713800)

-- MAIN APP DEPOTS / PACKAGES
addappid(713801, 1, "749fb0820cf5db8ac1a3f0876c544e274b1e08cdb0c3baaa89a84bb430d8bfac")
