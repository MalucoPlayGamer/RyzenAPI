-- Lua provided by RyzenAPI
-- Game: The TakeOver

-- MAIN APPLICATION
addappid(418620)
-- Game: addappid(418620)

-- MAIN APP DEPOTS / PACKAGES
addappid(418621, 1, "050e4101d49a98f51e80e794b218d0e6ce183833b5a846aba6e52f76c9465585")
