-- Lua provided by RyzenAPI
-- Game: Dragon Abyss

-- MAIN APPLICATION
addappid(2280580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2280581, 1, "a530accf8a300aca50f512d50853e1a4850d7af5642b40212e8ebbd145e88484")
