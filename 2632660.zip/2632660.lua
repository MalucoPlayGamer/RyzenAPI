-- Lua provided by RyzenAPI
-- Game: 2632660

-- MAIN APPLICATION
addappid(2632660)
-- Game: addappid(2632660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2632661, 1, "6d71f6df0cdbbb1a1bfcbdb077b5080425cedb20cd6e6b7dfb0d82eb71bc4a52")
