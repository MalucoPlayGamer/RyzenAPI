-- Lua provided by RyzenAPI
-- Game: Cursed Isles

-- MAIN APPLICATION
addappid(721540)

-- MAIN APP DEPOTS / PACKAGES
addappid(721541,0,"79d40e1110e06078eaf49350f1bba95b6f940a9cb6775a123e3392a99dae00ff")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
