-- Lua provided by RyzenAPI
-- Game: Cursed Isles

-- MAIN APPLICATION
addappid(721540)

-- MAIN APP DEPOTS / PACKAGES
addappid(721541,0,"79d40e1110e06078eaf49350f1bba95b6f940a9cb6775a123e3392a99dae00ff")

