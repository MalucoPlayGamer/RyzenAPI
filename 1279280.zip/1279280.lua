-- Lua provided by RyzenAPI 
-- Game: Welcome to the Adventurer Inn!
addappid(1279280)
addappid(1279281, 1, "a27301326c4702f1e100b6966b31bcd15d1267e01781f73829c47ee3fd6f70aa")
addappid(1279282, 1, "31c5d847fdb22fc6c0e4d316357b6687e1f9173374a1f3d9b7bee848103bffc0")
