-- Lua provided by RyzenAPI
-- Game: Nexoria: Dungeon Rogue Heroes

-- MAIN APPLICATION
addappid(932210)

-- MAIN APP DEPOTS / PACKAGES
addappid(932211, 1, "3c431672335a74b4aa3a50fc863ad01ee5bdf79ffe9c36d0a7174834ac65d953")

