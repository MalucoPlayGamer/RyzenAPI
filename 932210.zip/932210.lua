-- Lua provided by RyzenAPI
-- Game: Nexoria: Dungeon Rogue Heroes

-- MAIN APPLICATION
addappid(932210)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(932211, 1, "3c431672335a74b4aa3a50fc863ad01ee5bdf79ffe9c36d0a7174834ac65d953")

