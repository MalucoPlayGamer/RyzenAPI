-- Lua provided by RyzenAPI
-- Game: Sweep

-- MAIN APPLICATION
addappid(3393180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3393181, 1, "4590698f5c5fd5c7467358d298fae94b39c167f1c2c3be6d8df2c7a5230262c3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
