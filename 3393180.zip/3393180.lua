-- Lua provided by RyzenAPI
-- Game: Sweep

-- MAIN APPLICATION
addappid(3393180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3393181, 1, "4590698f5c5fd5c7467358d298fae94b39c167f1c2c3be6d8df2c7a5230262c3")
