-- Lua provided by SkyAPI 
-- Game: Four Course Combat
addappid(1489220)
addappid(1489221, 1, "0934619db42f11edf3eab9b55531ee4e6f0da0046adaca206be6466a5b062b66")
