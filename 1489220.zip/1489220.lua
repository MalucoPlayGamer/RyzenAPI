-- Lua provided by RyzenAPI
-- Game: 1489220

-- MAIN APPLICATION
addappid(1489220)
-- Game: addappid(1489220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1489221, 1, "0934619db42f11edf3eab9b55531ee4e6f0da0046adaca206be6466a5b062b66")
