-- Lua provided by RyzenAPI
-- Game: 1265410

-- MAIN APPLICATION
addappid(1265410)
-- Game: addappid(1265410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1265411, 1, "f41cefc1a8705c998ee7073fbaca40aba6b202308b5dc08848db9553683084ab")
