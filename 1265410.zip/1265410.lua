-- Lua provided by RyzenAPI
-- Game: Computer Physics Simulator 2020

-- MAIN APPLICATION
addappid(1265410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1265411, 1, "f41cefc1a8705c998ee7073fbaca40aba6b202308b5dc08848db9553683084ab")

