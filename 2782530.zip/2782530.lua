-- Lua provided by RyzenAPI
-- Game: 2782530

-- MAIN APPLICATION
addappid(2782530)
-- Game: addappid(2782530)

-- MAIN APP DEPOTS / PACKAGES
addappid(2782531, 1, "97d06e3dc41d975f681a0022d5d3ec174e5ae824d0c58ab29b68138fd22626b4")
