-- Lua provided by RyzenAPI
-- Game: Drift Experience Japan: Supporter Edition

-- MAIN APPLICATION
addappid(2322410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2322411, 1, "f1cb621c4a0d1ad0318eb79a5abd85992a388db723c5f5a4648957ca540eefda")

