-- Lua provided by RyzenAPI
-- Game: Drift Experience Japan: Supporter Edition

-- MAIN APPLICATION
addappid(2322410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2322411, 1, "f1cb621c4a0d1ad0318eb79a5abd85992a388db723c5f5a4648957ca540eefda")
