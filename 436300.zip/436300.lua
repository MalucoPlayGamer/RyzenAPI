-- Lua provided by SkyAPI 
-- Game: AppID 436300
addappid(436300)
addappid(436301, 1, "b7916547c053f0212c5b9552250f1ab55a47a453d5339751c6e869ae87507166")
