-- Lua provided by SkyAPI 
-- Game: Asterix & Obelix XXL 3  - The Crystal Menhir
addappid(1109690)
addappid(1109691, 1, "b12ec3ad09f90bbce67363e17a583a710f4a6175b9c70ab52b915220dfc5d131")
addappid(1109692, 1, "2573322a054ba19bbee02886b4480c5f2aad9066a0498836cb7b449c524efc92")
