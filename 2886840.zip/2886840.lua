-- Lua provided by RyzenAPI
-- Game: Summoners War: Chronicles - Official Art Book (e-Book)

-- MAIN APPLICATION
addappid(2886840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2886840,0,"55b147fc3432045a991958d091ccf3e906e62a6580f39e8606fb2b637c23908f")
