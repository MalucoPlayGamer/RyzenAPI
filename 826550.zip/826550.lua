-- Lua provided by RyzenAPI
-- Game: Golf Cart Drive

-- MAIN APPLICATION
addappid(826550)

-- MAIN APP DEPOTS / PACKAGES
addappid(826551,0,"864d2be6bad844871a37ffcd27def560c6125eaa1a5455b3b8c5104c6a0db58a")

