-- Lua provided by RyzenAPI
-- Game: Game: AppID 1216220

-- MAIN APPLICATION
addappid(1216220)
-- Game: addappid(1216220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216221, 1, "4c67fad5845bf1b553b3a5a8578afb878a18422992c475967ecaef8031ee2382")
