-- Lua provided by RyzenAPI
-- Game: Boiling Steel: Preface

-- MAIN APPLICATION
addappid(1216220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1216221, 1, "4c67fad5845bf1b553b3a5a8578afb878a18422992c475967ecaef8031ee2382")
