-- Lua provided by RyzenAPI
-- Game: Feel The Snow

-- MAIN APPLICATION
addappid(538100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(538101, 1, "7e7007a29764dea0a4d30e266c6eecb782fafc471436b6b504b50fbb95f21964")

