-- Lua provided by RyzenAPI
-- Game: addappid(538100)

-- MAIN APPLICATION
addappid(538100)

-- MAIN APP DEPOTS / PACKAGES
addappid(538101, 1, "7e7007a29764dea0a4d30e266c6eecb782fafc471436b6b504b50fbb95f21964")
