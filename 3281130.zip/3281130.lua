-- Lua provided by RyzenAPI
-- Game: 3281130

-- MAIN APPLICATION
addappid(3281130)
-- Game: addappid(3281130)

-- MAIN APP DEPOTS / PACKAGES
addappid(3281131, 1, "c7a7f8fbb7ff5ad33e4af9d4b0ca2543bc4e3d4f095ba15937fb45d75569f353")
