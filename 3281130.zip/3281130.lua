-- Lua provided by RyzenAPI
-- Game: World of Outlaws: Dirt Racing 24 Gold Edition

-- MAIN APPLICATION
addappid(3281130)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3281131, 1, "c7a7f8fbb7ff5ad33e4af9d4b0ca2543bc4e3d4f095ba15937fb45d75569f353")

