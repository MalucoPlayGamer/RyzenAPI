-- Lua provided by RyzenAPI
-- Game: addappid(2280000)

-- MAIN APPLICATION
addappid(2280000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2280001, 1, "9dc7d341caca533f52e45b8e33249b270dbb7f926718c2e1a0a2a3cf5551a801")
