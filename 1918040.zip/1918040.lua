-- Lua provided by RyzenAPI
-- Game: Game: Army of Ruin

-- MAIN APPLICATION
addappid(1918040)
-- Game: addappid(1918040)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918041, 1, "b162c854ac2c2530ede4f2f4e4000fa4e9b6f208b2f6f85470f3b0d49dbbfc0e")
addappid(1918042, 1, "82e3e708076af3a86d3149f83dcc269c29df3d9a489ca8e9c78966c712fc9837")
