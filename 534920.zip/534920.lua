-- Lua provided by RyzenAPI
-- Game: Game: AppID 534920

-- MAIN APPLICATION
addappid(534920)
-- Game: addappid(534920)

-- MAIN APP DEPOTS / PACKAGES
addappid(534921, 1, "342660b2fff1b63bfc4db1342782238d61ff0a0a2492ab4f10d8919ae9f17b86")
