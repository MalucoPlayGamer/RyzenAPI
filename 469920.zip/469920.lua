-- Lua provided by RyzenAPI
-- Game: 469920

-- MAIN APPLICATION
addappid(469920)
addappid(571220)
-- Game: addappid(469920)

-- MAIN APP DEPOTS / PACKAGES
addappid(469921, 1, "300113f53a251a9a4552cb02e8a664944c6f26912974716ebcba5a731ca5b4e3")
