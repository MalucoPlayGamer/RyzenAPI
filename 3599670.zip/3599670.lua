-- Lua provided by RyzenAPI
-- Game: Forest Factory Simulator

-- MAIN APPLICATION
addappid(3599670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3599671, 1, "f92588604c8c93fc6bbeacba5918aac274ae592340aafd1b95e87f23fa9b9ab2")

