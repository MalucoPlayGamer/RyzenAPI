-- Lua provided by RyzenAPI
-- Game: Lusty God

-- MAIN APPLICATION
addappid(2300660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2300661, 1, "d3e0c8a90ab582cefe08703e9f25ab48e499fafd64ed37e3e47d319123fd002b")
