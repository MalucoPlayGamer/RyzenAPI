-- Lua provided by RyzenAPI
-- Game: addappid(1876930)

-- MAIN APPLICATION
addappid(1876930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876931, 1, "e32dd4e6bb4da56c605a2eb79b5c15331165521402fd6bd058d8ac8d13ba8336")
