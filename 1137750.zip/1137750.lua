-- Lua provided by RyzenAPI
-- Game: AppID 1137750

-- MAIN APPLICATION
addappid(1137750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137751, 1, "cb893aa124304bb89a0f140bbd3e10f801fb060b671460c585e7e0befab4ac03")
