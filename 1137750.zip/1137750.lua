-- Lua provided by RyzenAPI
-- Game: Farmer's Life

-- MAIN APPLICATION
addappid(1137750)
addappid(2926840)
addappid(3468940)
addappid(3967800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137751,0,"cb893aa124304bb89a0f140bbd3e10f801fb060b671460c585e7e0befab4ac03")

