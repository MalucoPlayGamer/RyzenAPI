-- Lua provided by RyzenAPI
-- Game: addappid(928780)

-- MAIN APPLICATION
addappid(928780)

-- MAIN APP DEPOTS / PACKAGES
addappid(928781, 1, "18c63639d7531fdae0bd0a7f82cc541a0f617d073e83dde91a9fab19f8f472c7")
