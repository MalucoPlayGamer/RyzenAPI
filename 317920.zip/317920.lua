-- Lua provided by RyzenAPI
-- Game: Hills Of Glory 3D

-- MAIN APPLICATION
addappid(317920)

-- MAIN APP DEPOTS / PACKAGES
addappid(317921, 1, "0bd53ce35be2c45b7c441ca8a061f52e770bf65d6429daa34be48428ffcde948")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
