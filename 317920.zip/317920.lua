-- Lua provided by RyzenAPI
-- Game: Hills Of Glory 3D

-- MAIN APPLICATION
addappid(317920)

-- MAIN APP DEPOTS / PACKAGES
addappid(317921, 1, "0bd53ce35be2c45b7c441ca8a061f52e770bf65d6429daa34be48428ffcde948")

