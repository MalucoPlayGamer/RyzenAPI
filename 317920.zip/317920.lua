-- Lua provided by SkyAPI 
-- Game: Hills Of Glory 3D
addappid(317920)
addappid(317921, 1, "0bd53ce35be2c45b7c441ca8a061f52e770bf65d6429daa34be48428ffcde948")
