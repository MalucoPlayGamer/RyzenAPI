-- Lua provided by RyzenAPI
-- Game: dotAGE Demo

-- MAIN APPLICATION
addappid(1997180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997181, 1, "0b8abf0c8ff9c7703dde0690d1dc744ce7601f89be19e212c3dfb4b956d5cd1c")

