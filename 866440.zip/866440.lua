-- Lua provided by RyzenAPI
-- Game: AppID 866440

-- MAIN APPLICATION
addappid(866440)

-- MAIN APP DEPOTS / PACKAGES
addappid(866441, 1, "677c79509fa0475e4620fa9969d0464e1d72393c90c233d17eb02681898d8707")
addappid(866442, 1, "a6ce079884c13bd5d0936066d9c1bbe68ab8859cf1935a257acfee7cd984ce80")
addappid(866443, 1, "c209b0d981db7194d4341c956015249e5cc2e6394f688db231721e939106dd27")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
