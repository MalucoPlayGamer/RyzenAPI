-- Lua provided by RyzenAPI
-- Game: addappid(2635330)

-- MAIN APPLICATION
addappid(2635330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2635330,0,"47aa3416d1e7400734bba72b97de13d46624d1196d9e242acc31d8bf33d336ea")
