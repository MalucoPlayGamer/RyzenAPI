-- Lua provided by RyzenAPI
-- Game: AppID 1821320

-- MAIN APPLICATION
addappid(1821320)
-- Game: addappid(1821320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1821321, 1, "58ecaaf16fd26f7650c4b96301e755e69c4d6bf0e3d95f16a291e9b922bca4a6")
