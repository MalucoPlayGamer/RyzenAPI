-- Lua provided by SkyAPI 
-- Game: AppID 33540
addappid(33540)
addappid(33541, 1, "1954b6e8bd929b7e577e1898f8f62aa1b5da58b979eebdcce83886b6a54efb7f")
addappid(33542, 1, "dc9a41c30fe3215b297ed9452bdb3595435e05a7144bc522ba4e96524cc1ea01")
addappid(33543, 1, "b904699d960960c65dfaf0d6a9ce7e03fbb8422c227dfef726e18e2742cd8edc")
addappid(33544, 1, "1243b59d3b9332d2222e85fd4fee83ac9558aeb6afc66a9808f45e96d7713b3a")
