-- Lua provided by RyzenAPI
-- Game: AppID 1986620

-- MAIN APPLICATION
addappid(1986620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1986621, 1, "fc9449ca7c86e1d4f48d80b1d822bfafe7fd22d26b715fe5995f78de752a695f")

