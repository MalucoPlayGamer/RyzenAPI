-- Lua provided by RyzenAPI
-- Game: Hanako: Honor & Blade

-- MAIN APPLICATION
addappid(349510)

-- MAIN APP DEPOTS / PACKAGES
addappid(349511, 1, "ff08394eab2db3da6dd42913355bfbf3cbad5455966344faf4a37db9d88d03cb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1714220)
