-- Lua provided by RyzenAPI
-- Game: addappid(349510)

-- MAIN APPLICATION
addappid(349510)

-- MAIN APP DEPOTS / PACKAGES
addappid(349511, 1, "ff08394eab2db3da6dd42913355bfbf3cbad5455966344faf4a37db9d88d03cb")
