-- Lua provided by RyzenAPI
-- Game: Trial of the Towers

-- MAIN APPLICATION
addappid(1051130)
addappid(1053050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1051131, 1, "3fdc449fdd7752264791c9359e7933c04225d7e390998f1ea8ef1def3aa27617")
addappid(1051132, 1, "7b4f5b215c4a886210c045ae1c8f9534b9e4b1d8a665f68a15eb39cb66f541c6")
