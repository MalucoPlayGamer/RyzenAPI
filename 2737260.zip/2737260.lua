-- Lua provided by RyzenAPI
-- Game: Battle RC

-- MAIN APPLICATION
addappid(2737260)
-- Game: addappid(2737260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2737261, 1, "a4aebf58681a1ed2f9158563124c72811e857d1565be1ced271e727f43f82e7a")
