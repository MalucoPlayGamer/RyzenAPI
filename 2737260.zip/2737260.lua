-- Lua provided by SkyAPI 
-- Game: Battle RC
addappid(2737260)
addappid(2737261, 1, "a4aebf58681a1ed2f9158563124c72811e857d1565be1ced271e727f43f82e7a")
