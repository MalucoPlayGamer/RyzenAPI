-- Lua provided by RyzenAPI
-- Game: 寂静破碎

-- MAIN APPLICATION
addappid(1927080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1927081, 1, "aaf9a65c6ad286aa87b168a9940383b60d66b2f432cd793c027dcfca17c6a17a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
