-- Lua provided by RyzenAPI
-- Game: 寂静破碎

-- MAIN APPLICATION
addappid(1927080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1927081, 1, "aaf9a65c6ad286aa87b168a9940383b60d66b2f432cd793c027dcfca17c6a17a")
