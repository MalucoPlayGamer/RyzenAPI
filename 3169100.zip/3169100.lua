-- Lua provided by RyzenAPI
-- Game: addappid(3169100)

-- MAIN APPLICATION
addappid(3169100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3169101, 1, "2ea4109c2fd22f1a60ddf1483c1dcd6f38a312eab6e7045c66eb3ade338d04a5")
