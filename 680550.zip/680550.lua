-- Lua provided by RyzenAPI
-- Game: Zombie Waiting

-- MAIN APPLICATION
addappid(680550)

-- MAIN APP DEPOTS / PACKAGES
addappid(680551, 1, "711e4190d718e231853927d2228e672c7d11a42cab29b1a197ddce7cf23dfeb6")

