-- Lua provided by RyzenAPI
-- Game: addappid(1071070)

-- MAIN APPLICATION
addappid(1071070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1071071, 1, "e499b6f3d39bbc1e456c2fbac09d5468da3a60144016018751cea8b8a01fd5df")
