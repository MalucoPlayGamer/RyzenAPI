-- Lua provided by RyzenAPI
-- Game: HotGirls Sliding Puzzle

-- MAIN APPLICATION
addappid(1751320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1751321, 1, "b570d46b45060a2a06f6dfbe2f162812cfc17624cee6b641964c4e65b7bfd334")
addappid(1754310, 0, "86a0353dfa643200c65ee476826635be5fa76c8da3aab69488fd59037246caa4")
