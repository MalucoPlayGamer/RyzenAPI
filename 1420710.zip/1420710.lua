-- Lua provided by RyzenAPI
-- Game: AppID 1420710

-- MAIN APPLICATION
addappid(1420710)
-- Game: addappid(1420710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420711, 1, "8e3e5317d58765b0d4c2027fa7394406f4801fb6349accc820f2e6eca9b8a2a3")
