-- Lua provided by RyzenAPI
-- Game: SiN Episodes: Emergence German

-- MAIN APPLICATION
addappid(1306)
addappid(1307)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301,0,"9edfa96b02ca1fd8829d639e08c23aaa12d7710eed3c25f30d9d4b757d5fea3f")
addappid(1302,0,"d622bb42b6792d88384e05793f8764922b9c6d77c78453dd3392ffa01584a1d7")
addappid(1303,0,"61cdbd9c7e3183b7184d08ec51e756ed4955474260681f1d2b4f5f98984e086d")
addappid(1304,0,"200fc0fe754cd7a9cda0e34c206d5fc758419d5a278b38041637291f137951a6")
addappid(1305,0,"bc61688f3aef32824ab38d0531b99da9c560d3ef7645d939b193e31782950f8d")

