-- Lua provided by RyzenAPI
-- Game: Shanghai Summer

-- MAIN APPLICATION
addappid(1323830)
-- Game: addappid(1323830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1323831, 1, "2a6049716831049f8ee162a4760b3cdbe37dd7c57c6f1cab929f01c6d2948fc8")
