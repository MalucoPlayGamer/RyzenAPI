-- Lua provided by RyzenAPI 
-- Game: Shanghai Summer
addappid(1323830)
addappid(1323831, 1, "2a6049716831049f8ee162a4760b3cdbe37dd7c57c6f1cab929f01c6d2948fc8")
