-- Lua provided by RyzenAPI
-- Game: Red Matter

-- MAIN APPLICATION
addappid(966680)
-- Game: addappid(966680)

-- MAIN APP DEPOTS / PACKAGES
addappid(966681, 1, "3792b2658f98c1380a4060863a60b3be1fe7e3b1462e7dc167c1c9df3ad647e7")
