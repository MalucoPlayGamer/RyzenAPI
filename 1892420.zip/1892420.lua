-- Lua provided by RyzenAPI
-- Game: The Bunny Graveyard

-- MAIN APPLICATION
addappid(1892420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1892421, 1, "9d37ee9415b3ab3ba038921bc56a167792fa71ea6c53fd7566b45d3ba06c048d")
