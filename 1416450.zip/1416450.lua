-- Lua provided by SkyAPI 
-- Game: Quest: Escape Room
addappid(1416450)
addappid(1416451, 1, "08312b96b2ef65dff4f441fc85cb094b7abf43339fec67a9ec405c1db9dc5ba7")
