-- Lua provided by RyzenAPI
-- Game: 220620

-- MAIN APPLICATION
addappid(220620)
-- Game: addappid(220620)

-- MAIN APP DEPOTS / PACKAGES
addappid(220621, 1, "cb533bb90636408e305bf3cb2504a12f82a5a334ad2f6d59be2ea9650cca4ace")
