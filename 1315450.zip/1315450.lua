-- Lua provided by SkyAPI 
-- Game: Black Skylands Demo
addappid(1315450)
addappid(1315451, 1, "1fc363152898fbb30c83771617a096ebe8aba895ba0b75d75b8f8bdb24c4c4d9")
