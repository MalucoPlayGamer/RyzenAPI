-- Lua provided by RyzenAPI
-- Game: Black Skylands Demo

-- MAIN APPLICATION
addappid(1315450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315451, 1, "1fc363152898fbb30c83771617a096ebe8aba895ba0b75d75b8f8bdb24c4c4d9")
