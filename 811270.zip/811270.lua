-- Lua provided by RyzenAPI
-- Game: 811270

-- MAIN APPLICATION
addappid(811270)
addappid(864560)
-- Game: addappid(811270)

-- MAIN APP DEPOTS / PACKAGES
addappid(811271, 1, "2566982c17ea75fc848d7407f23d75ac979b5621e1c1ca38498ab09e6954ff67")
