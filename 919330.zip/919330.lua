-- Lua provided by RyzenAPI
-- Game: Ghost in the pool

-- MAIN APPLICATION
addappid(919330)

-- MAIN APP DEPOTS / PACKAGES
addappid(919331,0,"6b3ae5770f4cffef0f5b2e8c2b41b10c5ad35adb6627b1aae2ade7f54c21bbc0")
addappid(1460680,0,"e47a0512d45901cc3920da88930879aa4a36825be105b880bb4ad4f53df5b54a")

