-- Lua provided by RyzenAPI
-- Game: AppID 919330

-- MAIN APPLICATION
addappid(919330)
-- Game: addappid(919330)

-- MAIN APP DEPOTS / PACKAGES
addappid(919331, 1, "6b3ae5770f4cffef0f5b2e8c2b41b10c5ad35adb6627b1aae2ade7f54c21bbc0")
