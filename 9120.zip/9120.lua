-- Lua provided by RyzenAPI
-- Game: Game: Hexen II Demo

-- MAIN APPLICATION
addappid(9120)
-- Game: addappid(9120)

-- MAIN APP DEPOTS / PACKAGES
addappid(9121, 1, "d96e192a27138efd001268a31cfada9067a7ac968261e52d9b141b37efd4e6cf")
