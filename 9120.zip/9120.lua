-- Lua provided by SkyAPI 
-- Game: Hexen II Demo
addappid(9120)
addappid(9121, 1, "d96e192a27138efd001268a31cfada9067a7ac968261e52d9b141b37efd4e6cf")
