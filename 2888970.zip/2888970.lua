-- Lua provided by RyzenAPI
-- Game: 2888970

-- MAIN APPLICATION
addappid(2888970)
-- Game: addappid(2888970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2888970,0,"bd7592219d5783caa483ee4f28c2d9a3f5d59860b407c5b71478d5eac11aa6e6")
