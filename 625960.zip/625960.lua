-- Lua provided by SkyAPI 
-- Game: AppID 625960
addappid(625960)
addappid(625961, 1, "afd931e4303e3aa3d3d4c8d1d4f432b4095db76644eaf715d0703900ad65c562")
addappid(625962, 1, "52aa2ce0848e35566d766d0002966dea8bf8515c2b7efabd02aac0c3231cbfb3")
addappid(1230230, 0, "d293a4ee3b76eecea9a324b1ab6b7e723bbc116560c7d885832db912177b6d09")
addappid(3423690)
