-- Lua provided by RyzenAPI 
-- Game: Grass Life Sim
addappid(3356720)
addappid(3356721, 1, "293a035f5b87bde1d1603011a5e1f7a4464b4c3b9f3e1ff0c8d8b45392a93fa4")
