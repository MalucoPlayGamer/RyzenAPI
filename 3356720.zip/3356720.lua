-- Lua provided by RyzenAPI
-- Game: Grass Life Sim

-- MAIN APPLICATION
addappid(3356720)

-- MAIN APP DEPOTS / PACKAGES
addappid(3356721, 1, "293a035f5b87bde1d1603011a5e1f7a4464b4c3b9f3e1ff0c8d8b45392a93fa4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
