-- Lua provided by RyzenAPI
-- Game: Epic Ninja

-- MAIN APPLICATION
addappid(2167830)
-- Game: addappid(2167830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167831, 1, "5477085bd0b077cd24bf42f2e475b58bf9485f73659c3e2a45540644c0ff7041")
