-- Lua provided by RyzenAPI
-- Game: 3023680

-- MAIN APPLICATION
addappid(3023680)
-- Game: addappid(3023680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3023681, 1, "0a5bdee724d0820da207c57645e11aa830bd024ba0f47d7c2f1af5349f937ae8")
