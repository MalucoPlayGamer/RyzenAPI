-- Lua provided by RyzenAPI 
-- Game: How to turn a Cherry tree spirit into an idol
addappid(3023680)
addappid(3023681, 1, "0a5bdee724d0820da207c57645e11aa830bd024ba0f47d7c2f1af5349f937ae8")
