-- Lua provided by RyzenAPI
-- Game: 1361870

-- MAIN APPLICATION
addappid(1361870)
-- Game: addappid(1361870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1361871, 1, "95d7d49a03b9ee450a7d0506f6ee7049fdf0fb6acea792d206d8336a5c6050aa")
