-- Lua provided by RyzenAPI
-- Game: addappid(2152350)

-- MAIN APPLICATION
addappid(2152350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2152351, 1, "7e17bf4741a0439aec0c6d9f3fa3fff294839211a905e78e0558eeee120f7a47")
