-- Lua provided by RyzenAPI
-- Game: Operation: Matriarchy

-- MAIN APPLICATION
addappid(435420)
-- Game: addappid(435420)

-- MAIN APP DEPOTS / PACKAGES
addappid(435421, 1, "180e21caf9b0640e69ae3eb2fb8e6077fb6f592b9b25de0eff82298fded954c1")
addappid(435422, 1, "5c6fbacf40915e33fd26b0a97720ae94d975adaab6ca4d88faa7375f60ed8420")
addappid(435423, 1, "f8eec647a1858cf5407f975da563bbf586b91ec32f6755e5442fc0ece90e5627")
addappid(435424, 1, "2742b639687c0351147934efdf3499c240e3783ec240b4581e120af11dfb5385")
