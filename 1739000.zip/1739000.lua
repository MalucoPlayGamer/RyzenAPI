-- Lua provided by RyzenAPI
-- Game: Franchise Hockey Manager 8

-- MAIN APPLICATION
addappid(1739000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1739001, 1, "f5aecae4b2c19f3c26fccbf153f09ffd5707970b1d530b8f1cce16f622697fbe")
addappid(1739003, 1, "44b130dc1869304bf415012176e7605eadc32332220009b5dd8832b777186cb8")
addappid(1739004, 1, "1045a6d2d578848bbe9666348c668fadddf699324825b09546ffd0ea46a8f440")
addappid(1739005, 1, "7d06c73abccbce221c343e3b4773ebe802624d9ea4ca37994a699fd06a0aedae")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
