-- Lua provided by RyzenAPI
-- Game: Zup! 2

-- MAIN APPLICATION
addappid(562220)
-- Game: addappid(562220)

-- MAIN APP DEPOTS / PACKAGES
addappid(562221, 1, "413d54bad77bfe28ce0c7f549c87b52177c294c74b88c0c4d8954624e4fcf20a")
addappid(569410, 0, "f4eae92152d4d1656e533c27961e2125476d98abf57b638931face7b593363c7")
