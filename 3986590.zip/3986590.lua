-- Lua provided by RyzenAPI
-- Game: Cloud Server Simulator

-- MAIN APPLICATION
addappid(3986590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3986591,0,"caa42ef474fdf4f8d84b241c76c18415908fc62ade1b483d5cceb9b85b4ec763")

