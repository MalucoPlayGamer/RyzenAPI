-- Lua provided by RyzenAPI
-- Game: Landflix Odyssey

-- MAIN APPLICATION
addappid(794850)

-- MAIN APP DEPOTS / PACKAGES
addappid(794851, 1, "760406514277fe170687adc248f4ad75e648b7a929c3071712bf3d7449377fda")
