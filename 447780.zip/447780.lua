-- Lua provided by RyzenAPI
-- Game: AppID 447780

-- MAIN APPLICATION
addappid(447780)
-- Game: addappid(447780)

-- MAIN APP DEPOTS / PACKAGES
addappid(447781, 1, "4b91e5fd037d72623ea4eeed9f409e310e91019061651e3fdf083c9c7bd06c3f")
