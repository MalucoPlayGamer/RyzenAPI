-- Lua provided by RyzenAPI
-- Game: Inworld Origins

-- MAIN APPLICATION
addappid(2199920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199921, 1, "e85a9de6fa6e0b8a1aca985ea829db5bcada5de5848c8ec87800cb6abf009057")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
