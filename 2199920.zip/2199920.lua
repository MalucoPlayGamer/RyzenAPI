-- Lua provided by RyzenAPI
-- Game: Inworld Origins

-- MAIN APPLICATION
addappid(2199920)
-- Game: addappid(2199920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199921, 1, "e85a9de6fa6e0b8a1aca985ea829db5bcada5de5848c8ec87800cb6abf009057")
