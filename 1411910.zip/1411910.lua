-- Lua provided by RyzenAPI
-- Game: 1411910

-- MAIN APPLICATION
addappid(1411910)
-- Game: addappid(1411910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1411911, 1, "8f3ebc25fc2fca88d99ee0a0983db4feed1e6174072e46f94bc59aae57d1445f")
