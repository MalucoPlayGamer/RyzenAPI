-- Lua provided by RyzenAPI
-- Game: Pop Star Life

-- MAIN APP DEPOTS / PACKAGES
addappid(4825210, 1, "793beb7d8990e01c24fa9fa4c1d2858fcfd01d2fb16153a3fbbf296c61c68e10") -- Pop Star Life
addappid(4825211, 1, "1390eaa2d020b1e9500481d3af4d25a0ddcbdcc6fa958524a93f3c94034a28c9") -- Depot 4825211

