-- Lua provided by RyzenAPI
-- Game: PhobLack

-- MAIN APPLICATION
addappid(3057350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3057351, 1, "ba718ea0694d9adcf7253aa5c558de5431b7d8b203145dfd27de69fdd477395c")

