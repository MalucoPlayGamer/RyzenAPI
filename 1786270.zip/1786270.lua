-- Lua provided by RyzenAPI
-- Game: 1786270

-- MAIN APPLICATION
addappid(1786270)
-- Game: addappid(1786270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1786271, 1, "f055e06917f4b9f53b4f59c9ca708d59daba8d771b9ffbb602b1da3b6c6a74f7")
