-- Lua provided by RyzenAPI
-- Game: Hentai Secrets

-- MAIN APPLICATION
addappid(982150)

-- MAIN APP DEPOTS / PACKAGES
addappid(982151, 1, "64e7caa3b3185c1309378f3722cb3e66c8d2eb1814f55d0129d17f3d8516bf00")
