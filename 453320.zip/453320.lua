-- Lua provided by RyzenAPI
-- Game: Game: Vairon's Wrath

-- MAIN APPLICATION
addappid(453320)
-- Game: addappid(453320)

-- MAIN APP DEPOTS / PACKAGES
addappid(453321, 1, "c8f0a15bfa38f57f03bb0314decfa6c6538534060e6b8af9e49785ba95704377")
addappid(453323, 1, "9bcb0e95105ceaba4cd11a5be33103438894d8a15fc65a3e8b7d08ad4d7560a3")
