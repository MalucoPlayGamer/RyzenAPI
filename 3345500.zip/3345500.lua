-- Lua provided by RyzenAPI
-- Game: Game: 饥饿的英灵殿

-- MAIN APPLICATION
addappid(3345500)
addappid(3380710)
-- Game: addappid(3345500)

-- MAIN APP DEPOTS / PACKAGES
addappid(3345501, 1, "3561f0042961508399c87d3cc65ee2382cadbc7a575051241898e13938e1187c")
