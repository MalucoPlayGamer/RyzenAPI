-- Lua provided by RyzenAPI
-- Game: 1133430

-- MAIN APPLICATION
addappid(1133430)
-- Game: addappid(1133430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133431, 1, "7ac9d98eab6d364103989bc1ea0ffe341d57cbac43a305459664a0538a2dfab4")
