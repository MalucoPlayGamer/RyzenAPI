-- Lua provided by RyzenAPI
-- Game: D.N.Age

-- MAIN APPLICATION
addappid(497470)

-- MAIN APP DEPOTS / PACKAGES
addappid(497471, 1, "dcfee0b4e9c4994a6342485fac0a0e813febc438bbc4bf2a411db8fefbce2a21")

