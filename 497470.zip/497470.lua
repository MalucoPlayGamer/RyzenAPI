-- Lua provided by RyzenAPI
-- Game: D.N.Age

-- MAIN APPLICATION
addappid(497470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(497471, 1, "dcfee0b4e9c4994a6342485fac0a0e813febc438bbc4bf2a411db8fefbce2a21")

