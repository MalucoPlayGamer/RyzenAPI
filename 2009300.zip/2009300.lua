-- Lua provided by RyzenAPI
-- Game: Game: AppID 2009300

-- MAIN APPLICATION
addappid(2009300)
-- Game: addappid(2009300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2009301, 1, "b40da33163a22c480410d10b8395f267c425e1b75b4870648c72cd0ace6ad256")
