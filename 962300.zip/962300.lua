-- Lua provided by RyzenAPI
-- Game: Cao Xiu - Officer Ticket / 曹休使用券

-- MAIN APPLICATION
addappid(962300)

-- MAIN APP DEPOTS / PACKAGES
addappid(962300,0,"08c507339b9b5c64543a8e5a683e7b504343eb0a4975ed35ea3ec975855f52db")
