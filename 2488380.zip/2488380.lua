-- Lua provided by RyzenAPI
-- Game: Game: Nine：Ambition Demo

-- MAIN APPLICATION
addappid(2488380)
-- Game: addappid(2488380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2488381, 1, "bd5b394808aac3e5c4827a8061f17410dc971c198787dce7d477a0cf0d8b89de")
