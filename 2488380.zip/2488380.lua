-- Lua provided by RyzenAPI 
-- Game: Nine：Ambition Demo
addappid(2488380)
addappid(2488381, 1, "bd5b394808aac3e5c4827a8061f17410dc971c198787dce7d477a0cf0d8b89de")
