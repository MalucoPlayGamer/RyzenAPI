-- Lua provided by SkyAPI 
-- Game: XiuzhenWorld2
addappid(3080880)
addappid(3080881, 1, "01f7eca562612b60c48a61e2f1363c61b6429ec1d32bb2ff64292e4974ad1302")
