-- Lua provided by RyzenAPI
-- Game: XiuzhenWorld2

-- MAIN APPLICATION
addappid(3080880)
-- Game: addappid(3080880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3080881, 1, "01f7eca562612b60c48a61e2f1363c61b6429ec1d32bb2ff64292e4974ad1302")
