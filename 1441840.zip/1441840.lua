-- Lua provided by RyzenAPI
-- Game: addappid(1441840)

-- MAIN APPLICATION
addappid(1441840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1441841, 1, "088e8bdd7a5708ee6d10f9f666bc42c1915098a889e0fc8fb4719eecfd528ad6")
addappid(1441842, 1, "9e5dfa9a048a16f5065fbb2de7fca4c414b61431d8e9be8fba8a15d56b092e36")
