-- Lua provided by RyzenAPI
-- Game: Orcs Will Never Be Slaves Demo

-- MAIN APPLICATION
addappid(3467600)

-- MAIN APP DEPOTS / PACKAGES
addappid(3467601, 1, "03cc1a87147e97e6d49cc8b07b8e52fd9cb7555b74f9858ca99fd7559d9f17d4")
