-- Lua provided by RyzenAPI
-- Game: Baldr Sky

-- MAIN APPLICATION
addappid(741140)

-- MAIN APP DEPOTS / PACKAGES
addappid(741141, 1, "e328d65c7ee7ca482bc483c0ce9f7af6cdc5331a3da1fb27c212c24e5d2b52e5")
addappid(741142, 1, "30f850c1be41a667103552358bdf68971e87c86e38418ebe9374d853417f53b4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
