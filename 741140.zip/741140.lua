-- Lua provided by SkyAPI 
-- Game: Baldr Sky
addappid(741140)
addappid(741141, 1, "e328d65c7ee7ca482bc483c0ce9f7af6cdc5331a3da1fb27c212c24e5d2b52e5")
addappid(741142, 1, "30f850c1be41a667103552358bdf68971e87c86e38418ebe9374d853417f53b4")
