-- Lua provided by RyzenAPI
-- Game: Silly Billy Demo

-- MAIN APPLICATION
addappid(2918680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2918681, 1, "60633fb93171ef40d090167b1a989f5af60e5849c54279fd7c4126aaa5c22436")

