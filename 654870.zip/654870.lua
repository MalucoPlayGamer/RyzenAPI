-- Lua provided by RyzenAPI
-- Game: AppID 654870

-- MAIN APPLICATION
addappid(654870)

-- MAIN APP DEPOTS / PACKAGES
addappid(654871, 1, "bca22401ca0e39915f0da48692efede5d7d0c24de099d3116aba03d30c572771")
