-- Lua provided by RyzenAPI
-- Game: Elf Enchanter: Arousing Anima

-- MAIN APPLICATION
addappid(1031170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1031171, 1, "23df1aada003b3aef1b90645c0604a43d1aff73a1c721af619b12e18c23658da")
addappid(1031174, 1, "a22a5b36191cbb725b7649b57c48822a42d7856c5afbb9c28d591ee46ba8dcf3")
addappid(1031175, 1, "11a592e644faf9db3a7285607e5c1291ac7fd6de241ab93493fca11315cf4123")

