-- Lua provided by RyzenAPI
-- Game: Game: Save daddy trump 2: The Final Triumph

-- MAIN APPLICATION
addappid(1493450)
-- Game: addappid(1493450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493451, 1, "75d9407fd56baf1585d942b715a83994ce5df9bb7497c32e8a2c0146ee311c52")
