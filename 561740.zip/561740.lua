-- Lua provided by RyzenAPI
-- Game: Game: MidBoss

-- MAIN APPLICATION
addappid(561740)
-- Game: addappid(561740)

-- MAIN APP DEPOTS / PACKAGES
addappid(561741, 1, "37bd181866c793304f83624352fe75cc93687e1a00bc5bffc2cde1a5c3c363c5")
addappid(561742, 1, "1e93efbb393793c7a0cfd0601291ee5258024d0fc178f0d3f012928f8da372b9")
addappid(561743, 1, "8d7f11299b2fa74ecb95832c88f3ac9f463cd1cef5abd29364e86cf03aeae068")
