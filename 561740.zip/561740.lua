-- Lua provided by RyzenAPI
-- Game: MidBoss

-- MAIN APPLICATION
addappid(561740)

-- MAIN APP DEPOTS / PACKAGES
addappid(561741, 1, "37bd181866c793304f83624352fe75cc93687e1a00bc5bffc2cde1a5c3c363c5")
addappid(561742, 1, "1e93efbb393793c7a0cfd0601291ee5258024d0fc178f0d3f012928f8da372b9")
addappid(561743, 1, "8d7f11299b2fa74ecb95832c88f3ac9f463cd1cef5abd29364e86cf03aeae068")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
