-- Lua provided by RyzenAPI
-- Game: Super Pixel Racers

-- MAIN APPLICATION
addappid(501020)

-- MAIN APP DEPOTS / PACKAGES
addappid(501021, 1, "2e63e8355c75442bc419e6a45edc7ee095cc3e1ad28f52ccd8977895071e6d6a")
addappid(501022, 1, "518caf589eb3337a93c50c78a34064efc96ccbe97d35d128b2dcac9b2034a084")
