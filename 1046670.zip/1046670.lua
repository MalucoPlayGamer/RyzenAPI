-- Lua provided by RyzenAPI
-- Game: Game: Delirium VR

-- MAIN APPLICATION
addappid(1046670)
-- Game: addappid(1046670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1046671, 1, "cef5f638e997ebeb4c6ec1144c1838b6e914535661338748febfe2806e23e1e4")
