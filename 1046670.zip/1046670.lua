-- Lua provided by SkyAPI 
-- Game: Delirium VR
addappid(1046670)
addappid(1046671, 1, "cef5f638e997ebeb4c6ec1144c1838b6e914535661338748febfe2806e23e1e4")
