-- Lua provided by RyzenAPI
-- Game: Deathbound Artbook

-- MAIN APPLICATION
addappid(2990150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990150,0,"3a559dc657ad8e843911e132f4a9234541e2d68e95a15146873aeea5d72853f1")
