-- Lua provided by RyzenAPI
-- Game: Simple Trains Demo

-- MAIN APPLICATION
addappid(2271830)
-- Game: addappid(2271830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2271831, 1, "dd177d309946dd5a9138eaf73ac89a9fef18e64a9615436cf0afcb8e225d29d8")
