-- Lua provided by RyzenAPI
-- Game: Beat Saber - Stephen Walking – "Glide"

-- MAIN APPLICATION
addappid(1181771)

-- MAIN APP DEPOTS / PACKAGES
addappid(1181771,0,"e52725b124f2ad782ebe1aaf97bd154cac2f29e5e30eb7cff863ae03acd7cf0d")

