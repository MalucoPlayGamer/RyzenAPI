-- Lua provided by RyzenAPI
-- Game: Revenge of Black Bone

-- MAIN APPLICATION
addappid(2964810)
-- Game: addappid(2964810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2964811, 1, "7de6522a94b684593b8b98330520f6150ca760181ed4c748ff54fb6b084d4a3f")
