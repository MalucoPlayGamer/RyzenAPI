-- Lua provided by RyzenAPI
-- Game: Jellies of the Deep

-- MAIN APPLICATION
addappid(3020970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3020971, 1, "a7e9d32160b753358f0e7ef18d12d44685a61d2681b395989e3ce86b3384ebee")
addappid(3020972, 1, "468b7dadc685b90f4c7639120615cf8333f1b48c979fea969ddd235ef6b5979a")

