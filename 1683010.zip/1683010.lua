-- Lua provided by RyzenAPI
-- Game: Cat from the box

-- MAIN APPLICATION
addappid(1683010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1683011, 1, "78affc5ec42e93682e66a0da59e01daa24a91afd567e53de243e9e7b45c16d01")
