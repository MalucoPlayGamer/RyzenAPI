-- Lua provided by RyzenAPI
-- Game: Game: 100 RUB: Operation Global Denomination

-- MAIN APPLICATION
addappid(1383170)
-- Game: addappid(1383170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1383171, 1, "c92cbe1450242164c85919d661d6c97f477ee4091e681c11f8f914fe9b40807a")
