-- Lua provided by RyzenAPI
-- Game: Game: See No Evil

-- MAIN APPLICATION
addappid(313830)
-- Game: addappid(313830)

-- MAIN APP DEPOTS / PACKAGES
addappid(313831, 1, "12d15cc7f56a64f87e566fe0d3ae79e49f7c337ef84ec38874dacbe78c412d33")
addappid(320210, 0, "c0cc9a5568c3b82a4148300c290f26173c4b18e685545984c186c2f31b71ce5d")
