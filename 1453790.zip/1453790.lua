-- Lua provided by RyzenAPI
-- Game: The Serpent Rogue

-- MAIN APPLICATION
addappid(1453790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453791, 1, "e50f8591f16215ab7dbfc6506a8aec9d8efe46f87446145ea631f73ea2d7cfb6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
