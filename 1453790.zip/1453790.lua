-- Lua provided by RyzenAPI
-- Game: addappid(1453790)

-- MAIN APPLICATION
addappid(1453790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1453791, 1, "e50f8591f16215ab7dbfc6506a8aec9d8efe46f87446145ea631f73ea2d7cfb6")
