-- Lua provided by SkyAPI 
-- Game: AppID 3559020
addappid(3559020)
addappid(3559021, 1, "ab573358d72fa67737e3f77a7ef0dfd7f9e269666ed0cd774255f90466688b2c")
