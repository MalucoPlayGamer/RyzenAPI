-- Lua provided by RyzenAPI
-- Game: Smiling Girls

-- MAIN APPLICATION
addappid(2417150)
addappid(2454330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2417151, 1, "b6bc92b49049fae11c50c71c1dfe65a29abaa65bbffe99b86b9d84d2ca578977")
