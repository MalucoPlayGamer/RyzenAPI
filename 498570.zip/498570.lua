-- Lua provided by RyzenAPI
-- Game: Extreme Forklifting 2

-- MAIN APPLICATION
addappid(498570)
-- Game: addappid(498570)

-- MAIN APP DEPOTS / PACKAGES
addappid(498571, 1, "6a2542f1f6048c13835128302afdd0e245678dbe101cb9cd0abc3d7da09b388d")
