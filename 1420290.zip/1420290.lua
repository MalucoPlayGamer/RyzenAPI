-- Lua provided by RyzenAPI
-- Game: 1420290

-- MAIN APPLICATION
addappid(1420290)
-- Game: addappid(1420290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420291, 1, "bfc3283b5b6f065ea392265eb28b2f48510b24e67eed61b153699ea263c1fea3")
