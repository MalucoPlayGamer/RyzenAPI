-- Lua provided by RyzenAPI
-- Game: No More Heroes

-- MAIN APPLICATION
addappid(1420290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420291, 1, "bfc3283b5b6f065ea392265eb28b2f48510b24e67eed61b153699ea263c1fea3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
