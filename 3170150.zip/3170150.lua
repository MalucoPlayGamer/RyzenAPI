-- Lua provided by SkyAPI 
-- Game: AppID 3170150
addappid(3170150)
addappid(3170151, 1, "f11ba1d870046810351e8844823b674eb5524511fee9806778efbde590f21e4c")
