-- Lua provided by RyzenAPI
-- Game: Game: AppID 3170150

-- MAIN APPLICATION
addappid(3170150)
-- Game: addappid(3170150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3170151, 1, "f11ba1d870046810351e8844823b674eb5524511fee9806778efbde590f21e4c")
