-- Lua provided by RyzenAPI
-- Game: Mortal Royale

-- MAIN APPLICATION
addappid(922630)
addappid(925760)

-- MAIN APP DEPOTS / PACKAGES
addappid(922631, 1, "521a00d4872d1680ef17d4a9d2a003bbf215ab87bc488ba8ec58f7fa2c7e16db")
