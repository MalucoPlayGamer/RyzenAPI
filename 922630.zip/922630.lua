-- Lua provided by SkyAPI 
-- Game: Mortal Royale
addappid(922630)
addappid(922631, 1, "521a00d4872d1680ef17d4a9d2a003bbf215ab87bc488ba8ec58f7fa2c7e16db")
addappid(925760)
