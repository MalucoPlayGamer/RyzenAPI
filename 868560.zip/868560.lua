-- Lua provided by RyzenAPI 
-- Game: AppID 868560
addappid(868560)
addappid(868561, 1, "5c71cc2a7dbf302cdf359c3a1e3a72c90612b99f22030eb985423c6af974b245")
