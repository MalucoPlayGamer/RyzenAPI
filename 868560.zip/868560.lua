-- Lua provided by RyzenAPI
-- Game: Fly Killer VR

-- MAIN APPLICATION
addappid(868560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(868561, 1, "5c71cc2a7dbf302cdf359c3a1e3a72c90612b99f22030eb985423c6af974b245")

