-- Lua provided by RyzenAPI
-- Game: Tokyo Train 4

-- MAIN APPLICATION
addappid(3071720)
addappid(3071724)

-- MAIN APP DEPOTS / PACKAGES
addappid(3071723,0,"746539d6008386ca5f921d676ee0f65bd8c9c992da9f2ac6931a6fa238717927")

