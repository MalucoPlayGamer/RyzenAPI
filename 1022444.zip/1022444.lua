-- Lua provided by RyzenAPI
-- Game: addappid(1022444)

-- MAIN APPLICATION
addappid(1022444)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022444,0,"90285e9c51620e725bfcec04ec5c6d255a03fad59256add66f97945be8f23df2")
