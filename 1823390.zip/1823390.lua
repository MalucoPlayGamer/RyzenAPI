-- Lua provided by RyzenAPI
-- Game: Game: Escape The Mad Empire

-- MAIN APPLICATION
addappid(1823390)
-- Game: addappid(1823390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1823391, 1, "6cceff9a646118a25d6e9023cc93f2cecae14a35a80f5d19fe708a187e2f14dc")
