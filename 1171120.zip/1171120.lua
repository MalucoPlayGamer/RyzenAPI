-- Lua provided by RyzenAPI 
-- Game: Nira
addappid(1171120)
addappid(1171121, 1, "91a0f1f07837e8161179f4dc88a8f1e9fb9fc65154a41e663e4f0a71121056fa")
