-- Lua provided by RyzenAPI
-- Game: 3485400

-- MAIN APPLICATION
addappid(3485400)
-- Game: addappid(3485400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3485401, 1, "f17852d22bd2d922bc8bd2309f7fa35dd511820f49d30d80a8187169fc92e815")
