-- Lua provided by RyzenAPI
-- Game: Carnage

-- MAIN APPLICATION
addappid(1340410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340411, 1, "0234b0bb0c8dc9cb6fb14655d6ce7bdbbaa8e27de100e476c48cb2552076f770")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
