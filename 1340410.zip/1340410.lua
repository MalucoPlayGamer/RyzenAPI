-- Lua provided by RyzenAPI
-- Game: addappid(1340410)

-- MAIN APPLICATION
addappid(1340410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1340411, 1, "0234b0bb0c8dc9cb6fb14655d6ce7bdbbaa8e27de100e476c48cb2552076f770")
