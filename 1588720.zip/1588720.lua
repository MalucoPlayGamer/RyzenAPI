-- Lua provided by RyzenAPI
-- Game: Ion Fury: Aftershock

-- MAIN APPLICATION
addappid(1588720)
-- Game: addappid(1588720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588721, 1, "d0a285f9d68a8ed26233afc3a260c75ed08c04a0993146492bb7c3e26b9f5e2e")
addappid(1588722, 1, "6238a01b71ab9a55d97acc7a9470e70b37e07dfbf8aa102d63d4820936f30b2b")
