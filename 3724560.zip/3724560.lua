-- Lua provided by RyzenAPI
-- Game: Game: Ornate Machina: The Thousand Trials

-- MAIN APPLICATION
addappid(3724560)
-- Game: addappid(3724560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3724561, 1, "d860c08191b248cbe35feb4b4b5bd343764979e397ac2b99dc652296484d5ef3")
