-- Lua provided by RyzenAPI
-- Game: Epic Conquest 2

-- MAIN APPLICATION
addappid(1235360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1235361, 1, "bc26400388acb229046bdd1eb3db918288e5bc2fb5209375a00b031a9bfa7984")
