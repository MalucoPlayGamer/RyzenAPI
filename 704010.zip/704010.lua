-- Lua provided by RyzenAPI
-- Game: LongStory

-- MAIN APPLICATION
addappid(704010)

-- MAIN APP DEPOTS / PACKAGES
addappid(704011,0,"f674dbb92db0c79b6d31394f2932489de8b1fd3c2420c389595a704a8aef2b3a")

