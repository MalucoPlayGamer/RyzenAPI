-- Lua provided by RyzenAPI
-- Game: The Fifth Expedition

-- MAIN APPLICATION
addappid(453030)
-- Game: addappid(453030)

-- MAIN APP DEPOTS / PACKAGES
addappid(453031, 1, "2cea03cfe553ec40192bdfb903e257a13242b8147f5d08e6d89431cfab3c0e95")
addappid(453032, 1, "5dcd2f0d7052aa010a2cceac19d364ff5705d3a290a0f6085db8c03ff14f883c")
