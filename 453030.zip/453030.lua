-- Lua provided by RyzenAPI
-- Game: The Fifth Expedition

-- MAIN APPLICATION
addappid(453030)

-- MAIN APP DEPOTS / PACKAGES
addappid(453031, 1, "2cea03cfe553ec40192bdfb903e257a13242b8147f5d08e6d89431cfab3c0e95")
addappid(453032, 1, "5dcd2f0d7052aa010a2cceac19d364ff5705d3a290a0f6085db8c03ff14f883c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
