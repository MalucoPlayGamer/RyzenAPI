-- Lua provided by SkyAPI 
-- Game: Dream of the Star Haven
addappid(2696080)
addappid(2696081, 1, "dbc9a6ec9a5c2a62a5dc8a412d0229f097fa66939f0838eeaba08984eeacdb0e")
addappid(2696082, 1, "b8f5bb163795a360e36adf9bda6d388b6faf9cd7c9c08dbeff408b4325e75bd5")
addappid(2696083, 1, "5fc3a11f0a47fc1ba4507247a30e9f377845631217d84c5949b61e21e19d090c")
