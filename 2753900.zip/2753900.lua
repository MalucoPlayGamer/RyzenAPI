-- Lua provided by RyzenAPI
-- Game: The King is Watching

-- MAIN APPLICATION
addappid(2753900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2753901, 1, "416d49c23e9d45fbd519129ae945ff52e8e57b2e8a0170688a8623c6ca0d3941")

