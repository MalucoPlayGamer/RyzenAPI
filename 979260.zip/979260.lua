-- Lua provided by RyzenAPI
-- Game: Gizmo

-- MAIN APPLICATION
addappid(979260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(979261, 1, "43065c3c4f60ec64a6c343423ea4a3b3459a4967828696e6f65b89edfab92eff")

