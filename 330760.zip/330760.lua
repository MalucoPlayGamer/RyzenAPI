-- Lua provided by RyzenAPI
-- Game: Running Shadow

-- MAIN APPLICATION
addappid(330760)
addappid(351670)
addappid(351671)
addappid(351672)
addappid(351673)
addappid(351674)
addappid(351675)
addappid(351676)

-- MAIN APP DEPOTS / PACKAGES
addappid(330761, 1, "384cf57ab0a2d1f423b604657dd65712f42d725d36b5e2cc7902dc9d13c2838b")
