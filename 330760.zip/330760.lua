-- Lua provided by RyzenAPI
-- Game: addappid(330760)

-- MAIN APPLICATION
addappid(330760)

-- MAIN APP DEPOTS / PACKAGES
addappid(330761, 1, "384cf57ab0a2d1f423b604657dd65712f42d725d36b5e2cc7902dc9d13c2838b")
