-- Lua provided by RyzenAPI
-- Game: 1133990

-- MAIN APPLICATION
addappid(1133990)
-- Game: addappid(1133990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1133991, 1, "7bc97635433195c6bd8f79e077bdbf2697de3c506ede75f76ca46df285397721")
