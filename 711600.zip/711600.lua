-- Lua provided by RyzenAPI 
-- Game: Dragon Orb
addappid(711600)
addappid(711601, 1, "0a2956a102ae80010c8f13519848a9d6f5806768c3b03bc008bc190f9cf2aef8")
