-- Lua provided by RyzenAPI
-- Game: addappid(711600)

-- MAIN APPLICATION
addappid(711600)

-- MAIN APP DEPOTS / PACKAGES
addappid(711601, 1, "0a2956a102ae80010c8f13519848a9d6f5806768c3b03bc008bc190f9cf2aef8")
