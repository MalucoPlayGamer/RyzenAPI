-- Lua provided by RyzenAPI
-- Game: Game: Peregrine

-- MAIN APPLICATION
addappid(2129540)
-- Game: addappid(2129540)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129541, 1, "421d990c26429a42af59d11c987206df2e91fe3a1a02da7b2307944751261314")
