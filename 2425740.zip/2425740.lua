-- Lua provided by RyzenAPI
-- Game: The Three Kingdoms Era in China 2000 years ago

-- MAIN APPLICATION
addappid(2425740)
addappid(5076890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2425741, 1, "6372a4a1b220d5a4af1d683fe2042ca001a838598fcece05b19114db0b61f6c6")
addappid(2425744, 1, "577da54c65cb44af794fb856a9176451c0fc4df634358fa076d3f3ab812b98af")
addappid(3044860, 0, "0f7ac5f39df71ec533061301d054f52848b24a2335966888e6238cf8dc3bffa1")
addappid(3044861, 1, "572801db13de709a16902149085f7fdb2fe88108a44d468fcad22d71a582d135")

