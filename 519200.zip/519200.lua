-- Lua provided by SkyAPI 
-- Game: Kitty Kitty Boing Boing: the Happy Adventure in Puzzle Garden!
addappid(519200)
addappid(519201, 1, "7a85c71544fe5d43ae833d3ab55eda5abe441034aafe9d20a50df69df57f87e4")
addappid(519203, 1, "18e2619da0fd6021ab42a987bd5d763d142f7fd210d2dd2c64d8f77693461486")
addappid(519204, 1, "34972db4d90beb34cbffad1e7aeb46f9fd3b7b398415fda6ce1b4cada4318bdc")
addappid(519205, 1, "2a990ea3a63626b16bd8e8845b114bf4e6804cb77608be9196a0fcabffc9cdb4")
