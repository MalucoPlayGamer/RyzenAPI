-- Lua provided by RyzenAPI
-- Game: 1812881

-- MAIN APPLICATION
addappid(1812881)
-- Game: addappid(1812881)

-- MAIN APP DEPOTS / PACKAGES
addappid(1812881,0,"4a2473561aea1b25663cba2ac1f4b50f20a2362aec2e392ef610447b0cb2598d")
