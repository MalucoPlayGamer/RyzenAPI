-- Lua provided by SkyAPI 
-- Game: AppID 1340480
addappid(1340480)
addappid(1340481, 1, "af417500e103392bdb3c37b9e1d1fd8de7afed8ac420e242154db4c965d0dbda")
addappid(2554900, 0, "f02b1f25909e279a9dd7528c0381c412c19219de212b14090be75e9d0d015274")
