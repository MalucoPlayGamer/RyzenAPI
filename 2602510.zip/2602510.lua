-- Lua provided by SkyAPI 
-- Game: AppID 2602510
addappid(2602510)
addappid(2602511, 1, "97698f8316ee01ae22f7dd81f24a65acdd4f4c2820d1f96ba0d7b04f70f6275c")
