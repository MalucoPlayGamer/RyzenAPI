-- Lua provided by RyzenAPI
-- Game: Truco

-- MAIN APPLICATION
addappid(1808980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(1808981, 1, "697296bb66312f9e140582d5b3596428b84de694a14ba37cd0aaf02428eb167e")

