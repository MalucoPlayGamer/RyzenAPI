-- Lua provided by SkyAPI 
-- Game: Truco
addappid(1808980)
addappid(1808981, 1, "697296bb66312f9e140582d5b3596428b84de694a14ba37cd0aaf02428eb167e")
