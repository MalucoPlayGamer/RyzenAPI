-- Lua provided by RyzenAPI
-- Game: SANABI Soundtrack

-- MAIN APPLICATION
addappid(2610780)
-- Game: addappid(2610780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2610780,0,"d950b7540514938c8fee116d2d97880cdd61dbfe4f6adff20e1fefbec8c96487")
addappid(2610790,0,"7d3a2d467bcfc09536994f8b25252bca1b6b29994f615e5159194ddd0b469083")
