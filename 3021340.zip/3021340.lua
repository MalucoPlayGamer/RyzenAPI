-- Lua provided by RyzenAPI
-- Game: 3021340

-- MAIN APPLICATION
addappid(3021340)
-- Game: addappid(3021340)

-- MAIN APP DEPOTS / PACKAGES
addappid(3021341, 1, "2c3d36b8b829b5aa86e589c0a35689604ad7c40f00b28ce08ee685e930b7a7d6")
