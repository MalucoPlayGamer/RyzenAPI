-- Lua provided by RyzenAPI
-- Game: pedalverse Demo

-- MAIN APPLICATION
addappid(3192060)

-- MAIN APP DEPOTS / PACKAGES
addappid(3192061, 1, "ca4444468787bb3722c1368a6e0bba23650aff775aa4f7710c092547c3551c5c")
