-- Lua provided by SkyAPI 
-- Game: SpartrackVR-FirosDemo Demo
addappid(1244750)
addappid(1244751, 1, "691fcea6eca91a565933a20c07e7c5a3889da1e8893f6a65086342928bea06ad")
