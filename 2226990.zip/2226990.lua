-- Lua provided by RyzenAPI 
-- Game: AppID 2226990
addappid(2226990)
addappid(2226991, 1, "98767ae1bc272e5c02bcac0c2bd5ea7f740105b195f2a32de84cb202e880a9a3")
