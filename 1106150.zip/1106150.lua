-- Lua provided by RyzenAPI
-- Game: 1106150

-- MAIN APPLICATION
addappid(1106150)
-- Game: addappid(1106150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1106151, 1, "47e8309ce477aba64e90e41a0b701a46b1cd39a9c7bd47ede5f72a00966f17b9")
