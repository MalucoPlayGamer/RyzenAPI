-- Lua provided by RyzenAPI
-- Game: You Must be 18 or Older to Enter

-- MAIN APPLICATION
addappid(608510)

-- MAIN APP DEPOTS / PACKAGES
addappid(608511, 1, "d5d51298e2896659132cfc03abacf8c3f2d60b623ca9f11004980f60527a9d5b")

