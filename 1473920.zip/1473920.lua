-- Lua provided by RyzenAPI
-- Game: Game: Hentai it's my life

-- MAIN APPLICATION
addappid(1473920)
-- Game: addappid(1473920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1473921, 1, "dc4b940cefa78a0ab4343562804174bf6436124f8d64400dbf4561373bc23ea1")
