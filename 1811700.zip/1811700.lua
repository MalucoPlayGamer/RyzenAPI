-- Lua provided by RyzenAPI
-- Game: addappid(1811700)

-- MAIN APPLICATION
addappid(1811700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1811701, 1, "aba12cb5406fe7ed01a188233cc6cc7a17d2b489ff1113b15384039a1038c84e")
