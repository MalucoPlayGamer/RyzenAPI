-- Lua provided by RyzenAPI
-- Game: Little Devil

-- MAIN APPLICATION
addappid(2191180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2191181, 1, "7604bd66d16d42b131cc516597efb136e6e92223ba8dd8003dcfada6cdea22bf")

