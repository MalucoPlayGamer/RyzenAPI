-- Lua provided by RyzenAPI
-- Game: NightFeed

-- MAIN APPLICATION
addappid(2718150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2718152,0,"55632d18af9215ac19efaf1b8bd1c7f56560c4998929407c3f199eee726f9965")

