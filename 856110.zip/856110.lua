-- Lua provided by RyzenAPI
-- Game: Game: AppID 856110

-- MAIN APPLICATION
addappid(856110)
-- Game: addappid(856110)

-- MAIN APP DEPOTS / PACKAGES
addappid(856111, 1, "d29ed3edf81e415b43a702fedb9045ceea34de4f2f3416dbe2bcb780afc95fad")
