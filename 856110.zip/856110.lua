-- Lua provided by RyzenAPI
-- Game: Antisnake

-- MAIN APPLICATION
addappid(856110)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(856111, 1, "d29ed3edf81e415b43a702fedb9045ceea34de4f2f3416dbe2bcb780afc95fad")

