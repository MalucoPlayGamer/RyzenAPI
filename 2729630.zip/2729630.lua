-- Lua provided by RyzenAPI
-- Game: Boti: Byteland Overclocked - Artbook

-- MAIN APPLICATION
addappid(2729630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2729630,0,"5a9aa80c7e288ada0ac563635159723e7182356375141af0faeb87e0074e46c2")
