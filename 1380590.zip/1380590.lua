-- Lua provided by RyzenAPI
-- Game: Love Tavern: Brothel Uncensored (18+)

-- MAIN APPLICATION
addappid(1380590)
-- Game: addappid(1380590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1380590,0,"7a23543921f369994c6221bb8df79e5cf25339615688c8c3a2e26f7392cdc2a1")
