-- Lua provided by RyzenAPI
-- Game: addappid(3528290)

-- MAIN APPLICATION
addappid(3528290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3528290,0,"1286f15d1b0ff1f689ed8e0d6e5941fa2f5f3176adbd98c83421b4add7795ae8")
