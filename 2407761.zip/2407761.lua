-- Lua provided by RyzenAPI
-- Game: Beat Saber - Queen - Bohemian Rhapsody

-- MAIN APPLICATION
addappid(2407761)

-- MAIN APP DEPOTS / PACKAGES
addappid(2407761,0,"ca69919a11b7c2ba1701d907afeaac9af1363e0e805e3f970e1c792d8be7a29d")

