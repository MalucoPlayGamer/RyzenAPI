-- Lua provided by RyzenAPI
-- Game: Bloons Card Storm

-- MAIN APPLICATION
addappid(2876550)
-- Game: addappid(2876550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2876551, 1, "7cf0a60ce56e6ecb737f6b56521db63d4b96beefe8272bf52170647f7eaf42fb")
addappid(2876553, 1, "194b98d4fc2898659436c72e3118e2b22416ea351f646f2c156c2cf937ad6e43")
