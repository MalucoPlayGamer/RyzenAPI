-- Lua provided by RyzenAPI
-- Game: The Guilt and the Shadow

-- MAIN APPLICATION
addappid(332630)

-- MAIN APP DEPOTS / PACKAGES
addappid(332631, 1, "1599596d949d0930608d4a896093c166bcc8c22afab42b49ce9ccfb304a028e0")
