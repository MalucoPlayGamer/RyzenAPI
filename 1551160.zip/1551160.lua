-- Lua provided by RyzenAPI
-- Game: Combat Mission Cold War

-- MAIN APPLICATION
addappid(1551160)
addappid(4002040)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1551161, 1, "3a433d6d4c4dd937b31e5fbf2f4d1467113ececed0c4a129dbd8bb1167dc89d2")
addappid(1551162, 1, "8c605079c0262c72ef01f864cad1b9ce00aaf1b51b245bc73d4ad1d17be8e9c9")

