-- Lua provided by RyzenAPI
-- Game: 3245380

-- MAIN APPLICATION
addappid(3245380)
-- Game: addappid(3245380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3245381, 1, "9817d6be6da4067bc2fc7c381300c218d2a27cd83cf70e2736eee9f55c26ce32")
