-- Lua provided by RyzenAPI
-- Game: Mobile Zombie

-- MAIN APPLICATION
addappid(694180)

-- MAIN APP DEPOTS / PACKAGES
addappid(694181, 1, "370f36935401cfcd993b30903545d7d9806e3c1ed7ae1ffae128abf0533c211e")

