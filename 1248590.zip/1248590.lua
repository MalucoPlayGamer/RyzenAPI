-- Lua provided by RyzenAPI
-- Game: A Squire's Tale

-- MAIN APPLICATION
addappid(1248590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1248591, 1, "643263bbd1231ceafe42453b79a016f50a2651581eee412b1c03f8cb99490816")
