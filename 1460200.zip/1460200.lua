-- Lua provided by RyzenAPI
-- Game: addappid(1460200)

-- MAIN APPLICATION
addappid(1460200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460201, 1, "f42b428b3b4df5a8728020eee265e1cb96d3ae3f4c9d440fb18ec407d4988a83")
