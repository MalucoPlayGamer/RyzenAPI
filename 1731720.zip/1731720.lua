-- Lua provided by RyzenAPI
-- Game: addappid(1731720)

-- MAIN APPLICATION
addappid(1731720)
addappid(1812350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1731721, 1, "6c540d3edaea8a817fe965c6ff78635f228960c8a131c8561ed28f71e6dde6ba")
