-- Lua provided by RyzenAPI 
-- Game: Imp of the Sun Soundtrack
addappid(1924190)
addappid(1924191, 1, "2d8f33064e0bf32d12bd1307f11516c3a17f27f720ffe7206ddc28b557c670b9")
addappid(1924192, 1, "e910bd9e844c3725bfd0304fd9f14d694be99a294145979513877f3dbeec8442")
