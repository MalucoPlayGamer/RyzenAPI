-- Lua provided by RyzenAPI 
-- Game: Death's Door Soundtrack
addappid(1528460)
addappid(1528461, 1, "53edddffb875ec37ae2d0f02bbbc37bc22c04c6e1b94dfd2c181f660b4da5f2f")
addappid(1528462, 1, "92f3f141e459c0a62ae3c4a537f8b7d66d2059f2e8b81bbe2fe94cbab4e0c31e")
