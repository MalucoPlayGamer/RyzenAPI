-- Lua provided by RyzenAPI
-- Game: Airport Madness: Time Machine

-- MAIN APPLICATION
addappid(402210)

-- MAIN APP DEPOTS / PACKAGES
addappid(402211, 1, "45305ddd725ffbc63d5bb6ecddae9ed9f5f440e0db40feb24f625f690c416af1")
addappid(402212, 1, "697471faad6d590c73fcc0e512aa03c2252ada6aa61a7cbeca15dc1aee716729")
