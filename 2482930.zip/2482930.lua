-- Lua provided by RyzenAPI
-- Game: Game: AppID 2482930

-- MAIN APPLICATION
addappid(2482930)
-- Game: addappid(2482930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2482931, 1, "e4e8efee9e45c3fcee5ddf4e20288fad08fc0627c10cd02b9d3989569c49e004")
