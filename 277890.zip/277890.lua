-- Lua provided by RyzenAPI 
-- Game: AppID 277890
addappid(277890)
addappid(277891, 1, "f56535019fa760136b220264755718f59a08c16d7f4510e48c1e62ac5b440c11")
