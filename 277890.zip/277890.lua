-- Lua provided by RyzenAPI
-- Game: Shantae: Risky's Revenge - Director's Cut

-- MAIN APPLICATION
addappid(277890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(277891, 1, "f56535019fa760136b220264755718f59a08c16d7f4510e48c1e62ac5b440c11")
