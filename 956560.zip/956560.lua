-- Lua provided by RyzenAPI
-- Game: StarCrossed

-- MAIN APPLICATION
addappid(956560)
addappid(1313850)

-- MAIN APP DEPOTS / PACKAGES
addappid(956561, 1, "511447f60c388fef0823a55236b999b15af5c005c7cad2807eea321ea0ba9d8d")
addappid(956562, 1, "140b9a0e1c62d5bde9c5102a5a47cabf3558dbd59aa9a0a3fc1e5715547bbd8d")
addappid(956563, 1, "3721efc2fdd0209da959eb00387df987f38217961ea68b710d50c7328c813701")
