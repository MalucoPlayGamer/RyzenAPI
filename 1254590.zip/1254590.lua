-- Lua provided by RyzenAPI
-- Game: Choco Pixel 3

-- MAIN APPLICATION
addappid(1254590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1254591, 1, "8eb2215ab0a73c62a7c37e294cc23ac45003a677a617db127fc1845fad315994")
