-- Lua provided by RyzenAPI 
-- Game: Choco Pixel 3
addappid(1254590)
addappid(1254591, 1, "8eb2215ab0a73c62a7c37e294cc23ac45003a677a617db127fc1845fad315994")
