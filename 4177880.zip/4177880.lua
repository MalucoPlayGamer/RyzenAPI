-- Lua provided by RyzenAPI
-- Game: Wizard Pool

-- MAIN APPLICATION
addappid(4177880)

-- MAIN APP DEPOTS / PACKAGES
addappid(4177881,0,"7e170e9a743ea3c213b98852092d078efc4c49c6b749477bb36ec496238b604c")

