-- Lua provided by RyzenAPI
-- Game: Game: AppID 484350

-- MAIN APPLICATION
addappid(484350)
addappid(652820)
-- Game: addappid(484350)

-- MAIN APP DEPOTS / PACKAGES
addappid(484351, 1, "05f327baca7b1e0a0304015dbfdefef677847c77a388f9a962fb99aecd65d04a")
