-- Lua provided by RyzenAPI
-- Game: Die With Glory

-- MAIN APPLICATION
addappid(551050)

-- MAIN APP DEPOTS / PACKAGES
addappid(551051,0,"cc6f8a35b12692ef850ecf52075b6d538ee72a1369c634a9c8e9cec4a3261d20")
addappid(551052,0,"d6f2a576df3fd67e2642992708faf47e17dbc37acb2798e541e2046f9bf3f72a")
addappid(803340,0,"0da1c180b7f08eed8e4217e13be1f8437b46ff0ee2d450d9b66ffd47599d3983")

