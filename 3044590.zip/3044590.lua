-- Lua provided by RyzenAPI
-- Game: Ale & Tale Tavern Demo

-- MAIN APPLICATION
addappid(3044590)
-- Game: addappid(3044590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3044591, 1, "a1a222ff75544ba547eabe8305dacc78c30be1914679ce6dd5eefa80ed7c6071")
