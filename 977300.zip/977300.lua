-- Lua provided by RyzenAPI
-- Game: Fenimore Fillmore: 3 Skulls of the Toltecs

-- MAIN APPLICATION
addappid(977300)

-- MAIN APP DEPOTS / PACKAGES
addappid(977301, 1, "9bc0198d66e5365f2e8e8a12c5eddaa7c92d2a5655c84dbc8c92fe8dcd094c9a")
