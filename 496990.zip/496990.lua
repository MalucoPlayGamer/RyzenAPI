-- Lua provided by RyzenAPI
-- Game: Ghost Sweeper

-- MAIN APPLICATION
addappid(496990)

-- MAIN APP DEPOTS / PACKAGES
addappid(496991, 1, "dad8aeb267879b72b6c0c2cb2ee330cb3d8d062d516fd8b8a8826c90ed1d775e")

