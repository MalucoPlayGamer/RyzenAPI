-- Lua provided by SkyAPI 
-- Game: AppID 1140410
addappid(1140410)
addappid(1140411, 1, "e53566a0b1566a3b39e8170bfedcb697ca00e5b59c024479f9acba223beb74e7")
