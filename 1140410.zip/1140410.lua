-- Lua provided by RyzenAPI
-- Game: AppID 1140410

-- MAIN APPLICATION
addappid(1140410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140411, 1, "e53566a0b1566a3b39e8170bfedcb697ca00e5b59c024479f9acba223beb74e7")

