-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - RPG HERO Team Pack

-- MAIN APPLICATION
addappid(2803750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2803750,0,"7fe484ad395274a50178b183cbccc667c1e7e1e9c36b92ce2013f1ab2f13f65d")

