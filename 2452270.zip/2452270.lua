-- Lua provided by RyzenAPI
-- Game: 2452270

-- MAIN APPLICATION
addappid(2452270)
-- Game: addappid(2452270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2452270,0,"de98419d69bd6fcb0603958d0ed38592693a6277bc986be886c3beb5ed63db20")
