-- Lua provided by RyzenAPI
-- Game: Dude, Stop

-- MAIN APPLICATION
addappid(574560)

-- MAIN APP DEPOTS / PACKAGES
addappid(574561, 1, "e42a4b9fd1ef57cb925f7943f83e2f9e339649558ce9263ea1a4a4224acbc928")

