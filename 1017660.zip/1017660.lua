-- Lua provided by RyzenAPI
-- Game: Don't Go into the Woods

-- MAIN APPLICATION
addappid(1017660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1017661, 1, "acc666455e05d153be4f458270f14770440f4a2e65c365310b16592755656423")

