-- Lua provided by RyzenAPI 
-- Game: AppID 1017660
addappid(1017660)
addappid(1017661, 1, "acc666455e05d153be4f458270f14770440f4a2e65c365310b16592755656423")
