-- Lua provided by RyzenAPI
-- Game: Tiny Troopers: Joint Ops XL

-- MAIN APPLICATION
addappid(2225750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225751, 1, "614ce5d949098da5664a2d7d7f500d5f8ffc17ecefa551cc869f6e648eb35f7c")
