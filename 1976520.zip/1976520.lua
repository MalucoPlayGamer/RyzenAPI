-- Lua provided by RyzenAPI
-- Game: A100

-- MAIN APPLICATION
addappid(1976520)
addappid(1980190)
addappid(1980191)
addappid(1980192)
addappid(1980193)
addappid(1980194)
addappid(2011490)
addappid(2011491)
addappid(2011492)
addappid(2011493)
addappid(2011494)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976521, 1, "3c55399b8bbdf620438f07adaa701bd91e2101087e248ba77dce6ad211cd4674")

