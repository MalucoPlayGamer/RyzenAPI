-- Lua provided by RyzenAPI
-- Game: Game: A100

-- MAIN APPLICATION
addappid(1976520)
-- Game: addappid(1976520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1976521, 1, "3c55399b8bbdf620438f07adaa701bd91e2101087e248ba77dce6ad211cd4674")
