-- Lua provided by SkyAPI 
-- Game: A100
addappid(1976520)
addappid(1976521, 1, "3c55399b8bbdf620438f07adaa701bd91e2101087e248ba77dce6ad211cd4674")
