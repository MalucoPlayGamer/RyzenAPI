-- Lua provided by RyzenAPI
-- Game: Game: IRON GUARD Soundtrack

-- MAIN APPLICATION
addappid(1747420)
-- Game: addappid(1747420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747421, 1, "6fbc35e708d04746cef3f37971636a57502a2c50cdf60ff3139d58ff342b0954")
