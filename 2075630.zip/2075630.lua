-- Lua provided by RyzenAPI
-- Game: Game: Enelia: Dawn of Madness

-- MAIN APPLICATION
addappid(2075630)
-- Game: addappid(2075630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2075631, 1, "6ed945a20d44695fce40b43836d839a0435b992711e7ab811d55b8c394930f9d")
