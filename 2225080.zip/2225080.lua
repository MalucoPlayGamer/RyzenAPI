-- Lua provided by RyzenAPI
-- Game: Jump Dash Soar

-- MAIN APPLICATION
addappid(2225080)
-- Game: addappid(2225080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2225081, 1, "2bb0f45b3b5aecdc985288f2dd6bca94efa8ee75d935849342abad8f2b9c1cd4")
