-- Lua provided by RyzenAPI
-- Game: AppID 385600

-- MAIN APPLICATION
addappid(385600)
-- Game: addappid(385600)

-- MAIN APP DEPOTS / PACKAGES
addappid(385601, 1, "80d91e0a03eddf26884685da7d29e1824eb1e48cd35ccc499a42e55dc24ec8a6")
