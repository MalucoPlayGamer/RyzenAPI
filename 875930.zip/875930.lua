-- Lua provided by RyzenAPI
-- Game: Rehtona

-- MAIN APPLICATION
addappid(875930)

-- MAIN APP DEPOTS / PACKAGES
addappid(875931, 1, "9043c6fa3b7e19288e270092c651be2dbe68bde67d6fee3b621d372728ed12ed")
addappid(875932, 1, "f65884e624f96742a77b6e9d08b77378d4d2b0a484310adcd74e4a0fb117839c")
