-- Lua provided by RyzenAPI
-- Game: addappid(464780)

-- MAIN APPLICATION
addappid(464780)

-- MAIN APP DEPOTS / PACKAGES
addappid(464784,0,"5750dc24df07462762de8c3138de996fda233cc1bc9368181330eb3c53b767c6")
