-- Lua provided by RyzenAPI
-- Game: Gladiator School

-- MAIN APPLICATION
addappid(556860)

-- MAIN APP DEPOTS / PACKAGES
addappid(556861, 1, "229d0101d750fa966640f45e3caf0d28968c77e464dc937d5311b2b2d2d8aaae")
