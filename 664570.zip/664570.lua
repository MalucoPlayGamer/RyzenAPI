-- Lua provided by RyzenAPI
-- Game: My Personal Angel

-- MAIN APPLICATION
addappid(664570)
-- Game: addappid(664570)

-- MAIN APP DEPOTS / PACKAGES
addappid(664571, 1, "e980291f100eef27f879bbdc823a7c4f7b64b4b5c0f9bb5450553b4981e80688")
