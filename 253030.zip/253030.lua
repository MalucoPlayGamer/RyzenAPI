-- Lua provided by RyzenAPI
-- Game: Game: Race The Sun

-- MAIN APPLICATION
addappid(253030)
-- Game: addappid(253030)

-- MAIN APP DEPOTS / PACKAGES
addappid(253031, 1, "0a850868867e887a855c2a2130112853214138c933252296e885049be1e6e892")
addappid(253032, 1, "7ea1b08d3a97976c1dfaba1ed1ffd6eefefef651958e3a9ae704e3859e627868")
addappid(253033, 1, "f39f949c08696cbdfa22ecbb5b6913ea82dc1341259931ef3346a6ccceeea239")
addappid(378730, 0, "2dcad09fbf379a14a93c2a7652cfe6fc81f6975e93244e6fe9fdffcb6a130ba2")
addappid(378731, 0, "961597938bb3b38fc08573e751fa76f5ae87635cae214e7dcf18776e49cae3fb")
