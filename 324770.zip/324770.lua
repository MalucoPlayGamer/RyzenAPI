-- Lua provided by RyzenAPI
-- Game: eXperience 112

-- MAIN APPLICATION
addappid(324770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(324771, 1, "49e0ba3028ef76fcb337d41a2a6672471213b4b7602c6fa243f4421037be954d")
addappid(324772, 1, "de4a0fb1228e9207d81105b8c60409f0936772259d32db306db9c730f23858a6")
addappid(324773, 1, "f9bdf38284e628f2d5c7d0efcde93b7e8fd041533521aadf4a9c1c33e5e587dd")
addappid(324774, 1, "37fd163b9f1470bdbb359c9fe01b77dbee94db458d667695e3dfb5a1f2a5820b")

