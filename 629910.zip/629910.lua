-- Lua provided by RyzenAPI
-- Game: Clicker Heroes 2

-- MAIN APPLICATION
addappid(629910)
addappid(882270)

-- MAIN APP DEPOTS / PACKAGES
addappid(629911, 1, "e28eb34f288321fb8ba6954d7ecd869ecc7b8e43a8f42d92822a5edde5020790")

