-- Lua provided by RyzenAPI 
-- Game: AppID 629910
addappid(629910)
addappid(629911, 1, "e28eb34f288321fb8ba6954d7ecd869ecc7b8e43a8f42d92822a5edde5020790")
addappid(882270)
