-- Lua provided by RyzenAPI
-- Game: addappid(985720)

-- MAIN APPLICATION
addappid(985720)

-- MAIN APP DEPOTS / PACKAGES
addappid(985721, 1, "a9a62cf8347f72b0c8b8681b5fa313995f617817388eeac4257278b1d2412d8b")
