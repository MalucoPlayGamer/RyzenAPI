-- Lua provided by RyzenAPI
-- Game: Lagoon Lounge : The Poisonous Fountain

-- MAIN APPLICATION
addappid(857690)

-- MAIN APP DEPOTS / PACKAGES
addappid(857691, 1, "eae2e22a2695b6b4f5960e8bc92405df36744dd97a56de12a908f0c5333a587c")
