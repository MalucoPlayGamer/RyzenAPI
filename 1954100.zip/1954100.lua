-- Lua provided by RyzenAPI
-- Game: addappid(1954100)

-- MAIN APPLICATION
addappid(1954100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1954101, 1, "3a59c30869bbdfa11b17b668b96a412474823573af647ab629da94ca8b5e614c")
