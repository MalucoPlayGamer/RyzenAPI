-- Lua provided by RyzenAPI
-- Game: Bonnie's Bakery

-- MAIN APPLICATION
addappid(2417580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2417581, 1, "ada8dc67dab1d456d56edd40ff04c6ab2af6ae102d99fd7fb2abba9cad2cc7f1")
addappid(2417582, 1, "5bbd387148abb621420848a172a92f3dac6bb69b81dc56fcb22dc1e14a0bea7e")

