-- Lua provided by RyzenAPI
-- Game: The Dream Of A Cockspur Demo

-- MAIN APPLICATION
addappid(2765190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2765191, 1, "721013fea7b7a29071793461b278a426e0b99cd77dbedf59189e7d1babaa820e")
