-- Lua provided by RyzenAPI
-- Game: Radiance of Souls

-- MAIN APPLICATION
addappid(4361240)

-- MAIN APP DEPOTS / PACKAGES
addappid(4361241,0,"aa8d7e8b233876d1e1bf66057049ec1e1edb7917487be462188b8699c6b356d5")

