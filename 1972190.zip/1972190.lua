-- Lua provided by RyzenAPI
-- Game: Animal Trail ☆ Girlish Square

-- MAIN APPLICATION
addappid(1972190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1972191, 1, "c34934920e94f65c7157493d44f4a3bbe97e7c8b00fab8a1b0b9a1adccafea21")

