-- Lua provided by RyzenAPI
-- Game: Brick Battalion

-- MAIN APPLICATION
addappid(496850)

-- MAIN APP DEPOTS / PACKAGES
addappid(496851, 1, "39a04f777d1782201e0889cff73ef3f90adb1c687097b4a87fd614019aff7d1b")
