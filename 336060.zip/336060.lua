-- Lua provided by RyzenAPI
-- Game: Raptor: Call of The Shadows - 2015 Edition

-- MAIN APPLICATION
addappid(336060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(336061, 1, "1cd4d39fda66c2aad61218e6b59582266387da6476a850644536baa098f4ded9")
