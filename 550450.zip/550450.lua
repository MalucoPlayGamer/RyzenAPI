-- Lua provided by RyzenAPI
-- Game: addappid(550450)

-- MAIN APPLICATION
addappid(550450)

-- MAIN APP DEPOTS / PACKAGES
addappid(550451, 1, "ddd171bcbc25503d5819cc0c1f18e1683c854542a2d9eb08540e2696eaa7ec72")
