-- Lua provided by RyzenAPI
-- Game: Sakura Angels

-- MAIN APPLICATION
addappid(342380)

-- MAIN APP DEPOTS / PACKAGES
addappid(342381, 1, "c5953b93d1408897f575ca929be4e2d6b91e1ddafc68c77f4db69a7a8585b581")
addappid(342383, 1, "bab4c7ae4bacfad0c84e347b63632a40912794e0d6c609210be1c4feaf9b7ef8")
