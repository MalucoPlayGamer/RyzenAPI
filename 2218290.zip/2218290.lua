-- Lua provided by RyzenAPI
-- Game: I'll be your ideal lover! - My Dream Lover -

-- MAIN APPLICATION
addappid(2218290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2218291, 1, "586e1c01ffe549e8040343a984014bc2cb7a6794c2278e886507dc352157884c")
