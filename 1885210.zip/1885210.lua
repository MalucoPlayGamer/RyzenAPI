-- Lua provided by RyzenAPI
-- Game: addappid(1885210)

-- MAIN APPLICATION
addappid(1885210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1885211, 1, "3706f3db1e617b0ba806fa966140848217240d3a60f9e2effd96a460aad5a67a")
