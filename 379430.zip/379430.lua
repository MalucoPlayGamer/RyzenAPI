-- Lua provided by RyzenAPI
-- Game: Kingdom Come: Deliverance

-- MAIN APPLICATION
addappid(379430)
addappid(768530)
addappid(801980)
addappid(883150)

-- MAIN APP DEPOTS / PACKAGES
addappid(379431, 1, "28025aa521351af4da4b05336ce0cdeb467cf54ab15af771b6e96e777e6e11ef")
addappid(379432, 1, "108f95cce2562576671a8d1deb159b583397b664cafabd96f622beaae2a38655")
addappid(379433, 1, "b73a679f54e714c4f1faf2c054cb3acaf90fcdd998e96984742b9f5f20d5325e")
addappid(836890, 0, "7e4b67dfff0691c120ae20411dd923d92fe00e434fc66529e528c431dcacf0ef")
addappid(836900, 0, "d131517918735f795946cf9898da1e5f69df47f9e2f4a6f572f74ab375f3152d")
addappid(836910, 0, "fde946d787d448a9ad59c6b49c4c8ed56da692d161669d585a82129d4c74be1e")
addappid(836920, 0, "abb26620bd532d9519f5c3359a4995bd7def223ec7ddef791fe0b487ecf6eff3")
addappid(836930, 0, "479474ba710c10d7b528343e0471cb4e979ad174ef2fefe437dbc0c0f1da8b43")
addappid(921950, 0, "7a9065cf0a6bab53fc81761cd1c3ccdd67e1516403d4a59d0a272de7b0c876ff")
addappid(977420, 0, "aafa5c0edc670ba1c9b40669ccbff37939d12a3484df559cda3a4fa671fdf72f")
addappid(1033890, 0, "4e8ad98af79c5565ecb6850e4f7a582e875c939630f61980a886f6a2e9168c81")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
