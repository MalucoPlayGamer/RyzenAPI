-- Lua provided by RyzenAPI
-- Game: 2817790

-- MAIN APPLICATION
addappid(2817790)
-- Game: addappid(2817790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817791, 1, "7758ba137858426fe8f6258bc39dc046772be0cf0e2f8de4dbfe9c2fa1cc7b08")
