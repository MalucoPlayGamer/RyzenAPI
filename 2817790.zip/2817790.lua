-- Lua provided by SkyAPI 
-- Game: AppID 2817790
addappid(2817790)
addappid(2817791, 1, "7758ba137858426fe8f6258bc39dc046772be0cf0e2f8de4dbfe9c2fa1cc7b08")
