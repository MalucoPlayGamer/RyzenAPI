-- 2327640's Lua and Manifest Created by Hubcap Manifest
-- Deadlock Station
-- Created: August 19, 2026 at 12:03:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2327640, 1, "0bd6f73c69c9088373838abf2aed12ab1d94bf610493afbc059e21f62126bbd9") -- Deadlock Station
-- MAIN APP DEPOTS
addappid(2327641, 1, "f5b5560251854db71eef863fd32ecb8fe85a2dbea8217aa7c6c163a403387510") -- Depot 2327641
setManifestid(2327641, "3134819170191931029", 145603580)