-- Lua provided by RyzenAPI
-- Game: Deadlock Station

-- MAIN APP DEPOTS / PACKAGES
addappid(2327640, 1, "0bd6f73c69c9088373838abf2aed12ab1d94bf610493afbc059e21f62126bbd9") -- Deadlock Station
addappid(2327641, 1, "f5b5560251854db71eef863fd32ecb8fe85a2dbea8217aa7c6c163a403387510") -- Depot 2327641

