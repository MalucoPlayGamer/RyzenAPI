-- Lua provided by RyzenAPI 
-- Game: Secret Cats - Spring Festival
addappid(3293970)
addappid(3293971, 1, "67df347ee80a7fa49cbe0358e2d2281ade8faac144237bb45c3fd25bd7f0a109")
addappid(3293973, 1, "15ceb321310984190e59cb2e9a1f53198930f8359e678f9fe39c6520153c8014")
addappid(3293974, 1, "e9b51072de47bd8a4191721ba1af5e52b15d0249d9a8864980180815e40049ae")
