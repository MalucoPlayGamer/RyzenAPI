-- Lua provided by RyzenAPI
-- Game: Shadows of War

-- MAIN APPLICATION
addappid(340220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(340221, 1, "1ecfd38608bac2a57546ab2f21cd55b73af18fb08226fc669359931ecec28771")
addappid(340223, 1, "939497c880676aa10a80cc85220e7b85f0e21cd3a233659cc29051ef611302b7")
addappid(387040, 0, "a5a9773a148619c96ddd17f64071344e7afb90e60ae13eed4a9a7b18f878e0a3")

