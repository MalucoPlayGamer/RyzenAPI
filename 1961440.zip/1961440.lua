-- Lua provided by RyzenAPI
-- Game: Dunjungle Demo

-- MAIN APPLICATION
addappid(1961440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1961441, 1, "82c68a7cab5685217a57dd65a5f3791b10bceb9f4f6443b7bdbae52980b524d6")

