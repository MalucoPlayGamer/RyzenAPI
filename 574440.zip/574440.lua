-- Lua provided by RyzenAPI 
-- Game: AppID 574440
addappid(574440)
addappid(574441, 1, "23081145279fecd4265b44deca45a91cdcb35c44c43028bcdb2337cb65cea90e")
