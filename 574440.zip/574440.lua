-- Lua provided by RyzenAPI
-- Game: addappid(574440)

-- MAIN APPLICATION
addappid(574440)

-- MAIN APP DEPOTS / PACKAGES
addappid(574441, 1, "23081145279fecd4265b44deca45a91cdcb35c44c43028bcdb2337cb65cea90e")
