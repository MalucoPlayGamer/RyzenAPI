-- Lua provided by RyzenAPI
-- Game: addappid(355920)

-- MAIN APPLICATION
addappid(355920)

-- MAIN APP DEPOTS / PACKAGES
addappid(355921, 1, "9a2c983049d4aa7c2ebb66400be68631a1c1ecd44dc3d7e7e8f48b56b2eb80e4")
