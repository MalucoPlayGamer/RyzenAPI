-- Lua provided by RyzenAPI 
-- Game: Ale & Tale Tavern
addappid(2683150)
addappid(2683151, 1, "fb4abcba88c9d336863c767233f69ca8be744236c5b6ae985441b2796efc5464")
