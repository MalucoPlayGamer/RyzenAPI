-- Lua provided by RyzenAPI
-- Game: Ale & Tale Tavern

-- MAIN APPLICATION
addappid(2683150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2683151, 1, "fb4abcba88c9d336863c767233f69ca8be744236c5b6ae985441b2796efc5464")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
