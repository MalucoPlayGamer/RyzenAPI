-- Lua provided by RyzenAPI
-- Game: Game: AppID 374010

-- MAIN APPLICATION
addappid(374010)
-- Game: addappid(374010)

-- MAIN APP DEPOTS / PACKAGES
addappid(374011, 1, "bd425687d6db2cb69acbc2cb09d3772e8ce28223c7cc0ae523fcbb5183c44eb0")
addappid(374012, 1, "cc896e50d095649cedd0adf6b296672811350f1ba5fe3b7adb31d1fcd9a96206")
