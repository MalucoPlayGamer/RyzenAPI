-- Lua provided by RyzenAPI
-- Game: Space Pilgrim Academy: Year 2

-- MAIN APPLICATION
addappid(831120)

-- MAIN APP DEPOTS / PACKAGES
addappid(831121, 1, "f0e98028e1fd48dc1242ed7d12c922147ec8af1c4f8ce01956a74ab0752fe790")

