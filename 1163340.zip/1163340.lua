-- Lua provided by RyzenAPI 
-- Game: AppID 1163340
addappid(1163340)
addappid(1163341, 1, "17f3c698d8024cf5c6efa4d1397f22d7256b90599b8743cdde91ef7c03a4ac35")
addappid(1485330, 0, "fbd5f87d5d3f396aa702580a215c15ad1388b7fbfb7a14c9bfd237c77410ae4f")
