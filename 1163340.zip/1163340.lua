-- Generated with Luie @ https://lua.tools/
-- 1163340 - Carrier Battles 4 Guadalcanal
-- Generated 2026-08-10 21:15:59 UTC
-- # Depots (Total/DLC/Shared): 3/1/0

-- Main AppID
addappid(1163340)

-- Main Depots
addappid(1163341, 1, "17f3c698d8024cf5c6efa4d1397f22d7256b90599b8743cdde91ef7c03a4ac35") -- (windows)
setManifestid(1163341, "3607523618485296721", 1909210409)

-- DLC's (no depot keys required)
addappid(1633240) -- CB4G - Operation FS scenario + Advanced Fog Of War
addappid(1850630) -- Carrier Battles - Submarines & Torpedo Alley scenario Sep 42
addappid(2384450) -- Carrier Battles - Indian Ocean Raid & Royal Navy
addappid(3030330) -- Carrier Battles - Into the Wind & Ceylon 1942
addappid(3377280) -- Carrier Battles - Hailstone 44
addappid(4058220) -- CB4G - Philippine Sea & Pilots
addappid(4738240) -- Carrier Battles 4 Guadalcanal - Leyte Gulf

-- DLC's (with depot keys)
-- CB4G - SeaPlanes at War & a Central Pacific 1943 Scenario (AppID: 1485330)
addappid(1485330)
addappid(1485330, 1, "fbd5f87d5d3f396aa702580a215c15ad1388b7fbfb7a14c9bfd237c77410ae4f")
setManifestid(1485330, "4069078396020002856", 0)

-- Missing Depots (We don't have the keys yet lol): 1163342
