-- Lua provided by RyzenAPI
-- Game: Carrier Battles 4 Guadalcanal

-- MAIN APPLICATION
addappid(1163340)
addappid(1485330)
addappid(1633240) -- CB4G - Operation FS scenario + Advanced Fog Of War
addappid(1850630) -- Carrier Battles - Submarines & Torpedo Alley scenario Sep 42
addappid(2384450) -- Carrier Battles - Indian Ocean Raid & Royal Navy
addappid(3030330) -- Carrier Battles - Into the Wind & Ceylon 1942
addappid(3377280) -- Carrier Battles - Hailstone 44
addappid(4058220) -- CB4G - Philippine Sea & Pilots
addappid(4738240) -- Carrier Battles 4 Guadalcanal - Leyte Gulf

-- MAIN APP DEPOTS / PACKAGES
addappid(1163341, 1, "17f3c698d8024cf5c6efa4d1397f22d7256b90599b8743cdde91ef7c03a4ac35") -- (windows)
addappid(1485330, 1, "fbd5f87d5d3f396aa702580a215c15ad1388b7fbfb7a14c9bfd237c77410ae4f")

