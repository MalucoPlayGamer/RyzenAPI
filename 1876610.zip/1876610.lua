-- Lua provided by RyzenAPI
-- Game: Verne: The Shape of Fantasy Demo

-- MAIN APPLICATION
addappid(1876610)
-- Game: addappid(1876610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1876611, 1, "10a708aaa538bdbd6c31b6b338994a67b32935ee2f99aff937a59bcc96366007")
