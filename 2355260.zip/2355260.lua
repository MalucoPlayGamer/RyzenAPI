-- Lua provided by RyzenAPI
-- Game: Game: Robin Morningwood Adventure - Attack of the gay clones

-- MAIN APPLICATION
addappid(2355260)
-- Game: addappid(2355260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2355261, 1, "4a2f931af82f7a4bd772cebb47671169eabdf5ad87f5d2e689ce254e64a86fc8")
