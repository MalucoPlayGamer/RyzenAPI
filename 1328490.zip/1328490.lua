-- Lua provided by RyzenAPI
-- Game: Rico-Jump

-- MAIN APPLICATION
addappid(1328490)
addappid(1519960)
addappid(1522240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328491, 1, "efd665b88031e3515bb7599d2935cf22bcf8e0f09cef5ca7e3c16127a093ae93")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
