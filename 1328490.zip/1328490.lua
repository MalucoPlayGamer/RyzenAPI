-- Lua provided by RyzenAPI
-- Game: Rico-Jump

-- MAIN APPLICATION
addappid(1328490)
addappid(1519960)
addappid(1522240)
-- Game: addappid(1328490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1328491, 1, "efd665b88031e3515bb7599d2935cf22bcf8e0f09cef5ca7e3c16127a093ae93")
