-- Lua provided by RyzenAPI
-- Game: zombie variant

-- MAIN APPLICATION
addappid(1247950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247951, 1, "239c7cdd45fdb29fffa0d1a2c52c699aa19f06543a4fc5e506cd74353f7eb93f")

