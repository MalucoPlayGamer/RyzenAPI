-- Lua provided by RyzenAPI
-- Game: Sunset Motel Demo

-- MAIN APPLICATION
addappid(2617490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617491, 1, "7b3dfc6f8240493292c289c2ef2ecae4b6178a3c925b2e2f0da8c002b24f6972")
