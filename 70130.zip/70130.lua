-- Lua provided by RyzenAPI
-- Game: AppID 70130

-- MAIN APPLICATION
addappid(70130)

-- MAIN APP DEPOTS / PACKAGES
addappid(70131, 1, "af86642e7825f0f7f1c80248bff79dd826c51c534b1bdc0785e8424f7e69a4ad")
