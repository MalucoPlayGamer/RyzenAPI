-- Lua provided by RyzenAPI
-- Game: MXGP - The Official Motocross Videogame Demo

-- MAIN APPLICATION
addappid(286650)
-- Game: addappid(286650)

-- MAIN APP DEPOTS / PACKAGES
addappid(286651, 1, "25cb8cbfb0c9e03c61d039b1e8dc09cb2f4c7669f3a0941833045fb70eb211b1")
