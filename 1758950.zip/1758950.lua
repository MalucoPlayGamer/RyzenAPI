-- Lua provided by RyzenAPI
-- Game: Banzai Escape 2: Subterranean

-- MAIN APPLICATION
addappid(1758950)
addappid(1762540)
addappid(1762541)
addappid(1762542)
addappid(1762543)
addappid(1777850)
addappid(1779600)
addappid(1779601)
addappid(1831280)
addappid(1831281)
addappid(1911080)
addappid(2145840)
addappid(2145841)
addappid(2304150)
addappid(2664780)
addappid(2883470)
addappid(2884790)
addappid(2884800)
addappid(3225580)
addappid(3304600)
addappid(3543280)
addappid(3837810)
addappid(4175820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758951, 1, "3651e588ed8ac682488b7648d77031600a182166827ae7b4edb91e5fe8e2e024")

