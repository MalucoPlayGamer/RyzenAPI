-- Lua provided by RyzenAPI
-- Game: Banzai Escape 2: Subterranean

-- MAIN APPLICATION
addappid(1758950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758951, 1, "3651e588ed8ac682488b7648d77031600a182166827ae7b4edb91e5fe8e2e024")
