-- Lua provided by RyzenAPI
-- Game: Valentino Rossi The Game

-- MAIN APPLICATION
addappid(438430)
addappid(491550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(438431, 1, "264b4988626b9026c8ca0285b5a7c1d3631ea87f50dc310f559970a70dc06adb")
addappid(464270, 0, "643152850e3146cb3c49d6dd35f19ddc7fc055366010027c03e2b3f07cb7de09")
addappid(464290, 0, "0231daa1f1338ce099f71a4a28526113ce1678a1cea3281b2cbbdf1e2c7dc7a0")
addappid(464300, 0, "e11518a6f972e08cd6dd7f4a95f3ff0c6711a9cc1fe5d9b0a57120196bb567f4")
addappid(464310, 0, "ca6e842aa47bbad82007ab3f7cd8f68f53cd3101e7409b54ad2a60048dfee2ad")
addappid(464320, 0, "556a85c7cced2e111e85f447a5d2b9a76ca21bfa1ea0109b2a3396f94d2f6120")
addappid(526670, 0, "b7c6772c4e3732aec1f94a4accd3543130a03fd49808acdd589ccecf7fffc133")
