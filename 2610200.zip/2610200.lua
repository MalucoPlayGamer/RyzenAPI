-- Lua provided by RyzenAPI
-- Game: Hidden City Top-Down 3D

-- MAIN APPLICATION
addappid(2610200)
-- Game: addappid(2610200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2610201, 1, "3ee24a5c208ba603c35d496449adc789630a16e8bf843da430a9836feae684cc")
