-- Lua provided by RyzenAPI
-- Game: addappid(1314590)

-- MAIN APPLICATION
addappid(1314590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1314591, 1, "f88ab26afe4b0eb01b74a740f3c60d17dde7e3bef8dc12ec3ee3758d6e91d9cf")
