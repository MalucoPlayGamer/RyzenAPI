-- Lua provided by RyzenAPI
-- Game: Aliens: Fireteam Elite

-- MAIN APPLICATION
addappid(1549970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1549971, 1, "4ac690bec527e770c57e0527886089cc9fe835779f3e70da8bdc7e5626c10410")

