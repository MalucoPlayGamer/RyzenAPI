-- Lua provided by RyzenAPI
-- Game: 388880

-- MAIN APPLICATION
addappid(388880)
-- Game: addappid(388880)

-- MAIN APP DEPOTS / PACKAGES
addappid(388881, 1, "dd211a172b43410e44d92b89c5615f2eadb5f6dcac614e5a7e389a8fbae36cdf")
addappid(388882, 1, "c1a947eceeacd834d08a0eda02fcebad654f3279963d4218a5ec4f1cf3ddb063")
addappid(388883, 1, "01d2d8cee8efa32284c76efa8b21bf155307c4a341145c9a67e0c7bb50d1073d")
addappid(388884, 1, "a125da1fad20abeb76ee3014727e885a27d2b66b4b6b820f96d3fcbf13d84142")
addappid(388885, 1, "a774d69747d607c5f6f9f398548e34569a441c43b009e51fe581a3abe19b3cf2")
addappid(388886, 1, "72af340112f261a37b219d7b4bb77b3d1208d412a060e7a2daed851d940f07f9")
