-- Lua provided by RyzenAPI
-- Game: Narcos: Rise of the Cartels

-- MAIN APPLICATION
addappid(914110)

-- MAIN APP DEPOTS / PACKAGES
addappid(914111, 1, "dc56fe5739a7714eb234a9f15ccb6382b58e51e6060bbeb593b5a9a0139bb771")

