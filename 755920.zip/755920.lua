-- Lua provided by RyzenAPI
-- Game: CHOP

-- MAIN APPLICATION
addappid(755920)

-- MAIN APP DEPOTS / PACKAGES
addappid(755927,0,"abdf0414530fa5c04cf96cb4f501994ae914a59503794bbb4c4fa589ffc7eb4b")
