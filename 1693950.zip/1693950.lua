-- Lua provided by RyzenAPI
-- Game: Boys Tale

-- MAIN APPLICATION
addappid(1693950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1693951, 1, "663ecd46409d1bda6f998af32af1b9895f1108020a69162152410eedce5a839a")

