-- Lua provided by RyzenAPI 
-- Game: AppID 388340
addappid(388340)
addappid(388341, 1, "a0b1f7a9a83cd1d5a5221aabc332ee011cba06d79b1b070715496a34bc690aa1")
addappid(388342, 1, "7dfeb5142392071fa9972e929ad577bae9c55835f6fbe98f485352aa83064c78")
