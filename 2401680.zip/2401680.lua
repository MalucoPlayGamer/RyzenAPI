-- Lua provided by RyzenAPI
-- Game: Game: Pet Shop Simulator

-- MAIN APPLICATION
addappid(2401680)
-- Game: addappid(2401680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2401681, 1, "db42f98ce5b346b2b30380411f5affe0c398cc0902195210ede5408abcd8da82")
