-- Lua provided by RyzenAPI
-- Game: Game: Sakura Knight 2

-- MAIN APPLICATION
addappid(1296260)
-- Game: addappid(1296260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296261, 1, "7582970e8aa3a8ce94431aff90b44876a4dce18a3830a0a4a352263549aa77b9")
