-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1350960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1350960,0,"145dccfe60738fa308707f827e19c7b37cf1fc34197894f61180a1e5fd88ada0")
addtoken(1350960,9803353038589610708)
