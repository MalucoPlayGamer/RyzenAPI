-- Lua provided by RyzenAPI
-- Game: addappid(3142360)

-- MAIN APPLICATION
addappid(3142360)

-- MAIN APP DEPOTS / PACKAGES
addappid(3142361, 1, "3fe472719c16eb1ebbcea9e1474840b964bfc345a6397b7e1de465875ef9ee10")
