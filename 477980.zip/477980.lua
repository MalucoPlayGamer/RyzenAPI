-- Lua provided by RyzenAPI
-- Game: addappid(477980)

-- MAIN APPLICATION
addappid(477980)

-- MAIN APP DEPOTS / PACKAGES
addappid(477981, 1, "9cc64acf895dd2758fe0f8413138e55a5cf81ed6274c21350900efaa358b9148")
