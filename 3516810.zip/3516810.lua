-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3516810)
-- Game: addappid(3516810)

-- MAIN APP DEPOTS / PACKAGES
addappid(3516810,0,"0b1f569f2d6f8baaa94874a6a7df7588513d66a0189da1614d808a5a497db914")
