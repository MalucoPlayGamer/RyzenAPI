-- Lua provided by RyzenAPI
-- Game: 1799210

-- MAIN APPLICATION
addappid(1799210)
-- Game: addappid(1799210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1799211, 1, "33e94ec1c656189447d2d744473f52b8c89b09b19be04b84d87e7e55cd99c7ca")
