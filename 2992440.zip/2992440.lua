-- Lua provided by RyzenAPI
-- Game: 2992440

-- MAIN APPLICATION
addappid(2992440)
-- Game: addappid(2992440)

-- MAIN APP DEPOTS / PACKAGES
addappid(2992441, 1, "d77ff41cadf5ee3fc8e3ef903f9a0eab9552f7a98692ab7150638a797585673a")
