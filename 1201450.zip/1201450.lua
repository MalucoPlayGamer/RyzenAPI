-- Lua provided by RyzenAPI
-- Game: Easy Hentai

-- MAIN APPLICATION
addappid(1201450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1201451, 1, "71a7e1670ff8a8757c22bcf481e3727f2e36cc6e194023a959cfb93fccf11108")
