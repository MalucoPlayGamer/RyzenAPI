-- Lua provided by RyzenAPI
-- Game: Intelligence: Dogs

-- MAIN APPLICATION
addappid(932350)
addappid(936910)
-- Game: addappid(932350)

-- MAIN APP DEPOTS / PACKAGES
addappid(932351, 1, "209cf70840072bfb0364ef9bc397031bc68c067291dd372492863f7efd1e2806")
