-- Lua provided by SkyAPI 
-- Game: The Bookwalker: Thief of Tales
addappid(1432100)
addappid(1432101, 1, "35518dbcaa6f636a0c3a6397d8d9d266052610ee877a8b31a4c0944e976a8e7c")
addappid(1432102, 1, "315d2d9dfdf965c622943f646061c5491efb57272866899872e6d1884df362bb")
addappid(2485400, 0, "1c2044c2a9a0d4c545c013e0cfce89c6c2b91c5918ce8cebe31523193f727399")
