-- Lua provided by RyzenAPI
-- Game: Game: The Bookwalker: Thief of Tales

-- MAIN APPLICATION
addappid(1432100)
-- Game: addappid(1432100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432101, 1, "35518dbcaa6f636a0c3a6397d8d9d266052610ee877a8b31a4c0944e976a8e7c")
addappid(1432102, 1, "315d2d9dfdf965c622943f646061c5491efb57272866899872e6d1884df362bb")
addappid(2485400, 0, "1c2044c2a9a0d4c545c013e0cfce89c6c2b91c5918ce8cebe31523193f727399")
