-- Lua provided by RyzenAPI
-- Game: Gamblers Table

-- MAIN APPLICATION
addappid(3618390)
addappid(4218840)

-- MAIN APP DEPOTS / PACKAGES
addappid(3618390,0,"a4ed71e9cece916bc3a74c744d76a557a2d3b0e967f770bc7dad12b181b3ae28")
addappid(3618391,0,"af524ae28cb634f861e43a8dc0f9dbc6002bb303ec8e8167e02a8c92fa57d1e9")
addappid(3618392,0,"0f1983ef9df338918e261c22b47c0bfdb8940a902f198be8f0e872fa7d0083ce")

