-- Lua provided by RyzenAPI
-- Game: Taival

-- MAIN APPLICATION
addappid(3152750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3152751,0,"d6d1e185dcc6e0371ab96aed6a28edfa42dbeb4fb6ef6f80f1413d3a9884ef6c")

