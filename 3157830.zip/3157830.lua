-- Lua provided by RyzenAPI
-- Game: addappid(3157830)

-- MAIN APPLICATION
addappid(3157830)

-- MAIN APP DEPOTS / PACKAGES
addappid(3157831, 1, "dabb58a44e22f5a1405da4dc59179c331fe5f0c8efd037a97dc2c58b2d85a683")
