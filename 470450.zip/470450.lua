-- Lua provided by RyzenAPI
-- Game: Game: AppID 470450

-- MAIN APPLICATION
addappid(470450)
-- Game: addappid(470450)

-- MAIN APP DEPOTS / PACKAGES
addappid(470451, 1, "5aa4c18bdbda9d85059a26c2fb98d322379c2d9e98b6231de4f8d1d12b9edeb8")
addappid(470452, 1, "3870b91786fcfdf8b02efe6ef54c7dcdd5c39073ac44f5dffb3b8db92d3606c1")
