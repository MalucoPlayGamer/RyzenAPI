-- Lua provided by RyzenAPI 
-- Game: Archmage Ricka
addappid(1981500)
addappid(1981501, 1, "1351a13e56f54cbbdcfef153f1cdf0f9f46e22ee30bab7d8c44f855c1a3ff764")
addappid(1981502, 1, "5568e84e3b08854ff9548f123cbd9039491ff2a4191390e4c868f4d3102a7f90")
