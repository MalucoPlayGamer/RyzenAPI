-- Lua provided by RyzenAPI
-- Game: addappid(3136070)

-- MAIN APPLICATION
addappid(3136070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3136071, 1, "5ecf24f1ce04f17c8637e417fee33c343ce41905fb65308e689650b8a3fe8fec")
