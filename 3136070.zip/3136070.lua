-- Lua provided by SkyAPI 
-- Game: Sportvida CyberDash
addappid(3136070)
addappid(3136071, 1, "5ecf24f1ce04f17c8637e417fee33c343ce41905fb65308e689650b8a3fe8fec")
