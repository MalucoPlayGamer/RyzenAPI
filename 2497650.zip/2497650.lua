-- Lua provided by RyzenAPI
-- Game: addappid(2497650)

-- MAIN APPLICATION
addappid(2497650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2497651, 1, "bfd0706032b2aaea4eccc569ad0a6d8b76a783b779c4412626a464138c17dbce")
