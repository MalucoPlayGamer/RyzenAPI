-- Lua provided by SkyAPI 
-- Game: Dance Eden
addappid(2934620)
addappid(2934621, 1, "2ce7160930fd2a57c81eb1a61340e24ffd1da3b81cbe1c10ab4a4e21c58e03d8")
