-- Lua provided by RyzenAPI
-- Game: 2934620

-- MAIN APPLICATION
addappid(2934620)
-- Game: addappid(2934620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2934621, 1, "2ce7160930fd2a57c81eb1a61340e24ffd1da3b81cbe1c10ab4a4e21c58e03d8")
