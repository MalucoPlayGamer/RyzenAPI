-- Lua provided by RyzenAPI
-- Game: 边缘空间

-- MAIN APPLICATION
addappid(3214190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3214191,0,"737eaa74eac3eac0eaa02bad618c4b359a2d366e7b22231ed3a6cff5a4e52c50")

