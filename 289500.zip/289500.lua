-- Lua provided by RyzenAPI
-- Game: AppID 289500

-- MAIN APPLICATION
addappid(289500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(289501, 1, "94a520b42f9942bf7c1cadaf573fb161c4ee1369f764842d8685c865185f4185")
addappid(289502, 1, "20678f523d44c8c023dc143a08d961a083ee6f9ac33051df45bfb01163bb0300")
addappid(289503, 1, "86da06eb70cdce7d9f5730bd70622cbdfd19692a82a0ffea61ae04262328128f")
addappid(289504, 1, "9aae44d46bf16a0318dfbbd1f8f6c258201d9fc23afdcc9bdb0dd8696850a54a")
addappid(289505, 1, "2efe5ed833c512c99b8e26091e5218fc72b3dfea11c1f0019e85a01b7c402ec0")
addappid(289506, 1, "2c58f9039b1382eca29f3b7f47347e6edb1399c0734b81dba642e64f17be7ffa")

