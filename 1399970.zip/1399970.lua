-- Lua provided by RyzenAPI
-- Game: 1399970

-- MAIN APPLICATION
addappid(1399970)
-- Game: addappid(1399970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399971, 1, "3ab8daa5fa387269938903be4c5ee694a71fdeab24b7f4b7041702e9d0cbb8ad")
