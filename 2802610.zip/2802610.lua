-- Lua provided by RyzenAPI
-- Game: 幻夜图书馆 - Library of Phantom Night Demo

-- MAIN APPLICATION
addappid(2802610)
-- Game: addappid(2802610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2802611, 1, "70b899f92be949fba7afcb5b012a931f16da8c67dc91868bc799b2871e1ac68e")
