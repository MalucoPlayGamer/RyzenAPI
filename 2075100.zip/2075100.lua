-- Lua provided by RyzenAPI
-- Game: addappid(2075100)

-- MAIN APPLICATION
addappid(2075100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2075101, 1, "deb4947ce8dada6c0b74940f9a79844962cd9a23424c47b47a10dbef210e4138")
