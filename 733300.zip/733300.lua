-- Lua provided by RyzenAPI 
-- Game: My Big Sister
addappid(733300)
addappid(733301, 1, "feac505adb2238a631e6a11d31e3c57315f3840cd1f263bdc446932535c513e1")
