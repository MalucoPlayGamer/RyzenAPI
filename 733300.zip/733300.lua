-- Lua provided by RyzenAPI
-- Game: My Big Sister

-- MAIN APPLICATION
addappid(733300)

-- MAIN APP DEPOTS / PACKAGES
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(733301, 1, "feac505adb2238a631e6a11d31e3c57315f3840cd1f263bdc446932535c513e1")

