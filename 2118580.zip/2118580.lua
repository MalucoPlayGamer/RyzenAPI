-- Lua provided by RyzenAPI
-- Game: SuperTotalCarnage!

-- MAIN APPLICATION
addappid(2118580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2118582,0,"3546e0e3f7d183c4f0ce9d0081cae96528711fb1cc01d91c032094134aa6f940")

