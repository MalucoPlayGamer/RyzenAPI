-- Lua provided by RyzenAPI
-- Game: Vasilisa and Baba Yaga

-- MAIN APPLICATION
addappid(2331070)
addappid(3666700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2331071, 1, "195b6d43a192fece38c10a7f3deee99db7016a82ac177254bc8d11169422387a")

