-- Lua provided by SkyAPI 
-- Game: AppID 815830
addappid(815830)
addappid(815831, 1, "8e79a4977a7e5f0db03edf44f01e990a1c9d94951c66f9897b3182a17077dfb1")
