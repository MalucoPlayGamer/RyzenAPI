-- Lua provided by RyzenAPI
-- Game: Chained in the Backrooms Demo

-- MAIN APPLICATION
addappid(3266780)

-- MAIN APP DEPOTS / PACKAGES
addappid(3266781, 1, "a2bd6396ce79befb7d125b2ce8f9f8933adfc16a6181c531eb15e7c9bd294407")
