-- Lua provided by RyzenAPI
-- Game: 2777620

-- MAIN APPLICATION
addappid(2777620)
-- Game: addappid(2777620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2777621, 1, "b8883a4b66554946413fcadfb30b1fc5067082a630b4685713a0de1484be0dad")
