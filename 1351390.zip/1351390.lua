-- Lua provided by RyzenAPI
-- Game: Game: AppID 1351390

-- MAIN APPLICATION
addappid(1351390)
-- Game: addappid(1351390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351391, 1, "9212a5ea48ac3ac09f38b0450aac56dc7492aee3cf6aa56bd55036cdf7d5d092")
addappid(1351392, 1, "afcc46f666d3b3b7a9b41bed664c0b9e67f8206f8254bdd77331f972abf5305c")
