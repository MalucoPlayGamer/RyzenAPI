-- Lua provided by RyzenAPI
-- Game: AppID 628420

-- MAIN APPLICATION
addappid(628420)
-- Game: addappid(628420)

-- MAIN APP DEPOTS / PACKAGES
addappid(628421, 1, "9d69fdfa5751cc2c958e3ac30af22f07d150b4fa6800700c23fbb5c67cea3515")
