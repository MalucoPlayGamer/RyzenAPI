-- Lua provided by RyzenAPI
-- Game: Game: AppID 12450

-- MAIN APPLICATION
addappid(12450)
-- Game: addappid(12450)

-- MAIN APP DEPOTS / PACKAGES
addappid(12451, 1, "7d877a21857dc80c95087a017c34762930f9888c4c83b45b0ca0951dbc6e37d9")
