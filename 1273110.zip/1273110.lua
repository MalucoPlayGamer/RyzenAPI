-- Lua provided by RyzenAPI
-- Game: Sir Stretchalot - The Wenches in the Well

-- MAIN APPLICATION
addappid(1273110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1273111, 1, "2a18ce141bd4a03e22e511f9d15917708ef19c963b327c70b5c9f38760a7b72a")
