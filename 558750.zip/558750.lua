-- Lua provided by RyzenAPI
-- Game: Goaltender VR

-- MAIN APPLICATION
addappid(558750)

-- MAIN APP DEPOTS / PACKAGES
addappid(558751, 1, "ff45afa8e505d9b0e5a92129e34bca819f9a43564a105a4efa327363fea8ab4b")
