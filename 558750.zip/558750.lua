-- Lua provided by SkyAPI 
-- Game: Goaltender VR
addappid(558750)
addappid(558751, 1, "ff45afa8e505d9b0e5a92129e34bca819f9a43564a105a4efa327363fea8ab4b")
