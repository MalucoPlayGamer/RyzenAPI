-- Lua provided by RyzenAPI
-- Game: Game: Granado Espada

-- MAIN APPLICATION
addappid(663090)
-- Game: addappid(663090)

-- MAIN APP DEPOTS / PACKAGES
addappid(663091, 1, "1adf47839846c255099fa4636a268d57bc8bef084386c692f506153a234cd818")
