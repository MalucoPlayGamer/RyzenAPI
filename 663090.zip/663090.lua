-- Lua provided by SkyAPI 
-- Game: Granado Espada
addappid(663090)
addappid(663091, 1, "1adf47839846c255099fa4636a268d57bc8bef084386c692f506153a234cd818")
