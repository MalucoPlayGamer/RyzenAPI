-- Lua provided by RyzenAPI
-- Game: Granado Espada

-- MAIN APPLICATION
addappid(663090)

-- MAIN APP DEPOTS / PACKAGES
addappid(663091, 1, "1adf47839846c255099fa4636a268d57bc8bef084386c692f506153a234cd818")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(687700)
addappid(687701)
addappid(687702)
addappid(775350)
addappid(775351)
addappid(806620)
addappid(806621)
addappid(842840)
addappid(842841)
