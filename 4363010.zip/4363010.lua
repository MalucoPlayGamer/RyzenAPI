-- Lua provided by RyzenAPI
-- Game: CHWÆST: A Creeping Parasite Horror

-- MAIN APPLICATION
addappid(4363010)

-- MAIN APP DEPOTS / PACKAGES
addappid(4363011,0,"9ea5cad4766707584b8752d92f5588dc32d90f5d9de2fdf3f286695e85d28a68")

