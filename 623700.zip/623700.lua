-- Lua provided by RyzenAPI
-- Game: 623700

-- MAIN APPLICATION
addappid(623700)
-- Game: addappid(623700)

-- MAIN APP DEPOTS / PACKAGES
addappid(623701, 1, "21ec65e6822a0f15e3d861374eae7d079c2cff329e1a286772667c91d307c94c")
