-- Lua provided by RyzenAPI
-- Game: Game: I commissioned some bees

-- MAIN APPLICATION
addappid(1996420)
-- Game: addappid(1996420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1996421, 1, "afd321937a4dd8b75dd852a4526a297e55d2b971a62ce92ca41e9cbe6c81a404")
