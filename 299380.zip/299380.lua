-- Lua provided by RyzenAPI
-- Game: 299380

-- MAIN APPLICATION
addappid(299380)
-- Game: addappid(299380)

-- MAIN APP DEPOTS / PACKAGES
addappid(299381, 1, "3349409a2b99eb9f37942191bb63db9c4d1e5b4dda50edebe8e2ea69819b69dd")
