-- Lua provided by RyzenAPI
-- Game: Masquerade: The Baubles of Doom

-- MAIN APPLICATION
addappid(299380)

-- MAIN APP DEPOTS / PACKAGES
addappid(299381, 1, "3349409a2b99eb9f37942191bb63db9c4d1e5b4dda50edebe8e2ea69819b69dd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
