-- Lua provided by RyzenAPI
-- Game: SEUM: Speedrunners from Hell

-- MAIN APPLICATION
addappid(457210)
addappid(1949041)
addappid(1949042)
addappid(1949043)
-- Game: addappid(457210)

-- MAIN APP DEPOTS / PACKAGES
addappid(457211, 1, "ad4aa28cbee76098ae6db553881bc2282141ef06e498435103584a02c1cd7d52")
addappid(457212, 1, "3e02ec7cc6265040a33a8a906f297d0ed7a7ac394a204dcd2c03b14ff38a5847")
addappid(457213, 1, "a52a73a3f33b86f1c7ef407221c5de9bf7cb951439c657b30e51c6cd6d65d4f2")
addappid(713561, 0, "a73b9ad836a7d3ae144defc27c7b785f9343723665c3b4b5c62cf9b8c8ee2579")
addappid(713562, 0, "57d5ff68231c52845c24d303cd9f7e436393accade867f98c09838d1b0e69ecc")
addappid(713563, 0, "948028126669f3da769a294de5921aa47290573f6551c17156cabdabe33d1218")
