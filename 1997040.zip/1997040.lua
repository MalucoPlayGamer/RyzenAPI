-- Lua provided by RyzenAPI
-- Game: addappid(1997040)

-- MAIN APPLICATION
addappid(1997040)
addappid(4465130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997041, 1, "47f68d7b70bc1a054ba3ab802ab17b93d8e60c5aa51e5c4b123204acb0b97116")
