-- Lua provided by RyzenAPI
-- Game: MARVEL SNAP

-- MAIN APPLICATION
addappid(1997040)
addappid(4465130)
addappid(4465140)
addappid(4465150)
addappid(4465160)
addappid(4465170)
addappid(4465180)
addappid(4465190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1997041, 1, "47f68d7b70bc1a054ba3ab802ab17b93d8e60c5aa51e5c4b123204acb0b97116")

