-- Lua provided by RyzenAPI
-- Game: 2772420

-- MAIN APPLICATION
addappid(2772420)
-- Game: addappid(2772420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2772421, 1, "feeee3f4d4e7383b7b3e73cae3d64cf5199942e995152fc270d457e86d436aa3")
