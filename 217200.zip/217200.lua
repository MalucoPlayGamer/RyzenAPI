-- Lua provided by RyzenAPI
-- Game: Game: AppID 217200

-- MAIN APPLICATION
addappid(217200)
-- Game: addappid(217200)

-- MAIN APP DEPOTS / PACKAGES
addappid(217201, 1, "425a471f8d8a11e57c2e573e9ea75ffd641d9dc92a423ee6e530fc6bac26b2b6")
