-- Lua provided by RyzenAPI
-- Game: addappid(962580)

-- MAIN APPLICATION
addappid(962580)

-- MAIN APP DEPOTS / PACKAGES
addappid(962581, 1, "ecf7c33add3af3999496a2d4d329be64b95a454bf226f5234367c1512353ab67")
