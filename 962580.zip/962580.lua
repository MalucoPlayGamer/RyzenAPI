-- Lua provided by RyzenAPI
-- Game: Summer in Mara

-- MAIN APPLICATION
addappid(962580)
addappid(1380090)

-- MAIN APP DEPOTS / PACKAGES
addappid(962581,0,"ecf7c33add3af3999496a2d4d329be64b95a454bf226f5234367c1512353ab67")
addappid(1380090,0,"fa43c66b8ea42354e5ba2ba88e18b1a73f20822bdcdd32ce3884abb70fd0ac03")

