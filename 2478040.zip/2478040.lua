-- Lua provided by RyzenAPI
-- Game: Slugs and Bugs: Conversion

-- MAIN APPLICATION
addappid(2478040)
-- Game: addappid(2478040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478041, 1, "6bcec586391de3874f7b8c0c330549c2fb4004610241a0b6afff747d31514e5a")
