-- Lua provided by RyzenAPI
-- Game: Game: Midnight Crane

-- MAIN APPLICATION
addappid(3841220)
-- Game: addappid(3841220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3841221, 1, "aab54728b207ad642294b0aef944136173216775913912d4d20ad20354e97fd2")
