-- Lua provided by RyzenAPI
-- Game: Bus Simulator 16

-- MAIN APPLICATION
addappid(324310)
addappid(443430)
addappid(563890)
addappid(609880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(324311, 1, "83f90bd9262bcdf8f300eb9a121175e65dadf6f15e85de9cd38b03b4c9295ae9")
addappid(324312, 1, "d4f02234ba0f374ba686a8982196e843dcb64d2c993522dfb30923bdb3584f8d")
