-- Lua provided by RyzenAPI
-- Game: FATE: Undiscovered Realms

-- MAIN APPLICATION
addappid(276890)

-- MAIN APP DEPOTS / PACKAGES
addappid(276891, 1, "9d14c038aef01c7a7edda41cf4303b31838df8ec5a7162660e9d292e6221c594")

