-- Lua provided by RyzenAPI
-- Game: 1864460

-- MAIN APPLICATION
addappid(1864460)
-- Game: addappid(1864460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1864461, 1, "2cfd0876343a05f677329eb10b1dc098420e34c4b485e02715cc5fe1bde46c21")
