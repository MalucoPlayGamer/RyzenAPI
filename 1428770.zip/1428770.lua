-- Lua provided by RyzenAPI 
-- Game: Kingdom Gun
addappid(1428770)
addappid(1428771, 1, "cfdaa2552885b460bf140790ce34b2425de8a5c62d515b9f69cce20aa9fb8bb2")
