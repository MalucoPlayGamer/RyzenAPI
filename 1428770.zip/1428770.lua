-- Lua provided by RyzenAPI
-- Game: Kingdom Gun

-- MAIN APPLICATION
addappid(1428770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428771, 1, "cfdaa2552885b460bf140790ce34b2425de8a5c62d515b9f69cce20aa9fb8bb2")

