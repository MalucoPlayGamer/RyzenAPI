-- Lua provided by SkyAPI 
-- Game: The Yamamura Estate
addappid(3143700)
addappid(3143701, 1, "e8c625ab9b2cd973ea81b4805b971de123aa7ab00f1f58e62f9871584d354211")
