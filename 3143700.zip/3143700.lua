-- Lua provided by RyzenAPI
-- Game: The Yamamura Estate

-- MAIN APPLICATION
addappid(3143700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3143701, 1, "e8c625ab9b2cd973ea81b4805b971de123aa7ab00f1f58e62f9871584d354211")

