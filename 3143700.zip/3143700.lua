-- Lua provided by RyzenAPI
-- Game: The Yamamura Estate

-- MAIN APPLICATION
addappid(3143700)

-- MAIN APP DEPOTS / PACKAGES
addappid(3143701, 1, "e8c625ab9b2cd973ea81b4805b971de123aa7ab00f1f58e62f9871584d354211")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
