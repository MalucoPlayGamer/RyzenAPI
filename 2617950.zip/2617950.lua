-- Lua provided by RyzenAPI
-- Game: Bullets & Brains Demo

-- MAIN APPLICATION
addappid(2617950)
-- Game: addappid(2617950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617951, 1, "d4c656c16635fd3483f6bf99af498b5564fb89ca428426975ca8721e27967db2")
