-- Lua provided by RyzenAPI
-- Game: Artifact Hunter

-- MAIN APPLICATION
addappid(1440020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1440021, 1, "420ec1af2c6fe845a3ab714f4fc5b5f589b03700fb07154e0eaf835481e364a8")

