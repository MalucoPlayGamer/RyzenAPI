-- Lua provided by RyzenAPI
-- Game: Game: Pangman

-- MAIN APPLICATION
addappid(1319320)
-- Game: addappid(1319320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1319321, 1, "6c75358a695d550df94e3f1d0b5fbe3f34b809d7a65f222fe9f91ec2fa1c79dc")
