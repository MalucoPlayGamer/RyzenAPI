-- Lua provided by RyzenAPI
-- Game: Game: AppID 3590330

-- MAIN APPLICATION
addappid(3590330)
-- Game: addappid(3590330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3590331, 1, "f3e6542d0785373de145c961470107681b533c7dda46d9fb17a033493d8ecaf2")
