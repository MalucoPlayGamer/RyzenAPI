-- Lua provided by RyzenAPI
-- Game: Game: AppID 3519390

-- MAIN APPLICATION
addappid(3519390)
-- Game: addappid(3519390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3519391, 1, "20022fdb59f665dbfc5e7de9b00bf36130ea6398a8b3b2d13e6dbf55b3f562cb")
