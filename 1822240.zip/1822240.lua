-- Lua provided by RyzenAPI
-- Game: Game: Stars In The Trash

-- MAIN APPLICATION
addappid(1822240)
addappid(3358370)
-- Game: addappid(1822240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1822241, 1, "995f02c6cf0274e5c8292d95dcbdcb9cbc206191d18c72adc7dba19bfd525aa4")
