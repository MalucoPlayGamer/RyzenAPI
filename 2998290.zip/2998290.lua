-- Lua provided by RyzenAPI
-- Game: Weirdo

-- MAIN APPLICATION
addappid(2998290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2998291, 1, "446c76053bf016bf6d54b3d27a5bad60b5773234362ea74e39b22ec41e3ed53b")
addappid(2998292, 1, "10fc5182bcf36a3b7c08afece23fdc2b25218722d389d489ae5b0678d8fef283")
addappid(2998293, 1, "06553e9711fbd2d034841f41cdcff258766ba5d3d763d271a53365f01f7f74fa")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3456130)
addappid(3456140)
