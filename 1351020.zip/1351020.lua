-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1351020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1351020,0,"f364318a09ccd8782f9c7128d8a4d04163ac2cc4a2c2c973825859c1afa32592")

