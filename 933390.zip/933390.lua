-- Lua provided by RyzenAPI 
-- Game: Mythical
addappid(933390)
addappid(933391, 1, "1f3828bd6ce810ae737c8e8900dea065f271bb640062e5a42d3f6683ec94b071")
addappid(933392, 1, "2bb4dc807287679d96bc9c92049ae208e486c4ec516d49e196009c8d94d1e6ec")
