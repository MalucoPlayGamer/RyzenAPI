-- Lua provided by RyzenAPI
-- Game: Game: Mythical

-- MAIN APPLICATION
addappid(933390)
-- Game: addappid(933390)

-- MAIN APP DEPOTS / PACKAGES
addappid(933391, 1, "1f3828bd6ce810ae737c8e8900dea065f271bb640062e5a42d3f6683ec94b071")
addappid(933392, 1, "2bb4dc807287679d96bc9c92049ae208e486c4ec516d49e196009c8d94d1e6ec")
