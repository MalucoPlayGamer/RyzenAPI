-- Lua provided by RyzenAPI 
-- Game: Mr. Prepper: Prologue
addappid(1340530)
addappid(1340531, 1, "2ecc53de54a846cd1943a86d15f8207bb62432cc042e7b2e0b161fa9d139e4c6")
