-- Lua provided by RyzenAPI
-- Game: Game: Die in the Dungeon

-- MAIN APPLICATION
addappid(2026820)
-- Game: addappid(2026820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2026821, 1, "891341488c8e6e96d7c8551a5d56799ea66ea333322887007d3b892cd866d249")
addappid(3450700, 0, "50dac3d62042ea8d2835fbe69f718e909e38e1c3e36dd2ee2cb0e709c98f70ca")
