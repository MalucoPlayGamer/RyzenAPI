-- Lua provided by RyzenAPI
-- Game: Exo Digger

-- MAIN APPLICATION
addappid(3612620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3612622,0,"93d8d53637d63588e5aa4e9100436d06107a8947580ece4da3a4b1fc7efb5437")
