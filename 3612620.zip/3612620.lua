-- Lua provided by RyzenAPI
-- Game: Exo Digger

-- MAIN APPLICATION
addappid(3612620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3612622,0,"93d8d53637d63588e5aa4e9100436d06107a8947580ece4da3a4b1fc7efb5437")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
