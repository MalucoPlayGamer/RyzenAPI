-- Lua provided by RyzenAPI
-- Game: Game: Depopulation

-- MAIN APPLICATION
addappid(718210)
-- Game: addappid(718210)

-- MAIN APP DEPOTS / PACKAGES
addappid(718211, 1, "b349d8ae5071c777eb096327e6753d402040f1b0a859c0f6712846702892f82e")
