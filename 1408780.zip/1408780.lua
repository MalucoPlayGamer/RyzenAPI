-- Lua provided by RyzenAPI
-- Game: Mad Taxi

-- MAIN APPLICATION
addappid(1408780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408781, 1, "f3521d2624698a001b2715279110cb45eebb46e9e66df3fe4c23900bbda791f1")

