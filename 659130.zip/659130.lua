-- Lua provided by RyzenAPI
-- Game: Shopping Tycoon

-- MAIN APPLICATION
addappid(659130)

-- MAIN APP DEPOTS / PACKAGES
addappid(659131, 1, "ef6cfddaa2e30242c7b9b0df2d35a6ae58ac05666f7d31330c334e40ffa99f55")

