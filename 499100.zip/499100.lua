-- Lua provided by RyzenAPI
-- Game: 499100

-- MAIN APPLICATION
addappid(499100)
-- Game: addappid(499100)

-- MAIN APP DEPOTS / PACKAGES
addappid(499101, 1, "9a39f401ea29514a873a952a52551f0510e25f5beec1cac6b523449505ca89f6")
