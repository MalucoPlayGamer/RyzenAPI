-- Lua provided by RyzenAPI
-- Game: AppID 3216590

-- MAIN APPLICATION
addappid(3216590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3216591, 1, "a289c4cee2e7813bfdb0f4f1065c5076c1ee35cf976f5c9a1d763d9bee02318e")

