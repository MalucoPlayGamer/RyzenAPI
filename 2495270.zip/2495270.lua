-- Lua provided by RyzenAPI
-- Game: Lab Cat Escape

-- MAIN APPLICATION
addappid(2495270)

-- MAIN APP DEPOTS / PACKAGES
addappid(2495271, 1, "65b03658f3dfbdab4554084448d5c3d5a4cceaec737772a15d92be90d73edcc7")

