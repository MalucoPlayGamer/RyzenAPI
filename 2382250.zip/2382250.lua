-- Lua provided by RyzenAPI
-- Game: Seven Nights Ghost

-- MAIN APPLICATION
addappid(2382250)
-- Game: addappid(2382250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2382251, 1, "75063de08864177e446b05244f6766185c1a25fdd781afe377c29e7f2241fa6e")
