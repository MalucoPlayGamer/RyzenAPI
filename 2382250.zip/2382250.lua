-- Lua provided by SkyAPI 
-- Game: Seven Nights Ghost
addappid(2382250)
addappid(2382251, 1, "75063de08864177e446b05244f6766185c1a25fdd781afe377c29e7f2241fa6e")
