-- Lua provided by RyzenAPI
-- Game: Steel Assault

-- MAIN APPLICATION
addappid(1280300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280301, 1, "9fa535476852bf4d5479b93678bd9f25b4910b1a1f9192b3ba2cd43837ab6cd7")
addappid(1280302, 1, "bc16f7bd84a8a78c81e7638cebdcb29857612543c39d3d9ac1ddeefc157b9c68")
addappid(1280303, 1, "dfe424a5ae7b790a88ad9df400add0221d696d7b47484875237b96a2cb042853")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
