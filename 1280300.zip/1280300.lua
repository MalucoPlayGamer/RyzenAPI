-- Lua provided by RyzenAPI
-- Game: Steel Assault

-- MAIN APPLICATION
addappid(1280300)
-- Game: addappid(1280300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1280301, 1, "9fa535476852bf4d5479b93678bd9f25b4910b1a1f9192b3ba2cd43837ab6cd7")
addappid(1280302, 1, "bc16f7bd84a8a78c81e7638cebdcb29857612543c39d3d9ac1ddeefc157b9c68")
addappid(1280303, 1, "dfe424a5ae7b790a88ad9df400add0221d696d7b47484875237b96a2cb042853")
