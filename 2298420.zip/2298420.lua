-- Lua provided by RyzenAPI
-- Game: addappid(2298420)

-- MAIN APPLICATION
addappid(2298420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2298421, 1, "38de95b4f3b6d35aac6d74dd50ffcb9ec504a28bcd8a8e3a2bb69015af0ba8fa")
