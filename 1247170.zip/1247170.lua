-- Lua provided by RyzenAPI
-- Game: addappid(1247170)

-- MAIN APPLICATION
addappid(1247170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1247171, 1, "b49e3ce3068ec8821b17859fc9944da5e8ab928b873fe3b9aec82298b71183b7")
