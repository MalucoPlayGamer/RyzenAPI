-- Lua provided by RyzenAPI
-- Game: 2646060

-- MAIN APPLICATION
addappid(2646060)
-- Game: addappid(2646060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2646061, 1, "5c686c6448eb7ad07af1b0e5fab6dfd20a488297435abdcf2ec974b7fb375d3f")
