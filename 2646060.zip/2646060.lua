-- Lua provided by SkyAPI 
-- Game: Luna's Light
addappid(2646060)
addappid(2646061, 1, "5c686c6448eb7ad07af1b0e5fab6dfd20a488297435abdcf2ec974b7fb375d3f")
