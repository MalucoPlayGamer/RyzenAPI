-- Lua provided by RyzenAPI
-- Game: The Jackbox Party Starter

-- MAIN APPLICATION
addappid(1755580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1755581, 1, "aeeb74b74b94bec0bfddd61e1a9f6c17aae14be679970d8eb0030394ead303a2")
addappid(1755582, 1, "8e2ca6c76f3a664d9cc158d646418970f48ef904993c9be26cf4f807f0223bfe")
addappid(2828508, 0, "86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")

