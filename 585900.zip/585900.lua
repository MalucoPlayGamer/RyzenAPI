-- Lua provided by RyzenAPI
-- Game: Harvest Moon: Light of Hope

-- MAIN APPLICATION
addappid(585900)
addappid(852000)
addappid(867200)
addappid(867220)
addappid(867230)

-- MAIN APP DEPOTS / PACKAGES
addappid(585901, 1, "211d69c21bd3ec291967a53ced10c3f9c6c9f72874585124308575412aa7aca4")

