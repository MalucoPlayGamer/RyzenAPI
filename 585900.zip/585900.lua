-- Lua provided by RyzenAPI
-- Game: 585900

-- MAIN APPLICATION
addappid(585900)
-- Game: addappid(585900)

-- MAIN APP DEPOTS / PACKAGES
addappid(585901, 1, "211d69c21bd3ec291967a53ced10c3f9c6c9f72874585124308575412aa7aca4")
