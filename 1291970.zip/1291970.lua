-- Lua provided by RyzenAPI
-- Game: Game: Mythic Dungeons

-- MAIN APPLICATION
addappid(1291970)
-- Game: addappid(1291970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1291971, 1, "9905b6cae4c99640ae506a889ff6ace220c724b2e76b196dc9e82c7423cfcfac")
