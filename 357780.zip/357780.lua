-- Lua provided by RyzenAPI
-- Game: AppID 357780

-- MAIN APPLICATION
addappid(357780)

-- MAIN APP DEPOTS / PACKAGES
addappid(357781, 1, "264285d6fff36906c0eb7d447593492e57a289c7f07966b42f61800b5e006227")
addappid(357782, 1, "49fae41bb211db0ae74ad22b6255822faa491ca089177fb14b1b462334a0aba7")
addappid(357783, 1, "29955a45115294c71b7fd9cf788759481bd2c5e17054955ce58632687baa6ee5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
