-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - Fantasy Heroine Character Pack 2

-- MAIN APPLICATION
addappid(1533170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1533170,0,"1e26c64f5e8a16fd55404fe1562a861b3737aeb33f0a58eabe68097ece68ebd3")

