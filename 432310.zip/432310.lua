-- Lua provided by RyzenAPI
-- Game: 432310

-- MAIN APPLICATION
addappid(432310)
-- Game: addappid(432310)

-- MAIN APP DEPOTS / PACKAGES
addappid(432311, 1, "600c2e8dccc38acd20325a5fa67623c55dc44075d69850c10559078a2c800f59")
