-- Lua provided by RyzenAPI
-- Game: Virtual Pool 4 Multiplayer

-- MAIN APPLICATION
addappid(432310)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(432311, 1, "600c2e8dccc38acd20325a5fa67623c55dc44075d69850c10559078a2c800f59")

