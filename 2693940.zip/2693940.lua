-- Lua provided by RyzenAPI
-- Game: NEODUEL: Backpack Monsters

-- MAIN APPLICATION
addappid(2693940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2693941, 1, "4911dead727df5a837596e27ff83bb201ef0dd16a2c12bc4fa41a4dd3eac690d")

