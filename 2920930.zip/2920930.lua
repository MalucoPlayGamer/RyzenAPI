-- Lua provided by SkyAPI 
-- Game: Tactics Greed Demo
addappid(2920930)
addappid(2920931, 1, "8714336cb5a5070548579ff14516fe2fd6e55a0c263dec58a4d6a38860183ee6")
