-- Lua provided by RyzenAPI
-- Game: Tactics Greed Demo

-- MAIN APPLICATION
addappid(2920930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2920931, 1, "8714336cb5a5070548579ff14516fe2fd6e55a0c263dec58a4d6a38860183ee6")
