-- Lua provided by SkyAPI 
-- Game: Squirrel Launcher
addappid(2254490)
addappid(2254491, 1, "5a80bdd0d2a78d3d12a81673256633278bcba722a9cbfdbd557327e9f4ade8fc")
