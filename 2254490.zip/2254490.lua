-- Lua provided by RyzenAPI
-- Game: 2254490

-- MAIN APPLICATION
addappid(2254490)
-- Game: addappid(2254490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2254491, 1, "5a80bdd0d2a78d3d12a81673256633278bcba722a9cbfdbd557327e9f4ade8fc")
