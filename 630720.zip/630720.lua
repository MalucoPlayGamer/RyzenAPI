-- Lua provided by RyzenAPI
-- Game: Game: Mana Spark

-- MAIN APPLICATION
addappid(630720)
-- Game: addappid(630720)

-- MAIN APP DEPOTS / PACKAGES
addappid(630721, 1, "dda3c76a33a00dd6cee5da2db45569bddff50384eb447d0ceee726927f4e081e")
addappid(630722, 1, "4953c3d0c255ccc2609952012b46ae5ec37287c170c85bc53b86bf6d239ce5a0")
addappid(630723, 1, "1f47e882d053645b36c6563884503a6961aefcfba5a82c400f4e35e76d21d469")
addappid(630729, 1, "2012d8b238dab15e53803822a932ff4921c43881f97f073d4b829b8fb28a7ff2")
