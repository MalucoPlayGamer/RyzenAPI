-- Lua provided by RyzenAPI
-- Game: 611650

-- MAIN APPLICATION
addappid(611650)
-- Game: addappid(611650)

-- MAIN APP DEPOTS / PACKAGES
addappid(611651, 1, "a52b75e21e12e3fbca5aadfebe5ff7455f370fa9f68aab0cad7f4f837ff84a1b")
