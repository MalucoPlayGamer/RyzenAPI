-- Lua provided by RyzenAPI
-- Game: 1375368

-- MAIN APPLICATION
addappid(1375368)
-- Game: addappid(1375368)

-- MAIN APP DEPOTS / PACKAGES
addappid(1375368,0,"2ec339b38bf022c49321f72b6f115df5d4daa8fe4b52902e7b692881a0971afc")
