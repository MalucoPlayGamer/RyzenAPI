-- Lua provided by RyzenAPI 
-- Game: AppID 2974800
addappid(2974800)
addappid(2974801, 1, "b971068d03a81960bf96b2d4895ecec5f24f2360e771aa5628d1901a0b03dc0c")
