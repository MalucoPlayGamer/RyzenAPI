-- Lua provided by RyzenAPI
-- Game: Fighting for Justice Episode 1

-- MAIN APPLICATION
addappid(1404030)

-- MAIN APP DEPOTS / PACKAGES
addappid(1404031, 1, "941015ce0fbe018e92f2bc1fbca8a5fd5af2231ebe70e9e8d2edc70661cb1395")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
