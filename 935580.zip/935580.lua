-- Lua provided by RyzenAPI
-- Game: True Fear: Forsaken Souls Part 2

-- MAIN APPLICATION
addappid(935580)

-- MAIN APP DEPOTS / PACKAGES
addappid(935581, 1, "5189384649509bf26954427f07053444bf283a875495d79dfd4897d265b3ed26")

