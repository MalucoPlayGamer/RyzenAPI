-- Lua provided by RyzenAPI
-- Game: addappid(1476690)

-- MAIN APPLICATION
addappid(1476690)

-- MAIN APP DEPOTS / PACKAGES
addappid(1476691, 1, "3ae83c307f9ee03cef9f587f8109161f11fe3c228e439c1e5f52a3520d55b5c6")
