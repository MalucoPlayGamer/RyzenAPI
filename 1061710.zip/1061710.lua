-- Lua provided by RyzenAPI
-- Game: AppID 1061710

-- MAIN APPLICATION
addappid(1061710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1061711, 1, "1f995ce7ac8d4e67ad2b0c841b9c3bd2b42f8a9de26453b3a0dba0943f100b9f")

