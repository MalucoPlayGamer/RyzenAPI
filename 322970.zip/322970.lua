-- Lua provided by RyzenAPI
-- Game: Subject 13

-- MAIN APPLICATION
addappid(322970)
-- Game: addappid(322970)

-- MAIN APP DEPOTS / PACKAGES
addappid(322971, 1, "860448b367a359fd0321b09ae50d4576864ea9e57f3ca35b9e079c302a3a924a")
addappid(322972, 1, "28a62b29438a4e0cd08288e5a8677e109fcb25dbc60320ad7b3b5d03add52b85")
