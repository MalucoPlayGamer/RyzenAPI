-- Lua provided by RyzenAPI 
-- Game: SLUDGE LIFE: The BIG MUD Sessions
addappid(2494930)
addappid(2494931, 1, "518bc304102582ac79ed50f7e960f7c8014ea5d64922a4b3ecbe0521d0487243")
