-- Lua provided by RyzenAPI
-- Game: Game: SLUDGE LIFE: The BIG MUD Sessions

-- MAIN APPLICATION
addappid(2494930)
-- Game: addappid(2494930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2494931, 1, "518bc304102582ac79ed50f7e960f7c8014ea5d64922a4b3ecbe0521d0487243")
