-- Lua provided by RyzenAPI
-- Game: Game: AppID 3684860

-- MAIN APPLICATION
addappid(3684860)
-- Game: addappid(3684860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3684861, 1, "d880e4d6a84e14cbe51601099a8cea1ea1bb4cbb2f474db46fef82d46ab8e2fd")
