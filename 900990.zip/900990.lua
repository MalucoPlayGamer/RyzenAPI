-- Lua provided by RyzenAPI
-- Game: Hentai Sokoban

-- MAIN APPLICATION
addappid(900990)

-- MAIN APP DEPOTS / PACKAGES
addappid(900991, 1, "565f73fe0aa5e75b9d4aaadd52e821d96e5a6fbfa81eeb8caee47c184d664ac1")

