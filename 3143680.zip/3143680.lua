-- Lua provided by RyzenAPI
-- Game: addappid(3143680)

-- MAIN APPLICATION
addappid(3143680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3143681, 1, "d17861e70c2f536018b104f1d55b645f88862ce2cfaba996d53e6eef389ec071")
