-- Lua provided by RyzenAPI
-- Game: AppID 1085630

-- MAIN APPLICATION
addappid(1085630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1085631, 1, "c080b00d2f5a3e42dd82190353c211db629a1ce1e34564f4a651615db78b1519")

