-- Lua provided by SkyAPI 
-- Game: Planet Alcatraz
addappid(289420)
addappid(289421, 1, "96c2086330ed1abd6113f3e003c6151d437f74b046d46a30a789865a5e0d9c05")
addappid(289422, 1, "2cc184db111cb611de9d9007dbe7172df9da2c3d3938a0806887c7e3a2c00014")
