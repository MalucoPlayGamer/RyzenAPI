-- Lua provided by RyzenAPI
-- Game: Game: Samurai Creator

-- MAIN APPLICATION
addappid(2098650)
-- Game: addappid(2098650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2098651, 1, "5490ebad3416d90d4fdf9f897c386c9048a5e775b6823ab4d6f3af727b16ca86")
addappid(2098652, 1, "c55d425574ff30fe3ae88252e3278289679dcd1f9f35e0852df83655453b5ef4")
addappid(2098653, 1, "a128971a1ab904eb5b7de3c134402d752b8a2adb2c3b95ee5f0f147c9bcac8a1")
