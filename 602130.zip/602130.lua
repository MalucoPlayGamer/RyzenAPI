-- Lua provided by RyzenAPI
-- Game: AppID 602130

-- MAIN APPLICATION
addappid(602130)

-- MAIN APP DEPOTS / PACKAGES
addappid(602131, 1, "36c5edc3c519c89e79477035c8a51ed5b6f57ac64de2fe87522a2dd51ef4c927")
