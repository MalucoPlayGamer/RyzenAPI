-- Lua provided by RyzenAPI
-- Game: Future Love Space Machine

-- MAIN APPLICATION
addappid(946110)

-- MAIN APP DEPOTS / PACKAGES
addappid(946111, 1, "8bbcbf9d5b5166bfff58a9cbd1bf10b4a1a3ebbcd6276cbc6f9888bf0f32598e")

