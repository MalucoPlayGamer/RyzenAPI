-- Lua provided by RyzenAPI 
-- Game: Disney Villains Cursed Café
addappid(2439220)
addappid(2439221, 1, "ce02eeb0bd6725ea11789fa393c9820e5593a07a3f74d67f6d8f992034df1308")
