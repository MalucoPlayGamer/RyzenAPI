-- Lua provided by SkyAPI 
-- Game: Bitcoin VS Brain
addappid(817110)
addappid(817111, 1, "c5274247f0a501029100293c03f5d3e959a60295f5167293a20bff90522736bd")
addappid(817730)
