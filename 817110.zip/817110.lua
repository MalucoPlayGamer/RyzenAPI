-- Lua provided by RyzenAPI
-- Game: Bitcoin VS Brain

-- MAIN APPLICATION
addappid(817110)
addappid(817730)

-- MAIN APP DEPOTS / PACKAGES
addappid(817111, 1, "c5274247f0a501029100293c03f5d3e959a60295f5167293a20bff90522736bd")

