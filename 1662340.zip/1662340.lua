-- Lua provided by RyzenAPI
-- Game: addappid(1662340)

-- MAIN APPLICATION
addappid(1662340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1662341, 1, "8c3f0c09c2438336f60411f1bae679ac23dfaac5ea8679d4e37169ba64498d65")
