-- Lua provided by RyzenAPI
-- Game: 봇치필드 Playtest

-- MAIN APPLICATION
addappid(2722020)
-- Game: addappid(2722020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2722021, 1, "e6b9b335fa3fdb7d51475f083fae2c824cd02aaf12b14a5342818fa053d70e0d")
