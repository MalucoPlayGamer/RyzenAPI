-- Lua provided by RyzenAPI 
-- Game: PAPER BIRDS
addappid(1752810)
addappid(1752811, 1, "9c9b0f20793db635cf1b6c5d57e73f07304a6a6d8322ee8f0b71d02f6c4ab63d")
