-- Lua provided by RyzenAPI
-- Game: PAPER BIRDS

-- MAIN APPLICATION
addappid(1752810)
-- Game: addappid(1752810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1752811, 1, "9c9b0f20793db635cf1b6c5d57e73f07304a6a6d8322ee8f0b71d02f6c4ab63d")
