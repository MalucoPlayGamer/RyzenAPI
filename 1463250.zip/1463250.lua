-- Lua provided by RyzenAPI
-- Game: addappid(1463250)

-- MAIN APPLICATION
addappid(1463250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1463250,0,"0eac812753bffacd14cd82dc3579c61d344eefa25c55c6221ea4553cd5f24228")
addappid(1463252,0,"53cbfbb54c94d691acd8cb39567eaa0d457a277472ebdba247a0930c48e526e2")
