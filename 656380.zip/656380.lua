-- Lua provided by RyzenAPI
-- Game: Chicken Daddy

-- MAIN APPLICATION
addappid(656380)

-- MAIN APP DEPOTS / PACKAGES
addappid(656381, 1, "4b84517650a890d2d94b970f6277c085be7c789964ecd18f3b8bf4cd8eb61439")

