-- Lua provided by RyzenAPI
-- Game: Operation: Polygon Storm

-- MAIN APPLICATION
addappid(2310160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2310161, 1, "d9e66eb033b40fd60533dc60970313ca9fa354a0c6edcb559cffea6b9094d0ed")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3124490)
addappid(3216920)
addappid(3280600)
addappid(3280610)
