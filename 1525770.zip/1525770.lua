-- Lua provided by RyzenAPI
-- Game: The Dark Side of the Moon: An Interactive FMV Thriller

-- MAIN APPLICATION
addappid(1525770)
-- Game: addappid(1525770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1525771, 1, "69333ff5c9580b04ba2e855bffd132467bf8699de62d5ca8783a67aabecfe815")
