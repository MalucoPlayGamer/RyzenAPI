-- Lua provided by RyzenAPI
-- Game: addappid(1525770)

-- MAIN APPLICATION
addappid(1525770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1525771, 1, "69333ff5c9580b04ba2e855bffd132467bf8699de62d5ca8783a67aabecfe815")
