-- Lua provided by RyzenAPI
-- Game: addappid(2283030)

-- MAIN APPLICATION
addappid(2283030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2283031, 1, "8e69040b2ac553a20b4b6948fe9ef666fcb4e8c6a9ab9b207d5466d38dcb2b56")
