-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(1771597)
-- Game: addappid(1771597)

-- MAIN APP DEPOTS / PACKAGES
addappid(1771597,0,"c28ae73ccc2c9ae36f300671ca5068b0bff12ce51d0efb1368c95d0f8c780b05")
