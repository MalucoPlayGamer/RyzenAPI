-- Lua provided by RyzenAPI
-- Game: Game: Extravaganza Rising

-- MAIN APPLICATION
addappid(501030)
-- Game: addappid(501030)

-- MAIN APP DEPOTS / PACKAGES
addappid(501031, 1, "e2b5d38d66a2944b6b94975cfeaffca3556e78f474fd1531aa01fbff0d3a92da")
addappid(501460, 0, "c531f610b576697035924ea077d558f0412205e7883953f149f6c374d528fadd")
