-- Lua provided by RyzenAPI
-- Game: Backrooms Cats and Lava

-- MAIN APPLICATION
addappid(3015110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3015111, 1, "5ac73005fed47087d352b405b363da10ffb5ecfd020429823589b907d5f7ad46")
