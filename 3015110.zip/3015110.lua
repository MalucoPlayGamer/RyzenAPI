-- Lua provided by SkyAPI 
-- Game: Backrooms Cats and Lava
addappid(3015110)
addappid(3015111, 1, "5ac73005fed47087d352b405b363da10ffb5ecfd020429823589b907d5f7ad46")
