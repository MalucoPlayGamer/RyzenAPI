-- 4438540's Lua and Manifest Created by Hubcap Manifest
-- Limitless Survivor
-- Created: July 24, 2026 at 06:09:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4438540) -- Limitless Survivor
-- MAIN APP DEPOTS
addappid(4438541, 1, "4f1666d3ab2d0c8b2a6b090215e3f522efdc91ad4218d42ff93b6e63205713fe") -- Depot 4438541
setManifestid(4438541, "933737311721677239", 516213218)