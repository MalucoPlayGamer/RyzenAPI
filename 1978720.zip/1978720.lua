-- Lua provided by RyzenAPI
-- Game: addappid(1978720)

-- MAIN APPLICATION
addappid(1978720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978721, 1, "c96e53b578cd0f6a533c9d82aef22990c5d8ae7a0625cbfad49bd3a0eff808fc")
addappid(2436880, 0, "30aabeca75c1a99444db3744e3942f2c04c85f0af6b3992ecb7ed504010c670e")
addappid(2444360, 0, "57265a62990b1959b8bf9ed272e37da31fdf2580937dfc340e5ceaf52af97e3e")
