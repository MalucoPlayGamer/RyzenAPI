-- Lua provided by RyzenAPI
-- Game: Ultimate Ragdoll Game

-- MAIN APPLICATION
addappid(1978720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978721, 1, "c96e53b578cd0f6a533c9d82aef22990c5d8ae7a0625cbfad49bd3a0eff808fc")
addappid(2436880, 0, "30aabeca75c1a99444db3744e3942f2c04c85f0af6b3992ecb7ed504010c670e")
addappid(2444360, 0, "57265a62990b1959b8bf9ed272e37da31fdf2580937dfc340e5ceaf52af97e3e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
