-- Lua provided by RyzenAPI
-- Game: Divided Reigns

-- MAIN APPLICATION
addappid(1139160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1139161, 1, "3246e651cccfdc54d6b7c22578823018c88460aeae7b9b05b58a0f837c07e5e5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
