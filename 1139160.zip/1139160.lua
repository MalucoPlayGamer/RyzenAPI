-- Lua provided by RyzenAPI
-- Game: Divided Reigns

-- MAIN APPLICATION
addappid(1139160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1139161, 1, "3246e651cccfdc54d6b7c22578823018c88460aeae7b9b05b58a0f837c07e5e5")
