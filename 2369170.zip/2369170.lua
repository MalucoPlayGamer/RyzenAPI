-- Lua provided by SkyAPI 
-- Game: Dominus Solaris
addappid(2369170)
addappid(2369171, 1, "d16df454f32c1bc59c0219860db7eb9337f4211825daae3a3e9dd8e3d6129909")
