-- Lua provided by RyzenAPI
-- Game: Game: Marshmallow Imouto Succubus

-- MAIN APPLICATION
addappid(2243980)
-- Game: addappid(2243980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2243981, 1, "55353c7bdce04fca0ca937bac5fdbc212bb04b123add838eb7654d610d2a5d46")
addappid(2243984, 1, "0bc1e306b9404a40a5079d621b99671a8d6fee89b06b28896b1fe2469e460f6f")
addappid(2243985, 1, "121f466a6ad8091c1d51c543819d0b6eb157fc9ea024c4208513e476df97e3e5")
