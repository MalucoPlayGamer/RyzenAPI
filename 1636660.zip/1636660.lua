-- Lua provided by RyzenAPI
-- Game: Absolute Tactics: Daughters of Mercy

-- MAIN APPLICATION
addappid(1636660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1636661, 1, "ac62b377285e972ad8f5a4b56b873ad9d143af3c9648d3172c0cd930385f180a")
addappid(2148580, 0, "6357a2b3dd1b878881f491d8bd0c2008914c09be29ec589bb7cee19024a6319a")

