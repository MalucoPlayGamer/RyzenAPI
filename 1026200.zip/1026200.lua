-- Lua provided by RyzenAPI
-- Game: AppID 1026200

-- MAIN APPLICATION
addappid(1026200)
-- Game: addappid(1026200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1026201, 1, "4ba998ce78292a5cc7918205006b4d090c2ebbff29a7c0a6835bdbe298b1927a")
