-- Lua provided by RyzenAPI
-- Game: AppID 299720

-- MAIN APPLICATION
addappid(299720)
-- Game: addappid(299720)

-- MAIN APP DEPOTS / PACKAGES
addappid(299721, 1, "7e6ae37f650e6adb896a88937aceeb438dc6d35b438026d2acd384ceff48aff4")
