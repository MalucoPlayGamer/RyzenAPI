-- Lua provided by RyzenAPI
-- Game: SYNTHROME

-- MAIN APPLICATION
addappid(3308280)
-- Game: addappid(3308280)

-- MAIN APP DEPOTS / PACKAGES
addappid(3308281, 1, "bc7aa853c7c1b79aa041ef51055fa8fef0b3b2ab316e6ab90ae7de3f666e5a37")
