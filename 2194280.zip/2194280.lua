-- Lua provided by RyzenAPI
-- Game: FAITH Soundtrack

-- MAIN APPLICATION
addappid(2194280)
-- Game: addappid(2194280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2194281, 1, "1af19244370309ffd5c814e46d1e8214708d9cac2cc724e5b1319ec2bb9734c1")
