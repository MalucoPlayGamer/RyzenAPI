-- Lua provided by RyzenAPI
-- Game: 超级机霸(Super Ship Blaster)

-- MAIN APPLICATION
addappid(2564370)
-- Game: addappid(2564370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564371, 1, "fe0effb409b1532839db79fdcd6906570c387e693c48014b358fc235ea688273")
