-- Lua provided by RyzenAPI
-- Game: 403390

-- MAIN APPLICATION
addappid(403390)
-- Game: addappid(403390)

-- MAIN APP DEPOTS / PACKAGES
addappid(403391, 1, "70564b6f1b1da32230113db3e826d9f3a46a2ab04e36bd75f832279e3fabdca8")
addappid(403392, 1, "f16cfd937e070a392e99b75b2b43f387369e21460afa2b56f939293b6eeaa314")
