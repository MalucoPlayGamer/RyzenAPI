-- Lua provided by RyzenAPI
-- Game: AppID 403390

-- MAIN APPLICATION
addappid(403390)

-- MAIN APP DEPOTS / PACKAGES
addappid(403391, 1, "70564b6f1b1da32230113db3e826d9f3a46a2ab04e36bd75f832279e3fabdca8")
addappid(403392, 1, "f16cfd937e070a392e99b75b2b43f387369e21460afa2b56f939293b6eeaa314")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
