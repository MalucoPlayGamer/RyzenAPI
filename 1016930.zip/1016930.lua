-- Lua provided by RyzenAPI
-- Game: Game: The Great Perhaps

-- MAIN APPLICATION
addappid(1016930)
-- Game: addappid(1016930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1016931, 1, "bba4eb0602c35454dfc7888994bbcfa4e711801c080466e6fcd6c306b1b21b20")
addappid(1016932, 1, "098e987bf24197e4650fc57855605564f9d6eb4c5143aa088ec4a82aae7f65b5")
addappid(1016933, 1, "9083129a8fd06641380135fd2176e07ba335fdb2aa541d68d1ac662bd1c7937e")
