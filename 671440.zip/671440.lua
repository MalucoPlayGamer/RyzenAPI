-- Lua provided by RyzenAPI
-- Game: Rise of Industry

-- MAIN APPLICATION
addappid(671440)
addappid(1139110)
addappid(1182960)

-- MAIN APP DEPOTS / PACKAGES
addappid(671441, 1, "de9691a2111fe56b81e65c36ffba91a1332de01bcdd76f9dec6d750ffb4a9bc9")
addappid(671442, 1, "aac43b29290670431a0c5ec5e6473f196071385a94f3bf5ff74d34e1f1430ef8")
addappid(671443, 1, "88136e40916bacb39c1f52d3edb7c9f41b774f84bb27cf0e446162013a378d6d")
addappid(938410, 0, "277db92987adfefa22356d53c7419a799cbc29d37424028942f9c5e1c2102120")

