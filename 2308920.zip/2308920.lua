-- Lua provided by RyzenAPI 
-- Game: Classic Car Simulator: Car Driving
addappid(2308920)
addappid(2308921, 1, "8bc8ce0577b3ec25cd829652a730512bc4ac21447b42a2481ff8f3081c9f2d77")
