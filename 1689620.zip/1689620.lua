-- Lua provided by RyzenAPI
-- Game: BLEACH Rebirth of Souls

-- MAIN APPLICATION
addappid(1689620)
addappid(3203740)
addappid(3203760)
addappid(3203770)
addappid(3203780)
addappid(3203790)
addappid(3203800)
addappid(3203820)
addappid(3203830)
addappid(3203840)
addappid(3203850)
addappid(3203940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1689621,0,"7ff1d0c9c2aea56e2337ba3c85dbf96f3e436b64f4845764d78eb97ad681181c")

