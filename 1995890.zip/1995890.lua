-- Lua provided by RyzenAPI
-- Game: Aerofly FS 4 Flight Simulator

-- MAIN APPLICATION
addappid(1995890)
-- Game: addappid(1995890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995891, 1, "6b3fc84d7a24d7f4f5800f84e73fc89f7275ff8bfa94b69a314bbbe76ac6d0aa")
addappid(1995892, 1, "c9b76fb78a8d79befbc40588f17cc0a75f7e285632757b8e95896d92d8da32fd")
addappid(2011820, 0, "a3aafe378aacd12baecdc6110da2ccb468a4d6b811baa533b4e45b2a414746e2")
addappid(2011821, 0, "63de99f8ff14b6e07d0222b0ad3f695b5de557160e985d6d2788d1e47c64f417")
addappid(2011823, 0, "216bb04f7293134916c04d64440c4196d6c6554b9ad796ac8052e8f3bffdaef0")
addappid(2011824, 0, "c56b60b3da1ca6c3e381453f98850e96ea4050ef93950d15c11db2135c629629")
