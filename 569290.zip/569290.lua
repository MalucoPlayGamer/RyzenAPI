-- Lua provided by RyzenAPI
-- Game: Metamorfose S

-- MAIN APPLICATION
addappid(569290)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(569291, 1, "21b51041a3f6156999241b29a050b2c33873f0258def3388d6e9c22e1d2a203c")

