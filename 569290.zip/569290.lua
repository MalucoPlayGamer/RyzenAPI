-- Lua provided by RyzenAPI
-- Game: Metamorfose S

-- MAIN APPLICATION
addappid(569290)
-- Game: addappid(569290)

-- MAIN APP DEPOTS / PACKAGES
addappid(569291, 1, "21b51041a3f6156999241b29a050b2c33873f0258def3388d6e9c22e1d2a203c")
