-- Lua provided by RyzenAPI
-- Game: East India Company: Privateer

-- MAIN APPLICATION
addappid(42800)
-- Game: addappid(42800)

-- MAIN APP DEPOTS / PACKAGES
addappid(42801, 1, "4e33aa9ac4db311c1ab45ee8e47a1102af58b49b14db8b7128a86a40fe9c4869")
