-- Lua provided by RyzenAPI
-- Game: 2353340

-- MAIN APPLICATION
addappid(2353340)
-- Game: addappid(2353340)

-- MAIN APP DEPOTS / PACKAGES
addappid(2353341, 1, "7e3d6fa9e2c1a8a445788ad9d5f3bac69c02e9a71ebef99685c4c68d126dae83")
