-- Lua provided by RyzenAPI
-- Game: addappid(596540)

-- MAIN APPLICATION
addappid(596540)

-- MAIN APP DEPOTS / PACKAGES
addappid(596541, 1, "a490f8f91fded3cb9b06b4d2057fa664d220b3b16ddab687b1c5399d190869a8")
