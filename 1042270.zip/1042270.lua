-- Lua provided by RyzenAPI
-- Game: Juicy Hentai

-- MAIN APPLICATION
addappid(1042270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1042271, 1, "2f3464c62e096c8f91ebbbafef4c17f50e224a712517ff1f9718d8f26095faf2")

