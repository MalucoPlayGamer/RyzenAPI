-- Lua provided by RyzenAPI
-- Game: AppID 1509350

-- MAIN APPLICATION
addappid(1509350)
-- Game: addappid(1509350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509351, 1, "427565584b832b5e91b2275dd95adde14af3a201492fe3864d9f6ab3a11c8516")
