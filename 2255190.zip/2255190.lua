-- Lua provided by RyzenAPI 
-- Game: FUMES Demo
addappid(2255190)
addappid(2255191, 1, "872a21382edb3e900f0ec06fd8b15fb915afac4e313bf471db7bc76f3945a03c")
