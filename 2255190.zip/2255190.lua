-- Lua provided by RyzenAPI
-- Game: Game: FUMES Demo

-- MAIN APPLICATION
addappid(2255190)
-- Game: addappid(2255190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2255191, 1, "872a21382edb3e900f0ec06fd8b15fb915afac4e313bf471db7bc76f3945a03c")
