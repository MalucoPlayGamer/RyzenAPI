-- Lua provided by RyzenAPI
-- Game: Seven: Enhanced Edition

-- MAIN APPLICATION
addappid(471010)
addappid(744871)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(471011, 1, "2412501f3787f672ed8df8818683aaa4bdca862ae9fc1d273003b2d6f158621a")
addappid(471014, 1, "b2bb436adc3c8998ba6c2e8faf0b5d62d50d437c00017250fcc839993f7d8a82")

