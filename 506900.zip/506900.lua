-- Lua provided by RyzenAPI
-- Game: 506900

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(229002)
addappid(506900)
-- Game: addappid(506900)

-- MAIN APP DEPOTS / PACKAGES
addappid(506902,0,"81c1255ccad9d60164af7a83952ec1cb351c5ec9ad5dfa97d4e274df5f1b7703")
