-- Lua provided by RyzenAPI
-- Game: Dangerous Bullets

-- MAIN APPLICATION
addappid(575770)
-- Game: addappid(575770)

-- MAIN APP DEPOTS / PACKAGES
addappid(575771, 1, "c5599d5da7a120e1bab4321b65f04e49ddcd2f0b3c1c16f5795c52229d4b0bba")
