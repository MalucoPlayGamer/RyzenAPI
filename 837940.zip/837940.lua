-- Lua provided by RyzenAPI
-- Game: Mobile Forces

-- MAIN APPLICATION
addappid(837940)

-- MAIN APP DEPOTS / PACKAGES
addappid(837941, 1, "6774e9bb9c23f741ee88c62bd41e590b3d4bae729e21ca782420fa43886dcfe0")
