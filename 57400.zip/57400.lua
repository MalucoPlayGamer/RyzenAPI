-- Lua provided by RyzenAPI
-- Game: Batman: Arkham City

-- MAIN APPLICATION
addappid(57400)
addappid(200770)
addappid(200780)
addappid(200790)
addappid(200800)
addappid(200810)
addappid(200820)
addappid(200830)
addappid(200840)
addappid(200850)
addappid(200870)
addappid(200880)
addappid(200891)

-- MAIN APP DEPOTS / PACKAGES
addappid(57401, 1, "8feb471e5e430cc44617e3d5d402a5e45ddc5a4da1ef2833a0f94231ece6dd6a")
addappid(200860, 0, "fc8493faa2ba8c15fb55601acd81443e28a5c04f97c61da8bf2b8c7bb1ad8751")
addappid(200890, 0, "54bf07aa4c0d2d26e1c261f95f6034e3bd938b3aa38bbb5ca34423f7e38e86f2")

