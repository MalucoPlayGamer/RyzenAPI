-- Lua provided by RyzenAPI
-- Game: Game: The Spirit Master of Retarnia -Conqueror of the Labyrinth-

-- MAIN APPLICATION
addappid(975020)
-- Game: addappid(975020)

-- MAIN APP DEPOTS / PACKAGES
addappid(975021, 1, "E7D7E171B07AE1CEBC07A005E641576AF1B3F6A450E5D46D1F24E755F65D31A0")
