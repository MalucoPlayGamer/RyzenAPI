-- Lua provided by RyzenAPI
-- Game: addappid(1607780)

-- MAIN APPLICATION
addappid(1607780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1607781, 1, "25708908e02319b2efd77f27b193f2fd1eea0aaba617a22c765fa8a79452baf6")
