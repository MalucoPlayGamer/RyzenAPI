-- Lua provided by RyzenAPI
-- Game: Put Your Stamp On

-- MAIN APPLICATION
addappid(2183480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2183481, 1, "11f3fd3e46a2ad1e2cb219ab4e1f59052b08116ca31f324cfeae3d6eb353072b")

