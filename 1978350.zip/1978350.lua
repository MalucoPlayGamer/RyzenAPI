-- Lua provided by SkyAPI 
-- Game: Friendly Blonding
addappid(1978350)
addappid(1978351, 1, "6688dc7f89959953f2d15bbe34b1989d0ad60142c63afddd7286077ce720cf69")
