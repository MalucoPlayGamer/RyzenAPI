-- Lua provided by RyzenAPI
-- Game: Friendly Blonding

-- MAIN APPLICATION
addappid(1978350)
-- Game: addappid(1978350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1978351, 1, "6688dc7f89959953f2d15bbe34b1989d0ad60142c63afddd7286077ce720cf69")
