-- Lua provided by SkyAPI 
-- Game: Interplanetary Gardener
addappid(1622560)
addappid(1622561, 1, "ab004120b19e6d5b3a27904fb90e974bd505ec5674db838d7580814c1358477c")
