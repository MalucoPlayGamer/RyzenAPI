-- Lua provided by RyzenAPI 
-- Game: Chill II
addappid(1041140)
addappid(1041141, 1, "b0379c5ed846e68629068b315db4e4f9b3459f35636366bc0e753aa8af2e2706")
