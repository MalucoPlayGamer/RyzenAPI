-- Lua provided by RyzenAPI 
-- Game: SPIRITGRAPHER: THE ASYLUM 99
addappid(3137910)
addappid(3137911, 1, "7069dc84b165e736c134b42fe622233df6b7527e14326c9dd95bd2bd6e395161")
