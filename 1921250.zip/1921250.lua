-- Lua provided by RyzenAPI
-- Game: Splinters of Regret

-- MAIN APPLICATION
addappid(1921250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921251, 1, "ee5dc3696e67796d9cfad40549c5d5d35b215a299f50441b179be88eca71f653")
