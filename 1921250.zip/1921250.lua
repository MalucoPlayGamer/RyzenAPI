-- Lua provided by RyzenAPI
-- Game: Splinters of Regret

-- MAIN APPLICATION
addappid(1921250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1921251, 1, "ee5dc3696e67796d9cfad40549c5d5d35b215a299f50441b179be88eca71f653")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
