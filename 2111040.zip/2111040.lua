-- Lua provided by RyzenAPI
-- Game: Dead Beacon

-- MAIN APPLICATION
addappid(2111040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2111041, 1, "ed55948f6690be7dca96fde3ff38ddc387c5c9209bc05888df2f1c036455e447")
