-- Lua provided by RyzenAPI
-- Game: Totally Accurate Battle Simulator

-- MAIN APPLICATION
addappid(508440)
-- Game: addappid(508440)

-- MAIN APP DEPOTS / PACKAGES
addappid(508443,0,"6de3434d18886e0ff07614c02781c1f625e189a4a9833e36f4287f77443ce44c")
addappid(508444,0,"c831d684196d21677fc279e01f064dd989c00c2f5c4975b0c58793fd71c1f3f9")
