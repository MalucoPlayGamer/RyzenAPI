-- Lua provided by RyzenAPI 
-- Game: Travel with dinosaurs
addappid(3807520)
addappid(3807521, 1, "a7313100a23e8d3d5aca3d3b32240526adefb2eccc87f0e18f762bb96d3e829a")
