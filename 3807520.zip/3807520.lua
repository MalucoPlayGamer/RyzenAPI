-- Lua provided by RyzenAPI
-- Game: 3807520

-- MAIN APPLICATION
addappid(3807520)
-- Game: addappid(3807520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3807521, 1, "a7313100a23e8d3d5aca3d3b32240526adefb2eccc87f0e18f762bb96d3e829a")
