-- Lua provided by RyzenAPI
-- Game: 美少女幸存者 Demo

-- MAIN APPLICATION
addappid(2222040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2222041, 1, "530ac20a81d92ec0bc9df7c4af9288b89d2a41bc6bd83041ba8263014faca185")
