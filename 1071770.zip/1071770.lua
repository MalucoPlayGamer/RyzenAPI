-- Lua provided by RyzenAPI 
-- Game: Princess's Peak
addappid(1071770)
addappid(1071771, 1, "b622c0eb3786f25434a890e7631b65fb724a34e4af5134ece3cbbbd20edb5ff9")
addappid(1079880, 0, "a27088b82d7da6d1f107ac0d26eb485ae7eed395b69e82d57bf9c96dd54ca00f")
