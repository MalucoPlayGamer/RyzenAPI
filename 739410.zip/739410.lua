-- Lua provided by SkyAPI 
-- Game: Zorbit's Orbits
addappid(739410)
addappid(739411, 1, "dbea1f3bfc5dd2bb7b7c68beebec1a4d1dcf3dea56b9a82d9592a4793b88d906")
