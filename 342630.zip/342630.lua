-- Lua provided by RyzenAPI
-- Game: Game: AppID 342630

-- MAIN APPLICATION
addappid(342630)
-- Game: addappid(342630)

-- MAIN APP DEPOTS / PACKAGES
addappid(342631, 1, "228873a1982e2a9164b1be1f23d2234264e35f70d6ad7cea0f4420cf1f52cd62")
addappid(342632, 1, "344b17c54cad3cc30c454637e2fe3b1995154c0dd87a4fa706053ead8ec92bed")
