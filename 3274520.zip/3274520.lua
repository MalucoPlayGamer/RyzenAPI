-- Lua provided by RyzenAPI
-- Game: Game: AppID 3274520

-- MAIN APPLICATION
addappid(3274520)
-- Game: addappid(3274520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3274521, 1, "a353148cf8c6edec6f44a0b6999f896f38bc8aadec0ebf27264ebc8c355f8b80")
