-- Lua provided by RyzenAPI
-- Game: 2395690

-- MAIN APPLICATION
addappid(2395690)
-- Game: addappid(2395690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2395691, 1, "728008dc7ec4b8d1cd44bf484b1e78d751d71221d0b42db00d8427790a1e441a")
