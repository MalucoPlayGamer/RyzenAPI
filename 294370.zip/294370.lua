-- Lua provided by RyzenAPI
-- Game: Crowntakers

-- MAIN APPLICATION
addappid(294370)
addappid(327810)
addappid(352560)

-- MAIN APP DEPOTS / PACKAGES
addappid(294371, 1, "f7493d89debfdc80bcad51186580dde6ec171507edf4a10a1ac7602a978826ed")
addappid(294372, 1, "4295357bead94088c37e41e2f3bd2a74b3bfad8c2cf47c62db47b173cc06daa9")
addappid(294373, 1, "207f4277b3db67f37421ad7b91543f8673f0812340c391a2e47d6837c4c079a5")

