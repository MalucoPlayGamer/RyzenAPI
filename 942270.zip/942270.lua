-- Lua provided by RyzenAPI
-- Game: Game: AppID 942270

-- MAIN APPLICATION
addappid(942270)
-- Game: addappid(942270)

-- MAIN APP DEPOTS / PACKAGES
addappid(942271, 1, "81930638cac415e5688b6225409606317d58eddc8f71b6a7076b42a876b5d0f7")
addappid(942272, 1, "7235851b1c4cefc862f1e4004c253ebdb0dbacf9bb8746957d67b762e35acd07")
addappid(942273, 1, "171fe6bb8bbbeb9e85a10ebd7d00fcf9f21f877259e439c9ae3801d8054dc3d6")
