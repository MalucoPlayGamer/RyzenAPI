-- Lua provided by RyzenAPI
-- Game: Game: AppID 703480

-- MAIN APPLICATION
addappid(703480)
-- Game: addappid(703480)

-- MAIN APP DEPOTS / PACKAGES
addappid(703481, 1, "b903cecd47a7aa24452628193473057dd4f489479bd455ab3d247e6706255464")
