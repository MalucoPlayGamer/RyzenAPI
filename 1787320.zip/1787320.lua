-- Lua provided by RyzenAPI
-- Game: The Atlas Mystery: A VR Puzzle Game

-- MAIN APPLICATION
addappid(1787320)
-- Game: addappid(1787320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787321, 1, "d9dd7cf9446c9dcd568521b0f213c28346a1f0ab3680a2b876da97ceed50d05d")
