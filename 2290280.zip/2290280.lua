-- Lua provided by RyzenAPI
-- Game: Game: 3D Whac-A-Mole

-- MAIN APPLICATION
addappid(2290280)
-- Game: addappid(2290280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2290281, 1, "98bbdc30b91121862e68379592c03f5c8f1f209d5f9b4b242ed52a961c66b7e5")
