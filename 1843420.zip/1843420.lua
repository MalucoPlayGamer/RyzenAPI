-- Lua provided by RyzenAPI
-- Game: Motorcycle Travel Simulator

-- MAIN APPLICATION
addappid(1843420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1843421, 1, "8fc644a4f48db6324255941a1cf1c8449f933f5163d98ccda25294cd8b59bd0d")

