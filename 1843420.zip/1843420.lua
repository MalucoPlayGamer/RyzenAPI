-- Lua provided by SkyAPI 
-- Game: Motorcycle Travel Simulator
addappid(1843420)
addappid(1843421, 1, "8fc644a4f48db6324255941a1cf1c8449f933f5163d98ccda25294cd8b59bd0d")
