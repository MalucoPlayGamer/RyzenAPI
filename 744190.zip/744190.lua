-- Lua provided by RyzenAPI
-- Game: Rusty Lake Paradise

-- MAIN APPLICATION
addappid(744190)

-- MAIN APP DEPOTS / PACKAGES
addappid(744191, 1, "23c8d767c0f6eb65130f7f4d1b17a821c73ab08520411c785db71584d920f51e")
addappid(744192, 1, "2ac800bc1a523ae8e3329b743e19e716f4ec3149444f7c2d3e2b9b90b083999f")

