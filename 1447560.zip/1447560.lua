-- Lua provided by RyzenAPI
-- Game: addappid(1447560)

-- MAIN APPLICATION
addappid(1447560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1447561, 1, "13748b06634d13627ad48f0644ff1be49cb8840dee9cbee99c50e23fc65b0c97")
