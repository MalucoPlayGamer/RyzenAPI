-- Lua provided by RyzenAPI
-- Game: 2282630

-- MAIN APPLICATION
addappid(2282630)
-- Game: addappid(2282630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2282631, 1, "b08220cec5086cf478e83b9f254b95bc39192132e5c9931d9df3bcba1795ab44")
