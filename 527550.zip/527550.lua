-- Lua provided by RyzenAPI
-- Game: Platro

-- MAIN APPLICATION
addappid(527550)

-- MAIN APP DEPOTS / PACKAGES
addappid(527551, 1, "10d77055baaf795b36bcc77c0935eabcbfc4da17c5932075653a171e9b686755")

