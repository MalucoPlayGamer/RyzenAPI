-- Lua provided by RyzenAPI
-- Game: Game: AppID 1415220

-- MAIN APPLICATION
addappid(1415220)
-- Game: addappid(1415220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1415221, 1, "7bcfc6534e16f9029eb0195388fb1984a1644727d944b4a6eb9e94cae153228b")
