-- Lua provided by RyzenAPI
-- Game: Game: A Simple Garbage Sorting Game

-- MAIN APPLICATION
addappid(3384180)
-- Game: addappid(3384180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3384181, 1, "9ea8ac95aae465220264ff00ede6cd6ff84bc3ac45e72bb09512f0f779cc41ec")
