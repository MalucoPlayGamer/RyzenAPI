-- Lua provided by RyzenAPI
-- Game: A Simple Garbage Sorting Game

-- MAIN APPLICATION
addappid(3384180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3384181, 1, "9ea8ac95aae465220264ff00ede6cd6ff84bc3ac45e72bb09512f0f779cc41ec")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
