-- Lua provided by RyzenAPI 
-- Game: ATC Ground Point
addappid(3239550)
addappid(3239551, 1, "c8cf68ff7c5f23849eec1b5532e7f9d718d4cb397a5b398b9894d8b46a99aa8f")
