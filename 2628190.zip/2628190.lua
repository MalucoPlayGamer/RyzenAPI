-- Lua provided by SkyAPI 
-- Game: 东方希莲船 ~ Ultimate Fatal Octopus
addappid(2628190)
addappid(2628191, 1, "3324f24c2ac6523f23bb1f2142641f252d31147a9461442ae0f9a4c1babb322e")
