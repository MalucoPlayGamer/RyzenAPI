-- Lua provided by RyzenAPI
-- Game: addappid(661480)

-- MAIN APPLICATION
addappid(661480)

-- MAIN APP DEPOTS / PACKAGES
addappid(661482,0,"1a7123dd7b04731905b746da80b418bffe679ea6647f8142e94420bac1b8143e")
