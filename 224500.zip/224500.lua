-- Lua provided by RyzenAPI
-- Game: addappid(224500)

-- MAIN APPLICATION
addappid(224500)
addappid(229003)
addappid(229012)

-- MAIN APP DEPOTS / PACKAGES
addappid(224501, 1, "5b708f35582b8e2b8f3a0c03f711c0bd30f503062c31a1a3745ecf4bd9e628fb")
addappid(224502, 1, "c66e1a8dd1775a43448f659d9852c57a0a53d63c23933f6a954e1a002ceed500")
addappid(224503, 1, "231e7bf1ce0f2f20a0bde675c85d7e3c116b2b9f7ab2ebe8843f0966692affe7")
