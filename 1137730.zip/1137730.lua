-- Lua provided by RyzenAPI
-- Game: Game: AppID 1137730

-- MAIN APPLICATION
addappid(1137730)
-- Game: addappid(1137730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1137731, 1, "5476cea2ba4c35abe6f47757822d56d07e1d76100b012fc1d88e5df44ac32852")
addappid(1149780, 0, "fb7b30d5adfddcdd096e10fbe09741b19156a9baa7a3ebc15dcfdd8d0439b235")
addappid(1149781, 0, "3d0ec3b547e2257f48b3a13f7f3db7ad30b41fa07c987732d4a2f22136c5ba4b")
