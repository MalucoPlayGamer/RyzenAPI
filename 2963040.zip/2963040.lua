-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2963040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963040,0,"b9f7ca498c875008b1527899878fe5849ba6def31df8f091b44191df030e0866")
