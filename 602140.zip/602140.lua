-- Lua provided by SkyAPI 
-- Game: The Uncertain: VR Experience
addappid(602140)
addappid(602141, 1, "f08348e2c772ec2b5c2ee444264b67c07a14c4e980d7c7bbebd66dafcbe87ee2")
