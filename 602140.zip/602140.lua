-- Lua provided by RyzenAPI
-- Game: The Uncertain: VR Experience

-- MAIN APPLICATION
addappid(602140)

-- MAIN APP DEPOTS / PACKAGES
addappid(602141, 1, "f08348e2c772ec2b5c2ee444264b67c07a14c4e980d7c7bbebd66dafcbe87ee2")

