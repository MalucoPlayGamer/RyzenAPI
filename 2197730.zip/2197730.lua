-- Lua provided by RyzenAPI
-- Game: 2197730

-- MAIN APPLICATION
addappid(2197730)
-- Game: addappid(2197730)

-- MAIN APP DEPOTS / PACKAGES
addappid(2197731, 1, "d900f41a529aab71936b58b9ac60fa50b61748d21b2f5d39325569be53e947b7")
