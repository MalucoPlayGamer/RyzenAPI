-- Lua provided by RyzenAPI
-- Game: 343050

-- MAIN APPLICATION
addappid(343050)
-- Game: addappid(343050)

-- MAIN APP DEPOTS / PACKAGES
addappid(343051, 1, "2c52e5002a767247ff7bb75add632763dc0afe52acc5769f5d5eb6209544b7f8")
addappid(343052, 1, "fcec5bd16dfbc7de765d0a1a7af7e175878d153d572012b3381b9b9cfcff3476")
addappid(343053, 1, "4af842c155c770e5b6ac26a64aa4869f7515d7c6ffa0b812e3798290d3b17c0e")
