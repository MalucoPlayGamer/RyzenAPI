-- Lua provided by RyzenAPI
-- Game: addappid(2780820)

-- MAIN APPLICATION
addappid(2780820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2780822,0,"484cd2c7f94eaf605349aba1a7776094041b84749018baa5b96c6b02aac113b5")
