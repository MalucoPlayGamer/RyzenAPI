-- Lua provided by RyzenAPI
-- Game: Graviteam Tactics: Don Bend

-- MAIN APPLICATION
addappid(2443610)
-- Game: addappid(2443610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2443610,0,"7df9333e34fbc99b525ef5102688997db8019a559cf6f8628606970dbbcc82d1")
