-- Lua provided by RyzenAPI
-- Game: Getting Over It with Your Body

-- MAIN APPLICATION
addappid(3879730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3879731, 1, "6424a9163c081df07a7be955284b588b343093cfc1eb87709830bb3a0591aeea")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
