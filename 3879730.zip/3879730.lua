-- Lua provided by RyzenAPI
-- Game: Getting Over It with Your Body

-- MAIN APPLICATION
addappid(3879730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3879731, 1, "6424a9163c081df07a7be955284b588b343093cfc1eb87709830bb3a0591aeea")

