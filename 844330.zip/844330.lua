-- Lua provided by RyzenAPI
-- Game: addappid(844330)

-- MAIN APPLICATION
addappid(844330)

-- MAIN APP DEPOTS / PACKAGES
addappid(844331, 1, "08b32821b9b450cf84558b0d3be215f1f16793cb243690e2c66b015aa6cc92e7")
