-- Lua provided by RyzenAPI
-- Game: AppID 1479440

-- MAIN APPLICATION
addappid(1479440)
-- Game: addappid(1479440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1479441, 1, "ced94ce2d9f4756d805f95f0795dd4f8e490eab626f6ea16a56624ca52b6075b")
