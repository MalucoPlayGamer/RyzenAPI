-- Lua provided by RyzenAPI
-- Game: 3566870

-- MAIN APPLICATION
addappid(3566870)
-- Game: addappid(3566870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3566871, 1, "2227bb8586b32ec09a11ea42a9512a6886ad564163c74b395b69fd4fdef92e17")
