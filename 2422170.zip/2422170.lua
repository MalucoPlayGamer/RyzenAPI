-- Lua provided by RyzenAPI
-- Game: Game: Anonymous Messages

-- MAIN APPLICATION
addappid(2422170)
-- Game: addappid(2422170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2422171, 1, "ee7c98963dd21ae6c2100459a85a3f7d01781373cc85899e5d823634d8186507")
addappid(2422172, 1, "d350fb3c7562608c1dcb67c1e0ee2a2d425cd4007e34d23972af98050abed862")
addappid(2422173, 1, "7c15703777cac804b8bb00122edddde3eea60f592484746483a850844ce1b35e")
