-- Lua provided by RyzenAPI
-- Game: Gloria's House

-- MAIN APPLICATION
addappid(3706100)

-- MAIN APP DEPOTS / PACKAGES
addappid(3706101, 1, "59c29ccc191deff0cab0a0382a5c6a2fb097618260e4c9d325ba6259d9bd433f")

