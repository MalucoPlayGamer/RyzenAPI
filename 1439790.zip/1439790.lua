-- Lua provided by RyzenAPI
-- Game: Game: Keep Wall

-- MAIN APPLICATION
addappid(1439790)
-- Game: addappid(1439790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1439791, 1, "4c47c293705f29157c63eb672ad3ea9776367b55ea0e6650d21afe4089674507")
