-- Lua provided by RyzenAPI
-- Game: Dr. Yaga Lost House

-- MAIN APPLICATION
addappid(3149310)
-- Game: addappid(3149310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3149311, 1, "0cb5290b031a48f330aaf5577fc00c240423dd60c36e4d0db1f41a49145824d4")
