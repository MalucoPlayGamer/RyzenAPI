-- Lua provided by RyzenAPI
-- Game: 2478500

-- MAIN APPLICATION
addappid(2478500)
-- Game: addappid(2478500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478501, 1, "aa7bb6d7b0e096bd53dcc354c85f276fa47dda165d6c29f43d1d5efca3e38415")
