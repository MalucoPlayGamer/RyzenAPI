-- Lua provided by RyzenAPI
-- Game: Game: MUMBA IV: Egypt Jewels

-- MAIN APPLICATION
addappid(1540330)
-- Game: addappid(1540330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1540331, 1, "c8d7a97eafbef97b3713c622783e5f4d00b8b809b1a1c4f4b4f6d93ebeee146a")
addappid(1540332, 1, "ffd721353dde8ea94363ecee28502f0f29eb149357c199c60993aab55c5a69ee")
addappid(1540333, 1, "691fe80ab228d1630e52f70f5d1fb4dfce0ec46643513b7a68920fc497c26acb")
addappid(1540334, 1, "d21e5f770d97a43da38884a1222806c7a84d9d629a4a72a631d51d046d0a6edb")
addappid(1540335, 1, "a15130f4e2700f41b80ecbfc0b444ac0c68aea075d1074df0263aaa076b11073")
