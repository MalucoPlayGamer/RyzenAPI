-- Lua provided by RyzenAPI 
-- Game: The Chameleon
addappid(1493970)
addappid(1493971, 1, "80966e7304ab4415753f29f8aee5226d45fb923ba98aaec83be7e04adce87001")
