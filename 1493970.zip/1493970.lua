-- Lua provided by RyzenAPI
-- Game: addappid(1493970)

-- MAIN APPLICATION
addappid(1493970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493971, 1, "80966e7304ab4415753f29f8aee5226d45fb923ba98aaec83be7e04adce87001")
