-- Lua provided by RyzenAPI
-- Game: The Chameleon

-- MAIN APPLICATION
addappid(1493970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493971, 1, "80966e7304ab4415753f29f8aee5226d45fb923ba98aaec83be7e04adce87001")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
