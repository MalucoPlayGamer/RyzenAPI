-- Lua provided by SkyAPI 
-- Game: AppID 1116050
addappid(1116050)
addappid(1116051, 1, "b8072e070b7efdef34a82ac1f4eb13802ce14515631c4cd103765eb40ee991fa")
