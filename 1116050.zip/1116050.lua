-- Lua provided by RyzenAPI
-- Game: 1116050

-- MAIN APPLICATION
addappid(1116050)
-- Game: addappid(1116050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1116051, 1, "b8072e070b7efdef34a82ac1f4eb13802ce14515631c4cd103765eb40ee991fa")
