-- Lua provided by RyzenAPI
-- Game: addappid(2232970)

-- MAIN APPLICATION
addappid(2232970)
addappid(4583370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232971, 1, "7d740c7619cf8de838af5a8cd6bbe2e4201e2a950eb8731b2e982b850084fc02")
