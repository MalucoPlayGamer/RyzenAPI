-- Lua provided by RyzenAPI
-- Game: Game: Sisters hypnosis sex

-- MAIN APPLICATION
addappid(2232970)
addappid(4583370)
-- Game: addappid(2232970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2232971, 1, "7d740c7619cf8de838af5a8cd6bbe2e4201e2a950eb8731b2e982b850084fc02")
