-- Lua provided by RyzenAPI
-- Game: Mournight

-- MAIN APPLICATION
addappid(3436970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3436971, 1, "265579c95631d691552f133c541d4e036df82c6cd4d831ddf603070a54ea0a40")

