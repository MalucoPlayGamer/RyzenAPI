-- Lua provided by RyzenAPI
-- Game: Deep Space Scoundrel

-- MAIN APPLICATION
addappid(2343120)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2343121, 1, "43af0954338d3cd267a4284d938ba2ff134a5baff5b95894cbb6c1cd872e1acc")
addappid(2343122, 1, "911f34069118dc5fb172a09924e51a7891ec637b3705380f47234b7ca54d47fb")

