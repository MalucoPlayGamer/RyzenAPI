-- Lua provided by RyzenAPI
-- Game: Monkey King Simulator - Chapter Huaguo Mountain

-- MAIN APPLICATION
addappid(1765150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1765151, 1, "bfd76a5bc14ce7a2f23d569a3283e4b962a4395b6d79491fb37e7240b9c7c31b")

