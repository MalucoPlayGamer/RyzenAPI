-- Lua provided by RyzenAPI
-- Game: Monkey King Simulator - Chapter Huaguo Mountain

-- MAIN APPLICATION
addappid(1765150)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1765151, 1, "bfd76a5bc14ce7a2f23d569a3283e4b962a4395b6d79491fb37e7240b9c7c31b")

