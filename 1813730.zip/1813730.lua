-- Lua provided by RyzenAPI
-- Game: Outpost

-- MAIN APPLICATION
addappid(1813730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813731, 1, "6efdfe1552d7a2581f55d2d560507dbe947802f49d183afead7da3f8dd35bb76")
