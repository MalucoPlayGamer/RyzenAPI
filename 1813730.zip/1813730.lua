-- Lua provided by RyzenAPI
-- Game: Outpost

-- MAIN APPLICATION
addappid(1813730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813731, 1, "6efdfe1552d7a2581f55d2d560507dbe947802f49d183afead7da3f8dd35bb76")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
