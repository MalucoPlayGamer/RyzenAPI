-- Lua provided by RyzenAPI
-- Game: Didnapper 2 Demo

-- MAIN APPLICATION
addappid(1813830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813831, 1, "e881ba1420dad6f56ab7ccf58c1a5b40315971d6176aa25e6017fedf97ceb720")

