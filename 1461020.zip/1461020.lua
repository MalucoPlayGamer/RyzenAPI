-- Lua provided by RyzenAPI
-- Game: Attack of the Mechadonk - The ultimate donkey

-- MAIN APPLICATION
addappid(1461020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461021, 1, "272b25e9c843feaf0051cbc48707aeab0970a345b7733e7fad5c84f37df9a35c")

