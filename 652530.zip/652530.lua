-- Lua provided by RyzenAPI 
-- Game: Potentia
addappid(652530)
addappid(652531, 1, "1c58f10b8d390aa5c5a83e98b0bf9753fb4644049ba924d486bdb28dc65836f2")
