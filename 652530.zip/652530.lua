-- Lua provided by RyzenAPI
-- Game: Potentia

-- MAIN APPLICATION
addappid(652530)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(652531, 1, "1c58f10b8d390aa5c5a83e98b0bf9753fb4644049ba924d486bdb28dc65836f2")

