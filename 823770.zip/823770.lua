-- Lua provided by RyzenAPI
-- Game: 823770

-- MAIN APPLICATION
addappid(823770)
-- Game: addappid(823770)

-- MAIN APP DEPOTS / PACKAGES
addappid(823771, 1, "a53504062168907116fcf0ac9705d2c6be0962c4f9a35a0bfe25fff5db1c810d")
