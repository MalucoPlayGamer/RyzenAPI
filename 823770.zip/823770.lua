-- Lua provided by SkyAPI 
-- Game: AppID 823770
addappid(823770)
addappid(823771, 1, "a53504062168907116fcf0ac9705d2c6be0962c4f9a35a0bfe25fff5db1c810d")
