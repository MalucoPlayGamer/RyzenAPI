-- Lua provided by RyzenAPI
-- Game: Game: Steven Universe: Save the Light

-- MAIN APPLICATION
addappid(821890)
-- Game: addappid(821890)

-- MAIN APP DEPOTS / PACKAGES
addappid(821891, 1, "8c4b1ea17503ca26f29fe5881a44d36cdcd2f6e5a3ab4e2ad4df4fd4d3dba4d3")
