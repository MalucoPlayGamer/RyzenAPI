-- Lua provided by RyzenAPI
-- Game: Please State Your Name : A VR Animated Film

-- MAIN APPLICATION
addappid(228990)
addappid(536210)

-- MAIN APP DEPOTS / PACKAGES
addappid(536212,0,"d25acd2b1dc389ac583a7eabde2ffa0f772ecad6a5b022453a2b14444e50e422")

