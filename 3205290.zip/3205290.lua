-- Lua provided by RyzenAPI
-- Game: 谁偷了我的女朋友

-- MAIN APPLICATION
addappid(3205290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3205291, 1, "25841acc955cad76efc389fa414b4074612751697b024dcac3987ae1da0ea888")

