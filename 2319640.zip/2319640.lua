-- Lua provided by RyzenAPI
-- Game: Rise of Gun

-- MAIN APPLICATION
addappid(2319640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2319641, 1, "5eb85c0962ac3f649278e521f950f6e9ee518ed8faa03466316904e84f6018e0")
