-- Lua provided by RyzenAPI
-- Game: addappid(1729740)

-- MAIN APPLICATION
addappid(1729740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1729741, 1, "ae083aff6754925333f345c885acd58509a103503fd7ce6de8abe8b03e9fe4d2")
