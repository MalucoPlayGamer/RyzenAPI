-- Lua provided by RyzenAPI
-- Game: Grand Tits Adventure [18+]

-- MAIN APPLICATION
addappid(3824080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3824081, 1, "1ddd763e541505195b0e73e9166806328a9113917b1849532befdf53270153b8")

