-- Lua provided by RyzenAPI
-- Game: Survivor Of The Journey

-- MAIN APPLICATION
addappid(2095740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2095741, 1, "06f28d882e839f7d9fc56d1a2ceb6504d33e689823a03937395cee0f72151010")

