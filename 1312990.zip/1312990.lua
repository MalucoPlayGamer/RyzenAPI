-- Lua provided by RyzenAPI
-- Game: Awkward Girls

-- MAIN APPLICATION
addappid(1312990)

-- MAIN APP DEPOTS / PACKAGES
addappid(1312991, 1, "e465911c7049a1255c369741de7083a3a8acfa797135dc36d572fbe85b803a80")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1324390)
