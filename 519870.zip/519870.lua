-- Lua provided by RyzenAPI
-- Game: 519870

-- MAIN APPLICATION
addappid(519870)
-- Game: addappid(519870)

-- MAIN APP DEPOTS / PACKAGES
addappid(519871, 1, "ad6b8928540f6cf9ee20b952ffb923bde8facba014f4fe10767d3ef3158c3cb5")
addappid(519872, 1, "6a87b92e4b5eb5ebd599ce47c7b5e6425be84861a327d095c66c361c90ec4815")
