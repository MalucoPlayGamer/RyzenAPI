-- Lua provided by RyzenAPI
-- Game: Game: 台北仲夏夜之梦

-- MAIN APPLICATION
addappid(3141580)
addappid(3633810)
-- Game: addappid(3141580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3141581, 1, "335718f347e646f461dc14fe78fd8727e9262bcf3457b893b7ead2ae20ef0e10")
