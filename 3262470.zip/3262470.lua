-- Lua provided by SkyAPI 
-- Game: 虚妄之言 Hollow Life And INsincere Words
addappid(3262470)
addappid(3262471, 1, "dcc8b368a1b9e333a6418ba0d6c4971acb73164ddc1e1937c7e7ccf35d226184")
