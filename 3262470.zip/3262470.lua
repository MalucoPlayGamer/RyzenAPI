-- Lua provided by RyzenAPI
-- Game: addappid(3262470)

-- MAIN APPLICATION
addappid(3262470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3262471, 1, "dcc8b368a1b9e333a6418ba0d6c4971acb73164ddc1e1937c7e7ccf35d226184")
