-- Lua provided by RyzenAPI 
-- Game: Deitydead：Elder Trial
addappid(2279700)
addappid(2279701, 1, "e5ce033fae62879e2d3e4aa880d272c9e5fcdf3328957d14641dcdc562b3bfa0")
