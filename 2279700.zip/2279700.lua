-- Lua provided by RyzenAPI
-- Game: Game: Deitydead：Elder Trial

-- MAIN APPLICATION
addappid(2279700)
-- Game: addappid(2279700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2279701, 1, "e5ce033fae62879e2d3e4aa880d272c9e5fcdf3328957d14641dcdc562b3bfa0")
