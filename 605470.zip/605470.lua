-- Lua provided by RyzenAPI
-- Game: Game: AppID 605470

-- MAIN APPLICATION
addappid(605470)
-- Game: addappid(605470)

-- MAIN APP DEPOTS / PACKAGES
addappid(605471, 1, "1713130c8adbd5174a4938e0f3a90836d9914173e42c2540d3aa5d605815b0d9")
