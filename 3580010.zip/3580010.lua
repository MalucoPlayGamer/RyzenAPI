-- Lua provided by RyzenAPI
-- Game: Lust Odyssey

-- MAIN APPLICATION
addappid(3580010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3580011, 1, "a96d01b6d79cb1db4fc2bc45ed05932cc7c6c722a53a698c71eec6ed6e8f0d37")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
