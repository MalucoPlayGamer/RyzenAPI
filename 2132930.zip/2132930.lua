-- Lua provided by RyzenAPI
-- Game: addappid(2132930)

-- MAIN APPLICATION
addappid(2132930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2132931, 1, "b8ed451d6f0a4dc6993a133761dcdf7a6bd615bdcf60a57b8257b5dfb809ac5c")
