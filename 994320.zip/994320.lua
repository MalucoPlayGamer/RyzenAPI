-- Lua provided by SkyAPI 
-- Game: Night City 2177
addappid(994320)
addappid(994321, 1, "fc9aa7c11e337dd39bb5ba7f3dca0b4294f7e80e46ca2f142246eab867f0822d")
