-- Lua provided by RyzenAPI
-- Game: Night City 2177

-- MAIN APPLICATION
addappid(994320)

-- MAIN APP DEPOTS / PACKAGES
addappid(994321, 1, "fc9aa7c11e337dd39bb5ba7f3dca0b4294f7e80e46ca2f142246eab867f0822d")
