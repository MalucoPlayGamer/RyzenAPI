-- Lua provided by RyzenAPI
-- Game: Evoland

-- MAIN APPLICATION
addappid(233470)
-- Game: addappid(233470)

-- MAIN APP DEPOTS / PACKAGES
addappid(233471, 1, "cc2bff779beca66fec6727ce50c410f01987e4e964f48435b1a705fcb1c431ee")
addappid(233472, 1, "6de414b3668fec065fa7f53fa8e42067a665983c2a8ffa5db57fff4adcf7282e")
addappid(233473, 1, "789f99352cccb47ec9c5e8e023ff55e5ab05e80823c9db03bf5e58501cd376b9")
