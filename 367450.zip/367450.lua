-- Lua provided by RyzenAPI 
-- Game: Poly Bridge
addappid(367450)
addappid(367451, 1, "d665d606792ae4631a504bd59f59310fffb87490652e9b149616eda8ad5962ba")
addappid(367452, 1, "1d911373e5f75e7fe50cf3e2708aab9380d1565dc3e7fc9bacb9339cc042dec6")
addappid(367453, 1, "03f1099f465d40ba0296be94392f13b6a696331a12f878d8a4931efb7a88397d")
