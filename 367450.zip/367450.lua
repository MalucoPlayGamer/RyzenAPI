-- Lua provided by RyzenAPI
-- Game: Poly Bridge

-- MAIN APPLICATION
addappid(367450)

-- MAIN APP DEPOTS / PACKAGES
addappid(367451, 1, "d665d606792ae4631a504bd59f59310fffb87490652e9b149616eda8ad5962ba")
addappid(367452, 1, "1d911373e5f75e7fe50cf3e2708aab9380d1565dc3e7fc9bacb9339cc042dec6")
addappid(367453, 1, "03f1099f465d40ba0296be94392f13b6a696331a12f878d8a4931efb7a88397d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
