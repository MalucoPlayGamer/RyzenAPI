-- Lua provided by RyzenAPI
-- Game: addappid(1890880)

-- MAIN APPLICATION
addappid(1890880)

-- MAIN APP DEPOTS / PACKAGES
addappid(1890881, 1, "ebe972d6c61c49fc3dc3e46677a94bb268ddc62aaffd6204edd0f6b746096755")
