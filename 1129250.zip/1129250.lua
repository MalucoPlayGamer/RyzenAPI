-- Lua provided by RyzenAPI
-- Game: NEKO-NIN exHeart 3

-- MAIN APPLICATION
addappid(1129250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1129251, 1, "b8e2f2a8ae12b9f57457dafce4cecffea03242b2382f3b2236ac791980491d21")
addappid(3166350, 0, "ec89ed3d75e618338e2adfb9908dbe7b32938c87d3246cc6ca88103184daf497")
