-- Lua provided by RyzenAPI
-- Game: Goat Survivor

-- MAIN APPLICATION
addappid(3470660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3470661, 1, "6952827fafb308ba2c84b059bbbece733de5be5a03b08a851825a9484d1195a0")
