-- 4712720's Lua and Manifest Created by Hubcap Manifest
-- Musica
-- Created: August 01, 2026 at 09:12:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4712720) -- Musica
-- MAIN APP DEPOTS
addappid(4712721, 1, "0de1507d7cf561671df684606ed9b6e30746a0b0a462be5194446f2be63b16c7") -- Depot 4712721
setManifestid(4712721, "2986618699897562444", 62549433)