-- Lua provided by RyzenAPI
-- Game: Musica

-- MAIN APPLICATION
addappid(4712720) -- Musica

-- MAIN APP DEPOTS / PACKAGES
addappid(4712721, 1, "0de1507d7cf561671df684606ed9b6e30746a0b0a462be5194446f2be63b16c7") -- Depot 4712721

