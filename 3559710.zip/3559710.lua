-- Lua provided by RyzenAPI 
-- Game: AppID 3559710
addappid(3559710)
addappid(3559711, 1, "8463cc43068360881cde28667c8f42c49e31505dfc145043f5079854363c1189")
