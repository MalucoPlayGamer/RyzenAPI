-- Lua provided by RyzenAPI
-- Game: addappid(1757440)

-- MAIN APPLICATION
addappid(1757440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1757441, 1, "9adeba86db0d2a1c4d6ad771f1021e3abd60bd2676879525dcce71e5a834d184")
