-- Lua provided by RyzenAPI
-- Game: Non-Euclidean Minesweeper

-- MAIN APPLICATION
addappid(3380320)

-- MAIN APP DEPOTS / PACKAGES
addappid(3380321, 1, "ba48bf0cc55485209162e2dc37b2c37901ad32086ef90a653f1cb9afa6855de8")
