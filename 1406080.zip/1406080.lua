-- Lua provided by RyzenAPI
-- Game: Arc Wizards

-- MAIN APPLICATION
addappid(1406080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1406081, 1, "a88b5800d72cd51f4760b8c57ff5cef8fcdaad3e065d7ce799969a8d8645e02f")

