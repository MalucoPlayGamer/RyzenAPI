-- Lua provided by RyzenAPI
-- Game: addappid(347280)

-- MAIN APPLICATION
addappid(347280)

-- MAIN APP DEPOTS / PACKAGES
addappid(347282,0,"d94c091f32fd80a5193a4ae7ab776a294e7483290a685fccd732ac0718a8bc43")
