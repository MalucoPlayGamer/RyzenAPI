-- Lua provided by RyzenAPI
-- Game: Game: AppID 2990580

-- MAIN APPLICATION
addappid(2990580)
-- Game: addappid(2990580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2990581, 1, "323a28714c6214a4c73b2e6094e18fc0db017239c3f1aad194b81cae55597dca")
