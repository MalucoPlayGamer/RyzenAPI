-- Lua provided by RyzenAPI
-- Game: addappid(2257640)

-- MAIN APPLICATION
addappid(2257640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257641, 1, "5aacb9f13d515586f3870ebb7a7ecd6db36448b0c13866ff44badfb3e16f0b06")
