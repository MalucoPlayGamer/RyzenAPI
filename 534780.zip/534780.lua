-- Lua provided by RyzenAPI
-- Game: XGun-Weapon Evolution

-- MAIN APPLICATION
addappid(534780)

-- MAIN APP DEPOTS / PACKAGES
addappid(534781, 1, "1dd325743a04e2875d7f967d133bc9715860596d5dfd94c586ee8a75090b4734")
