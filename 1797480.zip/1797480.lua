-- Lua provided by RyzenAPI
-- Game: addappid(1797480)

-- MAIN APPLICATION
addappid(1797480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1797481, 1, "ed14e6887ef77fee6a8b09d06abd396b8633f0854772a4c3be05f7e2349c432f")
