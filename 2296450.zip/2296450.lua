-- Lua provided by SkyAPI 
-- Game: AppID 2296450
addappid(2296450)
addappid(2296451, 1, "0397b2062cb613973bacfe709603a4f43406a27c479aee61f4dcb8c7fccf21aa")
