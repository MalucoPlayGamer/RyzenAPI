-- Lua provided by RyzenAPI
-- Game: addappid(2296450)

-- MAIN APPLICATION
addappid(2296450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2296451, 1, "0397b2062cb613973bacfe709603a4f43406a27c479aee61f4dcb8c7fccf21aa")
