-- Lua provided by RyzenAPI
-- Game: ENDWALKER: FINAL FANTASY XIV Original Soundtrack

-- MAIN APPLICATION
addappid(3372310)
-- Game: addappid(3372310)

-- MAIN APP DEPOTS / PACKAGES
addappid(3372311, 1, "f8b31fc992717147e3a460e85ac13c58c34d9d1c56d319178cbec630f7de4ebd")
