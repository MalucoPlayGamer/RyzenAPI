-- Lua provided by RyzenAPI
-- Game: WARRIORS OROCHI 4 Ultimate - Special Costume for Yang Jian

-- MAIN APPLICATION
addappid(1176615)

-- MAIN APP DEPOTS / PACKAGES
addappid(1176615,0,"6670f13620afd2c3f315ff41c56cb95556837977a81727b755f0351762145ad4")
