-- Lua provided by RyzenAPI
-- Game: Dark Blue Warriorr

-- MAIN APPLICATION
addappid(2094230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2094231, 1, "af2a33a71dea486b05d25f4af29e3dbc6596cff9a61bb9d16fa72e2b3ef43054")
