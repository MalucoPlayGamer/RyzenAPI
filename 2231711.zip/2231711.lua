-- Lua provided by RyzenAPI
-- Game: Pin Badge "Lucky Cat"

-- MAIN APPLICATION
addappid(2231711)

-- MAIN APP DEPOTS / PACKAGES
addappid(2231711,0,"da080eda99e8ae5a741fe5cab8f51b4e950d5210f15e1c77b041634d1df944f5")

