-- Lua provided by RyzenAPI
-- Game: addappid(456690)

-- MAIN APPLICATION
addappid(456690)

-- MAIN APP DEPOTS / PACKAGES
addappid(456691, 1, "53e338e81120f4cc7befec3fb4ebbcad325d1dfe20c8840ded4f9ae0d8da0dbb")
