-- Lua provided by SkyAPI 
-- Game: AppID 238170
addappid(238170)
addappid(238171, 1, "f46759745589a4faaa6cc0b4dcab341d3be568409c7210c6aca82ad2308ee2b8")
