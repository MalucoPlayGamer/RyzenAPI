-- Lua provided by RyzenAPI
-- Game: addappid(238170)

-- MAIN APPLICATION
addappid(238170)

-- MAIN APP DEPOTS / PACKAGES
addappid(238171, 1, "f46759745589a4faaa6cc0b4dcab341d3be568409c7210c6aca82ad2308ee2b8")
