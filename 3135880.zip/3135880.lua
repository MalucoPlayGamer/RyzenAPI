-- Lua provided by RyzenAPI
-- Game: Dragon's Dog mother

-- MAIN APPLICATION
addappid(3135880)
-- Game: addappid(3135880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3135881, 1, "0238e37fba83b4350d82e529cbf967f66566fcc16718ffad0b2a439b72d7b35a")
