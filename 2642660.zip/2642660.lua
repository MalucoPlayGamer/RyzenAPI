-- Lua provided by RyzenAPI
-- Game: 2642660

-- MAIN APPLICATION
addappid(2642660)
-- Game: addappid(2642660)

-- MAIN APP DEPOTS / PACKAGES
addappid(2642661, 1, "7f34137bbfca68d9cec27ececb8ae5beae12ae57f9c52995653f3b59ab49c4fa")
addappid(2642662, 1, "7b91377344d121002fb7e2dc7e6952a9379c47ec9d67bf7c4e69f1163101cc80")
