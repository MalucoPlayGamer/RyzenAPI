-- Lua provided by RyzenAPI
-- Game: 2636320

-- MAIN APPLICATION
addappid(2636320)
-- Game: addappid(2636320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2636321, 1, "964a09038ac96cb8ce59e00b75f79e53ed25a334f80692a8cef76d4c0e915a85")
