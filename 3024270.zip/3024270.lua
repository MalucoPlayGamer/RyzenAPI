-- Lua provided by RyzenAPI
-- Game: 3024270

-- MAIN APPLICATION
addappid(3024270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3024270,0,"37db060f19e0bdddce3d0c64b7caa6f681d9348c8143f89d2130cfbff94ac4d3")

