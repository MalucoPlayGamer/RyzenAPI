-- Lua provided by RyzenAPI
-- Game: AppID 3186690

-- MAIN APPLICATION
addappid(3186690)

-- MAIN APP DEPOTS / PACKAGES
addappid(3186691, 1, "adeb23e983aafdc2df4c6a812c957995e3a4a9b8fedb97f7e97a07dd360e95d7")

