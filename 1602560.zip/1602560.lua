-- Lua provided by RyzenAPI
-- Game: The Many Pieces of Mr. Coo

-- MAIN APPLICATION
addappid(1602560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602561, 1, "4ce9a0dd749800e43fafaafa60d1a4536f1f0f08d7ae32a831b2997503ebc09e")
