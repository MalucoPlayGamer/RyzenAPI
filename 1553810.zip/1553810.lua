-- Lua provided by RyzenAPI
-- Game: addappid(1553810)

-- MAIN APPLICATION
addappid(1553810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1553811, 1, "f63655e8ff6c0bbc6e1daa47b129292af36540302bf6c2a82af5b1e564d9d736")
