-- Lua provided by RyzenAPI
-- Game: Game: Arsene Lupin - Once a Thief

-- MAIN APPLICATION
addappid(2922980)
-- Game: addappid(2922980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2922981, 1, "b977e04e8acfd99921dc27640b048208ca63452945659f93b6ced3f6b7e5783f")
addappid(3270640, 0, "81c7c32ff29fb326ce5d5a02e78705ffdb5dbf7cfdfc43fa9e776ea676662c91")
