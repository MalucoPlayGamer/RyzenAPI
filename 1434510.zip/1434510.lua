-- Lua provided by RyzenAPI 
-- Game: Park The Car
addappid(1434510)
addappid(1434511, 1, "9652820680ce97b58e7ec4c849d6cd156ca1057a5ac3c7c63b4c41f005b7d14a")
