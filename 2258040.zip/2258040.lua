-- Lua provided by RyzenAPI
-- Game: World of Turtle

-- MAIN APPLICATION
addappid(2258040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2258041, 1, "dbb5222247d8f2b2c377316144765f6ee3bda2ee2cdae34fcc51116b508b49c0")
