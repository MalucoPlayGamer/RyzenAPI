-- Lua provided by RyzenAPI
-- Game: ARK: Scorched Earth Ascended

-- MAIN APPLICATION
addappid(2849450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2849450,0,"06a4aa068a1a3940e0c7eff34508ad6474806f4b46520ef9ea12b4b7f77a3d0e")

