-- Lua provided by RyzenAPI
-- Game: Blamed Demo

-- MAIN APPLICATION
addappid(2483650)
-- Game: addappid(2483650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2483651, 1, "339b888940a9d6f1bb9462667e8740538f9fefcafd51ccee780b8b795fa89f0d")
