-- Lua provided by RyzenAPI
-- Game: 3211930

-- MAIN APPLICATION
addappid(3211930)
-- Game: addappid(3211930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3211931, 1, "a77bec61044aee738b7b0dfe0cf19e5782e6b06ca206d1468df7d7f16b937321")
