-- Lua provided by RyzenAPI
-- Game: addappid(1653430)

-- MAIN APPLICATION
addappid(1653430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1653431, 1, "f0b2c2ed803a21c4b22fa0802903dde86a319e4b72e7536be43e61be340b9ad0")
