-- Lua provided by RyzenAPI
-- Game: Wildlife Park 3

-- MAIN APPLICATION
addappid(287200)

-- MAIN APP DEPOTS / PACKAGES
addappid(287201, 1, "0e5f7730e6f66fdb0fb768138590c34807581acd9590018f97b95c8b0c6b25b3")
addappid(287202, 1, "69509cd7e45ddeebbfe06067d6a99216c5a1dd89b6535e10093675d864a31cde")
addappid(287203, 1, "6b4c877fe1b58b694240ccae2ffd1f217a3182258c9164f2af088101cd47f786")
addappid(287204, 1, "85dbadf6f7e64f03315cb1cd1798a3d328014ec547053a03a1cf48c8e7c85189")
addappid(287205, 1, "bbcff58e9767a240427aa7aa072b33abea0e91a0b86cc060b35bb806e9d7f2c9")
addappid(287206, 1, "22dd010faefebac0dd71fc52a3e185d7ddc704c9147234a08cd3d2de1029769c")
addappid(287207, 1, "fdd867e0c0c47743c73678d5ec4e417690df4d4f2e3f11a5c5bd15abac5aeb20")
addappid(287208, 1, "870068ee5fc6fb9be3eb10551a84f37ad394940ac25a80023e61fe61edec59b1")
addappid(602461, 0, "401f66c231f35caea429ca2a812e2eb51183de3f7426c41cb09b7171a28c6af1")
addappid(798320, 0, "50a3cb1eea6e2b499fe2943f92b114d23c04a92bd0fe51274541b9e6fad8fe48")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(602460)
addappid(767580)
addappid(858720)
addappid(958380)
addappid(958381)
