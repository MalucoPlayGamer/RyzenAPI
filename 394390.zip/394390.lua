-- Lua provided by RyzenAPI
-- Game: addappid(394390)

-- MAIN APPLICATION
addappid(394390)

-- MAIN APP DEPOTS / PACKAGES
addappid(394391, 1, "59bb214db8b5f62c495e6cea15f55f9470a46fbc9e155fca92fd3a4084b66bc3")
