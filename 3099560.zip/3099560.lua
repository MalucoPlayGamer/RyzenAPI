-- Lua provided by RyzenAPI
-- Game: Money And Lady Demo

-- MAIN APPLICATION
addappid(3099560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3099561, 1, "4d4811c5fcc1c7c61b5db846f6ad5edf1bb17c314a23deeab17a6c1ba33f31b8")

