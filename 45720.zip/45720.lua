-- Lua provided by RyzenAPI
-- Game: 45720

-- MAIN APPLICATION
addappid(45720)
-- Game: addappid(45720)

-- MAIN APP DEPOTS / PACKAGES
addappid(45721, 1, "defaf7cfde2b8e60ef57787870f32bb103327171c1b2828c7811a4e9f334b433")
