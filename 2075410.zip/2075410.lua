-- Lua provided by RyzenAPI
-- Game: addappid(2075410)

-- MAIN APPLICATION
addappid(2075410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2075411, 1, "3e7ab5577f0e31888f51f19449c7fecab29482da7f7a2eb30383271319d8248a")
