-- Lua provided by RyzenAPI 
-- Game: Digger Online
addappid(278970)
addappid(278971, 1, "5e84a8f7805aa5e101a63f19439368c1e69d110235f4fbcbe6455744bdb66c24")
