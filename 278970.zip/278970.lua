-- Lua provided by RyzenAPI
-- Game: Digger Online

-- MAIN APPLICATION
addappid(278970)

-- MAIN APP DEPOTS / PACKAGES
addappid(278971, 1, "5e84a8f7805aa5e101a63f19439368c1e69d110235f4fbcbe6455744bdb66c24")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
