-- Lua provided by RyzenAPI
-- Game: 290470

-- MAIN APPLICATION
addappid(290470)
-- Game: addappid(290470)

-- MAIN APP DEPOTS / PACKAGES
addappid(290471, 1, "a12568f64bcefa130f2d60b9bca7f89b440dce8086d824a680627b01b5226852")
