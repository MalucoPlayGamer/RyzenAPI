-- Lua provided by RyzenAPI
-- Game: Onigiri

-- MAIN APPLICATION
addappid(290470)
addappid(1348470)
addappid(1348500)

-- MAIN APP DEPOTS / PACKAGES
addappid(290471, 1, "a12568f64bcefa130f2d60b9bca7f89b440dce8086d824a680627b01b5226852")

