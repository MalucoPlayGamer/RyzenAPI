-- Lua provided by RyzenAPI
-- Game: addappid(2465080)

-- MAIN APPLICATION
addappid(2465080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2465081, 1, "98564e225dbfd4b59484a5691d603e4f7de5299ef82ae72a14a76764dc4ea0a6")
