-- Lua provided by RyzenAPI
-- Game: AppID 916910

-- MAIN APPLICATION
addappid(916910)

-- MAIN APP DEPOTS / PACKAGES
addappid(916911, 1, "8dc905197f3e24f2d988b52deddf5770e86a0d12e592aa081d3cdde62ca23aab")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
