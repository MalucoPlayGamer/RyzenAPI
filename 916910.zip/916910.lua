-- Lua provided by RyzenAPI
-- Game: AppID 916910

-- MAIN APPLICATION
addappid(916910)

-- MAIN APP DEPOTS / PACKAGES
addappid(916911, 1, "8dc905197f3e24f2d988b52deddf5770e86a0d12e592aa081d3cdde62ca23aab")
