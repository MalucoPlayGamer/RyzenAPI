-- Lua provided by RyzenAPI
-- Game: Tales of Destruction

-- MAIN APPLICATION
addappid(486480)

-- MAIN APP DEPOTS / PACKAGES
addappid(486481, 1, "cdf5de91688ae07aab3af7ba9971807ac2ae82c80503d78c3a91ec0ba5c223c9")
