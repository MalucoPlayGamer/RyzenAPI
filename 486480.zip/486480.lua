-- Lua provided by RyzenAPI
-- Game: Tales of Destruction

-- MAIN APPLICATION
addappid(486480)

-- MAIN APP DEPOTS / PACKAGES
addappid(486481, 1, "cdf5de91688ae07aab3af7ba9971807ac2ae82c80503d78c3a91ec0ba5c223c9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
