-- Lua provided by RyzenAPI
-- Game: Boxel Golf

-- MAIN APPLICATION
addappid(1945820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945821, 1, "b9f00a8ca3a7817978506153fef08922c0a881e80fd1e4b27672245f29d2eae2")

