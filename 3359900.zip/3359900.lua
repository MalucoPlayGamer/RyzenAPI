-- Lua provided by RyzenAPI
-- Game: REAL BOUT FATAL FURY 2: THE NEWCOMERS

-- MAIN APPLICATION
addappid(3359900)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3359901, 1, "939a4aa533fd1eade4a02356eb95e41e1026753c56a85d974d6cce1e4b25ca82")

