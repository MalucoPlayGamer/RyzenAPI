-- Lua provided by RyzenAPI
-- Game: addappid(3359900)

-- MAIN APPLICATION
addappid(3359900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3359901, 1, "939a4aa533fd1eade4a02356eb95e41e1026753c56a85d974d6cce1e4b25ca82")
