-- Lua provided by RyzenAPI
-- Game: Wild Dive

-- MAIN APPLICATION
addappid(1598010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1598011, 1, "8bb05dacc1c40faefb1b7bea3c52be17942ce599bbb90ad7a029b54949e488e0")

