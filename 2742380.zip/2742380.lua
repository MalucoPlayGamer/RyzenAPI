-- Lua provided by RyzenAPI
-- Game: Apex Heroines - Silver Legend 白银传说

-- MAIN APPLICATION
addappid(2742380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2742380,0,"f0344369750827b72b9fb680063cf630392d20427fb0d7df5354d29174d5fda3")

