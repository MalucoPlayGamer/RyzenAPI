-- Lua provided by RyzenAPI
-- Game: Pixel Game Maker MV -2D Side-scroller Shooting Game Sample Project

-- MAIN APPLICATION
addappid(1582590)
-- Game: addappid(1582590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1582591, 1, "f4fcde716e9b2caddbc5ca90732df3ecfd5d89d2fecde1be3b92a25a5dbf39de")
