-- Lua provided by RyzenAPI
-- Game: Milfvania Ep. 3

-- MAIN APPLICATION
addappid(2520110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2520112,0,"e44d1fbc285cd10bd8894e81180e3530dbe4738d1da201e10af513b82ef1622d")
