-- Lua provided by RyzenAPI
-- Game: Game: Lucius Demake - Soundtrack

-- MAIN APPLICATION
addappid(538460)
-- Game: addappid(538460)

-- MAIN APP DEPOTS / PACKAGES
addappid(538461, 1, "667a7e4371876762105a75bc743b43a36c28ae2cf69b82753d8800f2c10db264")
