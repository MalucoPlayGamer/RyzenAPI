-- Lua provided by RyzenAPI
-- Game: addappid(3277380)

-- MAIN APPLICATION
addappid(3277380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3277381, 1, "10e0cb008b869db81c3fc5f95ed173a99a9cbd349584ba195f838e9ed872d8eb")
