-- Lua provided by RyzenAPI
-- Game: Game: Killing Zombies

-- MAIN APPLICATION
addappid(534440)
-- Game: addappid(534440)

-- MAIN APP DEPOTS / PACKAGES
addappid(534441, 1, "db915bab52841f8754e8abac7bcfe0866ae67d3f31b47e67e5d7b59e356d0bf2")
