-- Lua provided by RyzenAPI
-- Game: Stray - Original Soundtrack

-- MAIN APPLICATION
addappid(2086160)
-- Game: addappid(2086160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2086161, 1, "fd1d42615e85864ec3fc7caf1f1b06a9ca54cabfb31bea32a6f1d08c24b78e45")
addappid(2086162, 1, "3e67977909dc764d102e327c26e3170be1cd27cb3e0e27a62c4d20250f88579b")
