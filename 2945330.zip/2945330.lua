-- Lua provided by SkyAPI 
-- Game: AppID 2945330
addappid(2945330)
addappid(2945331, 1, "b52d0935dad95c44306e344ca15d1984b028c50eb94d8e4ca09a4686b188e660")
