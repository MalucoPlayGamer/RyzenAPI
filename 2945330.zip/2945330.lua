-- Lua provided by RyzenAPI
-- Game: addappid(2945330)

-- MAIN APPLICATION
addappid(2945330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945331, 1, "b52d0935dad95c44306e344ca15d1984b028c50eb94d8e4ca09a4686b188e660")
