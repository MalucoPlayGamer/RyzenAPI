-- Lua provided by RyzenAPI
-- Game: 1826640

-- MAIN APPLICATION
addappid(1826640)
-- Game: addappid(1826640)

-- MAIN APP DEPOTS / PACKAGES
addappid(1826641, 1, "cc88aab7ca0ff1df29c0ebe0c27b5432508d5fed99dd137ad1a20f9cc8beb028")
