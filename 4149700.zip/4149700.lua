-- Lua provided by RyzenAPI
-- Game: Dreamcore: Rabbit Hole

-- MAIN APPLICATION
addappid(4149700)

-- MAIN APP DEPOTS / PACKAGES
addappid(4149701,0,"a25dab69be88fc2f6bef1faa5de4b440efe2116cd93a9cefcdaa232612fbc0ac")

