-- Lua provided by RyzenAPI
-- Game: Horse Farm Simulator Demo

-- MAIN APPLICATION
addappid(3235080)

-- MAIN APP DEPOTS / PACKAGES
addappid(3235081, 1, "dca478f56fe28125a60d2d495ca927901108fb15f8b2728ddc36f0bbbf20f8f2")
