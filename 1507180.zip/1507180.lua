-- Lua provided by RyzenAPI
-- Game: Game: Math Hero - Minimalist Puzzle

-- MAIN APPLICATION
addappid(1507180)
-- Game: addappid(1507180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507181, 1, "23039668f61c863acf3cac2809ef9d0777fafcc59ef1a414f34091799a71dd91")
