-- 4668220's Lua and Manifest Created by Hubcap Manifest
-- Farm Factory Simulator
-- Created: July 16, 2026 at 07:45:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4668220) -- Farm Factory Simulator
-- MAIN APP DEPOTS
addappid(4668221, 1, "ef5c09920298d42193f9b51c1e1407672f1ac5d5d56d5deedf39365b2f3c20d5") -- Depot 4668221
setManifestid(4668221, "2815207201215312460", 6148908936)