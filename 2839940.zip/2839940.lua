-- Lua provided by RyzenAPI
-- Game: The Tomb of Corruption

-- MAIN APPLICATION
addappid(2839940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2839941, 1, "99a7fdd0a109f4e55cb2fe9d3dcd0ead534c9e4f73175db8495ac0b620984823")
