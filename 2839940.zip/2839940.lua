-- Lua provided by RyzenAPI
-- Game: The Tomb of Corruption

-- MAIN APPLICATION
addappid(2839940)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2839941, 1, "99a7fdd0a109f4e55cb2fe9d3dcd0ead534c9e4f73175db8495ac0b620984823")

