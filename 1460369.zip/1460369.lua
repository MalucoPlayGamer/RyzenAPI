-- Lua provided by RyzenAPI
-- Game: FUSER™ - Marshmello ft. Bastille - "Happier"

-- MAIN APPLICATION
addappid(1460369)

-- MAIN APP DEPOTS / PACKAGES
addappid(1460369,0,"5a674e8fbf641b1002a5a4fcd328a677ec57a2fa472388b2ad5c283ae5ab6391")
