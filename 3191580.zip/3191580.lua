-- Lua provided by RyzenAPI
-- Game: Game: Harem Dungeon

-- MAIN APPLICATION
addappid(3191580)
-- Game: addappid(3191580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3191581, 1, "ba5202acf43d3dfd2b86c548d9158c950778aba0de61dfbe991a3f92d53827bc")
