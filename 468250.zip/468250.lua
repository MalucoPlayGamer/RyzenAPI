-- Lua provided by RyzenAPI
-- Game: Warfare Online

-- MAIN APPLICATION
addappid(468250)

-- MAIN APP DEPOTS / PACKAGES
addappid(468251, 1, "6ddac374270bafe060d790fa9d1cc93a277a2ce0c691b54230b340645543f0e3")

