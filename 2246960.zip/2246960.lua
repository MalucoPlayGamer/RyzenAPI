-- Lua provided by RyzenAPI
-- Game: addappid(2246960)

-- MAIN APPLICATION
addappid(2246960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2246961, 1, "e24ea39d05fd9700ce256a0cc4e8f58636dc30661c8bc26e25bedccce231449d")
