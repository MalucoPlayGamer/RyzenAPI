-- Lua provided by RyzenAPI
-- Game: Ninja VS Zombies

-- MAIN APPLICATION
addappid(2228960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2228961, 1, "d91bff0983c00834fdd8b320a1088c070676cdc8f552fb0ddf7f7c0bfbac010c")
