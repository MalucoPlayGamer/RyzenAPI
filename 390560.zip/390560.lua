-- Lua provided by RyzenAPI
-- Game: Fantasy Strike

-- MAIN APPLICATION
addappid(390560)
addappid(640040)
addappid(1221900)
addappid(1222760)

-- MAIN APP DEPOTS / PACKAGES
addappid(390561, 1, "e3489582da1c7be6bae3dda62ae259b697e74328cb5371d45a64453596af5538")
addappid(390563, 1, "5f5ca6e2a79e2cbe46bb23ed16e3366c410a104d5e226431284c86e9bffec39a")
addappid(390564, 1, "8398335158fbb3bb60b09d58727984957d980eb595394631dc4d93f9bfac0c79")

