-- Lua provided by RyzenAPI
-- Game: whiskers

-- MAIN APPLICATION
addappid(3097940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3097941, 1, "3f43973d97633ac0e8fddc94dcb5bb0e94fddd72be01db993d063a63b6082371")

