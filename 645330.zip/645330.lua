-- Lua provided by RyzenAPI
-- Game: Game: Frontline Heroes VR

-- MAIN APPLICATION
addappid(645330)
-- Game: addappid(645330)

-- MAIN APP DEPOTS / PACKAGES
addappid(645331, 1, "a01963f8e56c59c47cdf086aa930a97a87a503c37488b22920c1f42486e93b36")
