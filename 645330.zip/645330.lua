-- Lua provided by RyzenAPI
-- Game: Frontline Heroes VR

-- MAIN APPLICATION
addappid(645330)

-- MAIN APP DEPOTS / PACKAGES
addappid(645331, 1, "a01963f8e56c59c47cdf086aa930a97a87a503c37488b22920c1f42486e93b36")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
