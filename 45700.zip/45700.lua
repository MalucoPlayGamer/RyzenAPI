-- Lua provided by RyzenAPI 
-- Game: Devil May Cry 4
addappid(45700)
addappid(45701, 1, "1302efa5f93914449d8d4b7a25c7a5db86023e4186981e2237b1766f9d255b13")
