-- Lua provided by RyzenAPI
-- Game: Game: Lofty Quest

-- MAIN APPLICATION
addappid(1758320)
-- Game: addappid(1758320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758321, 1, "2d8aaea9e991b32c027c87e195e82b025802344892f04c2c9459c2648c770cb8")
