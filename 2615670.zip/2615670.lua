-- Lua provided by RyzenAPI
-- Game: Bewitching Sinners

-- MAIN APPLICATION
addappid(2615670)
-- Game: addappid(2615670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2615671, 1, "8bc2945ca474de1691221f84c63d718f0a1cfcb28fef277753ef72fabb4e3af8")
