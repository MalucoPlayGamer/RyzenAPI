-- Lua provided by RyzenAPI
-- Game: Scary Game

-- MAIN APPLICATION
addappid(3809870)
-- Game: addappid(3809870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3809871, 1, "6d40e092cbc30ebda1575a2843280aae61d4940798a5ae1f4e81c391da646af1")
