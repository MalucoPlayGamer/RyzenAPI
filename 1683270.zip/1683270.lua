-- Lua provided by RyzenAPI
-- Game: Recall: Empty Wishes

-- MAIN APPLICATION
addappid(1683270)
-- Game: addappid(1683270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1683271, 1, "ffcc2ffc643c0355e43412ef4764633a20166c9fc1ba264d2d367554cba4eecf")
