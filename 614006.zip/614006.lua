-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - Airport London-Heathrow

-- MAIN APPLICATION
addappid(614006)

-- MAIN APP DEPOTS / PACKAGES
addappid(615890,0,"14f90751335dee231201f9848079dc23edfd7c83a2c5ebcbf1e449ca6bf385e4")
