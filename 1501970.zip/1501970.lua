-- Lua provided by RyzenAPI
-- Game: addappid(1501970)

-- MAIN APPLICATION
addappid(1501970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1501971, 1, "6ef97ffb2ba105c6912abeaa6048ec1a4b0b2d60748ac6a121b081586b15037f")
