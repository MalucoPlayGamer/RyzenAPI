-- Lua provided by RyzenAPI
-- Game: 1394500

-- MAIN APPLICATION
addappid(1394500)
-- Game: addappid(1394500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394501, 1, "50f3b2f53da9fe3fd08051de4373e63069ee1360444dfa59eec7690c2846e81d")
