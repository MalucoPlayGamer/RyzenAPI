-- Lua provided by RyzenAPI 
-- Game: PhotoWorld
addappid(1435020)
addappid(1435021, 1, "4547271a4134521f0908713157c2d6e81224cac42d11971e6a08c5633e0ea6fc")
