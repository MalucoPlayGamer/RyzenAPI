-- Lua provided by RyzenAPI
-- Game: PhotoWorld

-- MAIN APPLICATION
addappid(1435020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1435021, 1, "4547271a4134521f0908713157c2d6e81224cac42d11971e6a08c5633e0ea6fc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
