-- Lua provided by RyzenAPI
-- Game: 2134600

-- MAIN APPLICATION
addappid(2134600)
-- Game: addappid(2134600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2134601, 1, "8a62acda938168b4ee6d55fde8fdf49ec05ad50732cdcb5eb458fa4e64aaa2ad")
