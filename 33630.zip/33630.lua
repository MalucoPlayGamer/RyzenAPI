-- Lua provided by RyzenAPI
-- Game: Crash Time III - Demo

-- MAIN APPLICATION
addappid(33630)

-- MAIN APP DEPOTS / PACKAGES
addappid(33631, 1, "9658b406894e7e30b872eb069520f1b3e6d5d77b262dd1c0a24d239a40fcce04")
