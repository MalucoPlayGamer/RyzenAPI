-- Lua provided by RyzenAPI
-- Game: Rubber Bandits Soundtrack

-- MAIN APPLICATION
addappid(1744160)
-- Game: addappid(1744160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744161, 1, "6459da581ee55eacd6423d16d5eb8904ed05627801464ae83e3f14289bb59324")
