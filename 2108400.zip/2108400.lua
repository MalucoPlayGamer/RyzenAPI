-- Lua provided by RyzenAPI
-- Game: Game: ATCo2

-- MAIN APPLICATION
addappid(2108400)
-- Game: addappid(2108400)

-- MAIN APP DEPOTS / PACKAGES
addappid(2108401, 1, "b399af4ec160cea20539e4c3993bbdc190f0d2bbaad5eb88c01e603fb510332d")
