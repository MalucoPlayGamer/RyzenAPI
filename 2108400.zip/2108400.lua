-- Lua provided by SkyAPI 
-- Game: ATCo2
addappid(2108400)
addappid(2108401, 1, "b399af4ec160cea20539e4c3993bbdc190f0d2bbaad5eb88c01e603fb510332d")
