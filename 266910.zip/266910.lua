-- Lua provided by RyzenAPI
-- Game: 266910

-- MAIN APPLICATION
addappid(266910)
-- Game: addappid(266910)

-- MAIN APP DEPOTS / PACKAGES
addappid(266911, 1, "20c37c43c64c980f27d838c8b0ba48cfe4cf3f30ada495f77ae06611d06a4560")
