-- Lua provided by RyzenAPI
-- Game: 2859330

-- MAIN APPLICATION
addappid(2859330)
-- Game: addappid(2859330)

-- MAIN APP DEPOTS / PACKAGES
addappid(2859331, 1, "a7ac32932a377ae156b44145213979536d4c17a749aaa86ab79f8a22fe595cb4")
