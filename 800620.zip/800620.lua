-- Lua provided by RyzenAPI
-- Game: Game: Fallen Hero: Rebirth

-- MAIN APPLICATION
addappid(800620)
-- Game: addappid(800620)

-- MAIN APP DEPOTS / PACKAGES
addappid(800621, 1, "0992a4141cfcfa5d4c08ea47c0014777dfcca5c0c31646010e743ab83a54016e")
