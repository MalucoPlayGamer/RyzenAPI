-- Lua provided by RyzenAPI
-- Game: Game: AppID 3261560

-- MAIN APPLICATION
addappid(3261560)
-- Game: addappid(3261560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3261561, 1, "942c940621a6911eff1a6af182f5caf692487bfb407d8081453f99f1538769ff")
