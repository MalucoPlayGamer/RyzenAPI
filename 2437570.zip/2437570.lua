-- Lua provided by RyzenAPI
-- Game: Game: Golden Chambers

-- MAIN APPLICATION
addappid(2437570)
-- Game: addappid(2437570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437571, 1, "a01bb6c5dca131fceeab493d75c07e7f850f66af3c0e405a6709a5b4abfa6c4d")
