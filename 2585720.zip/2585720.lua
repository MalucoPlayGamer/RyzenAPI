-- Lua provided by RyzenAPI
-- Game: Sex Apocalypse 2

-- MAIN APPLICATION
addappid(2585720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2585721, 1, "e932bc4d6ffbeeddc250d24bc5e252fbf93b6ddbabb15d917e404cd2bf812d34")
