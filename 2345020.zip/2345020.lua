-- Lua provided by RyzenAPI
-- Game: Bee Island

-- MAIN APPLICATION
addappid(2345020)
-- Game: addappid(2345020)

-- MAIN APP DEPOTS / PACKAGES
addappid(2345021, 1, "1d9e6fed07e9306261af06dc9fa6432cdd93df234134b3ba3a9f12da6f8e5390")
