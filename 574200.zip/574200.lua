-- Lua provided by SkyAPI 
-- Game: AppID 574200
addappid(574200)
addappid(574201, 1, "0fd33f94c5847037862a1ad7f0be2f17bba1e50caee90172c4f327989e246fa5")
addappid(1037870, 0, "0ea1633f368e7cdc4ebd236a2a0a0cfab923ea5db00705a4a0de472d388b9d29")
