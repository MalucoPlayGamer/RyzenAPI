-- Lua provided by RyzenAPI
-- Game: 3012630

-- MAIN APPLICATION
addappid(3012630)
-- Game: addappid(3012630)

-- MAIN APP DEPOTS / PACKAGES
addappid(3012631, 1, "581c42bcc868d2e42ed11e65f85512540ba43b0527c1a8fc34c96a725006f34d")
