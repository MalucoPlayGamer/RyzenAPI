-- Lua provided by RyzenAPI
-- Game: Trivia Vault: 1980's Trivia 2

-- MAIN APPLICATION
addappid(693880)

-- MAIN APP DEPOTS / PACKAGES
addappid(693881, 1, "af364875b5594d340fd667ffdd9c849e80dc740501ef2259d5ed74c09d871301")
