-- Lua provided by RyzenAPI
-- Game: 1646420

-- MAIN APPLICATION
addappid(1646420)
-- Game: addappid(1646420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1646421, 1, "748745480daa2b1fd353cf3b04494f4ced66c3edc8e4a51dc48d369165b54559")
