-- Lua provided by RyzenAPI
-- Game: Elewar: Fused Survivors

-- MAIN APPLICATION
addappid(2489560)
addappid(3202600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2489561, 1, "de0a9e6486622e8f0684e6edf7d721206e9f13e0279341ebbdfc5a421077213f")

