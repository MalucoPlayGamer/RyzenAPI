-- Lua provided by RyzenAPI
-- Game: Elewar: Fused Survivors

-- MAIN APPLICATION
addappid(2489560)
addappid(3202600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2489561, 1, "de0a9e6486622e8f0684e6edf7d721206e9f13e0279341ebbdfc5a421077213f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
