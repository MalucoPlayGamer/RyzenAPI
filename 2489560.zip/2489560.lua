-- Lua provided by SkyAPI 
-- Game: Elewar: Fused Survivors
addappid(2489560)
addappid(2489561, 1, "de0a9e6486622e8f0684e6edf7d721206e9f13e0279341ebbdfc5a421077213f")
addappid(3202600)
