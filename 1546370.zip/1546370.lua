-- Lua provided by RyzenAPI
-- Game: Fill and Cross Magic Journey

-- MAIN APPLICATION
addappid(1546370)
-- Game: addappid(1546370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1546371, 1, "acc09182c902a2f0596996d8128d6fe2670c659293b481bdcb826b621ea129d0")
addappid(1546372, 1, "6f4f4688b1df47e1bdebaaff8e5b76beb17d342812fe48bdc1074b400c949ff2")
