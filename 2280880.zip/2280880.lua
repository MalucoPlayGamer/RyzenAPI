-- Lua provided by RyzenAPI
-- Game: 2280880

-- MAIN APPLICATION
addappid(2280880)
-- Game: addappid(2280880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2280881, 1, "a6bce508f2f3da81c3407ad8511b74e2d2d64c3c2b86b1cf2019197522c3d7bf")
