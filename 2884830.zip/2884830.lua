-- Lua provided by RyzenAPI
-- Game: Chocolate Factory Simulator Demo

-- MAIN APPLICATION
addappid(2884830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2884831, 1, "8f6fe09d409b6d1bf58b0c1393d3f491668e64e58cdfd67ac166e43c702b6568")
