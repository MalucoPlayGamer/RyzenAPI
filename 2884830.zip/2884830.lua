-- Lua provided by SkyAPI 
-- Game: Chocolate Factory Simulator Demo
addappid(2884830)
addappid(2884831, 1, "8f6fe09d409b6d1bf58b0c1393d3f491668e64e58cdfd67ac166e43c702b6568")
