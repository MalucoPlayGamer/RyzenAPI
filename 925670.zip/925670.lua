-- Lua provided by RyzenAPI
-- Game: AppID 925670

-- MAIN APPLICATION
addappid(925670)
-- Game: addappid(925670)

-- MAIN APP DEPOTS / PACKAGES
addappid(925671, 1, "025f500c3d9de4454a68acb744ca8df9b1c0ebad83e67f0ab074def9bd06387b")
addappid(925672, 1, "195fe40edf7ab2f16576b709f9644233cbbd412d70c5b76ed32c8aab76412b92")
addappid(925680, 1, "8dd25fe849b30f0d844acd9a3d397ab1298c3b8583fa760bef6a0cc3424c3742")
addappid(996340, 0, "d231568336c3ebfc7821c52008dfd596919bd1b82aaf9acec7cd54254f952bcd")
