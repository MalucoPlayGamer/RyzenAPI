-- Lua provided by RyzenAPI
-- Game: Game: Ash & Adam's GOBSMACKED

-- MAIN APPLICATION
addappid(2769410)
-- Game: addappid(2769410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2769411, 1, "0542a9dc037adb85a84f4ccbc1a9ceef32e7cfa33878910a3ca72673437b8ef7")
