-- Lua provided by RyzenAPI
-- Game: Sunset Overdrive

-- MAIN APPLICATION
addappid(847370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(847371, 1, "d05c427fd369235384c4b3d6de5431f6103a8cb8dbc4518c43d5fd059dd46d8b")

