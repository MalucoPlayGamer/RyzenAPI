-- Lua provided by RyzenAPI
-- Game: AppID 422760

-- MAIN APPLICATION
addappid(422760)

-- MAIN APP DEPOTS / PACKAGES
addappid(422761, 1, "83f57fa5fec404a987f1d0f0311201c6a4e5bc0ce829f0f08d74eeb4bef9bfd1")
