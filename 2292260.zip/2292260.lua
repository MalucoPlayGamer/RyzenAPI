-- Lua provided by RyzenAPI
-- Game: STAR WARS™: Dark Forces Remaster

-- MAIN APPLICATION
addappid(2292260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2292261, 1, "5465b30e030733132ce9f43979745ba965c432fcc696a8c417e76562390e4ca6")
addappid(2292262, 1, "bbb250df48dd04b3de614c3516b0f6e28cfa8e01c892ca210de7d6621f0dda79")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
