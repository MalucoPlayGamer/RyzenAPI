-- Lua provided by RyzenAPI
-- Game: addappid(3453870)

-- MAIN APPLICATION
addappid(3453870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3453871, 1, "71eb8de96210dabeffe5c162dc140d5261a69ef74dd76b0352f8407217f66322")
