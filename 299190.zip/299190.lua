-- Lua provided by RyzenAPI
-- Game: ibb & obb - Original Soundtrack

-- MAIN APPLICATION
addappid(299190)

-- MAIN APP DEPOTS / PACKAGES
addappid(299190,0,"40c69e06bc1647289e84a91c3789c0110d71b55a2930481dff36d8a236c10b16")

