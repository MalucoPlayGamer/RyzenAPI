-- Lua provided by RyzenAPI
-- Game: addappid(2743840)

-- MAIN APPLICATION
addappid(2743840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2743841, 1, "2928ba62e59bc417d220c12a1aff908cd00872838742b3ff2ba6d3273366b6c8")
