-- Lua provided by RyzenAPI
-- Game: Game: SENRAN KAGURA Peach Ball

-- MAIN APPLICATION
addappid(1074080)
-- Game: addappid(1074080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1074081, 1, "8f666db87634e0fd9068dfb38a18692211ce507c4684e60bba7cd078574a4970")
