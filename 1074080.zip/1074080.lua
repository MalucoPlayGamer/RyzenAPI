-- Lua provided by RyzenAPI
-- Game: SENRAN KAGURA Peach Ball

-- MAIN APPLICATION
addappid(1074080)
addappid(1110110)
addappid(1110111)
addappid(1110112)
addappid(1110113)
addappid(1110120)
addappid(1110121)
addappid(1110122)
addappid(1110123)
addappid(1110124)
addappid(1110125)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1074081,0,"8f666db87634e0fd9068dfb38a18692211ce507c4684e60bba7cd078574a4970")

