-- Lua provided by RyzenAPI
-- Game: SENRAN KAGURA Peach Ball

-- MAIN APPLICATION
addappid(1074080)
addappid(1110110)
addappid(1110111)
addappid(1110112)
addappid(1110113)
addappid(1110120)
addappid(1110121)
addappid(1110122)
addappid(1110123)
addappid(1110124)
addappid(1110125)

-- MAIN APP DEPOTS / PACKAGES
addappid(1074081,0,"8f666db87634e0fd9068dfb38a18692211ce507c4684e60bba7cd078574a4970")

