-- Generated with Luie @ https://lua.tools/
-- 1206560 - WorldBox - God Simulator
-- Generated 2026-08-26 02:46:03 UTC
-- # Depots (Total/DLC/Shared): 3/0/0

-- Main AppID
addappid(1206560, 1, "bc4a616c22736f244adab2bf84e39ac6a3b332aee5024f19644e363dda04739e")

-- Main Depots
addappid(1206561, 1, "cba01e9f6c75a6b26fe978e7179476176b3a191358379fcd3727d4fdaef5d2b6") -- (windows)
setManifestid(1206561, "275499322938599766", 717871121)
addappid(1206562, 1, "2acab5beee720ed79f9dd82af12b58b6f26da5a338108137bb3fc3a9ebb9e2d1") -- (linux)
setManifestid(1206562, "8253564855964330400", 813355412)
addappid(1206563, 1, "a8274d9f4b7eb9fef72ff6c6f15ab8913f473de3e6dee34f77c85a0134884bc1") -- (macos)
setManifestid(1206563, "2328332092819105166", 876702219)
