-- Lua provided by RyzenAPI
-- Game: 3269270

-- MAIN APP DEPOTS / PACKAGES
addappid(3269270, 1)
-- Game: addappid(3269270, 1)
