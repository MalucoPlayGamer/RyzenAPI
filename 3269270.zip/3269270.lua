-- Lua provided by RyzenAPI
-- Game: Mafia: The Old Country - Gatto Nero Pack

-- MAIN APP DEPOTS / PACKAGES
addappid(3269270, 1)

