-- Lua provided by RyzenAPI
-- Game: addappid(3269270, 1)

-- MAIN APP DEPOTS / PACKAGES
addappid(3269270, 1)
