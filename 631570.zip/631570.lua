-- Lua provided by RyzenAPI
-- Game: Whispers of a Machine

-- MAIN APPLICATION
addappid(631570)

-- MAIN APP DEPOTS / PACKAGES
addappid(631571, 1, "d27bc18b75959ab647a470e55e734f85062f40389ab350570a4698418ba6c0f7")
addappid(631572, 1, "fecf631d4ee06b150b099edd72fd98d951aaec6c116764cac5846b768bed603b")

