-- Lua provided by RyzenAPI
-- Game: All Is Dust

-- MAIN APPLICATION
addappid(373330)

-- MAIN APP DEPOTS / PACKAGES
addappid(373331, 1, "3c7f53aab5963ebd26143339fd8b6a459ee626d9b3578580421344aba9f42a66")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
