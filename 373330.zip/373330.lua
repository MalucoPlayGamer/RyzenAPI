-- Lua provided by RyzenAPI
-- Game: addappid(373330)

-- MAIN APPLICATION
addappid(373330)

-- MAIN APP DEPOTS / PACKAGES
addappid(373331, 1, "3c7f53aab5963ebd26143339fd8b6a459ee626d9b3578580421344aba9f42a66")
