-- Lua provided by RyzenAPI
-- Game: Slash or Die 2

-- MAIN APPLICATION
addappid(644580)

-- MAIN APP DEPOTS / PACKAGES
addappid(644581, 1, "dbc2b5fde164f8992ec6ed4ab84296f04310c4bb4ca63fc9f77ea39bd71a506c")

