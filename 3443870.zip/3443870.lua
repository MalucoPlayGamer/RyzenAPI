-- Lua provided by SkyAPI 
-- Game: BUTTON PRISON
addappid(3443870)
addappid(3443871, 1, "b0052197632a8e150cf1efc445588eb2f3e11637f721e9ca108af269857658d3")
