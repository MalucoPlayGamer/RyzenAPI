-- Lua provided by RyzenAPI
-- Game: addappid(861480)

-- MAIN APPLICATION
addappid(861480)

-- MAIN APP DEPOTS / PACKAGES
addappid(861481, 1, "db2f8c1ea994128368d03b7cf3a1321b8e8a802fe3fadb194a2ee8740376f26a")
