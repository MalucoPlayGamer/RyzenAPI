-- Lua provided by RyzenAPI
-- Game: Clones

-- MAIN APPLICATION
addappid(72400)

-- MAIN APP DEPOTS / PACKAGES
addappid(72401, 1, "486c6dcd458cbfe7bb3bc9cd8e6dd08ef912311f17634593dea4e0347b4b58ea")
