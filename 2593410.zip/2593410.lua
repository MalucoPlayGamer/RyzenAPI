-- Lua provided by RyzenAPI
-- Game: 2593410

-- MAIN APPLICATION
addappid(2593410)
-- Game: addappid(2593410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2593412,0,"81d89c84fcf89bf1350d1a1a8f3e7d615ca8b279ce3859356ddcb6ea9ff5b9e4")
addappid(2593414,0,"e12d987942c5041cac9a89b393ee3f429ae0c2eec8cf32152b6954f43ae3124f")
