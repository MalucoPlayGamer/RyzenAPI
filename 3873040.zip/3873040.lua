-- 3873040's Lua and Manifest Created by Hubcap Manifest
-- Last Breath
-- Created: July 08, 2026 at 03:41:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3873040) -- Last Breath
-- MAIN APP DEPOTS
addappid(3873041, 1, "43614cb18c273840b0add117ac26ca912aa8c4425bafca28e23c8b1ff351e62f") -- Depot 3873041
setManifestid(3873041, "401963380904606426", 4970615772)