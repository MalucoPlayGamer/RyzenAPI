-- Lua provided by RyzenAPI
-- Game: addappid(956864)

-- MAIN APPLICATION
addappid(956864)

-- MAIN APP DEPOTS / PACKAGES
addappid(956864,0,"a502c7afe79318548a89634cace6ce674a3fad2cb2ca79fac48b32d424c71f04")
