-- Lua provided by RyzenAPI
-- Game: The Painter's Apprentice

-- MAIN APPLICATION
addappid(780630)

-- MAIN APP DEPOTS / PACKAGES
addappid(780631,0,"2a0bf26ed44aed43c0480915a2b4aed5363b98adf1c45e8c780414c05cc87ed7")

