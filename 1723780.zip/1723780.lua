-- Lua provided by RyzenAPI
-- Game: Finnish Cottage Simulator

-- MAIN APPLICATION
addappid(1723780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1723781, 1, "423942a94260c317f4cd8cc3a3f09e4a28488b2cc63c7109408c40a6afa1ab4c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
