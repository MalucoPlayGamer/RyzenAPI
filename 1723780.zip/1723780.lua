-- Lua provided by RyzenAPI
-- Game: Finnish Cottage Simulator

-- MAIN APPLICATION
addappid(1723780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1723781, 1, "423942a94260c317f4cd8cc3a3f09e4a28488b2cc63c7109408c40a6afa1ab4c")
