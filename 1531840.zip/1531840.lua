-- Lua provided by RyzenAPI
-- Game: Game: AppID 1531840

-- MAIN APPLICATION
addappid(1531840)
-- Game: addappid(1531840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1531841, 1, "e2d5eef747e09cb9f1d69b19174c75c14a24baaa7ae95d37353d209f5029c293")
