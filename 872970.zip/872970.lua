-- Lua provided by RyzenAPI
-- Game: Azurael's Circle: Chapter 1

-- MAIN APPLICATION
addappid(872970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(872971, 1, "68f2c08c901f658f3c9bbdb8fb9138edf01f8c12b65cd0a8db267848080d748f")

