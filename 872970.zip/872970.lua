-- Lua provided by RyzenAPI
-- Game: Game: Azurael's Circle: Chapter 1

-- MAIN APPLICATION
addappid(872970)
-- Game: addappid(872970)

-- MAIN APP DEPOTS / PACKAGES
addappid(872971, 1, "68f2c08c901f658f3c9bbdb8fb9138edf01f8c12b65cd0a8db267848080d748f")
