-- Lua provided by RyzenAPI 
-- Game: The Alliance Alive HD Remastered
addappid(1027250)
addappid(1027251, 1, "910def502bdc9414fb579cfeca7ef191158edf0a9b51fa45634bdc48f320d73f")
