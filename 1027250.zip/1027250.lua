-- Lua provided by RyzenAPI
-- Game: addappid(1027250)

-- MAIN APPLICATION
addappid(1027250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1027251, 1, "910def502bdc9414fb579cfeca7ef191158edf0a9b51fa45634bdc48f320d73f")
