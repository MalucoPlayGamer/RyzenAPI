-- Lua provided by RyzenAPI
-- Game: The Alliance Alive HD Remastered

-- MAIN APPLICATION
addappid(1027250)
addappid(1184100)
addappid(1184101)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(1027251, 1, "910def502bdc9414fb579cfeca7ef191158edf0a9b51fa45634bdc48f320d73f")

