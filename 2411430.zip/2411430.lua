-- Lua provided by RyzenAPI
-- Game: 不和我推谈恋爱就会死？！

-- MAIN APPLICATION
addappid(2411430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2411431, 1, "95b10618ce1c915fcb96a77be4a66a160ce3a7ddcf914f992868299ce23acb43")

