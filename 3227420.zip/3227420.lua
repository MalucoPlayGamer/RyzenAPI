-- Lua provided by RyzenAPI
-- Game: COPPER ODYSSEY 2

-- MAIN APPLICATION
addappid(3227420)
addappid(3487710)
-- Game: addappid(3227420)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227421, 1, "316dddfe96cebb05e4da3d4cf86f0594cd1c801ae2d7a294619c12a7fe1d5717")
