-- Lua provided by RyzenAPI
-- Game: My Lovable Demon

-- MAIN APPLICATION
addappid(3854420) -- My Lovable Demon
addappid(5099350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3854421, 1, "472790060214a6d4f97b512830d36ce54c0d3cb4e3bb7a347e5d19b586c9598b") -- Depot 3854421
addappid(5099350, 1, "b2ab20856fccd62bd14fdf759f37d8062ab911c7cb1585b587b9a725fc84b60f") -- Art Pack - Depot 5099350

