-- 3854420's Lua and Manifest Created by Hubcap Manifest
-- My Lovable Demon
-- Created: August 24, 2026 at 10:59:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3854420) -- My Lovable Demon
-- MAIN APP DEPOTS
addappid(3854421, 1, "472790060214a6d4f97b512830d36ce54c0d3cb4e3bb7a347e5d19b586c9598b") -- Depot 3854421
setManifestid(3854421, "6938883754402650970", 1146691379)
-- DLCS WITH DEDICATED DEPOTS
-- Art Pack (AppID: 5099350)
addappid(5099350)
addappid(5099350, 1, "b2ab20856fccd62bd14fdf759f37d8062ab911c7cb1585b587b9a725fc84b60f") -- Art Pack - Depot 5099350
setManifestid(5099350, "7483010933310063257", 280053191)