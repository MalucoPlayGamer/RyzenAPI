-- Lua provided by RyzenAPI
-- Game: Calculate It

-- MAIN APPLICATION
addappid(3043740)
-- Game: addappid(3043740)

-- MAIN APP DEPOTS / PACKAGES
addappid(3043741, 1, "dc9904d451a767bb28a0f1e19500c127bec5da7b99512b21b4ecf6b9da0fcdff")
