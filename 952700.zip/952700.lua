-- Lua provided by RyzenAPI
-- Game: addappid(952700)

-- MAIN APPLICATION
addappid(952700)

-- MAIN APP DEPOTS / PACKAGES
addappid(952701, 1, "9772fd7d2619f21a89a744272c07bd76ddd4fe253a7682cd877ab8b16ca64878")
