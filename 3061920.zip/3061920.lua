-- Lua provided by RyzenAPI
-- Game: Instinct

-- MAIN APPLICATION
addappid(3061920)
-- Game: addappid(3061920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3061921, 1, "5d6be12368b44fd2edf2d0a72f1dded154837253100ad1385b2e967fe1332f8b")
addappid(3061922, 1, "770c3d8250b52d29da0adef90a08c63bcbd82902170e38ef46d385990d359e22")
addappid(3061924, 1, "958c90c2a74e601ca37f507f8f1bdde0d863dce6aadd7d85f161364504109e46")
