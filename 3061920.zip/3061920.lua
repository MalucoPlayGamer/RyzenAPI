-- Lua provided by RyzenAPI
-- Game: Instinct

-- MAIN APPLICATION
addappid(3061920)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(3061921, 1, "5d6be12368b44fd2edf2d0a72f1dded154837253100ad1385b2e967fe1332f8b")
addappid(3061922, 1, "770c3d8250b52d29da0adef90a08c63bcbd82902170e38ef46d385990d359e22")
addappid(3061924, 1, "958c90c2a74e601ca37f507f8f1bdde0d863dce6aadd7d85f161364504109e46")

