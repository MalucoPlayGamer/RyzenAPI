-- Lua provided by RyzenAPI
-- Game: Akimbot

-- MAIN APPLICATION
addappid(1843540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843541, 1, "486ea887441e0b8b401d3b57e6e04eb34c2be01d96d3cf83560a9bc93d062443")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
