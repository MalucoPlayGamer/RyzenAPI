-- Lua provided by RyzenAPI
-- Game: Akimbot

-- MAIN APPLICATION
addappid(1843540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1843541, 1, "486ea887441e0b8b401d3b57e6e04eb34c2be01d96d3cf83560a9bc93d062443")

