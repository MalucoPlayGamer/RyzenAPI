-- Lua provided by RyzenAPI
-- Game: Game: Esports History Demo

-- MAIN APPLICATION
addappid(1742460)
-- Game: addappid(1742460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1742461, 1, "ced1f033aff01e5eaa98039dea971a5a30472c6b15177929ff67a842d973b9ed")
