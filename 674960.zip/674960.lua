-- Lua provided by RyzenAPI
-- Game: Gods of the Fallen Land

-- MAIN APPLICATION
addappid(674960)

-- MAIN APP DEPOTS / PACKAGES
addappid(674961, 1, "679c50e2f2b687a5ec7067a5fc4ab45cb18606507e3aad610209163066ed2b8f")

