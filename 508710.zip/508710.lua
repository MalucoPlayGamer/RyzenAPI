-- Lua provided by RyzenAPI
-- Game: AppID 508710

-- MAIN APPLICATION
addappid(508710)

-- MAIN APP DEPOTS / PACKAGES
addappid(508711, 1, "a7d00d0dd240cf30ea8ce5e5d9d880b8b5828c93d391b5cd1f525cd79bfd9f91")

