-- Lua provided by RyzenAPI
-- Game: 2299040

-- MAIN APPLICATION
addappid(2299040)
-- Game: addappid(2299040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2299041, 1, "9b56e5aaa161e042bcf2ddae8238087084802abf17bfa63d24f504309c4151d2")
