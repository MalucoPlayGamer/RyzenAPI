-- Lua provided by RyzenAPI
-- Game: Love Curse: Find Your Soulmate

-- MAIN APPLICATION
addappid(3069120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3069121, 1, "6c732b4ed048dcfd3e6058463893d907004b54c5ebcd916c9e3088778a62070d")

