-- Lua provided by RyzenAPI
-- Game: Game: Dungeon Village 2

-- MAIN APPLICATION
addappid(1983710)
-- Game: addappid(1983710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1983711, 1, "916fbb6379e2d5275fd26e16725d019a8a03bfa39656c0aaa481156d89889566")
