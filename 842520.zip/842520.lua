-- Lua provided by RyzenAPI
-- Game: Neon Void Runner

-- MAIN APPLICATION
addappid(842520)

-- MAIN APP DEPOTS / PACKAGES
addappid(842521,0,"bd0c96d47bbdf448be846632bde82ea6e6806fc06594c75d6176457bfabc124c")

