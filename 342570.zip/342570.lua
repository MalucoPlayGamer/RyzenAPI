-- Lua provided by RyzenAPI
-- Game: HIS (Heroes In the Sky)

-- MAIN APPLICATION
addappid(342570)

-- MAIN APP DEPOTS / PACKAGES
addappid(342571, 1, "2548c9c0112031aff6dac57080c61ec214b171a2c62d6ce33d6f60cb3ff155e7")

