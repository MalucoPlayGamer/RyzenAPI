-- Lua provided by RyzenAPI
-- Game: HIS (Heroes In the Sky)

-- MAIN APPLICATION
addappid(342570)

-- MAIN APP DEPOTS / PACKAGES
addappid(342571, 1, "2548c9c0112031aff6dac57080c61ec214b171a2c62d6ce33d6f60cb3ff155e7")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(352680)
addappid(353740)
addappid(353741)
addappid(353742)
addappid(353930)
addappid(354940)
addappid(355260)
addappid(355262)
addappid(356120)
addappid(356121)
addappid(356122)
addappid(356123)
addappid(356124)
addappid(369500)
addappid(369501)
addappid(369502)
addappid(369503)
addappid(369504)
addappid(369505)
addappid(369506)
addappid(369507)
addappid(369508)
addappid(369509)
addappid(369510)
addappid(369511)
