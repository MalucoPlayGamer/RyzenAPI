-- Lua provided by RyzenAPI
-- Game: Mysterious Blocks

-- MAIN APPLICATION
addappid(1565480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1565481, 1, "3d3d8283c12654794811532c51a259fcc8b86306f50db4d61a3e01b35b0df8b6")

