-- Lua provided by RyzenAPI
-- Game: Morphblade

-- MAIN APPLICATION
addappid(494720)
-- Game: addappid(494720)

-- MAIN APP DEPOTS / PACKAGES
addappid(494721, 1, "786ccca32e36d65937176e58abcc39577025c7f139424d710b5bb8c0b4df8a49")
