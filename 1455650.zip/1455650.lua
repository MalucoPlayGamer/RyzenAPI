-- Lua provided by RyzenAPI
-- Game: Facing

-- MAIN APPLICATION
addappid(1455650)
-- Game: addappid(1455650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455651, 1, "7db25c3e4b3b817d313f80769a3ffae20bd383389022ef40173be0d988668f3b")
