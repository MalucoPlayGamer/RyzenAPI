-- Lua provided by RyzenAPI
-- Game: Facing

-- MAIN APPLICATION
addappid(1455650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1455651, 1, "7db25c3e4b3b817d313f80769a3ffae20bd383389022ef40173be0d988668f3b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
