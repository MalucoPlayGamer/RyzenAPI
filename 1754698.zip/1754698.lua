-- Lua provided by RyzenAPI
-- Game: Atelier Sophie 2 - Plachta's Swimsuit "Clivia Nobilis"

-- MAIN APPLICATION
addappid(1754698)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754698,0,"0f1689965003e30d98b944f77870832ebfa9208f7b1f7bb2563f74aa66cce8f4")

