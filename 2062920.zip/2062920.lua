-- Lua provided by RyzenAPI
-- Game: 2062920

-- MAIN APPLICATION
addappid(2062920)
-- Game: addappid(2062920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2062921, 1, "2be0975ae0179068fd4101703c577523cc24d2f3e0cc1cf2b2a23d272aa11603")
