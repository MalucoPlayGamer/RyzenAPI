-- Lua provided by RyzenAPI
-- Game: AppID 378260

-- MAIN APPLICATION
addappid(378260)
-- Game: addappid(378260)

-- MAIN APP DEPOTS / PACKAGES
addappid(378261, 1, "69bc96420acf2d6c801976d96f129f4cfaa845d5fee1b5dec430d4f0bfde2b4c")
