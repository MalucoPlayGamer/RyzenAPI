-- Lua provided by RyzenAPI
-- Game: 1754050

-- MAIN APPLICATION
addappid(1754050)
-- Game: addappid(1754050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1754051, 1, "b9160acebfc11a3f0da357c8d0e23f91b14572341fd30d0685e29f0114a1dbfa")
