-- Lua provided by RyzenAPI
-- Game: 389730

-- MAIN APPLICATION
addappid(389730)
-- Game: addappid(389730)

-- MAIN APP DEPOTS / PACKAGES
addappid(389731, 1, "ced260a7f27dd73a1bdb16c642549470d25ee659c70bc35dc9879e23d38e811c")
