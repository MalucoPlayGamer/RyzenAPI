-- Lua provided by RyzenAPI
-- Game: Game: Severed Steel Demo

-- MAIN APPLICATION
addappid(1631910)
-- Game: addappid(1631910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631911, 1, "8818be4c5aa69f557ea90ee5443277153e7a97318e342f5de27b3925628513e9")
