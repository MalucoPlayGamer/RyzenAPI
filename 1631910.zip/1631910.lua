-- Lua provided by SkyAPI 
-- Game: Severed Steel Demo
addappid(1631910)
addappid(1631911, 1, "8818be4c5aa69f557ea90ee5443277153e7a97318e342f5de27b3925628513e9")
