-- Lua provided by RyzenAPI
-- Game: Grandpa's House

-- MAIN APPLICATION
addappid(2496940)
-- Game: addappid(2496940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2496941, 1, "dfb900c1f20b1e88585dbfe2529b64debb0694b3c8e5816890a7c0518f1fbee5")
