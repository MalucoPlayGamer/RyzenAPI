-- Lua provided by RyzenAPI
-- Game: Futanari Sex - The Gym

-- MAIN APPLICATION
addappid(2025060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2025061, 1, "abbc7b6a4ff4f48988530477ce475f1867c71936a83e5b6225d59f77708209b9")
