-- Lua provided by RyzenAPI
-- Game: Kukoos: Lost Pets

-- MAIN APPLICATION
addappid(1468250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(1468251, 1, "0bb3fca60f655345f6ccfcb2e21fe3f75d088159ce7b020608a51f02d1616dd6")

