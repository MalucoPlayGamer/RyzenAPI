-- Lua provided by RyzenAPI 
-- Game: Kukoos: Lost Pets
addappid(1468250)
addappid(1468251, 1, "0bb3fca60f655345f6ccfcb2e21fe3f75d088159ce7b020608a51f02d1616dd6")
