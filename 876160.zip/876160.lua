-- Lua provided by RyzenAPI
-- Game: Occupy White Walls

-- MAIN APPLICATION
addappid(876160)

-- MAIN APP DEPOTS / PACKAGES
addappid(876161, 1, "3c0ab511f67669fc4334a5f485f4d74d06245743e807fd63adb178ef0c802c5e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1125090)
