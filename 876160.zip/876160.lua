-- Lua provided by RyzenAPI
-- Game: Occupy White Walls

-- MAIN APPLICATION
addappid(876160)
-- Game: addappid(876160)

-- MAIN APP DEPOTS / PACKAGES
addappid(876161, 1, "3c0ab511f67669fc4334a5f485f4d74d06245743e807fd63adb178ef0c802c5e")
