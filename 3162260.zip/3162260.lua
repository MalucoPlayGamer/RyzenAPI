-- Lua provided by RyzenAPI
-- Game: Doll Catching Simulator

-- MAIN APPLICATION
addappid(3162260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3162262,0,"32be118d34f8f77e4edc13251cb383816f73ca90d7b615676fa65699a233633d")
