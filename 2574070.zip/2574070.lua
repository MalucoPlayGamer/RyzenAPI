-- Lua provided by RyzenAPI
-- Game: Ascent of Ashes Demo

-- MAIN APPLICATION
addappid(2574070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2574071, 1, "a6a366074fcf0b07de1bb47382102694f6174f8a713706045fac118e81bfc9e4")

