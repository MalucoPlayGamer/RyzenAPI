-- Lua provided by RyzenAPI
-- Game: Fatrifice

-- MAIN APPLICATION
addappid(2340250)
-- Game: addappid(2340250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340252,0,"4a00192e8870ad0440106ffa1fdd28f7e380ceceac07cd562e8ee3f9d820a544")
addappid(2340253,0,"a1d3f78d496247ede34d4d4d0e87a9f01ca0e47e2c8175bec0dbf85b6c75fc0b")
addappid(2345420,0,"784e194e53be32b85a38a460b2685331170894ce14a9bbe8600724869e1c78a5")
