-- Lua provided by RyzenAPI
-- Game: 3D PUZZLE - Farming 2

-- MAIN APPLICATION
addappid(2670720)
-- Game: addappid(2670720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2670721, 1, "a0ab69c0a58b51e8ec53e7b092f37658776f2f258a04ef329913bcea635df086")
