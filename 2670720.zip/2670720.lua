-- Lua provided by RyzenAPI
-- Game: addappid(2670720)

-- MAIN APPLICATION
addappid(2670720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2670721, 1, "a0ab69c0a58b51e8ec53e7b092f37658776f2f258a04ef329913bcea635df086")
