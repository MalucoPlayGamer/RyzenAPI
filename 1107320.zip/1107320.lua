-- Lua provided by SkyAPI 
-- Game: AppID 1107320
addappid(1107320)
addappid(1107321, 1, "6e3a930a48829c711299685f520f1f304a512102627facc243b6ff199e47906c")
