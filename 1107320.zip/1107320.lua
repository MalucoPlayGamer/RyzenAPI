-- Lua provided by RyzenAPI
-- Game: AppID 1107320

-- MAIN APPLICATION
addappid(1107320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1107321, 1, "6e3a930a48829c711299685f520f1f304a512102627facc243b6ff199e47906c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
