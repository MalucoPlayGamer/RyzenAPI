-- Lua provided by RyzenAPI
-- Game: Game: Outpost

-- MAIN APPLICATION
addappid(2339690)
-- Game: addappid(2339690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2339691, 1, "22930e068f59492053235a661562f39cad65b59e27439d5f3f6506487dc9f2fb")
