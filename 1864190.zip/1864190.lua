-- Lua provided by RyzenAPI
-- Game: AppID 1864190

-- MAIN APPLICATION
addappid(1864190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1864191, 1, "0488a5cfbc29e95601beaf37e81f826ed8d995299c0e018fba8229b572e7e87a")
addappid(1901120, 0, "5f1500fb29c61e9c0c60ed05e90d58256c525367c83f607c85020580c22b570b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
