-- Lua provided by RyzenAPI
-- Game: AppID 1202420

-- MAIN APPLICATION
addappid(1202420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1202421, 1, "ff2d1a15a5b01650e1554a127ef9520bac188f6e4eff67c59fa36ce15ea25e2b")

