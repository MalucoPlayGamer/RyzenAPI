-- Lua provided by RyzenAPI
-- Game: AppID 1202420

-- MAIN APPLICATION
addappid(1202420)
-- Game: addappid(1202420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202421, 1, "ff2d1a15a5b01650e1554a127ef9520bac188f6e4eff67c59fa36ce15ea25e2b")
