-- Generated with Luie @ https://lua.tools/
-- 3400350 - Third Crisis: Neon Nights
-- Generated 2026-08-29 06:59:03 UTC
-- # Depots (Total/DLC/Shared): 3/2/0

-- Main AppID
addappid(3400350, 1, "b5b7a7ddb7bd6becf50f0f3e59b6fce4335796f33bfc57465433be563aa52872")

-- Main Depots
addappid(3400351, 1, "d7235ae13dc595910e55dbe00a78c7f1944a44268fa6fea54330f1451bed200f")
setManifestid(3400351, "455322201823925033", 3814624704)

-- DLC's (no depot keys required)
addappid(4508330) -- Third Crisis: Neon Nights - Bonus Outfit

-- DLC's (with depot keys)
-- Third Crisis: Neon Nights (Original Soundtrack) (AppID: 4508790)
addappid(4508790)
addappid(4508791, 1, "b1de76ab9a21bebfa621e9d724d812b1cb8af607d985d15fa1e232e589e0e827")
setManifestid(4508791, "2793140172435451612", 987845808)
addappid(4508792, 1, "26e7c13e6a8c7ac7af6d18d641cab104b5a3ef31ddfef90a6f1e7cb65fc40577")
setManifestid(4508792, "7515656223376528465", 88318686)
