-- Lua provided by RyzenAPI
-- Game: Third Crisis: Neon Nights

-- MAIN APPLICATION
addappid(4508330) -- Third Crisis: Neon Nights - Bonus Outfit
addappid(4508790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3400350, 1, "b5b7a7ddb7bd6becf50f0f3e59b6fce4335796f33bfc57465433be563aa52872")
addappid(3400351, 1, "d7235ae13dc595910e55dbe00a78c7f1944a44268fa6fea54330f1451bed200f")
addappid(4508791, 1, "b1de76ab9a21bebfa621e9d724d812b1cb8af607d985d15fa1e232e589e0e827")
addappid(4508792, 1, "26e7c13e6a8c7ac7af6d18d641cab104b5a3ef31ddfef90a6f1e7cb65fc40577")

