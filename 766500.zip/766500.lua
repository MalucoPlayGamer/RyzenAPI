-- Lua provided by RyzenAPI
-- Game: Game: AppID 766500

-- MAIN APPLICATION
addappid(766500)
-- Game: addappid(766500)

-- MAIN APP DEPOTS / PACKAGES
addappid(766501, 1, "ef0fbd43c666865a96decda3a6033d8602cb086042fca53b94e91c1c13ae9663")
