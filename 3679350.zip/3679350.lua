-- Lua provided by RyzenAPI
-- Game: Trump Trade War

-- MAIN APPLICATION
addappid(3679350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3679351, 1, "3235c684b22639bf9478d28cc552aa770ba04311836e260143c63844fdab0f73")

