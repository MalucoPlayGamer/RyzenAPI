-- Lua provided by RyzenAPI
-- Game: addappid(2493010)

-- MAIN APPLICATION
addappid(2493010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2493011, 1, "fb067c6f6e79de9a1eccc05eab5b520d0307b50f8bf562940327bc7711a64be6")
