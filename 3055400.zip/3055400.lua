-- Lua provided by RyzenAPI 
-- Game: High School Rizz Party
addappid(3055400)
addappid(3055401, 1, "3cbc8256f965cd34ed41fb54797e372fa57b608db136591d498c214fb95cbafc")
