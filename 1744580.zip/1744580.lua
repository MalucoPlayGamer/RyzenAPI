-- Lua provided by RyzenAPI
-- Game: Game: EVAN QUEST

-- MAIN APPLICATION
addappid(1744580)
-- Game: addappid(1744580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744581, 1, "1e69a6c02f9cf0740b08016260d1fcf9fdcd26fe3003c4b747764e73a562c234")
