-- Lua provided by SkyAPI 
-- Game: EVAN QUEST
addappid(1744580)
addappid(1744581, 1, "1e69a6c02f9cf0740b08016260d1fcf9fdcd26fe3003c4b747764e73a562c234")
