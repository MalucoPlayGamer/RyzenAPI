-- Lua provided by RyzenAPI
-- Game: addappid(2426410)

-- MAIN APPLICATION
addappid(2426410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2426411, 1, "bed50cf82ef1454942f612c3fadedfb13d0e5853ab0746d5592b939625d0e7b5")
