-- Lua provided by RyzenAPI
-- Game: Game: Laundromat Manager Simulator Demo

-- MAIN APPLICATION
addappid(3507790)
-- Game: addappid(3507790)

-- MAIN APP DEPOTS / PACKAGES
addappid(3507791, 1, "ccc5f37eb12b9bc62f40e3cceca2905e386b4c3e824046a91f420c60c7015535")
