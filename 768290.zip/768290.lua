-- Lua provided by RyzenAPI
-- Game: Snow White Solitaire. Charmed Kingdom

-- MAIN APPLICATION
addappid(768290)

-- MAIN APP DEPOTS / PACKAGES
addappid(768291,0,"413f54f919a797a52c637db0f22211816d5d5001620cf83554bc6c6e8d37ed8d")
addappid(768293,0,"b03fc6571b41ab7d4f2061a2f55ae9842340120d4de8e5754ecadc980cb4ad9e")

