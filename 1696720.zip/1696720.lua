-- Lua provided by RyzenAPI 
-- Game: PsiloSybil
addappid(1696720)
addappid(1696721, 1, "de79744b829ff6b03c5ea14c814e47a931f3aef19a759dba2f6e8587595cb618")
