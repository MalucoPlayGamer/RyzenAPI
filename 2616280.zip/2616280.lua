-- Lua provided by RyzenAPI
-- Game: 2616280

-- MAIN APPLICATION
addappid(2616280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2616280,0,"90c0f4f999cf97c155faf05f4acb8867d891aa20949add3a6d86f83b36b1aba3")

