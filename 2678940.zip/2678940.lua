-- Lua provided by RyzenAPI
-- Game: 2678940

-- MAIN APPLICATION
addappid(2678940)
-- Game: addappid(2678940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2678941, 1, "a680515bfbf8e82aaa6557b3658c9adb22ce583ac6032709615d1207a5e2f261")
