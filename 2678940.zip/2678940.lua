-- Lua provided by RyzenAPI
-- Game: Avo Escape Space

-- MAIN APPLICATION
addappid(2678940)

-- MAIN APP DEPOTS / PACKAGES
addappid(2678941, 1, "a680515bfbf8e82aaa6557b3658c9adb22ce583ac6032709615d1207a5e2f261")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
