-- Lua provided by RyzenAPI
-- Game: 2817070

-- MAIN APPLICATION
addappid(2817070)
-- Game: addappid(2817070)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817071, 1, "00bc1164bbdaa489f83002c776a0f1d5c6affce87bb456246c25ae4e4d3e2ab0")
