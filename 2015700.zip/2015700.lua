-- Lua provided by RyzenAPI
-- Game: 东方心之解束~Saving from the devil

-- MAIN APPLICATION
addappid(2015700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015701, 1, "4a336bdd7ab95e0263da113b6131d3b72125b57d547d0ca180f9160be3551f0d")

