-- Lua provided by RyzenAPI
-- Game: addappid(2015700)

-- MAIN APPLICATION
addappid(2015700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2015701, 1, "4a336bdd7ab95e0263da113b6131d3b72125b57d547d0ca180f9160be3551f0d")
