-- Lua provided by RyzenAPI
-- Game: Game: ...

-- MAIN APPLICATION
addappid(1963980)
-- Game: addappid(1963980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1963981, 1, "96af90f34b23001a22d176d52079b3ac2e8182c4cfd298d5b2a09f7602c7da10")
