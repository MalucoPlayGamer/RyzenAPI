-- Lua provided by RyzenAPI
-- Game: Chamber of the Sci-Mutant Priestess

-- MAIN APPLICATION
addappid(768480)

-- MAIN APP DEPOTS / PACKAGES
addappid(768482,0,"554900dde5507530bd849fdaaaad84851755f89862238b307d5666f5c57024a5")

