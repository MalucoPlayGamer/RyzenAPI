-- Lua provided by RyzenAPI
-- Game: 509190

-- MAIN APPLICATION
addappid(509190)
addappid(522980)
-- Game: addappid(509190)

-- MAIN APP DEPOTS / PACKAGES
addappid(509191, 1, "29acdd6f3501998a5c25768c226a64038a878f5dbcfc982cf0574d78e0b293b8")
addappid(509192, 1, "c5a4d2d08e3c41b34922c5417cc3b2dab6185c038ef083bb27918af3354b0aec")
addappid(509193, 1, "9de0c77c1ca7fa7fa607b585b767184a29ba89b611baf0875ca9bb54c43cf552")
