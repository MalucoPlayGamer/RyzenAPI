-- Lua provided by RyzenAPI
-- Game: 2805590

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(2805590)
-- Game: addappid(2805590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2805592,0,"1956ff95f1eb2ee5d1927d5630859e7e15def23561aedafd084b2cb16ed28157")
