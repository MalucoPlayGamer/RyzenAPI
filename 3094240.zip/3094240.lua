-- Lua provided by SkyAPI 
-- Game: Super reaKtor Demo
addappid(3094240)
addappid(3094241, 1, "3adfe0d0a66617534915c134b21092e9e907a3b393abb5efa293ff8780bd204f")
