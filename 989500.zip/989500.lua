-- Lua provided by RyzenAPI
-- Game: 989500

-- MAIN APPLICATION
addappid(989500)

-- MAIN APP DEPOTS / PACKAGES
addappid(989500,0,"5e25c783e956c5909e1f3bce39ba1cb6df4f8a1486dd14c38403a9fbaad4a862")

