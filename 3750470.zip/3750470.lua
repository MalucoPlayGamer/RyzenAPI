-- Lua provided by RyzenAPI
-- Game: 新庄园时代

-- MAIN APPLICATION
addappid(3750470)
