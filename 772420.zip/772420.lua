-- Lua provided by RyzenAPI
-- Game: AppID 772420

-- MAIN APPLICATION
addappid(772420)
-- Game: addappid(772420)

-- MAIN APP DEPOTS / PACKAGES
addappid(772421, 1, "5db1663216b154e92c38274ef499664ccfd7addd01dc524d926611ed99a4db51")
