-- Lua provided by RyzenAPI
-- Game: addappid(676630)

-- MAIN APPLICATION
addappid(676630)

-- MAIN APP DEPOTS / PACKAGES
addappid(676631, 1, "82a7988ee109b331667e061f74cd0987175d6fd99ddfadcecbeffab7d4259041")
