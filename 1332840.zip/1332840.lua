-- Lua provided by RyzenAPI
-- Game: Rise and Fall

-- MAIN APPLICATION
addappid(1332840)
-- Game: addappid(1332840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1332841, 1, "5f4690389fa916acb92de0877f0c35e301939819319c5d854a40571094f460ba")
