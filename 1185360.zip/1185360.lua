-- Lua provided by RyzenAPI
-- Game: Game: AppID 1185360

-- MAIN APPLICATION
addappid(1185360)
-- Game: addappid(1185360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1185361, 1, "2068bf280669cf4951281f861fde85581ddf724d980ab3f7acc5b97853bf25f8")
