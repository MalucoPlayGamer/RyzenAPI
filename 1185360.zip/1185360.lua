-- Lua provided by SkyAPI 
-- Game: AppID 1185360
addappid(1185360)
addappid(1185361, 1, "2068bf280669cf4951281f861fde85581ddf724d980ab3f7acc5b97853bf25f8")
