-- Lua provided by RyzenAPI
-- Game: AppID 1185360

-- MAIN APPLICATION
addappid(1185360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1185361, 1, "2068bf280669cf4951281f861fde85581ddf724d980ab3f7acc5b97853bf25f8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
