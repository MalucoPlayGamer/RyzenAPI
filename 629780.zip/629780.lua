-- Lua provided by RyzenAPI
-- Game: WizzBall

-- MAIN APPLICATION
addappid(629780)

-- MAIN APP DEPOTS / PACKAGES
addappid(629781,0,"ba13909e67e8288e5f893c74408ea02277c0dcc876b0498a0eb10abc3efcbb53")

