-- Lua provided by RyzenAPI 
-- Game: AppID 2469270
addappid(2469270)
addappid(2469271, 1, "5fc83070aceb29012fab453eeaae35a1de2f3660f6128721c46c6d42bb575fa7")
