-- Lua provided by RyzenAPI
-- Game: Game: Speedball 2 HD

-- MAIN APPLICATION
addappid(251690)
-- Game: addappid(251690)

-- MAIN APP DEPOTS / PACKAGES
addappid(251691, 1, "3dade2edb9f510c018445ad9ae1e4e21d752de5ca2210c39bfe05ae06350c3ae")
