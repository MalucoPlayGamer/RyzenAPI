-- Lua provided by RyzenAPI
-- Game: Speedball 2 HD

-- MAIN APPLICATION
addappid(251690)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(251691, 1, "3dade2edb9f510c018445ad9ae1e4e21d752de5ca2210c39bfe05ae06350c3ae")

