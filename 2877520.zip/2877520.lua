-- Lua provided by RyzenAPI
-- Game: 緋櫻白狐 Demo

-- MAIN APPLICATION
addappid(2877520)
-- Game: addappid(2877520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2877521, 1, "1f6ef577fe411b79893cf048aad5c8a16bf2fc3a1711a3bebd2b7b15b6e8d127")
