-- Lua provided by RyzenAPI
-- Game: 冷血症骰子

-- MAIN APPLICATION
addappid(1401220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1401221, 1, "c4fc3754c5442447b49f68c67d3427a51db93a794bceee096adf2586dcfa5c34")
