-- Lua provided by RyzenAPI
-- Game: Game: AshenForest

-- MAIN APPLICATION
addappid(1160020)
-- Game: addappid(1160020)

-- MAIN APP DEPOTS / PACKAGES
addappid(1160021, 1, "bbb66420d60ca7c5b0194ba5413a39f5c0e317565a13bbbbaf7b91df97288450")
