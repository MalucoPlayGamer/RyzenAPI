-- Lua provided by RyzenAPI
-- Game: Solas City Heroes Demo

-- MAIN APPLICATION
addappid(2127670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2127671, 1, "b78dbd88e4325e87cefcf8dea8d7a3899c6421aa24b64808faec1dcb31109c8b")

