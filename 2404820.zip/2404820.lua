-- Lua provided by RyzenAPI
-- Game: 2404820

-- MAIN APPLICATION
addappid(2404820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2404822,0,"bf92dc138f38edcef8e1128c3fc12bd92240812ab167a6786d3b21fb8ada8ce6")
addappid(2404823,0,"004bf4483a5ecfc69cf31f6559e0da40d52808fa59f52a178cac0c46c6b9ae2f")
addappid(2404824,0,"6dffb6a9d644c68a67b3cd800aed397e464d3ddece00497c999fb16697bcad3a")

