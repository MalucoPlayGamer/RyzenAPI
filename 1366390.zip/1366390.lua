-- Lua provided by RyzenAPI
-- Game: LuPR: Lunar Post Recruit

-- MAIN APPLICATION
addappid(1366390)

-- MAIN APP DEPOTS / PACKAGES
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(1366391, 1, "a121086abe5be3aca9d3712171f3b8a584ebac55f352de68d184543cbaabeee2")

