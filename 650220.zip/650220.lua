-- Lua provided by RyzenAPI
-- Game: Interplanetary: Enhanced Edition

-- MAIN APPLICATION
addappid(650220)
addappid(674700)
addappid(674702)
addappid(674703)
addappid(674704)
-- Game: addappid(650220)

-- MAIN APP DEPOTS / PACKAGES
addappid(650228,0,"84654ff85826e949bc171075dd1b4a701724ac9b2b40762493d1c4c4783f6496")
addappid(650229,0,"6edeefdf5d6e64efc6056044a8aaab52d0818b2726c3694ab88ff609167beba5")
addappid(674701,0,"24e43c2458b149c858d98b624d502308867ea92f74bd4ae01b6012c9f95fabed")
