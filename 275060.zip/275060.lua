-- Lua provided by RyzenAPI
-- Game: 275060

-- MAIN APPLICATION
addappid(228985)
addappid(228990)
addappid(229004)
addappid(275060)

-- MAIN APP DEPOTS / PACKAGES
addappid(275062,0,"5fc3cdbfd9725c25061a073ca8a00c20ebcb6949288a87a24e96957e701784a0")
