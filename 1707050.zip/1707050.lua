-- Lua provided by RyzenAPI
-- Game: Geo-Duck

-- MAIN APPLICATION
addappid(1707050)
-- Game: addappid(1707050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1707051, 1, "952aa71c82abf2c7b1206f445f798106003f5114033eeb79514d08a97e8a5367")
addappid(1707052, 1, "0dcc801a3e87fb72e2bc5f7d610b23fed18ae1ba1c4147091c2d7e7b7c9a412e")
