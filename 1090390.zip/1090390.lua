-- Lua provided by RyzenAPI
-- Game: House of 1000 Doors: Serpent Flame

-- MAIN APPLICATION
addappid(1090390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1090391, 1, "4787cd9b8dea4008a3c7ece34e57120fb0aacb0fb98041c709019f834aa4990e")
addappid(1090398, 1, "8a62d15323ae81510a88f9b7594f1921a1a641dafc00b13fd70e45f528f75da0")
