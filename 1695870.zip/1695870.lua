-- Lua provided by RyzenAPI
-- Game: DunDun VR

-- MAIN APPLICATION
addappid(1695870)
-- Game: addappid(1695870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1695871, 1, "7394edd27118c9ba2d04979a1e39f53609ca4efc11768ff0e0483081928bd51a")
