-- Lua provided by SkyAPI 
-- Game: DunDun VR
addappid(1695870)
addappid(1695871, 1, "7394edd27118c9ba2d04979a1e39f53609ca4efc11768ff0e0483081928bd51a")
