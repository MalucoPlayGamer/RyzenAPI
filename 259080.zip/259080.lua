-- Lua provided by RyzenAPI
-- Game: Game: AppID 259080

-- MAIN APPLICATION
addappid(259080)
addappid(271540)
addappid(271750)
-- Game: addappid(259080)

-- MAIN APP DEPOTS / PACKAGES
addappid(259081, 1, "2291d5589d16735839216456b9f70bf6fc47a843051e21e663b8533c50a86530")
