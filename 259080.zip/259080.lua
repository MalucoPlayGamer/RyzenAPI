-- Lua provided by RyzenAPI
-- Game: Just Cause 2: Multiplayer Mod

-- MAIN APPLICATION
addappid(259080)
addappid(271540)
addappid(271750)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(259081, 1, "2291d5589d16735839216456b9f70bf6fc47a843051e21e663b8533c50a86530")
