-- Lua provided by RyzenAPI
-- Game: 589510

-- MAIN APPLICATION
addappid(589510)
-- Game: addappid(589510)

-- MAIN APP DEPOTS / PACKAGES
addappid(589511, 1, "8872a7d9a27f4aa318e79dfeb50ec4fdf2a846b40d6569662a9c4c89bd3a7b84")
