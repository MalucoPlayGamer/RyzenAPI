-- Lua provided by RyzenAPI
-- Game: Shovel Knight: Specter of Torment

-- MAIN APPLICATION
addappid(589510)

-- MAIN APP DEPOTS / PACKAGES
addappid(589511, 1, "8872a7d9a27f4aa318e79dfeb50ec4fdf2a846b40d6569662a9c4c89bd3a7b84")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
