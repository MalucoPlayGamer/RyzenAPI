-- Lua provided by RyzenAPI
-- Game: Sakura Beach

-- MAIN APPLICATION
addappid(377680)

-- MAIN APP DEPOTS / PACKAGES
addappid(377681, 1, "33c58c64b3032abe03a66187d21744a56dc75192844e9c0eabd4f499cda8f712")

