-- Lua provided by RyzenAPI
-- Game: 道衍诀

-- MAIN APPLICATION
addappid(1951220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1951222,0,"d59bbabba349cc1d33ae024766224fc322622cb671a09a4437b7c3f8d5265da6")
