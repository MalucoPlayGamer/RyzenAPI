-- Lua provided by RyzenAPI
-- Game: Game: AppID 1096000

-- MAIN APPLICATION
addappid(1096000)
-- Game: addappid(1096000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1096001, 1, "1abd8f318b97b1bb9b3c2077c7457e6a70152c4bb193497f583e9e586546801a")
