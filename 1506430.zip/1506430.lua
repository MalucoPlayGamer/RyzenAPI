-- Lua provided by SkyAPI 
-- Game: AppID 1506430
addappid(1506430)
addappid(1506431, 1, "1b4ad49c0b4076fb3050b9c6c0e77b5c9955b9ff3573757012d1f5b91cb20f7c")
