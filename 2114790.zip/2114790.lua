-- Lua provided by RyzenAPI 
-- Game: AIdventure
addappid(2114790)
addappid(2114791, 1, "6d2527c2237743e83a5c86cc00cd2c564c624575f4466b79dc6b701a224b35ea")
