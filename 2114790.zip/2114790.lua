-- Lua provided by RyzenAPI
-- Game: Game: AIdventure

-- MAIN APPLICATION
addappid(2114790)
-- Game: addappid(2114790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2114791, 1, "6d2527c2237743e83a5c86cc00cd2c564c624575f4466b79dc6b701a224b35ea")
