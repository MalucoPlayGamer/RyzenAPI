-- Lua provided by RyzenAPI
-- Game: Guilty Gear -Strive- Original Soundtrack Necessary Discrepancy Disc 1

-- MAIN APPLICATION
addappid(1998650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1998651, 1, "dcbf48645dba4d9eca0d76f45d2cc74c27e570e14b6d7b5cdac07cc5f4b3fbbc")
addappid(1998652, 1, "5aa40b440760e690eed6f20f20238a97e6a3a6adbc953307072eda8b315513eb")

