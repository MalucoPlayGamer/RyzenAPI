-- Lua provided by RyzenAPI
-- Game: addappid(2738420)

-- MAIN APPLICATION
addappid(2738420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738421, 1, "9406b62ed5d8751866726b7cd2a363956c2e2e07a6053ffbfd027dd435651ccd")
