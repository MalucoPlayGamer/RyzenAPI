-- Lua provided by RyzenAPI
-- Game: AppID 2738420

-- MAIN APPLICATION
addappid(2738420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2738421, 1, "9406b62ed5d8751866726b7cd2a363956c2e2e07a6053ffbfd027dd435651ccd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
