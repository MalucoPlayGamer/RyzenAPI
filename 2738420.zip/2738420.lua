-- Lua provided by SkyAPI 
-- Game: AppID 2738420
addappid(2738420)
addappid(2738421, 1, "9406b62ed5d8751866726b7cd2a363956c2e2e07a6053ffbfd027dd435651ccd")
