-- Lua provided by RyzenAPI
-- Game: AppID 477950

-- MAIN APPLICATION
addappid(477950)
-- Game: addappid(477950)

-- MAIN APP DEPOTS / PACKAGES
addappid(477951, 1, "c451ac7a9d58ce6d06ea8069359db44338ebd12615b7917788ebf438906ec5ab")
