-- Lua provided by RyzenAPI
-- Game: Superscout

-- MAIN APPLICATION
addappid(2862610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2862611, 1, "dfdfcbe0f12d3f777564ca192f7726d31e382f0070d18003edfdd55d3ed1358d")
addappid(2862612, 1, "2655c9499a351b532fc4382bd6da5aa9a05a07d3f8f7b63c53e486fa31723c35")
addappid(2862613, 1, "c88a9385e7d4b7133798484fc01ce0d75e256d82aa6c3886ae2d59542876ac6d")
addappid(2862614, 1, "1ec1648064cfca57c089bfe0cd807e223b90bfbbd9b1cfe9baaa3c01602ec020")
addappid(2862615, 1, "8bf3cec8d208880cf50a0471786fe72501759490e1a768d9ceea23da14f5376f")
addappid(2862616, 1, "b7923ca8beda33d6cdc931286e876282b46b7835d1c01a8d87ddc1b91fd5a8db")
addappid(2862617, 1, "fe24fd9589ea9faffff8bc789d64e296ca3bd4a575b2274c0eab91ef1d0f27b6")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3090560)
