-- Lua provided by RyzenAPI
-- Game: Zombidle : REMONSTERED

-- MAIN APPLICATION
addappid(612020)
addappid(705520)
addappid(705540)
addappid(705560)
addappid(746230)
addappid(1074560)

