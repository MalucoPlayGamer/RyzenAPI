-- Lua provided by RyzenAPI
-- Game: Zombidle : REMONSTERED

-- MAIN APPLICATION
addappid(612020)

