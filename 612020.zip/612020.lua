-- Lua provided by RyzenAPI
-- Game: Zombidle : REMONSTERED

-- MAIN APPLICATION
addappid(612020)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(705520)
addappid(705540)
addappid(705560)
addappid(746230)
addappid(1074560)
