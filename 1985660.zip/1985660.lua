-- Lua provided by RyzenAPI
-- Game: addappid(1985660)

-- MAIN APPLICATION
addappid(1985660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1985661, 1, "5a8447e916a4dd1d7c26a811c06709dbf1dece512f7b8a7f1ba4e6fbe5f4a3b3")
