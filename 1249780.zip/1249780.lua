-- Lua provided by RyzenAPI
-- Game: Iron Disco

-- MAIN APPLICATION
addappid(1249780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1249781, 1, "9812605c32e8d7f35f9dff456c410d20f1f4a968325869387907a0274947f952")
addappid(1660760, 0, "4851eca26284c5563db4547914e1282c969a93a687df117a6e36d78a4c0671e2")
