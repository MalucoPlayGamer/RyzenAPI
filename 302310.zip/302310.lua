-- Lua provided by RyzenAPI
-- Game: Dungeon of Elements

-- MAIN APPLICATION
addappid(302310)

-- MAIN APP DEPOTS / PACKAGES
addappid(302311, 1, "81d5732c1b4498499a1fd619030d6b83d504d8dd8eccde982a04c7a70929eac1")
addappid(302312, 1, "0cc60969c123cb86f6e30958b01f572f405e68e8daf230bf623c849ba2083e9a")
addappid(302313, 1, "ebf07cc9bb568933962c1e3a2cbf18e80674b1d4fbc2a780b644b7e4bab67551")

