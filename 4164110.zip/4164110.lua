-- Lua provided by RyzenAPI
-- Game: Closed Circuit: Recursive Idle

-- MAIN APPLICATION
addappid(4164110) -- Closed Circuit: Recursive Idle
-- addappid(4164112) -- Depot 4164112 (empty depot)

-- MAIN APP DEPOTS / PACKAGES
addappid(4164111, 1, "f60979b056fc9de64954ee069d002fbfa3517e37a161b57f38149d569678e460") -- Depot 4164111

