-- 4164110's Lua and Manifest Created by Hubcap Manifest
-- Closed Circuit: Recursive Idle
-- Created: August 10, 2026 at 13:56:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4164110) -- Closed Circuit: Recursive Idle
-- MAIN APP DEPOTS
addappid(4164111, 1, "f60979b056fc9de64954ee069d002fbfa3517e37a161b57f38149d569678e460") -- Depot 4164111
setManifestid(4164111, "1367092797320426789", 171664358)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4164112) -- Depot 4164112 (empty depot)