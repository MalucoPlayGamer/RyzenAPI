-- Lua provided by RyzenAPI 
-- Game: Persona 4 Arena Ultimax
addappid(1602010)
addappid(1602011, 1, "bda80d85becc8413a5051192377fce270c19310afa645bdb331247e705363b60")
