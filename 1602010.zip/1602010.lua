-- Lua provided by RyzenAPI
-- Game: Persona 4 Arena Ultimax

-- MAIN APPLICATION
addappid(1602010)

-- MAIN APP DEPOTS / PACKAGES
addappid(1602011, 1, "bda80d85becc8413a5051192377fce270c19310afa645bdb331247e705363b60")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
