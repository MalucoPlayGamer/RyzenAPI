-- Lua provided by RyzenAPI
-- Game: RPG Maker MZ - SERIALGAMES Living Good City Tileset - 80's Scene SET

-- MAIN APPLICATION
addappid(2945480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945480,0,"1d8850cf1e9b22cb1487847b710f25a0882de99cf912026d8ee712803e97baeb")
