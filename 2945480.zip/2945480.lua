-- Lua provided by RyzenAPI
-- Game: 2945480

-- MAIN APPLICATION
addappid(2945480)
-- Game: addappid(2945480)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945480,0,"1d8850cf1e9b22cb1487847b710f25a0882de99cf912026d8ee712803e97baeb")
