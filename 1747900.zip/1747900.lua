-- Lua provided by RyzenAPI
-- Game: Enchanted Blacksmith

-- MAIN APPLICATION
addappid(1747900)

-- MAIN APP DEPOTS / PACKAGES
addappid(1747901, 1, "e480c5808bfe60c0a64a898af95659eabab40c2b8c86cb05fed87747b6d3036b")

