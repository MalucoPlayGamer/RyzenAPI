-- Lua provided by RyzenAPI
-- Game: Dread Hunger

-- MAIN APPLICATION
addappid(1418630)
addappid(1874970)
addappid(1874971)
addappid(1874972)
addappid(1874973)
addappid(1874974)
addappid(1874975)
addappid(1874976)
addappid(1908760)
addappid(1908761)
addappid(1908762)
addappid(2002130)
addappid(2002150)
addappid(2002170)
addappid(2164000)
addappid(2164001)
addappid(2164002)
addappid(2164003)
addappid(2164004)
addappid(2164005)
addappid(2164006)
addappid(2164007)
addappid(2164008)
addappid(2164009)
addappid(2164010)
addappid(2164011)
addappid(2164190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1418631, 1, "a256761f4bb960e6da0b51d94a2db1b90a271ffe045488386fe71923954b6eda")

