-- Lua provided by RyzenAPI 
-- Game: Dread Hunger
addappid(1418630)
addappid(1418631, 1, "a256761f4bb960e6da0b51d94a2db1b90a271ffe045488386fe71923954b6eda")
