-- Lua provided by RyzenAPI
-- Game: Godslayer Arena

-- MAIN APPLICATION
addappid(2870430)

-- MAIN APP DEPOTS / PACKAGES
addappid(2870431, 1, "fee213fd375ad3a530c3de459562eacf8fca03e04cc93bd25d2d417b06ff5c68")

