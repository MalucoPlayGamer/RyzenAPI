-- Lua provided by RyzenAPI
-- Game: AppID 417920

-- MAIN APPLICATION
addappid(417920)
-- Game: addappid(417920)

-- MAIN APP DEPOTS / PACKAGES
addappid(417921, 1, "062cb8de17f79f6f3750def142db8bf369ed4e7a1f08f29818675d4c2536f8c1")
