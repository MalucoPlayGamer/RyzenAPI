-- Lua provided by RyzenAPI
-- Game: Fuel Station Simulator

-- MAIN APPLICATION
addappid(2697520)

-- MAIN APP DEPOTS / PACKAGES
addappid(2697521, 1, "a8e6842d10a0d9ce02130694ee2418c68e1bc4315086d486a026df433a00d8f8")
