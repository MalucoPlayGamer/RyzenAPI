-- Lua provided by RyzenAPI
-- Game: TOTALLY BASEBALL

-- MAIN APPLICATION
addappid(1192380)

-- MAIN APP DEPOTS / PACKAGES
addappid(1192381, 1, "3edc31ea8ca6c62405c07aebd58796aa20afc6d8030b4ec84a51e4c7ca5ef72f")

