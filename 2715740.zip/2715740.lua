-- Lua provided by RyzenAPI 
-- Game: Tutor X Hypnosis
addappid(2715740)
addappid(2715741, 1, "b48b4efb2d15e391694e503a215068f64d0a4a6e290bb28a1709ac69c1d5df9f")
addappid(2732170, 0, "142588d91e4ded0f459e1c1899f761cff57f781b015ca06db6ef917820a10e02")
