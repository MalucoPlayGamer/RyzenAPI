-- Lua provided by RyzenAPI
-- Game: Ghosts of War: Battle Royale WW2 Shooting games

-- MAIN APPLICATION
addappid(1755120)
-- Game: addappid(1755120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1755121, 1, "646993f3e460a466a43ff50646b47005fcccee08ecfc1a12a2146bff5353dfa9")
