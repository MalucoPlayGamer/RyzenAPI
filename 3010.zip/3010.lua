-- Lua provided by RyzenAPI
-- Game: Xpand Rally

-- MAIN APPLICATION
addappid(3010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3011, 1, "22becf2930cce43c3dcd394c54ab8122cbfd5e114ea2dc715eedca768223eafb")
