-- Lua provided by RyzenAPI
-- Game: Game: AppID 1525650

-- MAIN APPLICATION
addappid(1525650)
-- Game: addappid(1525650)

-- MAIN APP DEPOTS / PACKAGES
addappid(1525651, 1, "2718b2df8da9d9165a038b9aa91738489f9b62090599e78128ff2e3b0a4e08c5")
