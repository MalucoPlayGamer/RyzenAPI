-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(3456140)

-- MAIN APP DEPOTS / PACKAGES
addappid(3456140,0,"1fb3060c7feaa00a33f30eb3961010a578d2b38a9e2e99fc31ff8ff618f72819")

