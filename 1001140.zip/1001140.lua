-- Lua provided by RyzenAPI
-- Game: Angry Birds VR: Isle of Pigs

-- MAIN APPLICATION
addappid(1001140)
-- Game: addappid(1001140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1001141, 1, "81c14580c1a52c0777c343a23877b949988ebfec4c862156b88978af0ff32211")
