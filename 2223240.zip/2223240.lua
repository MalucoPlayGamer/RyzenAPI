-- Lua provided by RyzenAPI
-- Game: Sword and Fairy 7 - Dreamlike World Expansion

-- MAIN APPLICATION
addappid(2223240)
-- Game: addappid(2223240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2223241, 1, "c7d3ba2342020f382cb7e6c7f202bbb7a136283e87870d04190562e15966f398")
