-- Lua provided by RyzenAPI
-- Game: Game: Pixel Gladiator

-- MAIN APPLICATION
addappid(542400)
addappid(566760)
-- Game: addappid(542400)

-- MAIN APP DEPOTS / PACKAGES
addappid(542401, 1, "0b1f2970edb076b03a61fec3d1a9bcd4474e43fb318da25e6317488e84bc09f6")
