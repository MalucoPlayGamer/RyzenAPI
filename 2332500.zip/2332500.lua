-- Lua provided by RyzenAPI
-- Game: Isekai Frontier

-- MAIN APPLICATION
addappid(2332500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2332501, 1, "4b2706b11fd2244a5779e751972fc83e13f394f717c240a34ac1c96b6c173d84")
