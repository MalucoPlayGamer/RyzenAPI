-- Lua provided by RyzenAPI
-- Game: Monster College

-- MAIN APPLICATION
addappid(2384600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384601, 1, "ed1624f29073628f5ba1bbde4ba9a4b1416104d2480e065d87b11ed307051291")
