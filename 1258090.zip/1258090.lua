-- Lua provided by RyzenAPI
-- Game: Duck Duck Goose

-- MAIN APPLICATION
addappid(1258090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258091, 1, "601b608565aa2d53ff782147fc4ba49195bb706f2158c1f4039935bf86adae77")

