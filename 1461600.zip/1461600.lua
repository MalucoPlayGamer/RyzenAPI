-- Lua provided by RyzenAPI
-- Game: Project Sparrow

-- MAIN APPLICATION
addappid(1461600)

-- MAIN APP DEPOTS / PACKAGES
addappid(1461601, 1, "cbc746b053c338692113af793b41bbe7050161c76c1ff20a478fb19f65b81816")
