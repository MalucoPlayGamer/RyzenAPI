-- Lua provided by SkyAPI 
-- Game: Project Sparrow
addappid(1461600)
addappid(1461601, 1, "cbc746b053c338692113af793b41bbe7050161c76c1ff20a478fb19f65b81816")
