-- Lua provided by RyzenAPI
-- Game: Game: Sweety Kitty

-- MAIN APPLICATION
addappid(2156450)
-- Game: addappid(2156450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156451, 1, "24d570b30d62d77f3338452bc5bd12f31ebc3ce8f5bf055bc83daa952da4053c")
