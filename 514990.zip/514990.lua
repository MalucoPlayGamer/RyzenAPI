-- Lua provided by RyzenAPI
-- Game: AppID 514990

-- MAIN APPLICATION
addappid(514990)

-- MAIN APP DEPOTS / PACKAGES
addappid(514991, 1, "643921d72f170c43ac2e52d6379275cbfc1099119c84a08c01047f18017ed1cd")
addappid(514992, 1, "6dd6694ea0db776fe8153a09a01946c671859a4ecee7f200bf5e2306d0d81f31")
addappid(514993, 1, "0d7a03e285619770c83110c30da511ec0437529c8542f5da833d7679f9fcd2da")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(589610)
addappid(590160)
addappid(590161)
addappid(590162)
addappid(593500)
addappid(593501)
addappid(593502)
addappid(593503)
