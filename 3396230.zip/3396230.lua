-- Lua provided by RyzenAPI
-- Game: addappid(3396230)

-- MAIN APPLICATION
addappid(3396230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3396232,0,"030490bf761a31c86db9ff08cccaab0de95afe968db167e970c4ab49a833409a")
