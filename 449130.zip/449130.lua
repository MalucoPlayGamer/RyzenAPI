-- Lua provided by RyzenAPI
-- Game: ENGAGE

-- MAIN APPLICATION
addappid(449130)

-- MAIN APP DEPOTS / PACKAGES
addappid(449131, 1, "25e285161fc30c53d4d657c4127dc5564b8b8cc27ec0529775cf104f801c7d9d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
