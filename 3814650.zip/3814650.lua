-- Lua provided by RyzenAPI
-- Game: addappid(3814650)

-- MAIN APPLICATION
addappid(3814650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3814653,0,"b474056d9740f0e226b88763b241974d545eeb0380ff7f4a42f003c4ba0aeb2b")
