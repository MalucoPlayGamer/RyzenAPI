-- Lua provided by RyzenAPI
-- Game: Dark Canyon

-- MAIN APPLICATION
addappid(1509560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509561, 1, "b198d088fab17596e77b5cfe2b7d2cb6b42f7d85a21351c05786b366a550173c")
