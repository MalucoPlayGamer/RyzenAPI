-- Lua provided by RyzenAPI
-- Game: Lone Leader

-- MAIN APPLICATION
addappid(518800)

-- MAIN APP DEPOTS / PACKAGES
addappid(518801, 1, "738e2fdf04e8093a7f0a141ec371a5c48204810fbb664dfa35a34250d67c66cc")
