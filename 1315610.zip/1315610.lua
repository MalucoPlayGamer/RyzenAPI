-- Lua provided by RyzenAPI
-- Game: addappid(1315610)

-- MAIN APPLICATION
addappid(1315610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1315611, 1, "f38f257f40756cbc627b4e1a50b69380dea545724cf9d812235a3f6b75cfd54a")
