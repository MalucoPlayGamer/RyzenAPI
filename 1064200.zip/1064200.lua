-- Lua provided by RyzenAPI
-- Game: Game: AppID 1064200

-- MAIN APPLICATION
addappid(1064200)
-- Game: addappid(1064200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1064201, 1, "4c66597b86cc1881afbd23b89981b31045452ee7de5fd5d1925f67262994271f")
