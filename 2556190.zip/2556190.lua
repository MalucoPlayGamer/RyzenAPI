-- Lua provided by RyzenAPI
-- Game: addappid(2556190)

-- MAIN APPLICATION
addappid(2556190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556191, 1, "e65a399d86ba8eb9019f0583af3ae28f0740e9a28d2691d4934350f06bcbafde")
