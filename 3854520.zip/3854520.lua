-- Lua provided by RyzenAPI
-- Game: addappid(3854520)

-- MAIN APPLICATION
addappid(3854520)

-- MAIN APP DEPOTS / PACKAGES
addappid(3854521, 1, "c3e06aa74e07aa615aa740b02efcf503e49c8b7899a22b8dbb313bf64c29646a")
