-- Lua provided by RyzenAPI
-- Game: 3537410

-- MAIN APPLICATION
addappid(3537410)
-- Game: addappid(3537410)

-- MAIN APP DEPOTS / PACKAGES
addappid(3537411, 1, "5d1fce0c0c4ce92d6f2feb9526580fc4fa901ef6328d60077cdc4dc42992102f")
