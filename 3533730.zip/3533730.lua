-- Lua provided by RyzenAPI
-- Game: 3533730

-- MAIN APPLICATION
addappid(3533730)
-- Game: addappid(3533730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3533731, 1, "1180e2ce90b77b8faffadeac719cb2d71c9e0fb99c90a3c0b672cc1c3cfa129c")
