-- Lua provided by RyzenAPI
-- Game: Warhammer 40,000: Boltgun - Words of Vengeance

-- MAIN APPLICATION
addappid(3533730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3533731, 1, "1180e2ce90b77b8faffadeac719cb2d71c9e0fb99c90a3c0b672cc1c3cfa129c")

