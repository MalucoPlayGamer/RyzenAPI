-- Lua provided by RyzenAPI
-- Game: Welcome to Empyreum Demo

-- MAIN APPLICATION
addappid(1864740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1864741, 1, "7ca6f2b045d1c360c796ab4751fc2d90cba5b7a4c86e46c3a0762884e56529a4")
