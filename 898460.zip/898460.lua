-- Lua provided by RyzenAPI
-- Game: Walkabout

-- MAIN APPLICATION
addappid(898460)

-- MAIN APP DEPOTS / PACKAGES
addappid(898461, 1, "09326bcf85250dec828fed5f8bd3f2eb2903aaeb28856b51854a6e66bc5e3232")

