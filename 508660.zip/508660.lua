-- Lua provided by RyzenAPI
-- Game: Triple X Tycoon

-- MAIN APPLICATION
addappid(508660)

-- MAIN APP DEPOTS / PACKAGES
addappid(508661, 1, "29f5a1a0474572f18121aabf9a6d87a2cfca0a139df90aa17a651269bb065178")
