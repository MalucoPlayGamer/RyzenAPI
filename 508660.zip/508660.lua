-- Lua provided by SkyAPI 
-- Game: AppID 508660
addappid(508660)
addappid(508661, 1, "29f5a1a0474572f18121aabf9a6d87a2cfca0a139df90aa17a651269bb065178")
