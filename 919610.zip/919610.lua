-- Lua provided by RyzenAPI
-- Game: The Ball Encounter

-- MAIN APPLICATION
addappid(919610)
-- Game: addappid(919610)

-- MAIN APP DEPOTS / PACKAGES
addappid(919611, 1, "d09d5a8fecbad6f64084750f0584a2379a2b7be0af15f208434d7d0c9f167360")
