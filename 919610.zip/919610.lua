-- Lua provided by RyzenAPI
-- Game: The Ball Encounter

-- MAIN APPLICATION
addappid(919610)

-- MAIN APP DEPOTS / PACKAGES
addappid(919611, 1, "d09d5a8fecbad6f64084750f0584a2379a2b7be0af15f208434d7d0c9f167360")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
