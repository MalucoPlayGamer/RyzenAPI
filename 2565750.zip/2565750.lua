-- Lua provided by RyzenAPI
-- Game: 2565750

-- MAIN APPLICATION
addappid(2565750)
-- Game: addappid(2565750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2565750,0,"96dd45b3502444fca6c30eb7ca256617b390f55c5dd2a33db714ed020da02bc5")
