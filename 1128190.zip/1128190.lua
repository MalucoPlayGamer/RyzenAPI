-- Lua provided by RyzenAPI
-- Game: Achievement Simulator

-- MAIN APPLICATION
addappid(1128190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1128191, 1, "7c7cc79488b52b25c214a77d0034807c48236bd15a2e52e4e5bf349e02730110")
addappid(1144750, 0, "3231ce88fdac5912be802621e25ab8fab1284a3ad782a6dff4a5178fbd564646")
