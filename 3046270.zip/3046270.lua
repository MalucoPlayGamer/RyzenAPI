-- Lua provided by RyzenAPI
-- Game: 3046270

-- MAIN APPLICATION
addappid(3046270)
-- Game: addappid(3046270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3046271, 1, "47df627a767746da36863684df2066740b6cc59361efdd82fab913d7cefbd204")
