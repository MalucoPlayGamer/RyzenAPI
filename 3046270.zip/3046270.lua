-- Lua provided by RyzenAPI 
-- Game: Hentai Tales: Uninhabited Island
addappid(3046270)
addappid(3046271, 1, "47df627a767746da36863684df2066740b6cc59361efdd82fab913d7cefbd204")
