-- Lua provided by RyzenAPI
-- Game: AppID 1112930

-- MAIN APPLICATION
addappid(1112930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1112931, 1, "0a172bceab1dd1555d0d1f556f256cb717884b3ce3ca3b8cf6ca1b74892ef340")
