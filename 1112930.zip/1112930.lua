-- Lua provided by RyzenAPI
-- Game: AppID 1112930

-- MAIN APPLICATION
addappid(1112930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1112931, 1, "0a172bceab1dd1555d0d1f556f256cb717884b3ce3ca3b8cf6ca1b74892ef340")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
