-- Lua provided by RyzenAPI
-- Game: Game: Khuga Bash!

-- MAIN APPLICATION
addappid(2654680)
-- Game: addappid(2654680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2654681, 1, "97a05a36451de1266c2bc1b5330a5d1eb11332c9a5be5f4e4a5aff415774aa3d")
