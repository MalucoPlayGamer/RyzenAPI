-- Lua provided by RyzenAPI
-- Game: Game: Arisen Force: HeroTest

-- MAIN APPLICATION
addappid(2951840)
-- Game: addappid(2951840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2951841, 1, "e69da573049cca34c8bd307f3baa5a5efc214d1e1bf7920405eaadb2a436a345")
