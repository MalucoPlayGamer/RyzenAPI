-- Lua provided by RyzenAPI
-- Game: Sky Mercenaries

-- MAIN APPLICATION
addappid(336090)

-- MAIN APP DEPOTS / PACKAGES
addappid(336091, 1, "e78193fa9f8a8f7a4dcacda23b4b864cf79a3d548160ec3170ae70314ed283fc")
addappid(336093, 1, "5266a44e4c8389a9209e2e7a7babf17477dc2ac08dd518b02a7f8b439d39134b")

