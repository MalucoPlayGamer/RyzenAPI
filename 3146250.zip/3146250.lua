-- Lua provided by RyzenAPI
-- Game: Escape The Maze

-- MAIN APPLICATION
addappid(3146250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3146251, 1, "0538d96812710888a2da579000b3379fb5c05431efe6c833ae0b574955a3ce50")

