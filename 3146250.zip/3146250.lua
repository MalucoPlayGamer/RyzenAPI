-- Lua provided by RyzenAPI
-- Game: Game: Escape The Maze

-- MAIN APPLICATION
addappid(3146250)
-- Game: addappid(3146250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3146251, 1, "0538d96812710888a2da579000b3379fb5c05431efe6c833ae0b574955a3ce50")
