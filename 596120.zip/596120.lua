-- Lua provided by RyzenAPI
-- Game: AppID 596120

-- MAIN APPLICATION
addappid(596120)
-- Game: addappid(596120)

-- MAIN APP DEPOTS / PACKAGES
addappid(596121, 1, "4c5ab3035b5b892657b634a238cb9971cba758dd3830d5ebb2432f9c31123d08")
