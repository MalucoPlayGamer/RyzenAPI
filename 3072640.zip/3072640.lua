-- Lua provided by RyzenAPI
-- Game: Guidus Zero

-- MAIN APPLICATION
addappid(3072640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3072641, 1, "10ac283646a63acf803b8ac078e02749f657036f81f726266a2f5ab1ae933f94")
