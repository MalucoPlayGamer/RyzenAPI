-- Lua provided by RyzenAPI
-- Game: Solitaire Battle Online

-- MAIN APPLICATION
addappid(3885830)

