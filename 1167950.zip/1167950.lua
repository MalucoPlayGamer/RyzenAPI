-- Lua provided by RyzenAPI
-- Game: 1167950

-- MAIN APPLICATION
addappid(1167950)
-- Game: addappid(1167950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1167951, 1, "0eebd2166d87e5bc0616d09e5a811786f4a11cf8e37407a9d59c7ee356ce023a")
