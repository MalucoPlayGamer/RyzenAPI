-- Lua provided by RyzenAPI
-- Game: GIGA WRECKER

-- MAIN APPLICATION
addappid(454410)

-- MAIN APP DEPOTS / PACKAGES
addappid(454411, 1, "3fba4c8b809f391d332148a56f79c2c68b1821e72203a9654972d217f35106d7")
addappid(586900, 0, "333803500dbd2435a5f514818715ee2d7eda8cf824855bf09dbdba29a8b5688a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
