-- Lua provided by RyzenAPI
-- Game: addappid(1228520)

-- MAIN APPLICATION
addappid(1228520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1228521, 1, "ffd0fe65430f74a66f3416ff21bf0da1fb359bff5f5fdf17f617f1badcc532fa")
