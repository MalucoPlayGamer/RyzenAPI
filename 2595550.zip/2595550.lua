-- Lua provided by RyzenAPI
-- Game: AppID 2595550

-- MAIN APPLICATION
addappid(2595550)
-- Game: addappid(2595550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2595551, 1, "fc8a44a93b1cefbaefd76bd6f740a9910a20a52a6afd6bf2278ec83e24fb64c3")
