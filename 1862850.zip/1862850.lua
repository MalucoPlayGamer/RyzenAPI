-- Lua provided by RyzenAPI 
-- Game: AppID 1862850
addappid(1862850)
addappid(1862851, 1, "2eda185557732c8ab72554aedb49377ff6e54d32208ec015bcc421b30cede4c2")
