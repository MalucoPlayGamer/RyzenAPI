-- Lua provided by RyzenAPI
-- Game: addappid(1862850)

-- MAIN APPLICATION
addappid(1862850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1862851, 1, "2eda185557732c8ab72554aedb49377ff6e54d32208ec015bcc421b30cede4c2")
