-- Lua provided by RyzenAPI
-- Game: 1074820

-- MAIN APPLICATION
addappid(1074820)
-- Game: addappid(1074820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1074821, 1, "09f05656713beee526b304f809849d0eaee8a8e4588df697879ec23b442dc5fd")
