-- Lua provided by SkyAPI 
-- Game: Eudemons Online
addappid(1074820)
addappid(1074821, 1, "09f05656713beee526b304f809849d0eaee8a8e4588df697879ec23b442dc5fd")
