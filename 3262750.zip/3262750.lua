-- Lua provided by RyzenAPI
-- Game: Whispers of the Void Demo

-- MAIN APPLICATION
addappid(3262750)

-- MAIN APP DEPOTS / PACKAGES
addappid(3262751, 1, "89d244997b8a96bfe98b6768222bf803a9278102bf9f808c17dc6f17b8a418c2")

