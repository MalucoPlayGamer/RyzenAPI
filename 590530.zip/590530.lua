-- Lua provided by RyzenAPI
-- Game: World Builder

-- MAIN APPLICATION
addappid(590530)

-- MAIN APP DEPOTS / PACKAGES
addappid(590531,0,"d5965d44a2c53e757e89f29bd0391762c411be070c9ff1c89011c5c4749e9090")

