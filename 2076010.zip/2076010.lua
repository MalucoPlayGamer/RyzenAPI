-- Lua provided by RyzenAPI
-- Game: UNDER NIGHT IN-BIRTH II Sys:Celes

-- MAIN APPLICATION
addappid(2076010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076011, 1, "5bbbf95f9bbd30168e03337a4ca557593e1d32f76a9df1f47ac731425d66ceb8")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2353330)
addappid(2441370)
addappid(2677080)
addappid(2677090)
addappid(2677100)
