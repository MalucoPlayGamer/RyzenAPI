-- Lua provided by RyzenAPI
-- Game: Game: UNDER NIGHT IN-BIRTH II Sys:Celes

-- MAIN APPLICATION
addappid(2076010)
-- Game: addappid(2076010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076011, 1, "5bbbf95f9bbd30168e03337a4ca557593e1d32f76a9df1f47ac731425d66ceb8")
