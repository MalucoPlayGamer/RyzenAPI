-- Lua provided by RyzenAPI 
-- Game: Exo Wanderers
addappid(3208780)
addappid(3208781, 1, "4e07883faf8910951a2aae2cd2e2d9e615ea03d3e5270264bbeb40d67b3ec360")
