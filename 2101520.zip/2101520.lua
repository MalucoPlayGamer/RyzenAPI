-- Lua provided by SkyAPI 
-- Game: AppID 2101520
addappid(2101520)
addappid(2101521, 1, "6e9831919badd28c58378ed4ea68e9e6b14a3a85161ad3afcb5d661648c6902f")
