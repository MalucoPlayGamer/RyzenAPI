-- Lua provided by RyzenAPI
-- Game: AppID 552200

-- MAIN APPLICATION
addappid(552200)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(552201, 1, "5b03f978cbb019a7c42bfd5311efdfec36ed7fbdb4683c19a361951fabaf6f0e")

