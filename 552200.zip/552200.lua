-- Lua provided by RyzenAPI
-- Game: AppID 552200

-- MAIN APPLICATION
addappid(552200)
-- Game: addappid(552200)

-- MAIN APP DEPOTS / PACKAGES
addappid(552201, 1, "5b03f978cbb019a7c42bfd5311efdfec36ed7fbdb4683c19a361951fabaf6f0e")
