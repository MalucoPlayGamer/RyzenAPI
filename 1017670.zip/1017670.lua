-- Lua provided by RyzenAPI
-- Game: AppID 1017670

-- MAIN APPLICATION
addappid(1017670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1017671, 1, "2c3ee0aa77fe52114608ea28a099228843846340cdafb7539bc5374dc7ddeb62")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
