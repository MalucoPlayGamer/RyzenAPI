-- Lua provided by RyzenAPI
-- Game: addappid(1017670)

-- MAIN APPLICATION
addappid(1017670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1017671, 1, "2c3ee0aa77fe52114608ea28a099228843846340cdafb7539bc5374dc7ddeb62")
