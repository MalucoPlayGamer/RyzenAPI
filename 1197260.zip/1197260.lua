-- Lua provided by RyzenAPI
-- Game: The Perfect Tower II

-- MAIN APPLICATION
addappid(1197260)
addappid(2347140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1197261, 1, "ce2181b314dc999cf93dd9ca8565fc5488cd604b1f45d0fd6c1401574e0f8802")
