-- Lua provided by RyzenAPI
-- Game: Death of a Wish

-- MAIN APPLICATION
addappid(2302080)
-- Game: addappid(2302080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2302081, 1, "9e2c986f49b4396ab725562443debe7102ecfb9bdb4eccd1355f060bd53a9dbc")
