-- Lua provided by RyzenAPI
-- Game: NationWar2:Chronicle

-- MAIN APPLICATION
addappid(1005460)
-- Game: addappid(1005460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005461, 1, "79e3a2725decbe353a8a20b2b8ab666f44acd2c16b9a83c178a25c0b9f64775c")
