-- Lua provided by RyzenAPI
-- Game: NationWar2:Chronicle

-- MAIN APPLICATION
addappid(1005460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1005461, 1, "79e3a2725decbe353a8a20b2b8ab666f44acd2c16b9a83c178a25c0b9f64775c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
