-- Lua provided by RyzenAPI
-- Game: Slitterhead

-- MAIN APPLICATION
addappid(2631250)
-- Game: addappid(2631250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2631251, 1, "35b65353c889458eccf51a3307b040e48e83aff12bddd5bfeb96a787392be005")
addappid(2631252, 1, "bb6e2fdcea1188e89b4fbbc62a18fad23a4580ab83074a3bee8bb5fee9c8eadf")
