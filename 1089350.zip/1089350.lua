-- Lua provided by RyzenAPI
-- Game: NBA 2K20

-- MAIN APPLICATION
addappid(1089350)
addappid(1128700)
addappid(1128701)
addappid(1128702)
addappid(1128703)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089351,0,"5f64f254a290569bd9659b6ccef6ec373a9d712b205817f57c419b12ffb4355e")

