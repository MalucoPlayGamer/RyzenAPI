-- Lua provided by RyzenAPI
-- Game: Game: AppID 1089350

-- MAIN APPLICATION
addappid(1089350)
-- Game: addappid(1089350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1089351, 1, "5f64f254a290569bd9659b6ccef6ec373a9d712b205817f57c419b12ffb4355e")
