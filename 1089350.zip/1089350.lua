-- Lua provided by RyzenAPI
-- Game: NBA 2K20

-- MAIN APPLICATION
addappid(1089350)
addappid(1128700)
addappid(1128701)
addappid(1128702)
addappid(1128703)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1089351,0,"5f64f254a290569bd9659b6ccef6ec373a9d712b205817f57c419b12ffb4355e")

