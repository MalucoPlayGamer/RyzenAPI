-- Lua provided by RyzenAPI
-- Game: 浮游

-- MAIN APPLICATION
addappid(2476840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2476841, 1, "cfbfdc300be7807aaef451f5f40e71009193d56bba13420e83e3bf3d7f3963bb")

