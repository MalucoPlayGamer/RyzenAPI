-- Lua provided by SkyAPI 
-- Game: 浮游
addappid(2476840)
addappid(2476841, 1, "cfbfdc300be7807aaef451f5f40e71009193d56bba13420e83e3bf3d7f3963bb")
