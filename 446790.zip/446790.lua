-- Lua provided by RyzenAPI
-- Game: Diluvion: Resubmerged

-- MAIN APPLICATION
addappid(446790)
addappid(543827)
addappid(543828)
addappid(543829)
addappid(576511)
addappid(576514)

-- MAIN APP DEPOTS / PACKAGES
addappid(446791, 1, "6db9e1da2268f634c5e244dfc3eb7467727040b94800124119daf575f991a320")
addappid(446792, 1, "99c18caf7a2d6dbce0fab58c730ab1316a6c71665d01f316c18ac1264a175397")
addappid(446793, 1, "df3e9d4ae61d5ccdfc1dbf6ccafe6e3fe6baf5b2bf77b68a7554ba96da0a0706")
addappid(446798, 1, "aa2038ad8e6918d329cac331d687263387967ed6a198f0a6948efc8a6327a260")
addappid(446799, 1, "0fc6b8cfc84a398d9c60c25c979346c5b7d7e5d153186b16170bcd8619fc398d")
addappid(543824, 0, "7a88b66b6b10369aaa940b9a51b044e954ad4cb35d561122bf4354b0d6456088")
addappid(543825, 0, "5bc65c3a8c1fcb0b1357d9cbe46769706d64fb5dc92e3716f858de0edb3bcd10")
addappid(543826, 0, "3fd3c243fb9b519258fe3add79470d8b7414eb19225019a3bb6d0afc94feedb8")
addappid(576512, 0, "6209a4a4c584cf0dcf7d9eecd0acd67cc2e5a731c37b2777c5106d68966bcc4c")
addappid(576513, 0, "84620d174dbb43f7d1edf0c74beda52ae8a28af4f0d2d9ce147e394ea397cc53")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(543820)
addappid(543821)
addappid(543822)
addappid(543823)
addappid(577600)
addappid(577610)
addappid(578020)
addappid(578030)
addappid(578380)
