-- Lua provided by RyzenAPI
-- Game: NeoCandy

-- MAIN APPLICATION
addappid(939260)

-- MAIN APP DEPOTS / PACKAGES
addappid(939261, 1, "bd0c6fd935116a57db4c8b6c33ebb7536efee0e65a2b422c696ca6079e1217d4")
