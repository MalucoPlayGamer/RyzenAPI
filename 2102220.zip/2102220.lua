-- Lua provided by RyzenAPI
-- Game: Memory Puzzle - Futanari Boss

-- MAIN APPLICATION
addappid(2102220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2102221, 1, "4162d96e50a924f230d8101b87377f87149ab425bef7b255720277bfd8b19303")

