-- Lua provided by RyzenAPI
-- Game: Westwood Shadows

-- MAIN APPLICATION
addappid(1122360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122361, 1, "6f32b4dd4a6b84cd6c504d9b75e2877a0d9eea76f46b695c92028b4129708ce4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
