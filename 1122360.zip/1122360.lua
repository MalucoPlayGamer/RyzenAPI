-- Lua provided by RyzenAPI 
-- Game: Westwood Shadows
addappid(1122360)
addappid(1122361, 1, "6f32b4dd4a6b84cd6c504d9b75e2877a0d9eea76f46b695c92028b4129708ce4")
