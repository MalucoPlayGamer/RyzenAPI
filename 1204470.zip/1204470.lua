-- Lua provided by RyzenAPI
-- Game: AppID 1204470

-- MAIN APPLICATION
addappid(1204470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1204471, 1, "11d6e60037693ab649ac991b7075b862e0afc344ccdd475005c49356cc0e9a17")

