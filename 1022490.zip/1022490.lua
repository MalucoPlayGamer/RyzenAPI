-- Lua provided by RyzenAPI
-- Game: addappid(1022490)

-- MAIN APPLICATION
addappid(1022490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022490,0,"24ed949f7a53d59212677346352ae2aa4ffee5ddcae315dd9b93cdb027693155")
