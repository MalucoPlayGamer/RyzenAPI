-- Lua provided by RyzenAPI 
-- Game: TRAMCITY HAKODATE
addappid(2614000)
addappid(2614001, 1, "a86a278b9826eb3ccfe0661e49ae7bd31b2a2cbd1e8d64f18ed80e52b35e1eb8")
