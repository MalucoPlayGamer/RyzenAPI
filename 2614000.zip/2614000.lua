-- Lua provided by RyzenAPI
-- Game: TRAMCITY HAKODATE

-- MAIN APPLICATION
addappid(2614000)
-- Game: addappid(2614000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614001, 1, "a86a278b9826eb3ccfe0661e49ae7bd31b2a2cbd1e8d64f18ed80e52b35e1eb8")
