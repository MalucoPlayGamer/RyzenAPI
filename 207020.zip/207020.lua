-- Lua provided by RyzenAPI
-- Game: Bang Bang Racing

-- MAIN APPLICATION
addappid(207020)

-- MAIN APP DEPOTS / PACKAGES
addappid(207021, 1, "b7a5d6c65af7f668192b8dd4783741422f6db2b988ac7117fcfe2121bb8a2268")
