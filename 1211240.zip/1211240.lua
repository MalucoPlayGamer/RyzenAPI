-- Lua provided by SkyAPI 
-- Game: AppID 1211240
addappid(1211240)
addappid(1211241, 1, "b50e1093baac4c53b35347af868010aee3bd106ce82c7489e76b21c1f545b061")
