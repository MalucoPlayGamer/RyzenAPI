-- Lua provided by RyzenAPI
-- Game: addappid(497820)

-- MAIN APPLICATION
addappid(497820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(497823,0,"1f8ba0b7eb2f00d98669ad7bcaf950dbb0296c522d266546ba64090da8fa8415")
