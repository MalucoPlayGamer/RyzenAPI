-- Lua provided by RyzenAPI 
-- Game: Daily Note
addappid(3720990)
addappid(3720991, 1, "6876959d0c13a5b11a12b8f4ed8ad975f670d52fd1bf87a5c963769c05a35699")
