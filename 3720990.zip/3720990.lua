-- Lua provided by RyzenAPI
-- Game: Daily Note

-- MAIN APPLICATION
addappid(3720990)

-- MAIN APP DEPOTS / PACKAGES
addappid(3720991, 1, "6876959d0c13a5b11a12b8f4ed8ad975f670d52fd1bf87a5c963769c05a35699")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
