-- Lua provided by RyzenAPI
-- Game: Night Shippers

-- MAIN APPLICATION
addappid(3761880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3761881,0,"d0a0aed4434cfce64086c34a0e44ea7cb2b630a017bf37c019396774c67e5742")

