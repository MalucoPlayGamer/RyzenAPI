-- Lua provided by RyzenAPI
-- Game: Night Shippers

-- MAIN APPLICATION
addappid(3761880)

-- MAIN APP DEPOTS / PACKAGES
addappid(3761881,0,"d0a0aed4434cfce64086c34a0e44ea7cb2b630a017bf37c019396774c67e5742")

