-- Lua provided by SkyAPI 
-- Game: The Girl Who Sees
addappid(1551480)
addappid(1551481, 1, "4d56d6566e8bd48937fa50f08a6fa54efbe09bd901ddacfd7e7c6d732dc62f66")
