-- Lua provided by RyzenAPI
-- Game: The Girl Who Sees

-- MAIN APPLICATION
addappid(1551480)
-- Game: addappid(1551480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1551481, 1, "4d56d6566e8bd48937fa50f08a6fa54efbe09bd901ddacfd7e7c6d732dc62f66")
