-- Lua provided by RyzenAPI
-- Game: 1140630

-- MAIN APPLICATION
addappid(1140630)
addappid(1432940)
-- Game: addappid(1140630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140631, 1, "295f89c47888af2b8c68d4ef6fc1ff6c3794d4ddaa5012932e3cb2a5b77d71b3")
