-- Lua provided by RyzenAPI
-- Game: Hidden World 6 Top-Down 3D

-- MAIN APPLICATION
addappid(2663780)
-- Game: addappid(2663780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2663781, 1, "f38c944966f21110fe85b5c11c3e2e6929304f65b3ed6991a7767c49e014c450")
