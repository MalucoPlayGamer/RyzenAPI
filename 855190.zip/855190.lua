-- Lua provided by RyzenAPI
-- Game: The Subject

-- MAIN APPLICATION
addappid(855190)

-- MAIN APP DEPOTS / PACKAGES
addappid(855191,0,"8a3c05bc1fb280a9377b75f8ade74b8ead5820f8fa8b6e8ee6bcc21cf83202e9")

