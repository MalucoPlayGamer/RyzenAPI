-- Lua provided by RyzenAPI
-- Game: 225300

-- MAIN APPLICATION
addappid(225300)
-- Game: addappid(225300)

-- MAIN APP DEPOTS / PACKAGES
addappid(225301, 1, "11e5778224416d09359430d3cb0fbf1ae4b012ec5ddf2a91843f1b3e05f9187f")
