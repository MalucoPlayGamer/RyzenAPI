-- Lua provided by RyzenAPI 
-- Game: Disharmonia
addappid(1949840)
addappid(1949841, 1, "ee36ccb09d86c15400d143cebf8c7ae56458b101f3d2bfc6092d905a64ed43d8")
