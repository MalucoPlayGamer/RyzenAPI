-- Lua provided by RyzenAPI 
-- Game: AppID 493650
addappid(493650)
addappid(493651, 1, "d3dca8c3301c61242739c4515844f068b6bbd9340e231eda0ab4fa11fe094a05")
addappid(493652, 1, "b8cdf5cc7e859f737c46bb1ae154be599ca4f7fb5bfb330b5471d9ad9987860d")
