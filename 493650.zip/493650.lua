-- Lua provided by RyzenAPI
-- Game: AppID 493650

-- MAIN APPLICATION
addappid(493650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(493651, 1, "d3dca8c3301c61242739c4515844f068b6bbd9340e231eda0ab4fa11fe094a05")
addappid(493652, 1, "b8cdf5cc7e859f737c46bb1ae154be599ca4f7fb5bfb330b5471d9ad9987860d")

