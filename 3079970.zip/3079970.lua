-- Lua provided by RyzenAPI
-- Game: Airport X-Ray Simulator

-- MAIN APPLICATION
addappid(3079970)

-- MAIN APP DEPOTS / PACKAGES
addappid(3079972,0,"6f8241800e907d0ce1e40888f65e5f11c779bfe313ba840d3334e581fe8ce753")
