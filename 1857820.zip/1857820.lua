-- Lua provided by RyzenAPI
-- Game: addappid(1857820)

-- MAIN APPLICATION
addappid(1857820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857821, 1, "d93bdd1b4c5c49734efdd18e60df43d94cab91cd4914398dcd11d86e591367c7")
