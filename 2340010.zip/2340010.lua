-- Lua provided by RyzenAPI
-- Game: Game: Ritual

-- MAIN APPLICATION
addappid(2340010)
-- Game: addappid(2340010)

-- MAIN APP DEPOTS / PACKAGES
addappid(2340011, 1, "c0f20469926c4945996265830b4ebf948919f292feccf8c660d4804c6e1456c7")
