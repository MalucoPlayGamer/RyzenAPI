-- Lua provided by SkyAPI 
-- Game: Ritual
addappid(2340010)
addappid(2340011, 1, "c0f20469926c4945996265830b4ebf948919f292feccf8c660d4804c6e1456c7")
