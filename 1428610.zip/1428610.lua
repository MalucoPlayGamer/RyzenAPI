-- Lua provided by RyzenAPI
-- Game: Animal Rescuer: Prologue

-- MAIN APPLICATION
addappid(1428610)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1428611, 1, "04fcf0f00568df31c34dc016f7a81dfbb609be5578ef3a78c40fff42a4d08bcf")

