-- Lua provided by RyzenAPI
-- Game: Animal Rescuer: Prologue

-- MAIN APPLICATION
addappid(1428610)
-- Game: addappid(1428610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1428611, 1, "04fcf0f00568df31c34dc016f7a81dfbb609be5578ef3a78c40fff42a4d08bcf")
