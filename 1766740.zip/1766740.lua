-- Lua provided by SkyAPI 
-- Game: Choo-Choo Charles
addappid(1766740)
addappid(1766741, 1, "007339d9d1d35d217e016e1bf1999a9212ac3d4478df466412866aa56bf3e47c")
