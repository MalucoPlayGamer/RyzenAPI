-- Lua provided by RyzenAPI
-- Game: Choo-Choo Charles

-- MAIN APPLICATION
addappid(1766740)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1766741, 1, "007339d9d1d35d217e016e1bf1999a9212ac3d4478df466412866aa56bf3e47c")

