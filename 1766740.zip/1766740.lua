-- Lua provided by RyzenAPI
-- Game: Choo-Choo Charles

-- MAIN APPLICATION
addappid(1766740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1766741, 1, "007339d9d1d35d217e016e1bf1999a9212ac3d4478df466412866aa56bf3e47c")

