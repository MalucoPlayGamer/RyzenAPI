-- Lua provided by RyzenAPI
-- Game: Coffee Bar Renovator Demo

-- MAIN APPLICATION
addappid(2288650)
-- Game: addappid(2288650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2288651, 1, "7aa21608e91b7a569a74f1b5642d7b5033b81771277334245d3838edb259884d")
