-- Lua provided by RyzenAPI
-- Game: 2562900

-- MAIN APPLICATION
addappid(2562900)
-- Game: addappid(2562900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2562901, 1, "0eaf1e6ab19333dfbe48c8c9a11962ba9d68810a5fb1cbe76f583a9cfb1a34cb")
