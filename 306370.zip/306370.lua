-- Lua provided by RyzenAPI
-- Game: World of Subways 1 – The Path

-- MAIN APPLICATION
addappid(306370)

-- MAIN APP DEPOTS / PACKAGES
addappid(306371, 1, "b8b5f38bf0d43283b5fdda2fcdaa4ceb8cf963a2a7811d27357d8d1e43b6b720")
addappid(306372, 1, "01e33537f30574ec26a563a4d6240d184f2467bdde27eec2a85760e1c2126184")
addappid(306373, 1, "84b5be6c37836592cedfd9852477f17be1918f45804e5fc2486086b8003886e7")
addappid(306374, 1, "b7b647f94c634ab404628e999981961452995acc7691d52639605486e5d7a4e4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
