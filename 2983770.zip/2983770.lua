-- Lua provided by RyzenAPI
-- Game: 2983770

-- MAIN APPLICATION
addappid(2983770)
-- Game: addappid(2983770)

-- MAIN APP DEPOTS / PACKAGES
addappid(2983771, 1, "7c2c6f16fd563b8e73e32ecefb1a7104599d7ce53337949a405afb52a83f4913")
