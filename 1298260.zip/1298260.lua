-- Lua provided by RyzenAPI
-- Game: Stay home and play with waifu!

-- MAIN APPLICATION
addappid(1298260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1298261, 1, "da38708b8f11e98942be30f5072fe556dad4b7ab45a335afc053f5950ac86250")
