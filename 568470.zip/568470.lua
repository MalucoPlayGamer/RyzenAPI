-- Lua provided by RyzenAPI
-- Game: Waking the Glares - Chapters I and II

-- MAIN APPLICATION
addappid(568470)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(568471, 1, "0a4fc79fcd882a981263eba963fb25276fb0d5f05b1b351560c783f29b530d74")
addappid(608650, 0, "5e5aa1893e77115401f76fc15993071c367f743bcd601617730ecfc044368b22")

