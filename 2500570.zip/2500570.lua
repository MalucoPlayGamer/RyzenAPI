-- Lua provided by SkyAPI 
-- Game: Little Droid
addappid(2500570)
addappid(2500571, 1, "67e194ec93d367fd593a021cbb6bd93c069592d147c0ca407779cd28fa6be603")
