-- Lua provided by RyzenAPI
-- Game: addappid(471400)

-- MAIN APPLICATION
addappid(471400)

-- MAIN APP DEPOTS / PACKAGES
addappid(471401, 1, "15b0f5512e6c6496f9d2c44a2d7cd73f8de9a7ad7d320693fd394f7229ea5e75")
