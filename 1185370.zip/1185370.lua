-- Lua provided by SkyAPI 
-- Game: Parked In The Dark
addappid(1185370)
addappid(1185371, 1, "a9821052ce1496dc78bf469b2911b42b042a4f7c65ff372c7c447ad17f36ad79")
