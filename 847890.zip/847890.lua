-- Lua provided by RyzenAPI
-- Game: 小黄条/YYNote

-- MAIN APPLICATION
addappid(847890)

-- MAIN APP DEPOTS / PACKAGES
addappid(847891, 1, "4c9000d233141cc1963a92a087fd5b3872837264e863dfe53eaccda8cd89e7b4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
