-- Lua provided by RyzenAPI
-- Game: 847890

-- MAIN APPLICATION
addappid(847890)
-- Game: addappid(847890)

-- MAIN APP DEPOTS / PACKAGES
addappid(847891, 1, "4c9000d233141cc1963a92a087fd5b3872837264e863dfe53eaccda8cd89e7b4")
