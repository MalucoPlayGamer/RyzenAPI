-- Lua provided by RyzenAPI
-- Game: AppGameKit Classic - Giant Asset Pack 1

-- MAIN APPLICATION
addappid(410530)

-- MAIN APP DEPOTS / PACKAGES
addappid(410530,0,"0c78b21a169eb8175803a1a4e62250911383d8285313faca53067a88bf192561")
