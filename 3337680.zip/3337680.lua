-- Lua provided by RyzenAPI
-- Game: addappid(3337680)

-- MAIN APPLICATION
addappid(3337680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3337681, 1, "ece5e535530682dd4baedd04b8b9f36246397966ee35c319d9755b9370b5a15d")
