-- Lua provided by RyzenAPI
-- Game: Brainrot Animals Fighting

-- MAIN APPLICATION
addappid(3337680)

-- MAIN APP DEPOTS / PACKAGES
addappid(3337681, 1, "ece5e535530682dd4baedd04b8b9f36246397966ee35c319d9755b9370b5a15d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
