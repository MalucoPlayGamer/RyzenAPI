-- Lua provided by RyzenAPI
-- Game: Slingbot Survivors

-- MAIN APPLICATION
addappid(3432800)

-- MAIN APP DEPOTS / PACKAGES
addappid(3432801, 1, "ab9839c4d84bad7afc18d3bb7b1945af2d5e058ac3d2f5751e2eb1f4d9eab70e")
