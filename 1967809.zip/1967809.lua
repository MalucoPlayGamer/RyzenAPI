-- Lua provided by RyzenAPI
-- Game: Beat Saber - Pendulum - Witchcraft

-- MAIN APPLICATION
addappid(1967809)

-- MAIN APP DEPOTS / PACKAGES
addappid(1967809,0,"977ced412af7ce118c118966e7e3f252b198056360c87e93117c288e01927a8e")

