-- Lua provided by RyzenAPI
-- Game: Dead TrailZ

-- MAIN APPLICATION
addappid(349150)

-- MAIN APP DEPOTS / PACKAGES
addappid(349152,0,"74fce5b2c5f6ee688343380fd95e51422f004a61dc215c49ef6d9eb1fcee8f43")

