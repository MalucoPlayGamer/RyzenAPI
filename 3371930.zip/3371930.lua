-- Lua provided by RyzenAPI 
-- Game: Only False
addappid(3371930)
addappid(3371931, 1, "81542dc8cc556e3df251f3311d3c72742692fcc39af048153f565a4ca16d696c")
