-- Lua provided by RyzenAPI
-- Game: addappid(3371930)

-- MAIN APPLICATION
addappid(3371930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3371931, 1, "81542dc8cc556e3df251f3311d3c72742692fcc39af048153f565a4ca16d696c")
