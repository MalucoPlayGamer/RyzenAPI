-- Lua provided by SkyAPI 
-- Game: AppID 1201370
addappid(1201370)
addappid(1201371, 1, "488f7b8f54d474e46613860235714c8f82f0e7983d7f4f0ddf1aa5be66273a39")
