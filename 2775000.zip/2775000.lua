-- Lua provided by RyzenAPI
-- Game: addappid(2775000)

-- MAIN APPLICATION
addappid(2775000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2775001, 1, "42e539ee6627bab6cd9cc27a95e6bf01348ca026849ef869e46743447e964c06")
