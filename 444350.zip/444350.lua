-- Lua provided by SkyAPI 
-- Game: HACK_IT
addappid(444350)
addappid(444351, 1, "54aae7660d7fdbf5a2bacd294cac36268145d2012113931bbff34f193f5b4d7e")
addappid(444352, 1, "ab1ecf6b9f74388e010e06c6c7e3d1c901ad3a94019da83b7451626a7456f5bd")
addappid(444353, 1, "51a8ee907297e8bb51be9a968f6ef3366aaba505612a47c93fda4ec44aac6bdf")
