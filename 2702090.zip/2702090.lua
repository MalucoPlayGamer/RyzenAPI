-- Lua provided by RyzenAPI
-- Game: addappid(2702090)

-- MAIN APPLICATION
addappid(2702090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2702091, 1, "b14dcd2567d587b8559f99af43f59e78d693b7ab872b5a2ae7db593ba4a99dd4")
