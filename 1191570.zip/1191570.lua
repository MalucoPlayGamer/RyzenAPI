-- Lua provided by RyzenAPI
-- Game: Game: Hero Soul: I want to be a Hero!

-- MAIN APPLICATION
addappid(1191570)
-- Game: addappid(1191570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1191571, 1, "2587c0f1d206db868a97b6d576e2ce7666a4995e64edb5b8b57cd3a9a579dd63")
