-- Lua provided by RyzenAPI
-- Game: addappid(3168260)

-- MAIN APPLICATION
addappid(3168260)

-- MAIN APP DEPOTS / PACKAGES
addappid(3168261, 1, "749bf7e07a235e19744c49d9e52c28077f3b903fa05cd3ca4f42f5dd1f949448")
