-- Lua provided by RyzenAPI
-- Game: AppID 351990

-- MAIN APPLICATION
addappid(351990)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(351991, 1, "ab062e022818af4c4efafece5e255ad6ec3e4483067a3ec7c4a5d8a60fbf63d1")

