-- Lua provided by RyzenAPI
-- Game: addappid(351990)

-- MAIN APPLICATION
addappid(351990)

-- MAIN APP DEPOTS / PACKAGES
addappid(351991, 1, "ab062e022818af4c4efafece5e255ad6ec3e4483067a3ec7c4a5d8a60fbf63d1")
