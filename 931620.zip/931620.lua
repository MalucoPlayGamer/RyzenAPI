-- Lua provided by RyzenAPI
-- Game: 931620

-- MAIN APPLICATION
addappid(931620)
-- Game: addappid(931620)

-- MAIN APP DEPOTS / PACKAGES
addappid(931621, 1, "17a6e4214e210b76dcc673483470fdcb9958abc69a26108733b2f75cd058e4c9")
