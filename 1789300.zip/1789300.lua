-- Lua provided by RyzenAPI
-- Game: White Flower

-- MAIN APPLICATION
addappid(1789300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1789301, 1, "b86131d19d5e036725155829875fe0f6467092ff18a1dacce74dc0a70131fa79")

