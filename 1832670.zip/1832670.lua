-- Lua provided by SkyAPI 
-- Game: AppID 1832670
addappid(1832670)
addappid(1832671, 1, "df063c50bbe20229136d7cacb6c3c2ddc2716b2d83f23a9163cb7fbab59da11b")
