-- Lua provided by RyzenAPI
-- Game: addappid(1832670)

-- MAIN APPLICATION
addappid(1832670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1832671, 1, "df063c50bbe20229136d7cacb6c3c2ddc2716b2d83f23a9163cb7fbab59da11b")
