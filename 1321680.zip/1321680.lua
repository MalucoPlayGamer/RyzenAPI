-- Lua provided by RyzenAPI
-- Game: Game: Hello Neighbor 2

-- MAIN APPLICATION
addappid(1321680)
addappid(2215320)
addappid(2215321)
addappid(2215322)
-- Game: addappid(1321680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1321681, 1, "3b7358ea38b82be2ea05fbd1d4b8271a15bfa62beea41f7682d0383073dcc0be")
