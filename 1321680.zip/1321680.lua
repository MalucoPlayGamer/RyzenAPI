-- Lua provided by RyzenAPI
-- Game: Hello Neighbor 2

-- MAIN APPLICATION
addappid(1321680)
addappid(2215320)
addappid(2215321)
addappid(2215322)

-- MAIN APP DEPOTS / PACKAGES
addappid(1321681, 1, "3b7358ea38b82be2ea05fbd1d4b8271a15bfa62beea41f7682d0383073dcc0be")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
