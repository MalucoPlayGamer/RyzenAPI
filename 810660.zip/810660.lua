-- Lua provided by RyzenAPI
-- Game: The Office Quest

-- MAIN APPLICATION
addappid(810660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(810661, 1, "b3993bb0b1c02b024ed6fa7f2bee4a31cbbe796d70356ba60a793c37cf84ea49")

