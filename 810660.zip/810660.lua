-- Lua provided by RyzenAPI
-- Game: AppID 810660

-- MAIN APPLICATION
addappid(810660)
-- Game: addappid(810660)

-- MAIN APP DEPOTS / PACKAGES
addappid(810661, 1, "b3993bb0b1c02b024ed6fa7f2bee4a31cbbe796d70356ba60a793c37cf84ea49")
