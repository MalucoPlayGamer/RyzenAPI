-- Lua provided by SkyAPI 
-- Game: AppID 810660
addappid(810660)
addappid(810661, 1, "b3993bb0b1c02b024ed6fa7f2bee4a31cbbe796d70356ba60a793c37cf84ea49")
