-- Lua provided by RyzenAPI
-- Game: Despotism 3k

-- MAIN APPLICATION
addappid(699920)
-- Game: addappid(699920)

-- MAIN APP DEPOTS / PACKAGES
addappid(699921, 1, "1df38ec11484821ed1847b16ff70f4d92ee4012ab3f6e5676ab5c7a8e6e4cc83")
addappid(699922, 1, "0b4ce69b9d37f295a9973a4b0b71a057faea7762b027473888151b08629745be")
addappid(699923, 1, "0f4c77be79b4b2f6319681d5b8f7119fa6139d2bf6d64ea5e8bcf91d58ccd576")
addappid(699924, 1, "8b55cf95e76b9ed4703110cbf6fb1d118719c8d4b1ad738ea43578f3a348c84a")
