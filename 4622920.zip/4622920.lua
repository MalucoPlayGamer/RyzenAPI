-- 4622920's Lua and Manifest Created by Hubcap Manifest
-- Cozy Coasters
-- Created: August 24, 2026 at 23:20:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4622920) -- Cozy Coasters
-- MAIN APP DEPOTS
addappid(4622921, 1, "c53242100d6cc8518f7858b630f90992f2d9dc497ad31ca0380ee797f74cd68e") -- Depot 4622921
setManifestid(4622921, "9005898292138468692", 2492366243)
addappid(4622922, 1, "d63cfe00ef5dbdf9898bd1ff344bf5a4879274f1549d5e7cea8e5ceb3ab2434b") -- Depot 4622922
setManifestid(4622922, "3470202485074252560", 2567841877)