-- Lua provided by RyzenAPI
-- Game: Cozy Coasters

-- MAIN APPLICATION
addappid(4622920) -- Cozy Coasters

-- MAIN APP DEPOTS / PACKAGES
addappid(4622921, 1, "c53242100d6cc8518f7858b630f90992f2d9dc497ad31ca0380ee797f74cd68e") -- Depot 4622921
addappid(4622922, 1, "d63cfe00ef5dbdf9898bd1ff344bf5a4879274f1549d5e7cea8e5ceb3ab2434b") -- Depot 4622922

