-- Lua provided by RyzenAPI
-- Game: 10 Dead Doves

-- MAIN APPLICATION
addappid(1564540)
addappid(2870880)
addappid(2870890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1564541, 1, "8c256fb91c75c48a13f0aa7540cd53857b405613d85be19b285a8ad9f6520c2a")

