-- Lua provided by RyzenAPI
-- Game: 1564540

-- MAIN APPLICATION
addappid(1564540)
-- Game: addappid(1564540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1564541, 1, "8c256fb91c75c48a13f0aa7540cd53857b405613d85be19b285a8ad9f6520c2a")
