-- Lua provided by RyzenAPI
-- Game: SILENT HILL f

-- MAIN APPLICATION
addappid(2947440)
addappid(3282160)
addappid(3282170)
addappid(3282180)
addappid(3282190)
addappid(3282720)
addappid(3516200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2947441, 1, "5329bd39507637997739c33a4b5737f9539ee434a7b79bd875b5fc7d1337c684")
addappid(3282721, 1, "fd38a70c015f046a880fc4db0487fcccdf05e009b286cc4175abdddf61511342")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4733020)
