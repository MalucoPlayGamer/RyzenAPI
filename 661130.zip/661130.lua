-- Lua provided by RyzenAPI
-- Game: ChilloutVR

-- MAIN APPLICATION
addappid(661130)
addappid(1435530)

-- MAIN APP DEPOTS / PACKAGES
addappid(661131, 1, "ea46b9e028ad438edc5b588e8f694d6d58cdffa9a2ea1830b2de4f9273378ec6")
addappid(661132, 1, "0ba0e79f61518d2212626b907921ee4ac01998b28cbd259819befd48e435874b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1136890)
