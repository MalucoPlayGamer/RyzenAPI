-- Lua provided by RyzenAPI
-- Game: ChilloutVR

-- MAIN APPLICATION
addappid(661130)
addappid(1435530)
-- Game: addappid(661130)

-- MAIN APP DEPOTS / PACKAGES
addappid(661131, 1, "ea46b9e028ad438edc5b588e8f694d6d58cdffa9a2ea1830b2de4f9273378ec6")
addappid(661132, 1, "0ba0e79f61518d2212626b907921ee4ac01998b28cbd259819befd48e435874b")
