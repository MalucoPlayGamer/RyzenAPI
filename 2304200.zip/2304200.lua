-- Lua provided by RyzenAPI
-- Game: 2304200

-- MAIN APPLICATION
addappid(2304200)
-- Game: addappid(2304200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2304205,0,"afcf8db1b8f4a571e89166c0bfdb41dbf38055c8324f43b7661038918b6fd289")
