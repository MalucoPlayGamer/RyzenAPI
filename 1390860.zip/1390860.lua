-- Lua provided by RyzenAPI
-- Game: 1390860

-- MAIN APPLICATION
addappid(1390860)
addappid(1864760)
-- Game: addappid(1390860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390861, 1, "f76fa2df10d70517c030f6eaee7849a55aa4b3df20b933ba44f180829bf8c585")
