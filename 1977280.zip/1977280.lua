-- Lua provided by RyzenAPI
-- Game: addappid(1977280)

-- MAIN APPLICATION
addappid(1977280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1977281, 1, "037f26a0b58fd933f56b55364c0effea90c49bc3c2f7c6f7b88a9a7c131c694a")
