-- Lua provided by RyzenAPI
-- Game: Game: Restaurant Manager

-- MAIN APPLICATION
addappid(724090)
-- Game: addappid(724090)

-- MAIN APP DEPOTS / PACKAGES
addappid(724091, 1, "c4b332f77440bc04e043d3c3039612a828fd92efe65f54a724db30a6e8121d50")
