-- Lua provided by RyzenAPI
-- Game: addappid(1330960)

-- MAIN APPLICATION
addappid(1330960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1330961, 1, "5e7365517aaaeb33d2aff686567fb80da2cfeb555e303be5540e01ea8009678d")
