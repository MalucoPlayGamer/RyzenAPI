-- Lua provided by RyzenAPI
-- Game: Rock, the Tree Hugger

-- MAIN APPLICATION
addappid(391410)

-- MAIN APP DEPOTS / PACKAGES
addappid(391411, 1, "7ecba1c3d69f34f85ada46a35bd6fa7a5ffaa13e355f9dea86b4216a8cbd0615")

