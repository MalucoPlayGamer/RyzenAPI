-- Lua provided by RyzenAPI
-- Game: Hentai Survivors

-- MAIN APPLICATION
addappid(2138510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138511, 1, "2a271b31d23ea96e3fb1b00964e9f14fae3f263f35265f706346c0f0bdc91212")

