-- Lua provided by RyzenAPI
-- Game: AppID 2871050

-- MAIN APPLICATION
addappid(2871050)
-- Game: addappid(2871050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2871051, 1, "c4a7a403e0afcd1292ba2ca75d61aa0a919ccf1ae2d857551b4db417a6486311")
