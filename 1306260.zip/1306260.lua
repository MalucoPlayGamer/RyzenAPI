-- Lua provided by RyzenAPI
-- Game: ClickCells: CPU girls

-- MAIN APPLICATION
addappid(1306260)
-- Game: addappid(1306260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1306261, 1, "24b444d72d38693f722b3652ef9e11d31a2d5017553f97edf6741b41e6ef8bee")
