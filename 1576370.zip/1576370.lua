-- Lua provided by RyzenAPI
-- Game: REPLIKATOR

-- MAIN APPLICATION
addappid(1576370)
-- Game: addappid(1576370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1576371, 1, "f47f1171a6dd28ddb9582b683b554285d7c386f9c594eb921ab2a53ba90d6f03")
