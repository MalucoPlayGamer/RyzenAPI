-- Lua provided by RyzenAPI
-- Game: OPPAI Succubus Academy Sucky and Busty, Demonic and Lusty!

-- MAIN APPLICATION
addappid(2854170)
addappid(2998620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2854171, 1, "6b7d17a5dce248ea62e596854cc58b84d88914c3a82c711f8236161ffaae0d4b")
addappid(2854172, 1, "4da70b5bbc7d3eb5633f9168b9a90f203dbf04ed23703ccfe0eaa6777aaa86a6")
addappid(2854173, 1, "7b7aa932798149b7bb19fcc23494eaf9e3e48194eb34fbe53b48fb653a75ed2b")

