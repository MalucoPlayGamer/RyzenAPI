-- Lua provided by RyzenAPI
-- Game: Game: Ghost legend

-- MAIN APPLICATION
addappid(2783980)
-- Game: addappid(2783980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2783981, 1, "9e8d81712efdd2a72bc38e01b70b0b451bfe7eb37dd627ec6dd8e286912bf3c5")
