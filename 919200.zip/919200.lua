-- Lua provided by RyzenAPI
-- Game: Game: Special Warfare - 特战之王

-- MAIN APPLICATION
addappid(919200)
-- Game: addappid(919200)

-- MAIN APP DEPOTS / PACKAGES
addappid(919201, 1, "990744b3271bd05a40b057b62e50aeb16f33b0bbeb6416baa177ac67d6b4a31d")
addappid(919203, 1, "df93012cc5e2659f9ac57a2290c34410d4f9d221ce82b58dd938bff3d6121129")
