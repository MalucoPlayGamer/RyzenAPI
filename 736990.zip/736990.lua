-- Lua provided by RyzenAPI
-- Game: 736990

-- MAIN APPLICATION
addappid(736990)
-- Game: addappid(736990)

-- MAIN APP DEPOTS / PACKAGES
addappid(736991, 1, "55e45fd8c813e58de57e8c3dbfeea3b2cb2572f0c333cdced742fc849a099c6a")
addappid(736992, 1, "fb5c097417652d54ab245aa48f1f4d4be1e772607ff4489ab6299ade2c73edfb")
addappid(736993, 1, "a9ceedf7e533382a4dc6a35ba95edcce02726d3b94f8eece044da399d0532456")
addappid(736994, 1, "90d52ce92cc4864c99346f3e0590373c30c0dd5ac9a69718ad6b1e87f361cf8e")
