-- Lua provided by RyzenAPI
-- Game: AppID 1279910

-- MAIN APPLICATION
addappid(1279910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279911, 1, "16d2dbdf3cf4946c3e180bbaadd1b3490b2ec90e3ace4d4f3e37a3097a8e6d16")
