-- Lua provided by RyzenAPI
-- Game: AppID 1279910

-- MAIN APPLICATION
addappid(1279910)
addappid(1793590)
addappid(1911280)
addappid(1911281)
addappid(1911282)
addappid(1911283)
addappid(1911284)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1279911, 1, "16d2dbdf3cf4946c3e180bbaadd1b3490b2ec90e3ace4d4f3e37a3097a8e6d16")

