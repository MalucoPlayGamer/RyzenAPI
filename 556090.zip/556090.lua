-- Lua provided by RyzenAPI
-- Game: FIGHTING SPACE

-- MAIN APPLICATION
addappid(556090)
-- Game: addappid(556090)

-- MAIN APP DEPOTS / PACKAGES
addappid(556091, 1, "c1b3dce4d0ba176088acb5728f6537b5ebe70256adcdab2e2cc3c3d0f93042a3")
