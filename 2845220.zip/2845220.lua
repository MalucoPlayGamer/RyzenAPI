-- Lua provided by RyzenAPI
-- Game: 2845220

-- MAIN APPLICATION
addappid(2845220)
-- Game: addappid(2845220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2845221, 1, "5f2037b1d1f3438b9b3475e6d494b0cbd72f5584d261852fb1ba39f9dbe58afd")
