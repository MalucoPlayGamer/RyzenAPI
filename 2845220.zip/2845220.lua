-- Lua provided by SkyAPI 
-- Game: Altushka +
addappid(2845220)
addappid(2845221, 1, "5f2037b1d1f3438b9b3475e6d494b0cbd72f5584d261852fb1ba39f9dbe58afd")
