-- Lua provided by RyzenAPI
-- Game: Altushka +

-- MAIN APPLICATION
addappid(2845220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2845221, 1, "5f2037b1d1f3438b9b3475e6d494b0cbd72f5584d261852fb1ba39f9dbe58afd")

