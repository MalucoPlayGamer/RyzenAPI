-- Lua provided by RyzenAPI 
-- Game: Wally and the FANTASTIC PREDATORS
addappid(1077450)
addappid(1077451, 1, "8d68f5b55af2aa7a48aec8927455fa2cd5c50a7f627b47bd0f1cb239b3a9e738")
