-- Lua provided by RyzenAPI
-- Game: 2762750

-- MAIN APPLICATION
addappid(2762750)
-- Game: addappid(2762750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2762751, 1, "c7f04a9c4f102467da9f4885a1ee83ef12a5162d09dfef39758e3f38e83bab7f")
