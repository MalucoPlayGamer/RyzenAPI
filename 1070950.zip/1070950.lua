-- Lua provided by RyzenAPI
-- Game: Game: AppID 1070950

-- MAIN APPLICATION
addappid(1070950)
-- Game: addappid(1070950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1070951, 1, "9629df11039389ec999ec9d8392598065ed0c285eb46ddf016ad6da7b1290793")
