-- Lua provided by RyzenAPI
-- Game: Cemetery of Bob Demo

-- MAIN APPLICATION
addappid(2851600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2851601, 1, "e8540b9bfdfdbf8adfabc9b08a178ce4156ffab96b3536e7dcb054dfb5a9e276")

