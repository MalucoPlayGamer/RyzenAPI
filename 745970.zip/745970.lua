-- 745970's Lua and Manifest Created by Hubcap Manifest
-- Terminal Conflict
-- Created: April 12, 2026 at 13:34:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(745970, 1, "ea0452d7753e2c99012890829417b067c6ec226114f399f69b37d65868f36183") -- Terminal Conflict
-- MAIN APP DEPOTS
addappid(745971, 1, "d941289dd6b81c0d86f36d31f108d42419f7aa55804c2f85da68478086085ffa") -- Terminal Conflict Windows
setManifestid(745971, "7849595853305734193", 978832042)
addappid(745972, 1, "8007ef530625bc6ce35f05fd9e1ab0b8ff9ef4c7f18b50b8ef8be8fe63451ba7") -- Terminal Conflict Mac
setManifestid(745972, "7804289938774121014", 1012532082)
addappid(745973, 1, "0bab137ea17656054f59ace7a41834db6d447ed62e5e9807f1ab1823cfe93a8c") -- Terminal Conflict Linux
setManifestid(745973, "3637743349653843332", 1030807400)
-- DLCS WITH DEDICATED DEPOTS
-- Terminal Conflict Supreme Commander Edition (AppID: 976370)
addappid(976370)
addappid(976370, 1, "1e5f093ff22f09cd6b0ddebbbf1246e0cca5418bc9cb61c3161816e174cf6400") -- Terminal Conflict Supreme Commander Edition - Terminal Conflict: Supreme Commander Edition (976370) Depot
setManifestid(976370, "5121891703545204002", 32)
-- Terminal Conflict Flower Power Edition (AppID: 976371)
addappid(976371)
addappid(976371, 1, "6a998faab9486c63b225d1dc4e26c3cb80caa905e4b27e38e65d9aa435c23b37") -- Terminal Conflict Flower Power Edition - Terminal Conflict: Flower Power Edition (976371) Depot
setManifestid(976371, "7120937921722834134", 32)
-- Terminal Conflict Eyes Only Edition (AppID: 1188360)
addappid(1188360)
addappid(1188360, 1, "09d0249e358a176c0a4afdaa8286961e15d995ab87eea839c3a303b28520c5af") -- Terminal Conflict Eyes Only Edition - Terminal Conflict: Eyes Only Edition (1188360) Depot
setManifestid(1188360, "7670376113045976814", 32)