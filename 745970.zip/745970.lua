-- Lua provided by RyzenAPI
-- Game: Terminal Conflict

-- MAIN APPLICATION
addappid(976370)
addappid(976371)
addappid(1188360)

-- MAIN APP DEPOTS / PACKAGES
addappid(745970, 1, "ea0452d7753e2c99012890829417b067c6ec226114f399f69b37d65868f36183") -- Terminal Conflict
addappid(745971, 1, "d941289dd6b81c0d86f36d31f108d42419f7aa55804c2f85da68478086085ffa") -- Terminal Conflict Windows
addappid(745972, 1, "8007ef530625bc6ce35f05fd9e1ab0b8ff9ef4c7f18b50b8ef8be8fe63451ba7") -- Terminal Conflict Mac
addappid(745973, 1, "0bab137ea17656054f59ace7a41834db6d447ed62e5e9807f1ab1823cfe93a8c") -- Terminal Conflict Linux
addappid(976370, 1, "1e5f093ff22f09cd6b0ddebbbf1246e0cca5418bc9cb61c3161816e174cf6400") -- Terminal Conflict Supreme Commander Edition - Terminal Conflict: Supreme Commander Edition (976370) Depot
addappid(976371, 1, "6a998faab9486c63b225d1dc4e26c3cb80caa905e4b27e38e65d9aa435c23b37") -- Terminal Conflict Flower Power Edition - Terminal Conflict: Flower Power Edition (976371) Depot
addappid(1188360, 1, "09d0249e358a176c0a4afdaa8286961e15d995ab87eea839c3a303b28520c5af") -- Terminal Conflict Eyes Only Edition - Terminal Conflict: Eyes Only Edition (1188360) Depot

