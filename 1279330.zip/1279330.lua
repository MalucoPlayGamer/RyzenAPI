-- Lua provided by RyzenAPI
-- Game: Under Lock

-- MAIN APPLICATION
addappid(1279330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279331, 1, "92127045d171ec198c752e2aa0806760fcce66a3bff3622b3a2229b882813043")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
