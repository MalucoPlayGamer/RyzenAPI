-- Lua provided by RyzenAPI
-- Game: Under Lock

-- MAIN APPLICATION
addappid(1279330)
-- Game: addappid(1279330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1279331, 1, "92127045d171ec198c752e2aa0806760fcce66a3bff3622b3a2229b882813043")
