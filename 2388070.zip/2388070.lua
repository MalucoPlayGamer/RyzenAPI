-- Lua provided by RyzenAPI
-- Game: Criminal Archives: Alphabetic Murders Collector's Edition

-- MAIN APPLICATION
addappid(2388070)
addappid(2388220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2388071, 1, "36b366db0b43414ac523b8cc8184f72d930278c08a398dbd854e3953b4eec811")
