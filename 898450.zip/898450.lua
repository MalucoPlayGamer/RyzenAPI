-- Lua provided by RyzenAPI
-- Game: addappid(898450)

-- MAIN APPLICATION
addappid(898450)

-- MAIN APP DEPOTS / PACKAGES
addappid(898451, 1, "9f610dea4346954fc7c88bf2333395c34a94c71295b870f859b2d2d3a767ac27")
