-- Lua provided by RyzenAPI
-- Game: AppID 898450

-- MAIN APPLICATION
addappid(898450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(898451, 1, "9f610dea4346954fc7c88bf2333395c34a94c71295b870f859b2d2d3a767ac27")

