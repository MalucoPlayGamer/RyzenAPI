-- Lua provided by RyzenAPI
-- Game: AppID 1039870

-- MAIN APPLICATION
addappid(1039870)
-- Game: addappid(1039870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1039871, 1, "9035b218a4e45d12b06bbfc474cac7f19aebcb55345076e0ddb41227e82173af")
