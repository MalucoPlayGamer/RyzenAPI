-- Lua provided by RyzenAPI
-- Game: The Stanley Parable: Ultra Deluxe

-- MAIN APPLICATION
addappid(1703340)
-- Game: addappid(1703340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1703341, 1, "4ad33a8eebc89ec9c5958991c29f4e6107081b775da63780ea7a65863e8720b1")
addappid(1703342, 1, "966eb6d445b023674763f835aa0f2785afa11b860655b1a61602f12208dbf796")
addappid(1703343, 1, "fc29c1a04e7652e4b7f63ee3f942884a38bfb77e3ffef99a95e6c289cc7d2923")
