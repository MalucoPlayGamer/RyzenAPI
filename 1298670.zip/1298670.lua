-- Lua provided by RyzenAPI
-- Game: I, AI

-- MAIN APPLICATION
addappid(1298670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1298671, 1, "411eefaa2d4d4eb30ad179a8f6d381dede5a016e6126a96cf8acbffc136a6a33")
