-- Lua provided by RyzenAPI
-- Game: AppID 1345370

-- MAIN APPLICATION
addappid(1345370)
-- Game: addappid(1345370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1345371, 1, "6ac1442796d2885e9ac31bdaf654f08716d081cdb58d2d1db27bad3ea64891c1")
