-- Lua provided by RyzenAPI
-- Game: 3288550

-- MAIN APPLICATION
addappid(3288550)
-- Game: addappid(3288550)

-- MAIN APP DEPOTS / PACKAGES
addappid(3288551, 1, "60c6f4913e86c54865585996560d9771cecbee7bf5a9d6105d9e1e85c10348de")
