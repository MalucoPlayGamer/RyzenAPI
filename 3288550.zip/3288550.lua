-- Lua provided by RyzenAPI 
-- Game: AppID 3288550
addappid(3288550)
addappid(3288551, 1, "60c6f4913e86c54865585996560d9771cecbee7bf5a9d6105d9e1e85c10348de")
