-- 2722380's Lua and Manifest Created by Hubcap Manifest
-- Rock and Roots
-- Created: July 25, 2026 at 11:55:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2722380) -- Rock and Roots
-- MAIN APP DEPOTS
addappid(2722381, 1, "0f627c9a1fb3ef3e04dd500ddf8b52e6bc695967b09eb09b55f4f92a3f5c1b6f") -- Depot 2722381
setManifestid(2722381, "7419943626395068097", 4767000545)