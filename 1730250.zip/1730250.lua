-- Lua provided by RyzenAPI
-- Game: addappid(1730250)

-- MAIN APPLICATION
addappid(1730250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730251, 1, "d57564b59b688968f1a8070b2d818821ee5c8acc6c7b123faaccb8b091e853ba")
