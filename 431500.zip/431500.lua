-- Lua provided by RyzenAPI
-- Game: 431500

-- MAIN APPLICATION
addappid(431500)
-- Game: addappid(431500)

-- MAIN APP DEPOTS / PACKAGES
addappid(431501, 1, "b92e0c65efe8e1e06e20f4776aed809dae3a3a5f14d0933d0d2577f0a39496f3")
