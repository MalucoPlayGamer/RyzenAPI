-- Lua provided by RyzenAPI
-- Game: Shadows of Duat

-- MAIN APPLICATION
addappid(2342750)
-- Game: addappid(2342750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2342751, 1, "4c272c08bfeec56877b7f9950d58d430840d11d5d2d645ef120df11a3c2aefd7")
