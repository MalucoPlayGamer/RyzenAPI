-- Lua provided by RyzenAPI 
-- Game: Shadows of Duat
addappid(2342750)
addappid(2342751, 1, "4c272c08bfeec56877b7f9950d58d430840d11d5d2d645ef120df11a3c2aefd7")
