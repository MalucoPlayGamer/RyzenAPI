-- Lua provided by RyzenAPI
-- Game: 1912340

-- MAIN APPLICATION
addappid(1912340)
-- Game: addappid(1912340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912341, 1, "a5b6114a6aa109926ce762bd68809991b9fca762013cfb8cc17071bb3ece5792")
