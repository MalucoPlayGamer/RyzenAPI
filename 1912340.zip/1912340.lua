-- Lua provided by RyzenAPI
-- Game: The Fantasy World of Mahjong Princess

-- MAIN APPLICATION
addappid(1912340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1912341, 1, "a5b6114a6aa109926ce762bd68809991b9fca762013cfb8cc17071bb3ece5792")
