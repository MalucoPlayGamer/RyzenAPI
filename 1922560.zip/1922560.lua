-- Lua provided by RyzenAPI
-- Game: Plants vs. Zombies™ Garden Warfare 2: Deluxe Edition

-- MAIN APPLICATION
addappid(1922560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1922561, 1, "1e43c639ac6e795304b48885b326acfcd86d6f53c39fd803abd36e6770742457")
addappid(1922562, 1, "d32055c3f5e9d8642d1bebfd77315df84e7842523b7bd69efbb2e0c329d51695")
addappid(1922563, 1, "711bce276c639967f8ab97b7619c54778302a3370edcdddb7e2bde31c6ec3ac5")
addappid(1922564, 1, "a8e69ead80983a149b6696eaf6cc65cd2b399f194c94f97b47af619c99a6b26a")
addappid(1922565, 1, "a48c1b714c51b3ecedecdb2d8f18e37a9c31177340d3b3221504370a575fcee9")
addappid(1922566, 1, "e4056bac61de386a1acab287a76375a0d58940391494f572613bcedea407c17f")
addappid(1922567, 1, "6ea3881bdead8fd6ae22deffa8561f30d3a0b4d89dc58c1ba3fbeba9ea7c82d0")
addappid(1922568, 1, "0636e5895910391007947a54c5490128989fa679d8a4983028e476c4d4e00c30")
addappid(1922569, 1, "6c0dca675dbd318fd4433dde3ca733de100108fb3e75c4818e9d1273eebb2c64")
addappid(3340991, 0, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1922590)
