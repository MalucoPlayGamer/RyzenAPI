-- Lua provided by RyzenAPI
-- Game: Chocolate makes you happy 7

-- MAIN APPLICATION
addappid(892880)

-- MAIN APP DEPOTS / PACKAGES
addappid(892881, 1, "0ab91cac8a45c1544eb8f209bd41d9e3affbc00f70aa57681b606166ebc4f77f")
