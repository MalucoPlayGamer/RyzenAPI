-- Lua provided by RyzenAPI
-- Game: Flesh Eating Geriatric Internet Predator

-- MAIN APPLICATION
addappid(1521670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1521671, 1, "f657e89b0759967c074b33261479728b27a32f7cdf134974816c790564d0f68c")
