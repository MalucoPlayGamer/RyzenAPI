-- Lua provided by RyzenAPI
-- Game: Starsphere

-- MAIN APPLICATION
addappid(408750)

-- MAIN APP DEPOTS / PACKAGES
addappid(408751, 1, "9ce17c7e87e223784bac7a8b1029e51437fa9b7ec348984548487b7e0523ab37")
