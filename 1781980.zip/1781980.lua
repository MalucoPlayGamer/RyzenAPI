-- Lua provided by RyzenAPI
-- Game: addappid(1781980)

-- MAIN APPLICATION
addappid(1781980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1781981, 1, "4d221ac0a91f76c2d0f699ebe48ab34255a4fa599caed48043d00e63149d9e1a")
