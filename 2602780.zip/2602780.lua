-- Lua provided by RyzenAPI
-- Game: Game: Filly Astray

-- MAIN APPLICATION
addappid(2602780)
-- Game: addappid(2602780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2602781, 1, "3053300d50123d035ef26f6532805a56813a8c4ff6b521c8706e169b91c57bdf")
