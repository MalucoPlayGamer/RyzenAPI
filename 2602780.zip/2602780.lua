-- Lua provided by RyzenAPI 
-- Game: Filly Astray
addappid(2602780)
addappid(2602781, 1, "3053300d50123d035ef26f6532805a56813a8c4ff6b521c8706e169b91c57bdf")
