-- Lua provided by SkyAPI 
-- Game: Thin Judgment
addappid(661460)
addappid(661461, 1, "2a220a8cc5476d6f128964bf3b0119439669b5e9dfcc848a296a310a505f99e2")
