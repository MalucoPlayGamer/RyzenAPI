-- Lua provided by RyzenAPI
-- Game: Thin Judgment

-- MAIN APPLICATION
addappid(661460)

-- MAIN APP DEPOTS / PACKAGES
addappid(661461, 1, "2a220a8cc5476d6f128964bf3b0119439669b5e9dfcc848a296a310a505f99e2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
