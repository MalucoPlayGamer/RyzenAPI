-- Lua provided by RyzenAPI
-- Game: Game: Hidden World 5 Top-Down 3D

-- MAIN APPLICATION
addappid(2655720)
-- Game: addappid(2655720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2655721, 1, "be86eba966cff3ef525932bfa61200a7045dcb4e1591c0790b0303bd5e7b801d")
