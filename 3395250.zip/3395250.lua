-- 3395250's Lua and Manifest Created by Hubcap Manifest
-- Broken Wings: Hornet Down
-- Created: August 12, 2026 at 09:20:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3395250) -- Broken Wings: Hornet Down
-- MAIN APP DEPOTS
addappid(3395251, 1, "c2747063283aa700e0495146d40f90b2d66d62ff2bf2abe36adf6635f269e7c0") -- Depot 3395251
setManifestid(3395251, "3021264837682638634", 3279627335)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3395255) -- Depot 3395255 (empty depot)