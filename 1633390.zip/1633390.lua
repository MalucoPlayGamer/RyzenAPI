-- Lua provided by RyzenAPI
-- Game: Hentai Pretty

-- MAIN APPLICATION
addappid(1633390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1633391, 1, "b8ef02eee1b58a7c9bf2317b55b4037f750892ddd46759dd5c7ae16a37a596b6")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(4852050)
addappid(4852060)
addappid(4852070)
addappid(4852080)
addappid(4852090)
addappid(4852100)
addappid(4852110)
addappid(4852130)
addappid(4852140)
addappid(4852150)
addappid(4852160)
addappid(4852170)
addappid(4852180)
addappid(4852190)
addappid(4852200)
addappid(4852210)
addappid(4852220)
addappid(4852230)
addappid(4852240)
addappid(4852250)
