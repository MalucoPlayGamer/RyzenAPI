-- Lua provided by RyzenAPI
-- Game: addappid(3227870)

-- MAIN APPLICATION
addappid(3227870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3227871, 1, "499b6e1e02b28aeea34ceb5665dcc0c3a8c006884b78c2e03964803578ac07e6")
