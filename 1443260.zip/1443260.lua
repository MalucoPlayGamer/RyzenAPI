-- Lua provided by RyzenAPI
-- Game: Game: Endless

-- MAIN APPLICATION
addappid(1443260)
-- Game: addappid(1443260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1443261, 1, "f1f0deb5e58d12250b02bde8187aac2cca07ab7923660fdd024ffee68b22b7dc")
