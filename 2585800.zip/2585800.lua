-- Lua provided by RyzenAPI
-- Game: OverDrift Festival Demo

-- MAIN APPLICATION
addappid(2585800)
-- Game: addappid(2585800)

-- MAIN APP DEPOTS / PACKAGES
addappid(2585801, 1, "692e52791da0003c8f052dd459cc5013fd7c11c783d59a345711cc654b9885fa")
