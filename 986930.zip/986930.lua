-- Lua provided by RyzenAPI
-- Game: Perchang

-- MAIN APPLICATION
addappid(986930)

-- MAIN APP DEPOTS / PACKAGES
addappid(986931, 1, "830c5ccc1d7816f97c42c8a1bcd66838b603b5859b5cb10f449aed83cd6d4b2a")
addappid(986932, 1, "0f1caa730a2d9dc40568c3e4ad2014ea56a16a840f777b288590be10754bf886")
addappid(986933, 1, "2caa04aaf4de0edfa0e806b3cb25925e933721c07d6f917f4c1ba0548c67a038")
