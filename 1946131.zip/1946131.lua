-- Lua provided by RyzenAPI
-- Game: 1946131

-- MAIN APPLICATION
addappid(1946131)
-- Game: addappid(1946131)

-- MAIN APP DEPOTS / PACKAGES
addappid(1946131,0,"5b54b785b8082ee545523c38a0e20fdb32e7eae556c7237d865acdbd11db2d1b")
