-- Lua provided by SkyAPI 
-- Game: AppID 1334160
addappid(1334160)
addappid(1334161, 1, "0700862c29af9b1c85027d679f793afc25a97d86ae6edc537abd22ec0cb2a072")
