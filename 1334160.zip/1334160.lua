-- Lua provided by RyzenAPI
-- Game: addappid(1334160)

-- MAIN APPLICATION
addappid(1334160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1334161, 1, "0700862c29af9b1c85027d679f793afc25a97d86ae6edc537abd22ec0cb2a072")
