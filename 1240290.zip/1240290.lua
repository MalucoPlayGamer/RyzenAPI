-- Lua provided by RyzenAPI
-- Game: Infestation: Battle Royale

-- MAIN APPLICATION
addappid(1240290)
-- Game: addappid(1240290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1240291, 1, "78af79c864f62ee2c9532f77d09e1f9e650c764bd5826928609cacb9d2d3a254")
