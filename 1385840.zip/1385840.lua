-- Lua provided by RyzenAPI
-- Game: Cube Worlds Survival

-- MAIN APPLICATION
addappid(1385840)
addappid(1483460)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385841, 1, "82c6526f11c25e05856a6f13f8707388a8d3375ec96fbbc4ac2b80fa1336ee51")
