-- Lua provided by RyzenAPI
-- Game: 1385840

-- MAIN APPLICATION
addappid(1385840)
-- Game: addappid(1385840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1385841, 1, "82c6526f11c25e05856a6f13f8707388a8d3375ec96fbbc4ac2b80fa1336ee51")
