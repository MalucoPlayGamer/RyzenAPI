-- Lua provided by RyzenAPI
-- Game: AppID 2251110

-- MAIN APPLICATION
addappid(2251110)
-- Game: addappid(2251110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2251111, 1, "a1856d0e96a2a132cceb1e4566e9f140ae7768c415cd212d271b97783f1e133f")
