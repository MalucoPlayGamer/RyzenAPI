-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2274960)

-- MAIN APP DEPOTS / PACKAGES
addappid(2274962,0,"939dc17bc718a00c21bc0553278ec156575aec9881631252c9bdd16efbd51572")

