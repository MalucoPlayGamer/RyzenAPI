-- Lua provided by RyzenAPI
-- Game: addappid(3727670)

-- MAIN APPLICATION
addappid(3727670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3727671, 1, "b16f829770e25a858a429bb7591ebfb91b2368fcb115ff641426c2c0ad3f72ae")
