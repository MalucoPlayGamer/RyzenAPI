-- Lua provided by RyzenAPI
-- Game: addappid(1203350)

-- MAIN APPLICATION
addappid(1203350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1203350,0,"f101c9fdb3ab4bad006a357acbc08735fc00549481de6758c47b54d782bf84e0")
