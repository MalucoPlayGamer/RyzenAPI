-- Lua provided by RyzenAPI
-- Game: addappid(406400)

-- MAIN APPLICATION
addappid(406400)

-- MAIN APP DEPOTS / PACKAGES
addappid(406401, 1, "4bd2e587a2bdc3dc0b8ec85ed0548b23e5dea3d6038808f86723155209d5cf26")
