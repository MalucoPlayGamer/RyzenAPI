-- Lua provided by RyzenAPI
-- Game: AppID 406400

-- MAIN APPLICATION
addappid(406400)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(406401, 1, "4bd2e587a2bdc3dc0b8ec85ed0548b23e5dea3d6038808f86723155209d5cf26")

