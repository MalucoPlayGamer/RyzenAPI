-- Lua provided by RyzenAPI
-- Game: League of Legends

-- MAIN APPLICATION
addappid(20590)

-- MAIN APP DEPOTS / PACKAGES
addappid(20591, 1, "74b14cfe0457b64add86f18049f4c2aa52ee163a76e23a2f1c46b50d9b57429a")
addappid(20592, 1, "4953799b99cc8743e5dab7a0bcb89d8857e69fe985e1dc08021416be35575394")
addappid(20593, 1, "4ff3c7a21b0f6e0f1d249fa9ea24eac2250b431509eea03221dbe4d80ac8663f")
addappid(20594, 1, "e8ffba7961a3e02860c01873400af4eadb0d16c94339ea5c1261605dd9f61fa9")
