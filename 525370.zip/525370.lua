-- Lua provided by RyzenAPI
-- Game: 525370

-- MAIN APPLICATION
addappid(525370)
-- Game: addappid(525370)

-- MAIN APP DEPOTS / PACKAGES
addappid(525372,0,"b9913dfddb89374ab601e8cd81f8234cd70bc88bfdbd9a8dc6a67a315eb9c8a7")
