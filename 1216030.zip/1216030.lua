-- Lua provided by RyzenAPI
-- Game: Wildfire Swap

-- MAIN APPLICATION
addappid(1216030)
addappid(1216031)
addappid(1216033)

-- MAIN APP DEPOTS / PACKAGES
addappid(1216032,0,"21e686b1b60a742eab63a834e5391d136cb5ff86c36b628729dab7cdffb3c939")

