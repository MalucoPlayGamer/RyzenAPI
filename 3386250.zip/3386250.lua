-- Lua provided by RyzenAPI
-- Game: Game: EPHEMERAL -MINIATURE GARDEN-

-- MAIN APPLICATION
addappid(3386250)
-- Game: addappid(3386250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3386251, 1, "8d3dab9bf507f7e809b95efefacc4d689911d35f2af62da3209125d8b0c436e1")
