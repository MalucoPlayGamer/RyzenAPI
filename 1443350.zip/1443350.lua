-- Lua provided by RyzenAPI
-- Game: Game: DEAD CIDE CLUB

-- MAIN APPLICATION
addappid(1443350)
-- Game: addappid(1443350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1443351, 1, "70ad8df9cd71b45c633aad12b931048df9428100e69a99e4ea167e6973d1f203")
