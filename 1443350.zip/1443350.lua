-- Lua provided by RyzenAPI
-- Game: DEAD CIDE CLUB

-- MAIN APPLICATION
addappid(1443350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1443351, 1, "70ad8df9cd71b45c633aad12b931048df9428100e69a99e4ea167e6973d1f203")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
