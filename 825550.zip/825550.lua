-- Lua provided by RyzenAPI
-- Game: addappid(825550)

-- MAIN APPLICATION
addappid(825550)

-- MAIN APP DEPOTS / PACKAGES
addappid(825551, 1, "82aa0be85d7d84632db3e6d7124ffdfd0c22567b0ba685498ce9d2d33ce4b915")
