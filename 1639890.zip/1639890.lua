-- Lua provided by RyzenAPI
-- Game: After School Murder Club!!

-- MAIN APPLICATION
addappid(1639890)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639891, 1, "dd45491db53d95958a2917fb3a8358d5029e00332dd5db2df7324f6590914d5d")

