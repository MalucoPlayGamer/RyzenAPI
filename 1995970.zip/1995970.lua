-- Lua provided by RyzenAPI
-- Game: Rush Rally Origins Demo

-- MAIN APPLICATION
addappid(1995970)
-- Game: addappid(1995970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995971, 1, "3f66300277de7ed9f227b06ce9f599ea1c8e06288cf57d339b9193e52a7230fc")
