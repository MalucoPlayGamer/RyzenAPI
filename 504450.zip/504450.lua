-- Lua provided by RyzenAPI
-- Game: AppID 504450

-- MAIN APPLICATION
addappid(504450)
-- Game: addappid(504450)

-- MAIN APP DEPOTS / PACKAGES
addappid(504451, 1, "032bc0b5e89b490d6df7188ace38789a6c969d0d928ed038b99886c675a57522")
