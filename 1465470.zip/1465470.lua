-- Lua provided by RyzenAPI
-- Game: Game: AppID 1465470

-- MAIN APPLICATION
addappid(1465470)
-- Game: addappid(1465470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1465471, 1, "93f4a37540967cc2e6b661061973e3281089b15e33a95fd24afdb5e6045aeebd")
