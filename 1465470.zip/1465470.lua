-- Lua provided by RyzenAPI
-- Game: The Crust

-- MAIN APPLICATION
addappid(1465470)
addappid(4627820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1465471, 1, "93f4a37540967cc2e6b661061973e3281089b15e33a95fd24afdb5e6045aeebd")
