-- Lua provided by RyzenAPI
-- Game: Good Robot

-- MAIN APPLICATION
addappid(358830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(358831, 1, "d966730139e6e00d4958e227a2e817892402b49faa199169e410b20618b65c7d")
addappid(439690, 0, "cf96153f134906a5a96d34da3f574a7e6cf1ceadffc4037607f1a351e7cfa7af")
