-- Lua provided by RyzenAPI 
-- Game: 炎の料理人クッキングファイター好
addappid(3401830)
addappid(3401831, 1, "54ba776a5247a801bbf67c808ad15cf0df8a152ac89205f2c2411ce65a063dab")
