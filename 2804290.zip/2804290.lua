-- Lua provided by RyzenAPI
-- Game: 英雄竞起

-- MAIN APPLICATION
addappid(2804290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2804291, 1, "f777557998e132385ad8d1cb998c357ed7f79972acb63336e321f0fcdd1b2b44")

