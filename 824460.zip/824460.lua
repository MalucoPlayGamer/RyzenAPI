-- Lua provided by RyzenAPI 
-- Game: HELLFRONT: HONEYMOON
addappid(824460)
addappid(824461, 1, "f08e729147bd5dbb33612c6f4a1816462335d2e770789e78cbb97eb9fcbcf11a")
