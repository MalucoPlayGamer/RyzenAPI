-- Lua provided by RyzenAPI
-- Game: HELLFRONT: HONEYMOON

-- MAIN APPLICATION
addappid(824460)
-- Game: addappid(824460)

-- MAIN APP DEPOTS / PACKAGES
addappid(824461, 1, "f08e729147bd5dbb33612c6f4a1816462335d2e770789e78cbb97eb9fcbcf11a")
