-- Lua provided by RyzenAPI
-- Game: WW2 Rebuilder: Remagen Map DLC

-- MAIN APPLICATION
addappid(2506150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2506151, 1, "e71ea2fcc257144a4f0ad4aa89666310d7e1439523e4f5a90eaeba5d5d5c2243")
