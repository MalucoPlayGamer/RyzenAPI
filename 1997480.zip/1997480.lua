-- Lua provided by RyzenAPI
-- Game: Liu Shan Maker

-- MAIN APPLICATION
addappid(1997480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1997481, 1, "6e01ca386e2eaaa9606f025f59618ddb12818c3b17f5857d2afba781fafe9270")
