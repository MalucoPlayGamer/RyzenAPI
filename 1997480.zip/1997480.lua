-- Lua provided by SkyAPI 
-- Game: AppID 1997480
addappid(1997480)
addappid(1997481, 1, "6e01ca386e2eaaa9606f025f59618ddb12818c3b17f5857d2afba781fafe9270")
