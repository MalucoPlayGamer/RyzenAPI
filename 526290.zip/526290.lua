-- Lua provided by RyzenAPI
-- Game: MY FIGHT

-- MAIN APPLICATION
addappid(526290)
addappid(874540)
addappid(876400)
addappid(876401)

-- MAIN APP DEPOTS / PACKAGES
addappid(526291, 1, "8f51f6022586a9b066a6170babb250dbbc77a6bb9df91e8cab70332abf2a6444")
