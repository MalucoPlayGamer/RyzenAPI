-- Lua provided by RyzenAPI
-- Game: AppID 1157220

-- MAIN APPLICATION
addappid(1157220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1157221, 1, "8b01c34853791362bcf43f590508f20c9f5acb3eeabdf63f21fa868d6019e9d1")
addappid(1157222, 1, "21b3fb398e9c4e92d36f21da5249d3afa8ab5ffa61411c39a239fdf7d0cd50df")
addappid(1157223, 1, "1a1acc91b1ad8205f6920274f9ca1f0c0ed1611a41987899c1a79f9ee3994d7c")
addappid(2199200, 0, "aedd7ce2df8799f018f23fd2d852a9d09a34bcdef46bb82f2be79b287e7b20a6")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
