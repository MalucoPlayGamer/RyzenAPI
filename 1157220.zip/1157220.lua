-- Lua provided by RyzenAPI
-- Game: AppID 1157220

-- MAIN APPLICATION
addappid(1157220)
-- Game: addappid(1157220)

-- MAIN APP DEPOTS / PACKAGES
addappid(1157221, 1, "8b01c34853791362bcf43f590508f20c9f5acb3eeabdf63f21fa868d6019e9d1")
addappid(1157222, 1, "21b3fb398e9c4e92d36f21da5249d3afa8ab5ffa61411c39a239fdf7d0cd50df")
addappid(1157223, 1, "1a1acc91b1ad8205f6920274f9ca1f0c0ed1611a41987899c1a79f9ee3994d7c")
addappid(2199200, 0, "aedd7ce2df8799f018f23fd2d852a9d09a34bcdef46bb82f2be79b287e7b20a6")
