-- Lua provided by RyzenAPI
-- Game: 2538490

-- MAIN APPLICATION
addappid(2538490)
-- Game: addappid(2538490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2538491, 1, "b51ccfe6aad3f8970b983fe3273282e779accdf682b02c7baa21c30183cf3c09")
