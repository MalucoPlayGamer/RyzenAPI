-- Lua provided by RyzenAPI
-- Game: Tormented Souls

-- MAIN APPLICATION
addappid(1367590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1367591, 1, "8d266d458eb33548cd821afee1d03b3b3dac003b602b36e3f35e7c2dfbf95ee4")
