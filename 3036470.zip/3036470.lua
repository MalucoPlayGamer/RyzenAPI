-- Lua provided by RyzenAPI
-- Game: addappid(3036470)

-- MAIN APPLICATION
addappid(3036470)

-- MAIN APP DEPOTS / PACKAGES
addappid(3036471, 1, "5fc57b2207d8fb6f926f800ecf9328369a3088a62a9211f35fc01c6f24a55a38")
