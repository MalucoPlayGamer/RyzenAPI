-- Lua provided by SkyAPI 
-- Game: 河神：沉溺之流
addappid(3036470)
addappid(3036471, 1, "5fc57b2207d8fb6f926f800ecf9328369a3088a62a9211f35fc01c6f24a55a38")
