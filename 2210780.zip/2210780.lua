-- Lua provided by RyzenAPI
-- Game: Game: Hentai BunnyGirl

-- MAIN APPLICATION
addappid(2210780)
-- Game: addappid(2210780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2210781, 1, "6e8f908a22814309bf2f2239365052e4cf0f42e53c92df743146ce2328479103")
