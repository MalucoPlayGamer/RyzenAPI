-- Lua provided by RyzenAPI
-- Game: Created: October 01, 2025 at 11:03:54 EDT

-- MAIN APPLICATION
addappid(1101420) -- 巨龙召唤
addappid(2263890) -- Dragon Call - Dragon Tower
addappid(2265570) -- Dragon Call - Aquarium Tower
addappid(2265571) -- Dragon Call - Demon Tower
addappid(2265572) -- Dragon Call - Devil Tower
addappid(2265573) -- Dragon Call - Hachi Tower

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(1101421, 1, "32a7cdff09c0ee029e6d8dc6876510d0fe2ed3ea2fa39f1072b7ae947bc67582") -- 巨龙召唤 Content

