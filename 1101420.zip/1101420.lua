-- Lua provided by SkyAPI 
-- Game: Dragon Call
addappid(1101420)
addappid(1101421, 1, "32a7cdff09c0ee029e6d8dc6876510d0fe2ed3ea2fa39f1072b7ae947bc67582")
