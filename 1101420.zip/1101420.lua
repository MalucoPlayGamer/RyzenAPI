-- Lua provided by RyzenAPI
-- Game: Dragon Call

-- MAIN APPLICATION
addappid(1101420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1101421, 1, "32a7cdff09c0ee029e6d8dc6876510d0fe2ed3ea2fa39f1072b7ae947bc67582")

