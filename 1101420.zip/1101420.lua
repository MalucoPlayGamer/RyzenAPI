-- 1101420's Lua and Manifest Created by Hubcap Manifest
-- 巨龙召唤
-- Created: October 01, 2025 at 11:03:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 5
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1101420) -- 巨龙召唤
-- MAIN APP DEPOTS
addappid(1101421, 1, "32a7cdff09c0ee029e6d8dc6876510d0fe2ed3ea2fa39f1072b7ae947bc67582") -- 巨龙召唤 Content
setManifestid(1101421, "5687266272723173035", 1318617554)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2263890) -- Dragon Call - Dragon Tower
addappid(2265570) -- Dragon Call - Aquarium Tower
addappid(2265571) -- Dragon Call - Demon Tower
addappid(2265572) -- Dragon Call - Devil Tower
addappid(2265573) -- Dragon Call - Hachi Tower