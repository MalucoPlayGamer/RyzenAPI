-- Lua provided by RyzenAPI
-- Game: 366380

-- MAIN APPLICATION
addappid(366380)
-- Game: addappid(366380)

-- MAIN APP DEPOTS / PACKAGES
addappid(366381, 1, "fc0e22d6d0fe70e2d61c27ed0520f66c7e5ce168124e4ecb4e5525230c609cb9")
