-- Lua provided by RyzenAPI
-- Game: addappid(483850)

-- MAIN APPLICATION
addappid(483850)

-- MAIN APP DEPOTS / PACKAGES
addappid(483851, 1, "227eb45c7233f36a95535ded8bda4730f1f9beb93626d6bddddf32ba571bb8ad")
addappid(483852, 1, "8f7c88aee90957012286e8a1d1028da5bdfc766170c836d46cf31a344c0bc3fa")
addappid(483853, 1, "42cc37d6b70551e817c547f8fddca04a26bce885a38ba6d638cc200d5e031fce")
