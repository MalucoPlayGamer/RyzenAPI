-- Lua provided by RyzenAPI
-- Game: Stream Arenas

-- MAIN APPLICATION
addappid(1390300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1390301, 1, "0313da3a45cd396411df8645766066b28ddd72f45434c894cd90aef8a7d70378")

