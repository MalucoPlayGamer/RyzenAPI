-- Lua provided by RyzenAPI
-- Game: 3103380

-- MAIN APPLICATION
addappid(3103380)
-- Game: addappid(3103380)

-- MAIN APP DEPOTS / PACKAGES
addappid(3103381, 1, "74f10af28671b9013ebddf6b7644e7489d3761da5ac623eb6a1ff881b01ac0de")
