-- Lua provided by RyzenAPI
-- Game: 316840

-- MAIN APPLICATION
addappid(316840)
-- Game: addappid(316840)

-- MAIN APP DEPOTS / PACKAGES
addappid(316841, 1, "f6ff2e71401e88473d62a7580cf9467fb04fe335198c2bb1aa9535ec8adcc1cd")
