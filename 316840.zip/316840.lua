-- Lua provided by SkyAPI 
-- Game: The Sacred Tears TRUE
addappid(316840)
addappid(316841, 1, "f6ff2e71401e88473d62a7580cf9467fb04fe335198c2bb1aa9535ec8adcc1cd")
