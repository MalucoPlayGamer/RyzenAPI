-- Lua provided by RyzenAPI
-- Game: DFF NT: Zanarkand Abes Uniform Appearance Set for Tidus

-- MAIN APPLICATION
addappid(1022502)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022502,0,"175c0eae9ec06ed2c3a8ddadc135a69408d4b9e2117780e3c9c6a33a527a8953")
