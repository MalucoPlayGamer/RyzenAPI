-- Lua provided by RyzenAPI
-- Game: Evil Labs

-- MAIN APPLICATION
addappid(680860)

-- MAIN APP DEPOTS / PACKAGES
addappid(680861,0,"cdff8d1b5f3f0928a3c75abf5898ab8152369b70e3d8e53ad5b4fa28982881f9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
