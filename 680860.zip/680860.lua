-- Lua provided by RyzenAPI
-- Game: Evil Labs

-- MAIN APPLICATION
addappid(680860)

-- MAIN APP DEPOTS / PACKAGES
addappid(680861,0,"cdff8d1b5f3f0928a3c75abf5898ab8152369b70e3d8e53ad5b4fa28982881f9")

