-- Lua provided by RyzenAPI
-- Game: Supraworld

-- MAIN APPLICATION
addappid(1869290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1869291, 1, "dd5c65c18dd7671d1a2e2df6dd21a59c408a1f152880e563649ee7508a88f2bc")
