-- Lua provided by RyzenAPI
-- Game: Rumours of a Roman Empire 18+ Patch

-- MAIN APPLICATION
addappid(3750180)
-- Game: addappid(3750180)

-- MAIN APP DEPOTS / PACKAGES
addappid(3750180,0,"9ee66d65ca4ec3231b84f5d77e662e3e4d55b05a841303af306a177bef021c0e")
