-- Lua provided by RyzenAPI
-- Game: Rampage of the Dead

-- MAIN APPLICATION
addappid(890640)

-- MAIN APP DEPOTS / PACKAGES
addappid(890641, 1, "9853145449f51893ce6a362a6fc4dc5cf850b6ad57a5dfe1ebe026fd672380a7")

