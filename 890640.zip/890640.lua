-- Lua provided by SkyAPI 
-- Game: Rampage of the Dead
addappid(890640)
addappid(890641, 1, "9853145449f51893ce6a362a6fc4dc5cf850b6ad57a5dfe1ebe026fd672380a7")
