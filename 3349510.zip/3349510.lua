-- Generated with Luie @ https://lua.tools/
-- 3349510 - The Ancient Magus' Bride Midsummer Pilgrimage
-- Generated 2026-08-24 18:42:21 UTC
-- # Depots (Total/DLC/Shared): 2/0/1

-- Main AppID
addappid(3349510)

-- Main Depots
addappid(3349511, 1, "b387f04f9f3d1f0f08c4dcd5ad1ee3dd4f2381fca8a171784cc70f6444916712")
setManifestid(3349511, "9053022825603716436", 2070409878)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
