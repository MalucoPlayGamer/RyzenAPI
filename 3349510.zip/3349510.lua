-- Lua provided by RyzenAPI
-- Game: The Ancient Magus' Bride Midsummer Pilgrimage

-- MAIN APPLICATION
addappid(3349510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(3349511, 1, "b387f04f9f3d1f0f08c4dcd5ad1ee3dd4f2381fca8a171784cc70f6444916712")

