-- Lua provided by RyzenAPI
-- Game: Grenade Madness

-- MAIN APPLICATION
addappid(432480)
-- Game: addappid(432480)

-- MAIN APP DEPOTS / PACKAGES
addappid(432481, 1, "7323d5d0bb42d832a4f6f353234567848d03a8d615e33d22d33a1738e5f4bd70")
