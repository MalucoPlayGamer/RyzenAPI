-- Lua provided by RyzenAPI
-- Game: Derpy Dino

-- MAIN APPLICATION
addappid(2387100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2387101, 1, "50fc3385f9806645781b7c506db0113c14ce4c2ac25de673215f41427d80d6a7")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
