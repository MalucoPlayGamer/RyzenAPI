-- Lua provided by RyzenAPI
-- Game: SACRALITH : The Archer`s Tale

-- MAIN APPLICATION
addappid(704360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(704361, 1, "fcab4882a9bee2d05e1bc5514190b83e18ddec6929657f286fefcafd2f298d26")

