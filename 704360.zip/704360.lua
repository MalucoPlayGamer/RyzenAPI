-- Lua provided by RyzenAPI
-- Game: 704360

-- MAIN APPLICATION
addappid(704360)
-- Game: addappid(704360)

-- MAIN APP DEPOTS / PACKAGES
addappid(704361, 1, "fcab4882a9bee2d05e1bc5514190b83e18ddec6929657f286fefcafd2f298d26")
