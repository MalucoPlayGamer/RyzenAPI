-- Lua provided by RyzenAPI
-- Game: Escape From Lighthouse

-- MAIN APPLICATION
addappid(2435750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2435751, 1, "62a5eebf47e3b6a1cc29795e76252f45364bd292b2a4d689d3e725e7652c770c")

