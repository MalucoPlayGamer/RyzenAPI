-- Lua provided by RyzenAPI
-- Game: Mine & Slash

-- MAIN APPLICATION
addappid(3417900)
-- Game: addappid(3417900)

-- MAIN APP DEPOTS / PACKAGES
addappid(3417901, 1, "dd9f175e96c14532349deb6430c864bf94192baf1760662e05c8acea8505434b")
