-- Lua provided by SkyAPI 
-- Game: Mine
addappid(2390860)
addappid(2390861, 1, "964252a1180a156c34847443d42150bb7d07dce73192bd263798a517f0c6a411")
