-- Lua provided by RyzenAPI
-- Game: addappid(1304450)

-- MAIN APPLICATION
addappid(1304450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304451, 1, "b01a8df66777858ef116c3d35b8d6ef30a2638899f4b78e87e58baa187b558ac")
