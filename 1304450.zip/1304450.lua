-- Lua provided by RyzenAPI
-- Game: Die Again: Prologue

-- MAIN APPLICATION
addappid(1304450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304451, 1, "b01a8df66777858ef116c3d35b8d6ef30a2638899f4b78e87e58baa187b558ac")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1354250)
