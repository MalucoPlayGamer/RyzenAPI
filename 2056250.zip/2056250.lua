-- Lua provided by RyzenAPI
-- Game: Game: You are the weapon! Genesis

-- MAIN APPLICATION
addappid(2056250)
-- Game: addappid(2056250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2056251, 1, "ec2812ae56c7d48f636b375fd2b6d26fa579bc1389393ddcbe764dc7f3629de2")
