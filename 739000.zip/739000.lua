-- Lua provided by RyzenAPI
-- Game: addappid(739000)

-- MAIN APPLICATION
addappid(739000)

-- MAIN APP DEPOTS / PACKAGES
addappid(739001, 1, "d3734f3f0bbc29b88d0a48d8121b673e2256e06fabee185c60be44cf3f71d925")
