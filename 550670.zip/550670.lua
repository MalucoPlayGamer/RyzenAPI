-- Lua provided by RyzenAPI
-- Game: What The Heck, Dude?

-- MAIN APPLICATION
addappid(550670)

-- MAIN APP DEPOTS / PACKAGES
addappid(550671, 1, "37eace1e56586ea135fa330a7aa787f7fdd43229d1108087b8895638637f2bad")
