-- Lua provided by RyzenAPI
-- Game: Game: AppID 550670

-- MAIN APPLICATION
addappid(550670)
-- Game: addappid(550670)

-- MAIN APP DEPOTS / PACKAGES
addappid(550671, 1, "37eace1e56586ea135fa330a7aa787f7fdd43229d1108087b8895638637f2bad")
