-- Lua provided by RyzenAPI
-- Game: Smart Factory

-- MAIN APPLICATION
addappid(941500)

-- MAIN APP DEPOTS / PACKAGES
addappid(941501, 1, "3a2e0163e2a4f41f71471305b79ba7bd8a17b72a8b55c23f6a249f99c557f39a")
