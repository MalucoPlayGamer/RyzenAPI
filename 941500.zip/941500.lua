-- Lua provided by SkyAPI 
-- Game: AppID 941500
addappid(941500)
addappid(941501, 1, "3a2e0163e2a4f41f71471305b79ba7bd8a17b72a8b55c23f6a249f99c557f39a")
