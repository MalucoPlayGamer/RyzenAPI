-- Lua provided by RyzenAPI
-- Game: 1234630

-- MAIN APPLICATION
addappid(1234630)
-- Game: addappid(1234630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234631, 1, "04178b1ab79ecff1bcd9fd7a16c80bff684a962bf6cdb6ee0276953eb269e727")
