-- Lua provided by SkyAPI 
-- Game: AppID 1110300
addappid(1110300)
addappid(1110301, 1, "a751e12dfd54b7957d6389fc55dc2715508e977297a63fd6245f171b04a28305")
