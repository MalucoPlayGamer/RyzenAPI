-- Lua provided by RyzenAPI
-- Game: Machine Ruin Self-Destruction Masturbation Life of the Sky Temple

-- MAIN APPLICATION
addappid(1774970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1774971, 1, "919a8e1d5ea260eb0bb3c4c1d5174ad8b6350131ce18990c944041bbeaa2d106")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
