-- 3982830's Lua and Manifest Created by Hubcap Manifest
-- Bottle Cracks
-- Created: August 14, 2026 at 06:09:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3982830) -- Bottle Cracks
-- MAIN APP DEPOTS
addappid(3982831, 1, "1fa6e1dbfe9c9c54bbb2429292d78512f76a2f40715d3e54f8b0670f3e0a026e") -- Depot 3982831
setManifestid(3982831, "5653687494062317493", 1285359713)
addappid(3982832, 1, "48a53d2de0b335d5b7254ace0cee1456b1ff73edca6ab8621ff8251a8f1d38d9") -- Depot 3982832
setManifestid(3982832, "8090208662789547856", 1429220234)