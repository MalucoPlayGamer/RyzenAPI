-- Lua provided by RyzenAPI
-- Game: Bottle Cracks

-- MAIN APPLICATION
addappid(3982830) -- Bottle Cracks

-- MAIN APP DEPOTS / PACKAGES
addappid(3982831, 1, "1fa6e1dbfe9c9c54bbb2429292d78512f76a2f40715d3e54f8b0670f3e0a026e") -- Depot 3982831
addappid(3982832, 1, "48a53d2de0b335d5b7254ace0cee1456b1ff73edca6ab8621ff8251a8f1d38d9") -- Depot 3982832

