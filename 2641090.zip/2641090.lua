-- Lua provided by RyzenAPI
-- Game: 2641090

-- MAIN APPLICATION
addappid(2641090)
-- Game: addappid(2641090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2641091, 1, "48a67094d44c04b196bcae3d1c7f2b372cbb544d9b44b0dcc4220c2b4dc27b28")
