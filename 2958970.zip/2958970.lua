-- Lua provided by RyzenAPI
-- Game: The Thing: Remastered

-- MAIN APPLICATION
addappid(2958970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2958971, 1, "6a77249e795dc23efaa8cc24bd18b87cd28f6707dc75eeb0e8f7a3170cd8e420")
addappid(2958972, 1, "8d1dc0c5fcf66fd80551e763fb9476517739447e5c617f42584661657027fcbc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
