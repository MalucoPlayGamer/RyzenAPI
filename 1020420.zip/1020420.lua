-- Lua provided by RyzenAPI 
-- Game: AppID 1020420
addappid(1020420)
addappid(1020421, 1, "cf0535b1856698aa915239ec2dc17b81886fb5347a6b8c43e5f23ac992a24934")
