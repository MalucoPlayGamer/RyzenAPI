-- Lua provided by RyzenAPI
-- Game: Game: AppID 1020420

-- MAIN APPLICATION
addappid(1020420)
-- Game: addappid(1020420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1020421, 1, "cf0535b1856698aa915239ec2dc17b81886fb5347a6b8c43e5f23ac992a24934")
