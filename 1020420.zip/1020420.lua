-- Lua provided by RyzenAPI
-- Game: AppID 1020420

-- MAIN APPLICATION
addappid(1020420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1020421, 1, "cf0535b1856698aa915239ec2dc17b81886fb5347a6b8c43e5f23ac992a24934")

