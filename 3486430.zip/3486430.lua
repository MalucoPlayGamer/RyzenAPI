-- Lua provided by RyzenAPI
-- Game: 帝国：权杖与文明

-- MAIN APPLICATION
addappid(3486430)

