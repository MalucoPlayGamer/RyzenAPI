-- Lua provided by RyzenAPI
-- Game: Hush

-- MAIN APPLICATION
addappid(379990)
-- Game: addappid(379990)

-- MAIN APP DEPOTS / PACKAGES
addappid(379991, 1, "4427345a2043dd9778b88dd2e87140777836aa1b69129dad099e583b4c3f8311")
