-- Lua provided by RyzenAPI
-- Game: Didactic Jesus Game

-- MAIN APPLICATION
addappid(2138140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2138141,0,"f7020908b58f48d56c6e86603d0b3b9531b39d99ac40f32e2db935db838f4d48")

