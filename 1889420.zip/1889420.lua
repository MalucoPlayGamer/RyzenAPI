-- Lua provided by RyzenAPI
-- Game: AppID 1889420

-- MAIN APPLICATION
addappid(1889420)
-- Game: addappid(1889420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1889421, 1, "8699585fc7e54f941df44476ceb4462d3e76587ccb4ff3106f8970a5fd25c9b0")
