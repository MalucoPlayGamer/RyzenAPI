-- Lua provided by SkyAPI 
-- Game: 天机录 Demo
addappid(2696640)
addappid(2696641, 1, "2df71cfc218aaa53313e9cc2d9c939e603b43df339a1ce9ae7dff459d72a149f")
