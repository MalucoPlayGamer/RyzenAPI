-- Lua provided by RyzenAPI
-- Game: 天机录 Demo

-- MAIN APPLICATION
addappid(2696640)
-- Game: addappid(2696640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2696641, 1, "2df71cfc218aaa53313e9cc2d9c939e603b43df339a1ce9ae7dff459d72a149f")
