-- Lua provided by RyzenAPI
-- Game: VR Triber

-- MAIN APPLICATION
addappid(680170)

-- MAIN APP DEPOTS / PACKAGES
addappid(680171, 1, "a21ccd2e5aa6788d2ff58886608b949cfbcdb4c1d84a2482941fe31d4d85e636")

