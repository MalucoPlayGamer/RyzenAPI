-- Lua provided by RyzenAPI
-- Game: Take Care (of me)

-- MAIN APPLICATION
addappid(3478190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3478191, 1, "afb7ef883936244170f63dc9059d9ff48bb8bb2f3778ce02042c7c6608fccaf5")

