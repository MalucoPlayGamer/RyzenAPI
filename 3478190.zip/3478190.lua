-- Lua provided by RyzenAPI
-- Game: Take Care (of me)

-- MAIN APPLICATION
addappid(3478190)

-- MAIN APP DEPOTS / PACKAGES
addappid(3478191, 1, "afb7ef883936244170f63dc9059d9ff48bb8bb2f3778ce02042c7c6608fccaf5")
