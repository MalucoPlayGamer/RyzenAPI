-- Lua provided by RyzenAPI
-- Game: addappid(1115630)

-- MAIN APPLICATION
addappid(1115630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1115631, 1, "2725e8cc8d2c9e35351d0c00b1c1a4eb5a5dd429f794e3d96ecaa52b3dbf5c86")
