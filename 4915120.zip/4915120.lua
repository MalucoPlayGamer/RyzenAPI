-- Lua provided by RyzenAPI
-- Game: Wacky! Deer & Munk Adventure

-- MAIN APPLICATION
addappid(4915120) -- Wacky! Deer & Munk Adventure

-- MAIN APP DEPOTS / PACKAGES
addappid(4915121, 1, "15f9aa84c954770b92d6e9e0930adf137c42fcfb56d4929dd8dd8493ce36ab01") -- Depot 4915121

