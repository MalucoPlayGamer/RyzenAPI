-- 4915120's Lua and Manifest Created by Hubcap Manifest
-- Wacky! Deer & Munk Adventure
-- Created: August 12, 2026 at 09:12:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4915120) -- Wacky! Deer & Munk Adventure
-- MAIN APP DEPOTS
addappid(4915121, 1, "15f9aa84c954770b92d6e9e0930adf137c42fcfb56d4929dd8dd8493ce36ab01") -- Depot 4915121
setManifestid(4915121, "5862888546516758089", 857042199)