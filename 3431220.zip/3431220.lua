-- Lua provided by RyzenAPI
-- Game: Lastbane

-- MAIN APPLICATION
addappid(3431220)

-- MAIN APP DEPOTS / PACKAGES
addappid(3431221, 1, "0c611e12ac64acdf48ca34a5ad62c2672a5d4f0c19d605dfbbbde9c32cf87f8b")

