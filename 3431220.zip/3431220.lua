-- Lua provided by RyzenAPI
-- Game: Lastbane

-- MAIN APPLICATION
addappid(3431220)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3431221, 1, "0c611e12ac64acdf48ca34a5ad62c2672a5d4f0c19d605dfbbbde9c32cf87f8b")

