-- Lua provided by RyzenAPI
-- Game: Blue Epic

-- MAIN APPLICATION
addappid(2371460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2371461, 1, "6ccfa0880ae86b014d5c8743baf757343b5833d5dc6f302ad7c84ba4ef7453e5")

