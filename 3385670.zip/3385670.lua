-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(3385670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3385673,0,"962554b58ff7df8c96d922aeb7a26ee91b9ba49d04f50e0f6e927fd685a03fcd")
addappid(3385674,0,"fceb85f132e44beb22fe28071d5308eae6f0e53855066f439c9e79d503500090")
addappid(3385675,0,"8f64fb04a7f9ef13fb47698c8e263a5bf3587c5478d90b97155d40c1bc05abcd")

