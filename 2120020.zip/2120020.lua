-- Lua provided by SkyAPI 
-- Game: DISDAIN Demo
addappid(2120020)
addappid(2120021, 1, "7085f2afd305ef8d820f755e8a86e818ad369a9e284cf398946ef356ca0a86aa")
addappid(2120022, 1, "0d7340536140b64629466f465ccc1126462d30942f711c070b7bee1c004f9feb")
