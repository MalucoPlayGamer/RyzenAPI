-- Lua provided by RyzenAPI 
-- Game: AppID 1971730
addappid(1971730)
addappid(1971731, 1, "456123d60f861c9b544f537bbccc61a9e9fd254a538716a078ff6f790e87c559")
