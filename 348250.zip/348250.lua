-- Lua provided by RyzenAPI
-- Game: Google Earth VR

-- MAIN APPLICATION
addappid(348250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(348251, 1, "f82a875622a95c76144b8ced7331e1df6937f346f06c3d759d2c44af4f4bef42")

