-- Lua provided by RyzenAPI
-- Game: addappid(348250)

-- MAIN APPLICATION
addappid(348250)

-- MAIN APP DEPOTS / PACKAGES
addappid(348251, 1, "f82a875622a95c76144b8ced7331e1df6937f346f06c3d759d2c44af4f4bef42")
