-- Lua provided by RyzenAPI
-- Game: flChess 2

-- MAIN APPLICATION
addappid(1535590)
-- Game: addappid(1535590)

-- MAIN APP DEPOTS / PACKAGES
addappid(1535591, 1, "10a9ed03879f4a8a627d4da8412919a74c1800704ea4528e5488004b71b3e9d4")
