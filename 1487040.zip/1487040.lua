-- Lua provided by RyzenAPI 
-- Game: Robin Morningwood Adventure Demo
addappid(1487040)
addappid(1487041, 1, "e10f18606a8aafb466827f6dc8d341514e73e89a023cf9d09ca6eac546c36fc6")
