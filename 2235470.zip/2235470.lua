-- Lua provided by RyzenAPI
-- Game: Chrono Survival Demo

-- MAIN APPLICATION
addappid(2235470)
addappid(2235471)

-- MAIN APP DEPOTS / PACKAGES
addappid(1897741,0,"1bcd154be8739cf7e7f296d967d87760b4a474d8d2d7bb1187ee0d62a1598f3f")

