-- Lua provided by RyzenAPI
-- Game: Star Wolves 3: Civil War

-- MAIN APPLICATION
addappid(46260)

-- MAIN APP DEPOTS / PACKAGES
addappid(46261, 1, "00807b58048c3566b6e1df48d703d60c12031c8da9c128899d79d047e910c8f0")
addappid(46262, 1, "14ca91fb6e5fa7cb4d0a0b21c2464b22fece950b3e0af857bddf046a891af856")
