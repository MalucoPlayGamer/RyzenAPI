-- Lua provided by RyzenAPI
-- Game: PAC-MAN WORLD Re-PAC

-- MAIN APPLICATION
addappid(1859470)
-- Game: addappid(1859470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1859471, 1, "bffebff52cb5c7c45170741fec3f27a625042a639feb070b32df1e2da921e942")
