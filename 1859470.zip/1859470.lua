-- Lua provided by RyzenAPI
-- Game: PAC-MAN WORLD Re-PAC

-- MAIN APPLICATION
addappid(1859470)
addappid(1905680)
addappid(2197660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1859471, 1, "bffebff52cb5c7c45170741fec3f27a625042a639feb070b32df1e2da921e942")

