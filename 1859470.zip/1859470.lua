-- Lua provided by RyzenAPI 
-- Game: PAC-MAN WORLD Re-PAC
addappid(1859470)
addappid(1859471, 1, "bffebff52cb5c7c45170741fec3f27a625042a639feb070b32df1e2da921e942")
