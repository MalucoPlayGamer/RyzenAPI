-- Lua provided by RyzenAPI 
-- Game: Hyperbolica
addappid(1256230)
addappid(1256231, 1, "37f318a3acb7dfe33e6a10d287e947a0d7373b42b18c26efb46bcb4aa2757a58")
addappid(1256232, 1, "2d8398037ac313ecbe8a31e147b1f4a7f129cbee255ab5967c8d06420982f2da")
addappid(1256233, 1, "6e37af454982cf2ab8d080a48fbfa4652390f55875c39a539fd5591781dbbd45")
