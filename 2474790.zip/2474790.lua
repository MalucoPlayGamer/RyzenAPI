-- Lua provided by RyzenAPI 
-- Game: Pellet Dodge
addappid(2474790)
addappid(2474791, 1, "5e54e4737dcc297bd34d00f875c294762c2bac279a23af9008aff0c124aa51d6")
