-- Lua provided by RyzenAPI
-- Game: Dragon Storm

-- MAIN APPLICATION
addappid(1274550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1274551, 1, "8bcb73e2dbc4bc4ae209e7389d3d63a21a341b1476dd8fbfc0d4ee6c85692f18")

