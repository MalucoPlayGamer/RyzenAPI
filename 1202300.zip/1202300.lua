-- Lua provided by RyzenAPI
-- Game: 失落之白 Eternal Liiivie EP1, 與世隔絕的白族

-- MAIN APPLICATION
addappid(1202300)
addappid(1205090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202301,0,"3b39f0eae46fef818c82362d71e81c35dc22b092fbf55f89c6930ef263958951")
addappid(1202302,0,"973210367a991cb189df27077e992c4b61e278cb65970c14d67153b087bec6c0")
addappid(1202303,0,"7e1ac49025b797848d74e952fe941916de9e18db671a89c0bb13de5597290911")
addappid(1202304,0,"fb6ea8fa1c1a5456492820b76f3235278f1c0834ee80c83eb5f24cb7c421a085")
addappid(1205091,0,"ef2fa770c97ada8eeb589a6a4cbb8af85aca513a993218d33597793b07de25cf")
addappid(1205093,0,"6ce9ab6fd2cd6a5fa985c852a7afa2ee25f02e428ee4daf34ae97643224b4d0f")
addappid(1205094,0,"5a50c4f4e354d0297c853b1b28fa186fd5024662d78f08fd1ced05898b589c38")
addappid(1205095,0,"cfa1fde76ffeded2cee5572cb0dcc848c6df382ccc37e06631cd057ab9f6953f")
addappid(1457671,0,"32eb490e4db5a820000d99f7db5dfda32c2dfecec6f4c043523c7ca57c64d8f9")
addappid(1506651,0,"bb13709a3975d516133f89f826c03819769d2fa15629ffd1a703156f70dda568")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1457670)
addappid(1506650)
