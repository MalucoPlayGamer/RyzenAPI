-- Lua provided by RyzenAPI
-- Game: Game: Eternal Liiivie - EP1 Liiivie Isolated From the World

-- MAIN APPLICATION
addappid(1202300)
-- Game: addappid(1202300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1202301, 1, "3b39f0eae46fef818c82362d71e81c35dc22b092fbf55f89c6930ef263958951")
addappid(1202302, 1, "973210367a991cb189df27077e992c4b61e278cb65970c14d67153b087bec6c0")
addappid(1202303, 1, "7e1ac49025b797848d74e952fe941916de9e18db671a89c0bb13de5597290911")
addappid(1202304, 1, "fb6ea8fa1c1a5456492820b76f3235278f1c0834ee80c83eb5f24cb7c421a085")
