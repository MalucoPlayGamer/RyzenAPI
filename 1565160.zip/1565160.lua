-- Lua provided by RyzenAPI
-- Game: 1565160

-- MAIN APPLICATION
addappid(1565160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1565160,0,"a54dbf2de9713fce707317034eada980ebc267b7c66de742926e9cc9c4fe1f8c")
