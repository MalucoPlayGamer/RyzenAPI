-- 4562110's Lua and Manifest Created by Hubcap Manifest
-- Cornhole Hero
-- Created: July 24, 2026 at 12:13:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4562110) -- Cornhole Hero
-- MAIN APP DEPOTS
addappid(4562111, 1, "6481e2b52bd622a27771b616db2d4e6b1b6c13a5e6e71096b80ca4054ab0750e") -- Depot 4562111
setManifestid(4562111, "4970016522490257340", 15113196)