-- Lua provided by RyzenAPI
-- Game: Game: AppID 223870

-- MAIN APPLICATION
addappid(223870)
-- Game: addappid(223870)

-- MAIN APP DEPOTS / PACKAGES
addappid(223871, 1, "fef5279a8964683ac2065842cd49f61543b1d27368b72c3bb570608bbdcd3c1e")
