-- Lua provided by SkyAPI 
-- Game: AppID 223870
addappid(223870)
addappid(223871, 1, "fef5279a8964683ac2065842cd49f61543b1d27368b72c3bb570608bbdcd3c1e")
