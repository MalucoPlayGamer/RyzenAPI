-- Lua provided by RyzenAPI
-- Game: Syberia 3

-- MAIN APPLICATION
addappid(464340)

-- MAIN APP DEPOTS / PACKAGES
addappid(464341, 1, "1019e25457033bc25efd462edce7e0eb8318d178c3549f680e9ba7c6d02bd1ec")
addappid(464342, 1, "fdbc1a670bc77b038f99fc7228c7b0fd346b53822883b191d0cc4c1aba043f59")
addappid(464348, 1, "42d42e73080f2ca5cb31af87320c5a1d55fc0c039577ff482e2a0946e339ea7b")

