-- Lua provided by RyzenAPI
-- Game: Syberia 3

-- MAIN APPLICATION
addappid(464340)

-- MAIN APP DEPOTS / PACKAGES
addappid(464341, 1, "1019e25457033bc25efd462edce7e0eb8318d178c3549f680e9ba7c6d02bd1ec")
addappid(464342, 1, "fdbc1a670bc77b038f99fc7228c7b0fd346b53822883b191d0cc4c1aba043f59")
addappid(464348, 1, "42d42e73080f2ca5cb31af87320c5a1d55fc0c039577ff482e2a0946e339ea7b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(625350)
addappid(673500)
