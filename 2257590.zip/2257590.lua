-- Lua provided by RyzenAPI
-- Game: Game: Alien Agent X

-- MAIN APPLICATION
addappid(2257590)
-- Game: addappid(2257590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2257591, 1, "6030654899eb4963856f04bedf210c64d290ede42c7caac7bf0cd434c5a988bc")
