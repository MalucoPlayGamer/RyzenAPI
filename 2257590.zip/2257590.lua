-- Lua provided by RyzenAPI
-- Game: Alien Agent X

-- MAIN APPLICATION
addappid(2257590)
addappid(2635040)
addappid(2710030)
addappid(2710130)
addappid(2710160)
addappid(2710240)
addappid(2710350)
addappid(2710370)
addappid(2710400)
addappid(2745770)
addappid(2745780)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(2257591, 1, "6030654899eb4963856f04bedf210c64d290ede42c7caac7bf0cd434c5a988bc")

