-- Lua provided by RyzenAPI
-- Game: Dap

-- MAIN APPLICATION
addappid(1372210)

-- MAIN APP DEPOTS / PACKAGES
addappid(1372211, 1, "a95c5beee73fa228eb7b728cfc84d3218d5b18cd87b4bf9f97b9bb1512999a87")
