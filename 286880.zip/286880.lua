-- Lua provided by RyzenAPI
-- Game: Game: Disney Planes

-- MAIN APPLICATION
addappid(286880)
-- Game: addappid(286880)

-- MAIN APP DEPOTS / PACKAGES
addappid(286881, 1, "3fdf0b2e532aa3fa684998195e79647d6649508138a184e48c45caad949e4076")
