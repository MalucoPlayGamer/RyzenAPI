-- Lua provided by SkyAPI 
-- Game: Disney Planes
addappid(286880)
addappid(286881, 1, "3fdf0b2e532aa3fa684998195e79647d6649508138a184e48c45caad949e4076")
