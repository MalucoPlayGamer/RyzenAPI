-- Lua provided by RyzenAPI 
-- Game: Paresis®
addappid(2073420)
addappid(2073421, 1, "43690d178736876f0aa1aed7c14955cede464fe372ddc3d2094bcaafef7130de")
