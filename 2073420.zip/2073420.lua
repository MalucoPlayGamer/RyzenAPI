-- Lua provided by RyzenAPI
-- Game: Paresis®

-- MAIN APPLICATION
addappid(2073420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2073421, 1, "43690d178736876f0aa1aed7c14955cede464fe372ddc3d2094bcaafef7130de")
