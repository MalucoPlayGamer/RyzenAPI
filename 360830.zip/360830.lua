-- Lua provided by RyzenAPI
-- Game: AppID 360830

-- MAIN APPLICATION
addappid(360830)

-- MAIN APP DEPOTS / PACKAGES
addappid(360831, 1, "aff471072be79d3a2f8185a70402a15f4a9bfc1c33a6923e6360250ddb56868c")
addappid(360832, 1, "0f09809b40cf43920d7eb1de2bcba0220a82c6ec15d9009a3f6cf1147818cb85")
addappid(360834, 1, "a4f6986b291f71fa202421f2da320f3dc74cb605f781caf3b98d01425e3bc86f")
addappid(360835, 1, "455d8bb25b53bd38c73511f5ec67266750093340e53967c1d28f317c376dc5e2")
addappid(564251, 0, "4b3859785f55193c7ba8e65dd97974fa8942f764d4e2def34a7364dd272eba19")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
