-- Lua provided by RyzenAPI
-- Game: Game: Super Company

-- MAIN APPLICATION
addappid(1830280)
-- Game: addappid(1830280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1830281, 1, "c034125212ee83e75d414a8e27ac2420cf5ef4df4ca419974998dc0e3243f0c3")
