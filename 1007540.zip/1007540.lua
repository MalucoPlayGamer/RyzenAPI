-- Lua provided by RyzenAPI
-- Game: TankDestruction

-- MAIN APPLICATION
addappid(1007540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1007541, 1, "4417ae5c8a1841af71db1295cc110db8c28174942c995cf422aa79cae1635cf7")

