-- Lua provided by RyzenAPI
-- Game: addappid(676580)

-- MAIN APPLICATION
addappid(676580)

-- MAIN APP DEPOTS / PACKAGES
addappid(676581, 1, "e18d6590ab6f51acbfa2bd76dd04afe02053509df72efafee83b242dbd45b337")
