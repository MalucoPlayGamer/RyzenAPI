-- Lua provided by RyzenAPI 
-- Game: AppID 676580
addappid(676580)
addappid(676581, 1, "e18d6590ab6f51acbfa2bd76dd04afe02053509df72efafee83b242dbd45b337")
