-- Lua provided by RyzenAPI
-- Game: Darkest Messia

-- MAIN APPLICATION
addappid(4186810)

-- MAIN APP DEPOTS / PACKAGES
addappid(4186811,0,"8378125bb9a2ed71298fe91b30212f44f8d9ab26889e2e433127bf507bb1e2c2")

