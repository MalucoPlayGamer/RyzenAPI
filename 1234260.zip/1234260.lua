-- Lua provided by RyzenAPI
-- Game: Game: Deadly Land

-- MAIN APPLICATION
addappid(1234260)
-- Game: addappid(1234260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1234261, 1, "1806e7efd150426e7d4f295d0257bfd63924c6310d8b749718507d1812f1c136")
