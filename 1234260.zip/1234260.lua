-- Lua provided by RyzenAPI 
-- Game: Deadly Land
addappid(1234260)
addappid(1234261, 1, "1806e7efd150426e7d4f295d0257bfd63924c6310d8b749718507d1812f1c136")
