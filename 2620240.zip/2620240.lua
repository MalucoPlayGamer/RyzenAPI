-- Lua provided by RyzenAPI
-- Game: 2620240

-- MAIN APPLICATION
addappid(2620240)
-- Game: addappid(2620240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620241, 1, "ddf1b6bf9dc3109068d5264de32ea63f2f97d63b26ff6f5b6b67e80337e58174")
