-- Lua provided by RyzenAPI
-- Game: Spectral Scream

-- MAIN APPLICATION
addappid(2620240)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620241, 1, "ddf1b6bf9dc3109068d5264de32ea63f2f97d63b26ff6f5b6b67e80337e58174")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3253800)
addappid(3463860)
addappid(3477700)
