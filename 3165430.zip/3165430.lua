-- Lua provided by RyzenAPI
-- Game: Game: Dead Metro Playtest

-- MAIN APPLICATION
addappid(3165430)
-- Game: addappid(3165430)

-- MAIN APP DEPOTS / PACKAGES
addappid(3165431, 1, "10e97504e0a7bac196b867b9f6519c4b1207e21fc1a3d7b1248baf4d65653177")
