-- Lua provided by RyzenAPI
-- Game: setManifestid(945683,"6928218048804652877")

-- MAIN APPLICATION
addappid(945680)
-- Game: addappid(945680)

-- MAIN APP DEPOTS / PACKAGES
addappid(945683,0,"1ae04c419bb01076fa17dd12073983fe1198d2882f88162f9ae8d91e25e5a03a")
