-- Lua provided by RyzenAPI
-- Game: addappid(3043150)

-- MAIN APPLICATION
addappid(3043150)

-- MAIN APP DEPOTS / PACKAGES
addappid(3043151, 1, "f3abf318dda007bd8fa2a70fe7fc8f8b769ce54eb58c02346c349a3094e242ce")
