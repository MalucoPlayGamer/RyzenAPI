-- Lua provided by RyzenAPI
-- Game: Game: 12 Labours of Hercules VI: Race for Olympus (Platinum Edition)

-- MAIN APPLICATION
addappid(567800)
-- Game: addappid(567800)

-- MAIN APP DEPOTS / PACKAGES
addappid(567801, 1, "6c58803837c69b96389e0477690c37e3ade978686c5adb166531fb465e6fd156")
addappid(567802, 1, "e502045410d48490cb92d141a3b993f171a1ca8904991001eb1710ece09a47cf")
addappid(567803, 1, "9a9c0b5a656296d8bd18c8e1cf41e1ec8873699df9b142789c4fd9e5c40b59a6")
