-- Lua provided by RyzenAPI
-- Game: Dark Angels: Masquerade of Shadows

-- MAIN APPLICATION
addappid(560720)

-- MAIN APP DEPOTS / PACKAGES
addappid(560721,0,"907a7bd66df0e7ab14650ad7763823e8b6d09b507c91eb2efb8fe4e30404e134")

