-- Lua provided by RyzenAPI
-- Game: Atlas Reactor VR Character Viewer

-- MAIN APPLICATION
addappid(457230)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(457231, 1, "0a6cb8c36c8a4d50f7f4d22f1ee7173573781faed2e4449485a378327548f947")

