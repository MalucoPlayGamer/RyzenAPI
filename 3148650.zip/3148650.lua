-- Lua provided by RyzenAPI
-- Game: addappid(3148650)

-- MAIN APPLICATION
addappid(3148650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3148651, 1, "0295da1227e8704be81e7b81dd15b87ea789d9c406c853d1a5baec0b90eeb352")
