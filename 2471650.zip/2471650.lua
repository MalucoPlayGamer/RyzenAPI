-- Lua provided by RyzenAPI
-- Game: 2471650

-- MAIN APPLICATION
addappid(2471650)
-- Game: addappid(2471650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2471651, 1, "5897be5972116e2ac3e2b01c90f2ca5ca666c970ddf6fe673d7e369a9e41f50e")
