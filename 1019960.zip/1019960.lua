-- Lua provided by RyzenAPI
-- Game: addappid(1019960)

-- MAIN APPLICATION
addappid(1019960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1019960,0,"892347771f99acc691323b006b5c5a1ea6ae850d713ab3f7437eeb41ae5c948a")
