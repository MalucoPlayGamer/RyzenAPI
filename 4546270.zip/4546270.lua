-- Lua provided by RyzenAPI
-- Game: Elven Friends

-- MAIN APPLICATION
addappid(4546270)

-- MAIN APP DEPOTS / PACKAGES
addappid(4546271,0,"e969620ba257d56fa2d9d5bc3de411683de0a1cfcfcc08656f70e59e09920713")

