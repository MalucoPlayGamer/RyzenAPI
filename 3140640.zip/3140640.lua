-- Lua provided by RyzenAPI
-- Game: Nightmare

-- MAIN APPLICATION
addappid(3140640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3140641, 1, "929bc6b1bcb0dae791c1a6c3e16517dc3194b4aaebdedfa2fbdda8cca843f252")

