-- Lua provided by RyzenAPI
-- Game: 589740

-- MAIN APPLICATION
addappid(589740)
-- Game: addappid(589740)

-- MAIN APP DEPOTS / PACKAGES
addappid(589741, 1, "d4e45ad6ba58d870ce611a3841692393c7dcbff77e80c6de3f6f5582347b2ec3")
