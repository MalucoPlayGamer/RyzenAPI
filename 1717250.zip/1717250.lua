-- Lua provided by RyzenAPI
-- Game: Ratten Reich

-- MAIN APPLICATION
addappid(1717250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717251, 1, "c27382226fdd0b0fbc98069808e7cf68ee74402a72362485c919c350df2ad8a2")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
