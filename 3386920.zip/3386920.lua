-- Lua provided by RyzenAPI
-- Game: Game: AppID 3386920

-- MAIN APPLICATION
addappid(3386920)
-- Game: addappid(3386920)

-- MAIN APP DEPOTS / PACKAGES
addappid(3386921, 1, "fe25111d402704a112e5c581e3de620920aa3c9ca5d52ab0143370a186b35eca")
