-- Lua provided by RyzenAPI 
-- Game: AppID 3386920
addappid(3386920)
addappid(3386921, 1, "fe25111d402704a112e5c581e3de620920aa3c9ca5d52ab0143370a186b35eca")
