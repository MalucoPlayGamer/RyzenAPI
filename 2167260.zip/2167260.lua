-- Lua provided by RyzenAPI
-- Game: Rendering Ranger™: R² [Rewind]

-- MAIN APPLICATION
addappid(2167260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2167261, 1, "b697cbdd3a1d5e8436dfd1611b59b565aa7a2161c1309ae79c861e95eebed2f8")

