-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2908040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2908042,0,"4e43521def5859f3a82c6341c57468513f3eac1923303319f3060dcec8e0d637")
