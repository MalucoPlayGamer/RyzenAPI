-- Lua provided by RyzenAPI
-- Game: Maitetsu:Pure Station

-- MAIN APPLICATION
addappid(880950)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(880951, 1, "fc7bc4b5903a5cb267b894492c3f68f3ea7d955629d44dde05a6cb91c3dbc3f5")
addappid(978070, 0, "eeaf229a30f3683fdbae2d3fc5489cdea41d3a2e875d8367a4184c2692a78d89")
addappid(1179800, 0, "4992a727fe528e7f48f6dac2d030657eb33f33156d74338a5de6bf6432d60e3b")

