-- Lua provided by RyzenAPI
-- Game: addappid(3376980)

-- MAIN APPLICATION
addappid(3376980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3376981, 1, "260672f2c3670e2b727c57dca9d368ad7dfb33004e034796ead2deecc3eeb7f2")
