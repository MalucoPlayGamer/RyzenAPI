-- Lua provided by RyzenAPI
-- Game: Neoncube

-- MAIN APPLICATION
addappid(382070)

-- MAIN APP DEPOTS / PACKAGES
addappid(382071, 1, "4b2b4ad6c54ffece4f3e607e72ac26d024090f442f3da52eddbf6d7d192f3aa5")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
