-- Lua provided by RyzenAPI
-- Game: The Sorting Bureau

-- MAIN APPLICATION
addappid(4120790) -- The Sorting Bureau

-- MAIN APP DEPOTS / PACKAGES
addappid(4120791, 1, "08e3826b5554b9ea9e8f74d93ba8f83f614817ff8c3c2054886dfa6917656cb5") -- Depot 4120791
addappid(4120792, 1, "7a57fa1532e182e84327db0fff5d3c4d6200a0bfdd63a26866814ba8d576f815") -- Depot 4120792

