-- 4120790's Lua and Manifest Created by Hubcap Manifest
-- The Sorting Bureau
-- Created: August 21, 2026 at 22:55:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4120790) -- The Sorting Bureau
-- MAIN APP DEPOTS
addappid(4120791, 1, "08e3826b5554b9ea9e8f74d93ba8f83f614817ff8c3c2054886dfa6917656cb5") -- Depot 4120791
setManifestid(4120791, "3702663133831315203", 663360773)
addappid(4120792, 1, "7a57fa1532e182e84327db0fff5d3c4d6200a0bfdd63a26866814ba8d576f815") -- Depot 4120792
setManifestid(4120792, "5014822900292395922", 766873142)