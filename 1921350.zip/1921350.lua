-- Lua provided by RyzenAPI
-- Game: addappid(1921350)

-- MAIN APPLICATION
addappid(1921350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732391,0,"4d0b9fdb6b2518a92b11563182daf85685d3d827ecc7ca573745d057eccf494a")
