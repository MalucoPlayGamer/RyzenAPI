-- Lua provided by RyzenAPI
-- Game: Graveyard Sprint

-- MAIN APPLICATION
addappid(2383830)

-- MAIN APP DEPOTS / PACKAGES
addappid(2383831, 1, "876ce7066e0eec2e59bd1e0203cfe477e1d26447bbb2304c902004e68597b301")

