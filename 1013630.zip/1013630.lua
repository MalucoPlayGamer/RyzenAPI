-- Lua provided by RyzenAPI
-- Game: setManifestid(1013632,"3670885402471143372")

-- MAIN APPLICATION
addappid(1013630)
-- Game: addappid(1013630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1013632,0,"5bd7d21af92360e50fdcf75cfa59bae8a76317dfac71f7af4aaed67eb874dbe9")
