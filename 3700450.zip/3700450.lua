-- Lua provided by RyzenAPI
-- Game: Lootimals

-- MAIN APPLICATION
addappid(3700450)
-- Game: addappid(3700450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3700451, 1, "902c527f41fd287af5027499da31e3588944afea0ab8ee2e807d7826ef46a0ea")
