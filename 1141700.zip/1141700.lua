-- Lua provided by SkyAPI 
-- Game: Desert monsters
addappid(1141700)
addappid(1141701, 1, "d18166ac131561ffef6322e90b761f5f798d8cae0cbef3b6ef8b8c780f38ad2f")
