-- Lua provided by RyzenAPI
-- Game: My Lands: Black Gem Hunting

-- MAIN APPLICATION
addappid(290730)
