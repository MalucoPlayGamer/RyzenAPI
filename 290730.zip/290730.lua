-- Lua provided by RyzenAPI
-- Game: My Lands: Black Gem Hunting

-- MAIN APPLICATION
addappid(290730)
addappid(313310)
addappid(313311)
addappid(316500)
addappid(316510)
addappid(316520)
addappid(316530)
addappid(316541)
addappid(326690)
addappid(326691)

