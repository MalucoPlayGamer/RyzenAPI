-- Lua provided by RyzenAPI
-- Game: Metal Planet

-- MAIN APPLICATION
addappid(299840)
-- Game: addappid(299840)

-- MAIN APP DEPOTS / PACKAGES
addappid(299841, 1, "48b97fa38705b5e790d0e5ca2069dc8625b58eea4aff50acc537f337423191d8")
