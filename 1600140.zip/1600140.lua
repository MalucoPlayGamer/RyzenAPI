-- Lua provided by RyzenAPI
-- Game: addappid(1600140)

-- MAIN APPLICATION
addappid(1600140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1600141, 1, "4837b6ae15a76bb6e6cfb947d1fad3e81bca100ec7c47c20ee4b0e706e7cca6d")
