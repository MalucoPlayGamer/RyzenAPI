-- Lua provided by RyzenAPI
-- Game: Game: Void Stealer Bodycam Horror Demo

-- MAIN APPLICATION
addappid(3173860)
-- Game: addappid(3173860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3173861, 1, "c47e0056bc268f17061adcc6ecde597986810371e8e9852fa2f68776b4c860e4")
