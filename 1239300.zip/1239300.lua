-- Lua provided by RyzenAPI
-- Game: Game: AppID 1239300

-- MAIN APPLICATION
addappid(1239300)
addappid(2097350)
addappid(2097360)
-- Game: addappid(1239300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1239301, 1, "52aa46943b0a3f4b2c5d93e9b4db807feaaf9dcbb156a1c9e1557914b5914967")
