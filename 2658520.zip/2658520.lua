-- Lua provided by RyzenAPI 
-- Game: AppID 2658520
addappid(2658520)
addappid(2658521, 1, "92ce14b8704372e79102b28077153267763ea3e067b9d6d402eeeba7df5f3e11")
