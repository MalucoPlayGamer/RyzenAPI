-- Lua provided by RyzenAPI 
-- Game: SpaceShips
addappid(1605950)
addappid(1605951, 1, "49b8e8fd9f3884cc149dc5ea81ff7772787a99bb08833b821db98f11e58ea31f")
