-- Lua provided by RyzenAPI
-- Game: Game: Pilgrims

-- MAIN APPLICATION
addappid(1049280)
-- Game: addappid(1049280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1049281, 1, "7c5209bbdb617f4abfb1f788e0b4a6c58118a2d822925bd469bc6018f4135cb3")
addappid(1049282, 1, "f6eef55a693d5856508445f570e6e2f77f94ce24c6898c55f644d4e125aec688")
addappid(1049283, 1, "5739d9b06f037df8dd6cf8d4d5658d46dca3c68e0efc83210fb057866180efba")
