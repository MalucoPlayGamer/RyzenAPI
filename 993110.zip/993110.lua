-- Lua provided by RyzenAPI
-- Game: Skinwalker Hunt

-- MAIN APPLICATION
addappid(993110)
-- Game: addappid(993110)

-- MAIN APP DEPOTS / PACKAGES
addappid(993111, 1, "abcb8cebb3ca480c7a5b6b8609d73aa05e97ba5762f5753017d16dd2aa32eeac")
