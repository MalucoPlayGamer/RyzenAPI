-- Lua provided by RyzenAPI
-- Game: Nightmare Shift Demo

-- MAIN APPLICATION
addappid(3222620)

-- MAIN APP DEPOTS / PACKAGES
addappid(3222621, 1, "b2434c8bbf5dc8187af9de70d6bf500fdf02b2106676fb02ff321f9f0a7cf9a9")
