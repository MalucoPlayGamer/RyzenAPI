-- Lua provided by RyzenAPI
-- Game: Ash of Legends Demo

-- MAIN APPLICATION
addappid(1283870)
-- Game: addappid(1283870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1283871, 1, "8c735293113b8487e428686790302eb6807b15d21d9453fff4ae50a072306c73")
