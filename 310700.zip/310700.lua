-- Lua provided by RyzenAPI
-- Game: Super Win the Game

-- MAIN APPLICATION
addappid(310700)

-- MAIN APP DEPOTS / PACKAGES
addappid(310701, 1, "7dad42af40c5c65979c127c77418f8bd3003ff13f9c47ab8f00bc70ad6fea9b0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
