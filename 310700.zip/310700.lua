-- Lua provided by RyzenAPI
-- Game: 310700

-- MAIN APPLICATION
addappid(310700)
-- Game: addappid(310700)

-- MAIN APP DEPOTS / PACKAGES
addappid(310701, 1, "7dad42af40c5c65979c127c77418f8bd3003ff13f9c47ab8f00bc70ad6fea9b0")
