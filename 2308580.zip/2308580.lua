-- Lua provided by RyzenAPI
-- Game: 2308580

-- MAIN APPLICATION
addappid(2308580)
-- Game: addappid(2308580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2308581, 1, "2901cf519b3f805b99db29bf0f95eafa731bc217797f29ccbb903f4daf70008c")
