-- Lua provided by RyzenAPI
-- Game: Rogue Waters

-- MAIN APPLICATION
addappid(1691190)
-- Game: addappid(1691190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1691191, 1, "76f9add990b1becf8fea2ff19733ccb4bfda9e41437de3163903cc515d8d109d")
