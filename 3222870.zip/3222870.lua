-- Lua provided by RyzenAPI
-- Game: 3222870

-- MAIN APPLICATION
addappid(3222870)
-- Game: addappid(3222870)

-- MAIN APP DEPOTS / PACKAGES
addappid(3222871, 1, "57f9f1179484c6ec1fd7a165db6b4be5dd4911960c871e98dec258ec52e531f7")
