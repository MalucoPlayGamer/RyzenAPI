-- Lua provided by RyzenAPI 
-- Game: Valor of Man Demo
addappid(3222870)
addappid(3222871, 1, "57f9f1179484c6ec1fd7a165db6b4be5dd4911960c871e98dec258ec52e531f7")
