-- Lua provided by RyzenAPI
-- Game: Over The Void

-- MAIN APPLICATION
addappid(330470)

-- MAIN APP DEPOTS / PACKAGES
addappid(330471, 1, "728c80aac26b20fceec7d5a51af75260b9b99e401dec19685e312b8b726e8ad3")
