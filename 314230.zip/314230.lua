-- Lua provided by RyzenAPI
-- Game: Rodina

-- MAIN APPLICATION
addappid(314230)
-- Game: addappid(314230)

-- MAIN APP DEPOTS / PACKAGES
addappid(314231, 1, "beaabc4186652ff45bd6ee7b8d0d1ca7c1d12af98e0b98ea7cc942adc00046c9")
