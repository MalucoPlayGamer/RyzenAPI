-- Lua provided by RyzenAPI
-- Game: addappid(509920)

-- MAIN APPLICATION
addappid(509920)

-- MAIN APP DEPOTS / PACKAGES
addappid(509921, 1, "c52f01935da13763afc1bf6982aa3333348cefe0e160960cb79183aa1fb2ba9c")
