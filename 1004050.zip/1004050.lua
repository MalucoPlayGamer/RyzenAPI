-- Lua provided by RyzenAPI
-- Game: time of the zombies

-- MAIN APPLICATION
addappid(1004050)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(1004051, 1, "da43cc6a26cbd418364a293985b409c9d0cea149bce8e3c8977b5dbbe0afaddc")

