-- Lua provided by RyzenAPI
-- Game: addappid(1004050)

-- MAIN APPLICATION
addappid(1004050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1004051, 1, "da43cc6a26cbd418364a293985b409c9d0cea149bce8e3c8977b5dbbe0afaddc")
