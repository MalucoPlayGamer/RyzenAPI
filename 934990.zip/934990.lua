-- Lua provided by RyzenAPI
-- Game: Game: Cute Girls VR

-- MAIN APPLICATION
addappid(934990)
-- Game: addappid(934990)

-- MAIN APP DEPOTS / PACKAGES
addappid(934991, 1, "ab851c91d1c743e2f1cc7b03486b83fa5f0fda0c694ca34921c4e11a4ca15750")
