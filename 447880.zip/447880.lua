-- Lua provided by RyzenAPI
-- Game: Game: AppID 447880

-- MAIN APPLICATION
addappid(447880)
-- Game: addappid(447880)

-- MAIN APP DEPOTS / PACKAGES
addappid(447881, 1, "8824f9c647dd4a044d3e1b0eb574fdd0e57101ef8bab86735817d3c2743b119c")
