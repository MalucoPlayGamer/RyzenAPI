-- Lua provided by RyzenAPI
-- Game: 1565100

-- MAIN APPLICATION
addappid(1565100)
-- Game: addappid(1565100)

-- MAIN APP DEPOTS / PACKAGES
addappid(1565100,0,"de81ee58a951bcd9dbfed04bea0c628e28e688f761aacd2a4866cd885847005b")
addtoken(1565100,"2840617736922173174")
