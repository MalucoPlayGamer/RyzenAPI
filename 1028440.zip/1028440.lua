-- Lua provided by SkyAPI 
-- Game: Arrow Tourney
addappid(1028440)
addappid(1028441, 1, "696e43a4c22fe7b1e2b9dfa5856d486b5b79bbc126dfd4c1cadd91276e153b95")
