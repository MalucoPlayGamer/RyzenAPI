-- Lua provided by RyzenAPI
-- Game: Game: Arrow Tourney

-- MAIN APPLICATION
addappid(1028440)
-- Game: addappid(1028440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028441, 1, "696e43a4c22fe7b1e2b9dfa5856d486b5b79bbc126dfd4c1cadd91276e153b95")
