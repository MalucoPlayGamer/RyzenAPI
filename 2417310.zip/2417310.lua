-- Lua provided by SkyAPI 
-- Game: ForeVR Cornhole VR
addappid(2417310)
addappid(2417311, 1, "e62c0932c67fad397a24ffbb1f26af948297683780f0e638437af5a313ac0805")
