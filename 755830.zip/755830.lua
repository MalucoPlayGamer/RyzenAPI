-- Lua provided by SkyAPI 
-- Game: Lonely Astronaut
addappid(755830)
addappid(755831, 1, "e5f6298c055d162472992b195d2a0b596108adafb9ca502d1a859a7d4e62bf02")
addappid(755832, 1, "1e68ee0abbb2a24e4a9722b5ac525e765bf13854f4150a67b09e22811fdd45fe")
addappid(755833, 1, "2ac35cb54425a6e40b4470f57256946f36160928af71a637cb1d7ecd62b79afc")
