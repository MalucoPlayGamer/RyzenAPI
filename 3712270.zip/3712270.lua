-- Lua provided by RyzenAPI 
-- Game: Paranormal Inc.
addappid(3712270)
addappid(3712271, 1, "80cf507a49410c58ad5c31effe1bd0415b35380956cbd3e3c8b116e115023ca8")
