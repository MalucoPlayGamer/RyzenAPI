-- Lua provided by RyzenAPI
-- Game: Game: Paranormal Inc.

-- MAIN APPLICATION
addappid(3712270)
-- Game: addappid(3712270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3712271, 1, "80cf507a49410c58ad5c31effe1bd0415b35380956cbd3e3c8b116e115023ca8")
