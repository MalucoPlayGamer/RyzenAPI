-- Lua provided by RyzenAPI
-- Game: 415670

-- MAIN APPLICATION
addappid(415670)
-- Game: addappid(415670)

-- MAIN APP DEPOTS / PACKAGES
addappid(415671, 1, "a3961cba8628436e5bd99e1b2d7626e4c97eefae6d6f994e67a6a3bf05fcafe3")
