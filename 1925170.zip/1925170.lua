-- Lua provided by RyzenAPI
-- Game: Rick and Josh adventures

-- MAIN APPLICATION
addappid(1925170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1925171, 1, "2ccbafdfce0b47e731c1bb6d40fab765ef54afa31616b261e2f063e65eedfa11")
