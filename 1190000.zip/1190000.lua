-- Lua provided by RyzenAPI
-- Game: Car Mechanic Simulator 2021

-- MAIN APPLICATION
addappid(1190000)
addappid(1685720)
addappid(1685721)
addappid(1748990)
addappid(1748991)
addappid(1773800)
addappid(1773801)
addappid(1931780)
addappid(1981550)
addappid(2085260)
addappid(2112230)
addappid(2112231)
addappid(2112232)
addappid(2282030)
addappid(2464230)
addappid(2546830)
addappid(2601200)
addappid(2721070)
addappid(2889700)
addappid(3335470)
addappid(3660210)
-- Game: addappid(1190000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1190001, 1, "b4f04348a15ca7c50e5275db9f0569947a2e3926ad0f05db23b4032050ee2f77")
