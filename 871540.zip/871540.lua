-- Lua provided by SkyAPI 
-- Game: BMX Streets
addappid(871540)
addappid(871541, 1, "0158c064648ac4e2ebeaaac25704874b8ad9e392f695b2675ada1266720ee67e")
