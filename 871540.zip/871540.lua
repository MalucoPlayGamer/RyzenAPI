-- Lua provided by RyzenAPI
-- Game: BMX Streets

-- MAIN APPLICATION
addappid(871540)

-- MAIN APP DEPOTS / PACKAGES
addappid(871541, 1, "0158c064648ac4e2ebeaaac25704874b8ad9e392f695b2675ada1266720ee67e")

