-- Lua provided by RyzenAPI
-- Game: Twin Cobra

-- MAIN APPLICATION
addappid(2022910)
-- Game: addappid(2022910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2022911, 1, "d9fbf4a75f422ec8c176ac515aa4787773dd733e3e93b6fd152ed510c7e55122")
addappid(2022912, 1, "978c9e4bb538f61f9b38389b6715161151b6f9925d2c835ca421ffbcca5e086a")
addappid(2022913, 1, "68f0b2feb33abc6d8f0d9916cf98b6917f0ff5d4d692edf209845cb422bad2be")
