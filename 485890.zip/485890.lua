-- Lua provided by RyzenAPI
-- Game: Game: AppID 485890

-- MAIN APPLICATION
addappid(485890)
-- Game: addappid(485890)

-- MAIN APP DEPOTS / PACKAGES
addappid(485891, 1, "ed56c96dc1b420cbdcfdfec2bd33eb65ced587fa3fd6713f8d4c16599cb97d28")
