-- Lua provided by RyzenAPI
-- Game: AppID 485890

-- MAIN APPLICATION
addappid(485890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- (windows)
addappid(485891, 1, "ed56c96dc1b420cbdcfdfec2bd33eb65ced587fa3fd6713f8d4c16599cb97d28")

