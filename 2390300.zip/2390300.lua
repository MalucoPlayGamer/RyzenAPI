-- Lua provided by RyzenAPI
-- Game: Game: The Skylia Prophecy - Original Game Soundtrack

-- MAIN APPLICATION
addappid(2390300)
-- Game: addappid(2390300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2390301, 1, "a7a37f84c66fe9d843b028a417b8d89f18fedeb70c8446806e812ace544c6f67")
