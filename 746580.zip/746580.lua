-- Lua provided by RyzenAPI
-- Game: HARDCORE MECHA

-- MAIN APPLICATION
addappid(746580)
addappid(955590)
addappid(1125641)
addappid(1125642)
addappid(1146680)
addappid(1146690)
addappid(1187230)
addappid(1344050)

-- MAIN APP DEPOTS / PACKAGES
addappid(746582,0,"62bb5d1a8c8fdf7da74c644516197a58f4d8a54b700fb073c1cfc4fa2e8a3586")
addappid(1125640,0,"0e5880dcb3b9bdc149864470e31f96e8afec03d3219d31fef7758fc428f29672")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
