-- Lua provided by RyzenAPI
-- Game: Game: Kika & Daigo: A Curious Tale

-- MAIN APPLICATION
addappid(1205140)
-- Game: addappid(1205140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1205141, 1, "df51fb90ae6f09bc1c78547697d50fd75dedbe435aead4fded6eddc7269f35c3")
