-- Lua provided by RyzenAPI
-- Game: Game: Helltaker

-- MAIN APPLICATION
addappid(1289310)
-- Game: addappid(1289310)

-- MAIN APP DEPOTS / PACKAGES
addappid(1289311, 1, "8a76446486a985b6fb8019f9ff9cb51717155afebaf093f777936ca31df07bd8")
addappid(1289312, 1, "0aef62a3de894c4ef02336c5798e38c21a2a4564caa327e5412fe7d240811288")
addappid(1289313, 1, "36a1150a257c814238b63986e8bd03f1179691714589bff626e2bf0b7d6794a2")
addappid(1289314, 1, "0ae3f8de8828c5aa3bafe13d91bb5c66830de99cae356751025b076dfbff3cb1")
addappid(1289315, 1, "77e4cd127cd6a189e8409ad5b3bed50b03b00b130c9e35a17f02b8d1daefa9fd")
addappid(1298590, 0, "839e47fd3b43d3eba1d5cff9162c1b94ee0ac5053f347e46cf3dbd1d8de44acd")
