-- Lua provided by RyzenAPI
-- Game: Endeavor: Rite of Passage

-- MAIN APPLICATION
addappid(1737110)
-- Game: addappid(1737110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1737111, 1, "04a031709b974a4276ff56c1acebc94b0e8771dcfde39912fd5fba889c8bcac8")
