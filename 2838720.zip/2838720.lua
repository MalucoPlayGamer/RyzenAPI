-- Lua provided by RyzenAPI
-- Game: Game: Tile Cities 2

-- MAIN APPLICATION
addappid(2838720)
-- Game: addappid(2838720)

-- MAIN APP DEPOTS / PACKAGES
addappid(2838721, 1, "a1fb454bd2b0cb95793dab0b7b4a913a903302a66c74596f76f5e50552aad311")
