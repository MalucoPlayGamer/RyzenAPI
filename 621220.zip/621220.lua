-- Lua provided by RyzenAPI
-- Game: Nantucket

-- MAIN APPLICATION
addappid(621220)
addappid(621221)
addappid(621223)
addappid(621224)
-- Game: addappid(621220)

-- MAIN APP DEPOTS / PACKAGES
addappid(621222,0,"4e6c5077fa5728189e12dc66c1b23670cb4accab3aa642601a26706456032295")
addappid(963260,0,"7595b6ff0e604e7891d7cce00ae213a8c57d4b5d9502c3b38f52bdff98b6b62c")
