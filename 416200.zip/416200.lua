-- Lua provided by RyzenAPI 
-- Game: Door To Door
addappid(416200)
addappid(416201, 1, "0d4bef2a4a7a962f53f600ad5f8b6c9364b02c5436e06165ddf30625f328c793")
