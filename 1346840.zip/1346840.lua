-- Lua provided by RyzenAPI
-- Game: Dead Reset

-- MAIN APPLICATION
addappid(1346840)
addappid(3496680)
-- Game: addappid(1346840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1346841, 1, "97c6131497053c1bb5d67ba18ab299d620ed9102c349d33a39a88f631ffbea41")
addappid(1346842, 1, "639e6998b8fd3c6504cc09f16dc96c068665e905632e4045daa48aae2f01c32c")
