-- Lua provided by RyzenAPI
-- Game: FREE GIRLS!

-- MAIN APPLICATION
addappid(2845190)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2845191, 1, "b91448b123813ac55dd146455f1950f70354340929ac7869ad165935e1b1294b")

