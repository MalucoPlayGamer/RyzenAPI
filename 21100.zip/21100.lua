-- Lua provided by RyzenAPI
-- Game: AppID 21100

-- MAIN APPLICATION
addappid(21100)
addappid(21150)
addappid(21160)
-- Game: addappid(21100)

-- MAIN APP DEPOTS / PACKAGES
addappid(21101, 1, "ba10622b48dd42a9e3941bce6da0417a57f676495edf533eabd2496edfdc2d40")
addappid(21102, 1, "7013a143f441beb09084cd5428103293baa61470594c4c622d70dbea23c6165c")
addappid(21103, 1, "a69cce87cd47ecee7373c646a45e3ab23298e7cd3aa5e7bdc97d70475e7ba55e")
addappid(21104, 1, "c24fbd4c2d9338e1aac3a4f941f07fed9168e61853346e886c646fe7d6dffa93")
addappid(21105, 1, "3682793c0655c3933288f1c3f22caaac7db3c66995cb45c5ce2cab787d636e33")
addappid(21106, 1, "b268a1b39c880bf54108aba9aa7fa06c0684c0fe937ae097f9cd071510147657")
addappid(21107, 1, "635ad7a5304754a0be85f9eab3a23b5697ac40b8a9afed43a6173c2910f48f9d")
addappid(21108, 1, "67a96846c0db3d26b323abb2ff918bdc12acdefc5a0924040c8ec8c922420430")
addappid(21109, 1, "a35eea34e0af13b68d30fddc068ded42455e580131eb56bc4dfdb4124e5ace5f")
