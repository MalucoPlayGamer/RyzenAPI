-- Lua provided by RyzenAPI
-- Game: Bomber 3

-- MAIN APPLICATION
addappid(2142920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142921, 1, "79fe52e5687f0145f7d187babd71eb8c87428c67dd16412da50fddd9a45e19f4")
