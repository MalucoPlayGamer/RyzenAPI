-- Lua provided by RyzenAPI
-- Game: Game: AppID 2495750

-- MAIN APPLICATION
addappid(2495750)
-- Game: addappid(2495750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2495751, 1, "1a52732bbae77991ed4797f5db1bcdfe0845b0668622c99466414980868d24cc")
