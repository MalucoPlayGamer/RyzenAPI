-- Lua provided by RyzenAPI
-- Game: 705450

-- MAIN APPLICATION
addappid(705450)
addappid(730080)
-- Game: addappid(705450)

-- MAIN APP DEPOTS / PACKAGES
addappid(705451, 1, "f3997d0eff184e55e12a9ec9ac541984a375733161c8d52b5c3e3fbd1a08098d")
