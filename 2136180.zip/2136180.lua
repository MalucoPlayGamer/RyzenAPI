-- Lua provided by RyzenAPI
-- Game: addappid(2136180)

-- MAIN APPLICATION
addappid(2136180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2136181, 1, "d94cb61681561bdb7302bcfefedee76dfa16cc24d3d3e6baed6755c870e43f9a")
