-- Lua provided by RyzenAPI
-- Game: 1960270

-- MAIN APPLICATION
addappid(1960270)
-- Game: addappid(1960270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1960271, 1, "b5d5f1bd784dea43a9d929ebcc65b50f78f389fc736a77bc6c6a3be00cda669a")
