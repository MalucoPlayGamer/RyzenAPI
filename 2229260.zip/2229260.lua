-- Lua provided by RyzenAPI
-- Game: Eden Eternal-聖境伝説

-- MAIN APPLICATION
addappid(2229260)

