-- Lua provided by RyzenAPI
-- Game: Shadowrun: Dragonfall - Director's Cut

-- MAIN APPLICATION
addappid(300550)

-- MAIN APP DEPOTS / PACKAGES
addappid(300551, 1, "703650d09be35123f9717dfcad7b46203deb3b098c471063a010c84822a10eb4")
addappid(300552, 1, "52f5f8e7c0c977445ee4740080f0ee6399aaa5cee0b2c0fe367f10461a12c4de")
addappid(300553, 1, "3ee65416fea61526581510cc661b343f75b42b3e085dbc166dde55f84c6968cd")
