-- Lua provided by RyzenAPI
-- Game: 428660

-- MAIN APPLICATION
addappid(428660)
-- Game: addappid(428660)

-- MAIN APP DEPOTS / PACKAGES
addappid(428664,0,"e072081b016be219b51a7c467a06165d7610f3fa36ed6aa4274a56db733ffb96")
