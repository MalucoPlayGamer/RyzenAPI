-- Lua provided by RyzenAPI
-- Game: Deliver Us The Moon

-- MAIN APPLICATION
addappid(428660)

-- MAIN APP DEPOTS / PACKAGES
addappid(428664,0,"e072081b016be219b51a7c467a06165d7610f3fa36ed6aa4274a56db733ffb96")

