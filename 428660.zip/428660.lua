-- Lua provided by RyzenAPI
-- Game: Deliver Us The Moon

-- MAIN APPLICATION
addappid(428660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(428664,0,"e072081b016be219b51a7c467a06165d7610f3fa36ed6aa4274a56db733ffb96")

