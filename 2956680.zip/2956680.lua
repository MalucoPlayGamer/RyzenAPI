-- 2956680's Lua and Manifest Created by Hubcap Manifest
-- LORT
-- Created: August 13, 2026 at 18:52:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2956680, 1, "69d0d14f84f1c1b925350fe0cc1d5daa1c61a2706f5406a67df68d59cc25e5d0") -- LORT
-- MAIN APP DEPOTS
addappid(2956681, 1, "69cd8a153b0209cfdd7ac94f8abeb8283ae6642bd2679e85dfc0760c94da4d97") -- Depot 2956681
setManifestid(2956681, "5567933229170182545", 3191008392)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)