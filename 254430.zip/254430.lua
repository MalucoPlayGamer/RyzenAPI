-- Lua provided by RyzenAPI
-- Game: AppID 254430

-- MAIN APPLICATION
addappid(254430)

-- MAIN APP DEPOTS / PACKAGES
addappid(254431, 1, "b5f18d3e09fa8eef85191ef969e3aeeb2d8d3711e1550eef7c89aaeb63028ef8")

