-- Lua provided by RyzenAPI
-- Game: 2353820

-- MAIN APPLICATION
addappid(2353820)
-- Game: addappid(2353820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2353821, 1, "b60540d996b30ab5f3fd2e49385e8c1a23bd11344a6fb49f1489aa63c629dfd0")
