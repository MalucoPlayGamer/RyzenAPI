-- Lua provided by RyzenAPI
-- Game: Office Affairs : Executive Decisions

-- MAIN APPLICATION
addappid(3259040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3259041, 1, "d32191c7a911000adc85051b2a5677a34b70c12f34648b113fdcc7e318dc9c0c")

