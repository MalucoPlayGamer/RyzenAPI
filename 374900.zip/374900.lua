-- Lua provided by RyzenAPI
-- Game: Game: AppID 374900

-- MAIN APPLICATION
addappid(374900)
-- Game: addappid(374900)

-- MAIN APP DEPOTS / PACKAGES
addappid(374901, 1, "13e0e51efe9497a75f48d023fe97bfdfca415dd15ca3a567edb8a51e6f118de1")
addappid(374902, 1, "47c0e77754ee5c1b3342ac54311ead652cbca40e874ec5dae4f69aad477abb15")
addappid(374903, 1, "c11dc33dcd75cad9eadeefcb09dddf570cefaebc3d1210bdd196fd7f5e90740e")
addappid(374904, 1, "4d9d579f9539340635c334a21dacfbaf7dec0d82337786d7a73f096b5dcaaa41")
addappid(374905, 1, "a61c3de0c334b2e377636876cb6406987f8a6604639c0142544729b293aa9fd9")
addappid(374906, 1, "e8fe72b8eed29ed03a0fa2d9ad586878572f91065ad956bb5fd9b20a6312da81")
addappid(374907, 1, "045e9d507d091b4660cec0fe5992a7ab9a198fd4aa395f4fb9d92d0cad3f041a")
addappid(374908, 1, "c68531311bf52bb87a23c34cd8c5a279bf603d3acd95c3e24eca578e69ebfcea")
addappid(374909, 1, "387ed89dfa4ceb238c07b6f83eee8094a23c29a827ccff7f6d5f7c05026ecc3c")
