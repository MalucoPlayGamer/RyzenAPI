-- Lua provided by RyzenAPI
-- Game: 781610

-- MAIN APPLICATION
addappid(781610)
-- Game: addappid(781610)

-- MAIN APP DEPOTS / PACKAGES
addappid(781611, 1, "fb896a9db35d4975ab8c3f05f793a8a3d2e0762f96b074574f2685ae10d10782")
