-- Lua provided by RyzenAPI
-- Game: 2434490

-- MAIN APPLICATION
addappid(2434490)
-- Game: addappid(2434490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2434491, 1, "98efc3872478b88db3a54f7c7cb8c4e37ee5ae442ea24ad0238936088b4e414a")
