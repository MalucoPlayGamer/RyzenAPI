-- Lua provided by RyzenAPI
-- Game: 2215640

-- MAIN APPLICATION
addappid(2215640)
-- Game: addappid(2215640)

-- MAIN APP DEPOTS / PACKAGES
addappid(2215641, 1, "6c6f646e165a1ee49277789b60066b6dcd589e5b3d5bfce32aabcffcdfd26c2e")
addappid(2215642, 1, "94a61efe844fb414a3add6f56d441cf205f63342bcbc81a38fdd14fa42a2dcc4")
