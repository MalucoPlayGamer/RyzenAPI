-- Lua provided by RyzenAPI
-- Game: Autumn Dream

-- MAIN APPLICATION
addappid(521980)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(521981, 1, "12343bb3753e9ef434bbbe0f097b5f4ced8177c1dc5b15df6ed8d02c59637333")

