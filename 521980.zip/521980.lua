-- Lua provided by RyzenAPI
-- Game: addappid(521980)

-- MAIN APPLICATION
addappid(521980)

-- MAIN APP DEPOTS / PACKAGES
addappid(521981, 1, "12343bb3753e9ef434bbbe0f097b5f4ced8177c1dc5b15df6ed8d02c59637333")
