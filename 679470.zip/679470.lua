-- Lua provided by RyzenAPI
-- Game: Solenars Edge Rebirth

-- MAIN APPLICATION
addappid(679470)
addappid(872050)
addappid(928290)
addappid(1430960)

-- MAIN APP DEPOTS / PACKAGES
addappid(679471, 1, "106f9b612dbc6e0d28983107bca838ee86feee9ee0020793208d3483e612b12e")
