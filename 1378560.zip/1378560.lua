-- Lua provided by RyzenAPI
-- Game: X-Plane 11 - Add-on: Aerosoft - XPRealistic v2

-- MAIN APPLICATION
addappid(1378560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378560,0,"ea8af523b7625c87430b9bd746e4b6b616591a3309eaaffa76b151b0499630a0")

