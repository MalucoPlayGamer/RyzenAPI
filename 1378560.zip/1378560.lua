-- Lua provided by RyzenAPI
-- Game: 1378560

-- MAIN APPLICATION
addappid(1378560)
-- Game: addappid(1378560)

-- MAIN APP DEPOTS / PACKAGES
addappid(1378560,0,"ea8af523b7625c87430b9bd746e4b6b616591a3309eaaffa76b151b0499630a0")
