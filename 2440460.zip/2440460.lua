-- Lua provided by RyzenAPI
-- Game: Game: Botany Manor Demo

-- MAIN APPLICATION
addappid(2440460)
-- Game: addappid(2440460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2440461, 1, "a7e38ef1d7da5628287f37dd894f1e7526991028836b350ab7c3390090831734")
