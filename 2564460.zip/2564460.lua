-- Lua provided by RyzenAPI
-- Game: Banter

-- MAIN APPLICATION
addappid(2564460)
-- Game: addappid(2564460)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564461, 1, "fc621a7d159a7365febc1e9ff1ff0175582cdcb77a2fefc274217e7000bda6a8")
