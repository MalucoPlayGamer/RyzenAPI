-- Lua provided by RyzenAPI
-- Game: Stranded In Time

-- MAIN APPLICATION
addappid(385150)
-- Game: addappid(385150)

-- MAIN APP DEPOTS / PACKAGES
addappid(385151, 1, "8175de7e28529d805bf7113b0329ddf1fb16dc989b00a8a7f2d86f9c4da3c48b")
addappid(385152, 1, "aaae812145aab6207115e8b55b1975df5f0544de94e2af707c5d3267deb2b4eb")
addappid(385153, 1, "172557909fd313c367c3b0625ae2092b0ab878610ecff929661676dd5613da81")
