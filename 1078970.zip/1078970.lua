-- Lua provided by RyzenAPI
-- Game: 局外人 L'Etranger

-- MAIN APPLICATION
addappid(1078970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1078971, 1, "44778218a9f9f70cc5201817060615cc491a28c9dc3a935aabb9a8759030decd")
addappid(1078972, 1, "15c46547821e12c885c0939545077e9a8d5fb5d16720f6b2881d53dcdc6f6461")
addappid(1078973, 1, "00b44a3ac56364e52642ea6e49fd1d2d888bff91058dfcf37b797d14710e6193")
addappid(1078974, 1, "308635baa23563dcfb18f289a24fb9bbb3d38ce0013ad32b5b0872e5103a120a")
addappid(1078975, 1, "c00b4a66e7bcf769d8c80362556eb6f5ac747bf413d249ccf91bb9e70480f1b5")
addappid(1078976, 1, "f72f3826b9a8b25605af1a4e9d635fcfc1a1a86dc6bb2945974ac20b2b0778a3")
addappid(1887900, 0, "5898b0ee5e8d5117f8f5ec1546163ec5842ca9ef6156e28657c6175e58307abb")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
