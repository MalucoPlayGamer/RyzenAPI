-- Lua provided by RyzenAPI
-- Game: Forgotten Fields

-- MAIN APPLICATION
addappid(1296980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1296982,0,"d075e3b15dc15b580d30a75490a5820dc81a4cafae80700dc4ce2dc3a7c258d5")
