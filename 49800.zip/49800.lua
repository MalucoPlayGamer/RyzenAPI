-- Lua provided by RyzenAPI 
-- Game: Flight of the Icarus
addappid(49800)
addappid(49801, 1, "24bb26a2202bd6100c734a5ebb80b3e129d6ef548b15f3c842a3374bbc19c9ef")
addappid(49802, 1, "5574249a0e7418f567a89e7ed1b4174d74e279e8bd3600fe9bcf236d92a39b12")
addappid(49803, 1, "6a191a13e5429573fdb250f0bb2438b55de9f669cedba05b3adca3edd20ec7e6")
