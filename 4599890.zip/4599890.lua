-- Lua provided by RyzenAPI
-- Game: Hong Kong Horror Incident: Yik Sin House

-- MAIN APPLICATION
addappid(4599890)

-- MAIN APP DEPOTS / PACKAGES
addappid(4599891,0,"5d86ed099afc8004a35b25aa2fa56d4eb5b754dc4c1b4402aae223f86be564af")

