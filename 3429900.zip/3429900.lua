-- Lua provided by RyzenAPI 
-- Game: AppID 3429900
addappid(3429900)
addappid(3429901, 1, "fd22606a6d84d400dce9d9603ad9eb871674ca4a917800ac9e82f395cafb8927")
