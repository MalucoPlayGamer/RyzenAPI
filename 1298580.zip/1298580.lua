-- Lua provided by SkyAPI 
-- Game: AppID 1298580
addappid(1298580)
addappid(1298581, 1, "92095878d570355301fc88ed3ee89d9ab6b153e13b4ab0f2e559d0c6578897d8")
