-- Lua provided by RyzenAPI
-- Game: 2195350

-- MAIN APPLICATION
addappid(2195350)
-- Game: addappid(2195350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2195351, 1, "855ce63e5b78fe7d46e656a3db4facd4a2f370080cc21830b59058a4055eb542")
