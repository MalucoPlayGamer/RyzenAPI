-- Lua provided by RyzenAPI
-- Game: 2623090

-- MAIN APPLICATION
addappid(2623090)

-- MAIN APP DEPOTS / PACKAGES
addappid(2623094,0,"6cbee5e9a4598bfbbb38f71087cfd103a5b85397d9afa95fef9e0dfd88d10963")

