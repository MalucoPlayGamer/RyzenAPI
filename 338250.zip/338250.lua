-- Lua provided by RyzenAPI
-- Game: Sigmund Minisode 1 [Free 2013 Holiday Special]

-- MAIN APPLICATION
addappid(338250)

-- MAIN APP DEPOTS / PACKAGES
addappid(338250,0,"327400bdcaf5863124d2bb33e5209fb4ee526815cbeb5f03ebba82ed9093ea08")
