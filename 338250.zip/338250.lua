-- Lua provided by RyzenAPI
-- Game: addappid(338250)

-- MAIN APPLICATION
addappid(338250)

-- MAIN APP DEPOTS / PACKAGES
addappid(338250,0,"327400bdcaf5863124d2bb33e5209fb4ee526815cbeb5f03ebba82ed9093ea08")
