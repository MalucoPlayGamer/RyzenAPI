-- Lua provided by RyzenAPI
-- Game: Game: AppID 1301930

-- MAIN APPLICATION
addappid(1301930)
-- Game: addappid(1301930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1301931, 1, "42ff5b1e3eaae657bd4494d004d213c42adc04f18b5c8edc72214d4ab7d1d606")
