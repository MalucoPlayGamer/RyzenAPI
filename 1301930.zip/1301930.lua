-- Lua provided by RyzenAPI 
-- Game: AppID 1301930
addappid(1301930)
addappid(1301931, 1, "42ff5b1e3eaae657bd4494d004d213c42adc04f18b5c8edc72214d4ab7d1d606")
