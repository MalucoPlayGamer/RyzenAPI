-- Lua provided by SkyAPI 
-- Game: Life Eater
addappid(2632930)
addappid(2632931, 1, "8146b5addf44e3d378bf678b574a06b3e23079c0bb1c63ddbbb03bc2cbe70722")
