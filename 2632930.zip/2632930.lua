-- Lua provided by RyzenAPI
-- Game: 2632930

-- MAIN APPLICATION
addappid(2632930)
-- Game: addappid(2632930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2632931, 1, "8146b5addf44e3d378bf678b574a06b3e23079c0bb1c63ddbbb03bc2cbe70722")
