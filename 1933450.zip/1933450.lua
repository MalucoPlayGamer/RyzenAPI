-- Lua provided by RyzenAPI
-- Game: ​Triple Fantasy

-- MAIN APPLICATION
addappid(1933450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1933451, 1, "8d4ad67c480af1f4bf40d0ac088db2a68cb04f9a29a06c9a658e379b8de0d0f5")
addappid(1933452, 1, "5e4cc6959c163ead8eed5fa6254c68f2274f9334e6fb32fac508519c27ef413c")

