-- Lua provided by RyzenAPI
-- Game: Game: Northend Tower Defense

-- MAIN APPLICATION
addappid(1669170)
-- Game: addappid(1669170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1669171, 1, "4197779dbfc812b135c213e672b0c119b0136cfcf29e84b4f1f33a7745e50e20")
addappid(1669172, 1, "22ae1972f00c9f92f3086cedfcd4653486ad70f8d2e4159ac46f03612c1e5414")
addappid(1669173, 1, "7be955cd8df783912e0dfcb9ebb5b633a58a5f6ad89d3ece0291661bfe9b4233")
addappid(1669174, 1, "793d1c14614499c18f398adeb1f9c48543956dca49c1c88486191163bfb59e53")
