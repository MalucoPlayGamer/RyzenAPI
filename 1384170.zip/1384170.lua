-- Lua provided by RyzenAPI
-- Game: 1384170

-- MAIN APPLICATION
addappid(1384170)
-- Game: addappid(1384170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384171, 1, "8436b34c9f28fec2ca5cdf9a554cac4eca56cd86f0dba0f6c9c25d487fb0fbc8")
