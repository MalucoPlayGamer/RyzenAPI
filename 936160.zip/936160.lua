-- Lua provided by RyzenAPI
-- Game: Atelier Rorona ~The Alchemist of Arland~ DX

-- MAIN APPLICATION
addappid(936160)

-- MAIN APP DEPOTS / PACKAGES
addappid(936161, 1, "4a471ce2aa22f3e54be0dbcd65ab5f16848335f5df36b795ce41e3a10dfd91d7")
