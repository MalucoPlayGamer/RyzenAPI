-- Lua provided by RyzenAPI
-- Game: Atelier Rorona ~The Alchemist of Arland~ DX

-- MAIN APPLICATION
addappid(936160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(936161, 1, "4a471ce2aa22f3e54be0dbcd65ab5f16848335f5df36b795ce41e3a10dfd91d7")

