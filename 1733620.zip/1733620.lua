-- Lua provided by RyzenAPI
-- Game: Game: Cursed Pantsu

-- MAIN APPLICATION
addappid(1733620)
-- Game: addappid(1733620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733621, 1, "8f136adfc61b0054a4b7ed0f1da17dc0d03fd0b1293424d42ca2c282ee45e0ba")
