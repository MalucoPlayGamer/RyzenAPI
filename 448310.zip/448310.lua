-- Lua provided by RyzenAPI
-- Game: Bitardia Cards: Memes of 2ch

-- MAIN APPLICATION
addappid(448310)

-- MAIN APP DEPOTS / PACKAGES
addappid(448311, 1, "385630cba37da0a6fdec8f6c652ae806199932b3d2c3897c25d9e4f2ce64e71a")
addappid(448312, 1, "e240277c355ae695d02fc8f020470e2e7f9c9fd21c449cc7823b870054c2a495")
addappid(448313, 1, "b40d664fb1eb87614db7a003c866af01f143a7936534d7a0cdb5ae0885d5e6d3")
