-- Lua provided by RyzenAPI
-- Game: Vecter

-- MAIN APPLICATION
addappid(1175140)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1219990)
