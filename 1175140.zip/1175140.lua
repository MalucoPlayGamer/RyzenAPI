-- Lua provided by RyzenAPI
-- Game: Vecter

-- MAIN APPLICATION
addappid(1175140)
addappid(1219990)

