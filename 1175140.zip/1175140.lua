-- Lua provided by RyzenAPI
-- Game: Vecter

-- MAIN APPLICATION
addappid(1175140)

