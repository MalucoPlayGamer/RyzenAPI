-- Lua provided by RyzenAPI
-- Game: Broken Arrow

-- MAIN APPLICATION
addappid(1604270)
addappid(4151720)
addappid(4232510)

-- MAIN APP DEPOTS / PACKAGES
addappid(1604270,0,"6a1d71140c5c5a62ae105124fe68479f68eb01b0bd07c51ce511632f9101ec2c")
addappid(1604271,0,"da1386311fdfb5dc5fd71357c294bbce7afd7e86bffd0588249f39807ac91d08")
addappid(1604272,0,"dec4f347ca36d0293362a8dba7e62b9d0f950872215aa4b70de99549ad402b27")
addappid(3751200,0,"7da9c745d0ff4b29d80193b0310c863c94993cf694eb5fb9c815e2a808e58e35")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
