-- Lua provided by RyzenAPI
-- Game: Game: Broken Arrow

-- MAIN APPLICATION
addappid(1604270)
-- Game: addappid(1604270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1604271, 1, "da1386311fdfb5dc5fd71357c294bbce7afd7e86bffd0588249f39807ac91d08")
addappid(1604272, 1, "dec4f347ca36d0293362a8dba7e62b9d0f950872215aa4b70de99549ad402b27")
addappid(3751200, 0, "7da9c745d0ff4b29d80193b0310c863c94993cf694eb5fb9c815e2a808e58e35")
