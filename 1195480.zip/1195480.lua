-- Lua provided by SkyAPI 
-- Game: DOOM Soundtrack
addappid(1195480)
addappid(1195481, 1, "4fb24da12d5364ad186add0a5d35d9359c625f6003f4837a917092468c698438")
