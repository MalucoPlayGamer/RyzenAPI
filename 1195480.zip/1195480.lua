-- Lua provided by RyzenAPI
-- Game: Game: DOOM Soundtrack

-- MAIN APPLICATION
addappid(1195480)
-- Game: addappid(1195480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1195481, 1, "4fb24da12d5364ad186add0a5d35d9359c625f6003f4837a917092468c698438")
