-- Lua provided by RyzenAPI
-- Game: addappid(775270)

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(775270)

-- MAIN APP DEPOTS / PACKAGES
addappid(775272,0,"08e3a017161e99667219c2f576f65bfe6550fcafaa198c4e8567aee067faac49")
