-- Lua provided by RyzenAPI
-- Game: addappid(1903810)

-- MAIN APPLICATION
addappid(1903810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1903813,0,"8874c9a87d26c90abf826cb8bc6aa52022e988686e61d6eee444d5f3aa348987")
