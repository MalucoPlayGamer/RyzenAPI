-- Lua provided by RyzenAPI
-- Game: Lu Lingqi (Dudou Costume)/呂玲綺「肚兜風コスチューム」

-- MAIN APPLICATION
addappid(892396)
-- Game: addappid(892396)

-- MAIN APP DEPOTS / PACKAGES
addappid(892396,0,"5482f5ecde1d0b051caac191bc329321d49fee4f8b06a296633a3e196d2e0aa3")
