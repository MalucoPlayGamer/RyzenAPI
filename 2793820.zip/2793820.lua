-- Lua provided by RyzenAPI
-- Game: All City King

-- MAIN APPLICATION
addappid(2793820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2793821, 1, "69dda70892e8da3ccc0735ec7a4b81d47c674818e4e914e97e67b7a7182a8e0e")

