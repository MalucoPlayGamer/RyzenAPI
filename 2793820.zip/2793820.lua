-- Lua provided by RyzenAPI
-- Game: All City King

-- MAIN APPLICATION
addappid(2793820)

-- MAIN APP DEPOTS / PACKAGES
addappid(2793821, 1, "69dda70892e8da3ccc0735ec7a4b81d47c674818e4e914e97e67b7a7182a8e0e")

