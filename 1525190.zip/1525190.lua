-- Lua provided by RyzenAPI
-- Game: Game: AppID 1525190

-- MAIN APPLICATION
addappid(1525190)
-- Game: addappid(1525190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1525191, 1, "0f9ea4047615da82ebf9d0e00546abb7676983a65dfdc41abb7546a253e55feb")
addappid(1525192, 1, "2e79d3b069644175b6b5ce3a9e4c135d9b52fe4da3e3105cac55ac98163bd27b")
addappid(1525194, 1, "5b85f8c24a8ddf1b0a5e4cd87878b739a2d9a0e8aa9789101965e02795ecfb30")
