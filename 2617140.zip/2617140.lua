-- Lua provided by RyzenAPI
-- Game: Divinity Hunting

-- MAIN APPLICATION
addappid(2617140)
-- Game: addappid(2617140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2617141, 1, "e5fd8ce9f82de152f63b508f6f61b354e53053c2c977239f710a02fe7ac7f60d")
