-- Lua provided by RyzenAPI
-- Game: 789000

-- MAIN APPLICATION
addappid(789000)
-- Game: addappid(789000)

-- MAIN APP DEPOTS / PACKAGES
addappid(789001, 1, "6ef75ab2c7470de51a3455b9bcb0ed16ea56a2ff2fa507cc4cf8c339ee5762ae")
