-- Lua provided by RyzenAPI
-- Game: New Joe & Mac - Caveman Ninja

-- MAIN APPLICATION
addappid(1492320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1492321, 1, "6596c3f2141f55b649dea3d05760bffb7668355ae0e44cb7ea59bf92f1b3e3b7")

