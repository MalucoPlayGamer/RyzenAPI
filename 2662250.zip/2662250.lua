-- Lua provided by SkyAPI 
-- Game: Detective Super Star Demo
addappid(2662250)
addappid(2662251, 1, "2107f85291ebfdf476d8c89efc218415bd5a3d030953b072dd50f98783cad156")
