-- Lua provided by RyzenAPI
-- Game: Detective Super Star Demo

-- MAIN APPLICATION
addappid(2662250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2662251, 1, "2107f85291ebfdf476d8c89efc218415bd5a3d030953b072dd50f98783cad156")
