-- Lua provided by RyzenAPI
-- Game: 282030

-- MAIN APPLICATION
addappid(282030)
-- Game: addappid(282030)

-- MAIN APP DEPOTS / PACKAGES
addappid(282031, 1, "53219d26641e0dacc730785f87427afe66f60ea094be7aa4c97895740ef679ec")
