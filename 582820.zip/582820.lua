-- Lua provided by RyzenAPI
-- Game: Game: AppID 582820

-- MAIN APPLICATION
addappid(582820)
-- Game: addappid(582820)

-- MAIN APP DEPOTS / PACKAGES
addappid(582821, 1, "df6a721340d3d3cdd328e803fa9b26425f8d63230a0c6f504fe982669bd516a7")
