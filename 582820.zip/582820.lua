-- Lua provided by SkyAPI 
-- Game: AppID 582820
addappid(582820)
addappid(582821, 1, "df6a721340d3d3cdd328e803fa9b26425f8d63230a0c6f504fe982669bd516a7")
