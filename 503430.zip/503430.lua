-- Lua provided by RyzenAPI
-- Game: 503430

-- MAIN APPLICATION
addappid(503430)
-- Game: addappid(503430)

-- MAIN APP DEPOTS / PACKAGES
addappid(503431, 1, "f36b4254818c96fec82795024e093484674f286c33ad9379b8fa21010ea1be6b")
