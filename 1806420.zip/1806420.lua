-- Lua provided by RyzenAPI
-- Game: Do U Copy?

-- MAIN APPLICATION
addappid(1806420)
-- Game: addappid(1806420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1806429,0,"53f1435e5e58ae4d651c46d5d7f6a0752356c7ae99745ce7324143f82d4edda0")
