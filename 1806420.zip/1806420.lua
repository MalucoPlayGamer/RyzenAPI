-- Lua provided by RyzenAPI
-- Game: Do U Copy?

-- MAIN APPLICATION
addappid(1806420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1806429,0,"53f1435e5e58ae4d651c46d5d7f6a0752356c7ae99745ce7324143f82d4edda0")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
