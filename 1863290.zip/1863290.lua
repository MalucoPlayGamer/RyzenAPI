-- Lua provided by RyzenAPI
-- Game: addappid(1863290)

-- MAIN APPLICATION
addappid(1863290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863292,0,"4bd38efc92c05bf066c4a12452acdc8cf858d881f29cd0417fb8332b57e20406")
