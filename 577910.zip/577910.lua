-- Lua provided by RyzenAPI
-- Game: Game: Ghost Blade HD

-- MAIN APPLICATION
addappid(577910)
-- Game: addappid(577910)

-- MAIN APP DEPOTS / PACKAGES
addappid(577911, 1, "0efc90ca69e7a26eca58b98dcd657ea9d5672b35fcd4408a511ad6b2d4a47fdb")
