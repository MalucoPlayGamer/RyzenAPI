-- Lua provided by SkyAPI 
-- Game: Ghost Blade HD
addappid(577910)
addappid(577911, 1, "0efc90ca69e7a26eca58b98dcd657ea9d5672b35fcd4408a511ad6b2d4a47fdb")
