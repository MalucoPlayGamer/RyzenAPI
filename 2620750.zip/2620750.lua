-- Lua provided by RyzenAPI
-- Game: Incredible Dracula: Dark Carnival

-- MAIN APPLICATION
addappid(2620750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2620751, 1, "3d2b5d3652bd3c0f272392756b5971b60dc4f702e99b19527e0081a3c3dd5dd5")

