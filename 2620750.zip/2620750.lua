-- Lua provided by SkyAPI 
-- Game: Incredible Dracula: Dark Carnival
addappid(2620750)
addappid(2620751, 1, "3d2b5d3652bd3c0f272392756b5971b60dc4f702e99b19527e0081a3c3dd5dd5")
