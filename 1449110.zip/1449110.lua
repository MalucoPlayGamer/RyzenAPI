-- Lua provided by RyzenAPI
-- Game: addappid(1449110)

-- MAIN APPLICATION
addappid(1449110)
addappid(3729910)
addappid(3938110)
addappid(4055350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1449111, 1, "1691760a5a08bde773f0880b6741283070c2c3931c41a09cab6682e29171c563")
