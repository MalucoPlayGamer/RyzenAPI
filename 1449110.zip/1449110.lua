-- Lua provided by RyzenAPI
-- Game: The Outer Worlds 2

-- MAIN APPLICATION
addappid(1449110)
addappid(3729850)
addappid(3729860)
addappid(3729880)
addappid(3729910)
addappid(3938110)
addappid(4055350)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1449111, 1, "1691760a5a08bde773f0880b6741283070c2c3931c41a09cab6682e29171c563")

