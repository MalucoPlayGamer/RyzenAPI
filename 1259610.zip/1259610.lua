-- Lua provided by RyzenAPI
-- Game: addappid(1259610)

-- MAIN APPLICATION
addappid(1259610)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259611, 1, "d584cb8c211b662215d4247f031be078a9edf4bd6e07ad42583a9c3663aed212")
