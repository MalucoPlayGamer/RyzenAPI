-- Lua provided by RyzenAPI
-- Game: Virus Buster

-- MAIN APPLICATION
addappid(1259610)
addappid(1262130)
addappid(1301490)

-- MAIN APP DEPOTS / PACKAGES
addappid(1259611, 1, "d584cb8c211b662215d4247f031be078a9edf4bd6e07ad42583a9c3663aed212")

