-- Lua provided by RyzenAPI
-- Game: 724970

-- MAIN APPLICATION
addappid(228985)
addappid(228986)
addappid(228990)
addappid(724970)
-- Game: addappid(724970)

-- MAIN APP DEPOTS / PACKAGES
addappid(724972,0,"cf46c30f82f465317a0f0a2968a2e488c659f0362e9d4f75754a62d899ca510a")
addappid(724973,0,"890cac5eb2d41a03d5d1c0125cdab7e094617598fb061cf051b28842f77e4eae")
addappid(724974,0,"d0d23caad120c2378acf7a42c89ab1c58b41442bba25c86f73efb0d255bcf147")
