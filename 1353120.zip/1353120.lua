-- Lua provided by RyzenAPI
-- Game: ココロクローバー パート１/Kokoro Clover Part1

-- MAIN APPLICATION
addappid(1353120)
-- Game: addappid(1353120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1353121, 1, "b3a7092f58f5693e7a9c21e85d9d963547f62d308c40a1d986ac4ce5070b1271")
