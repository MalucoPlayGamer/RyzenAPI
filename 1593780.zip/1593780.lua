-- Lua provided by RyzenAPI
-- Game: Game: Organs Please

-- MAIN APPLICATION
addappid(1593780)
-- Game: addappid(1593780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1593781, 1, "0edd3ad6efce3faa63e4ec7d0870a957b28852d0ebee522e5df09c46724de146")
