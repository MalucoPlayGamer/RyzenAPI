-- Lua provided by RyzenAPI
-- Game: RIVE

-- MAIN APPLICATION
addappid(278100)
addappid(505250)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(278101, 1, "10d67d4a02815f0a19f3127434b1b919426caed400ea99bfb49efea456f12196")
addappid(278102, 1, "f99edb5f51683918c652d782974ccaf1a594452d48c2981103b9b246184af57f")
addappid(278103, 1, "7bdf5fe6956c502ff52f4aade6d0d023fbf3f7ccee4880469e6afedf16c7bbf5")
