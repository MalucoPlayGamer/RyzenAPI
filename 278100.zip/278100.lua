-- Lua provided by RyzenAPI
-- Game: Game: AppID 278100

-- MAIN APPLICATION
addappid(278100)
-- Game: addappid(278100)

-- MAIN APP DEPOTS / PACKAGES
addappid(278101, 1, "10d67d4a02815f0a19f3127434b1b919426caed400ea99bfb49efea456f12196")
addappid(278102, 1, "f99edb5f51683918c652d782974ccaf1a594452d48c2981103b9b246184af57f")
addappid(278103, 1, "7bdf5fe6956c502ff52f4aade6d0d023fbf3f7ccee4880469e6afedf16c7bbf5")
