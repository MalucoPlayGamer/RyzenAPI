-- Lua provided by RyzenAPI 
-- Game: Fated Souls
addappid(370780)
addappid(370781, 1, "e2bc37950d8741469fc8f89ab70bb8f562627d1279f02fe548a28bc27f907d26")
