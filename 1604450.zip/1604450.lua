-- Lua provided by RyzenAPI
-- Game: AI Battle Royale Generator

-- MAIN APPLICATION
addappid(1604450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1604451, 1, "e6ac139974a2b5387e469a3f851db380bd1b109f7d4f015fe6659ca8353f9e05")

