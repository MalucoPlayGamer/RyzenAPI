-- Lua provided by RyzenAPI
-- Game: 44670

-- MAIN APPLICATION
addappid(44670)
-- Game: addappid(44670)

-- MAIN APP DEPOTS / PACKAGES
addappid(44671, 1, "8c1c838275e6d21c212eabec805b69612bfaa454cbb92d0d9c87eb80386a10a7")
