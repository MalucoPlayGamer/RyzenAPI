-- Lua provided by RyzenAPI
-- Game: Shivering Stone

-- MAIN APPLICATION
addappid(2480180) -- Shivering Stone

-- MAIN APP DEPOTS / PACKAGES
addappid(2480181, 1, "b852acaf9f1c681e877b4e8e0cdd61c7ea1ce69257b3591fb8a2bfa4d7093540") -- Depot 2480181
