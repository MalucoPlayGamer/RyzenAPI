-- Lua provided by RyzenAPI
-- Game: Game: AppID 3252640

-- MAIN APPLICATION
addappid(3252640)
-- Game: addappid(3252640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3252641, 1, "f21c038b11571c1a072bc4d9a46f15ac59e382c092d13d844092d50700f415ad")
