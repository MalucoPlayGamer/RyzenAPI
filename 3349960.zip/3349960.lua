-- Lua provided by RyzenAPI
-- Game: okey.gg

-- MAIN APPLICATION
addappid(3349960)
-- Game: addappid(3349960)

-- MAIN APP DEPOTS / PACKAGES
addappid(3349962,0,"ea360ba19b543573b7c286c3925ce81d58ff27fd1f622a3817c8403830104bcc")
