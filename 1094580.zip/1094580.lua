-- Lua provided by RyzenAPI
-- Game: Ecio

-- MAIN APPLICATION
addappid(1094580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1094581, 1, "02490858707b41a7dafc1228e21364d78ced4f45fe9cffe86f00597b1eb1c00a")
