-- Lua provided by RyzenAPI
-- Game: Caffeine

-- MAIN APPLICATION
addappid(865770)

-- MAIN APP DEPOTS / PACKAGES
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- (windows)
addappid(865771, 1, "f0ca7f46d470a75cb8586e0d796e3909c118b9260410b9bf2cf259837ddd10ad")

