-- Lua provided by RyzenAPI
-- Game: CounterAttack: Uprising

-- MAIN APPLICATION
addappid(451600)

-- MAIN APP DEPOTS / PACKAGES
addappid(451601, 1, "fcd4ee232b1a7ad5216998fb5d14c5b10b58bdc2fcaec2dbb0eb8f36861332fa")
