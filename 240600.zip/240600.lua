-- Lua provided by RyzenAPI
-- Game: MotoGP™13

-- MAIN APPLICATION
addappid(240600)

-- MAIN APP DEPOTS / PACKAGES
addappid(240601, 1, "a0408c852c44b0476ef3eb5cf2a910e041253a7e73e41c688433fe7586a8ab4c")
addappid(240610, 1, "4e27554a0ec1ad8be78924096475b2f59dedac08c32d3347453919c0b02eb0c2")
addappid(240611, 1, "b08cc39e13cdfbc956673486bb1a640573e872c9c43d3b267d40d5aa28e22438")
addappid(240612, 1, "13bb7fc676622d7717543107b81bfa0f00db7a1d397743e28cc2337faa916897")
addappid(240613, 1, "d963b43019ef1d521853b235dd65ee2df153ad797339459fdd8f84b08384597a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
