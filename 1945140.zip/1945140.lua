-- Lua provided by RyzenAPI
-- Game: Game: AppID 1945140

-- MAIN APPLICATION
addappid(1945140)
-- Game: addappid(1945140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1945141, 1, "56c7732721fd02b27382ea9bf2481ad1be39c75621f0f5bd6260f0bd2b2bf2c0")
addappid(1945142, 1, "3b1afe88ce7bb83a421d5667c4df6cd2aa60927a9714b94987de1fb421f93db3")
