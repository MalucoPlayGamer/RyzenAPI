-- Lua provided by RyzenAPI
-- Game: Digital Artbook – Sex Arena 🖌️

-- MAIN APPLICATION
addappid(3668760)
-- Game: addappid(3668760)

-- MAIN APP DEPOTS / PACKAGES
addappid(3668760,0,"84f184304e61490990a3d766d41e0c99ab6f9d09aada14c04468b6f892079830")
