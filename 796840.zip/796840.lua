-- Lua provided by SkyAPI 
-- Game: AppID 796840
addappid(796840)
addappid(796841, 1, "7b7d10d8b95731fd745cf9631ec8cdd41cac016525f71453422d51c0742cf274")
