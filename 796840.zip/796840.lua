-- Lua provided by RyzenAPI
-- Game: addappid(796840)

-- MAIN APPLICATION
addappid(796840)

-- MAIN APP DEPOTS / PACKAGES
addappid(796841, 1, "7b7d10d8b95731fd745cf9631ec8cdd41cac016525f71453422d51c0742cf274")
