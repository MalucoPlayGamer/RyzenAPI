-- Lua provided by RyzenAPI
-- Game: Back 4 Boobs: Sakura's Escape

-- MAIN APPLICATION
addappid(1744670)
-- Game: addappid(1744670)

-- MAIN APP DEPOTS / PACKAGES
addappid(1744671, 1, "0653191c2342bdc5870a20945ee022159893208787010178bd4cd9acd8c2ce9d")
