-- Lua provided by RyzenAPI
-- Game: Game: AppID 2866120

-- MAIN APPLICATION
addappid(2866120)
-- Game: addappid(2866120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2866121, 1, "3970a05ec3833e9e8e9cf8587c3215da421e2a522af1008fe8358900f565b0c9")
