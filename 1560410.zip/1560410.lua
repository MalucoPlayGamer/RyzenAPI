-- Lua provided by RyzenAPI
-- Game: addappid(1560410)

-- MAIN APPLICATION
addappid(1560410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1560411, 1, "c76d535af2dc2877406d2da8a790169979e0c845e661a1a6c24cf058764ea0c2")
