-- Lua provided by RyzenAPI 
-- Game: Magic: The Gathering - Duels of the Planeswalkers 2012
addappid(49470)
addappid(49471, 1, "ff302281f367a97424afa7d2e15133b2675b973eb191403755a59a3e5d0e2584")
addappid(97328, 0, "634566b580450b41aa9c6bf2979aa9b7ad8726b72df16858efe0e018eb83e124")
