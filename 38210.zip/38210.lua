-- Lua provided by RyzenAPI
-- Game: 38210

-- MAIN APPLICATION
addappid(38210)
-- Game: addappid(38210)

-- MAIN APP DEPOTS / PACKAGES
addappid(38211, 1, "ce17f5faf814d73eef344ba98cd30811471a097a53ce31df09e805375111b175")
