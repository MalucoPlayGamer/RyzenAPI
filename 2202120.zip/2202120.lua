-- Lua provided by RyzenAPI
-- Game: addappid(2202120)

-- MAIN APPLICATION
addappid(2202120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202121, 1, "c9c834b2a7255f30c40f439d38bb573d51079ed529bed183bc183978ca35411b")
