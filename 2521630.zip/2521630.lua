-- Lua provided by RyzenAPI
-- Game: Mini Settlers

-- MAIN APPLICATION
addappid(2521630)

-- MAIN APP DEPOTS / PACKAGES
addappid(2521631, 1, "d06bb3d739ba94610c96828ed1642365fa3dfbefbd811f058750a5a33d22c706")

