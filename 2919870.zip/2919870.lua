-- Lua provided by RyzenAPI
-- Game: Lost Dreams

-- MAIN APPLICATION
addappid(2919870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2919871, 1, "bb6093ce5f0fced4665d4c857381aae331e2f7b3912551ccdb27caa509b4118c")
