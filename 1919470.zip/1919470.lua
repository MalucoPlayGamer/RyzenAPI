-- Lua provided by RyzenAPI
-- Game: Atari 50: The Anniversary Celebration

-- MAIN APPLICATION
addappid(1919470)
-- Game: addappid(1919470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1919471, 1, "8f6c607ac280538dbe077f205c4d666dd808710c0b888bf9989b138cdfcd727f")
addappid(2775650, 0, "16897101360c7fdea484656a398ffbc7925cdfa7955b3a5d7ffd593666d0253b")
addappid(3101170, 0, "cdb0cd0405566d882b015304443203a076a23118b17b35cc6ebac7431a56e7ff")
