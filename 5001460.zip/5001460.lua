-- 5001460's Lua and Manifest Created by Hubcap Manifest
-- Moros
-- Created: August 12, 2026 at 01:14:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5001460) -- Moros
-- MAIN APP DEPOTS
addappid(5001461, 1, "474c31787853bc0b0be8e5cfdab73ca0b4238204ce4a1b6132bc14ecf6a1b714") -- Depot 5001461
setManifestid(5001461, "6259653449860746437", 297522131)