-- Lua provided by RyzenAPI
-- Game: Moros

-- MAIN APPLICATION
addappid(5001460) -- Moros

-- MAIN APP DEPOTS / PACKAGES
addappid(5001461, 1, "474c31787853bc0b0be8e5cfdab73ca0b4238204ce4a1b6132bc14ecf6a1b714") -- Depot 5001461

