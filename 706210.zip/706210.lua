-- Lua provided by RyzenAPI
-- Game: Haul Asteroid

-- MAIN APPLICATION
addappid(706210)

-- MAIN APP DEPOTS / PACKAGES
addappid(706211, 1, "90289dbe4d081343fd1f94b3d54d31a31a73ab75c1fd88c8506021e8adda2d6a")
