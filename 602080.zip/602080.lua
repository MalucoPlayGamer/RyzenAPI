-- Lua provided by RyzenAPI
-- Game: Solaroids

-- MAIN APPLICATION
addappid(602080)

-- MAIN APP DEPOTS / PACKAGES
addappid(602081,0,"0e87270d4dcd76ae9c5dbcb7a719270bcc031528d2a52bdb98188f2f28898ffb")
addappid(602082,0,"6a12510f085ac33eff12fbe10659786e4c626f974529653ea077a7baedcbf57e")

