-- Lua provided by RyzenAPI
-- Game: Solaroids

-- MAIN APPLICATION
addappid(602080)

-- MAIN APP DEPOTS / PACKAGES
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(602081,0,"0e87270d4dcd76ae9c5dbcb7a719270bcc031528d2a52bdb98188f2f28898ffb")
addappid(602082,0,"6a12510f085ac33eff12fbe10659786e4c626f974529653ea077a7baedcbf57e")

