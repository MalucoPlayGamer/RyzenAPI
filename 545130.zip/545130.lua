-- Lua provided by SkyAPI 
-- Game: AppID 545130
addappid(545130)
addappid(545131, 1, "1550919fa7478e08c94ea435f587bcfe3cb867675d4aa9df0f33b4681d08a6a4")
