-- Lua provided by RyzenAPI
-- Game: Game: AppID 545130

-- MAIN APPLICATION
addappid(545130)
-- Game: addappid(545130)

-- MAIN APP DEPOTS / PACKAGES
addappid(545131, 1, "1550919fa7478e08c94ea435f587bcfe3cb867675d4aa9df0f33b4681d08a6a4")
