-- Lua provided by RyzenAPI
-- Game: My name is You and it's the only unusual thing in my life

-- MAIN APPLICATION
addappid(1118840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1118841, 1, "e4fdbf680b355f9cca03258a0e1948a4c10c0e251d285f27f191244c423fed79")

