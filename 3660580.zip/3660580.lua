-- Lua provided by RyzenAPI
-- Game: Royal Vermin

-- MAIN APPLICATION
addappid(3660580)
addappid(3930560)

