-- Lua provided by RyzenAPI
-- Game: Royal Vermin

-- MAIN APPLICATION
addappid(3660580)

