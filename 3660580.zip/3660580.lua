-- Lua provided by RyzenAPI
-- Game: Royal Vermin

-- MAIN APPLICATION
addappid(3660580)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3930560)
