-- Lua provided by SkyAPI 
-- Game: Devious Path
addappid(2972350)
addappid(2972351, 1, "b8e1681b17f5187cccb83d6c4b16b447eef586b189f32da29e7e5b1dbef2860e")
