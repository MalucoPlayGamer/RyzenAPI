-- Lua provided by RyzenAPI
-- Game: Devious Path

-- MAIN APPLICATION
addappid(2972350)
-- Game: addappid(2972350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2972351, 1, "b8e1681b17f5187cccb83d6c4b16b447eef586b189f32da29e7e5b1dbef2860e")
