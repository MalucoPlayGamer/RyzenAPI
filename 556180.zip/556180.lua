-- Lua provided by RyzenAPI
-- Game: Mysterium

-- MAIN APPLICATION
addappid(556180)
addappid(563300)
addappid(563780)

-- MAIN APP DEPOTS / PACKAGES
addappid(556181, 1, "726541ff60ed07dfcbbb396e5dcbd084fe868a94842aa88cb1312dbb39358d8b")

