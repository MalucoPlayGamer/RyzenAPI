-- Lua provided by RyzenAPI
-- Game: Game: Heart'n Block

-- MAIN APPLICATION
addappid(869630)
-- Game: addappid(869630)

-- MAIN APP DEPOTS / PACKAGES
addappid(869631, 1, "2b56929e58d9efaffe249b56e3e089fc95c9c1f08bfc39e3bbee77e1601e28c9")
addappid(869632, 1, "4e989ba0c0a99bc279b11e9850b0856e702a03dd49e7d0d12cb973c073267e1f")
