-- Lua provided by SkyAPI 
-- Game: Heart'n Block
addappid(869630)
addappid(869631, 1, "2b56929e58d9efaffe249b56e3e089fc95c9c1f08bfc39e3bbee77e1601e28c9")
addappid(869632, 1, "4e989ba0c0a99bc279b11e9850b0856e702a03dd49e7d0d12cb973c073267e1f")
