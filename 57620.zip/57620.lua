-- Lua provided by RyzenAPI 
-- Game: Patrician IV
addappid(57620)
addappid(57621, 1, "807847b9b9a7a5d6f6fb1ba495ff8fdabdfcad9f50c5d14b241fd6e3199ad784")
addappid(57622, 1, "499317e7e3e8e8f738dfce55d332c95d70537f53be3fb13e8da6ae5df5bc612a")
addappid(57623, 1, "57ccdb053cc16af1d01412879015beb0a40e5407d30d217474cfa33a7b2d0cb3")
addappid(57730)
