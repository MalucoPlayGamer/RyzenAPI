-- Lua provided by RyzenAPI
-- Game: addappid(542880)

-- MAIN APPLICATION
addappid(542880)

-- MAIN APP DEPOTS / PACKAGES
addappid(542881, 1, "22028e117802f4c4706fa2addcb8e5aacc684fdd1be2da47f5b30eb4dd0bd213")
