-- Lua provided by SkyAPI 
-- Game: kHED
addappid(976330)
addappid(976331, 1, "fd9e7d3064dfdd01eaf3ae6a9032419ba7b552de6f9bb98c68084e73b3c556e3")
