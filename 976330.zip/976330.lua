-- Lua provided by RyzenAPI
-- Game: kHED

-- MAIN APPLICATION
addappid(976330)

-- MAIN APP DEPOTS / PACKAGES
addappid(976331, 1, "fd9e7d3064dfdd01eaf3ae6a9032419ba7b552de6f9bb98c68084e73b3c556e3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
