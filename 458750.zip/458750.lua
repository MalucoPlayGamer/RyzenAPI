-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(458750)
addappid(458751)
addappid(458753)
addappid(458754)
addappid(458755)

-- MAIN APP DEPOTS / PACKAGES
addappid(458752,0,"1722e1ea688d999f0ca032f5cd9bf41c77528acafcb7269809ed8db4bb2888d6")
