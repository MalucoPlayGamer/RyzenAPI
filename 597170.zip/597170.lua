-- Lua provided by RyzenAPI
-- Game: Clone Drone in the Danger Zone

-- MAIN APPLICATION
addappid(597170)
addappid(4824790)
addappid(4833350)
addappid(4833360)

-- MAIN APP DEPOTS / PACKAGES
addappid(597170,0,"854dbedc56dd80e20fd91e8dd77eb2928d7d24c8acfbf2e009544ef6195901e5")
addappid(597171,0,"54a12fbbe95ba3b3a1ce8580f41e3d3b36b0e88b0780b2a9377f9b8768eb3bd2")
addappid(597172,0,"9b6d15086bc7fcc9f9663e9ddcb98328595627032d3c906a333f9b86ae97ac15")

