-- Lua provided by SkyAPI 
-- Game: Arcanists
addappid(2901550)
addappid(2901551, 1, "12bf8c93772cac311a78f6c6268b15590e1a6feab654d5df0db488ffa92eb53f")
addappid(2901552, 1, "128e14d1804d8fab5d7472267c7469f51b6922372bdc9847e76ab41db04da0e6")
addappid(2901553, 1, "13a014f367d59819d02f7fdba1cef99bc5cdc85cd0df6a62ba9ea5307e7c9eb5")
