-- Lua provided by RyzenAPI
-- Game: Gunhouse

-- MAIN APPLICATION
addappid(704110)

-- MAIN APP DEPOTS / PACKAGES
addappid(704111,0,"4600dec686dc4312016d85381f2de82df5d505fed6ef2cfe574bfbe3cb3257b1")

