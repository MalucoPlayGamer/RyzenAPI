-- Lua provided by RyzenAPI
-- Game: Armored War

-- MAIN APPLICATION
addappid(1631530)
-- Game: addappid(1631530)

-- MAIN APP DEPOTS / PACKAGES
addappid(1631531, 1, "0bc438e5d8b452d319e1688a2b11d1cf204265e05dbe87e6e70f6ff13497bb6e")
