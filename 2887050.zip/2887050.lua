-- Lua provided by RyzenAPI
-- Game: addappid(2887050)

-- MAIN APPLICATION
addappid(2887050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2887051, 1, "619dfe46f900ed90ded83d40460b2ae3946d60a48ca82dc26ebb3d747c745ffe")
