-- Lua provided by RyzenAPI
-- Game: AppID 712080

-- MAIN APPLICATION
addappid(712080)
-- Game: addappid(712080)

-- MAIN APP DEPOTS / PACKAGES
addappid(712081, 1, "925b16555c2515a700984c56bc7e2e5a7671404a5325e52ad1f19ebb16b7641d")
