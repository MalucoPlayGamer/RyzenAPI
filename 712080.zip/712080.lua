-- Lua provided by RyzenAPI
-- Game: 7 Bones and 7 Stones - The Ritual

-- MAIN APPLICATION
addappid(712080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(712081, 1, "925b16555c2515a700984c56bc7e2e5a7671404a5325e52ad1f19ebb16b7641d")
