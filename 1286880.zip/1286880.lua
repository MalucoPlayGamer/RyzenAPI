-- Lua provided by RyzenAPI
-- Game: Ship Graveyard Simulator

-- MAIN APPLICATION
addappid(1286880)
addappid(1918190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286881, 1, "73fbc4ec2441db925364ee7921204361cfb62431d36dcc0bfa9bbb50267aea2d")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
