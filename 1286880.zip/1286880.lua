-- Lua provided by RyzenAPI
-- Game: addappid(1286880)

-- MAIN APPLICATION
addappid(1286880)
addappid(1918190)

-- MAIN APP DEPOTS / PACKAGES
addappid(1286881, 1, "73fbc4ec2441db925364ee7921204361cfb62431d36dcc0bfa9bbb50267aea2d")
