-- Lua provided by RyzenAPI
-- Game: AppID 583010

-- MAIN APPLICATION
addappid(583010)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(583011, 1, "4527069accc1cb6aae5f2b3e32203a8061a137783f7aa136db6a9c558dd49410")

