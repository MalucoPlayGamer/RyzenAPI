-- Lua provided by RyzenAPI
-- Game: 583010

-- MAIN APPLICATION
addappid(583010)
-- Game: addappid(583010)

-- MAIN APP DEPOTS / PACKAGES
addappid(583011, 1, "4527069accc1cb6aae5f2b3e32203a8061a137783f7aa136db6a9c558dd49410")
