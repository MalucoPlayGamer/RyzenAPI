-- Lua provided by RyzenAPI
-- Game: Hentai Halloween

-- MAIN APPLICATION
addappid(1171440)
addappid(1180180)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171441, 1, "66406f6fa078daeda9197345cc81b9243f052daca7d71c09ea69a585787d12f5")

