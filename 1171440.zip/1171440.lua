-- Lua provided by RyzenAPI
-- Game: AppID 1171440

-- MAIN APPLICATION
addappid(1171440)

-- MAIN APP DEPOTS / PACKAGES
addappid(1171441, 1, "66406f6fa078daeda9197345cc81b9243f052daca7d71c09ea69a585787d12f5")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1180180)
