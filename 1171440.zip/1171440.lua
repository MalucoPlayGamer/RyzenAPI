-- Lua provided by SkyAPI 
-- Game: AppID 1171440
addappid(1171440)
addappid(1171441, 1, "66406f6fa078daeda9197345cc81b9243f052daca7d71c09ea69a585787d12f5")
