-- Lua provided by RyzenAPI
-- Game: Demeo

-- MAIN APPLICATION
addappid(1484280)
-- Game: addappid(1484280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1484281, 1, "aaa814ad1a235312ae0274245cf6cd361dc8c3e7dda76ea0f4a3d19ae1937fcc")
