-- Lua provided by RyzenAPI
-- Game: Game: Scary School Simulator 2

-- MAIN APPLICATION
addappid(2667850)
-- Game: addappid(2667850)

-- MAIN APP DEPOTS / PACKAGES
addappid(2667851, 1, "e395580599a232556ced73e40d09be27f042592c10a2a3a9c498f4b1105a1a77")
addappid(2667852, 1, "f2a8b18a80cfc969877da515d6d728014ad6bbf6dfc3b5cc682aaba0defcc185")
addappid(2667853, 1, "dbc10be4d726d9b3d75ed34d19fc62a3d3f30328fcd9f1f9bb03e18d5181be1c")
