-- Lua provided by RyzenAPI
-- Game: Race Arcade

-- MAIN APPLICATION
addappid(355010)
addappid(606090)

-- MAIN APP DEPOTS / PACKAGES
addappid(355011, 1, "ce300700599974d088ce964f2f92dd27cbe1f6c68e633175812a68d6597ab3cc")
addappid(355012, 1, "e0ddc9b688f0094bbde8436ff8eb5918956c8168d424e3736a636c19c0f4c56f")
addappid(355013, 1, "cf3b2fd6e3f9261bdb87a9549816b9f883a139b98d476b1989d04e7f526aeefa")

