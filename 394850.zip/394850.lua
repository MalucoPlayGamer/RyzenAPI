-- Lua provided by RyzenAPI
-- Game: Square Brawl

-- MAIN APPLICATION
addappid(394850)
addappid(394855)
addappid(394856)

-- MAIN APP DEPOTS / PACKAGES
addappid(394854,0,"bb44730535258c07412ac35cc0a8ea87b7fbb99c855bd93e30cf416048123ad6")
