-- Lua provided by RyzenAPI
-- Game: Game: The Dwarves

-- MAIN APPLICATION
addappid(403970)
-- Game: addappid(403970)

-- MAIN APP DEPOTS / PACKAGES
addappid(403971, 1, "d9cfcadcc0c06ca497e0924965af1412930b34a757c98739250b4891b11589c2")
addappid(403972, 1, "2bd1a96c791aa1500e7240fd839c7fd2f4aa994254485160dd66223cad89aef8")
addappid(403973, 1, "c3c3d912e9189335f6d792e7978a68b54bbe0ed774ca6d75f187c141ef70d214")
addappid(545070, 0, "2a2c46cba0d595ffe6c375bf82836a7e3b1675dbc9cc4a7a0877188bc9ec9011")
