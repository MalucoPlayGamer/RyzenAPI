-- Lua provided by RyzenAPI 
-- Game: Backrooms Bodycam 2
addappid(3775610)
addappid(3775611, 1, "ba6221a766d7302933911e077f971387965442ff603ec7e4dc5d738a5376aa69")
