-- Lua provided by SkyAPI 
-- Game: GIBZ
addappid(448320)
addappid(448321, 1, "f184e978a0d280287193806924dd33e4aa8474a91c8001c5456f093662917fe7")
