-- Lua provided by RyzenAPI
-- Game: Horror Ville Maze Escape

-- MAIN APPLICATION
addappid(1088800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1088801, 1, "43f53e857752a2956dfa02168fc853e8b4e5f848579d813a1f3f50d312accfe4")
