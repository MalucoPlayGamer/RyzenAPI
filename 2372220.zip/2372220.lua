-- Lua provided by RyzenAPI
-- Game: Wonderway

-- MAIN APPLICATION
addappid(2372220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2372221, 1, "de843425201db49f4291e88d90b05d389683f6920c0febeb19fa90071d7dd93c")

