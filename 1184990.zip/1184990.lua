-- Lua provided by RyzenAPI 
-- Game: AppID 1184990
addappid(1184990)
addappid(1184991, 1, "5eaddf1273bf12187d0a6cd50e6898af63ed812cc72ef6fc85da775c4f477741")
addappid(1324670, 0, "2c07e226e2ea4d381407b7a28525c75ead8bac6ae0478826ecccc9046c4a3af0")
