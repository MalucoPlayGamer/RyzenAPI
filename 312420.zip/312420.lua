-- Lua provided by RyzenAPI 
-- Game: AppID 312420
addappid(312420)
addappid(312421, 1, "ec4eaa6da56b6c1ee8e979e60b13d5eb4849cae270f1d25cfad29406d484d538")
