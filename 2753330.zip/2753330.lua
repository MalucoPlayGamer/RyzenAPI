-- Lua provided by RyzenAPI 
-- Game: Hardcore Cottagecore
addappid(2753330)
addappid(2753331, 1, "0d0326f4e02364b3c10afb0509c07f7c51645775b5ef188a1f61ad6825459382")
