-- Lua provided by RyzenAPI
-- Game: Apsulov: End of Gods

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(960980)

-- MAIN APP DEPOTS / PACKAGES
addappid(960982,0,"2545ac34f017be3a01bd4a4923dd0a0f0f95303642cc039446eba2d1da8826cf")
addappid(1129530,0,"b702a0db89bab8bda343b7be22555a2af03fac7bce0a620dbdb2190299fd199e")

