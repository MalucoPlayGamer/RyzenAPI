-- Lua provided by RyzenAPI
-- Game: Swish Ball Clicker

-- MAIN APPLICATION
addappid(4686000) -- Swish Ball Clicker

-- MAIN APP DEPOTS / PACKAGES
addappid(4686002, 1, "03aa4a80546b3d2ad505b11cee8511ce2f3ddff8e1ead5fc8cf87bdefc2edba6") -- Depot 4686002
addappid(4686003, 1, "f9edb84c36012c5de46c6bcffa5af6d44568bb6fafd5ae5c1dd13f6b0ff6ca37") -- Depot 4686003
addappid(4686004, 1, "80ce512a52a45d47fecda7dc7a10f8fb98fde4c9dba0c7ecf503f536af33b9f9") -- Depot 4686004

