-- Lua provided by RyzenAPI
-- Game: addappid(684590)

-- MAIN APPLICATION
addappid(684590)

-- MAIN APP DEPOTS / PACKAGES
addappid(684591, 1, "3f8c9c4eeea6b610a6598af2c5fe39f1fe20057bcf3763778a8548fc89026d65")
