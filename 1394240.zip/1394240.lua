-- Lua provided by RyzenAPI
-- Game: addappid(1394240)

-- MAIN APPLICATION
addappid(1394240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1394241, 1, "77233a162a1de91eb6fb6d53fd3e7c10a92ab8b89249061dc2a668898aa9de61")
