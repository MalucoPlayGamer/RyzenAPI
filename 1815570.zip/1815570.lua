-- Lua provided by RyzenAPI
-- Game: Aces & Adventures

-- MAIN APPLICATION
addappid(1815570)
addappid(2367830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1815571, 1, "43854fc9588850153502e013601fdefd703cf3fb451479d2985d9a6be5594150")
