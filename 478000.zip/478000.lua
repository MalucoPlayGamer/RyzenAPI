-- Lua provided by SkyAPI 
-- Game: AppID 478000
addappid(478000)
addappid(478001, 1, "cae8fc8f749fb6af284041667f6de02ce1aaad3aae1ff88aafb55da11f3b2faa")
