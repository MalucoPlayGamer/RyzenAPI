-- Lua provided by RyzenAPI
-- Game: Age of Conan: Unchained

-- MAIN APPLICATION
addappid(217750)
addappid(217760)
addappid(268600)
addappid(489750)
addappid(530690)

-- MAIN APP DEPOTS / PACKAGES
addappid(217751, 1, "6624da2ecd8bb60ef0dceb8ca085fd2c32bbd515f67300362e34c24ab61f6dd9")
