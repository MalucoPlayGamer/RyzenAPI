-- Lua provided by RyzenAPI
-- Game: Cute BAR

-- MAIN APPLICATION
addappid(1844300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844301, 1, "90d1f749a703c70f609d541078686e45d94e1dbc98cba274569330ceda68de73")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1858520)
