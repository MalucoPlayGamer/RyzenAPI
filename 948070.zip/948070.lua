-- Lua provided by RyzenAPI
-- Game: SNUSE 221

-- MAIN APPLICATION
addappid(948070)
-- Game: addappid(948070)

-- MAIN APP DEPOTS / PACKAGES
addappid(948071, 1, "d575dd1c8935185017e21580c7a13bbeb2ac888677686f67eca0de3553571d1b")
