-- Lua provided by RyzenAPI
-- Game: SNUSE 221

-- MAIN APPLICATION
addappid(948070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(948071, 1, "d575dd1c8935185017e21580c7a13bbeb2ac888677686f67eca0de3553571d1b")

