-- Lua provided by RyzenAPI
-- Game: Artisan Story

-- MAIN APPLICATION
addappid(2505510)

-- MAIN APP DEPOTS / PACKAGES
addappid(2505511, 1, "29e3fb708d9308f3eaaf2fe90dbd7d57f95a1c1d551b0cce777e049c6ff2a8bc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
