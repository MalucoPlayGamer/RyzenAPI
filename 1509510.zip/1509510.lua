-- Lua provided by RyzenAPI
-- Game: Settlement Survival

-- MAIN APPLICATION
addappid(1509510)
addappid(2511170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1509511, 1, "4cfe3bbdd4ed5b7dbf16087fd86db74a2d9785e8aa6d9c4eddf97491e07fcccc")
addappid(1509512, 1, "b05aebb75ce0f1104d8027e154dffc676282f24baf9cce3c40442f95ac386fd7")
addappid(2511171, 0, "43e1ddb9238aac3dda7bea00ade97207a371a449dad6786de1384df6486229d1")
