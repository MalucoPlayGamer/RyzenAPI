-- Lua provided by SkyAPI 
-- Game: AppID 867700
addappid(867700)
addappid(867701, 1, "58d603d1259cdbf28ce93b063157edefba3201e1e4ad8790798b52dbca879b95")
addappid(868680)
addappid(1023670)
addappid(1145930)
