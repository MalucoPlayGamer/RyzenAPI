-- Lua provided by RyzenAPI
-- Game: Bioguard

-- MAIN APPLICATION
addappid(2669910)

-- MAIN APP DEPOTS / PACKAGES
addappid(2669911,0,"9e1bc21c04626b9ea99f2a0a36857a51a0e869e76852cb44b501a976676a72a9")

