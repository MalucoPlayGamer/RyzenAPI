-- Lua provided by RyzenAPI
-- Game: Game: Dream of Light

-- MAIN APPLICATION
addappid(1758930)
-- Game: addappid(1758930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1758931, 1, "2bedf6484ff90171c9ce3094f2adfa621cb8f7755473720e24d6f57d4981e429")
