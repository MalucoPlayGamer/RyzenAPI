-- Lua provided by SkyAPI 
-- Game: Keiko-san (47) my co-worker, is a single mother
addappid(1834420)
addappid(1834421, 1, "2febcb1c576bdcf577735e61e8654a18ebf734d8e7a535d37b0b8bd461cd9b79")
