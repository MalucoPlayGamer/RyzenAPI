-- Lua provided by RyzenAPI
-- Game: addappid(1834420)

-- MAIN APPLICATION
addappid(1834420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1834421, 1, "2febcb1c576bdcf577735e61e8654a18ebf734d8e7a535d37b0b8bd461cd9b79")
