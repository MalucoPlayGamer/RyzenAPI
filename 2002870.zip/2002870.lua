-- Lua provided by RyzenAPI
-- Game: AppID 2002870

-- MAIN APPLICATION
addappid(2002870)
addappid(2517650)
addappid(2517830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(2002871, 1, "73ad6e97d50a47a9863bd2da733bbbc7b712458d440b0b9c95fa96bc7a55987c")

