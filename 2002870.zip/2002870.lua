-- Lua provided by RyzenAPI 
-- Game: AppID 2002870
addappid(2002870)
addappid(2002871, 1, "73ad6e97d50a47a9863bd2da733bbbc7b712458d440b0b9c95fa96bc7a55987c")
