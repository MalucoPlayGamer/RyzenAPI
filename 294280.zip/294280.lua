-- Lua provided by RyzenAPI
-- Game: 294280

-- MAIN APPLICATION
addappid(294280)
-- Game: addappid(294280)

-- MAIN APP DEPOTS / PACKAGES
addappid(294281, 1, "9ca70bfc116e312a14152e9d7c0e36e89ab067963c1591f6351d282b295fe11d")
