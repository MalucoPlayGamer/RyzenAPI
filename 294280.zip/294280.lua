-- Lua provided by RyzenAPI
-- Game: Scooby Doo! & Looney Tunes Cartoon Universe: Adventure

-- MAIN APPLICATION
addappid(294280)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(294281, 1, "9ca70bfc116e312a14152e9d7c0e36e89ab067963c1591f6351d282b295fe11d")

