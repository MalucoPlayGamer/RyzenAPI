-- Lua provided by RyzenAPI
-- Game: Kamikaze Lassplanes Demo

-- MAIN APPLICATION
addappid(2779250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2779251, 1, "0b1151484a307531afb664fbb8c39438093cea4399e9c52437671d7bcd63f491")
