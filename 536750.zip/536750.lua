-- Lua provided by RyzenAPI
-- Game: BoomTown! Deluxe

-- MAIN APPLICATION
addappid(536750)

-- MAIN APP DEPOTS / PACKAGES
addappid(536751, 1, "b646c5b5988810394285d77f2490614a3004cf30c8407c0cdec35053b7e7a47a")

