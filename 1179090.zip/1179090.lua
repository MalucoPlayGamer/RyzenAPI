-- Lua provided by RyzenAPI
-- Game: 1179090

-- MAIN APPLICATION
addappid(1179090)
-- Game: addappid(1179090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179091, 1, "bc59bdc0e48477e6c7f4c5cd079c3ac7ee5dbc50bc09d6d6bf949249ba2a9381")
