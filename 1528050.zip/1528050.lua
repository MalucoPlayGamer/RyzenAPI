-- Lua provided by RyzenAPI
-- Game: Underland

-- MAIN APPLICATION
addappid(1528050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1528051, 1, "876e8812d66480d9e1c4de285d00a90f1245acc784307b1047d1e2aa0f44601d")

