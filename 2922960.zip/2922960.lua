-- Lua provided by RyzenAPI 
-- Game: AppID 2922960
addappid(2922960)
addappid(2922961, 1, "a8f511705f71b24947316929010ba63971d21218fca0711a803a85602063e6b5")
