-- Lua provided by RyzenAPI
-- Game: Boogeyman

-- MAIN APPLICATION
addappid(412770)
-- Game: addappid(412770)

-- MAIN APP DEPOTS / PACKAGES
addappid(412771, 1, "205a19274e12fe8a6389df01063157eff26908318fc72e0791f62382f726979b")
addappid(412772, 1, "d48fb2402b36797d5c8628f5bfd1d4c16c8daabbdb708da518e0d37c1ad966a9")
