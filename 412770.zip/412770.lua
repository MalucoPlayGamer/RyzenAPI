-- Lua provided by RyzenAPI
-- Game: Boogeyman

-- MAIN APPLICATION
addappid(412770)

-- MAIN APP DEPOTS / PACKAGES
addappid(412771, 1, "205a19274e12fe8a6389df01063157eff26908318fc72e0791f62382f726979b")
addappid(412772, 1, "d48fb2402b36797d5c8628f5bfd1d4c16c8daabbdb708da518e0d37c1ad966a9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
