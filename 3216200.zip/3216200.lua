-- Lua provided by RyzenAPI
-- Game: Game: Death Forest Abyss

-- MAIN APPLICATION
addappid(3216200)
addappid(4138850)
-- Game: addappid(3216200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3216201, 1, "61e0208e094d1a28bd5abf588f7540c3cdcfcf4abeea2470341ea9f8986289a0")
