-- Lua provided by SkyAPI 
-- Game: AppID 763790
addappid(763790)
addappid(763791, 1, "2c025c02c1c4af416f827b4ea8ca8bed3ca91039e3dd2ec4384e4f8f373e06aa")
