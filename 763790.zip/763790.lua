-- Lua provided by RyzenAPI
-- Game: TrainerVR

-- MAIN APPLICATION
addappid(763790)

-- MAIN APP DEPOTS / PACKAGES
addappid(763791, 1, "2c025c02c1c4af416f827b4ea8ca8bed3ca91039e3dd2ec4384e4f8f373e06aa")

