-- Lua provided by RyzenAPI
-- Game: addappid(2316930)

-- MAIN APPLICATION
addappid(2316930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2316931, 1, "ab252894ee2012f793b12042b3d84275b6e347b58dcec60a017c7f97edd46501")
