-- Lua provided by RyzenAPI
-- Game: Wizard Combat

-- MAIN APPLICATION
addappid(2832490)
-- Game: addappid(2832490)

-- MAIN APP DEPOTS / PACKAGES
addappid(2832496,0,"55b28d74e13ee459dc40c2ea2e63597c8c88af4996fcc7cb1fcd48b619f4b15e")
