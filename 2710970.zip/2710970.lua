-- Lua provided by SkyAPI 
-- Game: Dungeon Vixens: A Tale of Temptation
addappid(2710970)
addappid(2710971, 1, "2c8b065e8cd2a975240611a403227a535294e035b796655095499a9d3316fde3")
