-- Lua provided by RyzenAPI
-- Game: Dungeon Vixens: A Tale of Temptation

-- MAIN APPLICATION
addappid(2710970)
-- Game: addappid(2710970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2710971, 1, "2c8b065e8cd2a975240611a403227a535294e035b796655095499a9d3316fde3")
