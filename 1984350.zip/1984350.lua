-- Lua provided by RyzenAPI
-- Game: 打工吧！天使酱 ~天使在魔界的劳改生活~

-- MAIN APPLICATION
addappid(1984350)
