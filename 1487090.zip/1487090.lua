-- Lua provided by RyzenAPI
-- Game: addappid(1487090)

-- MAIN APPLICATION
addappid(1487090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1487094,0,"c26e07e3c44c60bd0358033d1fe3c4ceea9a118b0d494c04932c1cbcd75c42d5")
