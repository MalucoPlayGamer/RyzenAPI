-- Lua provided by RyzenAPI
-- Game: Slappyball

-- MAIN APPLICATION
addappid(1482620)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1563690)
addappid(3062130)
