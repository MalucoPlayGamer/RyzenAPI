-- Lua provided by RyzenAPI
-- Game: Slappyball

-- MAIN APPLICATION
addappid(1482620)

