-- Lua provided by RyzenAPI
-- Game: addappid(1336450)

-- MAIN APPLICATION
addappid(1336450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1336451, 1, "ce5f5aa4f56a2a9763e9fe38876e9f250f5e6e014d365e63a91f162bf7ab1f15")
