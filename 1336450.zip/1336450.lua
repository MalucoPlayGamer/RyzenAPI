-- Lua provided by RyzenAPI
-- Game: Poco In

-- MAIN APPLICATION
addappid(1336450)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1336451, 1, "ce5f5aa4f56a2a9763e9fe38876e9f250f5e6e014d365e63a91f162bf7ab1f15")
