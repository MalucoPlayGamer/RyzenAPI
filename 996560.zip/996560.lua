-- Lua provided by RyzenAPI
-- Game: AppID 996560

-- MAIN APPLICATION
addappid(996560)

-- MAIN APP DEPOTS / PACKAGES
addappid(996561, 1, "4e5bb948808bc4ebf59890491bdbafd9621cf03dc5472e68d6fb19fa6b23cfc8")
addappid(996562, 1, "5c21d5386b3b032c2fc0366220de297253db782d4dbcb236fd48db3ec7dfe61b")

