-- Lua provided by RyzenAPI
-- Game: FUSER™ - Zara Larsson - "Look What You've Done"

-- MAIN APPLICATION
addappid(1620950)

-- MAIN APP DEPOTS / PACKAGES
addappid(1620950,0,"ad01ca19bf0a7e337c5baa707b0835e9983f7bed9842fb99275dc8073732a9e8")
