-- Lua provided by RyzenAPI
-- Game: 向往的方向

-- MAIN APPLICATION
addappid(2234030)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2234031, 1, "d266b72499cf78f8e761d6e4600d5a22ed72449ff10fedc9c6673496d70ebbac")

