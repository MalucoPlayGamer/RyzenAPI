-- Lua provided by RyzenAPI
-- Game: 向往的方向

-- MAIN APPLICATION
addappid(2234030)
-- Game: addappid(2234030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2234031, 1, "d266b72499cf78f8e761d6e4600d5a22ed72449ff10fedc9c6673496d70ebbac")
