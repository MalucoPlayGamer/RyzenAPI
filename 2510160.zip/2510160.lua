-- Lua provided by RyzenAPI
-- Game: Game: Bounce & Roll

-- MAIN APPLICATION
addappid(2510160)
-- Game: addappid(2510160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2510161, 1, "e21f7f2e4986a96cb1bbc6f1cdf964c6693f157b122a19b50d830cedae9e6eab")
