-- Lua provided by RyzenAPI
-- Game: addappid(2087040)

-- MAIN APPLICATION
addappid(2087040)

-- MAIN APP DEPOTS / PACKAGES
addappid(2087040,0,"639da6f29f8b18e4459d9dbc175a3528f2c3bcd8aae3fa19c1eee2e155a4d490")
