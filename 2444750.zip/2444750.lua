-- Lua provided by RyzenAPI
-- Game: Shape of Dreams

-- MAIN APPLICATION
addappid(2444750)
-- Game: addappid(2444750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2444751, 1, "ef362189306209d0c11c3b509c34fd001aed76b0fc0ea258001430f6793519a5")
