-- Lua provided by RyzenAPI
-- Game: Endless World Demo

-- MAIN APPLICATION
addappid(1059210)

-- MAIN APP DEPOTS / PACKAGES
addappid(840261,0,"68393bb84ae42b9e51f7e6c298ffa0dc73e2d1f16edbd9708c054034cb9ecb3d")

