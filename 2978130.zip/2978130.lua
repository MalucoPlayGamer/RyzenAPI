-- Lua provided by RyzenAPI
-- Game: 2978130

-- MAIN APPLICATION
addappid(2978130)
-- Game: addappid(2978130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2978131, 1, "3bd6cf9ae9b84f8ed471e9864effa8ebba39aa07c709a858b67826316a5591b0")
