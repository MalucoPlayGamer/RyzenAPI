-- Lua provided by RyzenAPI
-- Game: Game: ORBIT

-- MAIN APPLICATION
addappid(348280)
-- Game: addappid(348280)

-- MAIN APP DEPOTS / PACKAGES
addappid(348281, 1, "c8b354eb72e61b060e2115ef063c5bade0120ecf243286ee6670e7a3299f580f")
