-- Lua provided by RyzenAPI 
-- Game: ORBIT
addappid(348280)
addappid(348281, 1, "c8b354eb72e61b060e2115ef063c5bade0120ecf243286ee6670e7a3299f580f")
