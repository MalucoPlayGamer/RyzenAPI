-- Lua provided by RyzenAPI
-- Game: Seasonal Soccer

-- MAIN APPLICATION
addappid(818380)
-- Game: addappid(818380)

-- MAIN APP DEPOTS / PACKAGES
addappid(818381, 1, "fac3c678ce4b58ba269051426c2960f3798d1f52888e7679c7473125bd3f9f35")
