-- Lua provided by RyzenAPI
-- Game: 1235710

-- MAIN APPLICATION
addappid(1235710)
-- Game: addappid(1235710)

-- MAIN APP DEPOTS / PACKAGES
addappid(1235712,0,"1df0b4231fdeb2809c131cc953d680e3e7591ea3c7f59df00eccfcbad9565348")
