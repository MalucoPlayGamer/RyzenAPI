-- Lua provided by RyzenAPI
-- Game: The Valiant

-- MAIN APPLICATION
addappid(959860)
addappid(2392910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(959861,0,"b99f2755491cbd7d7a077a6345e827e49be5a992c1d64d633e1d98ef1daecd67")

