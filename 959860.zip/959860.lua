-- Lua provided by RyzenAPI
-- Game: Game: The Valiant

-- MAIN APPLICATION
addappid(959860)
-- Game: addappid(959860)

-- MAIN APP DEPOTS / PACKAGES
addappid(959861, 1, "b99f2755491cbd7d7a077a6345e827e49be5a992c1d64d633e1d98ef1daecd67")
