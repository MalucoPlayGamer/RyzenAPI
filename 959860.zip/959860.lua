-- Lua provided by RyzenAPI 
-- Game: The Valiant
addappid(959860)
addappid(959861, 1, "b99f2755491cbd7d7a077a6345e827e49be5a992c1d64d633e1d98ef1daecd67")
