-- Lua provided by RyzenAPI
-- Game: Game: AppID 813300

-- MAIN APPLICATION
addappid(813300)
-- Game: addappid(813300)

-- MAIN APP DEPOTS / PACKAGES
addappid(813301, 1, "76d4bc45fa1b93f0054952742207e6b566380c9bf4bb7e274936508bbc78cb63")
addappid(1049770, 0, "3bb885c4baf928f7d900a8a538bd600a6d3e4e373455fab743e93f0832795afa")
