-- Lua provided by RyzenAPI
-- Game: Rome: Total War™ - Collection

-- MAIN APPLICATION
addappid(4760)
-- Game: addappid(4760)

-- MAIN APP DEPOTS / PACKAGES
addappid(4761, 1, "84873d58cee5c6ab5fb346773926b215610b66acbdaf82b9ce8605ecd34eca69")
addappid(4762, 1, "c7fecb34fd485b257182c94e2f5dc2f1ddf0e938683d176b7bdb7822da49a551")
addappid(4763, 1, "20c120bc9d12188dab64556175c8b94a311c1d9a1b790cc7c7c270cdc5cec05b")
addappid(4764, 1, "9eaa80c79f32e10235ee93ba50b353314513f06dd7d0c93ac75115ae9565185c")
addappid(4765, 1, "af8475e41afdf2d546cf774842a6e35fd5e55200aa67534dd2df95ac66d77b24")
addappid(4766, 1, "842784e90d8e482656f7f5fe268e6f440c80618a6c93aed58a04020de3f22895")
addappid(4767, 1, "f3da87052a113485f640b0ae1d12c046888c05aa00b86475cd5104a92fd12cd7")
