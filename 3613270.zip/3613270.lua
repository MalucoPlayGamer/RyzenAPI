-- 3613270's Lua and Manifest Created by Hubcap Manifest
-- Star Ores Inc.
-- Created: July 26, 2026 at 14:19:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(3613270, 1, "13af55b9ce8fb9c7053a6c0472969382b8477ef90d0fe9d133a099d3c3060318") -- Star Ores Inc.
-- MAIN APP DEPOTS
addappid(3613271, 1, "436ec5d56ba66d670f409779e9721373f24c63da10c16930816259863bf14060") -- Depot 3613271
setManifestid(3613271, "8658681907588921278", 2441225491)
-- DLCS WITH DEDICATED DEPOTS
-- Star Ores Inc.  The Official Book Story, Background  Insights (AppID: 4119350)
addappid(4119350)
addappid(4119350, 1, "cb2748896cb98bf367773c91f96776ec6ba3af912b52942061e3f09a0c915585") -- Star Ores Inc.  The Official Book Story, Background  Insights - Depot 4119350
setManifestid(4119350, "4037949787028465716", 51806739)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4145470) -- Star Ores Inc. - Support Pack