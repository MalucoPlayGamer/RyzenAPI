-- Lua provided by RyzenAPI
-- Game: LingerieS / ランジェリーズ

-- MAIN APPLICATION
addappid(2890890)

-- MAIN APP DEPOTS / PACKAGES
addappid(2890891, 1, "e60c94dbc93d4ff68753b42b9b3e597d749b8739eba27c0ea016196fd04888a3")
addappid(2893920, 0, "55fc8b745cd9389c7001ea343fb1aceaec46bdcacca640897db70e4fed2210e4")

