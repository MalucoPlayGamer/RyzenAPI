-- Lua provided by RyzenAPI
-- Game: addappid(1010480)

-- MAIN APPLICATION
addappid(1010480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1010481, 1, "108909d861fdbc233612eefd183ad325beb6623713ddc6176f44c25c3428c096")
