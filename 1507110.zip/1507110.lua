-- Lua provided by RyzenAPI
-- Game: Game: Kill The Emperor

-- MAIN APPLICATION
addappid(1507110)
-- Game: addappid(1507110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1507111, 1, "d9a7672ef0f822658bb23996158137e7ba65b287210ce9c412cd20066cc8462c")
