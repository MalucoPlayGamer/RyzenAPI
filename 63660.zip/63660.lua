-- Lua provided by RyzenAPI
-- Game: Myst: Masterpiece Edition

-- MAIN APPLICATION
addappid(63660)

-- MAIN APP DEPOTS / PACKAGES
addappid(63661, 1, "890c562cc0714297319a92b81a0d8541b811b5b8d6387dc49e8ef700701721ac")
addappid(63662, 1, "79085083070bb83d7221035f84c1286be1c4c8c66a56d91c46ff1c4b4fa83475")
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
