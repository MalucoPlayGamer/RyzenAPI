-- Lua provided by RyzenAPI
-- Game: Game: AppID 597590

-- MAIN APPLICATION
addappid(597590)
-- Game: addappid(597590)

-- MAIN APP DEPOTS / PACKAGES
addappid(597591, 1, "e6b6e614bba5a9f59c3ce0c74b9dff2fa3bd6ed2897f62596ef82ea5d8383d39")
