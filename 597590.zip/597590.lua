-- Lua provided by RyzenAPI
-- Game: AppID 597590

-- MAIN APPLICATION
addappid(597590)

-- MAIN APP DEPOTS / PACKAGES
addappid(597591, 1, "e6b6e614bba5a9f59c3ce0c74b9dff2fa3bd6ed2897f62596ef82ea5d8383d39")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
