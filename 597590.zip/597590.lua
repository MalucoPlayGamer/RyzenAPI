-- Lua provided by RyzenAPI 
-- Game: AppID 597590
addappid(597590)
addappid(597591, 1, "e6b6e614bba5a9f59c3ce0c74b9dff2fa3bd6ed2897f62596ef82ea5d8383d39")
