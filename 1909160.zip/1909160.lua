-- Lua provided by RyzenAPI
-- Game: Glamor & Girls - Artbook 18+

-- MAIN APPLICATION
addappid(1909160)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909160,0,"9275c352b7f118e4d94c3a341a8c9f7ea92084c1b5a0a79063ac910957ba9715")

