-- Lua provided by RyzenAPI
-- Game: Painkiller Overdose

-- MAIN APPLICATION
addappid(3270)

-- MAIN APP DEPOTS / PACKAGES
addappid(3271, 1, "850b0923c335f1e1ff7837c3eb3e32adb5b9c61cccf5b9c4da4dcb561953310b")
addappid(3272, 1, "d4a54e28c2c0ce79d3b26572fc013a00ba3da9f755d2c0f6429ed853c1006b52")
addappid(3273, 1, "98b4235c3d57cb2aa62506daaea25d63dc6207d23a4c894ae8ac6251c1e88923")

