-- Lua provided by RyzenAPI
-- Game: 596560

-- MAIN APPLICATION
addappid(596560)
-- Game: addappid(596560)

-- MAIN APP DEPOTS / PACKAGES
addappid(596561, 1, "c4886544e8c7d41f23d4d9fd84468f992c87033c78e5313647dbc48a0bcef3f9")
