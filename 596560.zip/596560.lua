-- Lua provided by RyzenAPI 
-- Game: AppID 596560
addappid(596560)
addappid(596561, 1, "c4886544e8c7d41f23d4d9fd84468f992c87033c78e5313647dbc48a0bcef3f9")
