-- Lua provided by SkyAPI 
-- Game: Piczle Cross: Story of Seasons
addappid(2591070)
addappid(2591071, 1, "dac632edd14b74c50d53c006a61c69ffe719d1365db2cfc835337b9f5a29f1f4")
