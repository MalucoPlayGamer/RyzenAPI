-- Lua provided by RyzenAPI
-- Game: Star Story: The Horizon Escape

-- MAIN APPLICATION
addappid(610310)

-- MAIN APP DEPOTS / PACKAGES
addappid(610313,0,"be5246a194839ff7348b54af0d963acb3b49370808411b4b2572ee4277cd29f2")
addappid(610316,0,"96edf1605c821e0b1587a1d3e6be53bda5398984a6ab68d0c2d6c8caf54f7212")
addappid(624510,0,"0c2d742ea53e4f608fd739ffbe08d5c7fb41e042c2f084e124716bac23d82f65")

