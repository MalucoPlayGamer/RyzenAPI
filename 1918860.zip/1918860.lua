-- Lua provided by RyzenAPI
-- Game: Game: The Upturned Soundtrack

-- MAIN APPLICATION
addappid(1918860)
-- Game: addappid(1918860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1918861, 1, "357fc1c11334f17665640c1daaf4dcf4ceec6235ee773b86cdede4fb549f990a")
