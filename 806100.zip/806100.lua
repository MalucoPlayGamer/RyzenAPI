-- Lua provided by RyzenAPI
-- Game: AppID 806100

-- MAIN APPLICATION
addappid(806100)
addappid(823010)
-- Game: addappid(806100)

-- MAIN APP DEPOTS / PACKAGES
addappid(806101, 1, "3919fbaa2a8e344fffbb39eec6bb9f10794aa1da45ebebfa9bea98d0d954086e")
