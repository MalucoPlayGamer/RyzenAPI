-- Lua provided by RyzenAPI
-- Game: Turok 2: Seeds of Evil

-- MAIN APPLICATION
addappid(405830)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(405831, 1, "91cf34abac63c6c12a53b8db93bb285c2d09648e54911a75076a266c7bae682e")
addappid(405832, 1, "78128df860bf542318cdb453f24e592c26eed7e8ab3c1e1ac47631762f688ea9")
addappid(405833, 1, "7c2630e8890689c4735bbb46f9cd53d0628ec353dd28f04f7a47fdec8ac3e20a")
addappid(405834, 1, "9a1b1c7ae1593930a01f55067ba0b3ec0fa522a0d3598e45bda43bfc1842d99e")
