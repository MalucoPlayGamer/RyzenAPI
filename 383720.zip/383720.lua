-- Lua provided by RyzenAPI
-- Game: Game: Swords & Crossbones: An Epic Pirate Story

-- MAIN APPLICATION
addappid(383720)
-- Game: addappid(383720)

-- MAIN APP DEPOTS / PACKAGES
addappid(383721, 1, "37babd8de8e254519e648044ad4d2641c78899198d5ca3ce9c297f2042975571")
addappid(383722, 1, "922a1393ecb20d4dab8affd9859f3e710f161432a3d5a44ed80ae1bbc80a9bad")
addappid(383723, 1, "fd1c81f4d6eaced99b01f02a67e11469872c7f6420fa24492cd6404c1272eb99")
addappid(383724, 1, "d2b88eb2928eb34bd5e42f32ccb4a1410b542e05a541658871a1a738717569e8")
