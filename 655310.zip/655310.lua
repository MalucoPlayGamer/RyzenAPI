-- Lua provided by RyzenAPI
-- Game: Game: AppID 655310

-- MAIN APPLICATION
addappid(655310)
-- Game: addappid(655310)

-- MAIN APP DEPOTS / PACKAGES
addappid(655311, 1, "32644149a920a3c1b4ace9bcffbd2208b99d04525be8407217b3ebbb7832c7d7")
