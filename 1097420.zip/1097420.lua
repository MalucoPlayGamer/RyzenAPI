-- Lua provided by RyzenAPI
-- Game: No-brainer Heroes

-- MAIN APPLICATION
addappid(1097420)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1097421, 1, "e376e8417b40c152bc61771a25d9b8506d2ada5b6d9a73db0fb6399796f069de")
addappid(1097422, 1, "fb5905b3bc25244b7a6f9261f322fe2430d1ada569a5f22cd537ede0aa17b08b")
addappid(1097423, 1, "e2f274db6c87a808e92301bff7dc4ad35a7fae8422203600c13c4b9219523c40")
addappid(1212900, 0, "4a943720239c62236a684bd1ab60a6ef59a523c8360b0db6badd506d8cfbecf7")
