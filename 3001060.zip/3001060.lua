-- Lua provided by RyzenAPI
-- Game: Funky Panic Attack

-- MAIN APPLICATION
addappid(3001060)
