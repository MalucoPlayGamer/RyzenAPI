-- Lua provided by RyzenAPI
-- Game: Locked Fears

-- MAIN APPLICATION
addappid(549910)

-- MAIN APP DEPOTS / PACKAGES
addappid(549911, 1, "cf22f24ab1c1c0a266ac0cb9aa70eb593313ec79b48d83cb7842bb2dafd002e6")

