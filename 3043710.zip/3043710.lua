-- Lua provided by RyzenAPI
-- Game: Diplomacy is Not an Option: Shareware

-- MAIN APPLICATION
addappid(3043710)

-- MAIN APP DEPOTS / PACKAGES
addappid(3043711, 1, "5a4b7c7e551ec548e6a878aa0a350ebb90c6e38288e4000a17ec4d2fdb468740")
