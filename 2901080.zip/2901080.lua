-- Lua provided by RyzenAPI
-- Game: addappid(2901080)

-- MAIN APPLICATION
addappid(2901080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2901081, 1, "944e99fa0b217ef011a1d8dbd026be2593bedcf024bb588dd088dc459b46ba77")
