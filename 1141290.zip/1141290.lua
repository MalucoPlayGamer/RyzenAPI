-- Lua provided by RyzenAPI
-- Game: Tactical Nexus

-- MAIN APPLICATION
addappid(1141290)
