-- Lua provided by RyzenAPI
-- Game: 1671340

-- MAIN APPLICATION
addappid(1671340)
-- Game: addappid(1671340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1671341, 1, "aea0ff78c9dfb1d444bf190ba47281aeec29757ecc9dcc2006dce90c6d963246")
