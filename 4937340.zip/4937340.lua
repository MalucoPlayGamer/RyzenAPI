-- Lua provided by RyzenAPI
-- Game: Boobs & Hexes

-- MAIN APPLICATION
addappid(4937340) -- Boobs & Hexes

-- MAIN APP DEPOTS / PACKAGES
addappid(4937342, 1, "ab2c6c2d5655f9e3c06b3f49506a0fc80933467fbefc7c3c2dc60249dd70043b") -- Depot 4937342
addappid(4937343, 1, "5ad27a417f21662149b182728d4de2cc050a65ec89f08e523888ffdf7d2278d4") -- Depot 4937343
addappid(4937344, 1, "1ee874f8bc61756742ab94e7677c3f47797790f70accc67c6cffce173737c4ed") -- Depot 4937344

