-- Lua provided by RyzenAPI
-- Game: addappid(3333090)

-- MAIN APPLICATION
addappid(3333090)

-- MAIN APP DEPOTS / PACKAGES
addappid(3333091, 1, "bdc609745e3fd33cebda77f079de5ccd962ed3dadd720f1a960ef1d39e7ff1bc")
