-- Lua provided by RyzenAPI 
-- Game: Wands
addappid(741400)
addappid(741401, 1, "3c27a59b5e95b4288ac5607a642c9cb9992c54ac80744ca6826df20c9cee4c33")
