-- Lua provided by RyzenAPI
-- Game: The Impregnation of the Elves: Conquest of the Arrogant Fairies by Impregnation

-- MAIN APPLICATION
addappid(2108290)
addappid(2183300)
-- Game: addappid(2108290)

-- MAIN APP DEPOTS / PACKAGES
addappid(2108291, 1, "269074d0cc0e614ac9bf05aa8d5125fefa1e7458224f180e1782790aa306244e")
