-- Lua provided by RyzenAPI
-- Game: Rift Riff

-- MAIN APPLICATION
addappid(2800900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800901, 1, "f3c7ea3002f656ee07bab9f10c17dbd3e775a438b4bd5c88a11f4fe3d4c3e9dd")
