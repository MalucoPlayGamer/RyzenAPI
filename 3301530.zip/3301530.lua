-- Lua provided by RyzenAPI
-- Game: addappid(3301530)

-- MAIN APPLICATION
addappid(3301530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3301531, 1, "cf50470295e9097e0642fa7929a96921ddee3f23bb1b09ecb34b4d87a688955c")
