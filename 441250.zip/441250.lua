-- Lua provided by RyzenAPI
-- Game: addappid(441250)

-- MAIN APPLICATION
addappid(441250)

-- MAIN APP DEPOTS / PACKAGES
addappid(441252,0,"878aa580e48472cc7d89b30a85f863573ea13adfd91977257b28eae3338ff0e5")
addappid(441253,0,"f255cff6944fa7660c7a64c8f9120e1e6cbdce814cdc2f92d8e15decb97e9bac")
