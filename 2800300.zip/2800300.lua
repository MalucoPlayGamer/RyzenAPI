-- Lua provided by RyzenAPI
-- Game: 100 Cats Singapore

-- MAIN APPLICATION
addappid(2800300)

-- MAIN APP DEPOTS / PACKAGES
addappid(2800301, 1, "290f8c930bad2deb8dfc4864e94450672f610c7578d02af01e70f0c1bc69ee26")

