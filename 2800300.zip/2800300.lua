-- Lua provided by SkyAPI 
-- Game: 100 Cats Singapore
addappid(2800300)
addappid(2800301, 1, "290f8c930bad2deb8dfc4864e94450672f610c7578d02af01e70f0c1bc69ee26")
