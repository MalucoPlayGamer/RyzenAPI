-- Lua provided by RyzenAPI
-- Game: Ancient Weapon Holly

-- MAIN APPLICATION
addappid(2403260)
addappid(2558590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2403261, 1, "f2b063e3904296b175535dab6585cd9fe75db8206756a14b356db8706e0bbf75")
