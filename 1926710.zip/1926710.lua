-- Lua provided by RyzenAPI 
-- Game: Jigsaw Novel - Double Trouble
addappid(1926710)
addappid(1926711, 1, "761d20cb547ea386531a18e4492c75dcc8a77f70a5eb50db56e5139e65915c1a")
