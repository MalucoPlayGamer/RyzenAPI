-- Lua provided by RyzenAPI
-- Game: PlayStation®VR2 App

-- MAIN APPLICATION
addappid(2580190)
-- Game: addappid(2580190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2580191, 1, "18e09ae79b675f11ba1d27a30063fe905aef3c507ec283aae3024976692882e1")
