-- Lua provided by RyzenAPI 
-- Game: REBEL
addappid(1904800)
addappid(1904801, 1, "9cf5c4e89a2dd55bb23df9ce319b6ec22551743d294dc7ad654e0a49bf249987")
