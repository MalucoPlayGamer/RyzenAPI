-- Generated with Luie @ https://lua.tools/
-- 1331440 - FUSER
-- Generated 2026-08-17 04:44:24 UTC
-- # Depots (Total/DLC/Shared): 3/0/2

-- Main AppID
addappid(1331440)

-- Main Depots
addappid(1331441, 1, "3c9cd93d2ccc41d5121efd490a94705e593f42c04d6fc431bee38aa7d50849b1") -- (windows)
setManifestid(1331441, "3504304450969605472", 26276090149)

-- DLC's (no depot keys required)
addappid(1356690) -- DLC 1356690
addappid(1427670) -- DLC 1427670
addtoken(1427670, "8089851906629943813")
addappid(1427671) -- DLC 1427671
addtoken(1427671, "11004441846419118566")
addappid(1427672) -- DLC 1427672
addtoken(1427672, "5168607812412684674")
addappid(1427673) -- DLC 1427673
addappid(1427674) -- DLC 1427674
addappid(1427675) -- DLC 1427675
addappid(1427676) -- DLC 1427676
addappid(1427677) -- DLC 1427677
addappid(1431160) -- DLC 1431160
addappid(1432120) -- DLC 1432120
addappid(1432121) -- DLC 1432121
addappid(1432122) -- DLC 1432122
addappid(1432123) -- DLC 1432123
addappid(1432124) -- DLC 1432124
addappid(1432125) -- DLC 1432125
addappid(1432126) -- DLC 1432126
addappid(1432127) -- DLC 1432127
addappid(1432128) -- DLC 1432128
addappid(1432129) -- DLC 1432129
addappid(1432140) -- DLC 1432140
addappid(1432141) -- DLC 1432141
addappid(1432142) -- DLC 1432142
addappid(1432143) -- DLC 1432143
addappid(1432144) -- DLC 1432144
addappid(1432145) -- DLC 1432145
addappid(1432146) -- DLC 1432146
addappid(1432147) -- DLC 1432147
addappid(1432148) -- DLC 1432148
addappid(1432149) -- DLC 1432149
addappid(1432150) -- DLC 1432150
addappid(1432151) -- DLC 1432151
addappid(1432152) -- DLC 1432152
addappid(1432153) -- DLC 1432153
addappid(1432154) -- DLC 1432154
addappid(1432155) -- DLC 1432155
addappid(1432156) -- DLC 1432156
addappid(1432157) -- DLC 1432157
addappid(1432158) -- DLC 1432158
addappid(1432159) -- DLC 1432159
addappid(1432160) -- DLC 1432160
addappid(1432161) -- DLC 1432161
addappid(1432162) -- DLC 1432162
addappid(1432163) -- DLC 1432163
addappid(1432164) -- DLC 1432164
addappid(1432165) -- DLC 1432165
addappid(1432166) -- DLC 1432166
addappid(1432167) -- DLC 1432167
addappid(1432168) -- DLC 1432168
addappid(1432169) -- DLC 1432169
addappid(1432170) -- DLC 1432170
addappid(1432171) -- DLC 1432171
addappid(1432172) -- DLC 1432172
addappid(1432173) -- DLC 1432173
addappid(1432174) -- DLC 1432174
addappid(1432175) -- DLC 1432175
addappid(1432176) -- DLC 1432176
addappid(1432177) -- DLC 1432177
addappid(1432178) -- DLC 1432178
addappid(1432180) -- DLC 1432180
addappid(1432181) -- DLC 1432181
addappid(1432182) -- DLC 1432182
addappid(1432190) -- DLC 1432190
addappid(1438180) -- DLC 1438180

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
