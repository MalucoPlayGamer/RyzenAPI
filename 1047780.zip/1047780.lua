-- Lua provided by RyzenAPI
-- Game: Game: AppID 1047780

-- MAIN APPLICATION
addappid(1047780)
-- Game: addappid(1047780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1047781, 1, "f31741eb2216953016e06392faea71ba10cb730665b1f880b7af8e90ddfe14c6")
