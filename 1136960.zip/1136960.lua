-- Lua provided by RyzenAPI
-- Game: AppID 1136960

-- MAIN APPLICATION
addappid(1136960)
-- Game: addappid(1136960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1136961, 1, "15d3dc10b585450c12b0fe3ddc288d9dd6ca52622f1919a5601fb13e05a2d257")
