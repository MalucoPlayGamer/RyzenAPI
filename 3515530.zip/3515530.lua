-- Lua provided by RyzenAPI
-- Game: Ice Cream Simulator

-- MAIN APPLICATION
addappid(3515530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3515531, 1, "8721ca94ac600fb7dd0d888249c92b19f18ab29a40d64e6268a0fc24597b1c49")
