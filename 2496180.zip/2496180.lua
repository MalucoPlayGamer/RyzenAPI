-- Lua provided by RyzenAPI
-- Game: Game: Ghost Town

-- MAIN APPLICATION
addappid(2496180)
-- Game: addappid(2496180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2496181, 1, "f73fe4eb6168188b3d3ed9a362608f4b07f181e7c94513efefa185250da1cd17")
