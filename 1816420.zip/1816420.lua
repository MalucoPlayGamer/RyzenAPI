-- Lua provided by RyzenAPI
-- Game: addappid(1816420)

-- MAIN APPLICATION
addappid(1816420)

-- MAIN APP DEPOTS / PACKAGES
addappid(1816421, 1, "992c665f73486ce709315e73f4cd11dd417e23ee85dffa8465a6417ff9e1ad0e")
