-- Lua provided by RyzenAPI
-- Game: Cubemen

-- MAIN APPLICATION
addappid(207250)
-- Game: addappid(207250)

-- MAIN APP DEPOTS / PACKAGES
addappid(207251, 1, "dbdfdc58d12a7952f2ca46765007185ce561c126df9b9e166577ea86dbb401cc")
addappid(207252, 1, "0eaf2610ee24326394a88916c80a5a5377b7488207296c071f09203ff4e7de12")
addappid(207254, 1, "e71088aedccc6e340f6055b561d3718764aa9acae3dff141b224dd5b05deb845")
