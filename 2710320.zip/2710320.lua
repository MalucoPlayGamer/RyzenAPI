-- Lua provided by RyzenAPI 
-- Game: THE DESCENT
addappid(2710320)
addappid(2710321, 1, "fe8d9aa80f664b7d9291f1672690b5bfa87d3c68ec407b8ade18aa5e85c49d53")
