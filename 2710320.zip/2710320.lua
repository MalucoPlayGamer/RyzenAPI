-- Lua provided by RyzenAPI
-- Game: Game: THE DESCENT

-- MAIN APPLICATION
addappid(2710320)
-- Game: addappid(2710320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2710321, 1, "fe8d9aa80f664b7d9291f1672690b5bfa87d3c68ec407b8ade18aa5e85c49d53")
