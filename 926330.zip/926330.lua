-- Lua provided by SkyAPI 
-- Game: AppID 926330
addappid(926330)
addappid(926331, 1, "29df427cd84df799c117da51168bf3b81a960165c80c019e9bf9726c6edff959")
