-- Lua provided by RyzenAPI
-- Game: 小西游记：石猴问世

-- MAIN APPLICATION
addappid(926330)

-- MAIN APP DEPOTS / PACKAGES
addappid(926331, 1, "29df427cd84df799c117da51168bf3b81a960165c80c019e9bf9726c6edff959")
