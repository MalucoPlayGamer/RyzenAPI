-- Lua provided by RyzenAPI
-- Game: addappid(910450)

-- MAIN APPLICATION
addappid(910450)

-- MAIN APP DEPOTS / PACKAGES
addappid(910451, 1, "f0aa71d4fab32aa05b58ec747b30e22ccbf05a55775b87ff3aecbc412fe96f34")
addappid(910452, 1, "ba41a3345f2b302ccd909ed015966389f40a17b1bdf26352479b89d4ce7171d2")
