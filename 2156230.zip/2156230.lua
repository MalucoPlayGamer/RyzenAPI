-- Lua provided by RyzenAPI
-- Game: Atelier Ryza 3 - "Another Look" Costume Set

-- MAIN APPLICATION
addappid(2156230)

-- MAIN APP DEPOTS / PACKAGES
addappid(2156230,0,"f8400b7b0326c7f520e98a587d14eb1c114aabb17a676cfde8dc184213b0116f")

