-- Lua provided by RyzenAPI
-- Game: Game: Hearts of Iron 2 Complete

-- MAIN APPLICATION
addappid(22130)
-- Game: addappid(22130)

-- MAIN APP DEPOTS / PACKAGES
addappid(22131, 1, "628c44f2cdd7bf2ed81ad2add24317f3c634a6a9e1fd45fb192570aab1211ffd")
