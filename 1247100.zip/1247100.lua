-- Lua provided by RyzenAPI
-- Game: AppID 1247100

-- MAIN APPLICATION
addappid(1247100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1247101, 1, "4f541e8e2154612773c00f3d49f48c0d49d9d3d07c94d3063d2223ae1419915f")

