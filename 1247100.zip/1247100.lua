-- Lua provided by SkyAPI 
-- Game: AppID 1247100
addappid(1247100)
addappid(1247101, 1, "4f541e8e2154612773c00f3d49f48c0d49d9d3d07c94d3063d2223ae1419915f")
