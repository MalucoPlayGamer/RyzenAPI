-- Lua provided by RyzenAPI
-- Game: On The Western Front

-- MAIN APPLICATION
addappid(866400)

-- MAIN APP DEPOTS / PACKAGES
addappid(866401,0,"3a83d1a89f1abf707e362991a00154ae964771ef6883d098380f3748a74c7e03")

