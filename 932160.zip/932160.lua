-- Lua provided by RyzenAPI
-- Game: addappid(932160)

-- MAIN APPLICATION
addappid(932160)

-- MAIN APP DEPOTS / PACKAGES
addappid(932161, 1, "4d350606bc287448c9e18c5875b803a93517667debafe6ff379420b1dfcd0c31")
