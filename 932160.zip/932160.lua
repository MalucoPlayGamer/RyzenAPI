-- Lua provided by RyzenAPI 
-- Game: Late at night
addappid(932160)
addappid(932161, 1, "4d350606bc287448c9e18c5875b803a93517667debafe6ff379420b1dfcd0c31")
