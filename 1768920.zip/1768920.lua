-- Lua provided by RyzenAPI
-- Game: Splatter

-- MAIN APPLICATION
addappid(1768920)

-- MAIN APP DEPOTS / PACKAGES
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(1768921, 1, "1bc131079f228c59a7bd37134c1893e99e7a76500b6397df9dc5f1e8ed620d13")

