-- Lua provided by RyzenAPI
-- Game: Game: AppID 1405720

-- MAIN APPLICATION
addappid(1405720)
-- Game: addappid(1405720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1405721, 1, "547e57c24e48a4797fa11261f2d2e8e4d6b0d96916fb299ec2c52c3ac8ddd638")
