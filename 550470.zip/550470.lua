-- Lua provided by RyzenAPI
-- Game: AppID 550470

-- MAIN APPLICATION
addappid(550470)

-- MAIN APP DEPOTS / PACKAGES
addappid(550471, 1, "bbfa9f9c719ea3d18b31c48d1c3128a7f379d5d61140a608050d3fe7723118d9")
addappid(550472, 1, "9e8ef825fd2cf0512548bef06166277e0de177f768606f9080c086cb28502021")
addappid(550473, 1, "3a5c5a462c7eb2f1080ff49e582dba1134a6d19128b36f4d6267dba8eca4e26f")
addappid(550474, 1, "2614bc0349f03f0b81f9bb68479a367eea4561dc180d6a9133f624415a638257")
addappid(550475, 1, "1cb1e3e2c23fc968513cae0d343ef02bcc1cfa05c2fc259c2001a6904d708cde")
addappid(550476, 1, "56930c6f6b8e0f8a69127019d69678a7f995d0800c995d88a6d7c7a205fca79b")
addappid(550477, 1, "41e4f8b62dde119f59c7c595e0e3f13f9df22adef5649a38f7fc1d9e19d468e4")
addappid(550479, 1, "80930fe1c52a09ea8ffbc0f54df86f19783c1206a2b5b02ff7c2c9b5edc5054e")
addappid(687252, 0, "38eaf67de0e88600c282da0f084cf749cb6e6a1dfef4c706cef07070dc8e1e9f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(687251)
