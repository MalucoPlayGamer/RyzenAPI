-- Lua provided by RyzenAPI
-- Game: addappid(1445740)

-- MAIN APPLICATION
addappid(1445740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1445741, 1, "8265f3c934fd6804754a7755fa9af9c0ba3d59f47f79d5dbda4b89b3f312d506")
