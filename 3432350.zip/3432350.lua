-- Lua provided by RyzenAPI 
-- Game: AppID 3432350
addappid(3432350)
addappid(3432351, 1, "f602f1370f052b3a24250c1fa76889d5c138eb7cfb1ba8d83198d8db8a488741")
