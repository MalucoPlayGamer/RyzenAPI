-- Lua provided by RyzenAPI
-- Game: 浪尖舞动SurfDance Demo

-- MAIN APPLICATION
addappid(3432350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3432351, 1, "f602f1370f052b3a24250c1fa76889d5c138eb7cfb1ba8d83198d8db8a488741")
