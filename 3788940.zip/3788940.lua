-- Lua provided by RyzenAPI
-- Game: Game: Gargouti Simulator

-- MAIN APPLICATION
addappid(3788940)
-- Game: addappid(3788940)

-- MAIN APP DEPOTS / PACKAGES
addappid(3788941, 1, "2a9742d873e8aeb38e0a78bda19fa43291eb069aa99bdcc491ad7558331f468a")
