-- Lua provided by RyzenAPI
-- Game: 385220

-- MAIN APPLICATION
addappid(385220)
-- Game: addappid(385220)

-- MAIN APP DEPOTS / PACKAGES
addappid(385221, 1, "af51437dabe4f16d6353881b5138c601bc539eae6fac86720bf9b3b667fca0e3")
