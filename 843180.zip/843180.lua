-- Lua provided by RyzenAPI
-- Game: 843180

-- MAIN APPLICATION
addappid(843180)
addappid(843184)
addappid(843185)
addappid(843187)

-- MAIN APP DEPOTS / PACKAGES
addappid(843186,0,"0838ed711675bb1a4aa5cdc499a76e33d5992cba273d09f3285cbf56946b8670")
