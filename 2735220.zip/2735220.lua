-- Lua provided by RyzenAPI
-- Game: Game: PolyZ

-- MAIN APPLICATION
addappid(2735220)
addappid(3849240)
-- Game: addappid(2735220)

-- MAIN APP DEPOTS / PACKAGES
addappid(2735221, 1, "c755c493b5ad54eabb764997ae78422300d7b9208709f8028211de7b73392078")
