-- Lua provided by RyzenAPI
-- Game: 2129160

-- MAIN APPLICATION
addappid(2129160)
-- Game: addappid(2129160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129161, 1, "f1a64d60857c881fab53f59b145ebb961f0283d1decf599bd3efffe5efe8d2f3")
