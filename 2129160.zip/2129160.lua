-- Lua provided by RyzenAPI
-- Game: Blue Wednesday

-- MAIN APPLICATION
addappid(2129160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2129161, 1, "f1a64d60857c881fab53f59b145ebb961f0283d1decf599bd3efffe5efe8d2f3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2580470)
