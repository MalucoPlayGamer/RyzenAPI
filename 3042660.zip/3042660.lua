-- Lua provided by RyzenAPI
-- Game: The Villainess Is Adored by the Prince of the Neighbor Kingdom

-- MAIN APPLICATION
addappid(3042660)
-- Game: addappid(3042660)

-- MAIN APP DEPOTS / PACKAGES
addappid(3042661, 1, "6d623a366a75fbd7da34d511eb816e3e87123f20eccd89453030e6fc27253792")
