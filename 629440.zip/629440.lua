-- Lua provided by RyzenAPI
-- Game: Graze Counter

-- MAIN APPLICATION
addappid(629440)
-- Game: addappid(629440)

-- MAIN APP DEPOTS / PACKAGES
addappid(629441, 1, "00917c305042b744d650fe62e205e13d6b9c4fb87b8d77b13ee3db19fc2dfa84")
addappid(629442, 1, "50128710393131dabd20ed0c38ffbdb53fbdde420971c579722f86ee07bdfe74")
