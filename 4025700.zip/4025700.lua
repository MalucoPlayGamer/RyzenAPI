-- Lua provided by RyzenAPI
-- Game: Heartopia

-- MAIN APPLICATION
addappid(4025700)
