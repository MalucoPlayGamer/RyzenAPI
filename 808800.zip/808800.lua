-- Lua provided by RyzenAPI
-- Game: Star Singularity

-- MAIN APPLICATION
addappid(808800)

-- MAIN APP DEPOTS / PACKAGES
addappid(808801,0,"2ffc067571ef124abf73251995ef64681102d8aa912117709984dbd694cb50ed")

