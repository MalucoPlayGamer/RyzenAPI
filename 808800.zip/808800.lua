-- Lua provided by RyzenAPI
-- Game: Star Singularity

-- MAIN APPLICATION
addappid(808800)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(808801,0,"2ffc067571ef124abf73251995ef64681102d8aa912117709984dbd694cb50ed")

