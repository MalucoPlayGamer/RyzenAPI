-- Lua provided by SkyAPI 
-- Game: Three Minutes to Eight Demo
addappid(2521280)
addappid(2521281, 1, "9e56613fd25857b96bf720b95ed082abe00534e5a23ecd0590ae6e7cfe06ae05")
