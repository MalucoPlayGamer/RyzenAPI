-- Lua provided by RyzenAPI
-- Game: Game: Three Minutes to Eight Demo

-- MAIN APPLICATION
addappid(2521280)
-- Game: addappid(2521280)

-- MAIN APP DEPOTS / PACKAGES
addappid(2521281, 1, "9e56613fd25857b96bf720b95ed082abe00534e5a23ecd0590ae6e7cfe06ae05")
