-- Lua provided by RyzenAPI
-- Game: Contract Work

-- MAIN APPLICATION
addappid(1076940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1076941, 1, "f8b8b4e8c73ba8a4e7c3735622c5335226177a0bdd47235bacfd8e0816a5ca7e")

