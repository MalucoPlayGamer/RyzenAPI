-- Lua provided by RyzenAPI
-- Game: Mayhemers

-- MAIN APPLICATION
addappid(2536260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2536261, 1, "4a9479f566e28998f98ddbf37cb096acc9c6c5a115c81d6528c1ba336f68a6df")
