-- Lua provided by RyzenAPI
-- Game: Hentai Vs Furries

-- MAIN APPLICATION
addappid(1208260)
-- Game: addappid(1208260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1208261, 1, "0bc0cc07024a3124bd3f52ded6854eba74126c0b63871fd92d0fc29ad4977799")
