-- Lua provided by RyzenAPI
-- Game: Hentai Vs Furries

-- MAIN APPLICATION
addappid(1208260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1208261, 1, "0bc0cc07024a3124bd3f52ded6854eba74126c0b63871fd92d0fc29ad4977799")

