-- Lua provided by RyzenAPI
-- Game: Game: Heroes of Civilizations

-- MAIN APPLICATION
addappid(676490)
addappid(1251730)
-- Game: addappid(676490)

-- MAIN APP DEPOTS / PACKAGES
addappid(676491, 1, "641484949e73c7edae07b66233135b2311a1ef05e7c793fdc96c773e65b70f42")
