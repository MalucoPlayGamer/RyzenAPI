-- Lua provided by RyzenAPI
-- Game: Heroes of Civilizations

-- MAIN APPLICATION
addappid(676490)
addappid(752110)
addappid(1251730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(676491, 1, "641484949e73c7edae07b66233135b2311a1ef05e7c793fdc96c773e65b70f42")

