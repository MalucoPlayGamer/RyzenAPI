-- Lua provided by SkyAPI 
-- Game: Sexy Iron Maidens
addappid(2686320)
addappid(2686321, 1, "3d5aa762633e0190464203a6e77b1dc1d32e6a5279a8d59108198428c04532e1")
