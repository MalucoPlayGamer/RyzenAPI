-- Lua provided by RyzenAPI
-- Game: Sexy Iron Maidens

-- MAIN APPLICATION
addappid(2686320)
-- Game: addappid(2686320)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686321, 1, "3d5aa762633e0190464203a6e77b1dc1d32e6a5279a8d59108198428c04532e1")
