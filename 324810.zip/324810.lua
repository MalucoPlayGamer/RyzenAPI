-- Lua provided by RyzenAPI
-- Game: TOXIKK

-- MAIN APPLICATION
addappid(324810)
addappid(503270)
addappid(533490)
addappid(533491)
addappid(533492)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(324811, 1, "a51015a3975c486d102bb417bc29cde384c86f3533c13e86d46073f361589d8e")
