-- Lua provided by RyzenAPI
-- Game: Game: AppID 324810

-- MAIN APPLICATION
addappid(324810)
addappid(503270)
-- Game: addappid(324810)

-- MAIN APP DEPOTS / PACKAGES
addappid(324811, 1, "a51015a3975c486d102bb417bc29cde384c86f3533c13e86d46073f361589d8e")
