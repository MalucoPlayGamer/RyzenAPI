-- Lua provided by RyzenAPI
-- Game: Threshold

-- MAIN APPLICATION
addappid(995470)

-- MAIN APP DEPOTS / PACKAGES
addappid(995471, 1, "ac3d95a3226a2f7e7a037adba12d6cc8f60e011c7e62bf38cf5e840c0bf24af3")

