-- Lua provided by RyzenAPI
-- Game: Threshold

-- MAIN APPLICATION
addappid(995470)

-- MAIN APP DEPOTS / PACKAGES
addappid(995471, 1, "ac3d95a3226a2f7e7a037adba12d6cc8f60e011c7e62bf38cf5e840c0bf24af3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
