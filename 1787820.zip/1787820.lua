-- Lua provided by RyzenAPI
-- Game: Mirror Party

-- MAIN APPLICATION
addappid(1787820)
addappid(1822102)
addappid(1822103)
addappid(1822104)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1787821, 1, "d560fbb7ddff85d537ccc0e139ee9f69e2d3dfc6ddb8b28aa094c5253f2041f7")
addappid(1822100, 0, "541f6eeefc3de256b913529d6fae42b4e421f986703c761a673c5b8e212050a2")
addappid(1822101, 0, "fb758c32d63982c44fac575146a333b09c1b6bb8453cf56f13851c24f8325725")

