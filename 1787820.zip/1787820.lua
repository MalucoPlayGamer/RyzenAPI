-- Lua provided by RyzenAPI
-- Game: Game: Mirror Party

-- MAIN APPLICATION
addappid(1787820)
-- Game: addappid(1787820)

-- MAIN APP DEPOTS / PACKAGES
addappid(1787821, 1, "d560fbb7ddff85d537ccc0e139ee9f69e2d3dfc6ddb8b28aa094c5253f2041f7")
addappid(1822100, 0, "541f6eeefc3de256b913529d6fae42b4e421f986703c761a673c5b8e212050a2")
addappid(1822101, 0, "fb758c32d63982c44fac575146a333b09c1b6bb8453cf56f13851c24f8325725")
