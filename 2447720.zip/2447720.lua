-- Lua provided by RyzenAPI
-- Game: Burger Zombies

-- MAIN APPLICATION
addappid(2447720)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2447721, 1, "7f4a531290d7f7a7c420d0dc32615c06bc9b6943d753a497274796aec842c13b")

