-- Lua provided by RyzenAPI
-- Game: Remnants Of Yore Playtest

-- MAIN APPLICATION
addappid(3653860)
-- Game: addappid(3653860)

-- MAIN APP DEPOTS / PACKAGES
addappid(3653861, 1, "7fc8d3c58f8443e563155cacf6c6eb3d69a83d511acf8a60580dd9546153362a")
