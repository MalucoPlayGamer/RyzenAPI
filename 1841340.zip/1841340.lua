-- Lua provided by RyzenAPI
-- Game: Game: Beyond Sunset Demo

-- MAIN APPLICATION
addappid(1841340)
-- Game: addappid(1841340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1841341, 1, "86493ca0fbdc9db565979e3fa99134cc481907f2674e9979aa7096e5204f0ae5")
