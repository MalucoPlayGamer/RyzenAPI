-- Lua provided by RyzenAPI
-- Game: Tomoyo After ~It's a Wonderful Life~ English Edition

-- MAIN APPLICATION
addappid(462990)
addappid(518710)

-- MAIN APP DEPOTS / PACKAGES
addappid(462991, 1, "f20e114c0f248a1c578fad23789dd18efc6c59260bca2c40413afa870f105e5c")
addappid(518711, 0, "18883b11cb6946e398bf6d117f316fdc21165663e135946bbc7f779c08d4efeb")
addappid(952900, 0, "7192053045bd2ef78ba1f0995c87d1735a80e7d05ba06ad1f71495e228d6fa58")
