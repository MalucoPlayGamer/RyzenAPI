-- Lua provided by RyzenAPI
-- Game: AppID 537130

-- MAIN APPLICATION
addappid(537130)

-- MAIN APP DEPOTS / PACKAGES
addappid(537131, 1, "a645ae9afd1753ee25a5d33a2959f483a315f2fca42b1730108d64cf5284f080")
addappid(537132, 1, "252ed01563eb39f1440978e4b216455369ed8c9eb7ab705cd9377ed938154a87")
addappid(537133, 1, "97e462c13cedd83b3946bf3ab075b6831d361a543f5b03d0f734a1d5f0b61b40")
addappid(537134, 1, "652bd6d16d6729ac3bf0ecde21374e1e74b83bb0a206ff2d2a6631293181f01f")
addappid(537136, 1, "b65fc406b8bdb68de0a97f210257de162ee16387b0d6eac31c2bf06a0c40b336")
addappid(537137, 1, "6abaef288ce2a479ea378165d022260238237f5abc3f95357aa23e25287eb2f8")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(673340)
