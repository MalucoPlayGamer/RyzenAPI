-- Lua provided by RyzenAPI
-- Game: Kunai Strike

-- MAIN APPLICATION
addappid(1982430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982431, 1, "765f3fe16737d6b5f9caedbdc02e240ef71727aeedbbe718ddfa6d92a7585e23")

