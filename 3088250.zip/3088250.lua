-- Lua provided by RyzenAPI
-- Game: Nitro Express

-- MAIN APPLICATION
addappid(3088250)

-- MAIN APP DEPOTS / PACKAGES
addappid(3088251, 1, "29bc6269d41b15e5aca49f0a0e9a4e2f3182e5c8767c7df16432aa14544f0dea")

