-- Lua provided by RyzenAPI
-- Game: Sucker for Love: Date to Die For

-- MAIN APPLICATION
addappid(2240790)

-- MAIN APP DEPOTS / PACKAGES
addappid(2240791, 1, "cacc2c222a12f4f7fdf8122fbd62073c13766553f27a237028709f8c1b829e03")

