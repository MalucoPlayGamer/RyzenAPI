-- Lua provided by SkyAPI 
-- Game: Zup! Q
addappid(2206560)
addappid(2206561, 1, "09c9a10c0173807c503fe3cab13dd63a8d0f247bbfb1f264814f5a2043f2b733")
