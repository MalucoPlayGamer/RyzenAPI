-- Lua provided by RyzenAPI
-- Game: addappid(2406150)

-- MAIN APPLICATION
addappid(2406150)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406151, 1, "291571b585a4a44a10dfc52738cef04374e304857f034b0367af2acca91c7b36")
