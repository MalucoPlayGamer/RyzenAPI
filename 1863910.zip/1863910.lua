-- Lua provided by RyzenAPI
-- Game: Project Speed 2

-- MAIN APPLICATION
addappid(1863910)

-- MAIN APP DEPOTS / PACKAGES
addappid(1863911, 1, "e389c354251cc1bb2036cf412e94cd5f32a2428d6c0732c75b4282f3a56419a7")
addappid(1863912, 1, "009991472c750a45d648ad4c5bd327035569fac629f080a51f0e152ee1f6c6d9")
addappid(1863913, 1, "c50b22a4b047dc86492a29d61354e6b0c25f57a86c3043c8954d6e11b631a6dc")
addappid(1863914, 1, "0fb2ac8c41de44fe88fcd6ec6f5515bbd83bc0332eccfbe2460d9331a298a66f")
addappid(1863915, 1, "984c27478b9d796349b9ebebc447e465b1d9e25ffe3674317812d024089169dd")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2437540)
