-- Lua provided by RyzenAPI
-- Game: Game: AppID 11480

-- MAIN APPLICATION
addappid(11480)
-- Game: addappid(11480)

-- MAIN APP DEPOTS / PACKAGES
addappid(11481, 1, "27cce5a5e63b6d5e20dacaac29266414a94be981f753940bdc292cc26b35f7bf")
addappid(11482, 1, "0e5d92e2baced255e72d2f9b71ec66d9efa2176d16e858325c1e30bea4d46fda")
addappid(11483, 1, "0ec4b698e79e78b6d6ea6ea5a25101eb50f93ad50977affc1542ba0e1b9cbe9a")
addappid(11484, 1, "dff90f68e0470b7c318b80152ab783851a95e91583a83af53a7c4bdf3645aa2e")
addappid(11485, 1, "ffe050f3f9363e2db5c8b11541fed5850fac942f525d950f95cac8f897462fb3")
addappid(11486, 1, "fcda45c4ee70f2736c8b6e416b6626785f042d4c5103dd4abed304e90ec49e58")
addappid(11487, 1, "d37554cd9a2e2407757d14044c6c1a5f50b029f5a4486ce5a8bb504595663839")
