-- Lua provided by RyzenAPI
-- Game: Light Rider

-- MAIN APPLICATION
addappid(228986)
addappid(228990)
addappid(866450)
-- Game: addappid(866450)

-- MAIN APP DEPOTS / PACKAGES
addappid(866452,0,"c09a8e7c58645c7d2304b5e6e9e1dcc66c7278a70b5734cc57946430269a5d45")
