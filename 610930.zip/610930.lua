-- Lua provided by RyzenAPI
-- Game: 610930

-- MAIN APPLICATION
addappid(610930)
-- Game: addappid(610930)

-- MAIN APP DEPOTS / PACKAGES
addappid(610931, 1, "b4c1fd6940164129e89a8b358f075b5d2c94a56f395fd5688178103302e7cd5a")
