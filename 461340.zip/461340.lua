-- Lua provided by RyzenAPI 
-- Game: AppID 461340
addappid(461340)
addappid(461341, 1, "3e59167e09c62952ee34f2fb2d688fd4485dd9a503006f42fb2de726f0f5b29e")
addappid(1087840, 0, "ab838a39ed6e46ed1911230cad5de6501682403a6fb32406b817a05b7ace78f0")
