-- Lua provided by RyzenAPI
-- Game: 1140500

-- MAIN APPLICATION
addappid(1140500)
-- Game: addappid(1140500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1140501, 1, "efb055d1971a5382971e22bda5951bbf3118af95754ed1fa5f6c763efab86a7a")
