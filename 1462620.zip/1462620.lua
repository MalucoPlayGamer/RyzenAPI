-- Lua provided by RyzenAPI
-- Game: Odd Adventure of Chub, Color, 23 and You

-- MAIN APPLICATION
addappid(1462620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1462621, 1, "b5966033cb5bc2fab52cc77a72d1cd3afd4af32efcc08bd3e2b588362fb53765")

