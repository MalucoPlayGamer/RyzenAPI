-- Lua provided by RyzenAPI
-- Game: AppID 569540

-- MAIN APPLICATION
addappid(569540)

-- MAIN APP DEPOTS / PACKAGES
addappid(569541, 1, "98e6cf8a444f2cc09ea2857043fd983dfac7dfcce8e597c22e238946a0c283ab")
