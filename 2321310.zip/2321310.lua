-- Lua provided by RyzenAPI
-- Game: addappid(2321310)

-- MAIN APPLICATION
addappid(2321310)

-- MAIN APP DEPOTS / PACKAGES
addappid(2321311, 1, "6d287003ddbf550ffa76379f0571ae4a415b4d2cccee91fc75d50d17c8c156df")
