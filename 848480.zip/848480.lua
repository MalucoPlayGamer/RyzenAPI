-- Lua provided by RyzenAPI
-- Game: Creeper World 4

-- MAIN APPLICATION
addappid(848480)

-- MAIN APP DEPOTS / PACKAGES
addappid(848481, 1, "42805f7d63eca83833221179256cfecb0e5c6bef0b73d9fdff229af22d67dfeb")
