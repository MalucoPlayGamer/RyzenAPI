-- Lua provided by RyzenAPI
-- Game: Game: AppID 371620

-- MAIN APPLICATION
addappid(371620)
-- Game: addappid(371620)

-- MAIN APP DEPOTS / PACKAGES
addappid(371621, 1, "ee537f65366dd57630c28766ab62219358342644d292b2d32878c8dfb81b072c")
