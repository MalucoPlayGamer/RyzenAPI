-- Lua provided by RyzenAPI
-- Game: Pax Dei

-- MAIN APPLICATION
addappid(1995520)
addappid(2919380)
addappid(2919390)
addappid(2919400)

-- MAIN APP DEPOTS / PACKAGES
addappid(1995521, 1, "271758a3b39f9bc289928dfd32ba73ca43575d81f7b173e2dfedbe4297657fd7")

