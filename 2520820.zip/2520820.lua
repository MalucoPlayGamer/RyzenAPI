-- Lua provided by RyzenAPI
-- Game: AppID 2520820

-- MAIN APPLICATION
addappid(2520820)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2520821, 1, "d791c5ef5c1c52934e652d44afdd6ee5758e0fd892cc5ac4aff3f30e37daf25a")

