-- Lua provided by RyzenAPI
-- Game: Stacklands

-- MAIN APPLICATION
addappid(1948280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1948281, 1, "8dd1d5025c5a7f1f95e4b0daaf4207089bdab6bc74746dc37e27ae30b2cee8de")
addappid(1948282, 1, "6d4f901bb48c128e3d01f9ff294d6fe9bc02932d0ab0eeb9881d86cfef996dfb")
addappid(2446110, 0, "ee6cab861739568f2ec3af0c3f4d6cb6ff49056d0b9d972633785776dbac536b")
addappid(2867570, 0, "321d32b4b23d37a101e7cccbd57595abbd5752d7738c4a75189a6c6584374b29")

