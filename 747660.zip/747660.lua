-- Lua provided by RyzenAPI
-- Game: Five Nights at Freddy's: Security Breach

-- MAIN APPLICATION
addappid(747660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(747661, 1, "2be8f0b84ce1709f94c1e3f51780dc5d9b578dee06c6e2a01bfa8062612b39d7")
addappid(1924720, 0, "0082af8a55cb6a77b1d8de8fc5264b5ec9899864bd449a859cffbf97f0125859")

