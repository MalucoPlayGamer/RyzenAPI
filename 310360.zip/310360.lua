-- Lua provided by RyzenAPI
-- Game: Higurashi When They Cry Hou - Ch.1 Onikakushi

-- MAIN APPLICATION
addappid(310360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(310361, 1, "fbf2124627dcc5fe916d4c3f62114547471316869a69340421585bd2895613b3")
addappid(310362, 1, "36e453b4a63f4a24a08046f44e508f1bace3e58adb45f9cd00e9eddf56709e96")
addappid(310363, 1, "5e70042eea5d33a3a0eef2b113e4b2360e613800a0f39065714346b0b202c9c6")
