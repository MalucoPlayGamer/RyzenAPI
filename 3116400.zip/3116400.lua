-- Lua provided by RyzenAPI
-- Game: addappid(3116400)

-- MAIN APPLICATION
addappid(3116400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3116401, 1, "0712be3a0b642929e5e3fabc95eea63ac73dc54295306c9a13339385a50600f8")
