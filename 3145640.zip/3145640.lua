-- Lua provided by RyzenAPI
-- Game: Gaming Copilot: AI Companion

-- MAIN APPLICATION
addappid(3145640)

-- MAIN APP DEPOTS / PACKAGES
addappid(3145641, 1, "c111744effbcb0d822e67b34615963989e128ed95d1223a1cde1045e19684f65")
