-- Lua provided by RyzenAPI 
-- Game: VARLET
addappid(3406620)
addappid(3406621, 1, "5d2c8e2ef3d208c8931c22f64f9601c4016bf5420b00f3995aa0bdaef611edf4")
addappid(3506650)
addappid(3885970, 0, "b01b6dab23df76cf116459ec89a291ae203a37a8c07940632c87415efda95f3f")
