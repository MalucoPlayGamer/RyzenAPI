-- Lua provided by RyzenAPI
-- Game: VARLET

-- MAIN APPLICATION
addappid(3406620)
addappid(3506650)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3406621, 1, "5d2c8e2ef3d208c8931c22f64f9601c4016bf5420b00f3995aa0bdaef611edf4")
addappid(3885970, 0, "b01b6dab23df76cf116459ec89a291ae203a37a8c07940632c87415efda95f3f")

