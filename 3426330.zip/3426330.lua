-- Lua provided by RyzenAPI
-- Game: Investigating Alien Cats 调查外星猫

-- MAIN APPLICATION
addappid(3426330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3426331, 1, "fa78fb36097968b3f24b775ecda9688c8dc6791cc5c48d462b9fab48b7d331df")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
