-- Lua provided by RyzenAPI
-- Game: 3426330

-- MAIN APPLICATION
addappid(3426330)
-- Game: addappid(3426330)

-- MAIN APP DEPOTS / PACKAGES
addappid(3426331, 1, "fa78fb36097968b3f24b775ecda9688c8dc6791cc5c48d462b9fab48b7d331df")
