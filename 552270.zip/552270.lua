-- Lua provided by RyzenAPI
-- Game: Primitive Road

-- MAIN APPLICATION
addappid(552270)

-- MAIN APP DEPOTS / PACKAGES
addappid(552271,0,"72f5fc6b23b4ca7771d7450ab9733830960e9d427d39565d9b28ef830f4c7e54")

