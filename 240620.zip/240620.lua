-- Lua provided by RyzenAPI
-- Game: Wanderlust Adventures

-- MAIN APPLICATION
addappid(240620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- (windows)
addappid(240621, 1, "9d050aa08c17e25601ec6ce40486edea67d03e325e98c0b99499fb6b24ea1093")

