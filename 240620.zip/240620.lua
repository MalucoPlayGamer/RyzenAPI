-- Lua provided by RyzenAPI
-- Game: 240620

-- MAIN APPLICATION
addappid(240620)
-- Game: addappid(240620)

-- MAIN APP DEPOTS / PACKAGES
addappid(240621, 1, "9d050aa08c17e25601ec6ce40486edea67d03e325e98c0b99499fb6b24ea1093")
