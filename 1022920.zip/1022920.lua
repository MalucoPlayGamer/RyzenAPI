-- Lua provided by RyzenAPI
-- Game: AppID 1022920

-- MAIN APPLICATION
addappid(1022920)
-- Game: addappid(1022920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1022921, 1, "bf3f54e01faf5c5cd8269b3f30355f2981bb665fe6fa4075d53d7883d1fa2859")
