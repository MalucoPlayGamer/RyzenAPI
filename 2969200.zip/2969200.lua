-- Lua provided by RyzenAPI
-- Game: Untraveled Lands: Chantico Demo

-- MAIN APPLICATION
addappid(2969200)
-- Game: addappid(2969200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969201, 1, "805e726986601ef58e06f5ed1915c533ec2fa5634703f10ef19e252ccbb194ab")
