-- Lua provided by RyzenAPI
-- Game: AppID 960730

-- MAIN APPLICATION
addappid(960730)

-- MAIN APP DEPOTS / PACKAGES
addappid(960731, 1, "07dcfc4c1ff0a76954e35bea693240b46bc2ae5cf2269a8a57d8680e1d5b5261")
