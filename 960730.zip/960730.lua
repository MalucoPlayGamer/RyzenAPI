-- Lua provided by RyzenAPI
-- Game: Memories Off Sorekara

-- MAIN APPLICATION
addappid(960730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(960731, 1, "07dcfc4c1ff0a76954e35bea693240b46bc2ae5cf2269a8a57d8680e1d5b5261")

