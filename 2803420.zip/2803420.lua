-- Lua provided by RyzenAPI
-- Game: Russian roulette Demo

-- MAIN APPLICATION
addappid(2803420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2803421, 1, "136a65f0aced9b5aa921dca85ffdd721d38e826b63d6875fedc7475d1fe55e7c")
