-- Lua provided by RyzenAPI
-- Game: BYTEWORLD

-- MAIN APPLICATION
addappid(3279000)
