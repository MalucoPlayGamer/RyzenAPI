-- Lua provided by RyzenAPI
-- Game: BYTEWORLD

-- MAIN APPLICATION
addappid(3279000)
addappid(3889660)

