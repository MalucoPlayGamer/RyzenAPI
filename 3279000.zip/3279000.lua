-- Lua provided by RyzenAPI
-- Game: BYTEWORLD

-- MAIN APPLICATION
addappid(3279000)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(3889660)
