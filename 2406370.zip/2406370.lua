-- Lua provided by RyzenAPI
-- Game: Darkblade Ascent

-- MAIN APPLICATION
addappid(2406370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406371, 1, "9bf0b904746e50442d37cd17d12030983ee495efc1a0d906595944b10fafb710")

