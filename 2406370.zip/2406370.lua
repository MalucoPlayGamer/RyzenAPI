-- Lua provided by RyzenAPI
-- Game: Darkblade Ascent

-- MAIN APPLICATION
addappid(2406370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406371, 1, "9bf0b904746e50442d37cd17d12030983ee495efc1a0d906595944b10fafb710")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
