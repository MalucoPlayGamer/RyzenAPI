-- Lua provided by RyzenAPI
-- Game: CatBallGravityMaze

-- MAIN APPLICATION
addappid(2651580)
-- Game: addappid(2651580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2651581, 1, "7ac67cb743bd4080f7cb42b25254c425a53b121d02378ce92271c03ac2ad88a4")
