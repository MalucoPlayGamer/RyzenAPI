-- Lua provided by RyzenAPI
-- Game: Guacamelee! Soundtrack

-- MAIN APPLICATION
addappid(257020)
-- Game: addappid(257020)

-- MAIN APP DEPOTS / PACKAGES
addappid(257020,0,"eb7d63e7d4886e8f33506011a64e66aa9d85c8eec8ed3506589fe70ccffd720e")
