-- Lua provided by RyzenAPI
-- Game: ArcRunner

-- MAIN APPLICATION
addappid(228989)
addappid(228990)
addappid(229007)
addappid(1575830)
-- Game: addappid(1575830)

-- MAIN APP DEPOTS / PACKAGES
addappid(1575832,0,"83810b68c2bd3cfdfbc9c717594e9e931b67e34110eef3fd8b7d7c3cd0146d0c")
