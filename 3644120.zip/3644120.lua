-- Lua provided by RyzenAPI
-- Game: Drunkn Bar Fight 2 VR

-- MAIN APPLICATION
addappid(3644120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3644121, 1, "ef4113aaca0c50106c11746998e28dedd2ae833ba7eb9b6d6808d4abdbc71709")
