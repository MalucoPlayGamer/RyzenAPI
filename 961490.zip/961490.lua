-- Lua provided by RyzenAPI
-- Game: Travis Strikes Again: No More Heroes Complete Edition

-- MAIN APPLICATION
addappid(961490)

-- MAIN APP DEPOTS / PACKAGES
addappid(961491,0,"19f71102c5a771a09df9a11cbdb822e16dcd1e030d6b0acbb117a72ff3b9f9db")
addappid(1172600,0,"fc6a2b8f99f16aac0ed2dc1cde2e140e3d5668bb690d1d7fa16b496046967c95")

