-- Lua provided by RyzenAPI
-- Game: Travis Strikes Again: No More Heroes Complete Edition

-- MAIN APPLICATION
addappid(961490)

-- MAIN APP DEPOTS / PACKAGES
addappid(961491,0,"19f71102c5a771a09df9a11cbdb822e16dcd1e030d6b0acbb117a72ff3b9f9db")
addappid(1172600,0,"fc6a2b8f99f16aac0ed2dc1cde2e140e3d5668bb690d1d7fa16b496046967c95")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
