-- Lua provided by RyzenAPI
-- Game: AppID 961490

-- MAIN APPLICATION
addappid(961490)

-- MAIN APP DEPOTS / PACKAGES
addappid(961491, 1, "19f71102c5a771a09df9a11cbdb822e16dcd1e030d6b0acbb117a72ff3b9f9db")
