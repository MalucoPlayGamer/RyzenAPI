-- Lua provided by RyzenAPI
-- Game: AppID 392080

-- MAIN APPLICATION
addappid(392080)

-- MAIN APP DEPOTS / PACKAGES
addappid(392081, 1, "4a74d56912dd9fe591d0094518e60e586707d58f8aa6977bd718d265563c3939")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
