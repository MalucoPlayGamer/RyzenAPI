-- Lua provided by RyzenAPI
-- Game: Game: AppID 392080

-- MAIN APPLICATION
addappid(392080)
-- Game: addappid(392080)

-- MAIN APP DEPOTS / PACKAGES
addappid(392081, 1, "4a74d56912dd9fe591d0094518e60e586707d58f8aa6977bd718d265563c3939")
