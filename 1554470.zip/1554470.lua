-- Lua provided by RyzenAPI
-- Game: addappid(1554470)

-- MAIN APPLICATION
addappid(1554470)

-- MAIN APP DEPOTS / PACKAGES
addappid(1554471, 1, "535dbf0cc0986c12556206b0a061b872468a9e36df7db7bdf4de13660380ca08")
