-- Lua provided by RyzenAPI
-- Game: Road Madness

-- MAIN APPLICATION
addappid(457710)

-- MAIN APP DEPOTS / PACKAGES
addappid(457711, 1, "6d28320018b7f74e6820945befc6c497e43782dc8e82e047fb1fe91d5e070d05")
addappid(491310, 0, "970eb8473196e813ac040cc6e0f2c361eb9085b7a01c2a7f2bd14213ef3d17b6")

