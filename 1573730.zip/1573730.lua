-- Lua provided by RyzenAPI
-- Game: AppID 1573730

-- MAIN APPLICATION
addappid(1573730)
-- Game: addappid(1573730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1573731, 1, "3ac75aa561f51df3e7cf20572587a862d0ffa997666a6ada9d8e5964b402ab31")
