-- Lua provided by RyzenAPI
-- Game: Beyond Enemy Lines - Remastered Edition

-- MAIN APPLICATION
addappid(1217750)
-- Game: addappid(1217750)

-- MAIN APP DEPOTS / PACKAGES
addappid(1217751, 1, "2f5d3da011632cd9721db76bb2e759e305c1715279bef1aaf41f34a819399749")
