-- Lua provided by RyzenAPI
-- Game: Over 9000 Zombies!

-- MAIN APPLICATION
addappid(273500)

-- MAIN APP DEPOTS / PACKAGES
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(273501, 1, "b4e95d800154878474d234b8f23ba370cec7bf6752caf6032f6c54a5ecfa3eef")
