-- Lua provided by RyzenAPI
-- Game: AppID 273500

-- MAIN APPLICATION
addappid(273500)
-- Game: addappid(273500)

-- MAIN APP DEPOTS / PACKAGES
addappid(273501, 1, "b4e95d800154878474d234b8f23ba370cec7bf6752caf6032f6c54a5ecfa3eef")
