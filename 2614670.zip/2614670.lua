-- Lua provided by RyzenAPI
-- Game: The World's Egg - For Those Who Dream

-- MAIN APPLICATION
addappid(2614670)

-- MAIN APP DEPOTS / PACKAGES
addappid(2614671, 1, "0f69e535aee7c7c38a6db281ad62343c9278d8f7deab2ac0baf55214a384ee84")
addappid(2614672, 1, "42f3bc274725a01c45affeae9244d715a78cac1b4b8d5b776ee2441a2a387f88")
addappid(2614673, 1, "0950929aeed85857ae2964157a94612041427899fb142bbdc683b2b250a97f6b")

