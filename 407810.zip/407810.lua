-- Lua provided by RyzenAPI
-- Game: Hard Reset Redux

-- MAIN APPLICATION
addappid(407810)

-- MAIN APP DEPOTS / PACKAGES
addappid(407811, 1, "33746f2c541cb3057ce9f9e7faa02adc8f84fe7569216aaad685284329f20f3c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
