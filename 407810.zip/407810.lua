-- Lua provided by RyzenAPI
-- Game: Game: Hard Reset Redux

-- MAIN APPLICATION
addappid(407810)
-- Game: addappid(407810)

-- MAIN APP DEPOTS / PACKAGES
addappid(407811, 1, "33746f2c541cb3057ce9f9e7faa02adc8f84fe7569216aaad685284329f20f3c")
