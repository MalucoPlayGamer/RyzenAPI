-- Lua provided by RyzenAPI
-- Game: Metrico+

-- MAIN APPLICATION
addappid(373990)

-- MAIN APP DEPOTS / PACKAGES
addappid(373991, 1, "293346b9f9c81fb74ce72ad408255430230194f1bc02c039a83cc4b79f890f4e")
addappid(373992, 1, "828453beb30671c7f3ac8c287a6e8d533db2a330f6c4b0a21e9c1678014704e8")
addappid(373993, 1, "dbc41d3190ce93e5418a897a029c79b33fe4aed8f55b76954e7716f9b9b4477f")
addappid(373994, 1, "717abf77ec2482394a0118a15fcc41fbcdc639b34055d074e6778a09b0b0a2c0")
addappid(373995, 1, "6f40bde58c3653583267612abf0c85dd1e2a71e0cd37cd0d021c60fefcd3702f")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
