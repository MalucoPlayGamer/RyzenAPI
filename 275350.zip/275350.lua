-- Lua provided by RyzenAPI
-- Game: Sentinel 3: Homeworld

-- MAIN APPLICATION
addappid(275350)

-- MAIN APP DEPOTS / PACKAGES
addappid(275351, 1, "4af0970a03d78b4db2befdc73f28af445c9c75f71bde31176438e5b1bdfe7bd0")
