-- Lua provided by RyzenAPI
-- Game: Elysium Restaurant

-- MAIN APPLICATION
addappid(2307550)

-- MAIN APP DEPOTS / PACKAGES
addappid(2307551, 1, "70d7d023a1b7c0c7c3960123111ddf3f05223bd41f5b5884263f0eded16e9f16")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
