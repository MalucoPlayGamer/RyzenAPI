-- Lua provided by RyzenAPI 
-- Game: Elysium Restaurant
addappid(2307550)
addappid(2307551, 1, "70d7d023a1b7c0c7c3960123111ddf3f05223bd41f5b5884263f0eded16e9f16")
