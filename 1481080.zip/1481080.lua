-- Lua provided by RyzenAPI
-- Game: DRAMAtical Murder

-- MAIN APPLICATION
addappid(1481080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1481081, 1, "310529d2d801d10414fb757f4c3aeb49c9f9e39cffe02c19acffb6e4bdb7020e")
addappid(1481082, 1, "e60d209e43c1923044e0593947a69821a4f2a4c4c505d2b4ca414dd802b9cabd")
addappid(1481083, 1, "53673c4926d749f24e04d69fcd91569b04e5545418f1d2806784cd8d21e65941")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
