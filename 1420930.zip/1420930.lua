-- Lua provided by RyzenAPI
-- Game: Movavi Slideshow Maker 8

-- MAIN APPLICATION
addappid(1420930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1420931, 1, "b9fff935552ca4aba640643400b1842875ededa879dfc804715e5ef8f4032705")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1451020)
addappid(1451021)
addappid(1451022)
addappid(1451023)
addappid(1451024)
addappid(1784450)
addappid(1784451)
