-- Lua provided by RyzenAPI
-- Game: Into the TIMEVERSE

-- MAIN APPLICATION
addappid(1309850)
-- Game: addappid(1309850)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309851, 1, "05b8e249ca6880882dacc0599976a67daf81dc92d595016d9ededcbede22453b")
