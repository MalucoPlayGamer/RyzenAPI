-- Lua provided by RyzenAPI 
-- Game: Into the TIMEVERSE
addappid(1309850)
addappid(1309851, 1, "05b8e249ca6880882dacc0599976a67daf81dc92d595016d9ededcbede22453b")
