-- Lua provided by RyzenAPI
-- Game: 1861240

-- MAIN APPLICATION
addappid(1861240)
-- Game: addappid(1861240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1861241, 1, "a1d938eb1fd0a6a3771a5216f9a6de1ede13e2c957e5420960ae0bab2b6f620f")
