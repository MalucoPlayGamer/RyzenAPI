-- Lua provided by RyzenAPI
-- Game: Game: AXIOM SOCCER

-- MAIN APPLICATION
addappid(903730)
-- Game: addappid(903730)

-- MAIN APP DEPOTS / PACKAGES
addappid(903731, 1, "eb906fb6cb91afcc6311d26ae651cb3d000741ce78cc1bbd4efee18e86733730")
