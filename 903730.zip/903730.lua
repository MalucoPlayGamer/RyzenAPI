-- Lua provided by RyzenAPI 
-- Game: AXIOM SOCCER
addappid(903730)
addappid(903731, 1, "eb906fb6cb91afcc6311d26ae651cb3d000741ce78cc1bbd4efee18e86733730")
