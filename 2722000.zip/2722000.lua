-- Lua provided by RyzenAPI
-- Game: Game: 我说什么她们都答应（OKeverything）

-- MAIN APPLICATION
addappid(2722000)
-- Game: addappid(2722000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2722001, 1, "f47e2e35ee18b987ae77f57495b50bcb39b8d037f75068dea324f2c06aef46fb")
