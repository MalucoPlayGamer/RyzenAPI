-- Lua provided by RyzenAPI
-- Game: Homicide Desk

-- MAIN APP DEPOTS / PACKAGES
addappid(4935210, 1, "2084cb6dfc463f95db2e84eb25e214c0193df38e9c8b024eea378fd58638494c") -- Homicide Desk
addappid(4935211, 1, "2f5a42c04be053f10fc3a911d41fb10eff5a5edcaf7ceff7dd81fea32caf861b") -- Depot 4935211

