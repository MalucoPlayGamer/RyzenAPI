-- Lua provided by RyzenAPI
-- Game: Super Furball

-- MAIN APPLICATION
addappid(364770)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(364771, 1, "f57b32b5d70237555e34e19609ba48e28c05e9a87704e9748973c3c05af2df11")
