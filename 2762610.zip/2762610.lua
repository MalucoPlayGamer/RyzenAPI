-- Lua provided by RyzenAPI
-- Game: addappid(2762610)

-- MAIN APPLICATION
addappid(2762610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2762611, 1, "ad491f571b39b81615e5ad6d73e0b0cb415168f0e542b8222df27a189b23557d")
