-- Lua provided by SkyAPI 
-- Game: Piranha Feeding
addappid(2762610)
addappid(2762611, 1, "ad491f571b39b81615e5ad6d73e0b0cb415168f0e542b8222df27a189b23557d")
