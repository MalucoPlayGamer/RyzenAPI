-- Lua provided by RyzenAPI
-- Game: Looking for Aliens

-- MAIN APPLICATION
addappid(1733500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1733501, 1, "5cb049d2e891b8012df07d0d339bc72e746a488753edec0272aac1a5cefe53af")
