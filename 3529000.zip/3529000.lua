-- Lua provided by RyzenAPI
-- Game: Phantom Brave: The Lost Hero - Soundtrack

-- MAIN APPLICATION
addappid(3529000)
-- Game: addappid(3529000)

-- MAIN APP DEPOTS / PACKAGES
addappid(3529001, 1, "868121e351eb66dc0267d51384ea462c34002bf206afb3bd22762192b65490cc")
addappid(3529002, 1, "3189247d95428b45463aa85801d7bab96b4a9a1ddc979d5fb2a3b22e68d7d357")
