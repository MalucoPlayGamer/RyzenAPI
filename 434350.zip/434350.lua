-- Lua provided by RyzenAPI
-- Game: 434350

-- MAIN APPLICATION
addappid(434350)

-- MAIN APP DEPOTS / PACKAGES
addappid(434350,0,"86ded3cefc870ad128f544dd4cf283ba868e195c869d48dc6ff15a59afacad96")
