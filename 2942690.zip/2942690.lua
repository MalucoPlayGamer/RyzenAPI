-- Lua provided by RyzenAPI
-- Game: Game: Book of Spells

-- MAIN APPLICATION
addappid(2942690)
-- Game: addappid(2942690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2942691, 1, "4223ef243b5f6ac7dbd754e5046111fb167bae81c681f2a80f242d72fce44d01")
