-- Lua provided by RyzenAPI
-- Game: addappid(1350980)

-- MAIN APPLICATION
addappid(1350980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1350980,0,"57e32c8529ee41c398f284aa0a4e7cf0b850d921ad2883af821fa801e1143ca9")
