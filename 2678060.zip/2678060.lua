-- Lua provided by RyzenAPI
-- Game: Inner Darkness

-- MAIN APPLICATION
addappid(2678060)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2678061, 1, "aeabc9d14a6606362555421f7e9ff76c888c70f09d871f3932042e5ac8a3342b")

