-- Lua provided by RyzenAPI
-- Game: 2678060

-- MAIN APPLICATION
addappid(2678060)
-- Game: addappid(2678060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2678061, 1, "aeabc9d14a6606362555421f7e9ff76c888c70f09d871f3932042e5ac8a3342b")
