-- Lua provided by SkyAPI 
-- Game: AppID 1002290
addappid(1002290)
addappid(1002291, 1, "a3b6a3995b8f33792adf185de9bbf2cb62f927609b9e804773899bb9d761b551")
