-- Lua provided by RyzenAPI
-- Game: AppID 1002290

-- MAIN APPLICATION
addappid(1002290)

-- MAIN APP DEPOTS / PACKAGES
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1002291, 1, "a3b6a3995b8f33792adf185de9bbf2cb62f927609b9e804773899bb9d761b551")

