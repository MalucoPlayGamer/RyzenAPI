-- Lua provided by RyzenAPI
-- Game: Sausage Fiesta

-- MAIN APPLICATION
addappid(1540840)

-- MAIN APP DEPOTS / PACKAGES
addappid(1540841, 1, "b0109c1c80c6d7da57d213c5fd9ae730d770e87e6c5f585e270b83df039b383f")

