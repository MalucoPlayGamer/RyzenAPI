-- Lua provided by RyzenAPI 
-- Game: Viktor, a Steampunk Adventure
addappid(550990)
addappid(550991, 1, "ff1e79099c7a3d653016678e51a50bbe2312ec41f14198ff6b71ae73739e2923")
