-- Lua provided by RyzenAPI
-- Game: Game: AppID 298280

-- MAIN APPLICATION
addappid(298280)
-- Game: addappid(298280)

-- MAIN APP DEPOTS / PACKAGES
addappid(298281, 1, "f73e9ecf17d2ba6951b4da7558cc46a0f6f3fdca3fd2e6aef47e01b8b6e68ad1")
addappid(298282, 1, "4af3a72a45823e6d52711f9a5abb8dab718602a5da8f7c5ff374cadd647214f4")
addappid(298283, 1, "8331fde58c4b641302b4da46aa27452b0a25c309b9adf70354b05ea75c8a0a39")
