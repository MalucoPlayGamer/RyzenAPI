-- Lua provided by SkyAPI 
-- Game: DEATHRUN TV
addappid(1591690)
addappid(1591691, 1, "d355fc2ceedb9dd72bcb9584008af446374b51a8419f8572f095d7a2ec1a1566")
addappid(1591692, 1, "701afb4780d5e16fa54fe6986579fba3109aac22323ddb44c211c0cd92468baf")
addappid(1591693, 1, "a6e9424331d2ffb1d51d5bf186d6766c7e8a732e2d3c1a4fd0b788e86bce69cd")
