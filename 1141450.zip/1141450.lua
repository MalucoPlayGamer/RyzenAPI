-- Lua provided by RyzenAPI
-- Game: addappid(1141450)

-- MAIN APPLICATION
addappid(1141450)

-- MAIN APP DEPOTS / PACKAGES
addappid(1141451, 1, "28311c86eb7d6db0227e4eff8dd6b504a83ccd5f9c307b5372c308021ef90fa3")
