-- Lua provided by RyzenAPI
-- Game: Concentration Required

-- MAIN APPLICATION
addappid(3434070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3434071, 1, "5446c7315ef29d80da4046cd07b805f45aba155d40716ef0df710ada173068d2")
