-- Lua provided by RyzenAPI
-- Game: 2018930

-- MAIN APPLICATION
addappid(2018930)
-- Game: addappid(2018930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2018931, 1, "3032a23c71226838bebab0c8dc32c8f6a0a2a7e388eedb031b8b1d7e9bd6ddb4")
