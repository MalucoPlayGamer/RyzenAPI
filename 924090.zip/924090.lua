-- Lua provided by RyzenAPI
-- Game: Trip in HELL

-- MAIN APPLICATION
addappid(924090)

-- MAIN APP DEPOTS / PACKAGES
addappid(924091, 1, "575230bc1ea838625ec52ed352cef6073a791d36940f09eef5714b0a724de409")
