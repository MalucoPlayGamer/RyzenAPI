-- Lua provided by RyzenAPI 
-- Game: Trip in HELL
addappid(924090)
addappid(924091, 1, "575230bc1ea838625ec52ed352cef6073a791d36940f09eef5714b0a724de409")
