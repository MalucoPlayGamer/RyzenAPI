-- Lua provided by RyzenAPI
-- Game: Trip in HELL

-- MAIN APPLICATION
addappid(924090)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229030, 1, "92f0f88867c8d5f351090eb2d27aeb50e2b621ae8a34708265d2c20c36fbcf5e") -- (windows)
addappid(924091, 1, "575230bc1ea838625ec52ed352cef6073a791d36940f09eef5714b0a724de409")

