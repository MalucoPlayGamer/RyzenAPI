-- Lua provided by RyzenAPI
-- Game: Infinite Crisis™

-- MAIN APPLICATION
addappid(345520)

-- MAIN APP DEPOTS / PACKAGES
addappid(345521, 1, "a206564ac7d2a9b00a02a21348dc1320e47745e5d63470aa4b5a6ebd6af8f20a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(351590)
addappid(351591)
