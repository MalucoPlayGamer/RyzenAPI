-- Lua provided by RyzenAPI
-- Game: addappid(2131780)

-- MAIN APPLICATION
addappid(2131780)

-- MAIN APP DEPOTS / PACKAGES
addappid(2131781, 1, "3ef6fe2ac792efceefef064c0e576a4d370a163b3924a75050e330014327ccb7")
