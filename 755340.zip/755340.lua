-- Lua provided by RyzenAPI
-- Game: Shawy Adventures

-- MAIN APPLICATION
addappid(755340)

-- MAIN APP DEPOTS / PACKAGES
addappid(755341,0,"4aec7d6f6214a527520ba772cd4e019a3e670e58d581b975dcc3d7fd53dcb889")
addappid(755342,0,"0109c99166ea6aaaa507e7b875407e4d74f2951b3c7b97458b30f59334337e63")
addappid(755345,0,"3b7ddac6d4af0e11248c61baeabe8e41a6be7e423a992ff1e841ba8ff2042143")

