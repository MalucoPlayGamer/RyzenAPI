-- Lua provided by RyzenAPI
-- Game: AppID 1028360

-- MAIN APPLICATION
addappid(1028360)
-- Game: addappid(1028360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1028361, 1, "788124e05d7d9b097dffb39369adeeb383225d98c0c2ecab61da5fc298716cac")
