-- Lua provided by SkyAPI 
-- Game: AppID 1175080
addappid(1175080)
addappid(1175081, 1, "82c17b9d6405e3fe95d79ddc6c3db7dd3611c93a5f8593cc870db0895a9198e9")
