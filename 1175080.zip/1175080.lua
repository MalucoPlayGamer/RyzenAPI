-- Lua provided by RyzenAPI
-- Game: AppID 1175080

-- MAIN APPLICATION
addappid(1175080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1175081, 1, "82c17b9d6405e3fe95d79ddc6c3db7dd3611c93a5f8593cc870db0895a9198e9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(1217970)
