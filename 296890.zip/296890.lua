-- Lua provided by RyzenAPI
-- Game: Game: Neon Shadow

-- MAIN APPLICATION
addappid(296890)
-- Game: addappid(296890)

-- MAIN APP DEPOTS / PACKAGES
addappid(296891, 1, "62471f0088a45fea07ad59919a5d5038d379c73aff645c0a861802247fb4c6e0")
