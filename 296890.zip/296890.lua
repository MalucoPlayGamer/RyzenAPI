-- Lua provided by RyzenAPI 
-- Game: Neon Shadow
addappid(296890)
addappid(296891, 1, "62471f0088a45fea07ad59919a5d5038d379c73aff645c0a861802247fb4c6e0")
