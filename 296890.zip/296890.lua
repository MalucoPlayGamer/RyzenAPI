-- Lua provided by RyzenAPI
-- Game: Neon Shadow

-- MAIN APPLICATION
addappid(296890)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(296891, 1, "62471f0088a45fea07ad59919a5d5038d379c73aff645c0a861802247fb4c6e0")

