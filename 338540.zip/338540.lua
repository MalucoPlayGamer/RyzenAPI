-- Lua provided by RyzenAPI
-- Game: AppID 338540

-- MAIN APPLICATION
addappid(338540)
-- Game: addappid(338540)

-- MAIN APP DEPOTS / PACKAGES
addappid(338541, 1, "8ea2500c524b837b4cb33af0942f0a337719af8ba2f14bd89b4e1b0c12c3dc10")
