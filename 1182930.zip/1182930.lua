-- Lua provided by RyzenAPI
-- Game: Game: AppID 1182930

-- MAIN APPLICATION
addappid(1182930)
-- Game: addappid(1182930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182931, 1, "dfe44415b9c9a0a0cd4c43d2627265d9376155578223541e39d5fddf123bb372")
