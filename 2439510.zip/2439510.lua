-- Lua provided by RyzenAPI 
-- Game: Doomsday × FAIRY TAIL
addappid(2439510)
addappid(2439511, 1, "068e8e7132c38ac6e9a6a359f9a50a30a9ddbb5a6174685ed532c174afcbd8e4")
