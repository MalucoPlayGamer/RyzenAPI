-- Lua provided by RyzenAPI
-- Game: addappid(2051500)

-- MAIN APPLICATION
addappid(2051500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2051502,0,"5009e21b6e4262e3f990e6acf8b5c6b5d650d0cf453268cfac2841947c3acf52")
