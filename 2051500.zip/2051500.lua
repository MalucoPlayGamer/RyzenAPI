-- Lua provided by RyzenAPI
-- Game: Soak & Splash

-- MAIN APPLICATION
addappid(2051500)

-- MAIN APP DEPOTS / PACKAGES
addappid(2051502,0,"5009e21b6e4262e3f990e6acf8b5c6b5d650d0cf453268cfac2841947c3acf52")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
