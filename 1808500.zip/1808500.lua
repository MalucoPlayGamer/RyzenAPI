-- Lua provided by RyzenAPI
-- Game: ARC Raiders

-- MAIN APPLICATION
addappid(1808500)
addappid(3948500)
addappid(3948510)
addappid(4048380)
addappid(4210150)
addappid(4424920)
addappid(4741040)
addappid(4920260)

-- MAIN APP DEPOTS / PACKAGES
addappid(1808501,0,"9f7c91d4609594120c713e82bb64d0ebf15c63fdf6887bc2b3f8f20fcf58e005")

