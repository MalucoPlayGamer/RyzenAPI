-- Lua provided by RyzenAPI
-- Game: ARC Raiders

-- MAIN APPLICATION
addappid(1808500)
addappid(3948500)
addappid(3948510)
addappid(4048380)
addappid(4210150)
addappid(4424920)
addappid(4741040)
addappid(4920260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1808501,0,"9f7c91d4609594120c713e82bb64d0ebf15c63fdf6887bc2b3f8f20fcf58e005")

