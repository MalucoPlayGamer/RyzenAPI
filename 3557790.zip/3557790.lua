-- Lua provided by SkyAPI 
-- Game: Vendetta Forever
addappid(3557790)
addappid(3557791, 1, "8747f8b84211dc2c5a0389fc2b865d60bd3b67148496fce228514c9b8626f383")
