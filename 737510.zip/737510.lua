-- Lua provided by RyzenAPI
-- Game: Dead Forest

-- MAIN APPLICATION
addappid(737510)

-- MAIN APP DEPOTS / PACKAGES
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- (windows)
addappid(737511, 1, "68e4a8f694e042454d89adb60cfe0dc243c83d5e7d42c33b2dd305c6a442acf0")

