-- Lua provided by RyzenAPI
-- Game: AppID 737510

-- MAIN APPLICATION
addappid(737510)

-- MAIN APP DEPOTS / PACKAGES
addappid(737511, 1, "68e4a8f694e042454d89adb60cfe0dc243c83d5e7d42c33b2dd305c6a442acf0")
