-- Lua provided by RyzenAPI
-- Game: addappid(1388570)

-- MAIN APPLICATION
addappid(1388570)

-- MAIN APP DEPOTS / PACKAGES
addappid(1388571, 1, "d9c8da7ce9eaf53f6dab84ce7769ffdb38d45b0dc48976de4a4b38547effea03")
