-- Lua provided by RyzenAPI
-- Game: Wéko The Mask Gatherer

-- MAIN APPLICATION
addappid(1682290)
-- Game: addappid(1682290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1682291, 1, "7ec36c96269ba0b460a53d5958a9ca9e5c0669e5e0f64a20708316dd86132029")
