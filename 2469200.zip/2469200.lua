-- Lua provided by RyzenAPI
-- Game: Fera: The Sundered Tribes

-- MAIN APPLICATION
addappid(2469200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2469201, 1, "0ada1a9770079555c3f9ad8a2cd2508dac8502289b51f41d4ce4a3b05ff05c93")

