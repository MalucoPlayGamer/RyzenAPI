-- Lua provided by RyzenAPI
-- Game: Fera: The Sundered Tribes

-- MAIN APPLICATION
addappid(2469200)

-- MAIN APP DEPOTS / PACKAGES
addappid(2469201, 1, "0ada1a9770079555c3f9ad8a2cd2508dac8502289b51f41d4ce4a3b05ff05c93")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
