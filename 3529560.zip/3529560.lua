-- Lua provided by RyzenAPI
-- Game: addappid(3529560)

-- MAIN APPLICATION
addappid(3529560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3529561, 1, "d4c38f9949d0774fafa8e57fb89da3d373a0edad7350e0b5e703666206343caa")
