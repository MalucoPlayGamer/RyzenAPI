-- Lua provided by RyzenAPI
-- Game: VoiceATC Simulator

-- MAIN APPLICATION
addappid(3529560)

-- MAIN APP DEPOTS / PACKAGES
addappid(3529561, 1, "d4c38f9949d0774fafa8e57fb89da3d373a0edad7350e0b5e703666206343caa")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
