-- Lua provided by RyzenAPI
-- Game: 反转21克 Demo

-- MAIN APPLICATION
addappid(2762140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2762141, 1, "f7d5e3f88b03801f6c98a094ee33643601c3ba3ef012f8c9a18feab5bbc25e13")

