-- Lua provided by RyzenAPI
-- Game: The Story of My Life

-- MAIN APPLICATION
addappid(917610)
-- Game: addappid(917610)

-- MAIN APP DEPOTS / PACKAGES
addappid(917611, 1, "74fb92b5de050c9b338b1823a0f29721d7d7c7fee762b6fffc249d6737caaeb6")
