-- Lua provided by RyzenAPI
-- Game: Whisker Squadron: Survivor

-- MAIN APPLICATION
addappid(2140100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2140101, 1, "df2b2bf36213c7f69ec5bc5f61c2924d563359db12b69c2f061a2cd2e61b3c97")



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(2666630)
