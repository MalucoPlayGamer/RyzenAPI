-- Lua provided by RyzenAPI
-- Game: MegaFactory Titan

-- MAIN APPLICATION
addappid(1803550)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- (windows)
addappid(1803551, 1, "38c6ceefea1d6ebdb69e27c29b2e0f7399b4aa22919e878c398cd4bb12c96fa0")
addappid(1803552, 1, "fcd44ccb1b455e06dd15dc2f310238672b329147d8646fb4dbe793685123109e")
addappid(1803553, 1, "6e552a20c0ff53349ac8083eaa963b3b27f22091ca1c66680f674c65664ff531")

