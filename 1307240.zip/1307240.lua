-- Lua provided by RyzenAPI
-- Game: 1307240

-- MAIN APPLICATION
addappid(1307240)
-- Game: addappid(1307240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1307241, 1, "e13ca4f5a679989a6d5d47837b6d13bf6e02fd377ff51b92725c8532db2fff6a")
