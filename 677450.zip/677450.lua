-- Lua provided by RyzenAPI
-- Game: Medieval Shopkeeper Simulator

-- MAIN APPLICATION
addappid(677450)
-- Game: addappid(677450)

-- MAIN APP DEPOTS / PACKAGES
addappid(677451, 1, "9358b82d0069974468f40a889ad8cc7514f2a899c50b417859707258c973658e")
