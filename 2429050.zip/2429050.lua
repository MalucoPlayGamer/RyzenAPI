-- Lua provided by RyzenAPI
-- Game: addappid(2429050)

-- MAIN APPLICATION
addappid(2429050)

-- MAIN APP DEPOTS / PACKAGES
addappid(2429051, 1, "4f1e7142a2497f0428cee5e8d6d4a924e045d14557f49467637fb94a5a0fbd96")
