-- Lua provided by RyzenAPI
-- Game: Academagia: The Making of Mages

-- MAIN APPLICATION
addappid(533480)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(533481, 1, "29932b133e4a657d0d73aa923d256373c365ecaf1dd8ea25eccecc96f3c7f7a5")

