-- Lua provided by RyzenAPI
-- Game: Academagia: The Making of Mages

-- MAIN APPLICATION
addappid(533480)
-- Game: addappid(533480)

-- MAIN APP DEPOTS / PACKAGES
addappid(533481, 1, "29932b133e4a657d0d73aa923d256373c365ecaf1dd8ea25eccecc96f3c7f7a5")
