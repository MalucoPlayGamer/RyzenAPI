-- Lua provided by RyzenAPI
-- Game: The Line of Defense

-- MAIN APPLICATION
addappid(3348570)

-- MAIN APP DEPOTS / PACKAGES
addappid(3348571, 1, "dbd64a611d4d392d9ff869883bdf48d06f6f484bd8b9a12246eeb662fbd4d7d1")

