-- Lua provided by SkyAPI 
-- Game: SGS Okinawa
addappid(2128770)
addappid(2128771, 1, "d8e3df1cc3734f276af71ed798eb0879d68a87d99167a47a8c04d7426752355f")
addappid(2128773, 1, "641d8109ea754e81f9bd81f6bc40e4bbd575207980dd83fee71772dc29713533")
