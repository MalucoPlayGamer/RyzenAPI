-- Lua provided by RyzenAPI
-- Game: Sector 598

-- MAIN APPLICATION
addappid(2296080)
-- Game: addappid(2296080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2296081, 1, "17497bb91780a7240c026376c01e435b30f7c5d37aa76e44a2cc68a4fd5f1f27")
