-- Lua provided by RyzenAPI
-- Game: 3074440

-- MAIN APPLICATION
addappid(3074440)
-- Game: addappid(3074440)

-- MAIN APP DEPOTS / PACKAGES
addappid(3074441, 1, "5516bf02d84498a85f3932c20e16e9ae970606b302c1edcd65231bd599a7e6eb")
