-- Lua provided by RyzenAPI
-- Game: AppID 578260

-- MAIN APPLICATION
addappid(578260)
-- Game: addappid(578260)

-- MAIN APP DEPOTS / PACKAGES
addappid(578261, 1, "1325d3f317f5c80025117b412c2ec226551c0e8282b8a635aaeda1d6c360e8b2")
