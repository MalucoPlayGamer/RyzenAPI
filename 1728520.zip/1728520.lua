-- Lua provided by RyzenAPI 
-- Game: Xuan-Yuan Sword V
addappid(1728520)
addappid(1728521, 1, "6b4369bdef8d5c222b6fd7ae61d1b3e34808222502ea759c90a2f159df2ddfbc")
addappid(1728522, 1, "ff17f63a417ab8ea371bbf40e66f46ced8949f53b6c34f4209cc5ca248bf1005")
