-- Lua provided by RyzenAPI 
-- Game: Yupitergrad 🚀(Virtual Reality Adventure)
addappid(1352020)
addappid(1352021, 1, "e1d60ae2e8a0a763d0b006842a4a0a3a45b96ccb8a14c743c7512d9742e9ab5f")
