-- Lua provided by RyzenAPI
-- Game: Space Engineers Deluxe

-- MAIN APPLICATION
addappid(573160)

-- MAIN APP DEPOTS / PACKAGES
addappid(573160,0,"90b858382780b17809d769a3c519d42315dec52ac14f62cc36a730028c8c2d55")
