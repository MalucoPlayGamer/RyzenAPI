-- Lua provided by RyzenAPI
-- Game: Enigmatis: The Ghosts of Maple Creek

-- MAIN APPLICATION
addappid(284750)

-- MAIN APP DEPOTS / PACKAGES
addappid(284751, 1, "ddc56be0db90b80d724b4a0029611ef0f75123ada26e88ad831795826c842b4c")
addappid(284752, 1, "7a57dd954320a1827fddcf48739554685bed2158fc5dec1060ec55f69734a309")
addappid(284753, 1, "e97290edc33a2a42c941decb03438a5817206c05092319e106935f0a82d4c822")

