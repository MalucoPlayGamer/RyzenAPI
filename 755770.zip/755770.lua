-- Lua provided by RyzenAPI
-- Game: YouTube VR

-- MAIN APPLICATION
addappid(755770)

-- MAIN APP DEPOTS / PACKAGES
addappid(755771, 1, "f664d66487f6c3945924aef7798376fe8c187edd208efa14ce2160a53563324f")

