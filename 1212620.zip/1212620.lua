-- Lua provided by RyzenAPI
-- Game: Game: Pretty Neko

-- MAIN APPLICATION
addappid(1212620)
-- Game: addappid(1212620)

-- MAIN APP DEPOTS / PACKAGES
addappid(1212621, 1, "c36e8b3af61a43387ffd06480abe9120dcad173a3d65e9e1dd19db993ac52cac")
addappid(1212622, 1, "f277724c87063e8bce41acc645296e6ddaa78de5a4515860aa34b3658a2a5354")
addappid(1217890, 0, "3ac0659221661269738521094cea38fc8c7ff2299b95258300204a946a3b9b35")
addappid(1217891, 0, "3bda5b1891dad0b765b85a5f131f80a6c55588f3a48aadc8e9a2ec3eec03b903")
