-- Lua provided by RyzenAPI
-- Game: The Rake Sees You

-- MAIN APPLICATION
addappid(4585260)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(4585261,0,"3f10fc62934db57cdaa25affeb7068a900aeb7a79756362c29b39cd1389c8862")

