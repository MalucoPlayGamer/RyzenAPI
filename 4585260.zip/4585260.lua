-- Lua provided by RyzenAPI
-- Game: The Rake Sees You

-- MAIN APPLICATION
addappid(4585260)

-- MAIN APP DEPOTS / PACKAGES
addappid(4585261,0,"3f10fc62934db57cdaa25affeb7068a900aeb7a79756362c29b39cd1389c8862")

