-- Lua provided by RyzenAPI
-- Game: Achromatic

-- MAIN APPLICATION
addappid(926170)
-- Game: addappid(926170)

-- MAIN APP DEPOTS / PACKAGES
addappid(926171, 1, "a94654a5a60d494dbcdb409ae28b2c85f249f0c0798a69f27a1c84613e7dc585")
