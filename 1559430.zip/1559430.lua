-- Lua provided by RyzenAPI
-- Game: 1559430

-- MAIN APPLICATION
addappid(1559430)
-- Game: addappid(1559430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1559431, 1, "028eee584672c960e435bd2f7bfc012238417bb3fa55dbf9ff556c47691822b2")
