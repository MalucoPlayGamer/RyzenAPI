-- Lua provided by SkyAPI 
-- Game: Heart Electric Playtest
addappid(3022070)
addappid(3022071, 1, "01d85ce9abc50da60519d13f4a804e3dd9ef4ed13d392deb91cfb2fbd8a630a0")
