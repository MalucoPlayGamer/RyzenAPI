-- Lua provided by RyzenAPI
-- Game: addappid(3022070)

-- MAIN APPLICATION
addappid(3022070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3022071, 1, "01d85ce9abc50da60519d13f4a804e3dd9ef4ed13d392deb91cfb2fbd8a630a0")
