-- Lua provided by RyzenAPI 
-- Game: Welcome to Basingstoke
addappid(336940)
addappid(336941, 1, "d55e3f9bab23530a488d37443f0989b64af896d87a922f1686c01f71ff52c82d")
addappid(336942, 1, "70278f2c86b1a64d793b072294a4ddbd1aba354e00d0e8660997fc4bd99549cf")
addappid(336943, 1, "8eed15c4655e4efbdf8e749e3971b96409d3b70b69b1e1062fdba70dc3faf551")
