-- Lua provided by RyzenAPI
-- Game: 3779670

-- MAIN APPLICATION
addappid(3779670)
-- Game: addappid(3779670)

-- MAIN APP DEPOTS / PACKAGES
addappid(3779672,0,"dfdfa7733cf5b9c66f0364660f4149dc93dd9a2efc116580ce86ada190993e94")
