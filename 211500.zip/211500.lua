-- Lua provided by RyzenAPI
-- Game: RaceRoom Racing Experience

-- MAIN APPLICATION
addappid(211500)

-- MAIN APP DEPOTS / PACKAGES
addappid(211501, 1, "34fa6e78a3a214e7e5ff6dc1b445ed0e41ec550f955c972325b6e2f34b986752")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(272770)
addappid(331800)
addappid(332120)
addappid(336270)
addappid(376360)
addappid(408220)
addappid(422670)
addappid(455270)
addappid(455280)
