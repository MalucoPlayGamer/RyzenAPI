-- Lua provided by RyzenAPI
-- Game: RaceRoom Racing Experience

-- MAIN APPLICATION
addappid(211500)

-- MAIN APP DEPOTS / PACKAGES
addappid(211501, 1, "34fa6e78a3a214e7e5ff6dc1b445ed0e41ec550f955c972325b6e2f34b986752")

