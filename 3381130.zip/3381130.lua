-- Lua provided by RyzenAPI
-- Game: World of Eggs: Idle Adventures

-- MAIN APPLICATION
addappid(3381130)



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5036300)
