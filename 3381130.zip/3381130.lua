-- Lua provided by RyzenAPI
-- Game: World of Eggs: Idle Adventures

-- MAIN APPLICATION
addappid(3381130)
addappid(5036300)

