-- Lua provided by RyzenAPI
-- Game: 215821

-- MAIN APPLICATION
addappid(215821)
-- Game: addappid(215821)

-- MAIN APP DEPOTS / PACKAGES
addappid(215821,0,"57730cee015383d7ac532ad4f010a3c2804957c779c2affc3cdff29aaa989915")
