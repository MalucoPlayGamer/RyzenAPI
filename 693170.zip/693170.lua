-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(693170)

-- MAIN APP DEPOTS / PACKAGES
addappid(693170,0,"adea15b721efc1cb7181fb4bcc79e98944a8bf5a1f377a24ed1e96fe01cba53a")

