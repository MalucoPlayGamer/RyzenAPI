-- Lua provided by RyzenAPI
-- Game: Sam & Max 303: They Stole Max's Brain!

-- MAIN APPLICATION
addappid(31240)

-- MAIN APP DEPOTS / PACKAGES
addappid(31241, 1, "d96f9f3b7393365024c4408426ad9c46b7a97a11134f155f8f895ed3031c5f7f")
addappid(31242, 1, "4e2135459ac00a5b6aa56afd33e59ab43265810e1aac4ba999556181af2a1b7f")

