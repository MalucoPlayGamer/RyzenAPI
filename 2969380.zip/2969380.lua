-- Lua provided by SkyAPI 
-- Game: BAKERU
addappid(2969380)
addappid(2969381, 1, "c0f097f8c53a4949eb0d5243a797381b1358f5310f8a9c66f1751b9d7af1c5be")
