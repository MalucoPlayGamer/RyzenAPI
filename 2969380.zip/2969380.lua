-- Lua provided by RyzenAPI
-- Game: BAKERU

-- MAIN APPLICATION
addappid(2969380)
-- Game: addappid(2969380)

-- MAIN APP DEPOTS / PACKAGES
addappid(2969381, 1, "c0f097f8c53a4949eb0d5243a797381b1358f5310f8a9c66f1751b9d7af1c5be")
