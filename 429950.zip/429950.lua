-- Lua provided by RyzenAPI
-- Game: ABO MANDO

-- MAIN APPLICATION
addappid(429950)
-- Game: addappid(429950)

-- MAIN APP DEPOTS / PACKAGES
addappid(429951, 1, "7344a8eb832c3b8fb038041bb4c4d172aa21946672b09dcea192e35e52e640ef")
