-- Lua provided by RyzenAPI
-- Game: ABO MANDO

-- MAIN APPLICATION
addappid(429950)

-- MAIN APP DEPOTS / PACKAGES
addappid(429951, 1, "7344a8eb832c3b8fb038041bb4c4d172aa21946672b09dcea192e35e52e640ef")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
