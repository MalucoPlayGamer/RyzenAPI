-- Lua provided by RyzenAPI
-- Game: addappid(1182270)

-- MAIN APPLICATION
addappid(1182270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1182270,0,"f71d7250e30a785f73e443ecad4457f4f3211cad6caaab610d9320aa0bd77a24")
