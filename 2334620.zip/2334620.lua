-- Lua provided by RyzenAPI
-- Game: addappid(2334620)

-- MAIN APPLICATION
addappid(2334620)

-- MAIN APP DEPOTS / PACKAGES
addappid(2334621, 1, "b67daa173df2b1c39bca2bf38af22cc0e48610fa18ec22933ef75ccd3f92beaa")
