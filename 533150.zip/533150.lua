-- Lua provided by RyzenAPI
-- Game: 533150

-- MAIN APPLICATION
addappid(533150)
-- Game: addappid(533150)

-- MAIN APP DEPOTS / PACKAGES
addappid(533151, 1, "253e25d2c7a548a3a552c17ae3c82b3c4e3d0b1da7c2bc70d16d07cfc96182f3")
