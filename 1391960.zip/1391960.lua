-- Lua provided by RyzenAPI
-- Game: Star Island

-- MAIN APPLICATION
addappid(1391960)

-- MAIN APP DEPOTS / PACKAGES
addappid(1391961, 1, "710cb1027d6293e1e31b71b247663fa0280b4b188d4591aab5f6129bb5ffdad1")

