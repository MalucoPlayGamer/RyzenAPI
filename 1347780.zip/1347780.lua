-- Lua provided by RyzenAPI
-- Game: Freedom Fighters

-- MAIN APPLICATION
addappid(1347780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347781, 1, "a2d3c4797e4e57f8c9c3a2229ee3c0a9bd8e3befb3cc7c61fbb5fe8271f4b1b4")

