-- Lua provided by RyzenAPI
-- Game: Freedom Fighters

-- MAIN APPLICATION
addappid(1347780)

-- MAIN APP DEPOTS / PACKAGES
addappid(1347781, 1, "a2d3c4797e4e57f8c9c3a2229ee3c0a9bd8e3befb3cc7c61fbb5fe8271f4b1b4")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
