-- Lua provided by SkyAPI 
-- Game: DynamicsBrushes
addappid(2863030)
addappid(2863031, 1, "7fa1386484cc3579de50addde521f01fffdacebbff8e3a3653270c9da7b240e4")
