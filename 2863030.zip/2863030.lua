-- Lua provided by RyzenAPI
-- Game: DynamicsBrushes

-- MAIN APPLICATION
addappid(2863030)
-- Game: addappid(2863030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2863031, 1, "7fa1386484cc3579de50addde521f01fffdacebbff8e3a3653270c9da7b240e4")
