-- Lua provided by RyzenAPI
-- Game: Infinity Imperium

-- MAIN APPLICATION
addappid(1309730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1309731, 1, "8787930e85152ad9d484708e69644b6c4f1e33473d0d99b1cf6eb23ccab08fde")
