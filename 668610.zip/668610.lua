-- Lua provided by RyzenAPI
-- Game: Lords of War

-- MAIN APPLICATION
addappid(668610)
-- Game: addappid(668610)

-- MAIN APP DEPOTS / PACKAGES
addappid(668611, 1, "10f60768850c0e0f4f6266f972ac72c5774a474db924216262b34614cdc30b84")
