-- Lua provided by RyzenAPI
-- Game: Girlfriend from Hell Demo

-- MAIN APPLICATION
addappid(2801680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2801681, 1, "ac3e833a61f29efa70a726afd1647359db8550ee63e45f02b0ed15b464f495c8")

