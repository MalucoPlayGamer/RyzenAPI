-- Lua provided by SkyAPI 
-- Game: Girlfriend from Hell Demo
addappid(2801680)
addappid(2801681, 1, "ac3e833a61f29efa70a726afd1647359db8550ee63e45f02b0ed15b464f495c8")
