-- Lua provided by RyzenAPI
-- Game: 1828320

-- MAIN APPLICATION
addappid(1828320)
-- Game: addappid(1828320)

-- MAIN APP DEPOTS / PACKAGES
addappid(1828321, 1, "2d0d68025c06e2ea5fbf36588df50c4ce7a48e3ea4d3351191b92c7c40d2846f")
