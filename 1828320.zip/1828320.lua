-- Lua provided by RyzenAPI
-- Game: Super Life: Franchise Lord

-- MAIN APPLICATION
addappid(1828320)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(1828321, 1, "2d0d68025c06e2ea5fbf36588df50c4ce7a48e3ea4d3351191b92c7c40d2846f")

