-- Lua provided by RyzenAPI
-- Game: Backrooms: Missing Persons

-- MAIN APPLICATION
addappid(3960200)

-- MAIN APP DEPOTS / PACKAGES
addappid(3960201,0,"3a05e1f099fb481916a3f146f4ba3de05f8cd0971224dffa1d3e860f76e2e387")

