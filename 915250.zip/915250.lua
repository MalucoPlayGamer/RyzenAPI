-- Lua provided by RyzenAPI
-- Game: addappid(915250)

-- MAIN APPLICATION
addappid(915250)

-- MAIN APP DEPOTS / PACKAGES
addappid(915251, 1, "0e6d7ed6614dc91af2caf8b6c152d6e758001623ad1729f7b1ae6579a8e34619")
