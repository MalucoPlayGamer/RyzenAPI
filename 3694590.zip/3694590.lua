-- Lua provided by RyzenAPI
-- Game: 3694590

-- MAIN APPLICATION
addappid(3694590)
-- Game: addappid(3694590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3694591, 1, "cd6288e2bd4dc656e19524c8d8a25c37396bda438ccc4469436f383d44aff446")
