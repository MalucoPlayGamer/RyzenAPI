-- Lua provided by RyzenAPI
-- Game: Haunted Room : 205

-- MAIN APPLICATION
addappid(3694590)

-- MAIN APP DEPOTS / PACKAGES
addappid(3694591, 1, "cd6288e2bd4dc656e19524c8d8a25c37396bda438ccc4469436f383d44aff446")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
