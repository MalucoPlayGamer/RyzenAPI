-- Lua provided by RyzenAPI
-- Game: Ship Of Mist

-- MAIN APPLICATION
addappid(3343390)
-- Game: addappid(3343390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3343391, 1, "7836bb90685eb0be5328b00fdc48e2b02c226cc888926bb0b9f5298a7aeb3278")
