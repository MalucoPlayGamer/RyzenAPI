-- Lua provided by RyzenAPI 
-- Game: Ship Of Mist
addappid(3343390)
addappid(3343391, 1, "7836bb90685eb0be5328b00fdc48e2b02c226cc888926bb0b9f5298a7aeb3278")
