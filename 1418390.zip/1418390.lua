-- Lua provided by RyzenAPI
-- Game: Antipaint

-- MAIN APPLICATION
addappid(1418390)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418391, 1, "43f9493ceb5366d61420d638812084c33228a194a1d8236bc20fc8de24de25cc")
