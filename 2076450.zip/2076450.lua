-- Lua provided by RyzenAPI
-- Game: Game: Freenergy

-- MAIN APPLICATION
addappid(2076450)
-- Game: addappid(2076450)

-- MAIN APP DEPOTS / PACKAGES
addappid(2076451, 1, "8ac249ae1ffd403dc6b1ebea05e78b8b32a0eed80a9869d71b7aebabbbd94e88")
