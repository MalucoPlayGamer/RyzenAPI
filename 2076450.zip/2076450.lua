-- Lua provided by SkyAPI 
-- Game: Freenergy
addappid(2076450)
addappid(2076451, 1, "8ac249ae1ffd403dc6b1ebea05e78b8b32a0eed80a9869d71b7aebabbbd94e88")
