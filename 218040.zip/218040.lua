-- Lua provided by RyzenAPI
-- Game: Democracy 2

-- MAIN APPLICATION
addappid(218040)
-- Game: addappid(218040)

-- MAIN APP DEPOTS / PACKAGES
addappid(218041, 1, "85fffde7e17ae52506a341777f6ae59ec62bc7981782c4d2523486a0d2e9f266")
addappid(218042, 1, "a34c520cc7c94c981978afcb8c92ecc444104377d60083e7916b0663a273cb29")
