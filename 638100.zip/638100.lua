-- Lua provided by RyzenAPI
-- Game: Game: AppID 638100

-- MAIN APPLICATION
addappid(638100)
-- Game: addappid(638100)

-- MAIN APP DEPOTS / PACKAGES
addappid(638101, 1, "30c7c3e5289aa263284bb45569bcc84aaacd4a8f2452012f92ec66e7a79b7bc8")
addappid(638102, 1, "3bbe3abb65d912a1efbfd5e51a824cc55f8581a4c84c89b1693955fe6586311d")
addappid(638103, 1, "96eab6710a0a031281ee4c59a516007a0dd6b42124520e3bdfed581f0f222e03")
