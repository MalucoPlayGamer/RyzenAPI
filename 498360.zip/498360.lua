-- Lua provided by RyzenAPI
-- Game: addappid(498360)

-- MAIN APPLICATION
addappid(498360)

-- MAIN APP DEPOTS / PACKAGES
addappid(498361, 1, "3a81d5fa0fc7fbc20482372ef1ee251bfa8f5f4b7211cb49fff8349309604e10")
