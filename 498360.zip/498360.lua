-- Lua provided by SkyAPI 
-- Game: Puzzle Nebula
addappid(498360)
addappid(498361, 1, "3a81d5fa0fc7fbc20482372ef1ee251bfa8f5f4b7211cb49fff8349309604e10")
