-- Lua provided by RyzenAPI
-- Game: Puzzle Nebula

-- MAIN APPLICATION
addappid(498360)

-- MAIN APP DEPOTS / PACKAGES
addappid(498361, 1, "3a81d5fa0fc7fbc20482372ef1ee251bfa8f5f4b7211cb49fff8349309604e10")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
