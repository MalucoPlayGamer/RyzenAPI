-- Lua provided by RyzenAPI
-- Game: 792640

-- MAIN APPLICATION
addappid(792640)
-- Game: addappid(792640)

-- MAIN APP DEPOTS / PACKAGES
addappid(792641, 1, "899d485a437f6b6ddc66631f5834ea31fee80402d2aeaf341036ffc11e4a6699")
