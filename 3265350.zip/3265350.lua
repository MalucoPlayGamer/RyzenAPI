-- Lua provided by RyzenAPI
-- Game: 虚谷 Demo

-- MAIN APPLICATION
addappid(3265350)

-- MAIN APP DEPOTS / PACKAGES
addappid(3265351, 1, "f4462882b1ea73871ca9d1fd903ecd81ef72dde32d4355669410eb95ebaca08c")

