-- Lua provided by RyzenAPI
-- Game: Five Nations Demo

-- MAIN APPLICATION
addappid(1568370)
-- Game: addappid(1568370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1568371, 1, "8687acca8b503db5c13dbbed9966505090da0d1ca80e1b36fbb9ff43b541c295")
