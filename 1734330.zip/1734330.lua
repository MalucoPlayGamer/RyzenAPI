-- Lua provided by RyzenAPI
-- Game: 1734330

-- MAIN APPLICATION
addappid(1734330)
-- Game: addappid(1734330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1734331, 1, "d08b8902525b7ba42f85928bda87758351070f2319b22d3bf02bc1811d1cfaf2")
