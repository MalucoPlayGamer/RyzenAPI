-- Lua provided by RyzenAPI 
-- Game: POWERTRIP
addappid(1734330)
addappid(1734331, 1, "d08b8902525b7ba42f85928bda87758351070f2319b22d3bf02bc1811d1cfaf2")
