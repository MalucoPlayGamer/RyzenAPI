-- Lua provided by RyzenAPI
-- Game: Lemon vs. Teddy

-- MAIN APPLICATION
addappid(1803290)

-- MAIN APP DEPOTS / PACKAGES
addappid(1803291, 1, "51038b8ca06b2dfcf02a5ec3bfe00f8b74555173dc2bc4f67c5c9751b10c4aff")
