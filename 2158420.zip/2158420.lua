-- Lua provided by RyzenAPI
-- Game: 2158420

-- MAIN APPLICATION
addappid(2158420)
-- Game: addappid(2158420)

-- MAIN APP DEPOTS / PACKAGES
addappid(2158421, 1, "8df13f7b1d664b1199e196e6e7e6b7439806d7e56aa234fda30fbe12b73328cc")
