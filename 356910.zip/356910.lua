-- Lua provided by RyzenAPI
-- Game: Battle Fantasia -Revised Edition-

-- MAIN APPLICATION
addappid(356910)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(356911, 1, "7f4375ab07fbba8a07e79a1bec4a7f887b853cb3187cd95af4eb546283985bb1")
addappid(383990, 0, "c01b569d339e37f7040d9114cecd45162356d5f6c72c3b1499c5b13f4ff0bf7d")

