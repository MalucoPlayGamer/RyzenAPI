-- Lua provided by SkyAPI 
-- Game: Battle Fantasia -Revised Edition-
addappid(356910)
addappid(356911, 1, "7f4375ab07fbba8a07e79a1bec4a7f887b853cb3187cd95af4eb546283985bb1")
addappid(383990, 0, "c01b569d339e37f7040d9114cecd45162356d5f6c72c3b1499c5b13f4ff0bf7d")
