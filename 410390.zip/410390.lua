-- Lua provided by RyzenAPI
-- Game: Warhammer: Vermintide VR - Hero Trials

-- MAIN APPLICATION
addappid(410390)
addappid(566960)
addappid(569730)

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- (windows)
addappid(410391, 1, "49624449728e83f85d84ff0aff11fad1f3643684846975121daf46b3fe788ac0")
