-- Lua provided by RyzenAPI
-- Game: AppID 410390

-- MAIN APPLICATION
addappid(410390)
-- Game: addappid(410390)

-- MAIN APP DEPOTS / PACKAGES
addappid(410391, 1, "49624449728e83f85d84ff0aff11fad1f3643684846975121daf46b3fe788ac0")
