-- Lua provided by RyzenAPI
-- Game: Game: Seed of the Dead: Sweet Home Theme Songs

-- MAIN APPLICATION
addappid(1724110)
-- Game: addappid(1724110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1724111, 1, "d7596ab7ec3ea53fd41602d6fce180db5611dcfc95097a0b82ffb48039b5c438")
addappid(1724112, 1, "ced4195af016893eb6c33c44f9c5afd0cbe7dfa1a4026ddcb6e069a1d6f8ce9d")
