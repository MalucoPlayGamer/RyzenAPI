-- Lua provided by RyzenAPI
-- Game: You Can(Not) Survive

-- MAIN APPLICATION
addappid(976340)

-- MAIN APP DEPOTS / PACKAGES
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(976341, 1, "f7f4c3aefa20dd78c87f9e341ecc7589bbffdecc331100abff0dd96e91c724bb")

