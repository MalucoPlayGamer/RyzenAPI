-- Lua provided by RyzenAPI
-- Game: You Can(Not) Survive

-- MAIN APPLICATION
addappid(976340)
-- Game: addappid(976340)

-- MAIN APP DEPOTS / PACKAGES
addappid(976341, 1, "f7f4c3aefa20dd78c87f9e341ecc7589bbffdecc331100abff0dd96e91c724bb")
