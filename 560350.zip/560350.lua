-- Lua provided by RyzenAPI
-- Game: addappid(560350)

-- MAIN APPLICATION
addappid(560350)

-- MAIN APP DEPOTS / PACKAGES
addappid(560351, 1, "f495ff7cafc73ceaa39689de1c96e893c42febb7961f77e71df2087527b8aed9")
