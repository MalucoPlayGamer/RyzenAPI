-- Lua provided by RyzenAPI
-- Game: addappid(1122200)

-- MAIN APPLICATION
addappid(1122200)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122200,0,"7ee1c6c2ee9305a1aaa75b891e06349d47c6fa2610e622b825b6d98ed3983b07")
