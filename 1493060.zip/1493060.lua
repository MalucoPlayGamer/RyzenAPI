-- Lua provided by RyzenAPI
-- Game: Game: Immortal Legacy: The Jade Cipher[VR]

-- MAIN APPLICATION
addappid(1493060)
-- Game: addappid(1493060)

-- MAIN APP DEPOTS / PACKAGES
addappid(1493061, 1, "7fc77967700ba3a9545a17c5eacc16df02e000b23d708232199946dd0ec2e560")
