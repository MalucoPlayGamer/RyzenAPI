-- Lua provided by RyzenAPI
-- Game: Game: The Quest

-- MAIN APPLICATION
addappid(428880)
addappid(459750)
-- Game: addappid(428880)

-- MAIN APP DEPOTS / PACKAGES
addappid(428881, 1, "d82046b7068287d73813e21d3f7e44bc608cbba2d0200a344b5150cdbf204233")
addappid(428882, 1, "b1ad63e46e5398427072f833f5dff2ae6444fbebc039cdd19dd2e885300080e2")
addappid(430050, 0, "8697dee6f86dd8378a8aa35e77af88399c8bf4b19f060d5779a0f1e532ff51d2")
