-- Lua provided by RyzenAPI
-- Game: Our Hero! Two

-- MAIN APPLICATION
addappid(1408050)

-- MAIN APP DEPOTS / PACKAGES
addappid(1408051, 1, "e3a3a3e1bf0d9b15ac7d4ed569816f7e0b774892cdcb853805b61a3889c4acaf")

