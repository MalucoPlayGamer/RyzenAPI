-- Lua provided by RyzenAPI
-- Game: addappid(1904120)

-- MAIN APPLICATION
addappid(1904120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1904121, 1, "e6d67babac3beebd8f44a013e448b5b177c01a35adfb1d847081fa5eb27d8534")
