-- Lua provided by RyzenAPI
-- Game: Princess Survivors

-- MAIN APPLICATION
addappid(2347030)

-- MAIN APP DEPOTS / PACKAGES
addappid(2347031, 1, "af64bfd8050554caa16406a39eeef3b065af87d362982d48311096d19c46c3e3")
addappid(2507360, 0, "c5fb8d84501191ab7a087f28a65ffe997591458b8a2630fbab36e95b4bd82c6c")

