-- Lua provided by RyzenAPI
-- Game: addappid(458290)

-- MAIN APPLICATION
addappid(458290)

-- MAIN APP DEPOTS / PACKAGES
addappid(458291, 1, "8d3f6e61377c9fb630177630f65c0d4e0d0e66ca152743614b98d8df262bbdc3")
