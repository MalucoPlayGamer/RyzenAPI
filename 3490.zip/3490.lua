-- Lua provided by RyzenAPI
-- Game: Game: Venice Deluxe

-- MAIN APPLICATION
addappid(3490)
-- Game: addappid(3490)

-- MAIN APP DEPOTS / PACKAGES
addappid(3491, 1, "0878b5908f65cab865df68ca09dc38cd0c1f1db565f96f71a80dd9a7b91d9e42")
