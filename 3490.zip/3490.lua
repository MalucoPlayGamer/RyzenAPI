-- Lua provided by SkyAPI 
-- Game: Venice Deluxe
addappid(3490)
addappid(3491, 1, "0878b5908f65cab865df68ca09dc38cd0c1f1db565f96f71a80dd9a7b91d9e42")
