-- Lua provided by RyzenAPI
-- Game: 1245980

-- MAIN APPLICATION
addappid(1245980)
-- Game: addappid(1245980)

-- MAIN APP DEPOTS / PACKAGES
addappid(1245981, 1, "7ddf03e710ca12f4be300e9eaf6c1c7497cd08ad450d169ebca45b0479eb3d64")
