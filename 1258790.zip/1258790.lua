-- Lua provided by RyzenAPI
-- Game: 1258790

-- MAIN APPLICATION
addappid(1258790)
-- Game: addappid(1258790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1258791, 1, "c76dd8403587738d8a5ca9f4f99337b686a0c89c9eeffd34402b6b020efca626")
