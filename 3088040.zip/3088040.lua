-- Lua provided by RyzenAPI
-- Game: 3088040

-- MAIN APPLICATION
addappid(3088040)
-- Game: addappid(3088040)

-- MAIN APP DEPOTS / PACKAGES
addappid(3088041, 1, "5b847e9de036b30d1f9220c86b2cc8768dded910ec7cc549a18668eefbfea2b5")
