-- Lua provided by RyzenAPI
-- Game: AppID 504750

-- MAIN APPLICATION
addappid(504750)

-- MAIN APP DEPOTS / PACKAGES
addappid(504751, 1, "4c70253f2fe0fa9b63b2c9ba0b1baf1e98c455ea0615cf0d4f42dee66edbea08")

