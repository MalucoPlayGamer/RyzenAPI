-- Lua provided by RyzenAPI
-- Game: 508390

-- MAIN APPLICATION
addappid(508390)
-- Game: addappid(508390)

-- MAIN APP DEPOTS / PACKAGES
addappid(508391, 1, "2cd7ab2a98c32b0ff9be1f5fcc43382438d83c90761922afec128bb437bfbc76")
addappid(508392, 1, "0865fef055b45d86ebfb5657119e31884026bb055f65ae837a83f6d041503266")
addappid(508393, 1, "d2cba8f6446b54c785a1b1b21f52d54ca5557c0e5fda660adc2fc574bde389d6")
