-- Lua provided by RyzenAPI
-- Game: Galactic Glitch: Infinity's Edge Demo

-- MAIN APPLICATION
addappid(2464840)

-- MAIN APP DEPOTS / PACKAGES
addappid(2464841, 1, "48397eba5ae2e1af4bb419ec016196703eb3a79e408dfed48092ae3e445f87e9")

