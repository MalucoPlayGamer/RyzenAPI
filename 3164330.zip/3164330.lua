-- Lua provided by RyzenAPI
-- Game: Infinity Nikki

-- MAIN APPLICATION
addappid(3164330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(3164331, 1, "051df33b7ec49fe04b19ff7fe6d183359f9c89ce57a07a1fa242b94751047516")

