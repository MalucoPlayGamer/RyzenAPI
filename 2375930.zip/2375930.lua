-- Lua provided by RyzenAPI
-- Game: Simple Multipliers

-- MAIN APPLICATION
addappid(2375930)

-- MAIN APP DEPOTS / PACKAGES
addappid(2375931, 1, "b1684bc8303b5e2656ca83cb03561603a7296c8b5d5ac9574411e1b51714d34a")
