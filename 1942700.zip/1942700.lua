-- Lua provided by SkyAPI 
-- Game: Astrea: Six-Sided Oracles - Demo
addappid(1942700)
addappid(1942701, 1, "b16190243a9693fc04774823312b09d997f2ff89e4ee85db5dd0fbb655e0e8ac")
