-- Lua provided by RyzenAPI
-- Game: addappid(1942700)

-- MAIN APPLICATION
addappid(1942700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1942701, 1, "b16190243a9693fc04774823312b09d997f2ff89e4ee85db5dd0fbb655e0e8ac")
