-- Lua provided by RyzenAPI
-- Game: My Step Sisters

-- MAIN APPLICATION
addappid(1526700)
-- Game: addappid(1526700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1526701, 1, "ab5c3f9a77768a49e49e7da5aa05ca7b926563d4254279eac724e7b9eba2d726")
