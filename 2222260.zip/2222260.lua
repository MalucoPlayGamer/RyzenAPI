-- Lua provided by SkyAPI 
-- Game: Gummy Dummy Battles
addappid(2222260)
addappid(2222261, 1, "f690bfe9f0761049f59a5c2b5593793caddc2067fbd0e23df4fd599f230d80bf")
