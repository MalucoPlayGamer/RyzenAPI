-- Lua provided by RyzenAPI
-- Game: Water Defense

-- MAIN APPLICATION
addappid(2461560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2461561, 1, "5e2aa07a7d9b4c05ad621433d134bda3a4a0b4773a8fa3999b8a447f3475a184")
addappid(2461562, 1, "0ed8342b7966f3b466f0773162048361dc8e830edb0e3b91d0070fd809077002")

