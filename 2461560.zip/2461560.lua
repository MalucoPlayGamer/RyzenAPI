-- Lua provided by RyzenAPI
-- Game: Game: Water Defense

-- MAIN APPLICATION
addappid(2461560)
-- Game: addappid(2461560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2461561, 1, "5e2aa07a7d9b4c05ad621433d134bda3a4a0b4773a8fa3999b8a447f3475a184")
addappid(2461562, 1, "0ed8342b7966f3b466f0773162048361dc8e830edb0e3b91d0070fd809077002")
