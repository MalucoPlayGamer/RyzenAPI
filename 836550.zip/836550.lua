-- Lua provided by RyzenAPI
-- Game: AppID 836550

-- MAIN APPLICATION
addappid(836550)
-- Game: addappid(836550)

-- MAIN APP DEPOTS / PACKAGES
addappid(836551, 1, "02e91b4b77c6d35041a286de932b1a8599250807d0334c0bcfa6bf5af038798b")
