-- Lua provided by SkyAPI 
-- Game: AppID 836550
addappid(836550)
addappid(836551, 1, "02e91b4b77c6d35041a286de932b1a8599250807d0334c0bcfa6bf5af038798b")
