-- Lua provided by RyzenAPI
-- Game: addappid(3266530)

-- MAIN APPLICATION
addappid(3266530)

-- MAIN APP DEPOTS / PACKAGES
addappid(3266530,0,"8ae18a716c4b1c3ffcb7f26379f83ae13bd48b91349fedc1cdad8a141413a676")
