-- Lua provided by RyzenAPI
-- Game: Game: The Tower on the Borderland

-- MAIN APPLICATION
addappid(2063180)
-- Game: addappid(2063180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063181, 1, "40ff689655e2a9b81b38138737c2d4a3d2a784ce657cacf9988b4d80e724dcf7")
