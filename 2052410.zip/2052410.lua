-- Lua provided by RyzenAPI
-- Game: addappid(2052410)

-- MAIN APPLICATION
addappid(2052410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2052411, 1, "6ab2d901d86a9f777078ad2d3310ba844676045d51fce0e67d2ad6ec7bb3c39d")
