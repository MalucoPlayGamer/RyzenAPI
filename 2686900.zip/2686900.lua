-- Lua provided by RyzenAPI
-- Game: Churn Vector

-- MAIN APPLICATION
addappid(2686900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686901, 1, "5345442adf6ca691d40d1d4e255b572a60f0bd3c5eed1365dcb9ce1daf27d926")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
