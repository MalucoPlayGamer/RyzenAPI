-- Lua provided by RyzenAPI
-- Game: addappid(2686900)

-- MAIN APPLICATION
addappid(2686900)

-- MAIN APP DEPOTS / PACKAGES
addappid(2686901, 1, "5345442adf6ca691d40d1d4e255b572a60f0bd3c5eed1365dcb9ce1daf27d926")
