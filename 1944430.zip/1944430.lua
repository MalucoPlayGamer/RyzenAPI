-- Lua provided by RyzenAPI
-- Game: Amnesia: The Bunker

-- MAIN APPLICATION
addappid(228981)
addappid(228982)
addappid(228983)
addappid(1944430)
-- Game: addappid(1944430)

-- MAIN APP DEPOTS / PACKAGES
addappid(1944432,0,"53d24d2ad4b763b59e6e9308f511aa3383912e019571d401c5bb5f8d40ad2ce0")
addappid(1944433,0,"e3c66caa20c0b0ce949af4150d408243d025c876c0527ef560b59c3a95cbb230")
addappid(1944434,0,"13ef6a459072b7d6e7868e8f85170eac5fbcaab162fc97ac2848d0815d71ee01")
addappid(1944435,0,"f768d94cca67686f523f605a70f3a9d84573edf287f86aa05d960949db311f44")
