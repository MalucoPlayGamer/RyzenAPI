-- Lua provided by RyzenAPI
-- Game: A Night With Angel

-- MAIN APPLICATION
addappid(2509190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2509191, 1, "a651c1703122b0266f437e2d6e878179ad82bfcdce1f42c599f08a196d050275")
