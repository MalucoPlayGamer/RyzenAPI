-- Lua provided by SkyAPI 
-- Game: AppID 555820
addappid(555820)
addappid(555821, 1, "205b151c78796db81567e24ac16ba695ed1c28633b9031a8d0357c5347d44b7b")
