-- Lua provided by RyzenAPI
-- Game: 555820

-- MAIN APPLICATION
addappid(555820)
-- Game: addappid(555820)

-- MAIN APP DEPOTS / PACKAGES
addappid(555821, 1, "205b151c78796db81567e24ac16ba695ed1c28633b9031a8d0357c5347d44b7b")
