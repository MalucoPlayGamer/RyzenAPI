-- Lua provided by RyzenAPI
-- Game: Game: The Van of Justice

-- MAIN APPLICATION
addappid(1761660)
-- Game: addappid(1761660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1761661, 1, "e64c41dbb7dbd9a8bd1e6d25ab9b034fa925b2e45729eff518eed0c324509419")
