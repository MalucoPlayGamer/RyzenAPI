-- Lua provided by RyzenAPI
-- Game: Calrivar Cluster

-- MAIN APPLICATION
addappid(1900540)

-- MAIN APP DEPOTS / PACKAGES
addappid(1900541, 1, "6cf4af04e4e85426fe91aa1d50c8114729f202f55b1c3a5cbcd568dae481d67d")
