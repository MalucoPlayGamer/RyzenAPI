-- Lua provided by SkyAPI 
-- Game: Calrivar Cluster
addappid(1900540)
addappid(1900541, 1, "6cf4af04e4e85426fe91aa1d50c8114729f202f55b1c3a5cbcd568dae481d67d")
