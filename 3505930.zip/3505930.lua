-- Lua provided by RyzenAPI
-- Game: Skyline

-- MAIN APPLICATION
addappid(3505930)

-- MAIN APP DEPOTS / PACKAGES
addappid(3505931, 1, "87bbc3172759ef04ccf928a8a34893143cfb365d7ab499daa577d2abe72f982b")

