-- Lua provided by RyzenAPI
-- Game: HENPRI

-- MAIN APPLICATION
addappid(3094010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3094011, 1, "870fc4fb313c4a09499c296edacbb27e74a1661e8b4afaed8647a29f1257bed5")
addappid(3094012, 1, "bdf32d10ab2ac7314df070a9922132b900c7380ad8deba4ef1c8f8169c8c75b9")
