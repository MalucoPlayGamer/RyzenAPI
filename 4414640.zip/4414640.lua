-- 4414640's Lua and Manifest Created by Hubcap Manifest
-- World's Greatest Author
-- Created: August 05, 2026 at 13:57:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4414640) -- World's Greatest Author
-- MAIN APP DEPOTS
addappid(4414641, 1, "3a913d9862d61459d4cb29420023f8b9c4d868b8a8d00ada5ecb5bc7aa36b361") -- Depot 4414641
setManifestid(4414641, "3900158268258743727", 200233331)