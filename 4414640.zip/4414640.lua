-- Lua provided by RyzenAPI
-- Game: World's Greatest Author

-- MAIN APPLICATION
addappid(4414640) -- World's Greatest Author

-- MAIN APP DEPOTS / PACKAGES
addappid(4414641, 1, "3a913d9862d61459d4cb29420023f8b9c4d868b8a8d00ada5ecb5bc7aa36b361") -- Depot 4414641

