-- Lua provided by RyzenAPI
-- Game: Covert Syndrome

-- MAIN APPLICATION
addappid(589460)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(589461, 1, "fffd15ac117726381a72f30a3a50806b5933a919e44da4a13b0933a836f643c4")
addappid(635530, 0, "b8a53123a46a6286c79fb8af9d56718af03fb57afe5ac284952370854213a050")

