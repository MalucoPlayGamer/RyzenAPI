-- Lua provided by RyzenAPI
-- Game: Psycho Fear Demo

-- MAIN APPLICATION
addappid(2396610)

-- MAIN APP DEPOTS / PACKAGES
addappid(2396611, 1, "7c51ef31fb0f2c59160e537de016a41c987467fa6d24f3acc832a5deaf31a923")
