-- Lua provided by RyzenAPI
-- Game: Awakening

-- MAIN APPLICATION
addappid(2586870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2586871, 1, "afac45965053d213d0f2c7570cb587e656716e88cfd86dd822455109f187244e")

