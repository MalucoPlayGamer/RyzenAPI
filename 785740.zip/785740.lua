-- Lua provided by RyzenAPI 
-- Game: This Is the Police 2
addappid(785740)
addappid(785741, 1, "9852f66b130c3961fd49e2480b65bbe0b584b39ab2d2f559e5467a697a84ae66")
addappid(785742, 1, "5949bbd88d7cfebf52c3798583fa0d6de33a9c1604ddff4f9e11cf6241ac89a3")
addappid(785743, 1, "ea5522eafa3f2da32305a6f65c3c00ce7d1184da132d37af5549a69f41496690")
addappid(917080, 0, "e1f9ca500ee2d80c6a2a9851cea129c327149076a5ab6cdf478211cd0fdac03c")
