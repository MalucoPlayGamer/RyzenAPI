-- Lua provided by RyzenAPI
-- Game: Drug Dealer Simulator: Free Sample

-- MAIN APPLICATION
addappid(1275630)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1275631, 1, "f603a9d279559832e57ad42bb5202afa9986b976e8f00bf16424dadefdf85932")

