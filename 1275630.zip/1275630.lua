-- Lua provided by RyzenAPI
-- Game: Drug Dealer Simulator: Free Sample

-- MAIN APPLICATION
addappid(1275630)
-- Game: addappid(1275630)

-- MAIN APP DEPOTS / PACKAGES
addappid(1275631, 1, "f603a9d279559832e57ad42bb5202afa9986b976e8f00bf16424dadefdf85932")
