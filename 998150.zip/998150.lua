-- Lua provided by RyzenAPI
-- Game: Game: AppID 998150

-- MAIN APPLICATION
addappid(998150)
-- Game: addappid(998150)

-- MAIN APP DEPOTS / PACKAGES
addappid(998151, 1, "6e8101b8b7f74d6791311a01dfae3db779a0ad3b691fe2d28044397b3b768010")
