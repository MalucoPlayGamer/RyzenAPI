-- Lua provided by RyzenAPI
-- Game: Shadow Man Remastered

-- MAIN APPLICATION
addappid(1413870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1413871, 1, "94726061d1184db1aeb2afec6cea778c721d840dca16a35afb3d9bde3ff3d005")
addappid(1413872, 1, "d56f37831a0e7b7e61de932c332929923951d2e394a81b430c8ffbde29a2897a")
addappid(1413873, 1, "e8971860905a9a52f38868151b9048b4f4afddd76533fe021b25750288992c98")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
