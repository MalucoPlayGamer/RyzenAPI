-- Lua provided by RyzenAPI 
-- Game: Shadow Man Remastered
addappid(1413870)
addappid(1413871, 1, "94726061d1184db1aeb2afec6cea778c721d840dca16a35afb3d9bde3ff3d005")
addappid(1413872, 1, "d56f37831a0e7b7e61de932c332929923951d2e394a81b430c8ffbde29a2897a")
addappid(1413873, 1, "e8971860905a9a52f38868151b9048b4f4afddd76533fe021b25750288992c98")
