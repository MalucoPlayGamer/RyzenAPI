-- Lua provided by RyzenAPI
-- Game: LIGHT: Black Cat & Amnesia Girl

-- MAIN APPLICATION
addappid(1730140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1730141, 1, "08e53c13f93293d1d47a89069e24e7e04dd8d1be8b9d6a985268e11ca3520fb6")
