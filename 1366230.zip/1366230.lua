-- Lua provided by RyzenAPI
-- Game: addappid(1366230)

-- MAIN APPLICATION
addappid(1366230)

-- MAIN APP DEPOTS / PACKAGES
addappid(1366231, 1, "e75e75c381e36604bb8510a73f5fef8a0abea4b824c23689d7b82a179b4bd64b")
