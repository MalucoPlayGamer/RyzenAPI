-- Lua provided by RyzenAPI
-- Game: 1847240

-- MAIN APPLICATION
addappid(1847240)
-- Game: addappid(1847240)

-- MAIN APP DEPOTS / PACKAGES
addappid(1847241, 1, "316b58f994e1005791c2f53ca2cab51044379eef9d51a1fdea4c72cc0e7fd0dd")
