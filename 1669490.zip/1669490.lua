-- Lua provided by RyzenAPI
-- Game: Jerma & Otto: The Curse of the Late Streamer

-- MAIN APPLICATION
addappid(1669490)

