-- Lua provided by RyzenAPI
-- Game: DOOM 3 Resurrection of Evil

-- MAIN APPLICATION
addappid(9070)

-- MAIN APP DEPOTS / PACKAGES
addappid(9071, 1, "ff4f9c0f456fbdf13bbac2511951fbea8fa2e81fac9416dbcee5008845be6b91")

