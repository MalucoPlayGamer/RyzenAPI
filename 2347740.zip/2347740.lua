-- Lua provided by RyzenAPI
-- Game: VenusBlood GAIA International

-- MAIN APPLICATION
addappid(2347740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2347741, 1, "02299be30e0b3789ea6df9bf854adbc5a230b91ff9cbe618365b244db7a7cf74")
addappid(2347742, 1, "138ab629621f7fb3cd3ebaad541b0d9387978296420616f20a51c16e5f0a0da5")
addappid(2347743, 1, "83280cfd99acd63180c4506eb0e9e0f3de7ec05f2b224421e513504b36f3cb09")
