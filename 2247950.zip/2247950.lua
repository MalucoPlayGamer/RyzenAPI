-- Lua provided by RyzenAPI
-- Game: Game: Digital Virus

-- MAIN APPLICATION
addappid(2247950)
-- Game: addappid(2247950)

-- MAIN APP DEPOTS / PACKAGES
addappid(2247951, 1, "f3ddd7c7ffd0322144ccd2168d5401ac2f1f71fbce9e6fdc5b67987bf9338595")
