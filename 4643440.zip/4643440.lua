-- Lua provided by RyzenAPI
-- Game: Harvester vs. Zombies

-- MAIN APPLICATION
addappid(4643440)
addappid(4906810)

-- MAIN APP DEPOTS / PACKAGES
addappid(4643441,0,"4cbad05d8249a033b6336bf43be6b70c170782aa7499f21f0902caf95ac315d5")

