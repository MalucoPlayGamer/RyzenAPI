-- Lua provided by RyzenAPI
-- Game: addappid(1079920)

-- MAIN APPLICATION
addappid(1079920)

-- MAIN APP DEPOTS / PACKAGES
addappid(1079920,0,"4cd0aabf34c9dd4fe814b1a4623786de57fe806dcb51391e6c9ded642d3241e8")
