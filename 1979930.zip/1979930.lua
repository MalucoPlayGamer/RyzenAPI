-- Lua provided by RyzenAPI
-- Game: Game: FreedroidRPG

-- MAIN APPLICATION
addappid(1979930)
-- Game: addappid(1979930)

-- MAIN APP DEPOTS / PACKAGES
addappid(1979931, 1, "112e1bb67e8eabad04b21faf347cdcb85c4a06226ac73830c12d89cf836b0043")
addappid(1979932, 1, "cfff91863a5574e756dcbeceebdc22d5cad81e98f0ae8d964b099779fcf4a4e4")
addappid(1979933, 1, "a081bc209293f9f932752d18e48c2ccb9c55ba755d3a5cdb816e88579935e590")
