-- Lua provided by RyzenAPI
-- Game: AppID 502230

-- MAIN APPLICATION
addappid(502230)

-- MAIN APP DEPOTS / PACKAGES
addappid(502231, 1, "40a8b84af5f96579c5197e7cdc5ec4c79946f30eb01e45debd37a84ed7666af8")
