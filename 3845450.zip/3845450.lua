-- Lua provided by RyzenAPI
-- Game: Gladiator Command

-- MAIN APPLICATION
addappid(3845450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3845451,0,"8dc9b451978d93973408cfbaf449bc335ca0779b006be6c1f6a84a9be79e3336")

