-- Lua provided by RyzenAPI
-- Game: addappid(2911250)

-- MAIN APPLICATION
addappid(2911250)

-- MAIN APP DEPOTS / PACKAGES
addappid(2911251, 1, "2deaa0dc47954277ddd7bd4c82c1656470bae5321e9435ef165f7c29bd08cbd6")
