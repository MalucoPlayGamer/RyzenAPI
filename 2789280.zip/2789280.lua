-- Lua provided by SkyAPI 
-- Game: My Shadow
addappid(2789280)
addappid(2789281, 1, "2aa236dab23b2cde65a91706b52b710f5051b6fe9ccbac8087b76ca69515ac07")
