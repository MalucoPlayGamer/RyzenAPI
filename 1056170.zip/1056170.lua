-- Lua provided by RyzenAPI
-- Game: SUPERVERSE

-- MAIN APPLICATION
addappid(1056170)
-- Game: addappid(1056170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1056171, 1, "88bea39f06ccb4023a36af06f468011d7fcdb4a2544ff5c5fc4a180678f8138e")
