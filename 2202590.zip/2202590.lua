-- Lua provided by RyzenAPI
-- Game: Shape Shifter: Formations

-- MAIN APPLICATION
addappid(2202590)

-- MAIN APP DEPOTS / PACKAGES
addappid(2202591, 1, "9ba4c6b6f7cdb552e31f84baaa2e174457c18887593f3c58a5037cb2185861e5")
