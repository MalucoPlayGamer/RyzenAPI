-- Lua provided by RyzenAPI
-- Game: Game: Space Cycle

-- MAIN APPLICATION
addappid(3162110)
-- Game: addappid(3162110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3162111, 1, "072f43be030489a5c4e3e5ece426eacf8c753286a70a11b08d31f308eed12497")
