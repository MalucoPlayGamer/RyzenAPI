-- Lua provided by RyzenAPI
-- Game: 1685730

-- MAIN APPLICATION
addappid(1685730)
-- Game: addappid(1685730)

-- MAIN APP DEPOTS / PACKAGES
addappid(1685731, 1, "4aaeab4e1dcf72a9f85417a1323da3b5e6f6e1574e1ad5d89e73b5e67ca867e5")
