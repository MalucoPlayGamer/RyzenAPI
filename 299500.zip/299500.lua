-- Lua provided by RyzenAPI
-- Game: International Snooker

-- MAIN APPLICATION
addappid(299500)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(299501, 1, "9a5fadd2010249c6328e1509b9e43ea92fde84bb200445d461d5e479fd763ae0")

