-- Lua provided by RyzenAPI
-- Game: AppID 299500

-- MAIN APPLICATION
addappid(299500)
-- Game: addappid(299500)

-- MAIN APP DEPOTS / PACKAGES
addappid(299501, 1, "9a5fadd2010249c6328e1509b9e43ea92fde84bb200445d461d5e479fd763ae0")
