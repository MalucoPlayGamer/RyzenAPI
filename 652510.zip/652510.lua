-- Lua provided by RyzenAPI
-- Game: ESCAPE Room: Reality

-- MAIN APPLICATION
addappid(652510)

-- MAIN APP DEPOTS / PACKAGES
addappid(652511,0,"fddf7b48cf8339bbc432c3bd96d4967bee482bc1afeaabd7cd536206136ff238")

