-- Lua provided by RyzenAPI
-- Game: Game: Fureraba ~Friend to Lover~

-- MAIN APPLICATION
addappid(822760)
-- Game: addappid(822760)

-- MAIN APP DEPOTS / PACKAGES
addappid(822761, 1, "548b18be32db349247a8527940843e0b9b55a4b42d9d81b47af23c244a29fe97")
addappid(823020, 0, "87cff2135596b19bc6997de0464820bf6524ea7b6c38842b3eaa8dae20e8d7df")
