-- Lua provided by RyzenAPI
-- Game: 1813130

-- MAIN APPLICATION
addappid(1813130)
-- Game: addappid(1813130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1813131, 1, "b7fb435882d02977dc318a3abad245f671174e9daa7fac9adea1cac8360a7ff8")
