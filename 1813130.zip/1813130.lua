-- Lua provided by RyzenAPI 
-- Game: Sugar Shack
addappid(1813130)
addappid(1813131, 1, "b7fb435882d02977dc318a3abad245f671174e9daa7fac9adea1cac8360a7ff8")
