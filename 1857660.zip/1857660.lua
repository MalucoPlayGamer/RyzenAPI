-- Lua provided by RyzenAPI
-- Game: Game: Exes Assault!!

-- MAIN APPLICATION
addappid(1857660)
-- Game: addappid(1857660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1857661, 1, "e099429fbd34dfb7b300c930405264e508ee5a879574414e2446f5ac81a05a18")
