-- Lua provided by RyzenAPI
-- Game: AppID 294670

-- MAIN APPLICATION
addappid(294670)
addappid(303130)
addappid(303131)
addappid(303132)
addappid(303133)
addappid(303134)
addappid(303135)
addappid(303136)
addappid(303137)
addappid(303138)
addappid(303139)
-- Game: addappid(294670)

-- MAIN APP DEPOTS / PACKAGES
addappid(294671, 1, "059ffaea9350d886a1695d1620504b7e4341330d0a47666a78b3e45edc189545")
addappid(294674, 1, "2754d537476a229926dcbc014a4bb9ce4dd8dfff9ee51169940f29ccdd2dcfdf")
addappid(294675, 1, "b9051271ad51ae479f6267a451d3112052cd6d58d81a8d3ccc6b360c8498eb36")
