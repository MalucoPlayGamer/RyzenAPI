-- Lua provided by RyzenAPI
-- Game: Coconut Simulator

-- MAIN APPLICATION
addappid(3335120)
-- Game: addappid(3335120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3335121, 1, "e61a79b31c3b0ad970dcd4f4c367c9a422034046f29e6fab79aa4710d3fe05a1")
