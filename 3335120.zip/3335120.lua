-- Lua provided by RyzenAPI
-- Game: Coconut Simulator

-- MAIN APPLICATION
addappid(3335120)

-- MAIN APP DEPOTS / PACKAGES
addappid(3335121, 1, "e61a79b31c3b0ad970dcd4f4c367c9a422034046f29e6fab79aa4710d3fe05a1")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
