-- Lua provided by SkyAPI 
-- Game: Coconut Simulator
addappid(3335120)
addappid(3335121, 1, "e61a79b31c3b0ad970dcd4f4c367c9a422034046f29e6fab79aa4710d3fe05a1")
