-- Lua provided by RyzenAPI
-- Game: Potion Shop Simulator

-- MAIN APPLICATION
addappid(2788920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2788921, 1, "60c5a660b3c7f3ce85df99d737bffb1fa804e5e013b9fa5f20f95f4b1ce851d2")
