-- Lua provided by RyzenAPI
-- Game: Game: AppID 2199180

-- MAIN APPLICATION
addappid(2199180)
-- Game: addappid(2199180)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199181, 1, "5c2edcbc7352df9f3314cce9926062b65005c601c1a4b8116a90b4ea1d25b467")
addappid(2199182, 1, "876ac3d28ec262aed97f62aa840b5aaa025e98a899022f74096c118ab8d372c9")
