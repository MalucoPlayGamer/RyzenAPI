-- Lua provided by RyzenAPI
-- Game: Sex-Loving Family

-- MAIN APPLICATION
addappid(2199180) -- Sex-Loving Family
addappid(2310140)
addappid(2310141)
addappid(2310170)
addappid(2325610)
addappid(3328760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2199181, 1, "5c2edcbc7352df9f3314cce9926062b65005c601c1a4b8116a90b4ea1d25b467") -- Depot 2199181
addappid(2199182, 1, "876ac3d28ec262aed97f62aa840b5aaa025e98a899022f74096c118ab8d372c9") -- Depot 2199182
addappid(2310140, 1, "087d02cb8cceb3d5d1bc531a993ba5d821bd9e4e87925e1cebd182b6cf0ce30b") -- Sex-Loving Family - Arisa After Story - - Depot 2310140
addappid(2310141, 1, "e12b614b66afc732295c29100b58b6631c48fdbdffd88e5a60d886eae44a1e4e") -- Sex-Loving Family - Fuyuka After Story - - Depot 2310141
addappid(2310170, 1, "de1463a0a59753f584b197afe4c0009fe068739abf33d6ad83a09cfae4c3d131") -- Sex-Loving Family - Manatsu After Story - - Depot 2310170
addappid(2325610, 1, "ca92fdcb81ef6f1b00dee056d9682572b797343ccafcd2e4e430984d15b5d7cb") -- X -  - - Depot 2325610
addappid(3328760, 1, "2ade7d0ff5b6286ba41eafe4f3c5696e7b60b582ba914ed44ee71fdb697a80b1") -- Sex-Loving Family - MOTION DLC - - Depot 3328760
-- addappid(2310142, 1, "MISSING_KEY") -- Sex-Loving Family - Arisa After Story - - Depot 2310142 (no key available)
-- addappid(2310171, 1, "MISSING_KEY") -- Sex-Loving Family - Manatsu After Story - - Depot 2310171 (no key available)
-- addappid(2359400, 1, "MISSING_KEY") -- Sex-Loving Family - Fuyuka After Story - - Depot 2359400 (no key available)
-- addappid(3328761, 1, "MISSING_KEY") -- Sex-Loving Family - MOTION DLC - - Depot 3328761 (no key available)

