-- Lua provided by RyzenAPI
-- Game: Fractal Space Demo

-- MAIN APPLICATION
addappid(1131860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1131864,0,"ed9864902b0ffe489b61eb75527931134ce28a9ba4a9113c81ad915659560e21")

