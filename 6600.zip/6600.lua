-- Lua provided by RyzenAPI
-- Game: Bullet Candy

-- MAIN APPLICATION
addappid(6600)
-- Game: addappid(6600)

-- MAIN APP DEPOTS / PACKAGES
addappid(6602,0,"fd519a2699d5a7fdf4f83122f32ff2dbf329d769d44c689793e8f1cb87f15908")
