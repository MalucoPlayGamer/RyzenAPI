-- Lua provided by RyzenAPI
-- Game: Webventure

-- MAIN APPLICATION
addappid(2500080)
-- Game: addappid(2500080)

-- MAIN APP DEPOTS / PACKAGES
addappid(2500081, 1, "8f78d499d5690e4aba71e88634f91e5ce230408050a49ee467b9a57206bfa1bc")
