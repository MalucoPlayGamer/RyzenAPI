-- Lua provided by RyzenAPI
-- Game: Webventure

-- MAIN APPLICATION
addappid(2500080)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2500081, 1, "8f78d499d5690e4aba71e88634f91e5ce230408050a49ee467b9a57206bfa1bc")

