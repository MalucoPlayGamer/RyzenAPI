-- Lua provided by RyzenAPI
-- Game: AppID 408400

-- MAIN APPLICATION
addappid(408400)

-- MAIN APP DEPOTS / PACKAGES
addappid(408401, 1, "2f3e8c5f79357546bc3d8502b96f524729be6942c7fcc174c005aadddddee74c")

