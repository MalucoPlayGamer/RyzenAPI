-- Lua provided by RyzenAPI
-- Game: Into the Dangerous World I Leapt

-- MAIN APPLICATION
addappid(1674810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1674811, 1, "6a4bffd905d560049dabdec857064936f2c7c512e821585e183e60ff8143a6f1")

