-- Lua provided by RyzenAPI
-- Game: Chants of Sennaar

-- MAIN APPLICATION
addappid(1931770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931771, 1, "eeac188d5d753f9dbe46706d81f78c44b49611ed4d60b201b350b81f3aabc276")
