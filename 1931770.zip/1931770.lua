-- Lua provided by RyzenAPI 
-- Game: Chants of Sennaar
addappid(1931770)
addappid(1931771, 1, "eeac188d5d753f9dbe46706d81f78c44b49611ed4d60b201b350b81f3aabc276")
