-- Lua provided by RyzenAPI
-- Game: Tricone Lab

-- MAIN APPLICATION
addappid(392610)
addappid(392613)

-- MAIN APP DEPOTS / PACKAGES
addappid(392612,0,"0a738fc42d68edeeff52882fdae20b6d9823a889b8881d99851bfcdb82eb371b")

