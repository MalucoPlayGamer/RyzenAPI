-- Lua provided by RyzenAPI
-- Game: Game: Main Deity Space Playtest

-- MAIN APPLICATION
addappid(2706810)
-- Game: addappid(2706810)

-- MAIN APP DEPOTS / PACKAGES
addappid(2706811, 1, "6878a6545f5d411aaf2c12ea0c214b1e564047b82f5b59238eab8059aa760ca2")
