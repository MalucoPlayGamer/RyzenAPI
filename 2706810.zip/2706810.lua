-- Lua provided by SkyAPI 
-- Game: Main Deity Space Playtest
addappid(2706810)
addappid(2706811, 1, "6878a6545f5d411aaf2c12ea0c214b1e564047b82f5b59238eab8059aa760ca2")
