-- Lua provided by RyzenAPI 
-- Game: AppID 1083660
addappid(1083660)
addappid(1083661, 1, "d12b57f7c878b12e5e93cf0807d0e2c8c85480dbc0206a730bb2da6d0250e2b1")
