-- Lua provided by RyzenAPI
-- Game: Fantasy Miner: Idle Depths

-- MAIN APPLICATION
addappid(4428430) -- Fantasy Miner: Idle Depths

-- MAIN APP DEPOTS / PACKAGES
addappid(4428431, 1, "5cc621b423521eeeb350fa1c3eaab8dda95ee5a88702bda4f69c9fc4e1488a4d") -- Depot 4428431
