-- Lua provided by RyzenAPI
-- Game: 2272740

-- MAIN APPLICATION
addappid(2272740)
-- Game: addappid(2272740)

-- MAIN APP DEPOTS / PACKAGES
addappid(2272741, 1, "9c1465e313ef691fef54d42f576c5242cba09b6eca242b605e0411ec60c8e754")
addappid(2272743, 1, "1fc31f7545f7ebbd0a4c202706cb9c6cb53d9884a78e2f65db4a80ca21e6365d")
