-- Lua provided by RyzenAPI
-- Game: Rewind Or Die

-- MAIN APPLICATION
addappid(2329130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2329131, 1, "a2d295a723c92f7c93eefa7770f7674971be0e5aee21dd93d6529ecdda82516a")

