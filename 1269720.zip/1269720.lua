-- Lua provided by RyzenAPI
-- Game: Game: 已下架

-- MAIN APPLICATION
addappid(1269720)
-- Game: addappid(1269720)

-- MAIN APP DEPOTS / PACKAGES
addappid(1269721, 1, "1b92c6ea45df6ea757538aeb827c8031cc4aeaa26961f8bcd60579d50daeae41")
