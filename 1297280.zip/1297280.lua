-- Lua provided by RyzenAPI
-- Game: Game: AppID 1297280

-- MAIN APPLICATION
addappid(1297280)
-- Game: addappid(1297280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1297281, 1, "25c30f9a6a9137f0abc9b019c7a7cad0777bf939352a046e6a74e59080fe8dd3")
