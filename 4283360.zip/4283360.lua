-- Lua provided by RyzenAPI
-- Game: Legionbound

-- MAIN APPLICATION
addappid(4283360)

-- MAIN APP DEPOTS / PACKAGES
addappid(4283361,0,"01f200be7d1a3ee646f73e5bda964c9a0cd0649be19338738dda86338578ed52")
addappid(4283361,0,"01f200be7d1a3ee646f73e5bda964c9a0cd0649be19338738dda86338578ed52") -- Main
addappid(4283362,0,"4ec1e6b49bdf03cb59d1f6d4d3c9f1a9f3b2540a7e17777a32fc4b150752ece0")

