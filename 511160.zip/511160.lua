-- Lua provided by RyzenAPI
-- Game: Cubway

-- MAIN APPLICATION
addappid(229005)
addappid(511160)

-- MAIN APP DEPOTS / PACKAGES
addappid(511165,0,"777a827f8c594c1cda41bdd829fec580c1f5903868fa88537469927979cd95fc")
addappid(511166,0,"8d48f00a062ef389ecfb1fa60b5cb7178fd784c8152fb0c94cb1c2a1e3eee4e7")
addappid(511167,0,"5a2a3b8f2b7da1b55b1fa9fbb51afe1503addc17ce90f30c857ab862a69b6e17")

