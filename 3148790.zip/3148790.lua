-- Lua provided by RyzenAPI 
-- Game: MiSa
addappid(3148790)
addappid(3148791, 1, "d48e599a8ab05b9bf76d9919f9b859fadd8d7660feb4d3a161fb08d1a62d673a")
