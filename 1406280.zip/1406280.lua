-- Lua provided by RyzenAPI
-- Game: Tattoo and Girls

-- MAIN APPLICATION
addappid(1406280)

-- MAIN APP DEPOTS / PACKAGES
addappid(1406281, 1, "8a80dbd112b9da1cf33ee72e774d42597975fa1efb4759291c919c190b76ea36")
