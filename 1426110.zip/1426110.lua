-- Lua provided by RyzenAPI
-- Game: Love n Dream: Virtual Happiness

-- MAIN APPLICATION
addappid(1426110)

-- MAIN APP DEPOTS / PACKAGES
addappid(1426111, 1, "711dccacbec994d76a4a654e82dc28a42ba0f5848de980b2f669a57a781848b7")

