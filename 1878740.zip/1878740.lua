-- Lua provided by RyzenAPI
-- Game: Five Nights At Floppa

-- MAIN APPLICATION
addappid(1878740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1878741, 1, "df66cdcad9b7e78eb0083f69c455633ea8ec8c0f98d68153d20e69752751b79a")

