-- Lua provided by RyzenAPI
-- Game: Asura Girls

-- MAIN APPLICATION
addappid(1284790)
addappid(1290870)

-- MAIN APP DEPOTS / PACKAGES
addappid(1284791, 1, "f0c7b48f0f60f113abf3764f0ad3b042f3b974609716082bfae17765e0f4e906")
