-- Lua provided by RyzenAPI
-- Game: Little Ghosthunter

-- MAIN APPLICATION
addappid(2384680)

-- MAIN APP DEPOTS / PACKAGES
addappid(2384681, 1, "c84286c68b1ad294b086900e675cd9a6d1c42ddad2548574459756d45c39542d")

