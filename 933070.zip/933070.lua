-- Lua provided by RyzenAPI
-- Game: AppID 933070

-- MAIN APPLICATION
addappid(933070)

-- MAIN APP DEPOTS / PACKAGES
addappid(933071, 1, "9a66bf2c817d9c6dc4428a6744ef180fc838db5bb9c7f16dffbfa35280c97a52")
