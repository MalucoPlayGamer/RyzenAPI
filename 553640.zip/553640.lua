-- Lua provided by RyzenAPI
-- Game: AppID 553640

-- MAIN APPLICATION
addappid(553640)
-- Game: addappid(553640)

-- MAIN APP DEPOTS / PACKAGES
addappid(553641, 1, "c43efb7d162191ffd887e73f2373974c64df411656075028af76deadb0f1dfdc")
addappid(553642, 1, "ecfcbba334f887d5fafca898004b2402e6a5fdfce89ed26c819092cdd88bd07c")
addappid(553643, 1, "ebeb0e8ee145d15f4c219bd914b6e1a77e77a82381793d9524d4cbe6dfb27a95")
