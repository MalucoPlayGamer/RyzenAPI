-- Lua provided by RyzenAPI
-- Game: ICEY

-- MAIN APPLICATION
addappid(553640)
addappid(598710)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(553641, 1, "c43efb7d162191ffd887e73f2373974c64df411656075028af76deadb0f1dfdc")
addappid(553642, 1, "ecfcbba334f887d5fafca898004b2402e6a5fdfce89ed26c819092cdd88bd07c")
addappid(553643, 1, "ebeb0e8ee145d15f4c219bd914b6e1a77e77a82381793d9524d4cbe6dfb27a95")

