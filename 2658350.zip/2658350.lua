-- Lua provided by RyzenAPI
-- Game: Vendir: Plague of Lies Demo

-- MAIN APPLICATION
addappid(228990)
addappid(2658350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2658352,0,"4f8d59a168dd6cfa4c160a14657b57dafd513ba570686cfd8297fad78da47def")

