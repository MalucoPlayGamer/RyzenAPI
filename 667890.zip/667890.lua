-- Lua provided by RyzenAPI
-- Game: Dead Maze

-- MAIN APPLICATION
addappid(667890)
