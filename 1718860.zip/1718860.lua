-- Lua provided by RyzenAPI
-- Game: Mayflower Reflections

-- MAIN APPLICATION
addappid(1718860)
-- Game: addappid(1718860)

-- MAIN APP DEPOTS / PACKAGES
addappid(1718861, 1, "caac23ae33ff0389b4a8e28eff994beaeaa40ca730f726a5103e5162eafc80bf")
