-- Lua provided by RyzenAPI
-- Game: Orc Covenant: Gay Bara Orc Visual Novel

-- MAIN APPLICATION
addappid(2243570)
-- Game: addappid(2243570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2243571, 1, "35a67d6834a92e2f4ed8cfeb09b04edb3182490f6a431f3cfc54fc33dee6b692")
