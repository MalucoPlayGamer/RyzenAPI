-- Lua provided by RyzenAPI
-- Game: 1398500

-- MAIN APPLICATION
addappid(1398500)
-- Game: addappid(1398500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398501, 1, "bbc0c263e85303dcd3857fd9aa326ac79450740f4e3c5405043f475baf760d9d")
addappid(1398503, 1, "37f50ee82561ccf2bc8a78dd2a23bef112782a012c6b6d5fae380dd8d61d8181")
