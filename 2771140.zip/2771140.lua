-- Lua provided by RyzenAPI
-- Game: BlazBlue Entropy Effect - Soundtrack A

-- MAIN APPLICATION
addappid(2771140)

-- MAIN APP DEPOTS / PACKAGES
addappid(2771141, 1, "4ea322c9278e847cc773c832e891c5d181c97706fe6327de5dcb50376c1be9c1")
addappid(2771142, 1, "f79ddf0111ff5d536aff589dfda6390b06a13d28f116f9eae97bc36fac3f8a6a")
