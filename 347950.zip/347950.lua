-- Lua provided by RyzenAPI
-- Game: Palace of Cards

-- MAIN APPLICATION
addappid(347950)

