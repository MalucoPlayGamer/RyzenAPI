-- Lua provided by RyzenAPI
-- Game: 457520

-- MAIN APPLICATION
addappid(457520)
-- Game: addappid(457520)

-- MAIN APP DEPOTS / PACKAGES
addappid(457521, 1, "bbc4f21688dbc7720899e0c6f57446c626620295469b125cf564fe03fdb72952")
