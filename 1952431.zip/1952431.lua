-- Lua provided by RyzenAPI
-- Game: RPG Developer Bakin Ruins Pack Vol.2

-- MAIN APPLICATION
addappid(1952431)

-- MAIN APP DEPOTS / PACKAGES
addappid(1952431,0,"e7efb37a23156172bc206e4c115756348277cbd148ece1150bc483e375004686")

