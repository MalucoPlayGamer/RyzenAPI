-- Lua provided by RyzenAPI
-- Game: A Shelter Full of Cats

-- MAIN APPLICATION
addappid(3087650)

-- MAIN APP DEPOTS / PACKAGES
addappid(3087651, 1, "b400ff15150a7a11d92479cda52378438b2aa19195eeca5c197f0bb52d203e4d")

