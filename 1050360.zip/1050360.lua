-- Lua provided by RyzenAPI
-- Game: Game: AppID 1050360

-- MAIN APPLICATION
addappid(1050360)
-- Game: addappid(1050360)

-- MAIN APP DEPOTS / PACKAGES
addappid(1050361, 1, "491b18266f414bbaa0fcc37dd44a5d6a875777dc035f9840d232e5647f05b3b5")
