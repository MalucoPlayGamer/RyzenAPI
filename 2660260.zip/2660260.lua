-- Lua provided by RyzenAPI
-- Game: Castaway Hand

-- MAIN APPLICATION
addappid(2660260)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660261, 1, "71b31138d143517a1448216727fabe7b07817c93b093e14b8f5bbe01c0d8e358")

