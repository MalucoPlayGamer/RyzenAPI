-- Lua provided by RyzenAPI
-- Game: The Narrator Is a DICK

-- MAIN APPLICATION
addappid(473450)

-- MAIN APP DEPOTS / PACKAGES
addappid(473451, 1, "b360ffcfbff598b60e6ab227a88b9749fada2b6d86ba4b0675575c17ac99b396")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
