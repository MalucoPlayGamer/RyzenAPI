-- Lua provided by RyzenAPI
-- Game: Game: The Narrator Is a DICK

-- MAIN APPLICATION
addappid(473450)
-- Game: addappid(473450)

-- MAIN APP DEPOTS / PACKAGES
addappid(473451, 1, "b360ffcfbff598b60e6ab227a88b9749fada2b6d86ba4b0675575c17ac99b396")
