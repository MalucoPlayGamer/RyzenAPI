-- Lua provided by RyzenAPI
-- Game: Atelier Yumia - "Wolf of the Streets" Costume for Rutger

-- MAIN APPLICATION
addappid(3742580)

-- MAIN APP DEPOTS / PACKAGES
addappid(3742580,0,"c2a4b52cc9cd9fa792fcc6ad6977ddff8a449dfe4b21a918a8f2a0f8b21b9381")
