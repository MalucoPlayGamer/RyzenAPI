-- Lua provided by RyzenAPI
-- Game: Hollow Knight - Official Soundtrack

-- MAIN APPLICATION
addappid(598190)

-- MAIN APP DEPOTS / PACKAGES
addappid(598191, 1, "28de6be11136081355170d4d8a3574a02f72f0c537bb232e2b8fb7cd930a8c03")

