-- Lua provided by SkyAPI 
-- Game: MechCrisis
addappid(2376870)
addappid(2376871, 1, "64a82a6eadd954f7a4fbf7d8c260e7c2af6e58d5bd49df4e485961a552d2a6fb")
