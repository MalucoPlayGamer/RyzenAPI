-- Lua provided by RyzenAPI
-- Game: MechCrisis

-- MAIN APPLICATION
addappid(2376870)
-- Game: addappid(2376870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2376871, 1, "64a82a6eadd954f7a4fbf7d8c260e7c2af6e58d5bd49df4e485961a552d2a6fb")
