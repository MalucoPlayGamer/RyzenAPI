-- Lua provided by RyzenAPI
-- Game: addappid(3049580)

-- MAIN APPLICATION
addappid(3049580)
addappid(3213280)
addappid(3215400)
addappid(3215410)
addappid(3215420)
addappid(3215430)
addappid(3215440)
addappid(3215450)

-- MAIN APP DEPOTS / PACKAGES
addappid(3049581, 1, "450d180a5b93d02ff328587d9578f964a1218c6175b5b971b484ce84b0164f59")
