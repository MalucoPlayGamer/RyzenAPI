-- Lua provided by RyzenAPI
-- Game: Malfunction

-- MAIN APPLICATION
addappid(666910)

-- MAIN APP DEPOTS / PACKAGES
addappid(666911,0,"cb0e02fb5f408829d869a6167d0e786fcc2dab2e98ff81abb915a38c6b6507d2")

