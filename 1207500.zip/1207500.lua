-- Lua provided by RyzenAPI
-- Game: 1207500

-- MAIN APPLICATION
addappid(1207500)
-- Game: addappid(1207500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1207501, 1, "dd6bbefb6e9edbb2f87eec95da7ed91a3776b6b0270f8a3fe713c37e91c3bf03")
