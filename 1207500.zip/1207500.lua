-- Lua provided by RyzenAPI 
-- Game: Coffee Break
addappid(1207500)
addappid(1207501, 1, "dd6bbefb6e9edbb2f87eec95da7ed91a3776b6b0270f8a3fe713c37e91c3bf03")
