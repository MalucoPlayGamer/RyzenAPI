-- Lua provided by RyzenAPI
-- Game: Game: Enigmatis 3: The Shadow of Karkhala

-- MAIN APPLICATION
addappid(495110)
addappid(720400)
-- Game: addappid(495110)

-- MAIN APP DEPOTS / PACKAGES
addappid(495111, 1, "00ef2be6021e9e50ea80cb3069052681f0cd97ccc9e9fe378ffad06f5a0d06b9")
addappid(495112, 1, "b8f7a095808edf34d2e44d017f4cc63a18b8f57898c4e28ec7e62b2492afd374")
addappid(495113, 1, "b5124cd6e06977f6af48ef8ece103122016b69b4487d5432e7303af21265d7a8")
