-- Lua provided by RyzenAPI
-- Game: Game: bloody lonely cold

-- MAIN APPLICATION
addappid(2063870)
-- Game: addappid(2063870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2063871, 1, "f41b5bfd415d6ddb159075cfca316c0a4bf5de82a4a8643b879c0edd386cb1b9")
