-- Lua provided by RyzenAPI
-- Game: Constance Demo

-- MAIN APPLICATION
addappid(2564350)

-- MAIN APP DEPOTS / PACKAGES
addappid(2564351, 1, "5332776314724e588af62b799042aff1a051ab244e18bfa68a596cca9898c321")
