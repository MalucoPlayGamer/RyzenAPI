-- Lua provided by RyzenAPI
-- Game: addappid(956700)

-- MAIN APPLICATION
addappid(956700)

-- MAIN APP DEPOTS / PACKAGES
addappid(956700,0,"fba263a6935b15c4a7305a039e333f3a451d2457cf8a45ca150142bd0c4a17a9")
