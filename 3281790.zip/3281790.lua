-- Lua provided by RyzenAPI
-- Game: Vape Store Miami

-- MAIN APPLICATION
addappid(3281790) -- Vape Store Miami

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3281791, 1, "a68b729805d67558728c4df84042aa58abaac9cef7b9cddf6a4000e7aed7a10b") -- Depot 3281791

