-- 3281790's Lua and Manifest Created by Hubcap Manifest
-- Vape Store Miami
-- Created: August 14, 2026 at 11:13:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3281790) -- Vape Store Miami
-- MAIN APP DEPOTS
addappid(3281791, 1, "a68b729805d67558728c4df84042aa58abaac9cef7b9cddf6a4000e7aed7a10b") -- Depot 3281791
setManifestid(3281791, "7721236407648604590", 17348821036)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)