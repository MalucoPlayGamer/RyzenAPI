-- Lua provided by RyzenAPI
-- Game: Rocksmith® 2014 Edition – Remastered – The Notetrackers - Bass - Intermediate Hammer-on Exercise 2

-- MAIN APPLICATION
addappid(1122559)

-- MAIN APP DEPOTS / PACKAGES
addappid(1122559,0,"383c4df90a7564f9295c6803bfc1db266b72db018b6874e7e30b226a43848b0c")

