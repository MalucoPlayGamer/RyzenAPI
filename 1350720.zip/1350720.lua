-- Lua provided by SkyAPI 
-- Game: PaperKlay
addappid(1350720)
addappid(1350721, 1, "c39daa8021487fbcb4d542fccb506af3e1f4f004312fbf51cbdd8163faeb5e99")
