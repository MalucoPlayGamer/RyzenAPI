-- Lua provided by RyzenAPI
-- Game: DEMON GAZE EXTRA

-- MAIN APPLICATION
addappid(1732340)
addappid(1937590)
addappid(1937591)
addappid(1937593)
addappid(1937594)
addappid(1937595)
addappid(1937596)
addappid(1937597)
addappid(3464240)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(1732341, 1, "1207092ee029140ed2eff6e778a50219b80cd2379420b6e3aa1563d3ddd63ad3")

