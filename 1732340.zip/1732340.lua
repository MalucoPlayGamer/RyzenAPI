-- Lua provided by RyzenAPI
-- Game: 1732340

-- MAIN APPLICATION
addappid(1732340)
-- Game: addappid(1732340)

-- MAIN APP DEPOTS / PACKAGES
addappid(1732341, 1, "1207092ee029140ed2eff6e778a50219b80cd2379420b6e3aa1563d3ddd63ad3")
