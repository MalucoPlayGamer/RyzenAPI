-- Lua provided by RyzenAPI
-- Game: 1588970

-- MAIN APPLICATION
addappid(1588970)
-- Game: addappid(1588970)

-- MAIN APP DEPOTS / PACKAGES
addappid(1588970,0,"62aa73cea4267d6931cce0422dcb3e1989e2846c22c436a93e8a5f0b9d181fe1")
