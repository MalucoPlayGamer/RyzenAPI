-- Lua provided by RyzenAPI
-- Game: 724350

-- MAIN APPLICATION
addappid(724350)
-- Game: addappid(724350)

-- MAIN APP DEPOTS / PACKAGES
addappid(724351, 1, "89be9e8650dbeeac904a37ccfd40b40e8518f0cdabdfbd2ea396702c9a958c67")
