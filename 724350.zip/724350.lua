-- Lua provided by RyzenAPI
-- Game: King of the Couch: Zoovival

-- MAIN APPLICATION
addappid(724350)

-- MAIN APP DEPOTS / PACKAGES
addappid(724351, 1, "89be9e8650dbeeac904a37ccfd40b40e8518f0cdabdfbd2ea396702c9a958c67")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
