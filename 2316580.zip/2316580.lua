-- Lua provided by RyzenAPI
-- Game: AppID 2316580

-- MAIN APPLICATION
addappid(2316580)
-- Game: addappid(2316580)

-- MAIN APP DEPOTS / PACKAGES
addappid(2316581, 1, "f7aa9ee7f93fa864a0f020fb5d9ba8417162c6fe2f022581f22f328a2f74e342")
