-- Lua provided by SkyAPI 
-- Game: AppID 2316580
addappid(2316580)
addappid(2316581, 1, "f7aa9ee7f93fa864a0f020fb5d9ba8417162c6fe2f022581f22f328a2f74e342")
