-- Lua provided by RyzenAPI
-- Game: Tales of Kenzera™: ZAU

-- MAIN APPLICATION
addappid(2316580)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- (windows)
addappid(2316581, 1, "f7aa9ee7f93fa864a0f020fb5d9ba8417162c6fe2f022581f22f328a2f74e342")
