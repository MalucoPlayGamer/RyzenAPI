-- Lua provided by RyzenAPI
-- Game: Dreamland

-- MAIN APPLICATION
addappid(2544880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2544881, 1, "a67c60f49e7760faedb47606ce3d208287630e604731e9ee82ed7741a7d1b343")

