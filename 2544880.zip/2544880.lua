-- Lua provided by RyzenAPI
-- Game: Dreamland

-- MAIN APPLICATION
addappid(2544880)
-- Game: addappid(2544880)

-- MAIN APP DEPOTS / PACKAGES
addappid(2544881, 1, "a67c60f49e7760faedb47606ce3d208287630e604731e9ee82ed7741a7d1b343")
