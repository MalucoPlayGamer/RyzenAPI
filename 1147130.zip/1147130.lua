-- Lua provided by RyzenAPI
-- Game: Countryballs: Modern Ballfare

-- MAIN APPLICATION
addappid(1147130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1147131, 1, "d4f8947456038a2985c756b31858c915d2ab826ca8c6533d401e6bda227921ae")
