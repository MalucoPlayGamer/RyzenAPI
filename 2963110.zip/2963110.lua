-- Lua provided by RyzenAPI
-- Game: addappid(2963110)

-- MAIN APPLICATION
addappid(2963110)

-- MAIN APP DEPOTS / PACKAGES
addappid(2963111, 1, "2e310bc9c1aea38712a9db027693b50469ecbd1280b962b965da98aace9e768f")
