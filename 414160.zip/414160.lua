-- Lua provided by SkyAPI 
-- Game: Nubarron: The adventure of an unlucky gnome
addappid(414160)
addappid(414161, 1, "f5702c96580abf91016e604ec9483450f9ef572657ba458ebc13da50db2c01f3")
addappid(414162, 1, "e0ebda6545d19632ec9db4c4d393fc2773be4ebf8f24485ee76ca24797598cc4")
addappid(414163, 1, "012fdc2d566c7215dcb282c390de6a946e53945441d41160ae8f081b8d892a46")
