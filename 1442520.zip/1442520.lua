-- 1442520's Lua and Manifest Created by Hubcap Manifest
-- Akatori
-- Created: August 05, 2026 at 13:38:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1442520, 1, "8240e7cea08855808bb96d838b3a6d3cf7029d7512c19e7d3c6ef68b377134c2") -- Akatori
-- MAIN APP DEPOTS
addappid(1442521, 1, "14c67a4cc34a8d969cad5dbefb7893cf7e407a5bd2c07d09d6d83c3a7a6659cb") -- Depot 1442521
setManifestid(1442521, "168895563364147264", 9464918596)
addappid(1442522, 1, "8568b0062e09c68ad6f1451300f8f67571b79b2808c6bd0d442c47347a813869") -- Depot 1442522
setManifestid(1442522, "4085119776327043512", 9753712657)