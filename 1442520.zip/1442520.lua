-- Lua provided by RyzenAPI
-- Game: Akatori

-- MAIN APP DEPOTS / PACKAGES
addappid(1442520, 1, "8240e7cea08855808bb96d838b3a6d3cf7029d7512c19e7d3c6ef68b377134c2") -- Akatori
addappid(1442521, 1, "14c67a4cc34a8d969cad5dbefb7893cf7e407a5bd2c07d09d6d83c3a7a6659cb") -- Depot 1442521
addappid(1442522, 1, "8568b0062e09c68ad6f1451300f8f67571b79b2808c6bd0d442c47347a813869") -- Depot 1442522



-- DLCs Adicionadas Automaticamente sem necessidade de DepotKey:
addappid(5026500)
