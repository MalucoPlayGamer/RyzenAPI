-- Lua provided by RyzenAPI
-- Game: 神探诸葛执

-- MAIN APPLICATION
addappid(2556600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2556601, 1, "59545840a67cafbbb42e5d293b54cd6e80730a86234b3a1326f77ddf37ebbd0f")
