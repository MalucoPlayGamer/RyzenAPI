-- Lua provided by RyzenAPI
-- Game: Idle Taoist Mage Warrior 2

-- MAIN APPLICATION
addappid(2945100)

-- MAIN APP DEPOTS / PACKAGES
addappid(2945101, 1, "399d7c65ce23ff5f921d48f05f8edb48bae45dd17ee1157ab152ad3a47d88ac3")
