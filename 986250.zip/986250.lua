-- Lua provided by RyzenAPI
-- Game: 986250

-- MAIN APPLICATION
addappid(986250)
-- Game: addappid(986250)

-- MAIN APP DEPOTS / PACKAGES
addappid(986250,0,"32e522702ed804a69738f88dd346ef1c864e3051319322ffd9088cb0b6b8b03a")
addappid(3170940,0,"6f9568f6bea3bcde66441a7caba72a37bdd4bf7ef8820b87d0b1ab6601d3b0df")
