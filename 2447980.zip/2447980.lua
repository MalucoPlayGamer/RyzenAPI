-- Lua provided by RyzenAPI
-- Game: Crown Gambit

-- MAIN APPLICATION
addappid(2447980)

-- MAIN APP DEPOTS / PACKAGES
addappid(2447981, 1, "0f953f0a434dfe917dd66d01bb6e61b66807d427289649ffba29003ca44092c1")
addappid(2447982, 1, "3bd90f54a984cf3b5549bd054886d1ecfa1d50b6ecc397c821b167438a5ac4f7")
