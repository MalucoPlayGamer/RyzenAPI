-- Lua provided by RyzenAPI
-- Game: Systematic Immunity

-- MAIN APPLICATION
addappid(395100)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
addappid(395101, 1, "ca0083b6dda3d44fc986cbf6ce31ae93741854f203a06f041c5132973ba8aaba")
addappid(477830, 0, "fdebd334db1dd77860b66dfa21fec905b70edd6e7153db030175c1d587fdb4b9")

