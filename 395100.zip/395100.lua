-- Lua provided by SkyAPI 
-- Game: AppID 395100
addappid(395100)
addappid(395101, 1, "ca0083b6dda3d44fc986cbf6ce31ae93741854f203a06f041c5132973ba8aaba")
addappid(477830, 0, "fdebd334db1dd77860b66dfa21fec905b70edd6e7153db030175c1d587fdb4b9")
