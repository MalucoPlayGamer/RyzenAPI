-- Lua provided by RyzenAPI
-- Game: AppID 3165010

-- MAIN APPLICATION
addappid(3165010)

-- MAIN APP DEPOTS / PACKAGES
addappid(3165011, 1, "a6f9b32ce7f7b3970a30621bfacf7bcf8beb4db2cfe5356e596762f5ad0eb3ae")
