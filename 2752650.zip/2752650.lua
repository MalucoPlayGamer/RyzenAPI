-- Lua provided by RyzenAPI
-- Game: Game: Trash Top Down Racing

-- MAIN APPLICATION
addappid(2752650)
-- Game: addappid(2752650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2752651, 1, "e11666440a206e295d4970e4c64b80ad1b9bcaab44c1e2711355140752d183d7")
