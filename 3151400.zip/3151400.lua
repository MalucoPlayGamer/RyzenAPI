-- Lua provided by RyzenAPI
-- Game: Liminal Universe

-- MAIN APPLICATION
addappid(3151400)
-- Game: addappid(3151400)

-- MAIN APP DEPOTS / PACKAGES
addappid(3151401, 1, "0fc056cd2ca4230c10a74cd73f2116cad1fe8b329ee5ffdbe4760bd3575c554e")
