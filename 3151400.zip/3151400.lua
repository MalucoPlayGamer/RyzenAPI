-- Lua provided by SkyAPI 
-- Game: Liminal Universe
addappid(3151400)
addappid(3151401, 1, "0fc056cd2ca4230c10a74cd73f2116cad1fe8b329ee5ffdbe4760bd3575c554e")
