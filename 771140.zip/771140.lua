-- Lua provided by RyzenAPI
-- Game: Gravity puzzles

-- MAIN APPLICATION
addappid(771140)

-- MAIN APP DEPOTS / PACKAGES
addappid(771141, 1, "3ddb1e7eb4976f699d0ff0ac1d9a4358fdb00855bba30fe322b1a896dee062e1")
