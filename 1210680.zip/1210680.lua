-- Lua provided by RyzenAPI
-- Game: 封神纪传奇

-- MAIN APPLICATION
addappid(1210680)
-- Game: addappid(1210680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1210681, 1, "241cc5a09f383715b162b3542ad3998c5410e9ae896205c67d2b7318435b90ee")
