-- Lua provided by RyzenAPI 
-- Game: AppID 1138260
addappid(1138260)
addappid(1138261, 1, "247111532605eb1e2303adda058790d384d061816cc3632ebf075a2d8d3d9b40")
