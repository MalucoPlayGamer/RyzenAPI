-- Lua provided by RyzenAPI
-- Game: Outcast 1.1

-- MAIN APPLICATION
addappid(336610)

-- MAIN APP DEPOTS / PACKAGES
addappid(336611, 1, "66f1cc6f4fc6fcdc740941cb0fdc6a071fd1fd6887681313e4b8123ae4a5d057")
addappid(336612, 1, "58cd689555bc8ef45fb1a0f6a9a6860ac8a41f5d9ae7d221e2ca612ec5541f9c")
addappid(336613, 1, "fa0f88d0d46cb48e925869256af1896d601123b78d3e56809f1bf245412adfec")
addappid(338900, 0, "ee71def06ca4af859f0569b6f045c80b2581604bddb362ce4061bf2aef617550")

