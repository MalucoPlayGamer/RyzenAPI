-- Lua provided by RyzenAPI
-- Game: A Series of Temporal Mishaps

-- MAIN APPLICATION
addappid(1905700)
-- Game: addappid(1905700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1905701, 1, "cb70608db9de97ec975728e575e79d731a5608fb8759edc4aacbc95b1582b122")
