-- Lua provided by RyzenAPI 
-- Game: AppID 3045620
addappid(3045620)
addappid(3045621, 1, "b4b66dde4ef5c20c3b9c29f1a5e118a1994ff7ca838cdcfd34513fb6dd1b5e81")
