-- Lua provided by RyzenAPI
-- Game: Stay or Leave / 留离

-- MAIN APPLICATION
addappid(910390)

-- MAIN APP DEPOTS / PACKAGES
addappid(910391, 1, "c082f62b16431da07ef15cfcd57eaf9d2236bd12108277770fc636841949cf5a")
addappid(910392, 1, "ce2b3add91f171171ab098ba94b2d48d57b0913869d303652ff7ab40d3e81669")
addappid(910393, 1, "86c1dadf57fc45c9ced7f3bd183f1a31914eb9bb46a0846456824080ceb9170f")

