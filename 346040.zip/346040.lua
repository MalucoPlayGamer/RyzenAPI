-- Lua provided by RyzenAPI
-- Game: 346040

-- MAIN APPLICATION
addappid(346040)
-- Game: addappid(346040)

-- MAIN APP DEPOTS / PACKAGES
addappid(346041, 1, "69dd53635e2e43b33fb41d7d66f43ea2c19f52aaba8e92f932a7ad91adf1ae2c")
addappid(346042, 1, "03b1b8790e6e09a5a6c102f19d6a8bc2e6f6bb65805ccd0390387e00ae5c98f8")
addappid(346043, 1, "257ed97a9c4c35d469b969a56042fe2b36b80e1719a70a0714230d991f4a2ac3")
