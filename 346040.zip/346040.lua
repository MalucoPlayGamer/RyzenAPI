-- Lua provided by RyzenAPI
-- Game: Joe's Diner

-- MAIN APPLICATION
addappid(346040)

-- MAIN APP DEPOTS / PACKAGES
addappid(346041, 1, "69dd53635e2e43b33fb41d7d66f43ea2c19f52aaba8e92f932a7ad91adf1ae2c")
addappid(346042, 1, "03b1b8790e6e09a5a6c102f19d6a8bc2e6f6bb65805ccd0390387e00ae5c98f8")
addappid(346043, 1, "257ed97a9c4c35d469b969a56042fe2b36b80e1719a70a0714230d991f4a2ac3")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- (windows)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
