-- Lua provided by RyzenAPI 
-- Game: Gassal Simulation
addappid(3397390)
addappid(3397391, 1, "b6049c935ad355c4ffd3255a4db1deb03f42fc61356124c09d17bd7e89b5f63b")
