-- Lua provided by RyzenAPI
-- Game: Game: Gassal Simulation

-- MAIN APPLICATION
addappid(3397390)
-- Game: addappid(3397390)

-- MAIN APP DEPOTS / PACKAGES
addappid(3397391, 1, "b6049c935ad355c4ffd3255a4db1deb03f42fc61356124c09d17bd7e89b5f63b")
