-- Lua provided by RyzenAPI
-- Game: addappid(2607160)

-- MAIN APPLICATION
addappid(2607160)

-- MAIN APP DEPOTS / PACKAGES
addappid(2607161, 1, "ba2dc2c0a6252933526175043e256e36fed5e85d35f1a93d814c609a41f4e57c")
