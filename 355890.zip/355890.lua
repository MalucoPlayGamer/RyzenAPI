-- Lua provided by RyzenAPI
-- Game: Game: AppID 355890

-- MAIN APPLICATION
addappid(355890)
-- Game: addappid(355890)

-- MAIN APP DEPOTS / PACKAGES
addappid(355891, 1, "99164f62754ac2f28e00bfce90764503214d91738af3843bec8c354192cef523")
