-- Lua provided by RyzenAPI
-- Game: 2406130

-- MAIN APPLICATION
addappid(2406130)
-- Game: addappid(2406130)

-- MAIN APP DEPOTS / PACKAGES
addappid(2406131, 1, "422645babbeb58eda4649bd061b7f54aac66108fb78d2918cfa3480987d4afc9")
