-- Lua provided by RyzenAPI
-- Game: 2297360

-- MAIN APPLICATION
addappid(2297360)
-- Game: addappid(2297360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2297361, 1, "25f0f48ec476aefa077578bebec18440c1d5fca8fc9fff83f72007e77a14990e")
