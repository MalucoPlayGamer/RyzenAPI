-- Lua provided by RyzenAPI
-- Game: Deckweaver: Descent Into Chaos

-- MAIN APPLICATION
addappid(2297360)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2297361, 1, "25f0f48ec476aefa077578bebec18440c1d5fca8fc9fff83f72007e77a14990e")

