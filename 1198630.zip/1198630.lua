-- Lua provided by SkyAPI 
-- Game: AppID 1198630
addappid(1198630)
addappid(1198631, 1, "fb73a8d1e506354cbd3a4051c1f6daf1ffc783d5679e8a3633e42d6d09de65ac")
