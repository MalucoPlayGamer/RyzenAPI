-- Lua provided by RyzenAPI
-- Game: InfinitasDM

-- MAIN APPLICATION
addappid(555180)
addappid(570010)
addappid(570430)
addappid(5042660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(555181,0,"88dd33b61919c18b73ca29f9a97ffd90c03e476bd9517d133816a428ae8d01e1")
addappid(682830,0,"9cfbb82cbe408e6731f0a621d83bdb8d2598bb05d97c61de9c8a5debc0720ea8")
addappid(682840,0,"719c235a888f787acadfcf34a370b1aedf75bc803af3e58585f53b61bdca185c")
addappid(682850,0,"527b0d1367068223d5a0c7f6d4a2cd6121514a08d5a4e2e485c6e01fc97cc008")

