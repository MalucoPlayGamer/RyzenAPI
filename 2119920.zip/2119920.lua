-- Lua provided by RyzenAPI
-- Game: 2119920

-- MAIN APPLICATION
addappid(2119920)
-- Game: addappid(2119920)

-- MAIN APP DEPOTS / PACKAGES
addappid(2119920,0,"ff2421ef63bf3fa8d3585c9b6fc1014efc743649e3b734527c08c4b57fb7b34b")
