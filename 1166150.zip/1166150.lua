-- Lua provided by RyzenAPI
-- Game: Darkour Demo

-- MAIN APPLICATION
addappid(1166150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1166151, 1, "1f8948dae66070a13a90b98506fe380237e4f65e448a29f175f5050dd0893d6a")
