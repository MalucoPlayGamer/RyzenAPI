-- Lua provided by SkyAPI 
-- Game: Once Upon A Puppet
addappid(1904880)
addappid(1904881, 1, "3129bb61eb9a39fa8f4d4142993675b18e9f0e0b56b80f4144aa70f3d5301b27")
addappid(3283050, 0, "7028a7810941a57217583d6c134ad780cf24a6f876bc62efb5748b0422d3e478")
