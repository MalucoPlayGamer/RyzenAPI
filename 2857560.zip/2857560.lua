-- Lua provided by RyzenAPI 
-- Game: Helbreath Nemesis
addappid(2857560)
addappid(2857561, 1, "93ec4e15ff383a68c8803d867a80415a7350d16568e9d804817032ac4192b7b1")
