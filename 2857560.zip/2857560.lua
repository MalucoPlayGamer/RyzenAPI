-- Lua provided by RyzenAPI
-- Game: Helbreath Nemesis

-- MAIN APPLICATION
addappid(2857560)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(2857561, 1, "93ec4e15ff383a68c8803d867a80415a7350d16568e9d804817032ac4192b7b1")

