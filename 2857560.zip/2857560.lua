-- Lua provided by RyzenAPI
-- Game: Game: Helbreath Nemesis

-- MAIN APPLICATION
addappid(2857560)
-- Game: addappid(2857560)

-- MAIN APP DEPOTS / PACKAGES
addappid(2857561, 1, "93ec4e15ff383a68c8803d867a80415a7350d16568e9d804817032ac4192b7b1")
