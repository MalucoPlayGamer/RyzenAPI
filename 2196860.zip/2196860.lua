-- Lua provided by RyzenAPI
-- Game: 锚点：封锁区 - Anchors:Blockade Zone

-- MAIN APPLICATION
addappid(2196860)

-- MAIN APP DEPOTS / PACKAGES
addappid(2196861, 1, "00c6e6e6aff8b5ca4c2086da3bdb0add41033932412ee08356bc7e55610237d9")

