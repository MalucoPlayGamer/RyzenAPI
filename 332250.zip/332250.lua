-- Lua provided by SkyAPI 
-- Game: AppID 332250
addappid(332250)
addappid(332251, 1, "144ce932ecd3ceca2d8cc181e729343ebc639bf3235dcc3623198b1ff7639be8")
addappid(332252, 1, "596239b217c83cceb4964af48ad6225a543f1f844f05ed5a89dee18e5c528171")
addappid(362700, 0, "c2d98d2f9267bfd1ff8a304d9d8944a76c5872a2ab888187f5d6cbde4b33ae78")
