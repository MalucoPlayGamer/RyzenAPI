-- Lua provided by RyzenAPI
-- Game: 1173410

-- MAIN APPLICATION
addappid(1173410)
-- Game: addappid(1173410)

-- MAIN APP DEPOTS / PACKAGES
addappid(1173413,0,"12dd03b22ecfc2b35669ae8d286e8f918884be1a5d39ebc74f40abf2cbfd87bc")
