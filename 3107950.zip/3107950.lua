-- Lua provided by RyzenAPI
-- Game: Dangerous line

-- MAIN APPLICATION
addappid(3107950)

-- MAIN APP DEPOTS / PACKAGES
addappid(3107951, 1, "8c5cc23d40edfe937ce4aa968bdc4702aaf9ca60318608000561dd5b21132fb2")
