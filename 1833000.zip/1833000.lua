-- Lua provided by RyzenAPI
-- Game: Game: N0va Desktop

-- MAIN APPLICATION
addappid(1833000)
-- Game: addappid(1833000)

-- MAIN APP DEPOTS / PACKAGES
addappid(1833001, 1, "f1828480ba203c26a02db890b91ed771762072c4f91197569182f1c094504842")
