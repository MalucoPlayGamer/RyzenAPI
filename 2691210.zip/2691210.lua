-- Lua provided by RyzenAPI
-- Game: addappid(2691210)

-- MAIN APPLICATION
addappid(2691210)

-- MAIN APP DEPOTS / PACKAGES
addappid(2691211, 1, "9ca519abd1ac5f04e1e8ea6b0feba65bc90048f098d5bc436fd353d14e278d59")
