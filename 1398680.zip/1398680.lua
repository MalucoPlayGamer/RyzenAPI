-- Lua provided by RyzenAPI
-- Game: Negligee: Girls Night

-- MAIN APPLICATION
addappid(1398680)
-- Game: addappid(1398680)

-- MAIN APP DEPOTS / PACKAGES
addappid(1398681, 1, "1b5c0cdbcb6d69f4a16b2a633feecad545c76e808fa1812f36c42c62b2b77905")
