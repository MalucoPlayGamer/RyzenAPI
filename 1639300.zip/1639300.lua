-- Lua provided by RyzenAPI
-- Game: My devil's voice (MLA)

-- MAIN APPLICATION
addappid(1639300)
-- Game: addappid(1639300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639301, 1, "d12c39d059450d2c13a96c8705db766488a1535698423d1f165052bd8f1d3844")
