-- Lua provided by RyzenAPI
-- Game: AppID 349840

-- MAIN APPLICATION
addappid(349840)

-- MAIN APP DEPOTS / PACKAGES
addappid(349841, 1, "1389d5be1f53334ee2ae9d5d66aac1cf36f863ec107f043cbd26fcb8a8b77ab1")
