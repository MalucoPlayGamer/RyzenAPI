-- Lua provided by RyzenAPI
-- Game: AppID 887800

-- MAIN APPLICATION
addappid(887800)
-- Game: addappid(887800)

-- MAIN APP DEPOTS / PACKAGES
addappid(887801, 1, "9f7e15447dc3ad2152d75efd4bd0067946633b1904e06366d453f6dcad772034")
