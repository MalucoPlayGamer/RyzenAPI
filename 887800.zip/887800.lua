-- Lua provided by RyzenAPI
-- Game: Snooker 19

-- MAIN APPLICATION
addappid(887800)
addappid(1196670)

-- MAIN APP DEPOTS / PACKAGES
addappid(887801,0,"9f7e15447dc3ad2152d75efd4bd0067946633b1904e06366d453f6dcad772034")

