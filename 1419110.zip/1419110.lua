-- Lua provided by RyzenAPI
-- Game: VR Hentai Girl

-- MAIN APPLICATION
addappid(1419110)
addappid(1447949)

-- MAIN APP DEPOTS / PACKAGES
addappid(1419111, 1, "47ef7fef13d51aa8cb623d091acf67368ba558df75275e22a9677677e6d503dc")
