-- Lua provided by RyzenAPI
-- Game: Koi x Shin Ai Kanojo

-- MAIN APPLICATION
addappid(2242710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2242711, 1, "f0c1db2358f96933e8fc301b68cd57f0935a4209cc36c1e12fcd8171b6ed3ada")
