-- Lua provided by RyzenAPI
-- Game: Super Onion Boy 2

-- MAIN APPLICATION
addappid(1624350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1624351, 1, "aea8834bf7568ba1fa7df8886d67d5b34b97b72de61fda520d1e3d0797b18cbf")
