-- Lua provided by RyzenAPI
-- Game: Super Onion Boy 2

-- MAIN APPLICATION
addappid(1624350)

-- MAIN APP DEPOTS / PACKAGES
addappid(1624351, 1, "aea8834bf7568ba1fa7df8886d67d5b34b97b72de61fda520d1e3d0797b18cbf")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
