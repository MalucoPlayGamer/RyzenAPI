-- 4411600's Lua and Manifest Created by Hubcap Manifest
-- 挂机破坏神 IdleDiablo
-- Created: June 23, 2026 at 06:08:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4411600) -- 挂机破坏神 IdleDiablo
-- MAIN APP DEPOTS
addappid(4411601, 1, "f500117c30bf45cd570394269afb5e1bb179cf6e1f027e49c8072cf313a71ac0") -- Depot 4411601
-- setManifestid(4411601, "4177298203040523001", 3622823299)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4845720) --  IdleDiablo 