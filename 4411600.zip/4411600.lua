-- 4411600's Lua and Manifest Created by Hubcap Manifest
-- 挂机破坏神 IdleDiablo
-- Created: July 26, 2026 at 07:18:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 2
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4411600) -- 挂机破坏神 IdleDiablo
-- MAIN APP DEPOTS
addappid(4411601, 1, "f500117c30bf45cd570394269afb5e1bb179cf6e1f027e49c8072cf313a71ac0") -- Depot 4411601
setManifestid(4411601, "5605256455572478797", 3918103427)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4845720) --  IdleDiablo 
addappid(4972260) --  IdleDiablo 