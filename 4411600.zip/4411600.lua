-- Lua provided by RyzenAPI
-- Game: 挂机破坏神 IdleDiablo


addappid(4411600) -- 挂机破坏神 IdleDiablo
addappid(4411601, 1, "f500117c30bf45cd570394269afb5e1bb179cf6e1f027e49c8072cf313a71ac0") -- Depot 4411601
addappid(4845720) --  IdleDiablo 