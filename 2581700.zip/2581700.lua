-- Lua provided by RyzenAPI
-- Game: MotoGP™24

-- MAIN APPLICATION
addappid(2581700)
-- Game: addappid(2581700)

-- MAIN APP DEPOTS / PACKAGES
addappid(2581701, 1, "e39d6ae1bb6e831de54de55033327df2311aa87d6040ac02b99c62f4f325bc38")
