-- Lua provided by RyzenAPI
-- Game: Lovely Fox

-- MAIN APPLICATION
addappid(861030)
-- Game: addappid(861030)

-- MAIN APP DEPOTS / PACKAGES
addappid(861031, 1, "1edbbce1216f5e5b606665022bd508a12eb667daf15874b498d1d6f339844ebd")
