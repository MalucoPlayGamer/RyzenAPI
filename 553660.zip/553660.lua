-- Lua provided by RyzenAPI
-- Game: PWND

-- MAIN APPLICATION
addappid(553660)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(553661, 1, "b4c743e7cb348dba013da6f53e6c12166503d735aa3710fd4dfb3239cf166856")
