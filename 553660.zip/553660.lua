-- Lua provided by RyzenAPI
-- Game: Game: AppID 553660

-- MAIN APPLICATION
addappid(553660)
-- Game: addappid(553660)

-- MAIN APP DEPOTS / PACKAGES
addappid(553661, 1, "b4c743e7cb348dba013da6f53e6c12166503d735aa3710fd4dfb3239cf166856")
