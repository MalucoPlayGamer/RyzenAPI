-- Lua provided by RyzenAPI
-- Game: Command & Conquer™ Generals

-- MAIN APPLICATION
addappid(2229870)

-- MAIN APP DEPOTS / PACKAGES
addappid(2229871, 1, "7bbdd2317efc43e7e825d0523f03388878101281c0b5ff8c220b9a990837f39d")
addappid(2229872, 1, "da4afb8e00b89cac3aa2fc656a41a22a86a6f8c33f9e5afb7cdab361ba57507f")
addappid(2229873, 1, "0d9b435f036655bbde912f8d4222f89bd5c8334a2bd60efaee0c1d967a3b7af9")
addappid(2229874, 1, "8a37d52a0732211131f79f6ffda71c8e87cadb3d3959b11ca7cb97c0f1c197ec")
addappid(2229875, 1, "1459d481fb3c5902a7c895791b74a3390ba77c76efae8422cdd3f6344c0133ab")
addappid(2229876, 1, "0f3a13abecd41f4929440186ee305d7ab83e1bae3ed5f739802525045bba20e1")
addappid(2229877, 1, "1e09a71d84bb05476799e9e386b69af47c4a9912cb7d726d4fc7cfcbfbf9f6e8")
addappid(2229878, 1, "b4d1e2f24bf457b64a0e305ab6ec568912b4d41980f34dd0b7358f49cefbbe9e")
addappid(2229879, 1, "b17ed84f50fd6b6218c11da75b989c4eb8a2ae1d72cdc0612df8cc65f5e1b1a0")
addappid(2237671, 0, "099fb65d8e703d24cd50da14af5857e205b83899a416bced0f17605148ec4e86")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
