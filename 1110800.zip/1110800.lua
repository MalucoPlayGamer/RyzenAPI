-- Lua provided by RyzenAPI
-- Game: 1110800

-- MAIN APPLICATION
addappid(1110800)
-- Game: addappid(1110800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1110801, 1, "3896cdf9f8acc14e8e1590efe147374d5859997e3610bb80b4fc1adb92e4977f")
