-- Lua provided by RyzenAPI
-- Game: Radiant Defense

-- MAIN APPLICATION
addappid(302970)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(302971, 1, "bf51d291cbb5ff8cb9a87fdb40db47ead5af2f0f862647501b232b0e360eac4d")

