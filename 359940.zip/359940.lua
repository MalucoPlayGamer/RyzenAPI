-- Lua provided by RyzenAPI
-- Game: 359940

-- MAIN APPLICATION
addappid(359940)
-- Game: addappid(359940)

-- MAIN APP DEPOTS / PACKAGES
addappid(359941, 1, "e331b6bc4f4d5b22f0756a0cb4a2aa3df2d9534f6b512be2098042706f382814")
