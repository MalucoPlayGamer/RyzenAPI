-- Lua provided by RyzenAPI
-- Game: DeadPoly

-- MAIN APPLICATION
addappid(1621070)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1621071, 1, "951c583576350f9dc860d4bfbb2e454318d1d09c31f9c2e57f7bbee6986407f8")

