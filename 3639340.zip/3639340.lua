-- Lua provided by SkyAPI 
-- Game: Lost in Random: The Eternal Die Official Soundtrack
addappid(3639340)
addappid(3639341, 1, "719cc4c14b687c85e93c5a1966c465428492440535411c2fae7b79bcce22be36")
