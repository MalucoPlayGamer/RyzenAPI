-- Lua provided by RyzenAPI
-- Game: SaGa Emerald Beyond

-- MAIN APPLICATION
addappid(2085000)

-- MAIN APP DEPOTS / PACKAGES
addappid(2085001, 1, "a739ff728c898366c5a53b69e0c1c0df860d226cedd8c2a3530a17a90a1d2895")
