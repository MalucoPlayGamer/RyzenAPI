-- Lua provided by RyzenAPI
-- Game: Sniper Ghost Warrior Contracts 2 Soundtrack

-- MAIN APPLICATION
addappid(1619170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1619171, 1, "8735b1c9ae3ad8a4ea0bc07915c6ae96315023c559a46c03bd2991fe3e21a37a")
addappid(1619172, 1, "e686377cb0e497f65bb29f810aa90c02e8120f4966f34dd37fb9da3ccab9e7c8")
addappid(1619173, 1, "affa4ac6c6181e62219f6389576e37b8d1aae57a94ee117eb04e03a5e26ef09a")
