-- Lua provided by RyzenAPI
-- Game: Element TD

-- MAIN APPLICATION
addappid(578350)

-- MAIN APP DEPOTS / PACKAGES
addappid(578351, 1, "0be5e4d0e2515886c60fc9127d394605d300b69ade561afe71b6fea258cf478b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
