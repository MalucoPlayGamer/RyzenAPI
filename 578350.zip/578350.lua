-- Lua provided by RyzenAPI
-- Game: addappid(578350)

-- MAIN APPLICATION
addappid(578350)

-- MAIN APP DEPOTS / PACKAGES
addappid(578351, 1, "0be5e4d0e2515886c60fc9127d394605d300b69ade561afe71b6fea258cf478b")
