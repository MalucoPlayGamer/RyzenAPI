-- Lua provided by RyzenAPI
-- Game: 1954070

-- MAIN APPLICATION
addappid(1954070)
-- Game: addappid(1954070)

-- MAIN APP DEPOTS / PACKAGES
addappid(1954071, 1, "97b16dcc7b6152ce5e7829d9e5a16cebfbf0cd244dddca9e67168e157b938905")
