-- Lua provided by RyzenAPI
-- Game: With in the Obscurity

-- MAIN APPLICATION
addappid(2817190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817191, 1, "0154b759975b49a6f83ff233528c15280b72a88f020a7fcdddbc48e9c18622bc")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
