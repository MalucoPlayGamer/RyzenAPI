-- Lua provided by RyzenAPI
-- Game: With in the Obscurity

-- MAIN APPLICATION
addappid(2817190)

-- MAIN APP DEPOTS / PACKAGES
addappid(2817191, 1, "0154b759975b49a6f83ff233528c15280b72a88f020a7fcdddbc48e9c18622bc")
