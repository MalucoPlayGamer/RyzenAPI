-- Lua provided by RyzenAPI
-- Game: addappid(1909370)

-- MAIN APPLICATION
addappid(1909370)

-- MAIN APP DEPOTS / PACKAGES
addappid(1909371, 1, "c5dacd9a416674f87ef335cb50501cfa7a588f0422915a198586e00fa1a15e7b")
