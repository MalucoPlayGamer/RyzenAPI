-- Lua provided by RyzenAPI
-- Game: Big Tiddy Goth GF Simulator

-- MAIN APPLICATION
addappid(1304580)

-- MAIN APP DEPOTS / PACKAGES
addappid(1304583,0,"51fbe0bb2767b4d29cacacec1dd78bebfc062f89cd04c23bb06f9c23d5f081ab")
