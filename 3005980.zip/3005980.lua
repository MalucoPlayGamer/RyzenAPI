-- Lua provided by RyzenAPI
-- Game: Hungry Noemi Demo

-- MAIN APPLICATION
addappid(3005980)

-- MAIN APP DEPOTS / PACKAGES
addappid(3005981, 1, "286279245c56c0bb349f175d70168d2f14ae5d7d3c47ca470ebbbc7868fb5c30")
