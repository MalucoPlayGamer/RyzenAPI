-- Lua provided by RyzenAPI 
-- Game: Post Soviet Zombies
addappid(1113310)
addappid(1113311, 1, "413cbffe6a5a75369017c9030ea8c473e2dcdbeca88093de8c60ce353d0273f8")
