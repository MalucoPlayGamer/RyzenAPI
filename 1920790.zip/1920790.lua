-- Lua provided by RyzenAPI
-- Game: Game: 生人症候群

-- MAIN APPLICATION
addappid(1920790)
-- Game: addappid(1920790)

-- MAIN APP DEPOTS / PACKAGES
addappid(1920791, 1, "444d4729e02a29a7b0db3ebf985c73609b770b2a92986e0e65b2bcc5804ed11e")
