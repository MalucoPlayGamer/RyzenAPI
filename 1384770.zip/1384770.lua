-- Lua provided by RyzenAPI
-- Game: 1384770

-- MAIN APPLICATION
addappid(1384770)
-- Game: addappid(1384770)

-- MAIN APP DEPOTS / PACKAGES
addappid(1384771, 1, "6cebd0e1186fc00e399ecd654bbc54c511670b98fbec2598bd81f50431801eeb")
