-- Lua provided by RyzenAPI
-- Game: 10120

-- MAIN APPLICATION
addappid(10120)
-- Game: addappid(10120)

-- MAIN APP DEPOTS / PACKAGES
addappid(10121, 1, "0caabc45dd8ebbe422fd69f931349c59ae8ec82f9385f5cb636a83255fd3619c")
