-- Lua provided by SkyAPI 
-- Game: Aces of the Galaxy™
addappid(10120)
addappid(10121, 1, "0caabc45dd8ebbe422fd69f931349c59ae8ec82f9385f5cb636a83255fd3619c")
