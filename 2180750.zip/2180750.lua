-- Lua provided by RyzenAPI
-- Game: Five Nights At Furry's

-- MAIN APPLICATION
addappid(2180750)
-- Game: addappid(2180750)

-- MAIN APP DEPOTS / PACKAGES
addappid(2180751, 1, "745ee81ca8c8dbcd93b21aefa82adda0b9c68d1d19c195e1b9b534743f210c68")
