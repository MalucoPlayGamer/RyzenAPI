-- Lua provided by RyzenAPI
-- Game: Dark Days of Horror

-- MAIN APPLICATION
addappid(865330)
-- Game: addappid(865330)

-- MAIN APP DEPOTS / PACKAGES
addappid(865331, 1, "9c0527f811638bcb89bb4bafa466a96bcac0fc1187332575a5a602ad2b414e50")
