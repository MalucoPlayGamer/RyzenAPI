-- Lua provided by RyzenAPI
-- Game: Dark Days of Horror

-- MAIN APPLICATION
addappid(865330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(865331, 1, "9c0527f811638bcb89bb4bafa466a96bcac0fc1187332575a5a602ad2b414e50")

