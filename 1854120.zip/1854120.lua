-- Lua provided by RyzenAPI
-- Game: 1854120

-- MAIN APPLICATION
addappid(1854120)
-- Game: addappid(1854120)

-- MAIN APP DEPOTS / PACKAGES
addappid(1854121, 1, "64a0dd4dc1c984a5b33f8bcdbd6430e7b6a747129464beded543e475335d5cd6")
