-- Lua provided by RyzenAPI
-- Game: Game: Gunsmith Simulator: Prologue

-- MAIN APPLICATION
addappid(1230170)
-- Game: addappid(1230170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1230171, 1, "157da1d72d7f391c2a6b5cb72842229b872eb822cfc9bdd3d271882ccae57381")
