-- Lua provided by RyzenAPI 
-- Game: Gunsmith Simulator: Prologue
addappid(1230170)
addappid(1230171, 1, "157da1d72d7f391c2a6b5cb72842229b872eb822cfc9bdd3d271882ccae57381")
