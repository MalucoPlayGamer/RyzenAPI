-- Lua provided by RyzenAPI
-- Game: Game: Gentlemen's Club

-- MAIN APPLICATION
addappid(1717170)
-- Game: addappid(1717170)

-- MAIN APP DEPOTS / PACKAGES
addappid(1717171, 1, "f4a8c7ab099ae214cede532ea6ed218bb0d82448d9fbd88e64c8426fab6642f1")
