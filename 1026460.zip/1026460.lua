-- Lua provided by SkyAPI 
-- Game: AppID 1026460
addappid(1026460)
addappid(1026461, 1, "50964c0c570c2b0169f1f6127572f824e923c13e0005b80e60ec83537e2232e0")
