-- Lua provided by RyzenAPI
-- Game: Seekers of the Ancient Playtest

-- MAIN APPLICATION
addappid(2598600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2598601, 1, "f6c9522bd53e266ce4b9219e7eee69d1411d85768ddceaafe365335c3360953d")

