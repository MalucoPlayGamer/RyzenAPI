-- Lua provided by RyzenAPI
-- Game: Slavistan

-- MAIN APPLICATION
addappid(504770)

-- MAIN APP DEPOTS / PACKAGES
addappid(504771, 1, "08d700ae575efc0242f04850417b07002c99b6f91c35924c28391334bfcc90e6")
