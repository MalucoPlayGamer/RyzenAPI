-- Lua provided by RyzenAPI
-- Game: Game: Football Manager 2022 Demo

-- MAIN APPLICATION
addappid(1624090)
-- Game: addappid(1624090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1624091, 1, "c86917e9ba3c95075dc5e7b39de314b5e13dbef86de4e6d049ff2f791fa0d839")
addappid(1624092, 1, "f57d6cd88e915b4d5b25363ab9aee7893c168404e360db4b87657537c61a5e57")
