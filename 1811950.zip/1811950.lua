-- Lua provided by RyzenAPI 
-- Game: The Legend of Heroes: Kuro no Kiseki
addappid(1811950)
addappid(1811951, 1, "2c335cd857f295d5be4ecf0840e9b0dcd85d44ec2d92fab0647875c394eb38b3")
