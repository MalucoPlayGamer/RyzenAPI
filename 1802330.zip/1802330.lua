-- Lua provided by RyzenAPI
-- Game: 1802330

-- MAIN APPLICATION
addappid(1802330)
-- Game: addappid(1802330)

-- MAIN APP DEPOTS / PACKAGES
addappid(1802331, 1, "46f131b4e99dc03ed60e36b57da8af7e2a449af66b96c4a7caec5cb8d383d9fa")
