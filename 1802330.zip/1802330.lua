-- Lua provided by RyzenAPI
-- Game: INVITATION To FEAR

-- MAIN APPLICATION
addappid(1802330)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(1802331, 1, "46f131b4e99dc03ed60e36b57da8af7e2a449af66b96c4a7caec5cb8d383d9fa")

