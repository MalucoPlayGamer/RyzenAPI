-- Lua provided by SkyAPI 
-- Game: INVITATION To FEAR
addappid(1802330)
addappid(1802331, 1, "46f131b4e99dc03ed60e36b57da8af7e2a449af66b96c4a7caec5cb8d383d9fa")
