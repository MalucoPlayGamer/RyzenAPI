-- Lua provided by RyzenAPI
-- Game: Old World

-- MAIN APPLICATION
addappid(597180)
addappid(1952840)
addappid(2261870)
addappid(2587410)
addappid(2587420)
addappid(2587430)
addappid(3406150)
addappid(4129630)

-- MAIN APP DEPOTS / PACKAGES
addappid(597180,0,"ab078c37955f78c8c435b763a746aebb4922a879e20606dbbb7635067a4ce2cb")
addappid(597181,0,"44832d82ba73423f7ad8811dab24c4890d02a444b7c94d2d4c73e7e66360a704")
addappid(597182,0,"b200a4ee00d34fae0bfef67e80e555f5b500422d66c711c0b2e293f6cbff36e1")
addappid(597183,0,"b055bb1a3d8bec6c1b563fc28e9aa1e1844426e2af6897a7f8aa325444213e24")

