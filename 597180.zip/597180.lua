-- Lua provided by RyzenAPI
-- Game: Game: AppID 597180

-- MAIN APPLICATION
addappid(597180)
-- Game: addappid(597180)

-- MAIN APP DEPOTS / PACKAGES
addappid(597181, 1, "44832d82ba73423f7ad8811dab24c4890d02a444b7c94d2d4c73e7e66360a704")
addappid(597182, 1, "b200a4ee00d34fae0bfef67e80e555f5b500422d66c711c0b2e293f6cbff36e1")
addappid(597183, 1, "b055bb1a3d8bec6c1b563fc28e9aa1e1844426e2af6897a7f8aa325444213e24")
