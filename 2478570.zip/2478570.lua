-- Lua provided by RyzenAPI
-- Game: This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.

-- MAIN APPLICATION
addappid(2478570)

-- MAIN APP DEPOTS / PACKAGES
addappid(2478570,0,"7e7c2e5033dd3cfa8892b739c7e3bfdd87e92f515c5cf515d35205fd32092866")
