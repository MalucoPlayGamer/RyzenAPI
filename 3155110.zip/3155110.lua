-- Lua provided by RyzenAPI
-- Game: addappid(3155110)

-- MAIN APPLICATION
addappid(3155110)

-- MAIN APP DEPOTS / PACKAGES
addappid(3155111, 1, "9c42dc60194a34f656063c71de44930a8993726fccff0fada0cea5531157210f")
