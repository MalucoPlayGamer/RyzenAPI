-- Lua provided by RyzenAPI
-- Game: Equinoxe

-- MAIN APPLICATION
addappid(1536520)
-- Game: addappid(1536520)

-- MAIN APP DEPOTS / PACKAGES
addappid(1536521, 1, "b1cd4889aa56cf0bf4becfd4e59b36f73d4736fa0334d7eab36067c2ed9ff2ff")
