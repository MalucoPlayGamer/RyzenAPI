-- Lua provided by SkyAPI 
-- Game: Equinoxe
addappid(1536520)
addappid(1536521, 1, "b1cd4889aa56cf0bf4becfd4e59b36f73d4736fa0334d7eab36067c2ed9ff2ff")
