-- Lua provided by RyzenAPI
-- Game: Mahjong Magic Journey

-- MAIN APPLICATION
addappid(567140)

-- MAIN APP DEPOTS / PACKAGES
addappid(567141, 1, "505ed4f2c11f57f804d6d77b1e032cf5189ec296576d51f1f2efb3ea18f01dca")

