-- Lua provided by RyzenAPI
-- Game: addappid(1179500)

-- MAIN APPLICATION
addappid(1179500)

-- MAIN APP DEPOTS / PACKAGES
addappid(1179501, 1, "36a585cb1efe2f21361da21fef5d8eb9049894ab737c1c9595324e38bc1e49a9")
