-- Lua provided by RyzenAPI
-- Game: AppID 2353470

-- MAIN APPLICATION
addappid(2353470)
-- Game: addappid(2353470)

-- MAIN APP DEPOTS / PACKAGES
addappid(2353471, 1, "79ad1f0334b4e36d4617a25c9eafce14af598eede4f7ef913ecf0daa7ccbdd76")
addappid(2353472, 1, "12f9071b42bdd8add640c23787cbb538fa01f016c76624df6afba807bf36910b")
addappid(2353473, 1, "196f0eb3d44ee57adbc607a683f6365f033a77816a95b212dc7db30e892e3ad1")
addappid(2353474, 1, "5f01d3b27dae541aed17f1e304d61e677152e93494cd6350a0e1858cccc2902a")
