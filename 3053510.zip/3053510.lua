-- Lua provided by RyzenAPI
-- Game: Game: Nordic Racing

-- MAIN APPLICATION
addappid(3053510)
-- Game: addappid(3053510)

-- MAIN APP DEPOTS / PACKAGES
addappid(3053511, 1, "7a067b8d3ed39763fbca0732e69650bb666fa6c53b6aa02dacc87707d3043bab")
