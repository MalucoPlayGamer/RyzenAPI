-- Lua provided by RyzenAPI
-- Game: addappid(2359170)

-- MAIN APPLICATION
addappid(2359170)

-- MAIN APP DEPOTS / PACKAGES
addappid(2359171, 1, "e630da84effdc7f8ba0a65f1db23f6e91ce5585919da47165f318ebe1e0e6e66")
