-- Lua provided by RyzenAPI 
-- Game: Splody
addappid(467810)
addappid(467811, 1, "856e22fb3f72a2b2cc83fa31434e56a7f9a7b30c0d1323d3f96b8e9ca6d9aba9")
