-- Lua provided by RyzenAPI
-- Game: Game: X-Mutation

-- MAIN APPLICATION
addappid(2788600)
-- Game: addappid(2788600)

-- MAIN APP DEPOTS / PACKAGES
addappid(2788601, 1, "32d4110ab21a7ba807d3932b4aa4cf04b924875ff5030a11b869a1889b60309a")
