-- Lua provided by RyzenAPI
-- Game: X-Mutation

-- MAIN APPLICATION
addappid(2788600)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2788601, 1, "32d4110ab21a7ba807d3932b4aa4cf04b924875ff5030a11b869a1889b60309a")

