-- Lua provided by RyzenAPI
-- Game: The Sekimeiya: Spun Glass

-- MAIN APPLICATION
addappid(1432500)
addappid(1567090)

-- MAIN APP DEPOTS / PACKAGES
addappid(1432504,0,"6c1d89de6f6a7d5c95cb53d3d6233b27b250ffd27010275f040eccbd8edea9a2")

