-- Lua provided by RyzenAPI
-- Game: Grail

-- MAIN APP DEPOTS / PACKAGES
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3597200, 1, "7ec13aa2b0c9734eec5f2c51347f5db30a056bb7b498a8ddfa94ad8c2bcb5532") -- Grail
addappid(3597201, 1, "6631d4b4edec5f38f6c807201c017c283de8cfd6b073af741a06c57f6b743714") -- Depot 3597201
addappid(3597202, 1, "e748a07d02914b4444fde9354c573ccde920ff0447e19c0773e31ab462aea02a") -- Depot 3597202

