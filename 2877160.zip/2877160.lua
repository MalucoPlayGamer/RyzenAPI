-- Lua provided by RyzenAPI
-- Game: 失乐星图Nornium

-- MAIN APPLICATION
addappid(2877160)

-- MAIN APP DEPOTS / PACKAGES
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2877161, 1, "f42a7e5c5f065ef5df11c3d8aad7b2eb3d8e587d483b2fcfd7acf21504695bde")

