-- Lua provided by RyzenAPI 
-- Game: 失乐星图Nornium
addappid(2877160)
addappid(2877161, 1, "f42a7e5c5f065ef5df11c3d8aad7b2eb3d8e587d483b2fcfd7acf21504695bde")
