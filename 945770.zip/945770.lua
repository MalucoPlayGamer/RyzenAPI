-- Lua provided by RyzenAPI
-- Game: Dark Envoy

-- MAIN APPLICATION
addappid(945770)
addappid(2660940)
addappid(4072380)

-- MAIN APP DEPOTS / PACKAGES
addappid(945771, 1, "172381d90e7f0c26b53ddef31436566e858d4c074c17e25ee1f4255db3680820")

