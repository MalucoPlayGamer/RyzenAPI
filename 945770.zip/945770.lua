-- Lua provided by RyzenAPI
-- Game: AppID 945770

-- MAIN APPLICATION
addappid(945770)
-- Game: addappid(945770)

-- MAIN APP DEPOTS / PACKAGES
addappid(945771, 1, "172381d90e7f0c26b53ddef31436566e858d4c074c17e25ee1f4255db3680820")
