-- Lua provided by RyzenAPI
-- Game: Game: AppID 616940

-- MAIN APPLICATION
addappid(616940)
-- Game: addappid(616940)

-- MAIN APP DEPOTS / PACKAGES
addappid(616941, 1, "5d79743ce3eadb5f6c6249a5810a9d61c61db4106e05bdd9150152260832ec60")
