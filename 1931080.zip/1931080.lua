-- Lua provided by RyzenAPI
-- Game: EXS1 Support package-All

-- MAIN APPLICATION
addappid(1931080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1931081, 1, "9803352f42eeb59064303eab5072b3226deba26456acbeb00f958dd14f2781b2")
