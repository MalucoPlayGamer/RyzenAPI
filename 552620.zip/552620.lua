-- Lua provided by RyzenAPI
-- Game: ATOM RPG

-- MAIN APPLICATION
addappid(552620)

-- MAIN APP DEPOTS / PACKAGES
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(552621, 1, "56235ccffecab695a3dcc3d2eb01dd5210fd6753af8b1d880c1838dd69ff2207")
addappid(552622, 1, "c3314d52aacb30754701214039d4e1f9165e12dd0daadbb91458af10597256b4")
addappid(552623, 1, "dd52207a2b2d034fd637d31f830303bc254cbd4a4970da6ce2a6cf742a743c81")
addappid(1093400, 0, "1ac11b97a430b6f2f2c3d45d64ce8dbaa40801e59cfab3e6e28bab6dee3d6481")

