-- Lua provided by RyzenAPI
-- Game: 3347730

-- MAIN APPLICATION
addappid(3347730)
-- Game: addappid(3347730)

-- MAIN APP DEPOTS / PACKAGES
addappid(3347731, 1, "528819ea8eda8c6a85d5137b705af94c64cc5ae3f836e36dc769143e5da18b75")
