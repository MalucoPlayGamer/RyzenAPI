-- Lua provided by RyzenAPI
-- Game: Cats of the Ming Dynasty

-- MAIN APPLICATION
addappid(2854690)
-- Game: addappid(2854690)

-- MAIN APP DEPOTS / PACKAGES
addappid(2854691, 1, "1bfdbfe73456d59cadd2b5ae0ea407e2443376dd14f2c256a3e414e40d4261cf")
