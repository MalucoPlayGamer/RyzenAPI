-- Lua provided by RyzenAPI
-- Game: Game: 长安夜明

-- MAIN APPLICATION
addappid(1243700)
-- Game: addappid(1243700)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243701, 1, "985009cc19e63176509f1b78cc703350206507d01167fdf5ba531920131ad3d5")
