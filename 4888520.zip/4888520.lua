-- 4888520's Lua and Manifest Created by Hubcap Manifest
-- 像素三国-僵尸地牢
-- Created: August 01, 2026 at 09:13:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4888520) -- 像素三国-僵尸地牢
-- MAIN APP DEPOTS
addappid(4888521, 1, "50392ea17102b73ef971581702b371c2bc1b62a7710bed05de839097aaf7159f") -- Depot 4888521
setManifestid(4888521, "2637443558049913620", 335340366)
addappid(4888522, 1, "53e9172a5650cb19be57843cf8afde4b9a5370bb2b48727ecc518af73529588f") -- Depot 4888522
setManifestid(4888522, "1009141270612350369", 306275499)
addappid(4888523, 1, "87d197a79c4340f656d9901e00513ca02738f3e911655ff7c5413edc37d6a551") -- Depot 4888523
setManifestid(4888523, "5330059802430952458", 322001355)