-- Lua provided by RyzenAPI
-- Game: Tkium Exclusion Area

-- MAIN APPLICATION
addappid(1847810)

-- MAIN APP DEPOTS / PACKAGES
addappid(1847819,0,"c7a5af4d1492c38237308c4fcee5c850187203e2528837ea84ed864d8a823ab5")

