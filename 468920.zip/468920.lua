-- Lua provided by RyzenAPI
-- Game: 468920

-- MAIN APPLICATION
addappid(468920)
-- Game: addappid(468920)

-- MAIN APP DEPOTS / PACKAGES
addappid(468921, 1, "a89390f36b8cf58a71b8a903c2a02cb8f0cb1c0593111e8fa42fa776433cc85c")
