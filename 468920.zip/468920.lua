-- Lua provided by RyzenAPI
-- Game: AppID 468920

-- MAIN APPLICATION
addappid(468920)
addappid(940820)
addappid(994210)
addappid(1055290)
addappid(1106170)
addappid(1137540)
addappid(1206630)
addappid(1256780)
addappid(1284880)
addappid(1318290)
addappid(1353980)
addappid(2088220)
addappid(2495880)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
addappid(468921, 1, "a89390f36b8cf58a71b8a903c2a02cb8f0cb1c0593111e8fa42fa776433cc85c")

