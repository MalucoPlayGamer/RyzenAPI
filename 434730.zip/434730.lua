-- Lua provided by RyzenAPI
-- Game: Half Dead

-- MAIN APPLICATION
addappid(434730)

-- MAIN APP DEPOTS / PACKAGES
addappid(434731, 1, "dfa1506ae9e0870abc1a16a85dfbdd420b7b31fe27c2745ae1b788c6c1b15c6a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
