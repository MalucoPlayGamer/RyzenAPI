-- Lua provided by RyzenAPI
-- Game: Game: Half Dead

-- MAIN APPLICATION
addappid(434730)
-- Game: addappid(434730)

-- MAIN APP DEPOTS / PACKAGES
addappid(434731, 1, "dfa1506ae9e0870abc1a16a85dfbdd420b7b31fe27c2745ae1b788c6c1b15c6a")
