-- Lua provided by RyzenAPI
-- Game: The Spatials: Galactology

-- MAIN APPLICATION
addappid(450700)
addappid(494410)

-- MAIN APP DEPOTS / PACKAGES
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- (windows)
addappid(450701, 1, "139383a134cbb73bc8ac6cf2824ee46bea8db7c32c8a518b4d6cd17b87fd318f")
addappid(450702, 1, "5356f0b0f7c6a4d85f3efa3cd71751a920bf1d44d7d0673bc650b8a537860b14")
addappid(450703, 1, "dd7f022befec1681e3293afab89db2e3abeca5531311486a5bf42c4a35afa923")

