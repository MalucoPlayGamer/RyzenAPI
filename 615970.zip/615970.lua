-- Lua provided by RyzenAPI
-- Game: Game: Displaced

-- MAIN APPLICATION
addappid(615970)
-- Game: addappid(615970)

-- MAIN APP DEPOTS / PACKAGES
addappid(615971, 1, "9e00f63eaf2fbd597a5842d0d8745304e128bded97331340dc7fdec5318c581c")
