-- Lua provided by RyzenAPI
-- Game: Tower Tactics: Celestial Dawn

-- MAIN APPLICATION
addappid(2328120)

-- MAIN APP DEPOTS / PACKAGES
addappid(2328120,0,"490ef7ed04441f799c706e147115ef8e12ea9f06fba8ca129bbe175915c77875")

