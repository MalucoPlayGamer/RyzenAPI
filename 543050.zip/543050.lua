-- Lua provided by RyzenAPI
-- Game: ARC Continuum

-- MAIN APPLICATION
addappid(543050)

-- MAIN APP DEPOTS / PACKAGES
addappid(543051, 1, "7d8023bb89b86b64fca7b803ec53f58bed3578a08a3fc06ed915f182c3b5d88e")
