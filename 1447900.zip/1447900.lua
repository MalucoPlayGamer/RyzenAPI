-- Lua provided by SkyAPI 
-- Game: Gold Dust
addappid(1447900)
addappid(1447901, 1, "23ae5346318608cdaae4904a3e6fa9732b8613654a4889a6b544f71961d8c352")
