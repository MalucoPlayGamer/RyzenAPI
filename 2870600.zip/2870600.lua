-- Lua provided by RyzenAPI
-- Game: Euro3v3

-- MAIN APPLICATION
addappid(2870600)
