-- Lua provided by RyzenAPI
-- Game: Hunt: The Unknown Quarry

-- MAIN APPLICATION
addappid(528450)
addappid(571610)

-- MAIN APP DEPOTS / PACKAGES
addappid(528451, 1, "5003ea79b5915fef0c22838dccb713d9aade90d971b319c12ae34d314206c993")
addappid(528452, 1, "3b29337437436b03b43ee4b926f68168f8c84caa26809a1c7b5443c38b4f0666")
addappid(528453, 1, "4e1cfca76ff9bc3d92456b2b0c65c54d120324deed791f5ef62de1bcae6d80ed")
addappid(528454, 1, "612f5ff5dbcf167408dcd06fab1079dcb1cea22b9a7e61b852ffb1f2ef21edd0")
