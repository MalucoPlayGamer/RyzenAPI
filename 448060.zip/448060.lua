-- Lua provided by RyzenAPI
-- Game: X-17

-- MAIN APPLICATION
addappid(448060)
-- Game: addappid(448060)

-- MAIN APP DEPOTS / PACKAGES
addappid(448061, 1, "b964cae45a009e6ecff6cdcf0ea664d8f8c92657f52a3d1865dcdeaf1afe1c43")
