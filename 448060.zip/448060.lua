-- Lua provided by RyzenAPI
-- Game: X-17

-- MAIN APPLICATION
addappid(448060)

-- MAIN APP DEPOTS / PACKAGES
addappid(448061, 1, "b964cae45a009e6ecff6cdcf0ea664d8f8c92657f52a3d1865dcdeaf1afe1c43")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
