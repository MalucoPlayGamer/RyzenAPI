-- Lua provided by SkyAPI 
-- Game: Killsquad
addappid(910490)
addappid(910491, 1, "1833c0dfecf11c74dac0a3b2a4f7f95fbae6d609e5272dee51e1768be41c0ca9")
addappid(1903020)
