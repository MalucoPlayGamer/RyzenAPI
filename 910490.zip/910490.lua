-- Lua provided by RyzenAPI
-- Game: Game: Killsquad

-- MAIN APPLICATION
addappid(910490)
addappid(1903020)
-- Game: addappid(910490)

-- MAIN APP DEPOTS / PACKAGES
addappid(910491, 1, "1833c0dfecf11c74dac0a3b2a4f7f95fbae6d609e5272dee51e1768be41c0ca9")
