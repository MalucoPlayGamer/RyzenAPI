-- Lua provided by SkyAPI 
-- Game: BeYourCat
addappid(2959670)
addappid(2959671, 1, "08957b726649fc2967a1e0590e3e9d1c749cdd782d259ae6e11262da91fa2064")
addappid(2959672, 1, "e702bb40bc1540b86f7d5c8d9417b2645da2cbcedf43dd0271a4ebe702cf3509")
