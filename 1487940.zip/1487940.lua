-- Lua provided by RyzenAPI
-- Game: Game: Nuumonsters

-- MAIN APPLICATION
addappid(1487940)
-- Game: addappid(1487940)

-- MAIN APP DEPOTS / PACKAGES
addappid(1487941, 1, "f7e58eeb6c092a915644a5480a857549a51057c4b64e08893de8bfa444302dcf")
