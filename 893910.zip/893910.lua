-- Lua provided by SkyAPI 
-- Game: Science Simulator
addappid(893910)
addappid(893911, 1, "57dd414ebc2017aa55506d4b587b2ffd4a0e465eb8b406f09444b843f9c8e5cd")
