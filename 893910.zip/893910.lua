-- Lua provided by RyzenAPI
-- Game: 893910

-- MAIN APPLICATION
addappid(893910)
-- Game: addappid(893910)

-- MAIN APP DEPOTS / PACKAGES
addappid(893911, 1, "57dd414ebc2017aa55506d4b587b2ffd4a0e465eb8b406f09444b843f9c8e5cd")
