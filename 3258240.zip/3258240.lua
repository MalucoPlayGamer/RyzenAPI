-- Lua provided by RyzenAPI
-- Game: addappid(3258240)

-- MAIN APPLICATION
addappid(3258240)

-- MAIN APP DEPOTS / PACKAGES
addappid(3258241, 1, "f8007d0d617561b5a2ea4f51d4cfb99d8a128bbb043b2af889fd001d9012e271")
