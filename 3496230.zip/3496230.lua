-- Lua provided by RyzenAPI 
-- Game: 100 Aztec Cats Soundtrack
addappid(3496230)
addappid(3496231, 1, "05c37571c8d494725553b86727dbc080d7b49cfabe8904e8c1eb46ae515d7d0a")
