-- Lua provided by RyzenAPI
-- Game: Game: 100 Aztec Cats Soundtrack

-- MAIN APPLICATION
addappid(3496230)
-- Game: addappid(3496230)

-- MAIN APP DEPOTS / PACKAGES
addappid(3496231, 1, "05c37571c8d494725553b86727dbc080d7b49cfabe8904e8c1eb46ae515d7d0a")
