-- Lua provided by RyzenAPI
-- Game: Elve

-- MAIN APPLICATION
addappid(3026290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3026291, 1, "c579c229e55ddb93e43f9d5f20ccace9d0c5cf8e13511f78e11dd4a4d42dad6e")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
