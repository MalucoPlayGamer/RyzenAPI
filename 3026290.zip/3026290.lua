-- Lua provided by RyzenAPI
-- Game: 3026290

-- MAIN APPLICATION
addappid(3026290)
-- Game: addappid(3026290)

-- MAIN APP DEPOTS / PACKAGES
addappid(3026291, 1, "c579c229e55ddb93e43f9d5f20ccace9d0c5cf8e13511f78e11dd4a4d42dad6e")
