-- Lua provided by RyzenAPI
-- Game: addappid(2437038)

-- MAIN APPLICATION
addappid(2437038)

-- MAIN APP DEPOTS / PACKAGES
addappid(2437038,0,"b0cef4baf5088098bad884ccab84677a6dbd5b413f9b0e5f47bef7a7962fc38f")
