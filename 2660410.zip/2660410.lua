-- Lua provided by RyzenAPI
-- Game: addappid(2660410)

-- MAIN APPLICATION
addappid(2660410)

-- MAIN APP DEPOTS / PACKAGES
addappid(2660411, 1, "c28fa0cbbd5e491db3bed6a601263e0df760ae2165975b45acdfe498d95edab3")
