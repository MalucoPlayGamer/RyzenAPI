-- Lua provided by RyzenAPI
-- Game: RWBY: Arrowfell

-- MAIN APPLICATION
addappid(1982150)

-- MAIN APP DEPOTS / PACKAGES
addappid(1982151, 1, "44d61579bd4d4ca0cabe4459075c54241f32dd7cd805a93bd34c6b47654a1a27")

