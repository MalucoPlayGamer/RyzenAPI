-- Lua provided by RyzenAPI
-- Game: 1989270

-- MAIN APPLICATION
addappid(1989270)
-- Game: addappid(1989270)

-- MAIN APP DEPOTS / PACKAGES
addappid(1989271, 1, "d28b035c178523e9824d85af2171fc42463e9e7b1c4e1845de83bc0e1e0d9a53")
addappid(1989273, 1, "17fc5b4ca7f5602fd795e28f59f2b1378f0733bbb7c75142d5cf72becee0b3d7")
