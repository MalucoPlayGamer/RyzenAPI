-- Lua provided by RyzenAPI
-- Game: addappid(614130)

-- MAIN APPLICATION
addappid(614130)

-- MAIN APP DEPOTS / PACKAGES
addappid(614131, 1, "6a5a9c156cf08150071834e9843004dd6e0ac3a6b06d610fe124bc88a638f386")
