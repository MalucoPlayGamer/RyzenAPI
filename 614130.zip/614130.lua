-- Lua provided by RyzenAPI 
-- Game: AppID 614130
addappid(614130)
addappid(614131, 1, "6a5a9c156cf08150071834e9843004dd6e0ac3a6b06d610fe124bc88a638f386")
