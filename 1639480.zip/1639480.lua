-- Lua provided by RyzenAPI
-- Game: addappid(1639480)

-- MAIN APPLICATION
addappid(1639480)

-- MAIN APP DEPOTS / PACKAGES
addappid(1639481, 1, "2b6cd3a39656359cebabba4f1dc92e26e68b7f5fa75abd695a1fc5dd3a0f7602")
