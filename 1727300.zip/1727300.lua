-- Lua provided by RyzenAPI
-- Game: Graviteam Tactics: Raging Bridgehead

-- MAIN APPLICATION
addappid(1727300)

-- MAIN APP DEPOTS / PACKAGES
addappid(1727300,0,"ed56e3018fb3c462f19e7950caeac5a44d6172ce7d2c815171c68c73a86551c4")

