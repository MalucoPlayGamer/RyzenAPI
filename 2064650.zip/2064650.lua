-- Lua provided by RyzenAPI
-- Game: Tower of Fantasy

-- MAIN APPLICATION
addappid(2064650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2064651, 1, "9ec611ae31513d82d00a4290db1c1fea16a5c2df7f84ecc0adf89aa1792003e9")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
