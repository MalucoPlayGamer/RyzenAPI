-- Lua provided by RyzenAPI
-- Game: Tower of Fantasy

-- MAIN APPLICATION
addappid(2064650)
-- Game: addappid(2064650)

-- MAIN APP DEPOTS / PACKAGES
addappid(2064651, 1, "9ec611ae31513d82d00a4290db1c1fea16a5c2df7f84ecc0adf89aa1792003e9")
