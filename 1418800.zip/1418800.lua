-- Lua provided by RyzenAPI
-- Game: Movavi Video Editor Plus 2021

-- MAIN APPLICATION
addappid(1418800)
addappid(1441870)
addappid(1441871)
addappid(1441872)
addappid(1441873)
addappid(1441874)
addappid(1441875)
addappid(1441876)
addappid(1441877)
addappid(1441878)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418801, 1, "998768ca62def673db3e29eb80ddbe6577e39fc056aeba78b1cfd68a7aeecfab")

