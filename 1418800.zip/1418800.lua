-- Lua provided by RyzenAPI
-- Game: AppID 1418800

-- MAIN APPLICATION
addappid(1418800)
-- Game: addappid(1418800)

-- MAIN APP DEPOTS / PACKAGES
addappid(1418801, 1, "998768ca62def673db3e29eb80ddbe6577e39fc056aeba78b1cfd68a7aeecfab")
