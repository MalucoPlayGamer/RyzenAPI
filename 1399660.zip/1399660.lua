-- Lua provided by RyzenAPI
-- Game: Game: My Little Prince - a jigsaw puzzle tale

-- MAIN APPLICATION
addappid(1399660)
-- Game: addappid(1399660)

-- MAIN APP DEPOTS / PACKAGES
addappid(1399661, 1, "f7f2491fa9364ef94406e949514f730ec539158ddc64b509283aa008bf4b0d99")
addappid(1399662, 1, "7cb9522e48fbc44f5cb1ed5345d2cb30856361622c3a27beaa563c7bf0887207")
