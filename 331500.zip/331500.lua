-- Lua provided by RyzenAPI
-- Game: Executive Assault

-- MAIN APPLICATION
addappid(331500)
addappid(390980)
-- Game: addappid(331500)

-- MAIN APP DEPOTS / PACKAGES
addappid(331501, 1, "a27aa665742db0ac4dec2289fbc86ca193759a7d0ca6321db3152d281e514835")
