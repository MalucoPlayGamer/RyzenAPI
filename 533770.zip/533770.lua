-- Lua provided by RyzenAPI
-- Game: The Writer: A Change Of Identity

-- MAIN APPLICATION
addappid(533770)

-- MAIN APP DEPOTS / PACKAGES
addappid(533771,0,"020ab85c4c144547f1a003c89f20c00a7c017ba04a844fac1d9528e0d9fbf03a")

