-- Lua provided by RyzenAPI
-- Game: 2997060

-- MAIN APPLICATION
addappid(2997060)
-- Game: addappid(2997060)

-- MAIN APP DEPOTS / PACKAGES
addappid(2997062,0,"64cb3ee090810960d3782b5d5cc0c6460af1fbd197e8854cf724ac8122b3a7c6")
