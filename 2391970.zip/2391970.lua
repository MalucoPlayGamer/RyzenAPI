-- Lua provided by RyzenAPI
-- Game: Game: AppID 2391970

-- MAIN APPLICATION
addappid(2391970)
-- Game: addappid(2391970)

-- MAIN APP DEPOTS / PACKAGES
addappid(2391971, 1, "88b2cae7180fc6df7107002a0f022bf08df40985f247c1198aed4f6bccf92bc7")
