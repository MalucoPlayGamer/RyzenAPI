-- Lua provided by RyzenAPI
-- Game: 1844080

-- MAIN APPLICATION
addappid(1844080)
-- Game: addappid(1844080)

-- MAIN APP DEPOTS / PACKAGES
addappid(1844081, 1, "610a1af9d3f35a9c549edb3e56d56eafe4d28be7572cc009d9a1faefde93abc9")
