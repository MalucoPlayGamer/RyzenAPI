-- Lua provided by RyzenAPI
-- Game: KSTG

-- MAIN APPLICATION
addappid(1775740)

-- MAIN APP DEPOTS / PACKAGES
addappid(1775741, 1, "60c772018baeb8d2870af90cfde63b7d22f48cc1cd0c6e9f954ab6eb743fe06c")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
