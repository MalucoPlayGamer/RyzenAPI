-- Lua provided by SkyAPI 
-- Game: KSTG
addappid(1775740)
addappid(1775741, 1, "60c772018baeb8d2870af90cfde63b7d22f48cc1cd0c6e9f954ab6eb743fe06c")
