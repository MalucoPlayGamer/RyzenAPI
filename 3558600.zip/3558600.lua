-- 3558600's Lua and Manifest Created by Hubcap Manifest
-- Leafy Corner
-- Created: July 30, 2026 at 14:19:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 0
-- Shared Depots: 5

-- MAIN APPLICATION
addappid(3558600, 1, "e25a062cccad49bb64c715464ccb31e57981c9838e8b1ed625c3292ca11e250e") -- Leafy Corner
-- MAIN APP DEPOTS
addappid(3558601, 1, "3808dc067fa26bcd76e84bbf45253edc4af82afc8189694779509ed45100d36b") -- Depot 3558601
setManifestid(3558601, "9170674414386078441", 624005351)
addappid(3558602, 1, "06381ef5913ff869939c5645d735f13362c86c0e8f18b99d790409d3b5104443") -- Depot 3558602
setManifestid(3558602, "3708693703396568555", 1379178706)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)