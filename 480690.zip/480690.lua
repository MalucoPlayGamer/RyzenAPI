-- Lua provided by RyzenAPI
-- Game: Inbound

-- MAIN APPLICATION
addappid(480690)

-- MAIN APP DEPOTS / PACKAGES
addappid(480691, 1, "2431e16b5c1e280b705575cd1b1f652b1b1deeec5d51834b15358609c26285ba")
