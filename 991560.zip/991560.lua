-- Generated with Luie @ https://lua.tools/
-- 991560 - ONE PUNCH MAN: A HERO NOBODY KNOWS 
-- Generated 2026-08-13 00:37:07 UTC
-- # Depots (Total/DLC/Shared): 2/0/1

-- Main AppID
addappid(991560, 1, "d8a51d77d4626ef47e048c23bbbd5ee1a8a256f8ea04007c79354b92f473232d")

-- Main Depots
addappid(991561, 1, "f677591f23e8238cfb5f334d9c0ce0842613812bd6e04ecbf022aba0260db721")
setManifestid(991561, "6025362291355450622", 7834380591)

-- DLC's (no depot keys required)
addappid(1171210) -- DLC 1171210
addappid(1171211) -- DLC 1171211
addappid(1176370) -- ONE PUNCH MAN: A HERO NOBODY KNOWS DLC Pack 1: Suiryu
addappid(1176371) -- ONE PUNCH MAN: A HERO NOBODY KNOWS DLC Pack 2: Lightning Max
addappid(1176372) -- ONE PUNCH MAN: A HERO NOBODY KNOWS DLC Pack 3: Watchdog Man
addappid(1176373) -- ONE PUNCH MAN: A HERO NOBODY KNOWS DLC Pack 4: Garou
addappid(1176374) -- DLC 1176374
addappid(1176375) -- DLC 1176375
addappid(1176376) -- DLC 1176376
addappid(1176377) -- DLC 1176377
addappid(1176378) -- ONE PUNCH MAN: A HERO NOBODY KNOWS Pre-Order DLC Pack
addappid(1176379) -- ONE PUNCH MAN: A HERO NOBODY KNOWS Character Pass

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- (windows)
