-- Lua provided by RyzenAPI
-- Game: addappid(991560)

-- MAIN APPLICATION
addappid(991560)

-- MAIN APP DEPOTS / PACKAGES
addappid(991561, 1, "f677591f23e8238cfb5f334d9c0ce0842613812bd6e04ecbf022aba0260db721")
