-- Lua provided by RyzenAPI
-- Game: Game: Death to Spies: Moment of Truth

-- MAIN APPLICATION
addappid(34410)
-- Game: addappid(34410)

-- MAIN APP DEPOTS / PACKAGES
addappid(34411, 1, "532d25ce5fca0513d0047999f98ad682ce859be62ef94b69a999cdae49596ede")
addappid(34412, 1, "192a6f6a8e2bbaf87467eac7f7b5c783cc2a211662595db4f525309c2a90669d")
addappid(34413, 1, "7da4a6b94f26a8dd517c74603a6000fc6521711bd3817633db806aab31bea8e8")
addappid(34414, 1, "9b4b83d12670e214005c6638a41616fb2e29c3dac4aa87b6fc5eaa88b063e7ad")
addappid(34415, 1, "9f57d04ebc348906fd4f990f907546e884d1e991030fa15e3483290b56db3852")
