-- Lua provided by RyzenAPI
-- Game: AppID 2578360

-- MAIN APPLICATION
addappid(2578360)
-- Game: addappid(2578360)

-- MAIN APP DEPOTS / PACKAGES
addappid(2578361, 1, "3d8191322945076df4bc11ef2799ee6efec901c1ea152e0ad1907bf957d7b648")
