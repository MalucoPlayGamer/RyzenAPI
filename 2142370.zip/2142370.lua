-- Lua provided by RyzenAPI
-- Game: King Of Water

-- MAIN APPLICATION
addappid(2142370)

-- MAIN APP DEPOTS / PACKAGES
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
addappid(2142371, 1, "1d2beaf63dee6457972646d7703f6824500155a57cfec6fea5e12670a7283845")

