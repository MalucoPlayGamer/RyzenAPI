-- Lua provided by RyzenAPI
-- Game: King Of Water

-- MAIN APPLICATION
addappid(2142370)

-- MAIN APP DEPOTS / PACKAGES
addappid(2142371, 1, "1d2beaf63dee6457972646d7703f6824500155a57cfec6fea5e12670a7283845")
