-- Lua provided by RyzenAPI
-- Game: Penny Arcade's On the Rain-Slick Precipice of Darkness 4

-- MAIN APPLICATION
addappid(237570)

-- MAIN APP DEPOTS / PACKAGES
addappid(237571, 1, "48b07c62d18ec75ee8474f2efbca10c70e4999e5c23a150d8a47b119b84abc2b")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- (windows)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- (windows)
