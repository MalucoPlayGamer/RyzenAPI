-- Lua provided by RyzenAPI
-- Game: Game: Penny Arcade's On the Rain-Slick Precipice of Darkness 4

-- MAIN APPLICATION
addappid(237570)
-- Game: addappid(237570)

-- MAIN APP DEPOTS / PACKAGES
addappid(237571, 1, "48b07c62d18ec75ee8474f2efbca10c70e4999e5c23a150d8a47b119b84abc2b")
