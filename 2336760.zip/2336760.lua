-- Lua provided by SkyAPI 
-- Game: Immortal Hunters
addappid(2336760)
addappid(2336761, 1, "f12cdd3b0632534870272d3050cd48f2305fd57adb3875cad06d29eaed9f723a")
