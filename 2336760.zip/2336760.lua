-- Lua provided by RyzenAPI
-- Game: Immortal Hunters

-- MAIN APPLICATION
addappid(2336760)

-- MAIN APP DEPOTS / PACKAGES
addappid(2336761, 1, "f12cdd3b0632534870272d3050cd48f2305fd57adb3875cad06d29eaed9f723a")



-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- (windows)
