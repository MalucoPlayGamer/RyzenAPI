-- Lua provided by RyzenAPI
-- Game: Atelier Agnes

-- MAIN APPLICATION
addappid(1684480)
addappid(2323250)

-- MAIN APP DEPOTS / PACKAGES
addappid(1684481, 1, "139faccafe8f96ab69365c0bfd9663ce9a4a3774ee7cee4ec26eca6ce709312f")

