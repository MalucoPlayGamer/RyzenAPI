-- Lua provided by RyzenAPI
-- Game: Ultimate Booster Experience

-- MAIN APPLICATION
addappid(499620)
-- Game: addappid(499620)

-- MAIN APP DEPOTS / PACKAGES
addappid(499621, 1, "ca2f424652033cbca45c36048ee6d3c7b104fec46585c7216a5417370c9a5042")
