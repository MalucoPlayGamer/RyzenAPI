-- Lua provided by RyzenAPI 
-- Game: Ultimate Booster Experience
addappid(499620)
addappid(499621, 1, "ca2f424652033cbca45c36048ee6d3c7b104fec46585c7216a5417370c9a5042")
