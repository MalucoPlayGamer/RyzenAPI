-- Lua provided by RyzenAPI
-- Game: Game: AppID 1243140

-- MAIN APPLICATION
addappid(1243140)
-- Game: addappid(1243140)

-- MAIN APP DEPOTS / PACKAGES
addappid(1243141, 1, "55f0a2bfb871bfb83bf7ce9beba7ed526808cd8f15f933e2bbdc771aa911e471")
