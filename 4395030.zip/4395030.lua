-- 4395030's Lua and Manifest Created by Hubcap Manifest
-- B-Prison Unchain
-- Created: August 13, 2026 at 11:18:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4395030, 1, "7b60f01f11f3dd598c0cd68fac642bfd5ee0bb4c0906ce6102d41aa220adcbc9") -- B-Prison Unchain
-- MAIN APP DEPOTS
addappid(4395031, 1, "57c12e77d0d9b2b9eaa57ff15412b95ba768bf7bc7a210f283643f026629af24") -- Depot 4395031
setManifestid(4395031, "5597563179371805680", 792682185)
addappid(4395032, 1, "54561a062c79a474d629ff3cf157951068dd11f426e0010dae613f468fb0855b") -- Depot 4395032
setManifestid(4395032, "600696430169050149", 792692141)
addappid(4395033, 1, "b8aaace5c584fcb5f17e19a2cc5bbbc90fe37f45671e4656a1025cfebf3c5e77") -- Depot 4395033
setManifestid(4395033, "4753520529615296881", 803296940)
addappid(4395034, 1, "138ad6c4c415d6ee07943d211dcfd0ac955c8bb99cbafe37790712c25f81913e") -- Depot 4395034
setManifestid(4395034, "9152231039083989742", 799860052)