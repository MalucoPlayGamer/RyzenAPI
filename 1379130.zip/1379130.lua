-- Lua provided by RyzenAPI
-- Game: 1379130

-- MAIN APPLICATION
addappid(1379130)
-- Game: addappid(1379130)

-- MAIN APP DEPOTS / PACKAGES
addappid(1379131, 1, "06405abe57f50ad9d667629d8c952e06a77f8003d8c6fcbc1aaacf33764be053")
